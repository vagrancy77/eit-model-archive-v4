"""Authorized phase3 low-LR continuation. No old outputs mutated, no test access."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import sys,json,time,hashlib,random,shutil,traceback,argparse,math
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import Dataset,DataLoader
from scipy import ndimage as ndi
sys.path.insert(0,'E:/Codex')
from eit_final_c4_loop.model import PhysicalReconstruction,C4FullField
from common import DATA,NORMALIZER
from models import objective
from symmetry import SymmetricFields,training_position_policy
from comsol_v4.data_v6 import ComsolDataset,Normalizer,signature,FINAL_SIGNATURE,file_hash
from comsol_v4.paper_common import configure_runtime,tensor_hash
from comsol_feedback_loop.io import write_json,save_checkpoint,replace
sys.path.insert(0,'E:/Codex/eit_short_review_v1')
from review import functions_only

HERE=Path(__file__).resolve().parent
ROOT=Path('E:/Codex/phase3_c4_long_v1')
PARENT=Path('E:/Codex/shape_generalization_v1/phase3/runs/physical_c4_seed20261025/best.pt')
COMPARISON=Path('E:/Codex/c4_same_weight_validation_v2')
OLD=Path('E:/Codex/protrusion_study_v1')
SEED=20261025;PARENT_EPOCH=105
METRIC=functions_only(Path('E:/Codex/eit_short_selection_v1/metrics.py'),{'metric'})['metric']
AGGREGATE=functions_only(Path('E:/Codex/eit_shape_general/evaluate.py'),{'aggregate'})['aggregate']

def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def status(phase,**kw):
    q=dict(phase=phase,pid=os.getpid(),updated_unix=time.time(),test_read=False,**kw)
    write_json(ROOT/'status.json',q);print(json.dumps(q,ensure_ascii=False),flush=True)
def copy_atomic(source,dest):
    dest=Path(dest);temp=dest.with_suffix('.copy.tmp');shutil.copyfile(source,temp);replace(temp,dest)
class Lock:
    def __enter__(self):
        import msvcrt
        ROOT.mkdir(exist_ok=True);self.f=(ROOT/'worker.lock').open('a+b')
        if self.f.tell()==0:self.f.write(b'0');self.f.flush()
        self.f.seek(0);msvcrt.locking(self.f.fileno(),msvcrt.LK_NBLCK,1);return self
    def __exit__(self,*exc):self.f.close()

def configuration():
    deps=[Path('E:/Codex/eit_shape_general')/s for s in ('physical_model.py','models.py','common.py','symmetry.py','evaluate.py')]
    deps += [Path('E:/Codex/eit_final_c4_loop/model.py'),Path('E:/Codex/eit_short_selection_v1/metrics.py')]
    deps += [Path('E:/Codex/eit_reproduction/comsol_v4')/s for s in ('data_v6.py','features.py','paper_common.py')]
    deps += [Path('E:/Codex/eit_reproduction/comsol_feedback_loop/io.py')]
    sources={str(p):file_hash(p) for p in sorted(list(HERE.glob('*.py'))+deps)}
    assets=[PARENT,Path(NORMALIZER),Path('E:/Codex/shape_generalization_v1/phase2/physical_projection.npz'),
       Path('E:/Codex/shape_generalization_v1/phase3/symmetry_acceptance.json'),
       Path('E:/Codex/short_selection_v1/runs/p_full/initial.pt'),
       COMPARISON/'phase3_seed25_on.npz',COMPARISON/'summary.json',COMPARISON/'audit.json',
       COMPARISON/'LONG_TRAIN_PLAN_DRAFT.md']
    return dict(version='phase3-c4-long-v1',authorized='User OK to proposed plan 2026-10-26',
       model='unchanged PhysicalReconstruction; existing C4FullField for validation/inference only',
       parent_checkpoint=str(PARENT),parent_epoch=PARENT_EPOCH,seed=SEED,
       optimizer='fresh AdamW state; pretrained weights retained, old optimizer/scheduler not resumed',
       lr=1e-5,weight_decay=1e-4,batch_size=24,validation_batch_size=2,
       max_additional_epochs=120,min_additional_epochs=20,early_stop_patience=25,early_stop_delta=1e-4,
       lr_patience=5,lr_factor=.5,min_lr=1e-6,lr_threshold=1e-4,lr_threshold_mode='rel',
       gradient_clip_norm=1.,precision='FP32; AMP off; matmul/cuDNN TF32 off',
       data_counts=dict(train=3400,val=720,test_reserved=720),dataset_signature=FINAL_SIGNATURE,
       augmentation='unchanged SymmetricFields; one allowed orientation/case/epoch; no held-out centers',
       epoch_order='seed + 1000003*(105+additional_epoch); rotation uses same absolute epoch',
       loss='original BCE + Dice + 0.1 material SmoothL1; no boundary or ROI/class-specific loss',
       validation='all 720 cases every epoch, C4 pooling; threshold0.5; same local masks for evaluation only',
       selection='maximum U=(all IoU+E local IoU)/2 among A>=epoch0 A-.002; epoch0 eligible; ties keep earlier',
       early_stop='after >=20 epochs, stop when 25 completed epochs without eligible U > patience_reference+1e-4',
       scheduler='ReduceLROnPlateau on generic C4 validation loss, NOT local-ROI training loss',
       error_tradeoff='always report recall and neighbor fill; no new hard fill exclusion threshold',
       checkpoint_every_batches=25,wall_deadline=None,test_read=False,physics_training=False,
       no_complete_champion=True,no_dynamic_K=True,
       limitation='exploratory reused validation, one continuation seed, historical test seen; fixed linear projection not COMSOL-equivalent',
       source_hashes=sources,assets={str(p):file_hash(p) for p in assets})

def protocol(freeze=False):
    p=configuration();path=ROOT/'protocol.json'
    assert p['assets'][str(PARENT)]=='28bf9696d5f3b7034ab4d6ceefb5a370420c408de50e66ca0445333be5bab828'
    assert signature(DATA)==FINAL_SIGNATURE
    if path.exists():assert read(path)==p,'Frozen protocol/source mismatch; do not change a live run'
    elif freeze:write_json(path,p)
    else:raise RuntimeError('Acceptance must freeze protocol first')
    return p,file_hash(path)

class Fields(Dataset):
    def __init__(self,split,limit=None):
        if split not in ('train','val'):raise ValueError('Test data access disabled')
        norm=Normalizer.load(NORMALIZER,DATA);norm.validate_training_contract(DATA,'calibrated')
        source=ComsolDataset(DATA,split,norm);self.rows=source.rows[:limit] if limit else source.rows
        self.fov=source.fov;self.items=[]
        for i,row in enumerate(self.rows):
            assert row['split']==split
            q=source[i];mask=q['mask'].numpy()[0].astype(bool)
            band=(ndi.distance_transform_edt(mask)+ndi.distance_transform_edt(~mask)<=2).astype(np.float32)
            mat=torch.cat((q['sigma'].clamp_min(1e-8).log(),q['eps_r'].clamp_min(1e-8).log()),0)
            self.items.append(dict(measurements=q['features'],mask=q['mask'],log_material=mat,boundary=torch.from_numpy(band)[None]))
            if (i+1)%400==0:status('loading_data',split=split,processed=i+1,total=len(self.rows))
    def __len__(self):return len(self.items)
    def __getitem__(self,i):return self.items[i]

def make(fov):
    m=PhysicalReconstruction(dict(kind='physical'),fov)
    m.load_state_dict(torch.load(PARENT,map_location='cpu',weights_only=True)['model'],strict=True)
    return m.cuda()
def optimizer(m,p):return torch.optim.AdamW(m.parameters(),lr=p['lr'],weight_decay=p['weight_decay'])
def eligible(v,base,p):return v['groups']['A']['iou']>=base['groups']['A']['iou']-.002
def utility(v):return .5*(v['groups']['all']['iou']+v['groups']['E']['local_iou'])
def move(b):return {k:v.cuda() for k,v in b.items()}
def rng_state():return dict(cpu=torch.get_rng_state(),cuda=torch.cuda.get_rng_state_all())
def rng_restore(s):torch.set_rng_state(s['cpu']);torch.cuda.set_rng_state_all(s['cuda'])

def diagnostics(ds):
    by={r['case_id']:r for r in read(OLD/'val_diagnostic.json')['metadata']};out=[]
    for row in ds.rows:
        cid=row['case_id']
        with np.load(OLD/'cache/val'/(cid+'.npz')) as z:out.append((by[cid],z['added'].astype(bool),z['neighbor'].astype(bool)))
    return out

@torch.no_grad()
def evaluate(m,ds,meta,epoch,p,tag):
    m.eval();pool=C4FullField(m).cuda().eval();records=[];probs=[];truths=[];total=0.;start=time.monotonic()
    for raw in DataLoader(ds,batch_size=p['validation_batch_size'],shuffle=False,num_workers=0):
        b=move(raw);o=pool(b['measurements']);_,loss=objective(o,b,m.fov,False)
        total+=float(loss)*len(b['mask']);pp=o['probability'][:,0].cpu().numpy();tt=raw['mask'][:,0].numpy()>.5
        errors=((o['log_material']-b['log_material']).abs()*m.fov).sum((2,3))/m.fov.sum()
        errors=errors.cpu().numpy()
        for j in range(len(pp)):
            info,a,n=meta[len(records)];r=METRIC(pp[j],tt[j],info,a,n)
            r.update(log_sigma_mae=float(errors[j,:2].mean()),log_eps_mae=float(errors[j,2:].mean()))
            records.append(r);probs.append(pp[j]);truths.append(tt[j])
        if len(records)%120==0:status('validation',epoch=epoch,processed=len(records),total=len(ds),tag=tag)
    groups=AGGREGATE(records)
    for name,g in groups.items():
        rr=[r for r in records if name=='all' or name==r['shape_class'] or (name=='BCDE' and r['shape_class']!='A') or (name.startswith('E_') and r.get('bump_size_class')==name[2:])]
        for k in ('log_sigma_mae','log_eps_mae'):g[k]=float(np.mean([r[k] for r in rr]))
    result=dict(epoch=epoch,tag=tag,score=total/len(ds),groups=groups,records=records,seconds=time.monotonic()-start)
    result['utility']=utility(result)
    # Attempts get their own filenames; a resumed validation never overwrites evidence.
    path=ROOT/'validation'/f'epoch_{epoch:04d}_{tag}'
    path.parent.mkdir(exist_ok=True)
    if path.with_suffix('.json').exists():path=path.with_name(path.name+f'_retry_{time.time_ns()}')
    np.savez_compressed(path.with_suffix('.npz'),probability=np.stack(probs),truth=np.stack(truths),case_ids=np.array([r['case_id'] for r in records]))
    result['prediction_path']=str(path.with_suffix('.npz'));result['prediction_sha256']=file_hash(path.with_suffix('.npz'))
    result['result_path']=str(path.with_suffix('.json'));write_json(path.with_suffix('.json'),result)
    del pool;return result

def acceptance():
    configure_runtime(SEED);p,ph=protocol(True)
    assert read(COMPARISON/'audit.json')['status']=='PASS'
    expected=read('E:/Codex/shape_generalization_v1/phase3/symmetry_acceptance.json')['policy']
    assert training_position_policy()==expected,'Historical augmentation ownership policy changed'
    tr=Fields('train',48);aug=SymmetricFields(tr,True,SEED);aug.epoch=PARENT_EPOCH+1
    m=make(tr.fov);parent_hash=tensor_hash(m.state_dict());opt=optimizer(m,p)
    batch=move(next(iter(DataLoader(aug,batch_size=24,shuffle=False))))
    m.train();value,_=objective(m(batch['measurements']),batch,m.fov,False)
    assert torch.isfinite(value);opt.zero_grad(set_to_none=True);value.backward()
    assert all(t.grad is not None and torch.isfinite(t.grad).all() for t in m.parameters())
    grad=float(torch.nn.utils.clip_grad_norm_(m.parameters(),1.,error_if_nonfinite=True));opt.step()
    updated=tensor_hash(m.state_dict());assert updated!=parent_hash
    qa=ROOT/'qa';qa.mkdir(exist_ok=True)
    saved=dict(model=m.state_dict(),optimizer=opt.state_dict(),rng=rng_state(),next_batch=1)
    save_checkpoint(qa/'resume_fixture.pt',saved)
    ck=torch.load(qa/'resume_fixture.pt',map_location='cpu',weights_only=True)
    restored=make(tr.fov);restored.load_state_dict(ck['model'],strict=True);opt2=optimizer(restored,p);opt2.load_state_dict(ck['optimizer'])
    assert tensor_hash(restored.state_dict())==updated
    for k,v in opt.state_dict()['state'].items():
        for name,t in v.items():
            other=opt2.state_dict()['state'][k][name]
            assert torch.equal(t.cpu(),other.cpu()) if torch.is_tensor(t) else t==other
    m.eval();restored.eval()
    with torch.no_grad():
        a=m(batch['measurements'])['probability'];b=restored(batch['measurements'])['probability']
        assert torch.equal(a,b)
        C4FullField(restored).cuda()(batch['measurements'][:2])
    del m,restored,opt,opt2,batch;torch.cuda.empty_cache()
    # QA updates are discarded; production re-loads exact unmodified parent.
    m=make(tr.fov);assert tensor_hash(m.state_dict())==parent_hash;del m
    p2,ph2=protocol();assert ph2==ph
    write_json(ROOT/'acceptance.json',dict(status='PASS',protocol_sha256=ph,finite_backward=True,
       gradient_norm_before_clip=grad,checkpoint_model_optimizer_roundtrip_exact=True,
       restored_forward_exact=True,qa_updates_discarded=True,training_position_policy_pass=True,
       parent_core_tensor_hash=parent_hash,qa_loss=float(value),test_read=False))
    status('accepted_not_started',protocol_sha256=ph)

def run():
    configure_runtime(SEED);p,ph=protocol();qa=read(ROOT/'acceptance.json')
    assert qa['status']=='PASS' and qa['protocol_sha256']==ph
    if (ROOT/'complete.json').exists():print('Already complete; never auto-extend');return
    if not (ROOT/'launch.json').exists():write_json(ROOT/'launch.json',dict(started_unix=time.time(),protocol_sha256=ph))
    write_json(ROOT/'worker_identity.json',dict(pid=os.getpid(),started_unix=time.time(),entry=str(__file__),protocol_sha256=ph))
    tr=Fields('train');va=Fields('val');assert len(tr)==3400 and len(va)==720
    meta=diagnostics(va);aug=SymmetricFields(tr,True,SEED)
    m=make(tr.fov);opt=optimizer(m,p)
    sched=torch.optim.lr_scheduler.ReduceLROnPlateau(opt,factor=p['lr_factor'],patience=p['lr_patience'],min_lr=p['min_lr'],threshold=p['lr_threshold'],threshold_mode=p['lr_threshold_mode'])
    history=[];epoch_done=0;next_batch=0;loss_total=0.;seen=0;global_updates=0;bad=0;order_hash=None
    checkpoint_dir=ROOT/'checkpoints';checkpoint_dir.mkdir(exist_ok=True)
    if (ROOT/'last.pt').exists():
        ck=torch.load(ROOT/'last.pt',map_location='cpu',weights_only=True);assert ck['protocol_sha256']==ph
        m.load_state_dict(ck['model'],strict=True);opt.load_state_dict(ck['optimizer']);sched.load_state_dict(ck['scheduler']);rng_restore(ck['rng'])
        epoch_done=ck['epoch_completed'];next_batch=ck['next_batch'];loss_total=ck['loss_total'];seen=ck['seen'];global_updates=ck['global_updates']
        history=ck['history'];bad=ck['bad'];best_u=ck['best_u'];best_epoch=ck['best_epoch'];best_path=Path(ck['best_path']);patience_ref=ck['patience_reference'];order_hash=ck['order_hash']
        baseline=read(ROOT/'baseline.json');copy_atomic(best_path,ROOT/'best.pt')
        del ck
    else:
        assert tensor_hash(m.state_dict())==qa['parent_core_tensor_hash']
        baseline=evaluate(m,va,meta,0,p,'baseline')
        with np.load(baseline['prediction_path']) as z:fresh=z['probability'];ids=z['case_ids']
        with np.load(COMPARISON/'phase3_seed25_on.npz') as z:
            assert np.array_equal(ids,z['case_ids']);assert np.array_equal(fresh>=.5,z['probability']>=.5)
            diff=float(np.max(np.abs(fresh-z['probability'])));assert diff<1e-4,diff
        expected=read(COMPARISON/'summary.json')['phase3_seed25_on']
        assert abs(baseline['utility']-expected['U'])<1e-12
        write_json(ROOT/'baseline.json',baseline);write_json(ROOT/'baseline_acceptance.json',dict(status='PASS',max_probability_difference=diff,baseline_U=baseline['utility'],test_read=False))
        best_u=baseline['utility'];best_epoch=0;patience_ref=best_u;best_path=checkpoint_dir/'epoch_0000.pt'
        save_checkpoint(best_path,dict(model=m.state_dict(),protocol_sha256=ph,epoch=0,utility=best_u,validation=baseline['result_path']))
        copy_atomic(best_path,ROOT/'best.pt')
    def save_last():
        save_checkpoint(ROOT/'last.pt',dict(model=m.state_dict(),optimizer=opt.state_dict(),scheduler=sched.state_dict(),rng=rng_state(),
          protocol_sha256=ph,epoch_completed=epoch_done,next_batch=next_batch,loss_total=loss_total,seen=seen,global_updates=global_updates,
          history=history,bad=bad,best_u=best_u,best_epoch=best_epoch,best_path=str(best_path),patience_reference=patience_ref,order_hash=order_hash))
    save_last()
    reason='max_additional_epochs'
    for epoch in range(epoch_done+1,p['max_additional_epochs']+1):
        if epoch_done>=p['min_additional_epochs'] and bad>=p['early_stop_patience']:reason='validation_early_stop';break
        protocol();tick=time.monotonic();aug.epoch=PARENT_EPOCH+epoch;m.train()
        gen=torch.Generator().manual_seed(SEED+1000003*(PARENT_EPOCH+epoch))
        order=torch.randperm(len(tr),generator=gen).tolist();new_hash=hashlib.sha256(np.array(order,dtype=np.int64).tobytes()).hexdigest()
        if next_batch:assert order_hash==new_hash,'Resume order mismatch'
        order_hash=new_hash;orderfile=ROOT/'orders'/f'epoch_{epoch:04d}.json'
        record=dict(epoch=epoch,absolute_epoch=PARENT_EPOCH+epoch,sha256=order_hash,case_ids=[tr.rows[i]['case_id'] for i in order])
        if orderfile.exists():assert read(orderfile)==record
        else:write_json(orderfile,record)
        loader=DataLoader(torch.utils.data.Subset(aug,order),batch_size=p['batch_size'],shuffle=False,num_workers=0)
        for bi,raw in enumerate(loader):
            if bi<next_batch:continue
            b=move(raw);out=m(b['measurements']);loss,_=objective(out,b,m.fov,False)
            if not torch.isfinite(loss):raise FloatingPointError('Nonfinite training loss')
            opt.zero_grad(set_to_none=True);loss.backward();torch.nn.utils.clip_grad_norm_(m.parameters(),1.,error_if_nonfinite=True);opt.step()
            loss_total+=float(loss.detach())*len(b['mask']);seen+=len(b['mask']);global_updates+=1;next_batch=bi+1
            if next_batch%p['checkpoint_every_batches']==0 or next_batch==len(loader):save_last()
            if next_batch%10==0 or next_batch==len(loader):status('training',epoch=epoch,processed=seen,total=3400,batch=next_batch,total_batches=len(loader),lr=opt.param_groups[0]['lr'],best_epoch=best_epoch,best_U=best_u,global_updates=global_updates)
        assert seen==3400
        val=evaluate(m,va,meta,epoch,p,'trained');u=val['utility'];ok=eligible(val,baseline,p);improved=ok and u>best_u
        if ok and u>patience_ref+p['early_stop_delta']:patience_ref=u;bad=0
        else:bad+=1
        sched.step(val['score'])
        if improved:
            best_u=u;best_epoch=epoch;best_path=checkpoint_dir/f'epoch_{epoch:04d}.pt'
            save_checkpoint(best_path,dict(model=m.state_dict(),protocol_sha256=ph,epoch=epoch,utility=u,validation=val['result_path']))
            copy_atomic(best_path,ROOT/'best.pt')
        history.append(dict(epoch=epoch,absolute_epoch=PARENT_EPOCH+epoch,train_cases=seen,training_loss=loss_total/seen,
            validation={k:v for k,v in val.items() if k!='records'},eligible=ok,selected_best=improved,best_epoch=best_epoch,
            patience_bad_epochs=bad,lr_next=opt.param_groups[0]['lr'],seconds=time.monotonic()-tick,order_sha256=order_hash,global_updates=global_updates))
        epoch_done=epoch;next_batch=0;seen=0;loss_total=0.;order_hash=None
        save_last();write_json(ROOT/'history.json',history)
        status('epoch_complete',epoch=epoch,best_epoch=best_epoch,best_U=best_u,validation=history[-1]['validation'],bad_epochs=bad)
    # Exact selected validation artifact belongs to the same saved model snapshot.
    chosen=torch.load(best_path,map_location='cpu',weights_only=True);selected=read(chosen['validation'])
    copy_atomic(best_path,ROOT/'best.pt');copy_atomic(selected['prediction_path'],ROOT/'selected_predictions.npz')
    write_json(ROOT/'selected_validation.json',selected);protocol()
    write_json(ROOT/'complete.json',dict(status='computed_pending_review',epochs=epoch_done,best_epoch=best_epoch,
        selected_U=best_u,selected_checkpoint=str(best_path),selected_checkpoint_sha256=file_hash(best_path),
        best_sha256=file_hash(ROOT/'best.pt'),last_sha256=file_hash(ROOT/'last.pt'),protocol_sha256=ph,
        stop_reason=reason,global_updates=global_updates,test_read=False,convergence_claim=False))
    status('computed_pending_review',epochs=epoch_done,best_epoch=best_epoch,best_U=best_u,stop_reason=reason)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--acceptance-only',action='store_true');args=parser.parse_args()
    with Lock():
        try:
            acceptance() if args.acceptance_only else run()
        except Exception:
            q=dict(time_unix=time.time(),traceback=traceback.format_exc());write_json(ROOT/f'error_{time.time_ns()}.json',q)
            status('failed',error=q['traceback']);raise
