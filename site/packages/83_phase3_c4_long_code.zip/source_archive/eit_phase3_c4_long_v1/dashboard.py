"""Read-only loopback dashboard, no write endpoints or arbitrary file serving."""
import json,time,ctypes
from ctypes import wintypes
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
ROOT=Path('E:/Codex/phase3_c4_long_v1');HERE=Path(__file__).parent
def read(p,default=None):
    try:return json.loads(p.read_text(encoding='utf-8'))
    except (OSError,ValueError):return default
def alive(pid):
    if not pid:return False
    k=ctypes.WinDLL('kernel32',use_last_error=True)
    k.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];k.OpenProcess.restype=wintypes.HANDLE
    k.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)];k.CloseHandle.argtypes=[wintypes.HANDLE]
    h=k.OpenProcess(0x1000,False,pid)
    if not h:return False
    code=wintypes.DWORD()
    try:return bool(k.GetExitCodeProcess(h,ctypes.byref(code))) and code.value==259
    finally:k.CloseHandle(h)
def snapshot():
    now=time.time();s=read(ROOT/'status.json',{});history=read(ROOT/'history.json',[])
    base=read(ROOT/'baseline.json');complete=read(ROOT/'complete.json');p=read(ROOT/'protocol.json',{})
    age=now-s.get('updated_unix',0);identity=read(ROOT/'worker_identity.json',{})
    running=s.get('phase') in ('loading_data','training','validation','epoch_complete')
    live=running and age<180 and s.get('pid')==identity.get('pid') and alive(s.get('pid'))
    eta=None
    if live and len(history)>=2:
        seconds=sum(h['seconds'] for h in history[-5:])/len(history[-5:])
        eta=seconds*max(0,p.get('max_additional_epochs',120)-len(history))
    best_epoch=complete.get('best_epoch') if complete else s.get('best_epoch',history[-1]['best_epoch'] if history else 0)
    best=base if best_epoch==0 else next((h['validation'] for h in history if h['epoch']==best_epoch),None)
    return dict(status=s,history=history,baseline=base and {k:v for k,v in base.items() if k!='records'},best=best,
       complete=complete,live=live,age_seconds=age,server_time=now,eta_to_cap_seconds=eta,
       max_epochs=p.get('max_additional_epochs',120),min_epochs=p.get('min_additional_epochs',20),
       elapsed_since_launch=now-read(ROOT/'launch.json',{}).get('started_unix',now),
       note='ETA只估算达到120轮上限的计算，不含审阅；早停会提前结束，失联时隐藏。')
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path in ('/','/index.html'):body=(HERE/'index.html').read_bytes();kind='text/html; charset=utf-8'
        elif self.path=='/api/status':body=json.dumps(snapshot(),ensure_ascii=False).encode();kind='application/json; charset=utf-8'
        elif self.path=='/favicon.ico':self.send_response(204);self.end_headers();return
        else:self.send_error(404);return
        self.send_response(200);self.send_header('Content-Type',kind);self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
    def log_message(self,*args):pass
if __name__=='__main__':
    print('http://127.0.0.1:8773',flush=True);ThreadingHTTPServer(('127.0.0.1',8773),Handler).serve_forever()
