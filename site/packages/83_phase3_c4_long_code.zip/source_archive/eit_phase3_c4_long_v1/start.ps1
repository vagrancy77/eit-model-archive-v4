$ErrorActionPreference='Stop'
$root='E:/Codex/phase3_c4_long_v1'
$existing=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^python(w)?\.exe$' -and $_.CommandLine -match 'eit_phase3_c4_long_v1[/\\]runner\.py' })
if ($existing.Count -gt 0) { throw "Worker already exists: $($existing.ProcessId -join ',')" }
if (Test-Path -LiteralPath "$root/complete.json") { throw 'Training already complete; do not extend it' }
if (-not (Test-Path -LiteralPath "$root/acceptance.json")) { throw 'Missing acceptance' }
& E:/conda-envs/pytorch-gpu/python.exe -B -c "import msvcrt; f=open(r'E:/Codex/phase3_c4_long_v1/worker.lock','r+b'); f.seek(0); msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1); msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1); f.close(); print('worker.lock FREE')"
if ($LASTEXITCODE -ne 0) { throw 'Worker lock busy' }
$stamp=Get-Date -Format 'yyyyMMdd_HHmmss_fff'
$p=Start-Process -FilePath 'E:/conda-envs/pytorch-gpu/python.exe' -ArgumentList @('-B','-u','E:/Codex/eit_phase3_c4_long_v1/runner.py') -WorkingDirectory 'E:/Codex' -WindowStyle Hidden -RedirectStandardOutput "$root/worker_$stamp.stdout.log" -RedirectStandardError "$root/worker_$stamp.stderr.log" -PassThru
Write-Output "Worker PID $($p.Id); logs $root/worker_$stamp.*.log"
$dash=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^python(w)?\.exe$' -and $_.CommandLine -match 'eit_phase3_c4_long_v1[/\\]dashboard\.py' })
if ($dash.Count -eq 0) {
  $d=Start-Process -FilePath 'E:/conda-envs/pytorch-gpu/python.exe' -ArgumentList @('-B','-u','E:/Codex/eit_phase3_c4_long_v1/dashboard.py') -WorkingDirectory 'E:/Codex' -WindowStyle Hidden -RedirectStandardOutput "$root/dashboard_$stamp.stdout.log" -RedirectStandardError "$root/dashboard_$stamp.stderr.log" -PassThru
  Write-Output "Dashboard PID $($d.Id): http://127.0.0.1:8773"
}
