"""Separate three-epoch feasibility run; original long-run code stays frozen."""
import argparse
import copy
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from datetime import datetime

PROJECT = Path('E:/Codex/eit_reproduction')
PARENT = Path('E:/Codex/complex_feedback_loop_v2')
ROOT = Path('E:/Codex/complex_feedback_quick_v2')
PYTHON = 'E:/conda-envs/pytorch-gpu/python.exe'
sys.path.insert(0, str(PROJECT))
import torch
import psutil
from comsol_feedback_loop import run
from comsol_feedback_loop.io import write_json, save_checkpoint, check_sources
from comsol_v4.data_v6 import file_hash


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def quick_protocol():
    p = copy.deepcopy(read(PARENT/'protocol.json'))
    check_sources(p['source_hashes'])
    if file_hash(Path(p['baseline_checkpoint'])) != p['baseline_sha256']:
        raise RuntimeError('Baseline checkpoint changed')
    p.update(version='diagram-closed-loop-v2-quick3', minimum_epochs=3, max_epochs=3,
             scope='Feasibility only: total 3 full-cohort epochs including inherited epoch 1; one seed; no convergence claim',
             parent_root=str(PARENT), parent_protocol_sha256=file_hash(PARENT/'protocol.json'),
             control_source_sha256=file_hash(Path(__file__)),
             handoff_policy='inherit full epoch-1 state; preserve original long-run checkpoints unchanged')
    return p


def lock_file(path):
    import msvcrt
    f = path.open('a+b')
    f.seek(0)
    try:
        msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
    except OSError:
        f.close()
        raise RuntimeError(f'Active owner of {path}; refusing duplicate')
    return f


def prepare():
    ROOT.mkdir(parents=True, exist_ok=True)
    p = quick_protocol()
    target = ROOT/'protocol.json'
    if target.exists() and read(target) != p:
        raise RuntimeError('Quick protocol already exists with different contents')
    if not target.exists():
        write_json(target, p)
    for rel in ['qa/architecture_acceptance.json', 'qa/fem/physics_acceptance.json',
                'dataset_integrity.json']:
        src, dst = PARENT/rel, ROOT/rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.exists() and file_hash(dst) != file_hash(src):
            raise RuntimeError(f'Conflicting acceptance record: {rel}')
        if not dst.exists():
            shutil.copy2(src, dst)
    for rel in ['qa/architecture_acceptance.json', 'qa/fem/physics_acceptance.json']:
        if read(ROOT/rel)['status'] != 'PASS':
            raise RuntimeError('Acceptance not passed')
    return p


def checked_process():
    proc = psutil.Process(8000)
    expected_time = datetime.fromisoformat('2026-10-21T09:55:08.681302+08:00').timestamp()
    args = proc.cmdline()
    if (abs(proc.create_time()-expected_time) > 1 or
            'comsol_feedback_loop.run' not in args or
            not any(a.replace('\\', '/').lower() == PARENT.as_posix().lower() for a in args) or
            Path(proc.exe()).resolve() != Path(PYTHON).resolve()):
        raise RuntimeError('Original worker PID identity does not match; no termination attempted')
    return proc


def adopt_checkpoint():
    # Only called after the original process has exited and its OS lock is acquired.
    phash, qhash = file_hash(PARENT/'protocol.json'), file_hash(ROOT/'protocol.json')
    last = torch.load(PARENT/'last.pt', map_location='cpu', weights_only=True)
    best = torch.load(PARENT/'best.pt', map_location='cpu', weights_only=True)
    if last['epoch'] != 1 or len(last['history']) != 1:
        raise RuntimeError('Expected exactly one complete inherited epoch')
    if best['epoch'] != last['best_epoch']:
        raise RuntimeError('Best checkpoint and resumable state disagree')
    lineage = {'parent_root': str(PARENT), 'parent_protocol_sha256': phash,
               'quick_protocol_sha256': qhash, 'inherited_epoch': 1,
               'preserved_state': ['model', 'optimizer', 'scheduler', 'early_stop',
                                   'history', 'rng_cpu', 'rng_cuda', 'normalizer'],
               'checkpoints': {}, 'created_unix': time.time()}
    for name, ck in [('last.pt', last), ('best.pt', best)]:
        if ck['protocol_sha256'] != phash:
            raise RuntimeError('Parent checkpoint provenance mismatch')
        original_hash = file_hash(PARENT/name)
        ck['protocol_sha256'] = qhash
        save_checkpoint(ROOT/name, ck)
        lineage['checkpoints'][name] = {'parent_sha256': original_hash,
                                       'quick_sha256': file_hash(ROOT/name), 'epoch': ck['epoch']}
    write_json(ROOT/'history.json', last['history'])
    write_json(ROOT/'lineage.json', lineage)
    write_json(PARENT/'paused_for_quick.json', {
        'reason': 'User requested separate short feasibility experiment; do not auto-resume long run',
        'resume_epoch': 1, 'quick_root': str(ROOT), 'protocol_sha256': phash,
        'last_sha256': lineage['checkpoints']['last.pt']['parent_sha256'],
        'best_sha256': lineage['checkpoints']['best.pt']['parent_sha256'],
        'updated_unix': time.time()})
    write_json(PARENT/'status.json', {'phase': 'paused', 'epoch': 1,
               'reason': 'Saved full epoch-1 resume state; separate quick experiment active',
               'quick_root': str(ROOT), 'updated_unix': time.time()})
    write_json(ROOT/'status.json', {'phase': 'starting', 'epoch': 1, 'max_epochs': 3,
               'minimum_epochs': 3, 'K': 3, 'updated_unix': time.time()})


def handoff():
    prepare()
    guard = lock_file(ROOT/'handoff.lock')
    try:
        if not (ROOT/'lineage.json').exists():
            print('Waiting for complete epoch 1 (train 3400 + val 720). No mid-epoch discard.', flush=True)
            while True:
                proc = checked_process()
                h = read(PARENT/'history.json') if (PARENT/'history.json').exists() else []
                if h:
                    if h[-1]['epoch'] != 1:
                        raise RuntimeError('Missed epoch-1 handoff; requires explicit review')
                    ck = torch.load(PARENT/'last.pt', map_location='cpu', weights_only=True)
                    if ck['epoch'] != 1 or len(ck['history']) != 1:
                        raise RuntimeError('History/checkpoint not synchronized')
                    del ck
                    proc = checked_process()  # recheck immediately before termination
                    print('Durable epoch-1 checkpoint confirmed; stopping only original owned worker.', flush=True)
                    proc.terminate()
                    proc.wait(timeout=45)
                    break
                s = read(PARENT/'status.json')
                s.update(phase='waiting_for_checkpoint', parent_phase=s.get('phase'),
                         max_epochs=3, minimum_epochs=3, parent_root=str(PARENT),
                         parent_updated_unix=s.get('updated_unix'), updated_unix=time.time())
                write_json(ROOT/'status.json', s)
                time.sleep(10)
            old_lock = lock_file(PARENT/'worker.lock')
            try:
                adopt_checkpoint()
            finally:
                old_lock.close()
        print('Handoff recorded; starting separate three-epoch experiment.', flush=True)
        launch_quick()
    finally:
        guard.close()


def launch_quick():
    # The original run.main owns a second OS lock for actual training.
    stamp = time.strftime('%Y%m%d_%H%M%S')
    out = ROOT/'worker_stdout.log'
    err = ROOT/'worker_stderr.log'
    if out.exists():
        out, err = ROOT/f'worker_resume_{stamp}_stdout.log', ROOT/f'worker_resume_{stamp}_stderr.log'
    with out.open('wb') as stdout, err.open('wb') as stderr:
        p = subprocess.Popen([PYTHON, '-u', str(Path(__file__).resolve()), '--mode', 'run'],
            cwd=PROJECT, stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
        write_json(ROOT/'worker_process.json', {'pid': p.pid, 'stdout': str(out), 'stderr': str(err),
                                              'started_unix': time.time()})
        code = p.wait()
    if code:
        raise RuntimeError(f'Quick worker exited with code {code}; see {err}')


def execute():
    p = prepare()
    lineage = read(ROOT/'lineage.json')
    if lineage['quick_protocol_sha256'] != file_hash(ROOT/'protocol.json'):
        raise RuntimeError('Quick lineage protocol mismatch')
    # Intentional experiment-specific schedule override; architecture and loss unchanged.
    run.protocol = lambda: p
    sys.argv = [str(Path(__file__)), '--root', str(ROOT)]
    run.main()


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--mode', choices=['prepare', 'handoff', 'run'], required=True)
    a = ap.parse_args()
    try:
        if a.mode == 'prepare':
            prepare()
            print('Separate quick protocol and acceptance records prepared; no training launched.')
        elif a.mode == 'handoff':
            handoff()
        else:
            execute()
    except Exception as exc:
        if ROOT.exists():
            write_json(ROOT/'control_error.json', {'mode': a.mode, 'error': repr(exc), 'time': time.time()})
        raise
