"""CPU-only handoff tests; no real processes stopped or training started."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch, Mock
import torch
import quick_loop as q


class HandoffTests(unittest.TestCase):
    def test_windows_process_identity(self):
        p = Mock()
        p.create_time.return_value = q.datetime.fromisoformat('2026-10-21T09:55:08.681302+08:00').timestamp()
        p.cmdline.return_value = [q.PYTHON, '-u', '-m', 'comsol_feedback_loop.run',
                                 '--root', 'E:/Codex/complex_feedback_loop_v2']
        p.exe.return_value = q.PYTHON
        with patch.object(q.psutil, 'Process', return_value=p):
            self.assertIs(q.checked_process(), p)
            p.cmdline.return_value[-1] = 'E:/Codex/another_experiment'
            with self.assertRaises(RuntimeError):
                q.checked_process()

    def test_schedule_only_and_source_integrity(self):
        parent = q.read(q.PARENT/'protocol.json')
        quick = q.quick_protocol()
        differences = {k for k in parent if parent[k] != quick[k]}
        self.assertEqual(differences, {'version', 'minimum_epochs', 'max_epochs', 'scope'})
        self.assertEqual(quick['K'], 3)
        self.assertFalse(quick['first_stage_frozen'])
        self.assertTrue(quick['end_to_end_physics_loss'])

    def test_duplicate_lock_refused(self):
        with tempfile.TemporaryDirectory(dir='E:/Codex/eit_experiment_control') as d:
            f = q.lock_file(Path(d)/'lock')
            try:
                with self.assertRaises(RuntimeError):
                    q.lock_file(Path(d)/'lock')
            finally:
                f.close()

    def test_state_preservation(self):
        with tempfile.TemporaryDirectory(dir='E:/Codex/eit_experiment_control') as d:
            parent, root = Path(d)/'parent', Path(d)/'quick'
            parent.mkdir(); root.mkdir()
            q.write_json(parent/'protocol.json', {'max_epochs': 250})
            q.write_json(root/'protocol.json', {'max_epochs': 3})
            state = {'protocol_sha256': q.file_hash(parent/'protocol.json'), 'epoch': 1,
                     'history': [{'epoch': 1}], 'best_epoch': 1, 'best_score': .25,
                     'model': {'weight': torch.tensor([1., 2.])},
                     'optimizer': {'state': {0: {'step': torch.tensor(850)}}},
                     'scheduler': {'last_epoch': 1}, 'rng_cpu': torch.tensor([3], dtype=torch.uint8)}
            for n in ['last.pt', 'best.pt']:
                torch.save(state, parent/n)
            hashes = {n: q.file_hash(parent/n) for n in ['last.pt', 'best.pt']}
            with patch.object(q, 'PARENT', parent), patch.object(q, 'ROOT', root):
                q.adopt_checkpoint()
            copied = torch.load(root/'last.pt', weights_only=True)
            self.assertEqual(copied['protocol_sha256'], q.file_hash(root/'protocol.json'))
            self.assertTrue(torch.equal(copied['model']['weight'], state['model']['weight']))
            self.assertEqual(copied['optimizer'], state['optimizer'])
            self.assertEqual(copied['scheduler'], state['scheduler'])
            self.assertEqual(copied['history'], state['history'])
            self.assertTrue(torch.equal(copied['rng_cpu'], state['rng_cpu']))
            for n, sha in hashes.items():
                self.assertEqual(q.file_hash(parent/n), sha)
            self.assertEqual(q.read(parent/'status.json')['phase'], 'paused')
            self.assertEqual(q.read(root/'lineage.json')['inherited_epoch'], 1)


if __name__ == '__main__':
    unittest.main()
