# 实例级几何—频散分解：第一轮可证伪实验

## 问题

旧的 `factorized` 模型共享一张病灶几何图，但为每个频率预测一张完整的空间对比度图。它改善了定位，却使病灶内部电导率强度 MAE 变差。本实验检验一种更强的表述能否解决该问题：最多三个共享病灶实例掩膜，且每个病灶单独预测一条随频率平滑、单调下降的响应曲线。

> 注意：Edinburgh mfEIT 公开文件只给出 `f1`--`f4`，没有公开实际 kHz。因此这里的频率坐标仅是 1--4 的有序坐标，平滑/单调约束是机制验证，不是可发表的 Cole--Cole 物理频散验证。

## 公平设置

- 数据：Edinburgh mfEIT Dataset，固定的分层 2048 / 512 / 512 train / validation / test phantom。
- 随机种子：20260729。
- 训练：40 epoch，batch size 64，latent dimension 64，base channels 8。
- 基线：普通四频联合模型 `joint` 和旧共享几何模型 `factorized`。
- 新模型：`instance_dispersion`，每例最多三张互斥的病灶实例掩膜加三条频率响应曲线。

## 结果

相对 `factorized`，新模型的整体结构指标更好：MAE -9.08%，RMSE -7.05%，SSIM +3.98%，Dice +3.83%，IoU +6.49%，背景假阳性 -18.36%。

但是关键的病灶强度定量没有改善：像素级 `lesion_contrast_mae` 从 0.14154 恶化至 0.15684（+10.81%）。在相同 512 个 phantom 的 1123 个真实病灶中，直接从真实病灶区域提取的四频曲线 MAE 也更差：

| 方法 | 真实病灶区域频谱 MAE ↓ |
|---|---:|
| joint | 0.16637 |
| factorized | 0.18408 |
| instance_dispersion | 0.20247 |

## 结论

该第一版实例级频散模型**没有通过**“结构与频谱定量同时改善”的预注册式标准。不能将其作为当前论文的主方法，也不能据此声称病灶级频散建模改善了定量多频 EIT。

它保留下来的事实是：更强的共享结构先验仍可稳定减少背景伪影和提升空间重建；但以离散、未知物理频率的 f1--f4 数据直接施加单调平滑曲线，会降低强度定量。若继续这个方向，下一项实验必须使用具有真实频率和已知介电参数的 CEM/Cole--Cole 仿真数据；否则建议转向新的研究问题。

## 可复核输出

- 训练检查点与整体指标：`outputs_edinburgh_instance_dispersion_pilot_20260729/` 和 `outputs_edinburgh_instance_dispersion_softmax_20260729/`
- 逐病灶频谱 CSV 与汇总：`outputs_edinburgh_instance_dispersion_spectrum_eval_20260729/`
- 三病灶重建图和曲线图：`outputs_edinburgh_instance_dispersion_figures_20260729/`
