# 公开神经网络 EIT 代码与数据调研

## 最终选择：GN4IP Conv U-Net

- 代码仓库：<https://github.com/wherzberg/GN4IP>
- 论文：<https://arxiv.org/abs/2305.05020>
- 本地固定提交：`0f744d41e87616b08bbaab9f7a8a48ef201d8c62`
- 许可证：GPL-3.0

选择原因：

1. 仓库直接包含训练数据、测试数据和预训练权重；
2. 同时包含 Conv U-Net、Graph U-Net 和迭代图网络；
3. 包含生成 EIT 数据的 EIDORS/MATLAB 源码；
4. 模型规模小，可以在 CPU 上运行，不属于大模型；
5. 公开预测结果可用于严格检查复现是否一致。

### 公开数据字段

`training_data_v0.mat`：

- 300 个训练样本；
- 256 个边界电压值 `VSIM`；
- 4204 单元重建网格；
- `X0`：均匀初始化；
- `X1`：第一次 LM 更新；
- `X2`：3 次 LM 后的网络输入；
- `Y`：真实电导率；
- `closest_elements`/`closest_pixels`：网格与 32×32 图像的最近邻映射。

`test_data_v0.mat` 包含同格式的 10 个测试样本。生成脚本设置包括：

- 16 电极；
- 半径 0.14 m；
- 电极宽度 0.02 m；
- 3 mA 激励；
- 1% 高斯噪声；
- 正问题和重建使用不同网格；
- 3 次 LM 迭代后交给 U-Net。

### 本工程所做的兼容修改

原 `GN4IP.py` 无条件导入 `torch_geometric`，即使只使用 Conv U-Net。本工程将该依赖改为可选，因此卷积模型只需 PyTorch。

原预测脚本使用测试集自身的输入均值和标准差。本工程同时输出：

- `legacy`：完全匹配作者预测脚本，便于严格复现；
- `train_stat`：使用训练阶段保存的输入统计量，避免依赖整个测试批次。

作者兼容模式与仓库保存的 `yhat`：

- 相对 L2 误差：`6.25 × 10^-16`；
- 最大绝对误差：`1.58 × 10^-15`。

这证明当前环境中的模型结构、权重、数据映射和数值输出均已复现。

公开测试集平均相关系数：

```text
3-step LM X2        0.5130
GN4IP legacy U-Net  0.9139
train-stat U-Net    0.8896
```

## 接入当前 CEM 数据

`adapt_cem_to_gn4ip.py` 将当前 1024 例数据转换为：

```text
X0 = 1
X1 = 线性 CEM 电导率更新
X2 = 1 + X1
Y  = 逆网格真实电导率
```

同时生成 GN4IP 所需的 32×32 最近邻映射。公开 Conv U-Net 在当前数据上训练 20 个 CPU epoch 后：

```text
平均相关系数   0.6756 -> 0.7985
平均相对 L2    0.1293 -> 0.1020
```

## 运行方法

在 WSL 中：

```bash
conda env create -f /mnt/e/Codex/eit_reproduction/environment-gn4ip.yml
conda activate gn4ip-env
cd /mnt/e/Codex/eit_reproduction

python reproduce_gn4ip.py
python train_gn4ip_short.py --epochs 3
python adapt_cem_to_gn4ip.py
python train_gn4ip_on_cem.py --epochs 20
python scripts/validate_gn4ip_reproduction.py
```

或执行：

```bash
bash scripts/run_gn4ip_pipeline.sh
```

## 其他核对过的公开项目

| 项目 | 代码 | 数据/权重 | 结论 |
|---|---|---|---|
| GN4IP | <https://github.com/wherzberg/GN4IP> | 训练集、测试集、多个权重 | 当前首选，已复现 |
| EIT reconstruction | <https://github.com/LarsG21/EIT_reconstruction> | 真实水槽数据、模型 | 适合第二阶段真实数据，但未检测到明确许可证且工程路径较杂 |
| EIT Transformer | <https://github.com/scaomath/eit-transformer> | 无公开训练数据/权重 | 代码完整，不能开箱复现论文结果 |
| ptEIT | <https://github.com/haijing-zhang/ptEIT> | 部分3D权重 | 三维点云任务，超出当前二维路线 |
| DeepDbar | <https://github.com/asHauptmann/DeepDbar> | 缺网络权重 | 不作为第一复现路线 |
| BeltramiNet | <https://github.com/asHauptmann/BeltramiNet> | 不公开训练数据 | 不作为第一复现路线 |

## 可用于后续真实数据验证的公开数据

- UEF 2D EIT：<https://fips.fi/open-datasets/eit-datasets/2d-electrical-impedance-tomography-dataset/>
- KTC2023：<https://zenodo.org/records/8252370>
- KIT4：<https://zenodo.org/records/1203914>

这些真实数据的几何、电极协议、标定和标签与当前模拟数据不同，需要单独的数据解析和域适配，不能直接套用当前权重。
