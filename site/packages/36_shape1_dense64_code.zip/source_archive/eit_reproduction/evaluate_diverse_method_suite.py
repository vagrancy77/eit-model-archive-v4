from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader

PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

from pytorch_eit.data import MultimodalCEMDataset
from pytorch_eit.models import MultiModalEITNet, RegistrationRobustMultiModalEITNet
from train_registration_robust_multimodal import add_false_blob


CONDITIONS = [
    "clean",
    "shift10px",
    "rotate10deg",
    "scale85pct",
    "warp_local",
    "missing",
    "blur_sigma4",
    "false_positive",
]
STRESS_AXES = {
    "shift_px": [0, 5, 10, 15, 20],
    "rotation_deg": [0, 5, 10, 15, 20],
    "scale_factor": [1.0, 0.95, 0.90, 0.85, 0.80],
    "warp_strength": [0.0, 0.03, 0.06, 0.09, 0.12],
}
METHODS = ["eit_only", "baseline", "hard_constraint", "soft_constraint", "robust"]


def identity_grid(image: torch.Tensor) -> torch.Tensor:
    batch, _, height, width = image.shape
    yy, xx = torch.meshgrid(
        torch.linspace(-1.0, 1.0, height, device=image.device, dtype=image.dtype),
        torch.linspace(-1.0, 1.0, width, device=image.device, dtype=image.dtype),
        indexing="ij",
    )
    grid = torch.stack([xx, yy], dim=-1)
    return grid.unsqueeze(0).expand(batch, -1, -1, -1)


def affine_corrupt(image: torch.Tensor, tx: float = 0.0, ty: float = 0.0, angle: float = 0.0, scale: float = 1.0) -> torch.Tensor:
    batch = image.shape[0]
    theta = image.new_zeros((batch, 2, 3))
    theta[:, 0, 0] = scale * np.cos(angle)
    theta[:, 0, 1] = -scale * np.sin(angle)
    theta[:, 1, 0] = scale * np.sin(angle)
    theta[:, 1, 1] = scale * np.cos(angle)
    theta[:, 0, 2] = tx
    theta[:, 1, 2] = ty
    grid = F.affine_grid(theta, image.shape, align_corners=False)
    return F.grid_sample(image, grid, mode="bilinear", padding_mode="zeros", align_corners=False)


def elastic_warp(image: torch.Tensor, strength: float, seed: int) -> torch.Tensor:
    if strength <= 0.0:
        return image
    generator = torch.Generator(device=image.device)
    generator.manual_seed(int(seed))
    batch, _, height, width = image.shape
    control = torch.randn((batch, 2, 9, 9), generator=generator, device=image.device, dtype=image.dtype)
    control = F.avg_pool2d(control, kernel_size=3, stride=1, padding=1)
    displacement = F.interpolate(control, size=(height, width), mode="bicubic", align_corners=False)
    displacement = F.avg_pool2d(displacement, kernel_size=7, stride=1, padding=3)
    grid = identity_grid(image) + strength * displacement.permute(0, 2, 3, 1)
    return F.grid_sample(image, grid, mode="bilinear", padding_mode="zeros", align_corners=False)


def normalize_prior(image: torch.Tensor) -> torch.Tensor:
    minimum = image.amin(dim=(-2, -1), keepdim=True)
    maximum = image.amax(dim=(-2, -1), keepdim=True)
    return (image - minimum) / (maximum - minimum).clamp_min(1e-6)


def derive_soft_hard_prior(image: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    if float(image.abs().sum()) == 0.0:
        zeros = torch.zeros_like(image)
        return zeros, zeros
    soft = normalize_prior(image)
    soft = F.avg_pool2d(soft, kernel_size=5, stride=1, padding=2)
    soft = soft.clamp(0.0, 1.0)
    hard = (soft >= 0.5).to(image.dtype)
    hard = F.max_pool2d(hard, kernel_size=3, stride=1, padding=1)
    return soft, hard


def corrupt_ultrasound(image: torch.Tensor, condition: str, seed: int) -> tuple[torch.Tensor, torch.Tensor]:
    if condition == "missing":
        zeros = torch.zeros_like(image)
        return zeros, torch.zeros((image.shape[0], 1), device=image.device, dtype=image.dtype)
    if condition == "clean":
        return image, torch.ones((image.shape[0], 1), device=image.device, dtype=image.dtype)
    if condition == "shift10px":
        return affine_corrupt(image, tx=0.22), torch.ones((image.shape[0], 1), device=image.device, dtype=image.dtype)
    if condition == "rotate10deg":
        return affine_corrupt(image, angle=np.deg2rad(10.0)), torch.ones((image.shape[0], 1), device=image.device, dtype=image.dtype)
    if condition == "scale85pct":
        return affine_corrupt(image, scale=0.85), torch.ones((image.shape[0], 1), device=image.device, dtype=image.dtype)
    if condition == "warp_local":
        return elastic_warp(image, strength=0.08, seed=seed), torch.ones((image.shape[0], 1), device=image.device, dtype=image.dtype)
    if condition == "blur_sigma4":
        return F.avg_pool2d(image, kernel_size=7, stride=1, padding=3), torch.ones((image.shape[0], 1), device=image.device, dtype=image.dtype)
    if condition == "false_positive":
        return add_false_blob(image), torch.ones((image.shape[0], 1), device=image.device, dtype=image.dtype)
    raise ValueError(f"unknown condition {condition}")


def apply_stress(image: torch.Tensor, axis: str, severity: float, seed: int) -> torch.Tensor:
    if axis == "shift_px":
        return affine_corrupt(image, tx=0.22 * float(severity) / 10.0)
    if axis == "rotation_deg":
        return affine_corrupt(image, angle=np.deg2rad(float(severity)))
    if axis == "scale_factor":
        return affine_corrupt(image, scale=float(severity))
    if axis == "warp_strength":
        return elastic_warp(image, strength=float(severity), seed=seed)
    raise ValueError(f"unknown stress axis {axis}")


def build_models(args, device: torch.device, voltage_dim: int, baseline_state: dict[str, object], robust_states: list[dict[str, object]]):
    baseline = MultiModalEITNet(voltage_dim=voltage_dim, base_channels=int(baseline_state["base_channels"])).to(device)
    baseline.load_state_dict(baseline_state["model_state"], strict=False)
    baseline.eval()
    robust_models = []
    for state in robust_states:
        model = RegistrationRobustMultiModalEITNet(voltage_dim=voltage_dim, base_channels=int(state["base_channels"])).to(device)
        model.load_state_dict(state["model_state"], strict=False)
        model.eval()
        robust_models.append(model)
    return baseline, robust_models


def masked_metrics(prediction: torch.Tensor, target: torch.Tensor, mask: torch.Tensor) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    prediction = prediction[:, 0] * mask
    target = target[:, 0] * mask
    p = prediction.flatten(1) - prediction.flatten(1).mean(1, keepdim=True)
    t = target.flatten(1) - target.flatten(1).mean(1, keepdim=True)
    corr = (p * t).sum(1) / (
        torch.linalg.vector_norm(p, dim=1) * torch.linalg.vector_norm(t, dim=1)
    ).clamp_min(1e-6)
    rel_l2 = torch.linalg.vector_norm((prediction - target).flatten(1), dim=1) / torch.linalg.vector_norm(
        target.flatten(1), dim=1
    ).clamp_min(1e-6)
    mae = torch.abs(prediction - target).sum(dim=(1, 2)) / mask.sum().clamp_min(1.0)
    return corr.cpu().numpy(), rel_l2.cpu().numpy(), mae.cpu().numpy()


def evaluate_batch_predictions(prediction: torch.Tensor, target: torch.Tensor, mask: torch.Tensor) -> dict[str, np.ndarray]:
    corr, rel_l2, mae = masked_metrics(prediction, target, mask)
    return {"correlation": corr, "relative_l2": rel_l2, "mae": mae}


def evaluate_suite(args, loader, device, mask, baseline, robust_models) -> tuple[list[dict[str, object]], dict[str, object], dict[str, object], list[dict[str, object]]]:
    raw_rows: list[dict[str, object]] = []
    stress_rows: list[dict[str, object]] = []
    example_cache: dict[str, dict[str, torch.Tensor]] = {}
    confidence_records: list[dict[str, object]] = []

    with torch.no_grad():
        sample_offset = 0
        for batch_index, batch in enumerate(loader):
            batch = {key: value.to(device=device, dtype=torch.float32) for key, value in batch.items()}
            batch_size = int(batch["target"].shape[0])
            for condition in CONDITIONS:
                condition_seed = args.seed + batch_index * 101 + CONDITIONS.index(condition)
                ultrasound, availability = corrupt_ultrasound(batch["ultrasound"], condition, condition_seed)
                baseline_output = baseline(batch["eit_image"], batch["voltages"], ultrasound, availability)
                eit_only_output = baseline(batch["eit_image"], batch["voltages"], torch.zeros_like(ultrasound), torch.zeros_like(availability))

                soft_prior, hard_prior = derive_soft_hard_prior(ultrasound)
                baseline_pred = baseline_output["reconstruction"]
                hard_pred = baseline_pred if condition == "missing" else hard_prior * baseline_pred + (1.0 - hard_prior) * 1.0
                soft_pred = baseline_pred if condition == "missing" else soft_prior * baseline_pred + (1.0 - soft_prior) * 1.0

                methods_predictions = {
                    "eit_only": eit_only_output["reconstruction"],
                    "baseline": baseline_pred,
                    "hard_constraint": hard_pred,
                    "soft_constraint": soft_pred,
                }
                robust_outputs = []
                for seed_index, robust_model in enumerate(robust_models, start=1):
                    robust_output = robust_model(batch["eit_image"], batch["voltages"], ultrasound, availability)
                    robust_outputs.append(robust_output)
                    corr, rel_l2, mae = masked_metrics(robust_output["reconstruction"], batch["target"], mask)
                    confidence = (robust_output["confidence_map"][:, 0] * mask).flatten(1).sum(1) / mask.sum().clamp_min(1.0)
                    for local_index in range(batch_size):
                        raw_rows.append(
                            {
                                "sample_index": sample_offset + local_index,
                                "condition": condition,
                                "method": "robust",
                                "seed": seed_index,
                                "correlation": float(corr[local_index]),
                                "relative_l2": float(rel_l2[local_index]),
                                "mae": float(mae[local_index]),
                                "confidence": float(confidence[local_index]),
                            }
                        )
                if condition not in example_cache:
                    example_cache[condition] = {
                        "target": batch["target"][0].detach().cpu(),
                        "eit_image": batch["eit_image"][0].detach().cpu(),
                        "ultrasound": ultrasound[0].detach().cpu(),
                        "availability": availability[0].detach().cpu(),
                        "baseline": baseline_pred[0].detach().cpu(),
                        "hard_constraint": hard_pred[0].detach().cpu(),
                        "soft_constraint": soft_pred[0].detach().cpu(),
                        "eit_only": eit_only_output["reconstruction"][0].detach().cpu(),
                        "robust": robust_outputs[0]["reconstruction"][0].detach().cpu(),
                        "confidence": robust_outputs[0]["confidence_map"][0].detach().cpu(),
                    }

                # Store deterministic method rows.
                for method, pred in methods_predictions.items():
                    corr, rel_l2, mae = masked_metrics(pred, batch["target"], mask)
                    for local_index in range(batch_size):
                        raw_rows.append(
                            {
                                "sample_index": sample_offset + local_index,
                                "condition": condition,
                                "method": method,
                                "seed": 0,
                                "correlation": float(corr[local_index]),
                                "relative_l2": float(rel_l2[local_index]),
                                "mae": float(mae[local_index]),
                                "confidence": None,
                            }
                        )

            sample_offset += batch_size

    # Stress curves are measured on the first robust model and the baseline.
    stress_metrics: dict[str, list[dict[str, object]]] = {axis: [] for axis in STRESS_AXES}
    with torch.no_grad():
        for axis, severities in STRESS_AXES.items():
            for severity in severities:
                corrs = {"eit_only": [], "baseline": [], "hard_constraint": [], "soft_constraint": [], "robust": []}
                rels = {key: [] for key in corrs}
                maes = {key: [] for key in corrs}
                for batch_index, batch in enumerate(loader):
                    batch = {key: value.to(device=device, dtype=torch.float32) for key, value in batch.items()}
                    condition_seed = args.seed + 999 + batch_index * 37 + int(severity * 100)
                    ultrasound = apply_stress(batch["ultrasound"], axis, severity, condition_seed)
                    availability = torch.ones((batch["eit_image"].shape[0], 1), device=device, dtype=batch["eit_image"].dtype)
                    if axis == "warp_strength" and float(severity) == 0.0:
                        ultrasound = batch["ultrasound"]
                    if axis == "scale_factor" and float(severity) == 1.0:
                        ultrasound = batch["ultrasound"]
                    baseline_output = baseline(batch["eit_image"], batch["voltages"], ultrasound, availability)["reconstruction"]
                    eit_only_output = baseline(batch["eit_image"], batch["voltages"], torch.zeros_like(ultrasound), torch.zeros_like(availability))["reconstruction"]
                    soft_prior, hard_prior = derive_soft_hard_prior(ultrasound)
                    hard_pred = hard_prior * baseline_output + (1.0 - hard_prior) * 1.0
                    soft_pred = soft_prior * baseline_output + (1.0 - soft_prior) * 1.0
                    robust_output = robust_models[0](batch["eit_image"], batch["voltages"], ultrasound, availability)["reconstruction"]
                    preds = {
                        "eit_only": eit_only_output,
                        "baseline": baseline_output,
                        "hard_constraint": hard_pred,
                        "soft_constraint": soft_pred,
                        "robust": robust_output,
                    }
                    for method, pred in preds.items():
                        corr, rel_l2, mae = masked_metrics(pred, batch["target"], mask)
                        corrs[method].extend(corr.tolist())
                        rels[method].extend(rel_l2.tolist())
                        maes[method].extend(mae.tolist())
                stress_metrics[axis].append(
                    {
                        "severity": float(severity),
                        "methods": {
                            method: {
                                "correlation": float(np.mean(corrs[method])),
                                "relative_l2": float(np.mean(rels[method])),
                                "mae": float(np.mean(maes[method])),
                            }
                            for method in METHODS
                        },
                    }
                )
    return raw_rows, stress_metrics, example_cache, confidence_records


def bootstrap_ci(values: np.ndarray, rng: np.random.Generator, n_bootstrap: int = 2000) -> dict[str, float]:
    values = np.asarray(values, dtype=float)
    if values.size == 0:
        return {"mean": float("nan"), "ci95_low": float("nan"), "ci95_high": float("nan")}
    draws = rng.choice(values, size=(n_bootstrap, values.size), replace=True).mean(axis=1)
    return {
        "mean": float(values.mean()),
        "ci95_low": float(np.quantile(draws, 0.025)),
        "ci95_high": float(np.quantile(draws, 0.975)),
    }


def paired_bootstrap(delta: np.ndarray, rng: np.random.Generator, n_bootstrap: int = 2000) -> dict[str, float]:
    delta = np.asarray(delta, dtype=float)
    draws = rng.choice(delta, size=(n_bootstrap, delta.size), replace=True).mean(axis=1)
    return {
        "mean": float(delta.mean()),
        "ci95_low": float(np.quantile(draws, 0.025)),
        "ci95_high": float(np.quantile(draws, 0.975)),
    }


def pearson(x: np.ndarray, y: np.ndarray) -> float:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    if x.size < 2 or np.std(x) < 1e-12 or np.std(y) < 1e-12:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def auc_score(labels: np.ndarray, scores: np.ndarray) -> float:
    labels = np.asarray(labels, dtype=np.int64)
    scores = np.asarray(scores, dtype=float)
    positive = labels == 1
    negative = labels == 0
    n_pos = int(positive.sum())
    n_neg = int(negative.sum())
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    order = np.argsort(scores)
    ranks = np.empty_like(order, dtype=float)
    sorted_scores = scores[order]
    i = 0
    while i < len(scores):
        j = i + 1
        while j < len(scores) and sorted_scores[j] == sorted_scores[i]:
            j += 1
        average_rank = (i + 1 + j) / 2.0
        ranks[order[i:j]] = average_rank
        i = j
    rank_sum_pos = float(ranks[positive].sum())
    return (rank_sum_pos - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg)


def confidence_analysis(robust_rows: list[dict[str, object]]) -> dict[str, object]:
    confidence = np.asarray([float(row["confidence"]) for row in robust_rows], dtype=float)
    mae = np.asarray([float(row["mae"]) for row in robust_rows], dtype=float)
    rel_l2 = np.asarray([float(row["relative_l2"]) for row in robust_rows], dtype=float)
    corrupted = np.asarray([0 if str(row["condition"]) == "clean" else 1 for row in robust_rows], dtype=np.int64)
    order = np.argsort(-confidence)
    sorted_mae = mae[order]
    coverages = np.linspace(0.05, 1.0, 20)
    selective = []
    for coverage in coverages:
        keep = max(1, int(math.ceil(coverage * len(sorted_mae))))
        selective.append(float(np.mean(sorted_mae[:keep])))
    low = np.percentile(mae, 5)
    high = np.percentile(mae, 95)
    quality = 1.0 - np.clip((mae - low) / max(high - low, 1e-8), 0.0, 1.0)
    edges = np.linspace(0.0, 1.0, 11)
    ece = 0.0
    for left, right in zip(edges[:-1], edges[1:], strict=True):
        in_bin = (confidence >= left) & (confidence < right if right < 1.0 else confidence <= right)
        if not np.any(in_bin):
            continue
        ece += float(in_bin.mean()) * abs(float(confidence[in_bin].mean()) - float(quality[in_bin].mean()))
    return {
        "confidence_corruption_auc": auc_score(1 - corrupted, confidence),
        "confidence_vs_mae_pearson": pearson(confidence, mae),
        "confidence_vs_relative_l2_pearson": pearson(confidence, rel_l2),
        "mae_ece_like": float(ece),
        "selective_mae": {
            "coverage": [float(x) for x in coverages],
            "mae": [float(x) for x in selective],
            "mae_at_25pct": float(selective[np.argmin(np.abs(coverages - 0.25))]),
            "mae_at_50pct": float(selective[np.argmin(np.abs(coverages - 0.50))]),
            "mae_at_75pct": float(selective[np.argmin(np.abs(coverages - 0.75))]),
            "mae_at_100pct": float(selective[-1]),
        },
    }


def aggregate_rows(raw_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    # Average robust seed rows per sample/condition and keep deterministic methods as-is.
    grouped: dict[tuple[int, str, str], list[dict[str, object]]] = {}
    for row in raw_rows:
        key = (int(row["sample_index"]), str(row["condition"]), str(row["method"]))
        grouped.setdefault(key, []).append(row)
    aggregated: list[dict[str, object]] = []
    for (sample_index, condition, method), rows in grouped.items():
        if method == "robust":
            aggregated.append(
                {
                    "sample_index": sample_index,
                    "condition": condition,
                    "method": method,
                    "seed": 0,
                    "correlation": float(np.mean([float(row["correlation"]) for row in rows])),
                    "relative_l2": float(np.mean([float(row["relative_l2"]) for row in rows])),
                    "mae": float(np.mean([float(row["mae"]) for row in rows])),
                    "confidence": float(np.mean([float(row["confidence"]) for row in rows if row["confidence"] is not None])),
                }
            )
        elif int(rows[0]["seed"]) == 0:
            row = rows[0]
            aggregated.append(row)
    return aggregated


def summarize(aggregated_rows: list[dict[str, object]], seed_rows: list[dict[str, object]]) -> dict[str, object]:
    conditions = CONDITIONS
    methods = METHODS
    summary: dict[str, object] = {"conditions": conditions, "methods": methods, "metrics": {}}
    for method in methods:
        summary["metrics"][method] = {}
        for condition in conditions:
            subset = [row for row in aggregated_rows if row["method"] == method and row["condition"] == condition]
            if not subset:
                continue
            summary["metrics"][method][condition] = {
                "correlation": bootstrap_ci(np.asarray([row["correlation"] for row in subset], dtype=float), np.random.default_rng(20260803)),
                "relative_l2": bootstrap_ci(np.asarray([row["relative_l2"] for row in subset], dtype=float), np.random.default_rng(20260804)),
                "mae": bootstrap_ci(np.asarray([row["mae"] for row in subset], dtype=float), np.random.default_rng(20260805)),
                "confidence": bootstrap_ci(
                    np.asarray([row["confidence"] for row in subset if row["confidence"] is not None], dtype=float),
                    np.random.default_rng(20260806),
                )
                if any(row["confidence"] is not None for row in subset)
                else None,
            }
    summary["seed_metrics"] = {}
    for seed in sorted({int(row["seed"]) for row in seed_rows if int(row["seed"]) > 0}):
        summary["seed_metrics"][f"seed_{seed}"] = {}
        for condition in conditions:
            subset = [row for row in seed_rows if row["seed"] == seed and row["method"] == "robust" and row["condition"] == condition]
            summary["seed_metrics"][f"seed_{seed}"][condition] = {
                "correlation": float(np.mean([row["correlation"] for row in subset])),
                "relative_l2": float(np.mean([row["relative_l2"] for row in subset])),
                "mae": float(np.mean([row["mae"] for row in subset])),
                "confidence": float(np.mean([row["confidence"] for row in subset])),
            }
    summary["confidence_analysis"] = confidence_analysis([row for row in aggregated_rows if row["method"] == "robust"])
    # robust vs other methods paired bootstrap on the aggregated per-sample rows.
    robust_rows = {(row["sample_index"], row["condition"]): row for row in aggregated_rows if row["method"] == "robust"}
    summary["paired_bootstrap"] = {}
    for method in ("baseline", "eit_only", "hard_constraint", "soft_constraint"):
        summary["paired_bootstrap"][method] = {}
        for condition in conditions:
            method_rows = {(row["sample_index"], row["condition"]): row for row in aggregated_rows if row["method"] == method and row["condition"] == condition}
            common_keys = sorted(set(robust_rows).intersection(method_rows))
            if not common_keys:
                continue
            robust_corr = np.asarray([robust_rows[key]["correlation"] for key in common_keys], dtype=float)
            other_corr = np.asarray([method_rows[key]["correlation"] for key in common_keys], dtype=float)
            robust_l2 = np.asarray([robust_rows[key]["relative_l2"] for key in common_keys], dtype=float)
            other_l2 = np.asarray([method_rows[key]["relative_l2"] for key in common_keys], dtype=float)
            robust_mae = np.asarray([robust_rows[key]["mae"] for key in common_keys], dtype=float)
            other_mae = np.asarray([method_rows[key]["mae"] for key in common_keys], dtype=float)
            summary["paired_bootstrap"][method][condition] = {
                "correlation_improvement": paired_bootstrap(robust_corr - other_corr, np.random.default_rng(20260807)),
                "relative_l2_improvement": paired_bootstrap(other_l2 - robust_l2, np.random.default_rng(20260808)),
                "mae_improvement": paired_bootstrap(other_mae - robust_mae, np.random.default_rng(20260809)),
            }
    return summary


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    fieldnames = ["sample_index", "condition", "method", "seed", "correlation", "relative_l2", "mae", "confidence"]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def plot_comparison(output_dir: Path, summary: dict[str, object]) -> None:
    methods = METHODS
    conditions = CONDITIONS
    colors = {
        "eit_only": "0.55",
        "baseline": "tab:blue",
        "hard_constraint": "tab:purple",
        "soft_constraint": "tab:green",
        "robust": "tab:orange",
    }
    figure, axes = plt.subplots(1, 3, figsize=(16, 4.7), constrained_layout=True)
    x = np.arange(len(conditions))
    for axis, metric_name, ylabel in zip(axes, ("correlation", "relative_l2", "mae"), ("Correlation", "Relative L2", "MAE"), strict=True):
        for method in methods:
            means = [summary["metrics"][method][condition][metric_name]["mean"] for condition in conditions]
            ci_low = [summary["metrics"][method][condition][metric_name]["ci95_low"] for condition in conditions]
            ci_high = [summary["metrics"][method][condition][metric_name]["ci95_high"] for condition in conditions]
            axis.plot(x, means, marker="o", label=method, color=colors[method])
            axis.fill_between(x, ci_low, ci_high, color=colors[method], alpha=0.08)
        axis.set_xticks(x, conditions, rotation=25, ha="right")
        axis.set_ylabel(ylabel)
        axis.grid(alpha=0.25)
    axes[0].legend(ncol=2, fontsize=8)
    figure.savefig(output_dir / "comparison.png", dpi=180)
    plt.close(figure)


def plot_stress(output_dir: Path, stress_metrics: dict[str, list[dict[str, object]]]) -> None:
    methods = METHODS
    colors = {
        "eit_only": "0.55",
        "baseline": "tab:blue",
        "hard_constraint": "tab:purple",
        "soft_constraint": "tab:green",
        "robust": "tab:orange",
    }
    figure, axes = plt.subplots(2, 2, figsize=(14, 9), constrained_layout=True)
    axes = axes.reshape(-1)
    for axis, (stress_name, rows) in zip(axes, stress_metrics.items(), strict=True):
        x = [row["severity"] for row in rows]
        for method in methods:
            axis.plot(x, [row["methods"][method]["relative_l2"] for row in rows], marker="o", label=method, color=colors[method])
        axis.set_xlabel(stress_name.replace("_", " "))
        axis.set_ylabel("Relative L2")
        axis.grid(alpha=0.25)
    axes[0].legend(ncol=2, fontsize=8)
    figure.savefig(output_dir / "stress_curves.png", dpi=180)
    plt.close(figure)


def plot_confidence(output_dir: Path, aggregated_rows: list[dict[str, object]], summary: dict[str, object]) -> None:
    robust_rows = [row for row in aggregated_rows if row["method"] == "robust"]
    confidence = np.asarray([float(row["confidence"]) for row in robust_rows], dtype=float)
    mae = np.asarray([float(row["mae"]) for row in robust_rows], dtype=float)
    rel_l2 = np.asarray([float(row["relative_l2"]) for row in robust_rows], dtype=float)
    conditions = np.asarray([str(row["condition"]) for row in robust_rows], dtype=object)
    condition_order = CONDITIONS
    figure, axes = plt.subplots(1, 3, figsize=(15, 4.5), constrained_layout=True)
    values = [confidence[conditions == condition] for condition in condition_order]
    axes[0].boxplot(values, tick_labels=condition_order, showfliers=False)
    axes[0].tick_params(axis="x", rotation=25)
    axes[0].set_title("Confidence by condition")
    axes[0].set_ylabel("Mean confidence")

    axes[1].scatter(confidence, mae, s=6, alpha=0.28)
    axes[1].set_title("Confidence vs MAE")
    axes[1].set_xlabel("Mean confidence")
    axes[1].set_ylabel("MAE")

    order = np.argsort(-confidence)
    sorted_mae = mae[order]
    coverages = np.linspace(0.05, 1.0, 20)
    risk = [float(np.mean(sorted_mae[: max(1, int(math.ceil(c * len(sorted_mae))))])) for c in coverages]
    axes[2].plot(coverages, risk, marker="o")
    axes[2].set_title("Risk-coverage")
    axes[2].set_xlabel("Coverage")
    axes[2].set_ylabel("Selective MAE")
    axes[2].grid(alpha=0.25)
    figure.savefig(output_dir / "confidence_reliability.png", dpi=180)
    plt.close(figure)

    figure, ax = plt.subplots(figsize=(8.5, 4.8), constrained_layout=True)
    positions = np.arange(len(condition_order))
    mean_mae = [float(np.mean(mae[conditions == condition])) for condition in condition_order]
    mean_conf = [float(np.mean(confidence[conditions == condition])) for condition in condition_order]
    ax.bar(positions - 0.18, mean_mae, width=0.36, color="tab:orange", label="MAE")
    ax2 = ax.twinx()
    ax2.bar(positions + 0.18, mean_conf, width=0.36, color="tab:blue", alpha=0.75, label="confidence")
    ax.set_xticks(positions, condition_order, rotation=25, ha="right")
    ax.set_ylabel("MAE")
    ax2.set_ylabel("Mean confidence")
    ax.legend(loc="upper left")
    ax2.legend(loc="upper right")
    ax.set_title("Condition-level confidence and error")
    figure.savefig(output_dir / "condition_confidence_error.png", dpi=180)
    plt.close(figure)


def plot_examples(output_dir: Path, example_cache: dict[str, dict[str, torch.Tensor]]) -> None:
    rows_to_show = ["clean", "scale85pct", "warp_local", "missing"]
    cols = ["target", "eit_only", "baseline", "hard_constraint", "soft_constraint", "robust", "confidence"]
    figure, axes = plt.subplots(len(rows_to_show), len(cols), figsize=(18, 3.2 * len(rows_to_show)), squeeze=False, constrained_layout=True)
    for row_index, condition in enumerate(rows_to_show):
        item = example_cache[condition]
        panels = [
            item["target"][0].numpy(),
            item["eit_only"][0].numpy(),
            item["baseline"][0].numpy(),
            item["hard_constraint"][0].numpy(),
            item["soft_constraint"][0].numpy(),
            item["robust"][0].numpy(),
            item["confidence"][0].numpy(),
        ]
        for col_index, (panel, title) in enumerate(zip(panels, cols, strict=True)):
            cmap = "magma" if title == "confidence" else "gray" if title in {"baseline"} else "viridis"
            axes[row_index, col_index].imshow(panel, cmap=cmap, vmin=0.0, vmax=1.0 if title == "confidence" else 2.95)
            axes[row_index, col_index].set_title(f"{condition} / {title}", fontsize=9)
            axes[row_index, col_index].axis("off")
    figure.savefig(output_dir / "examples.png", dpi=180)
    plt.close(figure)


def main() -> None:
    parser = argparse.ArgumentParser(description="Unified method-suite evaluation on the diverse independent CEM dataset.")
    parser.add_argument("--data", type=Path, default=PROJECT_ROOT / "datasets" / "multimodal_cem_v3.npz")
    parser.add_argument("--baseline-checkpoint", type=Path, default=PROJECT_ROOT / "outputs_pytorch_multimodal" / "model.pt")
    parser.add_argument(
        "--robust-checkpoint",
        action="append",
        type=Path,
        default=[
            PROJECT_ROOT / "outputs_registration_robust_multimodal_warm_seed1" / "model.pt",
            PROJECT_ROOT / "outputs_registration_robust_multimodal_warm_seed2" / "model.pt",
            PROJECT_ROOT / "outputs_registration_robust_multimodal_warm_seed3" / "model.pt",
        ],
    )
    parser.add_argument("--output-dir", type=Path, default=PROJECT_ROOT / "outputs_diverse_method_suite")
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--seed", type=int, default=20260803)
    parser.add_argument("--cpu", action="store_true")
    args = parser.parse_args()

    device = torch.device("cpu" if args.cpu or not torch.cuda.is_available() else "cuda")
    data = np.load(args.data)
    train_voltage = np.asarray(data["voltage_features"], dtype=np.float32)[data["train_indices"]]
    voltage_mean = train_voltage.mean(0)
    voltage_std = np.maximum(train_voltage.std(0), np.median(train_voltage.std(0)) * 1e-3 + 1e-6)

    dataset = MultimodalCEMDataset(args.data, "test", modality_dropout=0.0)
    dataset.voltages = (dataset.voltages - voltage_mean) / voltage_std
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=0)

    baseline_state = torch.load(args.baseline_checkpoint, map_location=device, weights_only=False)
    robust_states = [torch.load(path, map_location=device, weights_only=False) for path in args.robust_checkpoint]
    baseline, robust_models = build_models(args, device, dataset.voltages.shape[1], baseline_state, robust_states)
    mask = torch.from_numpy(np.asarray(data["mask"], dtype=np.float32)).to(device)

    raw_rows, stress_metrics, example_cache, _ = evaluate_suite(args, loader, device, mask, baseline, robust_models)
    aggregated_rows = aggregate_rows(raw_rows)
    summary = summarize(aggregated_rows, raw_rows)
    summary.update(
        {
            "stress_metrics": stress_metrics,
            "data": str(args.data.resolve()),
            "baseline_checkpoint": str(args.baseline_checkpoint.resolve()),
            "robust_checkpoints": [str(path.resolve()) for path in args.robust_checkpoint],
            "device": str(device),
            "samples": int(len(dataset)),
            "interpretation_warning": "The hard/soft constraint baselines are post-processed priors derived from the ultrasound proxy, not extra trained networks.",
        }
    )

    args.output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(args.output_dir / "per_sample_metrics_by_seed.csv", raw_rows)
    write_csv(args.output_dir / "per_sample_metrics.csv", aggregated_rows)
    (args.output_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    plot_comparison(args.output_dir, summary)
    plot_stress(args.output_dir, stress_metrics)
    plot_confidence(args.output_dir, aggregated_rows, summary)
    plot_examples(args.output_dir, example_cache)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
