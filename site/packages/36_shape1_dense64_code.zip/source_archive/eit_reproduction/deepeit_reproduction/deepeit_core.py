from __future__ import annotations

import copy
import csv
import math
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.tri as mtri
import numpy as np
import torch
from scipy.ndimage import uniform_filter, zoom
from scipy.optimize import minimize_scalar
from scipy.spatial import cKDTree
from torch import nn
from torch.nn import functional as F


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def safe_correlation(first: np.ndarray, second: np.ndarray) -> float:
    first = np.asarray(first, dtype=float).reshape(-1)
    second = np.asarray(second, dtype=float).reshape(-1)
    if np.std(first) <= 0.0 or np.std(second) <= 0.0:
        return float("nan")
    return float(np.corrcoef(first, second)[0, 1])


def minmax(values: np.ndarray, mask: np.ndarray | None = None) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    subset = values[np.asarray(mask, dtype=bool)] if mask is not None else values
    low = float(np.min(subset))
    high = float(np.max(subset))
    if not np.isfinite(low) or not np.isfinite(high) or high <= low:
        return np.zeros_like(values, dtype=float)
    return (values - low) / (high - low)


def windowed_ssim(
    prediction: np.ndarray,
    target: np.ndarray,
    mask: np.ndarray | None = None,
    window_size: int = 7,
) -> float:
    prediction = np.asarray(prediction, dtype=float)
    target = np.asarray(target, dtype=float)
    if prediction.ndim != 2 or target.ndim != 2:
        pred = prediction.reshape(-1)
        truth = target.reshape(-1)
        c1 = 0.01**2
        c2 = 0.03**2
        mu_pred = float(np.mean(pred))
        mu_truth = float(np.mean(truth))
        var_pred = float(np.var(pred))
        var_truth = float(np.var(truth))
        covariance = float(np.mean((pred - mu_pred) * (truth - mu_truth)))
        return float(
            (2.0 * mu_pred * mu_truth + c1)
            * (2.0 * covariance + c2)
            / ((mu_pred**2 + mu_truth**2 + c1) * (var_pred + var_truth + c2))
        )

    c1 = 0.01**2
    c2 = 0.03**2
    mu_pred = uniform_filter(prediction, size=window_size, mode="nearest")
    mu_truth = uniform_filter(target, size=window_size, mode="nearest")
    mu_pred_sq = mu_pred * mu_pred
    mu_truth_sq = mu_truth * mu_truth
    mu_cross = mu_pred * mu_truth
    sigma_pred_sq = uniform_filter(prediction * prediction, size=window_size, mode="nearest") - mu_pred_sq
    sigma_truth_sq = uniform_filter(target * target, size=window_size, mode="nearest") - mu_truth_sq
    sigma_cross = uniform_filter(prediction * target, size=window_size, mode="nearest") - mu_cross
    ssim_map = (
        (2.0 * mu_cross + c1)
        * (2.0 * sigma_cross + c2)
        / ((mu_pred_sq + mu_truth_sq + c1) * (sigma_pred_sq + sigma_truth_sq + c2))
    )
    if mask is not None:
        return float(np.mean(ssim_map[np.asarray(mask, dtype=bool)]))
    return float(np.mean(ssim_map))


def global_ssim(prediction: np.ndarray, target: np.ndarray) -> float:
    pred = np.asarray(prediction, dtype=float).reshape(-1)
    truth = np.asarray(target, dtype=float).reshape(-1)
    c1 = 0.01**2
    c2 = 0.03**2
    mu_pred = float(np.mean(pred))
    mu_truth = float(np.mean(truth))
    var_pred = float(np.var(pred))
    var_truth = float(np.var(truth))
    covariance = float(np.mean((pred - mu_pred) * (truth - mu_truth)))
    return float(
        (2.0 * mu_pred * mu_truth + c1)
        * (2.0 * covariance + c2)
        / ((mu_pred**2 + mu_truth**2 + c1) * (var_pred + var_truth + c2))
    )


def image_metrics(
    prediction: np.ndarray,
    target: np.ndarray,
    mask: np.ndarray | None = None,
) -> dict[str, float]:
    """Metrics used in the paper, computed after min-max normalization."""

    pred_image = minmax(np.asarray(prediction, dtype=float), mask)
    truth_image = minmax(np.asarray(target, dtype=float), mask)
    if mask is not None:
        mask_bool = np.asarray(mask, dtype=bool)
        pred = pred_image[mask_bool].reshape(-1)
        truth = truth_image[mask_bool].reshape(-1)
    else:
        pred = pred_image.reshape(-1)
        truth = truth_image.reshape(-1)
    mse = float(np.mean((pred - truth) ** 2))
    psnr = float("inf") if mse <= 0.0 else float(20.0 * math.log10(1.0 / math.sqrt(mse)))
    relative_error = float(
        np.linalg.norm(pred - truth) / max(np.linalg.norm(truth), np.finfo(float).eps)
    )
    cc = safe_correlation(pred, truth)
    ssim = global_ssim(pred, truth)
    metrics = {"ssim": float(ssim), "cc": cc, "psnr": psnr, "re": relative_error}
    if pred_image.ndim == 2 and truth_image.ndim == 2:
        metrics["ssim_windowed"] = windowed_ssim(pred_image, truth_image, mask)
    return metrics


def element_centers(nodes: np.ndarray, elements: np.ndarray) -> np.ndarray:
    triangles = np.asarray(elements, dtype=np.int64)[:, :3]
    return np.asarray(nodes, dtype=float)[triangles, :2].mean(axis=1)


def make_element_sampling_grid(
    nodes: np.ndarray,
    elements: np.ndarray,
    device: torch.device,
) -> torch.Tensor:
    centers = element_centers(nodes, elements)
    grid = torch.as_tensor(centers, dtype=torch.float32, device=device)
    return grid.view(1, -1, 1, 2)


def sample_image_on_elements(image: torch.Tensor, grid: torch.Tensor) -> torch.Tensor:
    sampled = F.grid_sample(
        image,
        grid,
        mode="bilinear",
        padding_mode="border",
        align_corners=True,
    )
    return sampled.view(-1)


def elements_to_grid(
    nodes: np.ndarray,
    elements: np.ndarray,
    values: np.ndarray,
    image_size: int = 128,
) -> tuple[np.ndarray, np.ndarray]:
    centers = element_centers(nodes, elements)
    axis = np.linspace(-1.0, 1.0, image_size)
    xx, yy = np.meshgrid(axis, axis)
    points = np.column_stack([xx.reshape(-1), yy.reshape(-1)])
    tree = cKDTree(centers)
    _, indices = tree.query(points, k=1)
    image = np.asarray(values, dtype=float)[indices].reshape(image_size, image_size)
    mask = (xx**2 + yy**2) <= 1.0
    return image, mask


def isotropic_tv(image: torch.Tensor, epsilon: float = 1e-10) -> torch.Tensor:
    dx = image[..., :, 1:] - image[..., :, :-1]
    dy = image[..., 1:, :] - image[..., :-1, :]
    dx = dx[..., :-1, :]
    dy = dy[..., :, :-1]
    return torch.sqrt(dx.square() + dy.square() + epsilon).mean()


class ConvBNLeaky(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, stride: int = 1) -> None:
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(
                in_channels,
                out_channels,
                kernel_size=3,
                stride=stride,
                padding=1,
                bias=False,
            ),
            nn.BatchNorm2d(out_channels),
            nn.LeakyReLU(0.2, inplace=True),
        )

    def forward(self, tensor: torch.Tensor) -> torch.Tensor:
        return self.block(tensor)


class DeepEITUNet(nn.Module):
    """U-Net-like DIP generator matching the architecture described in Fig. 2."""

    def __init__(
        self,
        skip_channels: Sequence[int] = (0, 0, 0, 4, 4),
        output_scale: float = 2.0,
    ) -> None:
        super().__init__()
        if len(skip_channels) != 5:
            raise ValueError("skip_channels must contain five integers")
        self.skip_channels = tuple(int(value) for value in skip_channels)
        self.output_scale = float(output_scale)
        channels = [8, 16, 32, 64, 128]

        self.down = nn.ModuleList()
        in_channels = 1
        for level, out_channels in enumerate(channels):
            stride = 1 if level == 0 else 2
            self.down.append(
                nn.Sequential(
                    ConvBNLeaky(in_channels, out_channels, stride=stride),
                    ConvBNLeaky(out_channels, out_channels),
                )
            )
            in_channels = out_channels

        self.skip = nn.ModuleList(
            [
                nn.Conv2d(channels[level], self.skip_channels[level], kernel_size=1)
                if self.skip_channels[level] > 0
                else nn.Identity()
                for level in range(5)
            ]
        )

        bottleneck_in = channels[-1] + self.skip_channels[-1]
        self.bottleneck = nn.Sequential(
            ConvBNLeaky(bottleneck_in, channels[-1]),
            ConvBNLeaky(channels[-1], channels[-1]),
        )

        decoder_specs = [
            (channels[-1] + self.skip_channels[3], 64),
            (64 + self.skip_channels[2], 32),
            (32 + self.skip_channels[1], 16),
            (16 + self.skip_channels[0], 8),
        ]
        self.up = nn.ModuleList(
            [
                nn.Sequential(
                    ConvBNLeaky(in_channels, out_channels),
                    ConvBNLeaky(out_channels, out_channels),
                )
                for in_channels, out_channels in decoder_specs
            ]
        )
        self.output = nn.Conv2d(8, 1, kernel_size=1)

    def forward(self, noise: torch.Tensor) -> torch.Tensor:
        features: list[torch.Tensor] = []
        tensor = noise
        for block in self.down:
            tensor = block(tensor)
            features.append(tensor)

        if self.skip_channels[-1] > 0:
            tensor = torch.cat([tensor, self.skip[-1](features[-1])], dim=1)
        tensor = self.bottleneck(tensor)

        for decoder_index, level in enumerate((3, 2, 1, 0)):
            tensor = F.interpolate(
                tensor,
                size=features[level].shape[-2:],
                mode="bilinear",
                align_corners=False,
            )
            if self.skip_channels[level] > 0:
                tensor = torch.cat([tensor, self.skip[level](features[level])], dim=1)
            tensor = self.up[decoder_index](tensor)

        return torch.sigmoid(self.output(tensor)) * self.output_scale


@dataclass(frozen=True)
class DeepEITConfig:
    iterations: int = 5000
    image_size: int = 128
    learning_rate: float = 1e-3
    skip_channels: tuple[int, int, int, int, int] = (0, 0, 0, 4, 4)
    eta: float = 2.0
    tv_weight: float = 0.0
    tv_epsilon: float = 1e-10
    lsp_threshold: float | None = 0.01
    lsp_lr_backoff: float = 0.9
    data_scale: float | None = None
    seed: int = 20260801
    device: str = "cpu"
    gradient_clip: float = 1.0
    log_every: int = 50


@dataclass(frozen=True)
class DeepEITIteration:
    iteration: int
    loss: float
    data_loss: float
    tv_loss: float
    relative_voltage_error: float
    sigma_min: float
    sigma_max: float
    learning_rate: float
    rejected_by_lsp: bool


@dataclass(frozen=True)
class DeepEITResult:
    conductivity: np.ndarray
    image: np.ndarray
    noise_input: np.ndarray
    predicted_voltage: np.ndarray
    sigma_homogeneous: float
    history: tuple[DeepEITIteration, ...]
    config: DeepEITConfig


def estimate_homogeneous_conductivity(
    forward_solver,
    measured_voltage: np.ndarray,
    lower: float = 0.05,
    upper: float = 3.0,
) -> float:
    measured = np.asarray(measured_voltage, dtype=float).reshape(-1)

    def objective(log_sigma: float) -> float:
        sigma = math.exp(float(log_sigma))
        predicted = np.asarray(forward_solver.solve_protocol(sigma).measurements)
        residual = predicted - measured
        return float(residual @ residual)

    result = minimize_scalar(
        objective,
        bounds=(math.log(lower), math.log(upper)),
        method="bounded",
        options={"xatol": 1e-4},
    )
    return float(math.exp(result.x))


def run_deepeit(
    forward_solver,
    measured_voltage: np.ndarray,
    nodes: np.ndarray,
    elements: np.ndarray,
    config: DeepEITConfig,
    sigma_homogeneous: float | None = None,
) -> DeepEITResult:
    seed_everything(config.seed)
    device = torch.device(config.device)
    measured = np.asarray(measured_voltage, dtype=float).reshape(-1)
    if sigma_homogeneous is None:
        sigma_homogeneous = estimate_homogeneous_conductivity(
            forward_solver,
            measured,
        )
    data_scale = (
        float(config.data_scale)
        if config.data_scale is not None
        else float(np.linalg.norm(measured) / math.sqrt(measured.size))
    )
    if not np.isfinite(data_scale) or data_scale <= 0.0:
        raise ValueError("data_scale must be positive and finite")

    output_scale = float(config.eta * sigma_homogeneous)
    model = DeepEITUNet(
        skip_channels=config.skip_channels,
        output_scale=output_scale,
    ).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=config.learning_rate)
    element_grid = make_element_sampling_grid(nodes, elements, device)
    noise = torch.empty(
        (1, 1, config.image_size, config.image_size),
        dtype=torch.float32,
        device=device,
    ).uniform_(0.0, 0.1)

    previous_loss = float("inf")
    history: list[DeepEITIteration] = []

    for iteration in range(1, config.iterations + 1):
        state_before_step = copy.deepcopy(model.state_dict())
        optimizer_before_step = copy.deepcopy(optimizer.state_dict())
        optimizer.zero_grad(set_to_none=True)
        image = model(noise)
        conductivity = sample_image_on_elements(image, element_grid)
        conductivity_np = conductivity.detach().cpu().numpy().astype(float)
        predicted = np.asarray(
            forward_solver.solve_protocol(conductivity_np).measurements,
            dtype=float,
        )
        residual = predicted - measured
        scaled_residual = residual / data_scale
        data_loss = 0.5 * float(scaled_residual @ scaled_residual)
        tv_tensor = config.tv_weight * isotropic_tv(image, config.tv_epsilon)
        tv_loss = float(tv_tensor.detach().cpu())
        total_loss = data_loss + tv_loss

        jacobian = np.asarray(
            forward_solver.compute_jacobian(conductivity_np),
            dtype=float,
        )
        grad_sigma = jacobian.T @ residual / (data_scale**2)
        grad_tensor = torch.as_tensor(
            grad_sigma,
            dtype=conductivity.dtype,
            device=device,
        )
        if config.tv_weight > 0.0:
            torch.autograd.backward(
                [conductivity, tv_tensor],
                [grad_tensor, torch.ones_like(tv_tensor)],
            )
        else:
            conductivity.backward(grad_tensor)
        if config.gradient_clip > 0.0:
            nn.utils.clip_grad_norm_(model.parameters(), config.gradient_clip)
        optimizer.step()

        rejected = False
        record_loss = total_loss
        record_data_loss = data_loss
        record_tv_loss = tv_loss
        record_residual = residual
        record_conductivity = conductivity_np

        if config.lsp_threshold is not None:
            with torch.no_grad():
                trial_image = model(noise)
                trial_conductivity = sample_image_on_elements(
                    trial_image,
                    element_grid,
                )
                trial_conductivity_np = (
                    trial_conductivity.detach().cpu().numpy().astype(float)
                )
                trial_predicted = np.asarray(
                    forward_solver.solve_protocol(
                        trial_conductivity_np,
                    ).measurements,
                    dtype=float,
                )
                trial_residual = trial_predicted - measured
                trial_scaled = trial_residual / data_scale
                trial_data_loss = 0.5 * float(trial_scaled @ trial_scaled)
                trial_tv_loss = float(
                    (config.tv_weight * isotropic_tv(trial_image, config.tv_epsilon))
                    .detach()
                    .cpu()
                )
                trial_loss = trial_data_loss + trial_tv_loss

            if (
                np.isfinite(previous_loss)
                and (trial_loss - previous_loss)
                / max(trial_loss, np.finfo(float).eps)
                > config.lsp_threshold
            ):
                model.load_state_dict(state_before_step)
                optimizer.load_state_dict(optimizer_before_step)
                for group in optimizer.param_groups:
                    group["lr"] *= config.lsp_lr_backoff
                rejected = True
            else:
                previous_loss = trial_loss
                record_loss = trial_loss
                record_data_loss = trial_data_loss
                record_tv_loss = trial_tv_loss
                record_residual = trial_residual
                record_conductivity = trial_conductivity_np
        else:
            previous_loss = total_loss

        learning_rate = float(optimizer.param_groups[0]["lr"])
        relative_voltage_error = float(
            np.linalg.norm(record_residual)
            / max(np.linalg.norm(measured), np.finfo(float).eps)
        )
        history.append(
            DeepEITIteration(
                iteration=iteration,
                loss=float(record_loss),
                data_loss=float(record_data_loss),
                tv_loss=float(record_tv_loss),
                relative_voltage_error=relative_voltage_error,
                sigma_min=float(np.min(record_conductivity)),
                sigma_max=float(np.max(record_conductivity)),
                learning_rate=learning_rate,
                rejected_by_lsp=rejected,
            )
        )
        if config.log_every > 0 and (
            iteration == 1
            or iteration == config.iterations
            or iteration % config.log_every == 0
        ):
            print(
                f"iter={iteration:05d} loss={record_loss:.6e} "
                f"rel_v={relative_voltage_error:.4e} "
                f"sigma=[{np.min(record_conductivity):.3f},"
                f"{np.max(record_conductivity):.3f}] "
                f"lr={learning_rate:.2e} rejected={int(rejected)}",
                flush=True,
            )

    with torch.no_grad():
        final_image = model(noise)
        final_conductivity = sample_image_on_elements(final_image, element_grid)
        final_conductivity_np = final_conductivity.detach().cpu().numpy().astype(float)
        final_image_np = final_image.detach().cpu().numpy()[0, 0].astype(float)
    final_prediction = np.asarray(
        forward_solver.solve_protocol(final_conductivity_np).measurements,
        dtype=float,
    )
    return DeepEITResult(
        conductivity=final_conductivity_np,
        image=final_image_np,
        noise_input=noise.detach().cpu().numpy()[0, 0].astype(float),
        predicted_voltage=final_prediction,
        sigma_homogeneous=float(sigma_homogeneous),
        history=tuple(history),
        config=config,
    )


def write_history_csv(history: Sequence[DeepEITIteration], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    columns = [
        "iteration",
        "loss",
        "data_loss",
        "tv_loss",
        "relative_voltage_error",
        "sigma_min",
        "sigma_max",
        "learning_rate",
        "rejected_by_lsp",
    ]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(columns)
        for record in history:
            writer.writerow([getattr(record, column) for column in columns])


def plot_deepeit_case1(
    nodes: np.ndarray,
    elements: np.ndarray,
    truth: np.ndarray,
    noise: np.ndarray,
    output_image: np.ndarray,
    reconstructions: dict[str, np.ndarray],
    metrics: dict[str, dict[str, float]],
    output_path: Path,
) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    triangulation = mtri.Triangulation(nodes[:, 0], nodes[:, 1], elements[:, :3])
    fields = [
        ("Ground truth", truth),
        ("Initial input", noise),
        ("Output image", output_image),
        ("DeepEIT", reconstructions["DeepEIT"]),
        ("NOSER", reconstructions["NOSER"]),
        ("L2", reconstructions["L2"]),
        ("TV", reconstructions["TV"]),
    ]
    figure, axes = plt.subplots(2, 4, figsize=(14, 7), constrained_layout=True)
    for axis, (title, field) in zip(axes.flat, fields, strict=False):
        if field.ndim == 2:
            image = axis.imshow(field, cmap="turbo", origin="lower", vmin=0.0, vmax=1.0)
        else:
            image = axis.tripcolor(
                triangulation,
                facecolors=minmax(field),
                shading="flat",
                cmap="turbo",
                vmin=0.0,
                vmax=1.0,
            )
        if title in metrics:
            metric = metrics[title]
            title = (
                f"{title}\nSSIM={metric['ssim']:.2f}, CC={metric['cc']:.2f}\n"
                f"PSNR={metric['psnr']:.1f}, RE={metric['re']:.3f}"
            )
        axis.set_title(title, fontsize=10)
        axis.set_aspect("equal")
        axis.set_axis_off()
        figure.colorbar(image, ax=axis, fraction=0.046, pad=0.04)
    for axis in axes.flat[len(fields) :]:
        axis.set_axis_off()
    figure.suptitle("DeepEIT Case 1 reproduction: heart-lung phantom")
    figure.savefig(output_path, dpi=180)
    plt.close(figure)


def plot_history(history: Sequence[DeepEITIteration], output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    iterations = np.array([record.iteration for record in history], dtype=int)
    losses = np.array([record.loss for record in history], dtype=float)
    voltage = np.array([record.relative_voltage_error for record in history], dtype=float)
    rejected = np.array([record.rejected_by_lsp for record in history], dtype=bool)
    figure, axes = plt.subplots(1, 2, figsize=(11, 4), constrained_layout=True)
    axes[0].semilogy(iterations, losses, linewidth=1.0)
    if np.any(rejected):
        axes[0].scatter(iterations[rejected], losses[rejected], s=12, c="crimson")
    axes[0].set_title("DeepEIT objective")
    axes[0].set_xlabel("Iteration")
    axes[0].set_ylabel("Loss")
    axes[0].grid(alpha=0.25)
    axes[1].semilogy(iterations, voltage, linewidth=1.0)
    axes[1].set_title("Relative voltage error")
    axes[1].set_xlabel("Iteration")
    axes[1].grid(alpha=0.25)
    figure.savefig(output_path, dpi=180)
    plt.close(figure)


def plot_high_resolution_mapping(
    nodes: np.ndarray,
    elements: np.ndarray,
    conductivity: np.ndarray,
    output_image: np.ndarray,
    output_path: Path,
) -> None:
    """Reproduce the Fig. 5 idea: map the DIP output to finer image supports."""

    output_path.parent.mkdir(parents=True, exist_ok=True)
    triangulation = mtri.Triangulation(nodes[:, 0], nodes[:, 1], elements[:, :3])
    normalized_mesh = minmax(conductivity)
    normalized_output = minmax(output_image)
    upsampled = zoom(normalized_output, 2.0, order=1)

    figure, axes = plt.subplots(1, 4, figsize=(16, 4), constrained_layout=True)
    mesh_image = axes[0].tripcolor(
        triangulation,
        facecolors=normalized_mesh,
        shading="flat",
        cmap="turbo",
        vmin=0.0,
        vmax=1.0,
    )
    axes[0].triplot(triangulation, color="white", linewidth=0.15, alpha=0.45)
    axes[0].set_title("M1 inverse mesh")
    figure.colorbar(mesh_image, ax=axes[0], fraction=0.046, pad=0.04)

    image = axes[1].imshow(
        normalized_output,
        origin="lower",
        cmap="turbo",
        vmin=0.0,
        vmax=1.0,
    )
    axes[1].set_title("f_theta(z), 128 x 128")
    figure.colorbar(image, ax=axes[1], fraction=0.046, pad=0.04)

    high_image = axes[2].imshow(
        upsampled,
        origin="lower",
        cmap="turbo",
        vmin=0.0,
        vmax=1.0,
    )
    axes[2].set_title("Mapped high-res grid")
    figure.colorbar(high_image, ax=axes[2], fraction=0.046, pad=0.04)

    axes[3].imshow(
        upsampled,
        origin="lower",
        cmap="gray",
        vmin=0.0,
        vmax=1.0,
    )
    axes[3].contour(upsampled, levels=[0.35, 0.65], colors=["cyan", "orange"], linewidths=1.8)
    axes[3].set_title("Boundary contours")

    for axis in axes:
        axis.set_aspect("equal")
        axis.set_axis_off()
    figure.suptitle("DeepEIT high-resolution boundary extraction")
    figure.savefig(output_path, dpi=180)
    plt.close(figure)
