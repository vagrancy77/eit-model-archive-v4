from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
from matplotlib.path import Path as MplPath
import matplotlib.pyplot as plt
import matplotlib.tri as mtri
import numpy as np
import pyeit.eit.protocol as protocol
from pyeit.mesh.wrapper import PyEITMesh

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from deepeit_reproduction.deepeit_core import (  # noqa: E402
    DeepEITConfig,
    estimate_homogeneous_conductivity,
    minmax,
    run_deepeit,
    write_history_csv,
)
from deepeit_reproduction.run_deepeit_reproduction import (  # noqa: E402
    metrics_for_reconstructions,
    run_tv_baseline,
)
from eit_basic.cem import CEMForward, reconstruct_cem_tikhonov  # noqa: E402
from eit_basic.noise import add_gaussian_noise_at_snr  # noqa: E402


@dataclass(frozen=True)
class Shape:
    kind: str
    center: tuple[float, float]
    size: tuple[float, float] | float
    angle_degrees: float = 0.0


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run surrogate water-tank DeepEIT cases when KIT-4 data are unavailable."
    )
    parser.add_argument(
        "--base-data",
        type=Path,
        default=PROJECT_ROOT / "outputs" / "simulation_data.npz",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=PROJECT_ROOT / "deepeit_reproduction" / "outputs_surrogate_water_tank",
    )
    parser.add_argument("--iterations", type=int, default=500)
    parser.add_argument("--image-size", type=int, default=128)
    parser.add_argument("--seed", type=int, default=20260801)
    parser.add_argument("--snr-db", type=float, default=60.0)
    parser.add_argument("--target-conductivity", type=float, default=0.05)
    parser.add_argument("--background-conductivity", type=float, default=1.0)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--electrode-width", type=float, default=2.5 / 14.0)
    parser.add_argument("--contact-impedance", type=float, default=0.01)
    parser.add_argument("--current-amplitude", type=float, default=1.0)
    parser.add_argument("--lambda-reg", type=float, default=0.01)
    return parser.parse_args()


def make_mesh(nodes: np.ndarray, elements: np.ndarray, electrodes: np.ndarray) -> PyEITMesh:
    return PyEITMesh(
        node=nodes,
        element=elements,
        perm=np.ones(elements.shape[0]),
        el_pos=electrodes,
    )


def centers(mesh: PyEITMesh) -> np.ndarray:
    return mesh.node[mesh.element[:, :3], :2].mean(axis=1)


def rectangle_mask(points: np.ndarray, shape: Shape) -> np.ndarray:
    width, height = shape.size  # type: ignore[misc]
    translated = points - np.asarray(shape.center, dtype=float)
    angle = np.deg2rad(shape.angle_degrees)
    cosine, sine = np.cos(angle), np.sin(angle)
    x_rotated = cosine * translated[:, 0] + sine * translated[:, 1]
    y_rotated = -sine * translated[:, 0] + cosine * translated[:, 1]
    return (np.abs(x_rotated) <= width / 2.0) & (np.abs(y_rotated) <= height / 2.0)


def circle_mask(points: np.ndarray, shape: Shape) -> np.ndarray:
    radius = float(shape.size)  # type: ignore[arg-type]
    return np.sum((points - np.asarray(shape.center, dtype=float)) ** 2, axis=1) <= radius**2


def triangle_mask(points: np.ndarray, shape: Shape) -> np.ndarray:
    width, height = shape.size  # type: ignore[misc]
    local = np.array(
        [
            [-width / 2.0, -height / 2.0],
            [width / 2.0, -height / 2.0],
            [0.0, height / 2.0],
        ],
        dtype=float,
    )
    angle = np.deg2rad(shape.angle_degrees)
    rotation = np.array(
        [[np.cos(angle), -np.sin(angle)], [np.sin(angle), np.cos(angle)]],
        dtype=float,
    )
    vertices = local @ rotation.T + np.asarray(shape.center, dtype=float)
    return MplPath(vertices).contains_points(points)


def apply_shapes(
    mesh: PyEITMesh,
    shapes: list[Shape],
    background: float,
    target: float,
) -> np.ndarray:
    points = centers(mesh)
    conductivity = np.full(mesh.n_elems, background, dtype=float)
    mask = np.zeros(mesh.n_elems, dtype=bool)
    for shape in shapes:
        if shape.kind == "rectangle":
            mask |= rectangle_mask(points, shape)
        elif shape.kind == "triangle":
            mask |= triangle_mask(points, shape)
        elif shape.kind == "circle":
            mask |= circle_mask(points, shape)
        else:
            raise ValueError(f"unknown shape kind: {shape.kind}")
    conductivity[mask] = target
    return conductivity


def surrogate_case_shapes() -> dict[str, list[Shape]]:
    return {
        "case2_rectangle": [
            Shape("rectangle", center=(0.34, 0.20), size=(0.18, 0.48), angle_degrees=-35.0),
        ],
        "case3_rectangle_triangle": [
            Shape("rectangle", center=(-0.33, 0.05), size=(0.16, 0.42), angle_degrees=-42.0),
            Shape("triangle", center=(0.33, 0.25), size=(0.34, 0.38), angle_degrees=-18.0),
        ],
        "case4_rectangle_circle": [
            Shape("rectangle", center=(-0.38, -0.03), size=(0.16, 0.46), angle_degrees=78.0),
            Shape("circle", center=(0.36, -0.34), size=0.18),
        ],
        "case5_three_targets": [
            Shape("rectangle", center=(-0.42, -0.05), size=(0.16, 0.42), angle_degrees=-20.0),
            Shape("triangle", center=(0.35, 0.42), size=(0.34, 0.38), angle_degrees=-20.0),
            Shape("circle", center=(0.45, -0.35), size=0.17),
        ],
    }


def plot_case(
    nodes: np.ndarray,
    elements: np.ndarray,
    truth: np.ndarray,
    reconstructions: dict[str, np.ndarray],
    metrics: dict[str, dict[str, float]],
    output_path: Path,
    title: str,
) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    triangulation = mtri.Triangulation(nodes[:, 0], nodes[:, 1], elements[:, :3])
    panels = [("Ground truth", truth), *reconstructions.items()]
    figure, axes = plt.subplots(1, len(panels), figsize=(4 * len(panels), 4), constrained_layout=True)
    for axis, (name, field) in zip(axes, panels, strict=True):
        image = axis.tripcolor(
            triangulation,
            facecolors=minmax(field),
            shading="flat",
            cmap="turbo",
            vmin=0.0,
            vmax=1.0,
        )
        axis.set_aspect("equal")
        axis.set_axis_off()
        label = name
        if name in metrics:
            metric = metrics[name]
            label = (
                f"{name}\nSSIM={metric['ssim']:.2f}, CC={metric['cc']:.2f}\n"
                f"PSNR={metric['psnr']:.1f}, RE={metric['re']:.3f}"
            )
        axis.set_title(label, fontsize=9)
        figure.colorbar(image, ax=axis, fraction=0.046, pad=0.04)
    figure.suptitle(title)
    figure.savefig(output_path, dpi=180)
    plt.close(figure)


def main() -> None:
    args = parse_arguments()
    saved = np.load(args.base_data)
    forward_mesh = make_mesh(
        saved["forward_nodes"],
        saved["forward_elements"],
        saved["forward_electrode_nodes"],
    )
    inverse_mesh = make_mesh(
        saved["inverse_nodes"],
        saved["inverse_elements"],
        saved["inverse_electrode_nodes"],
    )
    protocol_object = protocol.create(
        n_el=inverse_mesh.el_pos.size,
        dist_exc=1,
        step_meas=1,
        parser_meas="std",
    )
    forward_solver = CEMForward(
        forward_mesh,
        protocol_object,
        electrode_width=args.electrode_width,
        contact_impedance=args.contact_impedance,
        current_amplitude=args.current_amplitude,
    )
    inverse_solver = CEMForward(
        inverse_mesh,
        protocol_object,
        electrode_width=args.electrode_width,
        contact_impedance=args.contact_impedance,
        current_amplitude=args.current_amplitude,
    )
    background_voltage = inverse_solver.solve_protocol(
        np.ones(inverse_mesh.n_elems),
    ).measurements
    jacobian = inverse_solver.compute_jacobian(np.ones(inverse_mesh.n_elems))
    args.output_dir.mkdir(parents=True, exist_ok=True)
    summary: dict[str, object] = {
        "scope": "surrogate water-tank cases for DeepEIT paper Cases 2-5",
        "strict_reproduction": False,
        "reason": "KIT-4 water tank voltages and target masks are not public with the paper.",
        "iterations": args.iterations,
        "cases": {},
    }
    for index, (case_name, shapes) in enumerate(surrogate_case_shapes().items(), start=2):
        print(f"Running surrogate {case_name}...", flush=True)
        sigma_forward = apply_shapes(
            forward_mesh,
            shapes,
            args.background_conductivity,
            args.target_conductivity,
        )
        sigma_inverse = apply_shapes(
            inverse_mesh,
            shapes,
            args.background_conductivity,
            args.target_conductivity,
        )
        clean_voltage = forward_solver.solve_protocol(sigma_forward).measurements
        noisy_voltage, _, actual_snr = add_gaussian_noise_at_snr(
            clean_voltage,
            args.snr_db,
            random_seed=args.seed + index,
        )
        sigma_hom = estimate_homogeneous_conductivity(inverse_solver, noisy_voltage)
        config = DeepEITConfig(
            iterations=args.iterations,
            image_size=args.image_size,
            learning_rate=1e-3,
            skip_channels=(0, 0, 0, 4, 4),
            eta=2.0,
            lsp_threshold=None,
            seed=args.seed + index,
            device=args.device,
            log_every=max(args.iterations // 5, 1),
        )
        result = run_deepeit(
            inverse_solver,
            noisy_voltage,
            inverse_mesh.node,
            inverse_mesh.element,
            config,
            sigma_homogeneous=sigma_hom,
        )
        difference = noisy_voltage - background_voltage
        noser = sigma_hom + reconstruct_cem_tikhonov(
            jacobian,
            difference,
            lambda_reg=args.lambda_reg,
            p=0.5,
        )
        l2 = sigma_hom + reconstruct_cem_tikhonov(
            jacobian,
            difference,
            lambda_reg=args.lambda_reg,
            p=0.0,
        )
        tv = run_tv_baseline(
            inverse_solver,
            noisy_voltage,
            inverse_mesh,
            iterations=30,
        )
        reconstructions = {
            "DeepEIT": result.conductivity,
            "NOSER": noser,
            "L2": l2,
            "TV": tv,
        }
        metrics = metrics_for_reconstructions(
            inverse_mesh.node,
            inverse_mesh.element,
            sigma_inverse,
            reconstructions,
            args.image_size,
        )
        case_dir = args.output_dir / case_name
        case_dir.mkdir(parents=True, exist_ok=True)
        write_history_csv(result.history, case_dir / "deepeit_history.csv")
        np.savez_compressed(
            case_dir / "surrogate_case_results.npz",
            truth=sigma_inverse,
            deepeit=result.conductivity,
            noser=noser,
            l2=l2,
            tv=tv,
            measured_voltage=noisy_voltage,
            clean_voltage=clean_voltage,
            forward_truth=sigma_forward,
            inverse_nodes=inverse_mesh.node,
            inverse_elements=inverse_mesh.element,
        )
        plot_case(
            inverse_mesh.node[:, :2],
            inverse_mesh.element[:, :3],
            sigma_inverse,
            reconstructions,
            metrics,
            case_dir / "surrogate_reconstruction.png",
            f"Surrogate {case_name}: paper Case {index} analogue",
        )
        summary["cases"][case_name] = {
            "actual_snr_db": float(actual_snr),
            "metrics": metrics,
            "figure": str((case_dir / "surrogate_reconstruction.png").resolve()),
        }
    with (args.output_dir / "surrogate_summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
