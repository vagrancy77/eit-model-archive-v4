# DeepEIT Reproduction Report

Paper: DeepEIT: Deep Image Prior Enabled Electrical Impedance Tomography, IEEE TPAMI 2023.

This report separates strict reproduction from independent reproduction. Strict reproduction is blocked because the paper does not distribute the custom code, KIT-4 water-tank voltage data, target photographs, target masks, exact random seeds or exact meshes. The implemented pipeline is therefore an independent reproduction using the published model, protocol and hyperparameters wherever available.

## Reproduction Scope

Implemented:

- Complete electrode model forward solver through the existing SciPy CEM backend.
- DIP parameterization sigma = P(f_theta(z)).
- U-Net-like encoder-decoder with skip channels ns = [0, 0, 0, 4, 4].
- Random input image z ~ U(0, 0.1), size 1 x 128 x 128.
- Adam optimizer with learning rate 0.001.
- Case 1 paper-length 5000-iteration DeepEIT run.
- NOSER, L2/Tikhonov and TV baselines.
- Fig. 4-style simulation result.
- Fig. 5-style high-resolution mapping.
- Fig. 11-14 ablation pipeline.
- Surrogate water-tank Cases 2-5 pipeline for when the original KIT-4 data are unavailable.

Not strictly reproducible from public material:

- Fig. 3 target photos and masks.
- Fig. 6-9 experimental KIT-4 reconstructions.
- Fig. 10 exact DIP vs DIP+TV water-tank comparison.

## Main Case 1 Result

Output directory:

`deepeit_reproduction/outputs_case1_5000_no_lsp`

Paper Table I target for Case 1 DeepEIT:

| Metric | Paper |
|---|---:|
| SSIM | 0.87 |
| CC | 0.96 |
| PSNR | 23.0 |
| RE | 0.016 |

Local independent 5000-iteration result:

| Method | SSIM | CC | PSNR | RE |
|---|---:|---:|---:|---:|
| DeepEIT | 0.870 | 0.881 | 18.1 | 0.221 |
| NOSER | 0.784 | 0.803 | 14.5 | 0.338 |
| L2 | 0.062 | 0.123 | 10.7 | 0.521 |
| TV | 0.863 | 0.874 | 16.3 | 0.272 |

Conclusion: the local run reproduces the paper's qualitative conclusion and nearly matches the reported SSIM, but it does not match CC, PSNR or RE. The likely causes are different meshes, phantom geometry, metric implementation details, unspecified eta, missing author random seed and our independent CEM implementation.

## Key Outputs

- Fig. 4 analogue: `outputs_case1_5000_no_lsp/figure4_case1_recomputed.png`
- Fig. 5 analogue: `outputs_case1_5000_no_lsp/figure5_high_resolution_mapping.png`
- Fig. 11 analogue: `outputs_paper_ablations_20260801/ablations/figure11_learning_rate_reconstructions.png`
- Fig. 12 analogue: `outputs_paper_ablations_20260801/ablations/figure12_learning_rate_loss_curves.png`
- Fig. 13 analogue: `outputs_paper_ablations_20260801/ablations/figure13_skip_connection_ablation.png`
- Fig. 14 partial analogue: `outputs_paper_ablations_20260801/ablations/figure14_lsp_comparison.png`
- Case 1 arrays: `outputs_case1_5000_no_lsp/case1_results.npz`
- Case 1 history: `outputs_case1_5000_no_lsp/case1_history.csv`
- Recomputed metrics: `outputs_case1_5000_no_lsp/case1_metrics_recomputed.json`
- Surrogate Cases 2-5: `outputs_surrogate_water_tank_20260801/surrogate_summary.json`

## Ablation Results

The 1000-iteration local ablation suite reproduced the paper's qualitative hyperparameter conclusions:

- Learning rate 0.001 is the strongest setting among [0.1, 0.01, 0.001, 0.0001, 0.00001].
- Skip channels [0, 0, 0, 4, 4] outperform no skips and are comparable to full skips, matching the paper's choice.
- The LSP/no-LSP comparison shows that no-LSP runs can have sharp objective spikes, while LSP produces a smoother loss curve.

Learning-rate summary:

| lr | SSIM | CC | PSNR | RE |
|---:|---:|---:|---:|---:|
| 0.1 | 0.815 | 0.850 | 13.1 | 0.394 |
| 0.01 | 0.838 | 0.853 | 15.6 | 0.298 |
| 0.001 | 0.859 | 0.879 | 18.3 | 0.217 |
| 0.0001 | 0.720 | 0.737 | 15.0 | 0.318 |
| 0.00001 | 0.603 | 0.623 | 13.1 | 0.394 |

Skip-connection summary:

| ns | SSIM | CC | PSNR | RE |
|---|---:|---:|---:|---:|
| [0, 0, 0, 0, 0] | 0.775 | 0.785 | 16.0 | 0.284 |
| [0, 0, 0, 4, 4] | 0.859 | 0.879 | 18.3 | 0.217 |
| [4, 4, 4, 4, 4] | 0.858 | 0.874 | 18.2 | 0.220 |

## Surrogate Cases 2-5

Because the original KIT-4 water-tank data are unavailable, the project includes surrogate CEM simulations with rectangle, triangle and circular insulating targets analogous to paper Cases 2-5. These are not strict reproductions of the experimental figures, but they keep the reconstruction workflow complete.

Average over four surrogate cases:

| Method | SSIM | CC | PSNR | RE |
|---|---:|---:|---:|---:|
| DeepEIT | 0.726 | 0.758 | 11.9 | 0.261 |
| NOSER | 0.483 | 0.532 | 8.3 | 0.397 |
| L2 | 0.036 | 0.041 | 9.0 | 0.362 |
| TV | 0.569 | 0.599 | 9.9 | 0.332 |

## Commands

Case 1:

```bash
cd /mnt/e/Codex/eit_reproduction
/home/luandingyu/miniforge3/envs/gn4ip-env/bin/python run_deepeit_reproduction.py --mode case1 --iterations 5000 --no-lsp --output-dir deepeit_reproduction/outputs_case1_5000_no_lsp
/home/luandingyu/miniforge3/envs/gn4ip-env/bin/python deepeit_reproduction/report_deepeit_result.py --results-dir deepeit_reproduction/outputs_case1_5000_no_lsp
```

Fig. 11-14 ablations:

```bash
/home/luandingyu/miniforge3/envs/gn4ip-env/bin/python run_deepeit_reproduction.py --mode full --skip-case1 --ablation-iterations 1000 --output-dir deepeit_reproduction/outputs_paper_ablations_20260801
```

Surrogate water-tank Cases 2-5:

```bash
/home/luandingyu/miniforge3/envs/gn4ip-env/bin/python deepeit_reproduction/run_surrogate_water_tank_cases.py --iterations 500 --output-dir deepeit_reproduction/outputs_surrogate_water_tank
```

## Current Verdict

The paper can be independently reproduced enough to support its main algorithmic claim: an untrained DIP network coupled with a CEM forward model can reconstruct simulated EIT targets and outperform conventional NOSER/L2 baselines. It cannot be completely and exactly reproduced from public assets alone.
