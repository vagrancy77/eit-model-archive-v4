from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pyeit.eit.protocol as protocol
from pyeit.mesh.wrapper import PyEITMesh

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from deepeit_reproduction.deepeit_core import (  # noqa: E402
    DeepEITConfig,
    elements_to_grid,
    estimate_homogeneous_conductivity,
    image_metrics,
    minmax,
    plot_deepeit_case1,
    plot_history,
    run_deepeit,
    write_history_csv,
)
from eit_basic.cem import CEMForward, reconstruct_cem_tikhonov  # noqa: E402
from eit_basic.nonlinear import NonlinearEITConfig, solve_absolute_eit  # noqa: E402


PAPER_DEEPEIT_CASE1 = {"ssim": 0.87, "cc": 0.96, "psnr": 23.0, "re": 0.016}


def parse_skip_channels(text: str) -> tuple[int, int, int, int, int]:
    values = tuple(int(part.strip()) for part in text.split(","))
    if len(values) != 5:
        raise argparse.ArgumentTypeError("skip channels must contain five integers")
    return values


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Reproduce DeepEIT with a PyTorch DIP generator and SciPy CEM."
    )
    parser.add_argument(
        "--mode",
        choices=["smoke", "case1", "full"],
        default="case1",
        help="smoke runs quickly; case1 reproduces the main simulation; full also runs ablations.",
    )
    parser.add_argument(
        "--base-data",
        type=Path,
        default=PROJECT_ROOT / "outputs" / "simulation_data.npz",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=PROJECT_ROOT / "deepeit_reproduction" / "outputs",
    )
    parser.add_argument("--iterations", type=int, default=None)
    parser.add_argument("--image-size", type=int, default=128)
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    parser.add_argument("--skip-channels", type=parse_skip_channels, default=(0, 0, 0, 4, 4))
    parser.add_argument("--eta", type=float, default=2.0)
    parser.add_argument("--tv-weight", type=float, default=0.0)
    parser.add_argument("--lsp-threshold", type=float, default=0.01)
    parser.add_argument("--lsp-lr-backoff", type=float, default=0.9)
    parser.add_argument("--no-lsp", action="store_true")
    parser.add_argument("--seed", type=int, default=20260801)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--electrode-width", type=float, default=2.5 / 14.0)
    parser.add_argument("--contact-impedance", type=float, default=0.01)
    parser.add_argument("--current-amplitude", type=float, default=1.0)
    parser.add_argument("--lambda-reg", type=float, default=0.01)
    parser.add_argument("--tv-baseline-iterations", type=int, default=None)
    parser.add_argument("--ablation-iterations", type=int, default=1000)
    parser.add_argument("--skip-case1", action="store_true")
    parser.add_argument("--ensure-base-data", action="store_true")
    return parser.parse_args()


def ensure_base_data(path: Path) -> None:
    if path.exists():
        return
    subprocess.run(
        [
            sys.executable,
            str(PROJECT_ROOT / "run_basic_eit.py"),
            "--model",
            "cem",
            "--output-dir",
            str(path.parent),
        ],
        cwd=PROJECT_ROOT,
        check=True,
    )


def make_mesh(nodes: np.ndarray, elements: np.ndarray, electrodes: np.ndarray) -> PyEITMesh:
    return PyEITMesh(
        node=nodes,
        element=elements,
        perm=np.ones(elements.shape[0]),
        el_pos=electrodes,
    )


def build_solver(saved: np.lib.npyio.NpzFile, args: argparse.Namespace) -> tuple[PyEITMesh, object, CEMForward]:
    inverse_mesh = make_mesh(
        saved["inverse_nodes"],
        saved["inverse_elements"],
        saved["inverse_electrode_nodes"],
    )
    protocol_object = protocol.create(
        n_el=inverse_mesh.el_pos.size,
        dist_exc=1,
        step_meas=1,
        parser_meas="std",
    )
    np.testing.assert_array_equal(protocol_object.ex_mat, saved["excitation_matrix"])
    np.testing.assert_array_equal(protocol_object.meas_mat, saved["measurement_matrix"])
    solver = CEMForward(
        inverse_mesh,
        protocol_object,
        electrode_width=args.electrode_width,
        contact_impedance=args.contact_impedance,
        current_amplitude=args.current_amplitude,
    )
    return inverse_mesh, protocol_object, solver


def run_tv_baseline(
    solver: CEMForward,
    measured: np.ndarray,
    mesh: PyEITMesh,
    iterations: int,
) -> np.ndarray:
    config = NonlinearEITConfig(
        max_iterations=iterations,
        tv_weight=1e-4,
        l2_weight=1e-4,
        tv_epsilon=1e-3,
        lm_damping=1e-2,
        min_conductivity=0.05,
        max_conductivity=3.0,
    )
    result = solve_absolute_eit(
        solver,
        measured_voltage=measured,
        initial_conductivity=np.ones(mesh.n_elems),
        nodes=mesh.node,
        elements=mesh.element,
        config=config,
    )
    return result.conductivity


def metrics_for_reconstructions(
    nodes: np.ndarray,
    elements: np.ndarray,
    truth: np.ndarray,
    reconstructions: dict[str, np.ndarray],
    image_size: int,
) -> dict[str, dict[str, float]]:
    truth_image, mask = elements_to_grid(nodes, elements, truth, image_size=image_size)
    metrics: dict[str, dict[str, float]] = {}
    for name, reconstruction in reconstructions.items():
        image, _ = elements_to_grid(nodes, elements, reconstruction, image_size=image_size)
        metrics[name] = image_metrics(image, truth_image, mask)
    return metrics


def case1_iterations(args: argparse.Namespace) -> int:
    if args.iterations is not None:
        return args.iterations
    if args.mode == "smoke":
        return 30
    return 5000


def tv_iterations(args: argparse.Namespace) -> int:
    if args.tv_baseline_iterations is not None:
        return args.tv_baseline_iterations
    if args.mode == "smoke":
        return 3
    return 30


def run_case1(args: argparse.Namespace) -> dict[str, object]:
    ensure_base_data(args.base_data)
    saved = np.load(args.base_data)
    mesh, _, solver = build_solver(saved, args)
    measured = np.asarray(saved["voltage_noisy"], dtype=float)
    truth = np.asarray(saved["conductivity_true_inverse"], dtype=float)
    sigma_hom = estimate_homogeneous_conductivity(solver, measured)
    print(f"Homogeneous conductivity estimate: {sigma_hom:.6f}", flush=True)

    config = DeepEITConfig(
        iterations=case1_iterations(args),
        image_size=args.image_size,
        learning_rate=args.learning_rate,
        skip_channels=args.skip_channels,
        eta=args.eta,
        tv_weight=args.tv_weight,
        lsp_threshold=None if args.no_lsp else args.lsp_threshold,
        lsp_lr_backoff=args.lsp_lr_backoff,
        seed=args.seed,
        device=args.device,
        log_every=max(case1_iterations(args) // 20, 1),
    )
    result = run_deepeit(
        solver,
        measured_voltage=measured,
        nodes=mesh.node,
        elements=mesh.element,
        config=config,
        sigma_homogeneous=sigma_hom,
    )

    jacobian = solver.compute_jacobian(np.ones(mesh.n_elems))
    background = solver.solve_protocol(np.ones(mesh.n_elems)).measurements
    difference = measured - background
    noser = sigma_hom + reconstruct_cem_tikhonov(
        jacobian,
        difference,
        lambda_reg=args.lambda_reg,
        p=0.5,
    )
    l2 = sigma_hom + reconstruct_cem_tikhonov(
        jacobian,
        difference,
        lambda_reg=args.lambda_reg,
        p=0.0,
    )
    tv = run_tv_baseline(
        solver,
        measured,
        mesh,
        iterations=tv_iterations(args),
    )
    reconstructions = {
        "DeepEIT": result.conductivity,
        "NOSER": noser,
        "L2": l2,
        "TV": tv,
    }
    metrics = metrics_for_reconstructions(
        mesh.node,
        mesh.element,
        truth,
        reconstructions,
        image_size=args.image_size,
    )

    args.output_dir.mkdir(parents=True, exist_ok=True)
    write_history_csv(result.history, args.output_dir / "case1_history.csv")
    np.savez_compressed(
        args.output_dir / "case1_results.npz",
        truth=truth,
        deepeit=result.conductivity,
        noser=noser,
        l2=l2,
        tv=tv,
        output_image=result.image,
        noise_input=result.noise_input,
        predicted_voltage=result.predicted_voltage,
        measured_voltage=measured,
        sigma_homogeneous=np.array(result.sigma_homogeneous),
        inverse_nodes=mesh.node,
        inverse_elements=mesh.element,
    )
    plot_deepeit_case1(
        mesh.node[:, :2],
        mesh.element[:, :3],
        truth,
        result.noise_input / max(float(np.max(result.noise_input)), np.finfo(float).eps),
        result.image / max(float(np.max(result.image)), np.finfo(float).eps),
        reconstructions,
        metrics,
        args.output_dir / "figure4_case1_reproduction.png",
    )
    plot_history(result.history, args.output_dir / "case1_loss_curves.png")

    summary: dict[str, object] = {
        "paper": "DeepEIT: Deep Image Prior Enabled Electrical Impedance Tomography",
        "strict_reproduction_possible": False,
        "strict_reproduction_blockers": [
            "The paper states the custom code is available only from the corresponding author upon reasonable request.",
            "The KIT-4 water tank measurements and target masks for Cases 2-5 are not distributed with the paper.",
            "The exact FEM meshes, contact impedance, eta coefficient and random seeds are not fully specified.",
        ],
        "implemented_scope": "Independent Case 1 reproduction with the paper protocol and a paper-like DIP U-Net.",
        "mode": args.mode,
        "deep_eit_config": {
            "iterations": config.iterations,
            "image_size": config.image_size,
            "learning_rate": config.learning_rate,
            "skip_channels": config.skip_channels,
            "eta": config.eta,
            "tv_weight": config.tv_weight,
            "lsp_threshold": config.lsp_threshold,
            "lsp_lr_backoff": config.lsp_lr_backoff,
            "seed": config.seed,
            "device": config.device,
        },
        "paper_case1_deepeit_target": PAPER_DEEPEIT_CASE1,
        "metrics": metrics,
        "metric_difference_deepeit_minus_paper": {
            key: float(metrics["DeepEIT"][key] - PAPER_DEEPEIT_CASE1[key])
            for key in PAPER_DEEPEIT_CASE1
        },
        "sigma_homogeneous": result.sigma_homogeneous,
        "outputs": {
            "arrays": str((args.output_dir / "case1_results.npz").resolve()),
            "figure4": str((args.output_dir / "figure4_case1_reproduction.png").resolve()),
            "loss_curves": str((args.output_dir / "case1_loss_curves.png").resolve()),
            "history": str((args.output_dir / "case1_history.csv").resolve()),
        },
    }
    with (args.output_dir / "case1_summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    print(json.dumps(summary["metrics"], ensure_ascii=False, indent=2), flush=True)
    return summary


def run_full_ablations(args: argparse.Namespace) -> None:
    saved = np.load(args.base_data)
    mesh, _, solver = build_solver(saved, args)
    measured = np.asarray(saved["voltage_noisy"], dtype=float)
    truth = np.asarray(saved["conductivity_true_inverse"], dtype=float)
    sigma_hom = estimate_homogeneous_conductivity(solver, measured)
    ablation_dir = args.output_dir / "ablations"
    ablation_dir.mkdir(parents=True, exist_ok=True)

    learning_rates = [1e-1, 1e-2, 1e-3, 1e-4, 1e-5]
    skip_sets = [(0, 0, 0, 0, 0), (0, 0, 0, 4, 4), (4, 4, 4, 4, 4)]
    rows: list[dict[str, object]] = []
    truth_image, mask = elements_to_grid(
        mesh.node,
        mesh.element,
        truth,
        image_size=args.image_size,
    )
    learning_rate_results: list[tuple[float, np.ndarray, dict[str, float], object]] = []
    for lr in learning_rates:
        config = DeepEITConfig(
            iterations=args.ablation_iterations,
            image_size=args.image_size,
            learning_rate=lr,
            skip_channels=args.skip_channels,
            eta=args.eta,
            lsp_threshold=None if args.no_lsp else args.lsp_threshold,
            lsp_lr_backoff=args.lsp_lr_backoff,
            seed=args.seed,
            device=args.device,
            log_every=250,
        )
        result = run_deepeit(solver, measured, mesh.node, mesh.element, config, sigma_hom)
        metrics = metrics_for_reconstructions(
            mesh.node,
            mesh.element,
            truth,
            {"DeepEIT": result.conductivity},
            args.image_size,
        )["DeepEIT"]
        learning_rate_results.append((lr, result.conductivity, metrics, result.history))
        write_history_csv(
            result.history,
            ablation_dir / f"learning_rate_{lr:g}_history.csv",
        )
        rows.append({"study": "learning_rate", "value": lr, **metrics})

    figure, axes = plt.subplots(2, 3, figsize=(12, 8), constrained_layout=True)
    axes = axes.reshape(-1)
    axes[0].imshow(truth_image, origin="lower", cmap="turbo", vmin=0.0, vmax=1.0)
    axes[0].set_title("Ground truth")
    axes[0].set_axis_off()
    for axis, (lr, conductivity, metrics, _) in zip(axes[1:], learning_rate_results, strict=True):
        image, _ = elements_to_grid(mesh.node, mesh.element, conductivity, args.image_size)
        axis.imshow(minmax(image, mask), origin="lower", cmap="turbo", vmin=0.0, vmax=1.0)
        axis.set_title(
            f"lr={lr:g}\nSSIM={metrics['ssim']:.2f}, CC={metrics['cc']:.2f}\n"
            f"PSNR={metrics['psnr']:.1f}, RE={metrics['re']:.3f}",
            fontsize=9,
        )
        axis.set_axis_off()
    figure.suptitle("Fig. 11 reproduction: learning-rate robustness")
    figure.savefig(ablation_dir / "figure11_learning_rate_reconstructions.png", dpi=180)
    plt.close(figure)

    figure, axis = plt.subplots(figsize=(8, 5), constrained_layout=True)
    for lr, _, _, history in learning_rate_results:
        iterations = [record.iteration for record in history]
        losses = [record.loss for record in history]
        axis.semilogy(iterations, losses, label=f"lr={lr:g}", linewidth=1.0)
    axis.set_title("Fig. 12 reproduction: learning-rate loss curves")
    axis.set_xlabel("Iteration")
    axis.set_ylabel("Loss")
    axis.grid(alpha=0.25)
    axis.legend()
    figure.savefig(ablation_dir / "figure12_learning_rate_loss_curves.png", dpi=180)
    plt.close(figure)

    skip_results: list[tuple[tuple[int, int, int, int, int], np.ndarray, dict[str, float]]] = []
    for skips in skip_sets:
        config = DeepEITConfig(
            iterations=args.ablation_iterations,
            image_size=args.image_size,
            learning_rate=args.learning_rate,
            skip_channels=skips,
            eta=args.eta,
            lsp_threshold=None if args.no_lsp else args.lsp_threshold,
            lsp_lr_backoff=args.lsp_lr_backoff,
            seed=args.seed,
            device=args.device,
            log_every=250,
        )
        result = run_deepeit(solver, measured, mesh.node, mesh.element, config, sigma_hom)
        metrics = metrics_for_reconstructions(
            mesh.node,
            mesh.element,
            truth,
            {"DeepEIT": result.conductivity},
            args.image_size,
        )["DeepEIT"]
        skip_results.append((skips, result.conductivity, metrics))
        rows.append({"study": "skip_channels", "value": ",".join(map(str, skips)), **metrics})

    figure, axes = plt.subplots(1, 4, figsize=(14, 4), constrained_layout=True)
    axes[0].imshow(truth_image, origin="lower", cmap="turbo", vmin=0.0, vmax=1.0)
    axes[0].set_title("Ground truth")
    axes[0].set_axis_off()
    for axis, (skips, conductivity, metrics) in zip(axes[1:], skip_results, strict=True):
        image, _ = elements_to_grid(mesh.node, mesh.element, conductivity, args.image_size)
        axis.imshow(minmax(image, mask), origin="lower", cmap="turbo", vmin=0.0, vmax=1.0)
        axis.set_title(
            f"ns={list(skips)}\nSSIM={metrics['ssim']:.2f}, CC={metrics['cc']:.2f}\n"
            f"PSNR={metrics['psnr']:.1f}, RE={metrics['re']:.3f}",
            fontsize=9,
        )
        axis.set_axis_off()
    figure.suptitle("Fig. 13 reproduction: skip-connection ablation")
    figure.savefig(ablation_dir / "figure13_skip_connection_ablation.png", dpi=180)
    plt.close(figure)

    lsp_results: list[tuple[str, object]] = []
    for label, threshold in (("With LSP", args.lsp_threshold), ("Without LSP", None)):
        config = DeepEITConfig(
            iterations=args.ablation_iterations,
            image_size=args.image_size,
            learning_rate=args.learning_rate,
            skip_channels=args.skip_channels,
            eta=args.eta,
            lsp_threshold=threshold,
            lsp_lr_backoff=args.lsp_lr_backoff,
            seed=args.seed,
            device=args.device,
            log_every=max(args.ablation_iterations // 4, 1),
        )
        result = run_deepeit(solver, measured, mesh.node, mesh.element, config, sigma_hom)
        lsp_results.append((label, result.history))
        write_history_csv(
            result.history,
            ablation_dir / f"{label.lower().replace(' ', '_')}_history.csv",
        )
    figure, axes = plt.subplots(1, 2, figsize=(11, 4), constrained_layout=True)
    for label, history in lsp_results:
        iterations = [record.iteration for record in history]
        losses = [record.loss for record in history]
        voltage_errors = [record.relative_voltage_error for record in history]
        axes[0].semilogy(iterations, losses, label=label, linewidth=1.0)
        axes[1].semilogy(iterations, voltage_errors, label=label, linewidth=1.0)
    axes[0].set_title("Loss")
    axes[1].set_title("Relative voltage error")
    for axis in axes:
        axis.set_xlabel("Iteration")
        axis.grid(alpha=0.25)
        axis.legend()
    figure.suptitle("Fig. 14 partial reproduction: LSP vs no LSP")
    figure.savefig(ablation_dir / "figure14_lsp_comparison.png", dpi=180)
    plt.close(figure)

    with (ablation_dir / "ablation_summary.json").open("w", encoding="utf-8") as handle:
        json.dump(rows, handle, ensure_ascii=False, indent=2)


def main() -> None:
    args = parse_arguments()
    if args.ensure_base_data:
        ensure_base_data(args.base_data)
    summary = None if args.skip_case1 else run_case1(args)
    if args.mode == "full":
        run_full_ablations(args)
    print(f"DeepEIT reproduction outputs: {args.output_dir.resolve()}")
    print(f"Summary: {(args.output_dir / 'case1_summary.json').resolve()}")
    if summary is not None and not summary["strict_reproduction_possible"]:
        print("Note: this is an independent reproduction because author code/data are not public.")


if __name__ == "__main__":
    main()
