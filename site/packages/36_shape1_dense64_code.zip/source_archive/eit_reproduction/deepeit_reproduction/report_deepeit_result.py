from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from deepeit_reproduction.deepeit_core import (  # noqa: E402
    plot_deepeit_case1,
    plot_high_resolution_mapping,
    plot_history,
)
from deepeit_reproduction.run_deepeit_reproduction import (  # noqa: E402
    PAPER_DEEPEIT_CASE1,
    metrics_for_reconstructions,
)


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Recompute metrics and figures from saved DeepEIT arrays."
    )
    parser.add_argument(
        "--results-dir",
        type=Path,
        default=PROJECT_ROOT
        / "deepeit_reproduction"
        / "outputs_case1_5000_no_lsp",
    )
    parser.add_argument("--image-size", type=int, default=128)
    return parser.parse_args()


def main() -> None:
    args = parse_arguments()
    arrays = np.load(args.results_dir / "case1_results.npz")
    history_path = args.results_dir / "case1_history.csv"
    reconstructions = {
        "DeepEIT": arrays["deepeit"],
        "NOSER": arrays["noser"],
        "L2": arrays["l2"],
        "TV": arrays["tv"],
    }
    metrics = metrics_for_reconstructions(
        arrays["inverse_nodes"],
        arrays["inverse_elements"],
        arrays["truth"],
        reconstructions,
        image_size=args.image_size,
    )
    summary = {
        "paper_case1_deepeit_target": PAPER_DEEPEIT_CASE1,
        "metrics": metrics,
        "metric_difference_deepeit_minus_paper": {
            key: float(metrics["DeepEIT"][key] - PAPER_DEEPEIT_CASE1[key])
            for key in PAPER_DEEPEIT_CASE1
        },
        "metric_note": (
            "Metrics were recomputed from saved arrays using the paper-facing "
            "global SSIM field plus an auxiliary ssim_windowed value. "
            "All image metrics use min-max normalization inside the circular "
            "imaging domain."
        ),
        "source_results": str((args.results_dir / "case1_results.npz").resolve()),
    }
    with (args.results_dir / "case1_metrics_recomputed.json").open(
        "w",
        encoding="utf-8",
    ) as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)

    noise = arrays["noise_input"]
    output_image = arrays["output_image"]
    plot_deepeit_case1(
        arrays["inverse_nodes"][:, :2],
        arrays["inverse_elements"][:, :3],
        arrays["truth"],
        noise / max(float(np.max(noise)), np.finfo(float).eps),
        output_image / max(float(np.max(output_image)), np.finfo(float).eps),
        reconstructions,
        metrics,
        args.results_dir / "figure4_case1_recomputed.png",
    )
    plot_high_resolution_mapping(
        arrays["inverse_nodes"][:, :2],
        arrays["inverse_elements"][:, :3],
        arrays["deepeit"],
        output_image,
        args.results_dir / "figure5_high_resolution_mapping.png",
    )
    if history_path.exists():
        import csv

        from deepeit_reproduction.deepeit_core import DeepEITIteration

        history = []
        with history_path.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            for row in reader:
                history.append(
                    DeepEITIteration(
                        iteration=int(row["iteration"]),
                        loss=float(row["loss"]),
                        data_loss=float(row["data_loss"]),
                        tv_loss=float(row["tv_loss"]),
                        relative_voltage_error=float(row["relative_voltage_error"]),
                        sigma_min=float(row["sigma_min"]),
                        sigma_max=float(row["sigma_max"]),
                        learning_rate=float(row["learning_rate"]),
                        rejected_by_lsp=row["rejected_by_lsp"] == "True",
                    )
                )
        plot_history(history, args.results_dir / "case1_loss_curves_recomputed.png")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
