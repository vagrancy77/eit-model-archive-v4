"""Download and verify the public Edinburgh mfEIT Dataset (CC BY 4.0)."""

from __future__ import annotations

import argparse
import shutil
import urllib.request
import zipfile
from pathlib import Path


DATA_URL = "https://datashare.ed.ac.uk/bitstreams/c7546c17-521f-4f08-8667-5ab10000cd15/download"
README_URL = "https://datashare.ed.ac.uk/bitstreams/603e7a9e-f671-4654-bf01-5e2de290c4d9/download"
LICENSE_URL = "https://datashare.ed.ac.uk/bitstreams/9997bdcb-4a52-4a78-b55c-0e51de843650/download"
EXPECTED_ZIP_BYTES = 47_576_486


def download(url: str, output: Path, expected_size: int | None = None) -> None:
    existing = output.stat().st_size if output.exists() else 0
    if expected_size is not None and existing == expected_size:
        print(f"already complete: {output}")
        return
    headers = {"User-Agent": "eit-reproduction/1.0"}
    mode = "wb"
    if existing > 0:
        headers["Range"] = f"bytes={existing}-"
        mode = "ab"
    request = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(request, timeout=120) as response:
        if existing > 0 and response.status != 206:
            existing = 0
            mode = "wb"
        with output.open(mode) as handle:
            shutil.copyfileobj(response, handle, length=1024 * 1024)
    if expected_size is not None and output.stat().st_size != expected_size:
        raise IOError(
            f"incomplete download: expected {expected_size} bytes, obtained {output.stat().st_size}; rerun to resume"
        )


def main() -> None:
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Download Edinburgh mfEIT Dataset from Edinburgh DataShare.")
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=root / "datasets" / "public" / "edinburgh_mfeit",
    )
    arguments = parser.parse_args()
    arguments.output_dir.mkdir(parents=True, exist_ok=True)
    archive = arguments.output_dir / "Edinburgh_mfEIT_Dataset.zip"
    download(DATA_URL, archive, EXPECTED_ZIP_BYTES)
    download(README_URL, arguments.output_dir / "README_source.txt")
    download(LICENSE_URL, arguments.output_dir / "license_text.txt")
    with zipfile.ZipFile(archive) as package:
        damaged = package.testzip()
        if damaged is not None:
            raise zipfile.BadZipFile(f"CRC failure in {damaged}")
        package.extractall(arguments.output_dir / "raw")
    print("dataset verified and extracted")
    print("citation: Chen et al. (2022), Edinburgh mfEIT Dataset, DOI 10.7488/ds/3464")


if __name__ == "__main__":
    main()
