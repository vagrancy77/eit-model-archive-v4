# Non-convex EIT reconstruction: method basis and experiment policy

## Problem definition

The target is not a cross-shaped phantom. It is any conductivity anomaly with
one or more materially inward boundaries. An instance is declared materially
non-convex before model comparison when its convex-hull indentation contains at
least 50 pixels and at least 3% of the instance convex hull at 256 x 256
resolution.

The public KTC2023 v3 evaluation set contains 21 phantoms. Under this fixed
component-wise rule, 17 contain at least one materially non-convex instance.
Their labels are not used for training, checkpoint selection, threshold
selection, or loss-weight selection.

## Literature routes used

The following records were queried from Crossref, OpenAlex, and Semantic
Scholar on 2026-08-19. They motivate an implicit boundary representation and
separate structure/electrical pathways rather than a shape-specific template.

1. A Parametric Level Set Method for Electrical Impedance Tomography. IEEE
   Transactions on Medical Imaging, 2018. DOI:
   <https://doi.org/10.1109/TMI.2017.2756078>
2. B-Spline Level Set Method for Shape Reconstruction in Electrical Impedance
   Tomography. IEEE Transactions on Medical Imaging, 2020. DOI:
   <https://doi.org/10.1109/TMI.2019.2961938>
3. Shape Reconstruction Using Boolean Operations in Electrical Impedance
   Tomography. IEEE Transactions on Medical Imaging, 2020. DOI:
   <https://doi.org/10.1109/TMI.2020.2983055>
4. Piecewise constant level-set enhanced active shape reconstruction for
   electrical impedance tomography. Measurement, 2021. DOI:
   <https://doi.org/10.1016/J.MEASUREMENT.2021.109335>
5. Bayesian Shape Reconstruction Using B-Spline Level Set in Electrical
   Impedance Tomography. IEEE Sensors Journal, 2022. DOI:
   <https://doi.org/10.1109/JSEN.2022.3199436>
6. Monotonicity-Based Shape Reconstruction in Electrical Impedance
   Tomography. SIAM Journal on Mathematical Analysis, 2013. DOI:
   <https://doi.org/10.1137/120886984>
7. A Moving Morphable Components Based Shape Reconstruction Framework for
   Electrical Impedance Tomography. IEEE Transactions on Medical Imaging,
   2019. DOI: <https://doi.org/10.1109/TMI.2019.2918566>
8. Shape-Driven Difference Electrical Impedance Tomography. IEEE Transactions
   on Medical Imaging, 2020. DOI:
   <https://doi.org/10.1109/TMI.2020.3004806>
9. Structure-Aware Dual-Branch Network for Electrical Impedance Tomography in
   Cell Culture Imaging. IEEE Transactions on Instrumentation and Measurement,
   2021. DOI: <https://doi.org/10.1109/TIM.2021.3092524>
10. DTU-Net: Learning Topological Similarity for Curvilinear Structure
    Segmentation, 2022. Open manuscript: <https://arxiv.org/abs/2205.11115>
11. Shape and boundary-aware multi-branch model for semi-supervised medical
    image segmentation. Computers in Biology and Medicine, 2022. DOI:
    <https://doi.org/10.1016/j.compbiomed.2022.105252>
12. Universal Topology Refinement for Medical Image Segmentation with
    Polynomial Feature Synthesis, 2024. Open manuscript:
    <https://arxiv.org/abs/2409.09796>

The MMC and shape-driven studies show that explicit geometry/topology variables
can outperform smooth pixel priors, including under modeling errors. We do not
copy their finite library of components: doing so would reintroduce a bias
toward a few named shapes. Instead, their shape/topology description principle
motivates a continuous implicit geometry field. The structure-aware dual-branch
study independently supports separating structural features from conductivity
features before their final prediction is formed.

The non-EIT segmentation studies add a second useful pattern: use a coarse
region predictor followed by a lightweight topology/error refiner, and train
the refiner on diverse synthetic segmentation failures. This is more relevant
to inward bays than a persistent-homology loss alone. Persistent homology can
constrain component and hole counts, but two shapes can have identical topology
while having completely different indentation depth. It is therefore an
optional global safeguard, not the primary concavity mechanism.

The signed-distance surface loss follows the general boundary-loss principle
introduced for segmentation by Kervadec et al. It is combined with region loss
rather than used alone, because a surface term can otherwise favor an empty or
shrunken foreground.

## What changed from the first shape-aware network

The first network penalized foreground probability throughout the ground-truth
convex-hull indentation. That improved notch preservation but was one-sided: a
network could shrink or miss a weak lesion and still receive a better notch
score.

The v2 experiment makes four structural changes:

1. A signed-distance head represents the boundary as a continuous zero level
   set. It does not encode a cross, star, crescent, or any other named shape.
2. A distance-based surface term and gradient agreement constrain the complete
   boundary.
3. Indentation supervision is local and symmetric. False foreground inside the
   notch and false background on the two lesion banks of the notch are penalized
   together, per sample, with equal weight.
4. A gated voltage encoder consumes the ordered 76 x 31 KTC measurement table
   in addition to the ridge image. The gate is initialized near zero so the
   model must demonstrate that raw measurements add useful information.

The conductivity head and KTC Jacobian consistency remain optional ablation
stages. No claim is based on adding all losses at once.

## Required comparisons

The fixed incremental ablation is:

1. `vanilla`: residual attention U-Net, cross-entropy plus Dice.
2. `sdf`: add continuous signed-distance geometry.
3. `boundary`: add gradient and signed-distance surface terms.
4. `indent`: add symmetric local indentation supervision.
5. `physics`: add conductivity regression and KTC Jacobian consistency.
6. `voltage`: add the gated raw-voltage branch without the linearized physics
   term, so a harmful physics loss cannot mask the voltage contribution.
7. `v2`: combine physics consistency and gated raw-voltage fusion.

After this ablation, a fusion experiment may combine the strongest region/
boundary component with the strongest indentation component. Candidate weights,
pooling rule, and admissibility constraints are chosen on synthetic validation
only. A candidate is inadmissible when it loses more than 0.005 validation IoU
or 0.010 boundary F1 relative to the best individual validation component. The
synthetic test and KTC evaluation labels are accessed only after this decision
is frozen.

All methods use the same nonlinear CEM training data, split, calibration cases,
optimizer, model-selection metric, and evaluation code.

## Success criteria

A method is not successful merely because notch preservation increases. It
must satisfy all of the following:

- improve the joint score `sqrt(foreground IoU * notch preservation)`;
- avoid a material drop in foreground IoU on the independent synthetic test;
- improve or preserve KTC-SSIM and lesion-class IoU on the untouched 21 cases;
- show a positive paired effect on the fixed 17-case subgroup;
- repeat across at least three training seeds;
- expose failures case by case rather than reporting only a pooled mean.

The 21 KTC evaluation labels are opened only after every checkpoint in a run is
frozen and the independent synthetic test has been evaluated.
