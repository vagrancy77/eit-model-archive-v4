from __future__ import annotations

from dataclasses import dataclass

import basix.ufl
import dolfinx
from dolfinx import fem
from dolfinx import mesh as dmesh
from mpi4py import MPI
import numpy as np
import scipy.linalg
import scipy.sparse as sparse
import scipy.sparse.linalg as sparse_linalg
from scipy.spatial import cKDTree
import ufl


@dataclass(frozen=True)
class ArrayProtocol:
    """EIT stimulation and measurement pairs without a pyEIT dependency."""

    excitation_pairs: np.ndarray
    measurement_pairs: np.ndarray

    def __post_init__(self) -> None:
        excitation_pairs = np.asarray(self.excitation_pairs, dtype=np.int64)
        measurement_pairs = np.asarray(self.measurement_pairs, dtype=np.int64)
        if excitation_pairs.ndim != 2 or excitation_pairs.shape[1] != 2:
            raise ValueError("excitation_pairs must have shape (n_exc, 2)")
        if (
            measurement_pairs.ndim != 3
            or measurement_pairs.shape[0] != excitation_pairs.shape[0]
            or measurement_pairs.shape[2] != 2
        ):
            raise ValueError(
                "measurement_pairs must have shape (n_exc, n_meas, 2)"
            )
        object.__setattr__(self, "excitation_pairs", excitation_pairs)
        object.__setattr__(self, "measurement_pairs", measurement_pairs)

    @property
    def n_excitations(self) -> int:
        return int(self.excitation_pairs.shape[0])

    @property
    def n_measurements_per_excitation(self) -> int:
        return int(self.measurement_pairs.shape[1])


@dataclass(frozen=True)
class FenicsxCEMSolution:
    """CEM fields returned in the original input-mesh ordering."""

    node_potentials: np.ndarray
    electrode_potentials: np.ndarray
    measurements: np.ndarray


@dataclass(frozen=True)
class _ElectrodeGeometry:
    edge_nodes: np.ndarray
    edge_electrode_ids: np.ndarray
    electrode_lengths: np.ndarray
    edge_counts: np.ndarray


def _triangle_geometry(
    nodes: np.ndarray,
    elements: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    coordinates = nodes[elements, :2]
    x0, y0 = coordinates[:, 0, 0], coordinates[:, 0, 1]
    x1, y1 = coordinates[:, 1, 0], coordinates[:, 1, 1]
    x2, y2 = coordinates[:, 2, 0], coordinates[:, 2, 1]

    twice_signed_area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0)
    if np.any(np.abs(twice_signed_area) < np.finfo(float).eps):
        raise ValueError("mesh contains a degenerate triangular element")

    areas = 0.5 * np.abs(twice_signed_area)
    gradients = np.empty((elements.shape[0], 3, 2), dtype=float)
    gradients[:, 0, 0] = y1 - y2
    gradients[:, 0, 1] = x2 - x1
    gradients[:, 1, 0] = y2 - y0
    gradients[:, 1, 1] = x0 - x2
    gradients[:, 2, 0] = y0 - y1
    gradients[:, 2, 1] = x1 - x0
    gradients /= twice_signed_area[:, None, None]
    return areas, gradients


def _boundary_edges(elements: np.ndarray) -> np.ndarray:
    all_edges = np.concatenate(
        [
            elements[:, [0, 1]],
            elements[:, [1, 2]],
            elements[:, [2, 0]],
        ],
        axis=0,
    )
    sorted_edges = np.sort(all_edges, axis=1)
    unique_edges, counts = np.unique(sorted_edges, axis=0, return_counts=True)
    return unique_edges[counts == 1]


def _assign_electrodes(
    nodes: np.ndarray,
    elements: np.ndarray,
    electrode_positions: np.ndarray,
    electrode_width: float,
) -> _ElectrodeGeometry:
    if electrode_width <= 0.0:
        raise ValueError("electrode_width must be positive")

    boundary_edges = _boundary_edges(elements)
    boundary_points = nodes[boundary_edges, :2]
    midpoint_angles = np.arctan2(
        boundary_points.mean(axis=1)[:, 1],
        boundary_points.mean(axis=1)[:, 0],
    )
    electrode_positions_2d = np.asarray(electrode_positions, dtype=float)[:, :2]
    electrode_angles = np.arctan2(
        electrode_positions_2d[:, 1],
        electrode_positions_2d[:, 0],
    )
    boundary_radius = float(
        np.mean(np.linalg.norm(electrode_positions_2d, axis=1))
    )
    half_angular_width = electrode_width / (2.0 * boundary_radius)

    angle_difference = midpoint_angles[:, None] - electrode_angles[None, :]
    wrapped_difference = np.arctan2(
        np.sin(angle_difference),
        np.cos(angle_difference),
    )
    closest_electrode = np.argmin(np.abs(wrapped_difference), axis=1)
    selected = np.min(np.abs(wrapped_difference), axis=1) <= half_angular_width

    edge_nodes = boundary_edges[selected]
    electrode_ids = closest_electrode[selected]
    edge_lengths = np.linalg.norm(
        nodes[edge_nodes[:, 0], :2] - nodes[edge_nodes[:, 1], :2],
        axis=1,
    )
    n_electrodes = electrode_positions_2d.shape[0]
    electrode_lengths = np.bincount(
        electrode_ids,
        weights=edge_lengths,
        minlength=n_electrodes,
    )
    edge_counts = np.bincount(electrode_ids, minlength=n_electrodes)
    if np.any(electrode_lengths <= 0.0):
        missing = np.flatnonzero(electrode_lengths <= 0.0).tolist()
        raise ValueError(
            "mesh is too coarse for the requested electrode width; "
            f"electrodes without boundary edges: {missing}"
        )
    return _ElectrodeGeometry(
        edge_nodes=edge_nodes,
        edge_electrode_ids=electrode_ids,
        electrode_lengths=electrode_lengths,
        edge_counts=edge_counts,
    )


def _match_coordinates(
    reference: np.ndarray,
    query: np.ndarray,
    tolerance: float,
    description: str,
) -> np.ndarray:
    distances, indices = cKDTree(reference).query(query)
    if np.max(distances, initial=0.0) > tolerance:
        raise RuntimeError(
            f"could not map {description}; maximum coordinate error is "
            f"{float(np.max(distances)):.3e}"
        )
    if np.unique(indices).size != query.shape[0]:
        raise RuntimeError(f"coordinate mapping for {description} is not one-to-one")
    return np.asarray(indices, dtype=np.int64)


class FenicsxCEMForward:
    """Complete electrode model with DOLFINx finite-element assembly.

    The volume stiffness and the electrode Robin mass terms are assembled by
    DOLFINx/UFL. The small electrode coupling blocks are integrated exactly on
    the same first-order boundary facets and combined with the DOLFINx matrix.
    All public arrays use the ordering of the input NumPy mesh.
    """

    def __init__(
        self,
        nodes: np.ndarray,
        elements: np.ndarray,
        electrode_positions: np.ndarray,
        protocol: ArrayProtocol,
        electrode_width: float,
        contact_impedance: float,
        current_amplitude: float = 1.0,
    ) -> None:
        if MPI.COMM_WORLD.size != 1:
            raise RuntimeError(
                "this reproducibility backend currently supports serial execution; "
                "run it with python rather than mpirun"
            )
        if contact_impedance <= 0.0:
            raise ValueError("contact_impedance must be positive")
        if current_amplitude <= 0.0:
            raise ValueError("current_amplitude must be positive")

        self.nodes = np.asarray(nodes, dtype=np.float64)[:, :2].copy()
        self.elements = np.asarray(elements, dtype=np.int64)[:, :3].copy()
        self.electrode_positions = np.asarray(
            electrode_positions,
            dtype=np.float64,
        )[:, :2].copy()
        self.protocol = protocol
        self.n_electrodes = int(self.electrode_positions.shape[0])
        self.electrode_width = float(electrode_width)
        self.contact_impedance = float(contact_impedance)
        self.current_amplitude = float(current_amplitude)

        maximum_electrode_index = max(
            int(np.max(protocol.excitation_pairs)),
            int(np.max(protocol.measurement_pairs)),
        )
        if maximum_electrode_index >= self.n_electrodes:
            raise ValueError("protocol references an electrode that does not exist")

        self.areas, self.basis_gradients = _triangle_geometry(
            self.nodes,
            self.elements,
        )
        self.electrodes = _assign_electrodes(
            self.nodes,
            self.elements,
            self.electrode_positions,
            self.electrode_width,
        )

        coordinate_element = basix.ufl.element(
            "Lagrange",
            "triangle",
            1,
            shape=(2,),
        )
        self.domain = dmesh.create_mesh(
            MPI.COMM_SELF,
            self.elements,
            coordinate_element,
            self.nodes,
        )
        self.potential_space = fem.functionspace(
            self.domain,
            ("Lagrange", 1),
        )
        self.conductivity_space = fem.functionspace(
            self.domain,
            ("DG", 0),
        )
        self._conductivity = fem.Function(self.conductivity_space)

        domain_scale = max(
            float(np.ptp(self.nodes[:, 0])),
            float(np.ptp(self.nodes[:, 1])),
            1.0,
        )
        tolerance = 1e-8 * domain_scale
        potential_coordinates = self.potential_space.tabulate_dof_coordinates()[
            :, :2
        ]
        self._potential_dof_for_input_node = _match_coordinates(
            potential_coordinates,
            self.nodes,
            tolerance,
            "CG1 degrees of freedom to input nodes",
        )
        input_cell_centers = self.nodes[self.elements].mean(axis=1)
        conductivity_coordinates = (
            self.conductivity_space.tabulate_dof_coordinates()[:, :2]
        )
        self._input_cell_for_conductivity_dof = _match_coordinates(
            input_cell_centers,
            conductivity_coordinates,
            tolerance,
            "DG0 degrees of freedom to input cells",
        )

        self.facet_tags, tagged_counts = self._build_facet_tags()
        if not np.array_equal(tagged_counts, self.electrodes.edge_counts):
            raise RuntimeError(
                "DOLFINx and NumPy electrode facet assignments disagree: "
                f"{tagged_counts.tolist()} != "
                f"{self.electrodes.edge_counts.tolist()}"
            )

        self._trial = ufl.TrialFunction(self.potential_space)
        self._test = ufl.TestFunction(self.potential_space)
        self._ds = ufl.Measure(
            "ds",
            domain=self.domain,
            subdomain_data=self.facet_tags,
        )
        electrode_mass = sum(
            self._trial * self._test * self._ds(electrode_index + 1)
            for electrode_index in range(self.n_electrodes)
        )
        self._node_form = fem.form(
            self._conductivity
            * ufl.inner(ufl.grad(self._trial), ufl.grad(self._test))
            * ufl.dx
            + (1.0 / self.contact_impedance) * electrode_mass
        )
        self._coupling_matrix, self._electrode_matrix = (
            self._assemble_electrode_blocks()
        )

    @property
    def dolfinx_version(self) -> str:
        return str(dolfinx.__version__)

    def _build_facet_tags(self) -> tuple[dmesh.MeshTags, np.ndarray]:
        topological_dimension = self.domain.topology.dim
        facet_dimension = topological_dimension - 1
        self.domain.topology.create_connectivity(
            facet_dimension,
            topological_dimension,
        )
        exterior_facets = dmesh.exterior_facet_indices(self.domain.topology)
        midpoints = dmesh.compute_midpoints(
            self.domain,
            facet_dimension,
            exterior_facets,
        )[:, :2]
        midpoint_angles = np.arctan2(midpoints[:, 1], midpoints[:, 0])
        electrode_angles = np.arctan2(
            self.electrode_positions[:, 1],
            self.electrode_positions[:, 0],
        )
        boundary_radius = float(
            np.mean(np.linalg.norm(self.electrode_positions, axis=1))
        )
        half_angular_width = self.electrode_width / (2.0 * boundary_radius)
        differences = midpoint_angles[:, None] - electrode_angles[None, :]
        wrapped = np.arctan2(np.sin(differences), np.cos(differences))
        electrode_ids = np.argmin(np.abs(wrapped), axis=1)
        selected = np.min(np.abs(wrapped), axis=1) <= half_angular_width

        tagged_facets = np.asarray(exterior_facets[selected], dtype=np.int32)
        tagged_values = np.asarray(electrode_ids[selected] + 1, dtype=np.int32)
        order = np.argsort(tagged_facets)
        facet_tags = dmesh.meshtags(
            self.domain,
            facet_dimension,
            tagged_facets[order],
            tagged_values[order],
        )
        counts = np.bincount(
            electrode_ids[selected],
            minlength=self.n_electrodes,
        )
        return facet_tags, counts

    def _assemble_electrode_blocks(
        self,
    ) -> tuple[sparse.csr_matrix, sparse.csr_matrix]:
        inverse_contact = 1.0 / self.contact_impedance
        edge_nodes = self.electrodes.edge_nodes
        electrode_ids = self.electrodes.edge_electrode_ids
        edge_lengths = np.linalg.norm(
            self.nodes[edge_nodes[:, 0]] - self.nodes[edge_nodes[:, 1]],
            axis=1,
        )

        rows: list[int] = []
        columns: list[int] = []
        values: list[float] = []
        electrode_diagonal = np.zeros(self.n_electrodes, dtype=float)
        for edge, electrode_id, edge_length in zip(
            edge_nodes,
            electrode_ids,
            edge_lengths,
            strict=True,
        ):
            first_dof = int(self._potential_dof_for_input_node[int(edge[0])])
            second_dof = int(self._potential_dof_for_input_node[int(edge[1])])
            coupling_value = -inverse_contact * float(edge_length) / 2.0
            rows.extend([first_dof, second_dof])
            columns.extend([int(electrode_id), int(electrode_id)])
            values.extend([coupling_value, coupling_value])
            electrode_diagonal[int(electrode_id)] += (
                inverse_contact * float(edge_length)
            )

        coupling = sparse.coo_matrix(
            (values, (rows, columns)),
            shape=(
                self.potential_space.dofmap.index_map.size_local,
                self.n_electrodes,
            ),
        ).tocsr()
        electrode = sparse.diags(electrode_diagonal, format="csr")
        return coupling, electrode

    def _validate_conductivity(
        self,
        conductivity: np.ndarray | float,
    ) -> np.ndarray:
        if np.isscalar(conductivity):
            values = np.full(self.elements.shape[0], conductivity, dtype=float)
        else:
            values = np.asarray(conductivity, dtype=float)
        if values.shape != (self.elements.shape[0],):
            raise ValueError("conductivity must contain one value per input cell")
        if np.any(values <= 0.0):
            raise ValueError("CEM conductivity values must be positive")
        return values

    def _assemble_system(
        self,
        conductivity: np.ndarray | float,
    ) -> sparse.csc_matrix:
        conductivity_values = self._validate_conductivity(conductivity)
        self._conductivity.x.array[:] = conductivity_values[
            self._input_cell_for_conductivity_dof
        ]
        self._conductivity.x.scatter_forward()

        node_matrix_dolfinx = fem.assemble_matrix(self._node_form)
        node_matrix_dolfinx.scatter_reverse()
        node_matrix = node_matrix_dolfinx.to_scipy().tocsr()

        n_potential_dofs = node_matrix.shape[0]
        node_constraint = sparse.csr_matrix((n_potential_dofs, 1))
        electrode_constraint = sparse.csr_matrix(
            np.ones((self.n_electrodes, 1), dtype=float)
        )
        scalar_zero = sparse.csr_matrix((1, 1))
        return sparse.bmat(
            [
                [node_matrix, self._coupling_matrix, node_constraint],
                [
                    self._coupling_matrix.transpose(),
                    self._electrode_matrix,
                    electrode_constraint,
                ],
                [
                    node_constraint.transpose(),
                    electrode_constraint.transpose(),
                    scalar_zero,
                ],
            ],
            format="csc",
        )

    def solve_pairs(
        self,
        conductivity: np.ndarray | float,
        electrode_pairs: np.ndarray,
        amplitudes: float | np.ndarray = 1.0,
    ) -> tuple[np.ndarray, np.ndarray]:
        pairs = np.asarray(electrode_pairs, dtype=np.int64)
        if pairs.ndim != 2 or pairs.shape[1] != 2:
            raise ValueError("electrode_pairs must have shape (n_patterns, 2)")
        if np.any(pairs < 0) or np.any(pairs >= self.n_electrodes):
            raise ValueError("electrode_pairs contains an invalid electrode index")

        amplitude_values = np.broadcast_to(
            np.asarray(amplitudes, dtype=float),
            (pairs.shape[0],),
        )
        system = self._assemble_system(conductivity)
        factorization = sparse_linalg.splu(system)
        n_potential_dofs = self.potential_space.dofmap.index_map.size_local
        right_hand_side = np.zeros(
            (n_potential_dofs + self.n_electrodes + 1, pairs.shape[0]),
            dtype=float,
        )
        for pattern_index, (pair, amplitude) in enumerate(
            zip(pairs, amplitude_values, strict=True)
        ):
            first_electrode, second_electrode = int(pair[0]), int(pair[1])
            right_hand_side[
                n_potential_dofs + first_electrode,
                pattern_index,
            ] = amplitude
            right_hand_side[
                n_potential_dofs + second_electrode,
                pattern_index,
            ] = -amplitude

        solution = factorization.solve(right_hand_side)
        dof_potentials = solution[:n_potential_dofs]
        input_node_potentials = dof_potentials[
            self._potential_dof_for_input_node
        ]
        electrode_potentials = solution[
            n_potential_dofs : n_potential_dofs + self.n_electrodes
        ]
        return input_node_potentials, electrode_potentials

    def solve_protocol(
        self,
        conductivity: np.ndarray | float,
    ) -> FenicsxCEMSolution:
        node_potentials, electrode_potentials = self.solve_pairs(
            conductivity,
            self.protocol.excitation_pairs,
            amplitudes=self.current_amplitude,
        )
        measurements = np.empty(
            (
                self.protocol.n_excitations,
                self.protocol.n_measurements_per_excitation,
            ),
            dtype=float,
        )
        for excitation_index in range(self.protocol.n_excitations):
            pairs = self.protocol.measurement_pairs[excitation_index]
            measurements[excitation_index] = (
                electrode_potentials[pairs[:, 0], excitation_index]
                - electrode_potentials[pairs[:, 1], excitation_index]
            )
        return FenicsxCEMSolution(
            node_potentials=node_potentials,
            electrode_potentials=electrode_potentials,
            measurements=measurements.reshape(-1),
        )

    def compute_jacobian(
        self,
        conductivity: np.ndarray | float,
    ) -> np.ndarray:
        flattened_measurements = self.protocol.measurement_pairs.reshape(-1, 2)
        unique_measurement_pairs, measurement_pair_indices = np.unique(
            flattened_measurements,
            axis=0,
            return_inverse=True,
        )
        combined_pairs = np.vstack(
            [self.protocol.excitation_pairs, unique_measurement_pairs]
        )
        combined_amplitudes = np.concatenate(
            [
                np.full(
                    self.protocol.n_excitations,
                    self.current_amplitude,
                ),
                np.ones(unique_measurement_pairs.shape[0]),
            ]
        )
        node_potentials, _ = self.solve_pairs(
            conductivity,
            combined_pairs,
            amplitudes=combined_amplitudes,
        )

        excitation_potentials = node_potentials[
            :, : self.protocol.n_excitations
        ]
        adjoint_potentials = node_potentials[
            :, self.protocol.n_excitations :
        ]
        excitation_element_values = excitation_potentials[self.elements]
        adjoint_element_values = adjoint_potentials[self.elements]
        excitation_gradients = np.einsum(
            "eip,eid->epd",
            excitation_element_values,
            self.basis_gradients,
        )
        adjoint_gradients = np.einsum(
            "eip,eid->epd",
            adjoint_element_values,
            self.basis_gradients,
        )

        n_rows = (
            self.protocol.n_excitations
            * self.protocol.n_measurements_per_excitation
        )
        jacobian = np.empty((n_rows, self.elements.shape[0]), dtype=float)
        row_index = 0
        for excitation_index in range(self.protocol.n_excitations):
            for _ in range(self.protocol.n_measurements_per_excitation):
                adjoint_index = measurement_pair_indices[row_index]
                gradient_product = np.einsum(
                    "ed,ed->e",
                    excitation_gradients[:, excitation_index],
                    adjoint_gradients[:, adjoint_index],
                )
                jacobian[row_index] = -self.areas * gradient_product
                row_index += 1
        return jacobian


def reconstruct_tikhonov(
    jacobian: np.ndarray,
    difference_voltage: np.ndarray,
    lambda_reg: float,
    p: float = 0.5,
) -> np.ndarray:
    """NOSER/Kotre-style linearized difference reconstruction."""

    if lambda_reg <= 0.0:
        raise ValueError("lambda_reg must be positive")
    jacobian_matrix = np.asarray(jacobian, dtype=float)
    voltage_vector = np.asarray(difference_voltage, dtype=float)
    normal_matrix = jacobian_matrix.T @ jacobian_matrix
    diagonal = np.diag(normal_matrix)
    diagonal_floor = max(
        float(np.max(diagonal)) * 1e-12,
        np.finfo(float).eps,
    )
    regularizer = np.maximum(diagonal, diagonal_floor) ** p
    system = normal_matrix + lambda_reg * np.diag(regularizer)
    right_hand_side = jacobian_matrix.T @ voltage_vector
    return scipy.linalg.solve(
        system,
        right_hand_side,
        assume_a="pos",
        check_finite=False,
    )
