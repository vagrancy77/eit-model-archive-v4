from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.tri as mtri
import numpy as np
from scipy.io import loadmat
import torch


def parse_arguments() -> argparse.Namespace:
    project_root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(
        description="Reproduce the public GN4IP Conv U-Net inference baseline."
    )
    parser.add_argument(
        "--gn4ip-root",
        type=Path,
        default=project_root / "external" / "GN4IP",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=project_root / "outputs_gn4ip",
    )
    return parser.parse_args()


def correlations(truth: np.ndarray, prediction: np.ndarray) -> np.ndarray:
    truth_centered = truth - truth.mean(axis=1, keepdims=True)
    prediction_centered = prediction - prediction.mean(axis=1, keepdims=True)
    denominator = np.linalg.norm(truth_centered, axis=1) * np.linalg.norm(
        prediction_centered,
        axis=1,
    )
    return np.divide(
        np.sum(truth_centered * prediction_centered, axis=1),
        denominator,
        out=np.full(truth.shape[0], np.nan),
        where=denominator > 0.0,
    )


def relative_l2(truth: np.ndarray, prediction: np.ndarray) -> np.ndarray:
    return np.linalg.norm(truth - prediction, axis=1) / np.linalg.norm(
        truth,
        axis=1,
    )


def load_state_dict(path: Path) -> dict:
    try:
        return torch.load(path, map_location="cpu", weights_only=True)
    except TypeError:
        return torch.load(path, map_location="cpu")


def run_model(model, grid: torch.Tensor) -> np.ndarray:
    model.eval()
    with torch.no_grad():
        return model(grid).detach().cpu().numpy()[:, 0]


def grid_to_mesh(grid: np.ndarray, closest_pixels: np.ndarray) -> np.ndarray:
    flattened = grid.reshape(grid.shape[0], -1)
    return flattened[:, closest_pixels]


def save_figure(
    nodes: np.ndarray,
    elements: np.ndarray,
    truth: np.ndarray,
    input_reconstruction: np.ndarray,
    legacy_prediction: np.ndarray,
    strict_prediction: np.ndarray,
    output: Path,
) -> None:
    triangulation = mtri.Triangulation(
        nodes[:, 0],
        nodes[:, 1],
        elements,
    )
    n_examples = min(3, truth.shape[0])
    figure, axes = plt.subplots(
        n_examples,
        4,
        figsize=(14, 3.4 * n_examples),
        constrained_layout=True,
    )
    if n_examples == 1:
        axes = axes[None, :]
    for row in range(n_examples):
        fields = [
            truth[row],
            input_reconstruction[row],
            legacy_prediction[row],
            strict_prediction[row],
        ]
        titles = [
            "Ground truth Y",
            "3-step LM input X2",
            "GN4IP legacy inference",
            "GN4IP train-stat inference",
        ]
        vmin = float(np.min(np.concatenate(fields)))
        vmax = float(np.max(np.concatenate(fields)))
        for column, (field, title) in enumerate(zip(fields, titles, strict=True)):
            image = axes[row, column].tripcolor(
                triangulation,
                facecolors=field,
                shading="flat",
                cmap="viridis",
                vmin=vmin,
                vmax=vmax,
            )
            axes[row, column].set_title(f"Sample {row}: {title}")
            axes[row, column].set_aspect("equal")
            axes[row, column].set_axis_off()
            figure.colorbar(
                image,
                ax=axes[row, column],
                fraction=0.046,
                pad=0.04,
            )
    figure.savefig(output, dpi=180)
    plt.close(figure)


def main() -> None:
    arguments = parse_arguments()
    python_directory = arguments.gn4ip_root / "python"
    sys.path.insert(0, str(python_directory))
    from GN4IP import ConvUNet

    data_directory = arguments.gn4ip_root / "data"
    training = loadmat(data_directory / "training_data_v0.mat")
    testing = loadmat(data_directory / "test_data_v0.mat")
    training_output = loadmat(data_directory / "conv_unet_train_output.mat")
    author_output = loadmat(data_directory / "conv_unet_test_output_v0.mat")

    closest_elements = testing["closest_elements"].astype(np.int64).reshape(-1) - 1
    closest_pixels = testing["closest_pixels"].astype(np.int64).reshape(-1) - 1
    n_pixels = int(testing["n_pixels"].item())
    test_x2 = np.asarray(testing["X2"], dtype=np.float64)
    test_y = np.asarray(testing["Y"], dtype=np.float64)
    x_grid = torch.from_numpy(
        test_x2[:, closest_elements].reshape(-1, 1, n_pixels, n_pixels)
    )

    model = ConvUNet(
        dim=2,
        channels_in=1,
        channels=8,
        channels_out=1,
        convolutions=2,
        n_pooling_layers=4,
        kernel_size=3,
    )
    model.load_state_dict(load_state_dict(data_directory / "conv_unet_model.pt"))
    model.cpu()

    y_mean = float(training_output["y_mean"].item())
    y_std = float(training_output["y_std"].item())
    legacy_x_mean = float(x_grid.mean())
    legacy_x_std = float(x_grid.std())
    legacy_grid = run_model(
        model,
        (x_grid - legacy_x_mean) / legacy_x_std,
    ) * y_std + y_mean

    train_x_mean = float(training_output["x_mean"].item())
    train_x_std = float(training_output["x_std"].item())
    strict_grid = run_model(
        model,
        (x_grid - train_x_mean) / train_x_std,
    ) * y_std + y_mean
    author_grid = np.asarray(author_output["yhat"], dtype=np.float64)

    legacy_mesh = grid_to_mesh(legacy_grid, closest_pixels)
    strict_mesh = grid_to_mesh(strict_grid, closest_pixels)
    author_mesh = grid_to_mesh(author_grid, closest_pixels)
    baseline_correlation = correlations(test_y, test_x2)
    legacy_correlation = correlations(test_y, legacy_mesh)
    strict_correlation = correlations(test_y, strict_mesh)

    author_denominator = max(np.linalg.norm(author_grid), np.finfo(float).eps)
    author_relative_error = float(
        np.linalg.norm(legacy_grid - author_grid) / author_denominator
    )
    author_max_error = float(np.max(np.abs(legacy_grid - author_grid)))
    summary = {
        "source": "https://github.com/wherzberg/GN4IP",
        "source_commit": "0f744d41e87616b08bbaab9f7a8a48ef201d8c62",
        "license": "GPL-3.0",
        "torch_version": torch.__version__,
        "device": "cpu",
        "training_samples": int(training["X2"].shape[0]),
        "test_samples": int(test_x2.shape[0]),
        "reconstruction_elements": int(test_x2.shape[1]),
        "grid_shape": [n_pixels, n_pixels],
        "measurements_per_sample": int(testing["VSIM"].shape[1]),
        "author_output_reproduction": {
            "relative_l2_error": author_relative_error,
            "maximum_absolute_error": author_max_error,
        },
        "mean_metrics": {
            "three_step_lm_correlation": float(np.nanmean(baseline_correlation)),
            "legacy_unet_correlation": float(np.nanmean(legacy_correlation)),
            "train_stat_unet_correlation": float(np.nanmean(strict_correlation)),
            "three_step_lm_relative_l2": float(
                np.mean(relative_l2(test_y, test_x2))
            ),
            "legacy_unet_relative_l2": float(
                np.mean(relative_l2(test_y, legacy_mesh))
            ),
            "train_stat_unet_relative_l2": float(
                np.mean(relative_l2(test_y, strict_mesh))
            ),
        },
        "normalization": {
            "legacy": "test-set X mean/std, matching upstream predict script",
            "train_stat": "training-set X mean/std saved by upstream train script",
        },
    }

    arguments.output_dir.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        arguments.output_dir / "gn4ip_reproduction.npz",
        truth_mesh=test_y,
        lm_input_mesh=test_x2,
        author_grid=author_grid,
        legacy_grid=legacy_grid,
        train_stat_grid=strict_grid,
        author_mesh=author_mesh,
        legacy_mesh=legacy_mesh,
        train_stat_mesh=strict_mesh,
        baseline_correlation=baseline_correlation,
        legacy_correlation=legacy_correlation,
        train_stat_correlation=strict_correlation,
    )
    with (arguments.output_dir / "summary.json").open(
        "w",
        encoding="utf-8",
    ) as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)

    rec_model = testing["rec_fmdl"][0, 0]
    nodes = np.asarray(rec_model["nodes"], dtype=float)
    elements = np.asarray(rec_model["elems"], dtype=np.int64) - 1
    save_figure(
        nodes,
        elements,
        test_y,
        test_x2,
        legacy_mesh,
        strict_mesh,
        arguments.output_dir / "gn4ip_conv_unet_reproduction.png",
    )

    print("GN4IP Conv U-Net inference completed.")
    print(
        "  Author output relative/max error: "
        f"{author_relative_error:.3e} / {author_max_error:.3e}"
    )
    print(
        "  Mean correlation LM -> legacy U-Net -> train-stat U-Net: "
        f"{summary['mean_metrics']['three_step_lm_correlation']:.4f} -> "
        f"{summary['mean_metrics']['legacy_unet_correlation']:.4f} -> "
        f"{summary['mean_metrics']['train_stat_unet_correlation']:.4f}"
    )
    print(f"  Outputs: {arguments.output_dir.resolve()}")


if __name__ == "__main__":
    main()
