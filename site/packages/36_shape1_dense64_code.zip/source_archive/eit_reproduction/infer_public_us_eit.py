from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from torch.nn import functional as F

from pytorch_eit.models import MultiModalEITNet


def parse_metadata(value: np.ndarray) -> list[dict[str, object]]:
    return json.loads(str(value.item()))


def correlation(prediction: np.ndarray, target: np.ndarray, mask: np.ndarray) -> float:
    p = prediction[:, mask]
    t = target[:, mask]
    p = p - p.mean(axis=1, keepdims=True)
    t = t - t.mean(axis=1, keepdims=True)
    denominator = np.linalg.norm(p, axis=1) * np.linalg.norm(t, axis=1)
    values = np.divide(np.sum(p * t, axis=1), denominator, out=np.zeros_like(denominator), where=denominator > 1e-8)
    return float(np.mean(values))


def main() -> None:
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Run the trained PyTorch fusion model on the public real US-EIT dataset.")
    parser.add_argument("--data", type=Path, default=root / "datasets" / "public_us_eit" / "public_us_eit_v1.npz")
    parser.add_argument("--checkpoint", type=Path, default=root / "outputs_pytorch_multimodal" / "model.pt")
    parser.add_argument("--output-dir", type=Path, default=root / "outputs_public_us_eit")
    parser.add_argument("--cpu", action="store_true")
    args = parser.parse_args()
    device = torch.device("cpu" if args.cpu or not torch.cuda.is_available() else "cuda")
    checkpoint = torch.load(args.checkpoint, map_location=device, weights_only=False)
    model = MultiModalEITNet(voltage_dim=int(checkpoint["voltage_dim"]), base_channels=int(checkpoint["base_channels"])).to(device)
    model.load_state_dict(checkpoint["model_state"])
    model.eval()
    data = np.load(args.data, allow_pickle=True)
    metadata = parse_metadata(data["metadata_json"])
    voltage_complex = np.asarray(data["voltage_features"], dtype=np.float32)
    voltage_real = voltage_complex[:, :208]
    voltage_imag = voltage_complex[:, 208:]
    voltage = np.sqrt(voltage_real * voltage_real + voltage_imag * voltage_imag)
    voltage = np.asarray([row / max(float(item["voltage_vpp"]), 1.0) for row, item in zip(voltage, metadata, strict=True)], dtype=np.float32)
    voltage = (voltage - np.asarray(checkpoint["voltage_mean"], dtype=np.float32)) / np.asarray(checkpoint["voltage_std"], dtype=np.float32)
    baseline = torch.from_numpy(np.asarray(data["baseline_tikhonov"], dtype=np.float32)[:, None])
    pseudo_target = torch.from_numpy(np.asarray(data["pseudo_target_gn"], dtype=np.float32)[:, None])
    ultrasound = torch.from_numpy(np.asarray(data["ultrasound"], dtype=np.float32))
    baseline = F.interpolate(baseline, size=(64, 64), mode="bilinear", align_corners=False)
    pseudo_target = F.interpolate(pseudo_target, size=(64, 64), mode="bilinear", align_corners=False)
    voltage_tensor = torch.from_numpy(voltage)
    availability = torch.ones((baseline.shape[0], 1), dtype=torch.float32)
    with torch.no_grad():
        output = model(baseline.to(device), voltage_tensor.to(device), ultrasound.to(device), availability.to(device))["reconstruction"].cpu().numpy()[:, 0]
        eit_only = model(baseline.to(device), voltage_tensor.to(device), ultrasound.to(device), torch.zeros_like(availability).to(device))["reconstruction"].cpu().numpy()[:, 0]
    target = pseudo_target.numpy()[:, 0]
    yy, xx = np.mgrid[0:64, 0:64]
    mask = (xx - 31.5) ** 2 + (yy - 31.5) ** 2 <= 30.0 ** 2
    summary = {
        "source": str(args.data.resolve()),
        "checkpoint": str(args.checkpoint.resolve()),
        "warning": "pseudo_target_gn is the public author's GN reconstruction; this is domain-adaptation evidence, not a ground-truth clinical score",
        "fusion_correlation_to_public_gn": correlation(output, target, mask),
        "eit_only_correlation_to_public_gn": correlation(eit_only, target, mask),
        "samples": len(metadata),
        "device": str(device),
    }
    args.output_dir.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(args.output_dir / "predictions.npz", prediction=output, eit_only=eit_only, baseline=baseline.numpy()[:, 0], pseudo_target=target, ultrasound=ultrasound.numpy()[:, 0])
    with (args.output_dir / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    count = min(4, output.shape[0])
    figure, axes = plt.subplots(count, 4, figsize=(12, 3 * count))
    axes = np.atleast_2d(axes)
    for row in range(count):
        fields = [target[row], baseline.numpy()[row, 0], output[row], ultrasound.numpy()[row, 0]]
        titles = ["public GN (pseudo-label)", "Tikhonov baseline", "PyTorch fusion", "shared ultrasound"]
        for column, (field, title) in enumerate(zip(fields, titles, strict=True)):
            axes[row, column].imshow(field, cmap="gray" if column == 3 else "viridis")
            axes[row, column].set_title(f"{metadata[row]['sample']}\n{title}", fontsize=8)
            axes[row, column].axis("off")
    figure.tight_layout()
    figure.savefig(args.output_dir / "examples.png", dpi=160)
    plt.close(figure)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

