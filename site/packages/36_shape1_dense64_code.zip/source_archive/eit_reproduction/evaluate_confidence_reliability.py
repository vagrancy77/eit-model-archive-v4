from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader

PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

from pytorch_eit.data import MultimodalCEMDataset
from pytorch_eit.models import RegistrationRobustMultiModalEITNet
from train_registration_robust_multimodal import corrupt_ultrasound


CONDITIONS = ("clean", "shift10px", "rotate10deg", "blur_sigma4", "false_positive")
CONDITION_SEVERITY = {
    "clean": 0,
    "blur_sigma4": 1,
    "false_positive": 1,
    "rotate10deg": 1,
    "shift10px": 1,
}


def masked_metrics(prediction: torch.Tensor, target: torch.Tensor, mask: torch.Tensor) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    prediction = prediction[:, 0] * mask
    target = target[:, 0] * mask
    p = prediction.flatten(1) - prediction.flatten(1).mean(1, keepdim=True)
    t = target.flatten(1) - target.flatten(1).mean(1, keepdim=True)
    corr = (p * t).sum(1) / (
        torch.linalg.vector_norm(p, dim=1) * torch.linalg.vector_norm(t, dim=1)
    ).clamp_min(1e-6)
    rel_l2 = torch.linalg.vector_norm((prediction - target).flatten(1), dim=1) / torch.linalg.vector_norm(
        target.flatten(1), dim=1
    ).clamp_min(1e-6)
    mae = torch.abs(prediction - target).sum(dim=(1, 2)) / mask.sum().clamp_min(1.0)
    return corr.cpu().numpy(), rel_l2.cpu().numpy(), mae.cpu().numpy()


def pearson(x: np.ndarray, y: np.ndarray) -> float:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    if x.size < 2 or np.std(x) < 1e-12 or np.std(y) < 1e-12:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def auc_score(labels: np.ndarray, scores: np.ndarray) -> float:
    labels = np.asarray(labels, dtype=np.int64)
    scores = np.asarray(scores, dtype=float)
    positive = labels == 1
    negative = labels == 0
    n_pos = int(positive.sum())
    n_neg = int(negative.sum())
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    order = np.argsort(scores)
    ranks = np.empty_like(order, dtype=float)
    sorted_scores = scores[order]
    i = 0
    while i < len(scores):
        j = i + 1
        while j < len(scores) and sorted_scores[j] == sorted_scores[i]:
            j += 1
        average_rank = (i + 1 + j) / 2.0
        ranks[order[i:j]] = average_rank
        i = j
    rank_sum_pos = float(ranks[positive].sum())
    return (rank_sum_pos - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg)


def selective_curve(confidence: np.ndarray, errors: np.ndarray, points: int = 20) -> tuple[np.ndarray, np.ndarray]:
    confidence = np.asarray(confidence, dtype=float)
    errors = np.asarray(errors, dtype=float)
    order = np.argsort(-confidence)
    sorted_errors = errors[order]
    coverages = np.linspace(0.05, 1.0, points)
    risks = []
    for coverage in coverages:
        keep = max(1, int(math.ceil(coverage * len(sorted_errors))))
        risks.append(float(np.mean(sorted_errors[:keep])))
    return coverages, np.asarray(risks, dtype=float)


def expected_calibration_error(confidence: np.ndarray, errors: np.ndarray, bins: int = 10) -> float:
    confidence = np.asarray(confidence, dtype=float)
    errors = np.asarray(errors, dtype=float)
    if len(confidence) == 0:
        return float("nan")
    # Convert MAE into an empirical quality score in [0, 1], so that higher is better like confidence.
    low = np.percentile(errors, 5)
    high = np.percentile(errors, 95)
    quality = 1.0 - np.clip((errors - low) / max(high - low, 1e-8), 0.0, 1.0)
    edges = np.linspace(0.0, 1.0, bins + 1)
    ece = 0.0
    for left, right in zip(edges[:-1], edges[1:], strict=True):
        in_bin = (confidence >= left) & (confidence < right if right < 1.0 else confidence <= right)
        if not np.any(in_bin):
            continue
        ece += float(in_bin.mean()) * abs(float(confidence[in_bin].mean()) - float(quality[in_bin].mean()))
    return float(ece)


def collect_records(args: argparse.Namespace) -> tuple[list[dict[str, float | int | str]], dict[str, object]]:
    device = torch.device("cpu" if args.cpu or not torch.cuda.is_available() else "cuda")
    data = np.load(args.data)
    train_voltage = np.asarray(data["voltage_features"], dtype=np.float32)[data["train_indices"]]
    voltage_mean = train_voltage.mean(0)
    voltage_std = np.maximum(train_voltage.std(0), np.median(train_voltage.std(0)) * 1e-3 + 1e-6)
    dataset = MultimodalCEMDataset(args.data, args.split, modality_dropout=0.0)
    dataset.voltages = (dataset.voltages - voltage_mean) / voltage_std
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=0)

    checkpoint = torch.load(args.checkpoint, map_location=device, weights_only=False)
    model = RegistrationRobustMultiModalEITNet(
        voltage_dim=dataset.voltages.shape[1],
        base_channels=int(checkpoint["base_channels"]),
    ).to(device)
    model.load_state_dict(checkpoint["model_state"], strict=False)
    model.eval()

    mask = torch.from_numpy(np.asarray(data["mask"], dtype=np.float32)).to(device)
    records: list[dict[str, float | int | str]] = []
    with torch.no_grad():
        sample_offset = 0
        for batch in loader:
            batch = {key: value.to(device=device, dtype=torch.float32) for key, value in batch.items()}
            batch_size = int(batch["target"].shape[0])
            for condition in CONDITIONS:
                ultrasound = corrupt_ultrasound(batch["ultrasound"], condition)
                output = model(batch["eit_image"], batch["voltages"], ultrasound, torch.ones_like(batch["ultrasound_available"]))
                corr, rel_l2, mae = masked_metrics(output["reconstruction"], batch["target"], mask)
                confidence = (output["confidence_map"][:, 0] * mask).flatten(1).sum(1) / mask.sum().clamp_min(1.0)
                conf_np = confidence.cpu().numpy()
                theta = output["registration_theta"].detach().cpu().numpy()
                for local_index in range(batch_size):
                    records.append(
                        {
                            "sample_index": sample_offset + local_index,
                            "condition": condition,
                            "is_corrupted_prior": CONDITION_SEVERITY[condition],
                            "confidence": float(conf_np[local_index]),
                            "correlation": float(corr[local_index]),
                            "relative_l2": float(rel_l2[local_index]),
                            "mae": float(mae[local_index]),
                            "theta_tx": float(theta[local_index, 0, 2]),
                            "theta_ty": float(theta[local_index, 1, 2]),
                            "theta_a00": float(theta[local_index, 0, 0]),
                            "theta_a01": float(theta[local_index, 0, 1]),
                            "theta_a10": float(theta[local_index, 1, 0]),
                            "theta_a11": float(theta[local_index, 1, 1]),
                        }
                    )
            sample_offset += batch_size

    meta = {"data": str(args.data.resolve()), "checkpoint": str(args.checkpoint.resolve()), "split": args.split, "device": str(device)}
    return records, meta


def summarize(records: list[dict[str, float | int | str]]) -> dict[str, object]:
    confidence = np.asarray([float(row["confidence"]) for row in records], dtype=float)
    mae = np.asarray([float(row["mae"]) for row in records], dtype=float)
    rel_l2 = np.asarray([float(row["relative_l2"]) for row in records], dtype=float)
    corrupted = np.asarray([int(row["is_corrupted_prior"]) for row in records], dtype=np.int64)
    conditions = sorted({str(row["condition"]) for row in records}, key=CONDITIONS.index)
    by_condition: dict[str, dict[str, float]] = {}
    for condition in conditions:
        idx = np.asarray([str(row["condition"]) == condition for row in records], dtype=bool)
        by_condition[condition] = {
            "n": int(idx.sum()),
            "mean_confidence": float(confidence[idx].mean()),
            "mean_mae": float(mae[idx].mean()),
            "mean_relative_l2": float(rel_l2[idx].mean()),
        }
    coverages, risks = selective_curve(confidence, mae)
    return {
        "samples_total": len(records),
        "condition_summary": by_condition,
        "confidence_corruption_auc": auc_score(1 - corrupted, confidence),
        "confidence_vs_mae_pearson": pearson(confidence, mae),
        "confidence_vs_relative_l2_pearson": pearson(confidence, rel_l2),
        "mae_ece_like": expected_calibration_error(confidence, mae),
        "selective_mae": {
            "coverage": [float(x) for x in coverages],
            "mae": [float(x) for x in risks],
            "mae_at_25pct": float(risks[np.argmin(np.abs(coverages - 0.25))]),
            "mae_at_50pct": float(risks[np.argmin(np.abs(coverages - 0.50))]),
            "mae_at_75pct": float(risks[np.argmin(np.abs(coverages - 0.75))]),
            "mae_at_100pct": float(risks[-1]),
        },
        "interpretation_warning": "Confidence is learned indirectly from reconstruction training; clean/corrupted labels are synthetic prior-corruption labels, not clinical uncertainty labels.",
    }


def write_csv(records: list[dict[str, float | int | str]], path: Path) -> None:
    fieldnames = list(records[0].keys())
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(records)


def plot_outputs(records: list[dict[str, float | int | str]], summary: dict[str, object], output_dir: Path) -> None:
    confidence = np.asarray([float(row["confidence"]) for row in records], dtype=float)
    mae = np.asarray([float(row["mae"]) for row in records], dtype=float)
    conditions = np.asarray([str(row["condition"]) for row in records], dtype=object)
    selective = summary["selective_mae"]
    figure, axes = plt.subplots(1, 3, figsize=(15, 4.5), constrained_layout=True)
    positions = np.arange(len(CONDITIONS))
    values = [confidence[conditions == c] for c in CONDITIONS]
    axes[0].boxplot(values, tick_labels=CONDITIONS, showfliers=False)
    axes[0].set_title("Confidence by prior condition")
    axes[0].set_ylabel("Mean spatial confidence")
    axes[0].tick_params(axis="x", rotation=28)

    rng = np.random.default_rng(20260803)
    keep = rng.choice(len(confidence), size=min(len(confidence), 1200), replace=False)
    axes[1].scatter(confidence[keep], mae[keep], s=7, alpha=0.28)
    axes[1].set_title("Confidence vs reconstruction MAE")
    axes[1].set_xlabel("Mean spatial confidence")
    axes[1].set_ylabel("MAE")

    axes[2].plot(selective["coverage"], selective["mae"], marker="o")
    axes[2].axhline(selective["mae_at_100pct"], color="0.5", linestyle="--", linewidth=1)
    axes[2].set_title("Risk-coverage curve")
    axes[2].set_xlabel("Kept fraction, high confidence first")
    axes[2].set_ylabel("Selective MAE")
    axes[2].grid(alpha=0.25)
    figure.savefig(output_dir / "confidence_reliability.png", dpi=180)
    plt.close(figure)

    condition_means = [float(np.mean(mae[conditions == c])) for c in CONDITIONS]
    condition_conf = [float(np.mean(confidence[conditions == c])) for c in CONDITIONS]
    figure, ax1 = plt.subplots(figsize=(8, 4.8), constrained_layout=True)
    ax1.bar(positions - 0.18, condition_means, width=0.36, color="tab:orange", label="MAE")
    ax1.set_ylabel("MAE")
    ax2 = ax1.twinx()
    ax2.bar(positions + 0.18, condition_conf, width=0.36, color="tab:blue", alpha=0.75, label="confidence")
    ax2.set_ylabel("Mean confidence")
    ax1.set_xticks(positions, CONDITIONS, rotation=25, ha="right")
    ax1.set_title("Condition-level confidence and error")
    handles1, labels1 = ax1.get_legend_handles_labels()
    handles2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(handles1 + handles2, labels1 + labels2, loc="upper right")
    figure.savefig(output_dir / "condition_confidence_error.png", dpi=180)
    plt.close(figure)


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate learned confidence reliability for the robust US-EIT model.")
    parser.add_argument("--data", type=Path, default=PROJECT_ROOT / "datasets" / "multimodal_cem_v2.npz")
    parser.add_argument("--checkpoint", type=Path, default=PROJECT_ROOT / "outputs_registration_robust_multimodal_warmstart" / "model.pt")
    parser.add_argument("--output-dir", type=Path, default=PROJECT_ROOT / "outputs_confidence_reliability")
    parser.add_argument("--split", choices=("train", "validation", "test"), default="test")
    parser.add_argument("--batch-size", type=int, default=48)
    parser.add_argument("--cpu", action="store_true")
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    records, meta = collect_records(args)
    summary = summarize(records)
    summary.update(meta)
    write_csv(records, args.output_dir / "per_sample_confidence_metrics.csv")
    (args.output_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    plot_outputs(records, summary, args.output_dir)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
