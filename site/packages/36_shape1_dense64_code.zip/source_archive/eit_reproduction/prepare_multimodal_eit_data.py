from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from pytorch_eit.data import mesh_to_grid, render_ultrasound_proxy


def main() -> None:
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Prepare grid and proxy-US data for the PyTorch multimodal EIT model.")
    parser.add_argument("--input", type=Path, default=root / "datasets" / "synthetic_cem_v1.npz")
    parser.add_argument("--output", type=Path, default=root / "datasets" / "multimodal_cem_v1.npz")
    parser.add_argument("--pixels", type=int, default=64)
    args = parser.parse_args()

    data = np.load(args.input)
    target_grid, mask, closest_pixels = mesh_to_grid(
        data["inverse_nodes"], data["inverse_elements"], data["conductivity_inverse"], args.pixels
    )
    baseline_mesh = 1.0 + np.asarray(data["linear_reconstructions"], dtype=np.float32)
    baseline_grid, _, _ = mesh_to_grid(
        data["inverse_nodes"], data["inverse_elements"], baseline_mesh, args.pixels
    )
    target_grid[:, mask == 0] = 1.0
    baseline_grid[:, mask == 0] = 1.0
    target_grid = np.clip(target_grid, 0.05, 2.95)
    baseline_grid = np.clip(baseline_grid, 0.05, 2.95)
    ultrasound_grid = render_ultrasound_proxy(target_grid, mask, seed=20260717)
    segmentation = ((np.abs(target_grid - 1.0) > 0.06) * mask[None]).astype(np.float32)
    voltage_scale = float(np.asarray(data["voltage_scale"]).reshape(()))
    voltage_features = np.asarray(data["voltage_differences"], dtype=np.float32) / max(voltage_scale, 1e-6)
    jacobian_scaled = np.asarray(data["jacobian"], dtype=np.float32) / max(voltage_scale, 1e-6)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        args.output,
        baseline_grid=baseline_grid.astype(np.float32),
        target_grid=target_grid.astype(np.float32),
        ultrasound_grid=ultrasound_grid.astype(np.float32),
        segmentation_grid=segmentation,
        mask=mask.astype(np.float32),
        voltage_features=voltage_features,
        jacobian_scaled=jacobian_scaled,
        closest_pixels=closest_pixels.astype(np.int64),
        train_indices=np.asarray(data["train_indices"], dtype=np.int64),
        validation_indices=np.asarray(data["validation_indices"], dtype=np.int64),
        test_indices=np.asarray(data["test_indices"], dtype=np.int64),
        target_mesh=np.asarray(data["conductivity_inverse"], dtype=np.float32),
        baseline_mesh=baseline_mesh,
    )
    metadata = {
        "source": str(args.input.resolve()),
        "output": str(args.output.resolve()),
        "samples": int(target_grid.shape[0]),
        "pixels": [args.pixels, args.pixels],
        "measurements": int(voltage_features.shape[1]),
        "ultrasound": "geometry-consistent synthetic B-mode proxy; not a physical acoustic simulation",
        "ground_truth": "CEM nonlinear conductivity on the inverse mesh",
        "data_consistency": "jacobian_scaled maps inverse-mesh conductivity changes to normalized voltage differences",
    }
    with args.output.with_suffix(".json").open("w", encoding="utf-8") as handle:
        json.dump(metadata, handle, ensure_ascii=False, indent=2)
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

