# 完整二维 CEM-EIT 复现工程

本工程已经形成从有限元正问题到神经网络重建的完整、可验证软件闭环：

```text
双网格与电导率真值
        ↓
完整电极模型（SciPy / FEniCSX）
        ↓
208 路边界电压与噪声
        ↓
线性差分 EIT ──→ 非线性绝对 EIT
        ↓                 ↓
批量非线性 CEM 数据集   Gauss–Newton + TV
        ↓
物理重建 + 残差 MLP
        ↓
独立测试、单帧推理与真实数据接口
```

工程使用正问题细网格和逆问题粗网格，避免 inverse crime。所有算法都保存数值数组、参数、评价指标和图片，并由自动校验脚本检查。

## 当前已验证结果

| 模块 | 结果 |
|---|---:|
| 电极协议 | 16 次激励 × 13 次测量 = 208 |
| 逆问题 Jacobian | 208 × 560 |
| SciPy/FEniCSX 背景电压相对误差 | `1.509 × 10^-14` |
| SciPy/FEniCSX Jacobian 相对误差 | `1.182 × 10^-14` |
| 线性心肺重建相关系数 | `0.8106` |
| 非线性 Gauss–Newton + TV 相关系数 | `0.8733` |
| 非线性最终电压相对误差 | `0.268%` |
| 非线性正值约束 | 满足，电导率范围约 `0.185–1.322` |
| 神经网络独立测试集样本 | 153 |
| 测试集平均相关系数：线性 → 神经网络 | `0.6756 → 0.7366` |
| 测试集平均相对 L2：线性 → 神经网络 | `0.7440 → 0.6764` |
| 神经网络改善相关系数的测试样本占比 | `86.9%` |
| 心肺样本相关系数：线性 → 神经网络 | `0.8106 → 0.8662` |
| GN4IP公开测试集：3步LM → Conv U-Net | `0.5130 → 0.9139` |
| GN4IP作者预测复现相对误差 | `6.25 × 10^-16` |
| 当前CEM数据：线性 → GN4IP Conv U-Net | `0.6756 → 0.7985` |

## 环境

Windows 基础环境：

```powershell
cd E:\Codex\eit_reproduction
python -m pip install -r requirements.txt
```

FEniCSX 使用 WSL/Ubuntu。已有环境可以直接使用；重新创建环境时可参考：

```bash
conda env create -f /mnt/e/Codex/eit_reproduction/environment-fenicsx.yml
conda activate fenicsx-env
```

GN4IP Conv U-Net 使用独立的 WSL 环境：

```bash
conda env create -f /mnt/e/Codex/eit_reproduction/environment-gn4ip.yml
conda activate gn4ip-env
```

## 一键运行

完整正式流程：

```powershell
cd E:\Codex\eit_reproduction
python run_complete_pipeline.py
```

快速冒烟测试：

```powershell
python run_complete_pipeline.py --quick
```

总控脚本依次运行线性 CEM、非线性绝对 EIT、数据集生成、神经网络训练、单帧推理、单元测试和制品校验，并生成 `outputs_complete/manifest.json` 和 SHA-256。

FEniCSX 后端在 WSL 中单独运行：

```bash
conda activate fenicsx-env
cd /mnt/e/Codex/eit_reproduction
python scripts/check_fenicsx_environment.py
python run_fenicsx_cem.py
python -m unittest tests.test_fenicsx_backend -v
```

## 分阶段运行

### 1. 线性差分 CEM-EIT

```powershell
python run_basic_eit.py --model cem
```

流程包括有限宽度电极、接触阻抗、60 dB 噪声、互易伴随 Jacobian 和 NOSER/Kotre 风格 Tikhonov 重建。

点电极对照：

```powershell
python run_basic_eit.py --model point
```

### 2. FEniCSX-CEM 验证

```bash
python run_fenicsx_cem.py
```

FEniCSX 后端通过 UFL/DOLFINx 装配区域刚度和电极 Robin 项，并与手工 SciPy CEM 逐项比较。输出位于 `outputs_fenicsx/`。

### 3. 非线性绝对 EIT

```powershell
python run_nonlinear_eit.py
```

已实现：

- 每次迭代重新求解非线性 CEM；
- 互易伴随 Jacobian；
- 对数电导率参数化和上下界，严格保证正值；
- Gauss–Newton / Levenberg–Marquardt；
- 网格对偶图上的平滑 TV；
- TV-IRLS/lagged diffusivity；
- 非线性目标回溯线搜索；
- 阻尼重试、自动停止和完整迭代历史。

默认参数已经针对当前心肺例子做过小规模确定性调优。输出位于 `outputs_nonlinear/`。

### 4. 生成神经网络数据集

```powershell
python generate_eit_dataset.py
```

默认生成 1024 个样本：

- 每个样本包含 1–4 个随机椭圆异常；
- 电导率包含低导和高导异常；
- 正问题使用 2821 单元细网格非线性 CEM；
- 标签使用独立的 560 单元逆网格；
- SNR 在 35–60 dB 随机变化；
- 保存干净/含噪电压、真值、线性重建、形状参数和固定划分；
- 训练/验证/测试为 717/154/153。

数据集位于 `datasets/synthetic_cem_v1.npz`，生成参数位于同名 JSON 文件。

### 5. 训练神经网络

```powershell
python train_neural_eit.py
```

当前基线是 NumPy 实现的残差 MLP：

```text
208 路电压
  → 物理 Tikhonov 重建（560 单元）
  → 128 隐藏单元 MLP
  → 学习电导率修正量
```

该方案不依赖 PyTorch，兼容当前 Python 3.14 环境。模型包含输入/输出归一化、Adam、权重衰减、验证集早停和正值裁剪。模型位于 `models/residual_mlp_v1.npz`。

### 6. 公开 GN4IP Conv U-Net 复现

公开来源、数据字段、许可证和候选项目对比见 [PUBLIC_NEURAL_EIT.md](PUBLIC_NEURAL_EIT.md)。

在 WSL `gn4ip-env` 中：

```bash
cd /mnt/e/Codex/eit_reproduction

# 复现作者预训练权重和保存的测试输出
python reproduce_gn4ip.py

# 验证公开训练代码的反向传播链路
python train_gn4ip_short.py --epochs 3

# 把当前1024例CEM数据转成GN4IP格式
python adapt_cem_to_gn4ip.py

# 用公开Conv U-Net训练当前CEM数据
python train_gn4ip_on_cem.py --epochs 20

python scripts/validate_gn4ip_reproduction.py
```

GN4IP仓库固定在提交 `0f744d41e87616b08bbaab9f7a8a48ef201d8c62`。本工程保留GPL-3.0许可证，并只对无条件 `torch_geometric` 导入做了卷积模型兼容修改。

### 7. 单帧和真实测量接口

对现有 CSV 运行推理：

```powershell
python predict_neural_eit.py outputs\voltages.csv --csv-column noisy
```

支持 `.csv`、`.npy` 和 `.npz`。真实数据需要提供 208 个测量值，并使用与训练数据相同的：

- 电极顺序；
- 激励与测量协议；
- 电流幅值；
- 几何尺寸和电极位置；
- 背景参考帧。

示例：

```powershell
python predict_neural_eit.py measurement.csv `
  --csv-column voltage `
  --background background.csv `
  --background-csv-column voltage
```

真实设备不满足上述标定条件时，必须重新生成匹配的网格/协议并用设备数据微调，不能直接把当前模型当作临床模型。

## 自动测试和工程校验

```powershell
python -m unittest discover -s tests -v
python scripts\validate_complete_project.py
python scripts\validate_gn4ip_reproduction.py
```

当前 Windows 环境执行 13 项测试通过，2 项 FEniCSX 测试因解释器中没有 DOLFINx 而跳过；这 2 项已在 WSL DOLFINx 0.10.0 中单独通过。

校验脚本检查：

- 208 路数据和 208×560 Jacobian；
- FEniCSX/SciPy 后端一致性；
- 非线性目标单调下降和正值约束；
- 训练/验证/测试划分完整；
- 所有数据有限且形状正确；
- 非线性方法优于线性基线；
- 神经网络在独立测试集上同时改善相关系数和相对 L2。

## 主要目录

```text
eit_basic/                 SciPy CEM、噪声、幻影、非线性、数据与神经网络
fenicsx_backend/           DOLFINx/UFL CEM 后端
tests/                     数值、算法、数据和模型测试
scripts/                   环境检查与完整制品校验
external/GN4IP/            固定提交的公开GPL-3.0代码、数据和权重
outputs/                   线性 CEM 输出
outputs_fenicsx/           FEniCSX 验证输出
outputs_nonlinear/         非线性绝对 EIT 输出
datasets/                  1024 样本 CEM 数据集
models/                    训练好的残差 MLP
outputs_neural/            测试集和单帧推理结果
outputs_gn4ip/             公开预训练复现、短训练和当前CEM训练结果
outputs_complete/          完整工程清单和哈希
```

数学细节见 [CEM_NOTES.md](CEM_NOTES.md)，公开项目调研见 [PUBLIC_NEURAL_EIT.md](PUBLIC_NEURAL_EIT.md)，交付状态和边界见 [PROJECT_STATUS.md](PROJECT_STATUS.md)。
## 公开真实数据与复杂 PyTorch 多模态网络

本工程现在包含公开真实 US-EIT 数据、数据解析器以及一个约 693 万参数的 PyTorch 双分支融合网络。完整的数据来源、许可证、限制和实验结果见 [DATASETS_AND_MULTIMODAL.md](DATASETS_AND_MULTIMODAL.md)。

在 Windows 科学 Python 环境中准备数据：

```powershell
E:\anaconda\python.exe prepare_multimodal_eit_data.py
E:\anaconda\python.exe prepare_public_us_eit.py
```

在 WSL 的 `gn4ip-env` 中训练和测试：

```bash
cd /mnt/e/Codex/eit_reproduction
python train_pytorch_multimodal_eit.py --epochs 20 --batch-size 32 --output-dir outputs_pytorch_multimodal
python infer_public_us_eit.py
python scripts/validate_pytorch_multimodal.py
python -m unittest discover -s tests -p 'test_pytorch_multimodal.py' -v
```

需要新建环境时可参考 `environment-pytorch-multimodal.yml`；已有 `gn4ip-env`（只要其中的 PyTorch 能看到 CUDA）也可直接运行。

训练数据是 CEM 电导率 phantom 加几何一致的超声代理图；真实 Zenodo 数据只用于域适配和方法验证，因为它只有一张共享超声图，且作者 GN 图不是独立真值。网络支持缺失超声模态，后续拿到同步 US-EIT 数据后可直接替换 `ultrasound_grid`。

## Edinburgh 四频 mfEIT 真值实验

已下载并接入 Edinburgh mfEIT Dataset（DOI `10.7488/ds/3464`，CC BY 4.0）：12,414 个四频 COMSOL phantom，同时提供 `4 × 104` 电压和 `4 × 64 × 64` 电导率变化真值。全部样本均验证为跨频共享病灶位置/尺寸、保留频率相关对比度。

当前三随机种子、2048 个分层训练样本 pilot 表明，共享几何分解模型相对普通联合多频模型将 Dice 从 0.585 提高到 0.647、质心误差从 3.00 像素降到 2.48 像素、背景假阳性降低 22.6%；但病灶内部对比度 MAE 变差 5.3%。因此共享几何是有效结构先验，下一步需要增加病灶级频谱校准分支。数据限制、运行命令、完整指标和下一步见 [EDINBURGH_MFEIT_EXPERIMENT.md](EDINBURGH_MFEIT_EXPERIMENT.md)。
