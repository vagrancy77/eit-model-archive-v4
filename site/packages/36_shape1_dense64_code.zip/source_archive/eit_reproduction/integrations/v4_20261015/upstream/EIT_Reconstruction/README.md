# v4/v6 EIT 重建训练工程

按项目根目录《模型.pdf》的结构描述重新实现，使用本次已验收的 3872 例 ADJACENT32 双频数据。PDF 链接的旧源码、旧权重、KTC 数据和 ABC2 结果在本机不存在；本工程不宣称恢复旧模型、参数量或论文指标。

## 开始和监控

本机专用 Python：D:\EIT_training_runtime\venv\Scripts\python.exe。
依赖及其实际安装版本记录于 requirements.txt 和 requirements.lock.txt；CUDA GPU 与真实 BF16 参数更新检查见 gpu_runtime_check.json。
正式工程位于 E:\EIT论文组\癌症\EIT_Reconstruction。
后台训练通过“启动训练.ps1”启动，窗口隐藏，日志和模型写入 runs\seed_20260911。
“监控训练.ps1”每两秒刷新；Ctrl+C 仅关闭监控，不停止训练。
也可双击项目根目录上一级的“打开训练监控.cmd”。监控同时提供文字进度条，训练完成后自动显示三阶段训练历史、验证指标和隔离测试集结果；读取失败时显示原因和路径，不再把完成后缺失的实时字段显示为 0/0。
“暂停训练.ps1”请求在完成当前批次后保存断点；再次运行“启动训练.ps1”删除暂停请求并续训。

CLI：

    python run_model.py verify
    python run_model.py self-test --device cuda
    python run_model.py prepare
    python run_model.py train --seeds 20260911 --device cuda
    python run_model.py evaluate --seeds 20260911 --device cuda
    python run_model.py infer-four --seeds 20260911 --device cuda

所有 CLI 需使用上述专用 Python。verify 验证工程清单中的静态源码、配置和说明；训练产生的动态文件另由阶段完成报告记录。配置变化需要主动重新生成清单，并使用与配置匹配的新算子/缓存。

## 数据、输入和真值

规范划分 train 2720、val 576、test 576，按位置隔离。val 内进一步按位置分出模型选择 288 例、门控校准 288 例；校准部分不用于任何网络权重拟合或模型选择，test 只在训练结束后评估。

每例原始电压和独立背景为 complex128 [频率2,驱动32,测量32]。频率为 10/50 kHz；驱动 d 正极为 d、负极为 d+1 循环。电压已相对该负极重参考，负极行恰为零。CNN 的电压输入为 float32 [实部10k,虚部10k,实部50k,虚部50k] × 测量32 × 驱动32；采用背景差值、固定参考电压尺度及只在 train 拟合的逐元素均值/标准差。没有将该数据伪装为旧 76×31 KTC 协议。

图像输入为 float32 [7,64,64]：
归一化线性图、3×3 平滑、7×7 平滑、Sobel x、Sobel y、梯度幅值、FOV。
线性图在 FOV 内减中位数、除绝对值 0.985 分位数，并截断到 [-5,5]。

监督标签：mask/cutout/mouth 为 [1,64,64] 浮点二值图；class 为 [64,64] 整数 0背景/1低电导率/2高电导率；SDF 为 [1,64,64]，外正内负、单位为像素距离/64；Δσ 与 Δεr 为 [2,64,64]，分别以 0.2 S/m 和 50000 归一化，FOV 外为零。这些标签不进入网络输入、v6 的 15 通道或风险统计。内部 FEM 电势场完全不被数据加载器读取。

## 线性重建和物理算子

生产算子采用同一已验证生成器的 COMSOL 均匀背景参考，而不是另一个离散模型。按 Fat/Muscle 和 10/50 kHz 导出全部32驱动的背景场，再由正向/伴随场梯度内积构建复 Jacobian。参考代表病例 A_000001、A_000055 均来自 train；材料在参考模型内统一为背景，不存在病灶电学对比。病例内部 FEM 场不读取，均匀参考场仅用于算子，不成为神经网络图像输入。

在 COMSOL 四阶、六点 Gauss 积分点组装导数，并由六个实际积分点恢复二次曲边几何映射与积分权重，避免用直边三角形面积或像素中心采样造成导数偏差。算子生成时实际重新求解三处像素电导率扰动及一处介电扰动，逐频核对；本批最大导数相对误差约0.168%，参考电压与原背景的相对误差约4e-14。报告还记录无积分点覆盖、参考灵敏度为零的像素（Fat 227、Muscle 126）；线性反演不能恢复这些独立像素自由度，空间网络和监督提供进一步先验。参考算子仍是固定均匀背景线性化，不是病例精确非线性正向解。

核验同时发现：元信息虽声明 finite_contact_impedance=0.01 Ωm²，生成器把 ContactImpedance 节点选在外部边界；COMSOL 此节点适用于内部边界。删除所有这些节点后的电压相对差异仅约1e-15，没有可测接触阻抗效应。因此当前数据应按实际有效的电流端子边界模型使用，不能宣称实现了有限接触阻抗。详见 CONTACT_MODEL_ADDENDUM.md 及真实删除节点实验。生产算子按实际生成模型匹配；physics.py 中独立 CEM 仅用于诊断/单元导数检验，不用于当前训练。

线性图采用联合 Δσ/Δεr 的零阶 Tikhonov 正则化最小二乘：x=Aᵀ(AAᵀ+λI)⁻¹ΔV。λ=0.02×AAᵀ 最大特征值估计；这是最小二乘反演，和 v6 的 Jacobian 伴随回投影不同。v6 回投影是 Aσᵀ(ΔV−A x)，按列平方和作灵敏度补偿再归一化。

PDF 原式 JΔσ 针对电导率重建；本批复数测量同时存在介电变化，因此增加双频 Δεr 辅助回归头，物理损失使用 J(Δσ+iωε0Δεr)，分别比较实部/虚部。该扩展是本工程的显式数据适配。物理一致性仍是软损失，不是硬 PDE 限制。

## v4 结构

残差块均为两层3×3卷积 + GroupNorm(8组) + SiLU + Dropout2d(0.05)，投影残差在通道/分辨率变化时使用1×1卷积。

图像编码器：[7,64,64] → [64,64,64] → [128,32,32] → [256,16,16] → [512,8,8]。
电压编码器：[4,32,32] → [32,32,32] → [64,16,16] → [128,8,8] → [256,4,4]。
将电压特征双线性调整至8×8，与图像瓶颈按通道拼接为 [768,8,8]，两个残差块融合至 [512,8,8]。
U-Net 解码器依次与图像跳跃特征拼接并输出 [256,16,16]、[128,32,32]、[64,64,64]。

输出：
三类概率 [3,64,64]；前景为低/高两类之和 [1,64,64]；
SDF [1,64,64]；归一化双频 Δσ/Δεr 各 [2,64,64]；
raw/connected/effective cutout、mouth、local gate 各 [1,64,64]；
case gate 为 [1,1,1]（每病例一标量）。
最终类别概率将前景乘 (1−effective_cutout)，删除量回归背景类，三类仍和为1。

v4 包含 PDF 中全部损失类别：基础/最终分类、Dice、SDF、边界梯度、电导率、物理电压、切除/开口 BCE+Dice、clDice、凹陷深度、面积预算、普通病例保护、门控；额外有介电常数回归。深度采用12步软腐蚀累计深度，面积预算监督实际删去面积；实现公式和权重见 losses.py/config.json。它们属于结构描述不足处的明确实现选择。

## 连通约束

外部 FOV 是传播起点。先以3×3 max-pool 在预测背景内传播64步，只有与域外连通的背景允许成为切口入口；mouth>0.5 指定入口，raw_cutout≥0.5 指定允许通过的切除支持域，再传播64步。最终将 raw 概率乘可达支持，再乘 local gate 和 case gate（v4）或 confidence（v6）。

可达支持是前向中的硬限制，不仅是损失项；支持内幅值和置信度可学习。阈值化传播不反传梯度，raw/mouth 均有独立监督损失。孤立内部孔洞不能作为传播种子。64步是当前64×64网格的显式上限。

## v6 结构与冻结

训练完成 v4 后加载其最佳验证权重，所有参数 requires_grad=False，持续 eval 模式；随后训练局部网络。冻结 v4 为 anchor 的来源，也提供其辅助输出，不是把 v4 权重拼进输入张量。

15通道 [15,64,64]：
三类概率3、熵1、SDF1、raw cutout1、connected cutout1、mouth1、effective cutout1、
10k Δσ1、归一化线性图1、7×7平滑1、边缘1、物理回投影1、FOV1。
特征函数不接收真值。

局部网络三层编码器：[15,64,64] → [32,64,64] → [64,32,32] → [128,16,16]。
context 下采样至 [256,8,8]，再使用 dilation=2 和4的残差块。
U-Net 跳跃解码：[128,16,16] → [64,32,32] → [32,64,64]。
removal/mouth/confidence 输出均为 [1,64,64]。

candidate 前景 = anchor 前景×(1−α×connected_removal×confidence)，α=1。
anchor/candidate 都为 [3,64,64] 的三类概率，只删除前景，不增加前景。
v4 的 local/case gate 和 v6 的 confidence/risk gate 是不同网络、不同参数；v6 的特征包含 v4 的门控后切除图。

## 56维统计与风险门控

12张无需真值的图各取 FOV 内 mean/std/q50/q95，共48维：
anchor前景、candidate前景、熵、SDF、raw removal、connected removal、effective removal、
confidence、mouth、物理回投影、归一化线性图、10k Δσ。
另8维：anchor/candidate面积比例、删除面积比例、删除/anchor比例、
anchor/candidate边界比例、测量电压差 RMS、anchor预测后的电压残差 RMS。
具体有序名称见 risk.py 的 FEATURE_NAMES；归一化统计仅在 train 拟合。

MLP：56 → Linear128 → LayerNorm → SiLU → Dropout0.1 → Linear96 → LayerNorm → SiLU → Dropout0.1 → Linear9。
三个目标各输出 q20/q50/q80，以中位数及两个 softplus 间隔构造有序分位数，pinball loss 训练。
标签只在训练期计算：真切口中被删除的软前景比例（收益）、硬掩膜 IoU 的非负下降、被误删真前景/全部真前景。
其收益具体定义是本工程的明确选择，PDF 没有给出标签提取源码。
保留校准位置用观测分位数残差校准输出，再排序保证分位数单调。

仅当 benefit q20>0、IoU loss q80≤0.006、wrong deletion q80≤0.05 才使用 candidate。
阈值来自 PDF，固定配置；预测网络和分位数校准学习数据，阈值不训练。
拒绝病例通过 torch.where 直接返回原 anchor，逐元素精确一致。
这不保证被接受的普通病例绝对无损，评估报告会统计下降案例。

## 训练安排、复现和范围

默认首个种子20260911：v4 100轮、local 50轮、gate 120轮，AdamW、余弦学习率、batch16、BF16。
轮数、通道数、损失权重均为本工程公开的初始配置，不是恢复 PDF 未给出的原超参数。
实际参数量写入 self_test_report.json / runs/seed_*/model_parameters.json；不得用 PDF 的旧参数量冒充实测数量。
CLI 支持多个种子按给定顺序运行。

风险训练前局部网络也冻结；风险标签在实际训练网络上计算，不由生成器预设。
中途保存模型、优化器、调度器、随机数状态、轮次/下个批次；可在同配置下断点续训。
完成后自动评估隔离 test，产出逐例路由、IoU/风险及分组统计。
infer-four 使用当前测试集各形状一例，不冒充旧 ABC2 四病例。
evaluate 支持 --ablation v4 / ungated / full；--voltage-noise、--missing-fraction、--physics-scale 支持测量与参考模型扰动。
当前工程无实测 KTC/临床/超声数据，也不复刻不存在的旧实验结果。

单病例无真值推理：输入 NPZ 必须包含复数电压 voltage、background_voltage，形状均为 [2,32,32]，以及 frequencies_hz=[10000,50000]；可直接采用最小数据包病例文件。执行 infer 时显式提供已知背景材料 Fat/Muscle，示例：

    python run_model.py infer --input case.npz --background-material Fat --output predictions/case --device cuda

训练结束后才能使用相应最佳权重进行正式推理。输出包含概率、掩膜、切除、风险分位数及双频电学预测。

