"""Portable historical V4-only entry. Training is explicit and never automatic."""
from pathlib import Path
import argparse,json,sys,hashlib
R=Path(__file__).resolve().parent;P=R/'EIT_Reconstruction';sys.path.insert(0,str(P))
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('action',choices=['verify','infer','train-original'])
    ap.add_argument('--weights',choices=['original','long_patience'],default='original');ap.add_argument('--input',type=Path)
    ap.add_argument('--background',choices=['Fat','Muscle']);ap.add_argument('--output',type=Path);ap.add_argument('--cache',type=Path);ap.add_argument('--device',default='cpu');a=ap.parse_args()
    if a.action=='verify':
        d=json.loads((R/'MANIFEST.sha256.json').read_text(encoding='utf-8'))
        for n,m in d.items():
            h=hashlib.sha256()
            with (R/n).open('rb') as f:
                for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
            assert h.hexdigest()==m['sha256'] and (R/n).stat().st_size==m['bytes'],n
        print('PASS',len(d),'files');return
    import torch,numpy as np
    from eit.models import V4
    cfg=json.loads((P/'config.json').read_text(encoding='utf-8'));torch.set_num_threads(2)
    if a.action=='train-original':
        if not a.cache or not a.output:ap.error('train-original requires --cache and --output')
        from eit.train import train_network,validation_roles
        from eit.data import EITDataset
        from eit.physics import Physics
        from eit.runtime import Reporter,seed_all
        from eit.models import LocalTopologyCorrectorV6,DualRiskQuantileGate
        seed_all(cfg['seed']);model=V4(cfg['v4_base'],cfg['dropout'],cfg['propagation_iterations']).to(a.device)
        local=LocalTopologyCorrectorV6(cfg['local_base'],cfg['dropout'],cfg['propagation_iterations'],cfg['alpha']).to(a.device);gate=DualRiskQuantileGate().to(a.device);del local,gate
        roles=validation_roles(a.cache,cfg['validation_seed'])
        train_network('v4',model,EITDataset(a.cache,'train'),EITDataset(a.cache,'val',positions=roles['selection_positions']),cfg,torch.device(a.device),Physics(P/'operators/operators.npz',torch.device(a.device)),a.output,Reporter(a.output))
        return
    if not a.input or not a.output or not a.background:ap.error('infer requires --input, --output and --background')
    from eit.data import input_features
    with np.load(a.input,allow_pickle=False) as z:v=z['voltage'].copy();bg=z['background_voltage'].copy();freq=z['frequencies_hz'].copy()
    assert v.shape==bg.shape==(2,32,32) and np.iscomplexobj(v) and np.iscomplexobj(bg)
    assert np.array_equal(freq,[10000,50000]) and np.isfinite(v).all() and np.isfinite(bg).all()
    idx=(np.arange(32)+1)%32;v-=v[:,np.arange(32),idx][:,:,None];bg-=bg[:,np.arange(32),idx][:,:,None]
    with np.load(P/'operators/operators.npz') as z:
        group=list(z['group_names']).index(a.background);image,table,_=input_features(v,bg,z['G'][group],z['voltage_scale'][group],z['valid'])
    with np.load(P/'cache/voltage_normalization.npz') as z:table=(table-z['mean'])/z['std']
    path=P/'runs/seed_20260911/v4/best.pt' if a.weights=='original' else R/'EIT_Comparison/results/project_v4_long_patience/best.pt'
    model=V4(cfg['v4_base'],cfg['dropout'],cfg['propagation_iterations']).to(a.device)
    ck=torch.load(path,map_location=a.device,weights_only=False);model.load_state_dict(ck['model'],strict=True);model.eval()
    with torch.no_grad():out=model(torch.from_numpy(image[None]).to(a.device),torch.from_numpy(table[None]).to(a.device))
    result={k:v[0].cpu().numpy() for k,v in out.items()};result['delta_sigma_S_per_m']=result['sigma']*.2;result['delta_epsilon']=result['epsilon']*50000;result['predicted_mask']=result['foreground'][0]>=.5;result['frequencies_hz']=freq
    a.output.parent.mkdir(parents=True,exist_ok=True);np.savez_compressed(a.output,**result);print('Saved',a.output,'checkpoint epoch',ck['epoch'])
if __name__=='__main__':main()
