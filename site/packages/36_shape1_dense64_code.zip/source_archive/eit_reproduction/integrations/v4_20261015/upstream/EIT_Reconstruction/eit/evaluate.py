from pathlib import Path
import json
import numpy as np
import torch
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from .models import V4,LocalTopologyCorrectorV6,DualRiskQuantileGate,make_v6_features,route
from .physics import Physics
from .data import EITDataset,input_features
from .runtime import load_weights,to_device,atomic_json
from .risk import extract_statistics,risk_targets,iou_per_case
from .train import loader,predict_local

@torch.no_grad()
def evaluate_all(project,config,device,seed,split="test",output=None,four=False,
                 ablation="full",noise=0.,missing=0.,physics_scale=1.):
    project=Path(project);run=project/"runs"/f"seed_{seed}"
    output=Path(output or run/"evaluation");output.mkdir(parents=True,exist_ok=True)
    v4=V4(config["v4_base"],config["dropout"],config["propagation_iterations"]).to(device)
    local=LocalTopologyCorrectorV6(config["local_base"],config["dropout"],config["propagation_iterations"],config["alpha"]).to(device)
    gate=DualRiskQuantileGate().to(device)
    load_weights(v4,run/"v4/best.pt",device);v4.eval()
    if ablation!="v4":
        load_weights(local,run/"local/best.pt",device);local.eval()
        if ablation!="ungated":load_weights(gate,run/"gate/best.pt",device);gate.eval()
    physics=Physics(project/"operators/operators.npz",device);physics.A*=physics_scale
    ds=EITDataset(project/"cache",split)
    if four:
        chosen={}
        for r in ds.rows:chosen.setdefault(r["shape_class"],r)
        ds.rows=list(chosen.values())[:4]
    if noise or missing or physics_scale!=1:
        with np.load(project/"operators/operators.npz") as z:
            G=z["G"]/physics_scale;valid=z["valid"]
        rng=np.random.default_rng(seed)
    records=[]
    for batch in loader(ds,config["batch_size"]):
        if noise or missing or physics_scale!=1:
            for i in range(len(batch["mask"])):
                dv=batch["dv"][i].numpy().copy(); n=1024
                delta=(dv[:,:n]+1j*dv[:,n:]).reshape(2,32,32)
                delta+=noise*np.sqrt(np.mean(np.abs(delta)**2))*\
                    (rng.normal(size=delta.shape)+1j*rng.normal(size=delta.shape))/np.sqrt(2)
                delta[rng.random(delta.shape)<missing]=0
                group=int(batch["group"][i])
                image,table,dv=input_features(delta,np.zeros_like(delta),G[group],np.ones(2),valid)
                batch["image"][i]=torch.from_numpy(image)
                batch["voltage"][i]=torch.from_numpy((table-ds.mean)/ds.std)
                batch["dv"][i]=torch.from_numpy(dv)
        batch=to_device(batch,device)
        with torch.autocast(device_type=device.type,dtype=torch.bfloat16,enabled=device.type=="cuda"):
            if ablation=="v4":
                a=v4(batch["image"],batch["voltage"]);final=a["final"];candidate=final
                accepted=torch.zeros(len(final),device=device,dtype=torch.bool)
                q=torch.full((len(final),3,3),float("nan"),device=device)
            else:
                a,c,bp,pred=predict_local(v4,local,physics,batch);candidate=c["candidate"]
                if ablation=="ungated":
                    accepted=torch.ones(len(candidate),device=device,dtype=torch.bool);final=candidate
                    q=torch.full((len(final),3,3),float("nan"),device=device)
                else:
                    statistics=extract_statistics(a,c,batch["image"],bp,batch["dv"],pred)
                    q=gate(statistics)
                    final,accepted=route(a["final"],candidate,q,
                        config["risk_thresholds"]["iou_q80"],config["risk_thresholds"]["deletion_q80"])
        anchor_iou=iou_per_case(a["foreground"],batch["mask"])
        candidate_iou=iou_per_case(candidate[:,1:].sum(1,keepdim=True),batch["mask"])
        final_iou=iou_per_case(final[:,1:].sum(1,keepdim=True),batch["mask"])
        risks=risk_targets(a["final"],candidate,batch["mask"],batch["cutout"])
        routed_removal=torch.zeros_like(a["foreground"]) if ablation=="v4" else torch.where(accepted[:,None,None,None],c["removal"],torch.zeros_like(c["removal"]))
        for i,cid in enumerate(batch["case_id"]):
            record={"case_id":cid,"shape_class":batch["shape_class"][i],"accepted":bool(accepted[i]),
                "anchor_iou":float(anchor_iou[i]),"candidate_iou":float(candidate_iou[i]),"final_iou":float(final_iou[i]),
                "concavity_benefit":float(risks[i,0]),"iou_loss":float(risks[i,1]),"wrong_deletion":float(risks[i,2]),
                "quantiles":q[i].float().cpu().tolist() if torch.isfinite(q[i]).all() else None}
            records.append(record)
            if four:
                arrays={"linear":batch["image"][i,0].float().cpu().numpy(),
                    "truth":batch["mask"][i,0].cpu().numpy(),"anchor":a["foreground"][i,0].float().cpu().numpy(),
                    "candidate":candidate[i,1:].sum(0).float().cpu().numpy(),
                    "final":final[i,1:].sum(0).float().cpu().numpy(),
                    "class_probabilities":final[i].float().cpu().numpy(),
                    "anchor_delta_sigma_S_per_m":a["sigma"][i].float().cpu().numpy()*physics.sigma_scale,
                    "delta_sigma_S_per_m":(a["sigma"]*(1-routed_removal))[i].float().cpu().numpy()*physics.sigma_scale,
                    "delta_epsilon":(a["epsilon"]*(1-routed_removal))[i].float().cpu().numpy()*physics.epsilon_scale}
                np.savez_compressed(output/(cid+".npz"),**arrays)
                fig,axes=plt.subplots(1,5,figsize=(15,3))
                for ax,key in zip(axes,["linear","truth","anchor","candidate","final"]):
                    ax.imshow(arrays[key],origin="lower",cmap="viridis");ax.set_title(key);ax.axis("off")
                fig.suptitle(f"{cid} | routed={record['accepted']} | IoU={record['final_iou']:.3f}")
                fig.tight_layout();fig.savefig(output/(cid+".png"),dpi=160);plt.close(fig)
    grouped={}
    for cls in sorted({r["shape_class"] for r in records}):
        subset=[r for r in records if r["shape_class"]==cls]
        grouped[cls]={"count":len(subset),"anchor_iou":float(np.mean([r["anchor_iou"] for r in subset])),
            "candidate_iou":float(np.mean([r["candidate_iou"] for r in subset])),
            "final_iou":float(np.mean([r["final_iou"] for r in subset])),
            "accepted":sum(r["accepted"] for r in subset),
            "severe_iou_drop_gt_0p1":sum(r["anchor_iou"]-r["final_iou"]>.1 for r in subset)}
    report={"status":"PASS","split":split,"case_count":len(records),"ablation":ablation,
        "stress":{"voltage_noise_fraction":noise,"missing_measurement_fraction":missing,
                  "missing_policy":"zero residual + recompute linear image","reference_operator_scale":physics_scale},
        "groups":grouped,"mean_anchor_iou":float(np.mean([r["anchor_iou"] for r in records])),
        "mean_final_iou":float(np.mean([r["final_iou"] for r in records])),
        "records":records,"note":"Current synthetic ADJACENT32 dataset; not absent KTC/ABC2 experiments."}
    atomic_json(output/"metrics.json",report);return report

