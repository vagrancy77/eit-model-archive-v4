"""Rebuilt v4/v6 pipeline. Run --help for all commands."""
from pathlib import Path
import argparse,json
import torch
from eit.runtime import verify_manifest
PROJECT=Path(__file__).resolve().parent

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("command",choices=["verify","prepare","train","evaluate","infer","infer-four","self-test","manifest"])
    p.add_argument("--config",type=Path,default=PROJECT/"config.json")
    p.add_argument("--device",default="cuda")
    p.add_argument("--seeds",type=int,nargs="+")
    p.add_argument("--split",choices=["train","val","test"],default="test")
    p.add_argument("--ablation",choices=["full","v4","ungated"],default="full")
    p.add_argument("--voltage-noise",type=float,default=0)
    p.add_argument("--missing-fraction",type=float,default=0)
    p.add_argument("--physics-scale",type=float,default=1)
    p.add_argument("--output",type=Path)
    p.add_argument("--input",type=Path)
    p.add_argument("--background-material",choices=["Fat","Muscle"])
    a=p.parse_args();cfg=json.loads(a.config.read_text(encoding="utf-8"))
    torch.set_num_threads(cfg["cpu_threads"])
    if a.command=="verify":print(json.dumps(verify_manifest(PROJECT),indent=2));return
    if a.command=="manifest":
        from eit.runtime import code_manifest
        code_manifest(PROJECT);return
    if a.command=="self-test":
        from tests.test_contract import run
        run(PROJECT,cfg,a.device);return
    if a.command=="prepare":
        from eit.physics import build_operators
        from eit.data import prepare_cache,assert_split_isolation
        from eit.runtime import Reporter
        reporter=Reporter(PROJECT/"runs/preparation")
        assert_split_isolation(cfg["dataset"])
        operator=PROJECT/"operators/operators.npz"
        if not operator.exists():build_operators(cfg["dataset"],operator.parent,cfg,reporter)
        prepare_cache(cfg["dataset"],PROJECT/"cache",operator,reporter);return
    if a.command=="train":
        from eit.train import pipeline
        pipeline(PROJECT,cfg,a.device,a.seeds);return
    if a.command=="infer":
        from eit.infer import infer_case
        if a.input is None or a.background_material is None or a.output is None:p.error("infer requires --input, --background-material and --output")
        print(json.dumps(infer_case(PROJECT,cfg,a.input,a.background_material,(a.seeds or [cfg['seed']])[0],torch.device(a.device),a.output,a.ablation),ensure_ascii=False,indent=2));return
    from eit.evaluate import evaluate_all
    if not (0<=a.missing_fraction<1) or a.physics_scale<=0:raise ValueError("Invalid stress setting")
    evaluate_all(PROJECT,cfg,torch.device(a.device),(a.seeds or [cfg["seed"]])[0],
        a.split,a.output,a.command=="infer-four",a.ablation,a.voltage_noise,a.missing_fraction,a.physics_scale)
if __name__=="__main__":main()

