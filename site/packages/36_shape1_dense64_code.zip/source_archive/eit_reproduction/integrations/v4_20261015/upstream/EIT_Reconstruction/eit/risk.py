"""56 truth-blind case statistics; label extraction is a separate training-only API."""
import torch
import torch.nn.functional as F

MAP_NAMES=["anchor_foreground","candidate_foreground","entropy","sdf",
    "raw_removal","connected_removal","effective_removal","confidence","mouth",
    "physics_backprojection","linear_normalized","delta_sigma_10k"]
STAT_NAMES=["mean","std","q50","q95"]
FEATURE_NAMES=[m+"_"+s for m in MAP_NAMES for s in STAT_NAMES]+[
    "anchor_area_fraction","candidate_area_fraction","removed_area_fraction",
    "removed_over_anchor","anchor_boundary_fraction","candidate_boundary_fraction",
    "voltage_residual_rms","predicted_voltage_residual_rms"]
assert len(FEATURE_NAMES)==56

def extract_statistics(anchor,local,image,bp,measured_residual,predicted_residual):
    """Uses model outputs, measured data, reference operators and FOV only."""
    fov=image[:,-1:]>.5
    a=anchor["final"][:,1:].sum(1,keepdim=True); c=local["candidate"][:,1:].sum(1,keepdim=True)
    ent=-(anchor["final"]*anchor["final"].clamp_min(1e-7).log()).sum(1,keepdim=True)
    maps=[a,c,ent,anchor["sdf"],local["raw_removal"],local["connected_removal"],
          local["removal"],local["confidence"],local["mouth"],bp,image[:,:1],anchor["sigma"][:,:1]]
    output=[]
    for b in range(a.shape[0]):
        valid=fov[b,0]; row=[]
        for m in maps:
            v=m[b,0][valid].float()
            row.extend([v.mean(),v.std(unbiased=False),torch.quantile(v,.5),torch.quantile(v,.95)])
        ah=(a[b:b+1]>=.5).float()*fov[b:b+1]
        ch=(c[b:b+1]>=.5).float()*fov[b:b+1]
        n=valid.sum().clamp_min(1)
        removed=(ah-ch).clamp_min(0).sum()
        abound=(F.max_pool2d(ah,3,1,1)+F.max_pool2d(-ah,3,1,1)).abs().sum()/n
        cbound=(F.max_pool2d(ch,3,1,1)+F.max_pool2d(-ch,3,1,1)).abs().sum()/n
        row.extend([ah.sum()/n,ch.sum()/n,removed/n,removed/ah.sum().clamp_min(1),abound,cbound,
            measured_residual[b].float().square().mean().sqrt(),
            (measured_residual[b]-predicted_residual[b]).float().square().mean().sqrt()])
        output.append(torch.stack(row))
    return torch.stack(output)

def iou_per_case(p,y):
    p=p>=.5; y=y>=.5
    dims=tuple(range(1,p.ndim))
    return ((p&y).sum(dims).float()+1e-6)/((p|y).sum(dims).float()+1e-6)

def risk_targets(anchor,candidate,truth,cutout):
    """Training labels: soft deletion benefit in the true concavity, IoU drop, false deletion."""
    a=anchor[:,1:].sum(1,keepdim=True); c=candidate[:,1:].sum(1,keepdim=True)
    dims=(1,2,3)
    benefit=((a-c)*cutout).sum(dims)/cutout.sum(dims).clamp_min(1)
    iou_risk=(iou_per_case(a,truth)-iou_per_case(c,truth)).clamp_min(0)
    removed=((a>=.5)&(c<.5)).float()
    wrong=(removed*truth).sum(dims)/truth.sum(dims).clamp_min(1)
    return torch.stack([benefit,iou_risk,wrong],1)

def quantile_loss(pred,target):
    q=pred.new_tensor([.2,.5,.8]); error=target[:,:,None]-pred
    return torch.maximum(q*error,(q-1)*error).mean()

