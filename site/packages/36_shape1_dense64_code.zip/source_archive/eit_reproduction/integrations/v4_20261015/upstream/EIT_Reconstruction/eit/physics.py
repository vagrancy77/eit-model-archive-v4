"""Reference 2D complete-electrode FEM, complex Jacobian and Tikhonov inversion.
This is an independently discretized reference, not the original COMSOL mesh.
Units: metre, ampere, S/m, relative permittivity; 2D depth is explicitly 1 metre.
"""
from pathlib import Path
import json
import numpy as np
from scipy import sparse, linalg
from scipy.sparse.linalg import splu
from scipy.spatial import cKDTree
import torch
EPS0=8.8541878128e-12

class CEM:
    def __init__(self,radius=.05,ne=32,width_deg=5,z=.01,current=.00025,rings=24):
        self.ne=ne; self.current=current; self.z=z
        centers=np.arange(ne)*2*np.pi/ne
        angles=np.unique(np.round(np.r_[np.arange(256)*2*np.pi/256,
            (centers-width_deg*np.pi/360)%(2*np.pi),(centers+width_deg*np.pi/360)%(2*np.pi)],12))
        angles.sort(); na=len(angles)
        radial=np.arange(1,rings+1)*radius/rings
        xy=[np.array([[0.,0.]])]+[np.c_[np.cos(angles),np.sin(angles)]*r for r in radial]
        self.xy=np.vstack(xy); triangles=[]
        for j in range(na): triangles.append([0,1+j,1+(j+1)%na])
        for ring in range(rings-1):
            lo=1+ring*na; hi=lo+na
            for j in range(na):
                k=(j+1)%na
                triangles.extend([[lo+j,hi+j,hi+k],[lo+j,hi+k,lo+k]])
        self.tri=np.array(triangles); coords=self.xy[self.tri]
        twice=(coords[:,1,0]-coords[:,0,0])*(coords[:,2,1]-coords[:,0,1])-\
              (coords[:,2,0]-coords[:,0,0])*(coords[:,1,1]-coords[:,0,1])
        self.area=np.abs(twice)/2
        self.grad=np.stack([np.c_[coords[:,1,1]-coords[:,2,1],coords[:,2,0]-coords[:,1,0]],
            np.c_[coords[:,2,1]-coords[:,0,1],coords[:,0,0]-coords[:,2,0]],
            np.c_[coords[:,0,1]-coords[:,1,1],coords[:,1,0]-coords[:,0,0]]],1)/twice[:,None,None]
        self.element=self.area[:,None,None]*np.einsum("tik,tjk->tij",self.grad,self.grad)
        n=len(self.xy); rr=[];cc=[];vv=[]; br=[];bc=[];bv=[];diag=np.zeros(ne)
        for j in range(na):
            k=(j+1)%na
            delta=(angles[k]-angles[j])%(2*np.pi); mid=(angles[j]+delta/2)%(2*np.pi)
            distance=(mid-centers+np.pi)%(2*np.pi)-np.pi
            e=int(np.argmin(np.abs(distance)))
            if abs(distance[e])>width_deg*np.pi/360+1e-10: continue
            a=1+(rings-1)*na+j; b=1+(rings-1)*na+k
            length=np.linalg.norm(self.xy[b]-self.xy[a])
            for i,ii in enumerate([a,b]):
                for q,jj in enumerate([a,b]):
                    rr.append(ii);cc.append(jj);vv.append(length/z*(2 if i==q else 1)/6)
                br.append(ii);bc.append(e);bv.append(-length/(2*z))
            diag[e]+=length/z
        self.contact=sparse.coo_matrix((vv,(rr,cc)),shape=(n,n)).tocsc()
        self.B=sparse.coo_matrix((bv,(br,bc)),shape=(n,ne)).tocsc()
        self.D=sparse.diags(diag).tocsc()
        self.rhs=np.zeros((n+ne+1,ne),dtype=complex)
        for e in range(ne-1): self.rhs[n+e,e]=1; self.rhs[n+ne-1,e]=-1
        self.rows=np.broadcast_to(self.tri[:,:,None],(len(self.tri),3,3)).reshape(-1)
        self.cols=np.broadcast_to(self.tri[:,None,:],(len(self.tri),3,3)).reshape(-1)
    def solve_basis(self,kappa):
        kappa=np.broadcast_to(kappa,(len(self.tri),))
        n=len(self.xy); ne=self.ne
        K=sparse.coo_matrix(((self.element*kappa[:,None,None]).reshape(-1),
            (self.rows,self.cols)),shape=(n,n)).tocsc()+self.contact
        gauge=sparse.csc_matrix(np.ones((ne,1)))
        A=sparse.bmat([[K,self.B,None],[self.B.T,self.D,gauge],
            [None,gauge.T,sparse.csc_matrix((1,1))]],format="csc")
        return splu(A).solve(self.rhs)
    def table(self,basis):
        n=len(self.xy); U=basis[n:n+self.ne]
        tables=[]
        for d in range(self.ne):
            neg=(d+1)%self.ne
            driven=self.current*(U[:,d]-U[:,neg])
            tables.append(driven-driven[neg])
        return np.array(tables)
    def jacobian(self,basis,pixels,nvalid):
        nodal=basis[:len(self.xy)]
        gradients=np.einsum("tie,tik->etk",nodal[self.tri],self.grad)
        mapping=sparse.coo_matrix((np.ones(len(pixels)),(np.arange(len(pixels)),pixels)),
                                  shape=(len(pixels),nvalid)).tocsr()
        result=[]
        for d in range(self.ne):
            neg=(d+1)%self.ne
            driven=self.current*(gradients[d]-gradients[neg])
            adj=gradients-gradients[neg]
            sensitivity=-self.area[None,:]*np.einsum("tk,etk->et",driven,adj)
            result.append(np.asarray(mapping.T @ sensitivity.T).T)
        return np.array(result)

def build_independent_cem_operators(dataset,output,config,status=lambda **kw:None):
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    with np.load(Path(dataset)/"grid.npz") as g:
        valid=g["valid_mask"].astype(bool);xx=g["x"];yy=g["y"]
    if xx.ndim==1: xx,yy=np.meshgrid(xx,yy)
    points=np.c_[xx[valid],yy[valid]]
    mesh=CEM(rings=config["physics"]["radial_rings"])
    centroids=mesh.xy[mesh.tri].mean(1)
    pixels=cKDTree(points).query(centroids)[1]
    rows=json.loads((Path(dataset)/"splits.json").read_text(encoding="utf-8"))["splits"]
    representatives={}
    for row in rows:
        with np.load(Path(dataset)/row["file"]) as z:
            p=json.loads(str(z["parameters_json"]))
            if p["background_material"] not in representatives:
                representatives[p["background_material"]]=(p,z["background_voltage"].copy())
        if len(representatives)==2: break
    names=sorted(representatives);operators=[];reconstructors=[];references=[];scales=[]
    report={"kind":"independent_2D_CEM_reference","depth_m":1.0,
        "radial_rings":config["physics"]["radial_rings"],"nodes":len(mesh.xy),
        "triangles":len(mesh.tri),"channels":["delta_sigma","delta_epsilon"],
        "linear_algorithm":"complex joint zeroth-order Tikhonov least squares",
        "groups":{},"jacobian_finite_difference":[]}
    for gi,name in enumerate(names):
        p,actual=representatives[name]; freq_ops=[];freq_inv=[];freq_ref=[];freq_scale=[];group_report=[]
        for fi,band in enumerate(["10","50"]):
            status(phase="PHYSICS",message=f"CEM {name} {band} kHz",group=gi,frequency=fi)
            sigma=float(p["sig_b"+band]);eps=float(p["eps_b"+band]);freq=float(p["freq"+str(fi+1)])
            kappa=sigma+1j*2*np.pi*freq*EPS0*eps
            basis=mesh.solve_basis(kappa); ref=mesh.table(basis);J=mesh.jacobian(basis,pixels,len(points)).reshape(1024,-1)
            scale=float(np.sqrt(np.mean(np.abs(actual[fi])**2)))
            ss=config["physics"]["sigma_scale"];es=config["physics"]["epsilon_scale"]
            JC=np.concatenate([J*ss,J*(1j*2*np.pi*freq*EPS0*es)],1)/scale
            A=np.concatenate([JC.real,JC.imag],0)
            # Relative damping tied to the largest eigenvalue, independent of labels.
            vec=np.ones(A.shape[0]);vec/=np.linalg.norm(vec)
            for _ in range(15):
                vec=A@(A.T@vec);vec/=max(np.linalg.norm(vec),1e-30)
            largest=float(vec@(A@(A.T@vec)))
            lam=config["physics"]["tikhonov_fraction"]*largest
            gram=A@A.T
            gram.flat[::gram.shape[0]+1]+=lam
            chol=linalg.cho_factor(gram,lower=True,check_finite=False)
            inverse=linalg.cho_solve(chol,A,check_finite=False).T
            freq_ops.append(A.astype(np.float32));freq_inv.append(inverse.astype(np.float32))
            freq_ref.append(ref);freq_scale.append(scale)
            # Finite difference of an actual pixel perturbation, full CEM re-solve.
            selected=int(np.argmin(np.sum((points-np.array([.003,.002]))**2,axis=1)))
            step=sigma*1e-4;perturbed=np.full(len(mesh.tri),kappa,dtype=complex)
            perturbed[pixels==selected]+=step
            fd=(mesh.table(mesh.solve_basis(perturbed))-ref).reshape(-1)/step
            error=float(np.linalg.norm(fd-J[:,selected])/max(np.linalg.norm(J[:,selected]),1e-30))
            if error>2e-3: raise RuntimeError(f"Jacobian finite difference failed: {error}")
            report["jacobian_finite_difference"].append({"background":name,"frequency_hz":freq,"relative_error":error})
            group_report.append({"frequency_hz":freq,"background_sigma":sigma,"background_epsilon":eps,
                "voltage_scale":scale,"damping":lam,"reference_vs_comsol_relative_rmse":
                float(np.linalg.norm(ref-actual[fi])/np.linalg.norm(actual[fi]))})
        operators.append(freq_ops);reconstructors.append(freq_inv);references.append(freq_ref);scales.append(freq_scale)
        report["groups"][name]=group_report
    np.savez(output/"operators.npz",A=np.array(operators),G=np.array(reconstructors),
             reference=np.array(references),voltage_scale=np.array(scales),
             valid=valid,group_names=np.array(names),sigma_scale=ss,epsilon_scale=es)
    report["status"]="PASS"
    (output/"physics_verification.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
    return report

def build_operators(dataset,output,config,status=lambda **kw:None):
    """Production reference follows the actual generator, including effective boundaries."""
    import subprocess,sys
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    project=Path(__file__).resolve().parents[1];reference_root=project/"reference_exports"
    audit_path=reference_root/"gauss_reference_checks.json"
    if not audit_path.exists():
        status(phase="PHYSICS",message="Exporting homogeneous same-generator COMSOL reference")
        subprocess.run([sys.executable,"-B",str(project/"reference/export_reference.py"),
                        "--project",str(project)],check=True)
    audit=json.loads(audit_path.read_text(encoding="utf-8"))
    if audit["status"]!="PASS":raise RuntimeError("COMSOL reference finite-difference audit failed")
    with np.load(Path(dataset)/"grid.npz") as g:valid=g["valid_mask"].astype(bool)
    names=["Fat","Muscle"];ops=[];invs=[];refs=[];scales=[];report={"status":"PASS","physics_config":config['physics'],
        "kind":"same_COMSOL_generator_gauss_adjoint","electrode_model":
        "effective terminal boundary; declared exterior ContactImpedance has no measurable effect",
        "linear_algorithm":"complex joint zeroth-order Tikhonov least squares",
        "quadrature_order":4,"curved_geometry_mapping":"quadratic recovered from six Gauss coordinates",
        "groups":{},"finite_difference_audit":audit}
    for gi,name in enumerate(names):
        folder=reference_root/name
        with np.load(folder/"gauss_reference_jacobian.npz") as z:Jall=z["J"];reference=z["reference"]
        params=json.loads((folder/"reference_parameters.json").read_text(encoding="utf-8"))
        group_ops=[];group_inv=[];group_scale=[];group_report=[]
        for fi,band in enumerate(["10","50"]):
            status(phase="PHYSICS",group=gi,frequency=fi,message=f"COMSOL adjoint Tikhonov {name} {band} kHz")
            freq=float(params["freq"+str(fi+1)]);J=Jall[fi];scale=float(np.sqrt(np.mean(np.abs(reference[fi])**2)))
            ss=config["physics"]["sigma_scale"];es=config["physics"]["epsilon_scale"]
            JC=np.concatenate([J*ss,J*(1j*2*np.pi*freq*EPS0*es)],1)/scale
            A=np.concatenate([JC.real,JC.imag],0)
            vec=np.ones(A.shape[0]);vec/=np.linalg.norm(vec)
            for _ in range(15):
                vec=A@(A.T@vec);vec/=max(np.linalg.norm(vec),1e-30)
            largest=float(vec@(A@(A.T@vec)));lam=config["physics"]["tikhonov_fraction"]*largest
            gram=A@A.T;gram.flat[::gram.shape[0]+1]+=lam
            chol=linalg.cho_factor(gram,lower=True,check_finite=False)
            inverse=linalg.cho_solve(chol,A,check_finite=False).T
            group_ops.append(A.astype(np.float32));group_inv.append(inverse.astype(np.float32));group_scale.append(scale)
            group_report.append({"frequency_hz":freq,"voltage_scale":scale,"damping":lam,
                "background_sigma":float(params["sig_b"+band]),"background_epsilon":float(params["eps_b"+band]),
                "zero_sensitivity_pixels":int((np.abs(J).sum(0)<1e-20).sum())})
        ops.append(group_ops);invs.append(group_inv);refs.append(reference);scales.append(group_scale);report["groups"][name]=group_report
    np.savez(output/"operators.npz",A=np.array(ops),G=np.array(invs),reference=np.array(refs),
        voltage_scale=np.array(scales),valid=valid,group_names=np.array(names),sigma_scale=ss,epsilon_scale=es)
    (output/"physics_verification.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
    return report

class Physics:
    def __init__(self,path,device):
        with np.load(path) as z:
            self.A=torch.from_numpy(z["A"]).to(device)
            self.valid=torch.from_numpy(z["valid"]).to(device)
            self.sigma_scale=float(z["sigma_scale"]);self.epsilon_scale=float(z["epsilon_scale"])
        self.n=int(self.valid.sum())
    def predict(self,sigma,epsilon,groups):
        # Disable autocast for large adjoint/forward sums.
        with torch.autocast(device_type=sigma.device.type,enabled=False):
            x=torch.cat([sigma.float()[:,:,self.valid],epsilon.float()[:,:,self.valid]],-1)
            out=x.new_zeros((len(x),2,2048))
            for g in range(self.A.shape[0]):
                idx=(groups==g).nonzero().flatten()
                if len(idx):
                    out[idx]=torch.stack([x[idx,f] @ self.A[g,f].T for f in range(2)],1)
            return out
    def loss(self,sigma,epsilon,dv,groups):
        pred=self.predict(sigma,epsilon,groups)
        denom=dv.float().square().mean((1,2)).clamp_min(1e-5)
        return (((pred-dv.float()).square().mean((1,2)))/denom).mean()
    def backproject(self,residual,groups):
        with torch.autocast(device_type=residual.device.type,enabled=False):
            bp=residual.new_zeros((len(residual),self.n),dtype=torch.float32)
            for g in range(self.A.shape[0]):
                idx=(groups==g).nonzero().flatten()
                if len(idx):
                    A=self.A[g,0,:,:self.n]
                    bp[idx]=(residual[idx,0].float()@A)/A.square().sum(0).clamp_min(1e-12)
            image=bp.new_zeros((len(bp),1,64,64));image[:,0,self.valid]=bp
            q=torch.quantile(image[:,0,self.valid].abs(),.985,dim=1).clamp_min(1e-6)
            return (image/q[:,None,None,None]).clamp(-5,5)

