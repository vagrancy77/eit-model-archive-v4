from pathlib import Path
import datetime,os,json,time,hashlib,random
import numpy as np
import torch

def atomic_json(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_name(path.name+".tmp."+str(os.getpid()))
    temp.write_text(json.dumps(value,indent=2,ensure_ascii=False),encoding="utf-8")
    for _ in range(100):
        try:os.replace(temp,path);return
        except PermissionError:time.sleep(.1)
    raise RuntimeError("Status file remains locked")
class Reporter:
    def __init__(self,run):
        self.run=Path(run);self.run.mkdir(parents=True,exist_ok=True);self.started=time.time();self.state={}
    def __call__(self,**changes):
        if changes.get("phase",self.state.get("phase"))!=self.state.get("phase"):
            for key in ("epoch","epochs","batch","batches","loss","loss_components","gradient_norm","lr","global_step","validation","validation_pinball","completed","total","partition"):
                self.state.pop(key,None)
        self.state.update(changes)
        self.state.update(pid=os.getpid(),updated_at=datetime.datetime.now().astimezone().isoformat(),
                          elapsed_seconds=time.time()-self.started)
        atomic_json(self.run/"status.json",self.state)
        with (self.run/"events.jsonl").open("a",encoding="utf-8") as f:
            f.write(json.dumps(self.state,ensure_ascii=False)+"\n")
def seed_all(seed):
    random.seed(seed);np.random.seed(seed);torch.manual_seed(seed)
    if torch.cuda.is_available():torch.cuda.manual_seed_all(seed)
def rng_state():
    return {"python":random.getstate(),"numpy":np.random.get_state(),"torch":torch.get_rng_state(),
            "cuda":torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None}
def restore_rng(s):
    random.setstate(s["python"]);np.random.set_state(s["numpy"]);torch.set_rng_state(s["torch"].cpu())
    if s["cuda"] is not None:torch.cuda.set_rng_state_all([x.cpu() for x in s["cuda"]])
def save_checkpoint(path,model,optimizer,scheduler,scaler,epoch,next_batch,step,best,config):
    path=Path(path);temp=path.with_suffix(".tmp.pt")
    torch.save({"model":model.state_dict(),"optimizer":optimizer.state_dict() if optimizer else None,
        "scheduler":scheduler.state_dict() if scheduler else None,"scaler":scaler.state_dict() if scaler else None,
        "epoch":epoch,"next_batch":next_batch,"global_step":step,"best":best,"config":config,
        "rng":rng_state()},temp);os.replace(temp,path)
def load_weights(model,path,device):
    checkpoint=torch.load(path,map_location=device,weights_only=False)
    model.load_state_dict(checkpoint["model"]);return checkpoint
def to_device(batch,device):
    return {k:(v.to(device,non_blocking=True) if torch.is_tensor(v) else v) for k,v in batch.items()}
def model_counts(v4,local,gate):
    count=lambda m:sum(p.numel() for p in m.parameters())
    return {"v4":count(v4),"local":count(local),"gate":count(gate),"total":count(v4)+count(local)+count(gate)}
def code_manifest(project):
    project=Path(project);files={}
    for p in project.rglob("*"):
        if p.is_file() and p.suffix in (".py",".java",".json",".md",".ps1",".txt") and not any(x in p.parts for x in ("runs","cache","operators","reference_exports","__pycache__")):
            if p.name in ("MANIFEST.json","supervisor_status.json","self_test_report.json","TRAINING_START_VERIFICATION.json"):continue
            files[p.relative_to(project).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
    atomic_json(project/"MANIFEST.json",{"files":files})
def verify_manifest(project):
    project=Path(project);files=json.loads((project/"MANIFEST.json").read_text(encoding="utf-8"))["files"]
    for name,h in files.items():
        if hashlib.sha256((project/name).read_bytes()).hexdigest()!=h:raise RuntimeError("Source changed: "+name)
    return {"status":"PASS","verified_files":len(files)}

