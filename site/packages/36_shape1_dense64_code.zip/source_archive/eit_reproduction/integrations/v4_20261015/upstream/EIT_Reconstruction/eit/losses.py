import torch
import torch.nn.functional as F
from .risk import iou_per_case

def masked_mean(x,fov): return (x*fov).sum()/(fov.sum()*x.shape[1]).clamp_min(1)
def dice(p,y,fov):
    p=p*fov; y=y*fov; dims=(1,2,3)
    return (1-(2*(p*y).sum(dims)+1)/((p+y).sum(dims)+1)).mean()
def binary(p,y,fov):
    # Probability BCE is unsafe under CUDA autocast; retain gradients in FP32.
    with torch.autocast(device_type=p.device.type,enabled=False):
        p=p.float();y=y.float();fov=fov.float()
        return masked_mean(F.binary_cross_entropy(p.clamp(1e-5,1-1e-5),y,reduction="none"),fov)+dice(p,y,fov)
def case_binary(p,y):
    with torch.autocast(device_type=p.device.type,enabled=False):
        return F.binary_cross_entropy(p.float().clamp(1e-5,1-1e-5),y.float())
def erode(x): return -F.max_pool2d(-x,3,1,1)
def soft_skeleton(x,steps=12):
    opened=F.max_pool2d(erode(x),3,1,1); skeleton=F.relu(x-opened)
    for _ in range(steps):
        x=erode(x); delta=F.relu(x-F.max_pool2d(erode(x),3,1,1))
        skeleton=skeleton+F.relu(delta-skeleton*delta)
    return skeleton
def cldice(p,y,fov):
    p=p*fov; y=y*fov; sp=soft_skeleton(p); sy=soft_skeleton(y); dims=(1,2,3)
    precision=((sp*y).sum(dims)+1)/(sp.sum(dims)+1)
    sensitivity=((sy*p).sum(dims)+1)/(sy.sum(dims)+1)
    return (1-2*precision*sensitivity/(precision+sensitivity+1e-6)).mean()
def depth(x,steps=12):
    result=x
    for _ in range(steps): x=erode(x); result=result+x
    return result
def boundary_loss(p,y,fov):
    return masked_mean((p[:,:,:,1:]-p[:,:,:,:-1]-(y[:,:,:,1:]-y[:,:,:,:-1])).abs(),fov[:,:,:,1:])+\
           masked_mean((p[:,:,1:,:]-p[:,:,:-1,:]-(y[:,:,1:,:]-y[:,:,:-1,:])).abs(),fov[:,:,1:,:])
def v4_loss(out,batch,physics,weights):
    y=batch["mask"]; fov=batch["fov"]; labels=batch["class"]
    # Base lesion is truth plus the deliberately removed concavity.
    base_y=(y+batch["cutout"]).clamp_max(1)
    lesion_class=labels.flatten(1).amax(1)[:,None,None]
    base_labels=torch.where(batch["cutout"][:,0]>.5,lesion_class,labels)
    ce=F.cross_entropy(out["base_logits"],base_labels,weight=y.new_tensor([.2,1,1]),reduction="none")[:,None]
    final_ce=F.nll_loss(out["final"].clamp_min(1e-6).log(),labels,weight=y.new_tensor([.2,1,1]),reduction="none")[:,None]
    ordinary=(batch["cutout"].sum((1,2,3))==0).float()[:,None,None,None]
    target_case=(1-ordinary)
    components={
        "base_ce":masked_mean(ce,fov),"final_ce":masked_mean(final_ce,fov),
        "dice":dice(out["foreground"],y,fov),
        "sdf":masked_mean(F.smooth_l1_loss(out["sdf"],batch["sdf"],reduction="none"),fov),
        "boundary":boundary_loss(out["foreground"],y,fov),
        "conductivity":masked_mean(F.smooth_l1_loss(out["sigma"],batch["sigma"],reduction="none"),fov),
        "permittivity":masked_mean(F.smooth_l1_loss(out["epsilon"],batch["epsilon"],reduction="none"),fov),
        "physics":physics.loss(out["sigma"],out["epsilon"],batch["dv"],batch["group"]),
        "cutout":binary(out["raw_cutout"],batch["cutout"],fov),
        "mouth":binary(out["mouth"],batch["mouth"],fov),
        "cldice":cldice(out["foreground"],y,fov),
        "depth":masked_mean((depth(out["raw_cutout"])-depth(batch["cutout"])).abs(),fov)/12,
        "area":((out["effective_cutout"]*base_y).sum((1,2,3))-batch["cutout"].sum((1,2,3))).abs().mean()/4096,
        "ordinary":masked_mean(out["effective_cutout"]*ordinary,fov),
        "gate":case_binary(out["case_gate"],target_case)+binary(out["local_gate"],batch["cutout"],fov)}
    total=sum(weights[k]*v for k,v in components.items())
    return total,components

def local_loss(local,anchor,batch,physics,weights):
    fov=batch["fov"]; truth=batch["mask"]; a=anchor["final"][:,1:].sum(1,keepdim=True)
    oracle=(a.detach()>=.5).float()*(1-truth)*fov
    c=local["candidate"][:,1:].sum(1,keepdim=True)
    ordinary=(batch["cutout"].sum((1,2,3))==0).float()[:,None,None,None]
    components={"removal":binary(local["raw_removal"],oracle,fov),
        "mouth":binary(local["mouth"],batch["mouth"],fov),
        "confidence":binary(local["confidence"],oracle,fov),
        "dice":dice(c,truth,fov),"final_ce":masked_mean(
            F.nll_loss(local["candidate"].clamp_min(1e-6).log(),batch["class"],reduction="none")[:,None],fov),
        "protection":masked_mean(local["removal"]*truth,fov),
        "ordinary":masked_mean(local["removal"]*ordinary,fov),
        "cldice":cldice(c,truth,fov),
        "depth":masked_mean((depth(local["raw_removal"])-depth(oracle)).abs(),fov)/12,
        "area":(local["removal"].sum((1,2,3))-oracle.sum((1,2,3))).abs().mean()/4096,
        "physics":physics.loss(anchor["sigma"]*(1-local["removal"]),
            anchor["epsilon"]*(1-local["removal"]),batch["dv"],batch["group"])}
    return sum(weights[k]*v for k,v in components.items()),components

def metrics(prob,batch):
    fg=prob[:,1:].sum(1,keepdim=True)
    iou=iou_per_case(fg*batch["fov"],batch["mask"])
    dice_score=1-dice(fg,batch["mask"],batch["fov"])
    return {"iou":iou.mean(),"dice":dice_score}

