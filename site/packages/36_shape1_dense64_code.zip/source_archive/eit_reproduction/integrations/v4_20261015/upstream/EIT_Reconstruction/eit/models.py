"""PDF architecture with explicit ADJACENT32 dual-frequency adaptation."""
import torch
from torch import nn
import torch.nn.functional as F

FEATURE_CHANNELS = ["p_background","p_low","p_high","entropy","sdf",
    "raw_cutout","connected_cutout","mouth","effective_cutout","delta_sigma_10k",
    "linear_normalized","smooth_7","edge","physical_backprojection","fov"]

class ResidualBlock(nn.Module):
    def __init__(self, ci, co, stride=1, dilation=1, dropout=.05):
        super().__init__()
        groups = min(8, co)
        self.body = nn.Sequential(
            nn.Conv2d(ci, co, 3, stride, dilation, dilation=dilation, bias=False),
            nn.GroupNorm(groups, co), nn.SiLU(),
            nn.Dropout2d(dropout),
            nn.Conv2d(co, co, 3, padding=dilation, dilation=dilation, bias=False),
            nn.GroupNorm(groups, co))
        self.skip = nn.Identity() if ci==co and stride==1 else nn.Conv2d(ci,co,1,stride,bias=False)
    def forward(self,x): return F.silu(self.body(x)+self.skip(x))

class Up(nn.Module):
    def __init__(self,ci,skip,co,dropout):
        super().__init__(); self.block=ResidualBlock(ci+skip,co,dropout=dropout)
    def forward(self,x,skip):
        return self.block(torch.cat([F.interpolate(x,size=skip.shape[-2:],mode="bilinear",align_corners=False),skip],1))

def connected_removal(raw, mouth, foreground, fov, iterations=64):
    """8-neighbour max-pool reachability; hard support, differentiable amplitudes.
    Only background pixels connected to FOV exterior can seed propagation.
    Predicted mouth selects the entry, and raw>=0.5 selects allowed cut pixels.
    Thresholded support is deliberately a hard constraint; losses supervise raw.
    """
    with torch.no_grad():
        inside=fov>.5; fg=(foreground>=.5)&inside
        bg=~fg
        outside=~inside
        # The exterior ring exists in the square 64x64 grid.
        reachable=outside.float()
        for _ in range(iterations):
            reachable=torch.maximum(reachable, F.max_pool2d(reachable,3,1,1)*bg.float())
        boundary_bg=(reachable>.5)&inside
        entry=(F.max_pool2d(boundary_bg.float(),3,1,1)>.5)&(mouth>.5)
        support=(raw>=.5)&inside
        grow=(entry&support).float()
        for _ in range(iterations):
            grow=torch.maximum(grow,F.max_pool2d(grow,3,1,1)*support.float())
    return raw*grow*fov

class V4(nn.Module):
    def __init__(self,base=64,dropout=.05,propagation=64):
        super().__init__(); self.propagation=propagation
        b=base
        self.image_encoder=nn.ModuleList([
            ResidualBlock(7,b,dropout=dropout),ResidualBlock(b,2*b,2,dropout=dropout),
            ResidualBlock(2*b,4*b,2,dropout=dropout),ResidualBlock(4*b,8*b,2,dropout=dropout)])
        self.voltage_encoder=nn.Sequential(
            ResidualBlock(4,32,dropout=dropout),ResidualBlock(32,64,2,dropout=dropout),
            ResidualBlock(64,128,2,dropout=dropout),ResidualBlock(128,256,2,dropout=dropout))
        self.fusion=nn.Sequential(ResidualBlock(8*b+256,8*b,dropout=dropout),
                                  ResidualBlock(8*b,8*b,dropout=dropout))
        self.decoder=nn.ModuleList([Up(8*b,4*b,4*b,dropout),Up(4*b,2*b,2*b,dropout),Up(2*b,b,b,dropout)])
        self.base_head=nn.Conv2d(b,3,1); self.sdf_head=nn.Conv2d(b,1,1)
        # Two frequencies; permittivity is an explicitly documented auxiliary head.
        self.sigma_head=nn.Conv2d(b,2,1); self.epsilon_head=nn.Conv2d(b,2,1)
        nn.init.zeros_(self.sigma_head.weight);nn.init.zeros_(self.sigma_head.bias)
        nn.init.zeros_(self.epsilon_head.weight);nn.init.zeros_(self.epsilon_head.bias)
        self.cutout_head=nn.Conv2d(b,1,1); self.mouth_head=nn.Conv2d(b,1,1)
        self.local_gate_head=nn.Conv2d(b,1,1)
        self.case_gate_head=nn.Sequential(nn.AdaptiveAvgPool2d(1),nn.Flatten(),nn.Linear(8*b,1))
    def forward(self,image,voltage):
        fov=image[:,-1:]; skips=[]; x=image
        for block in self.image_encoder: x=block(x); skips.append(x)
        v=self.voltage_encoder(voltage)
        v=F.interpolate(v,size=x.shape[-2:],mode="bilinear",align_corners=False)
        x=self.fusion(torch.cat([x,v],1)); case_gate=self.case_gate_head(x).sigmoid()[:,:,None,None]
        for block,skip in zip(self.decoder,reversed(skips[:-1])): x=block(x,skip)
        logits=self.base_head(x); base=logits.softmax(1)
        base=torch.cat([1-fov+base[:,:1]*fov,base[:,1:]*fov],1)
        raw=self.cutout_head(x).sigmoid()*fov
        mouth=self.mouth_head(x).sigmoid()*fov
        local=self.local_gate_head(x).sigmoid()*fov
        conn=connected_removal(raw,mouth,base[:,1:].sum(1,keepdim=True),fov,self.propagation)
        effective=conn*local*case_gate
        fg=base[:,1:]*(1-effective)
        final=torch.cat([1-fg.sum(1,keepdim=True),fg],1)
        return {"base_logits":logits,"base":base,"final":final,
            "foreground":final[:,1:].sum(1,keepdim=True),
            "sdf":self.sdf_head(x)*fov,"sigma":self.sigma_head(x)*fov,
            "epsilon":self.epsilon_head(x)*fov,"raw_cutout":raw,"connected_cutout":conn,
            "mouth":mouth,"effective_cutout":effective,"local_gate":local,"case_gate":case_gate}

class LocalTopologyCorrectorV6(nn.Module):
    def __init__(self,base=32,dropout=.05,propagation=64,alpha=1.0):
        super().__init__(); self.propagation=propagation; self.alpha=alpha; b=base
        self.encoder=nn.ModuleList([ResidualBlock(15,b,dropout=dropout),
            ResidualBlock(b,2*b,2,dropout=dropout),ResidualBlock(2*b,4*b,2,dropout=dropout)])
        self.context=nn.Sequential(ResidualBlock(4*b,8*b,2,dropout=dropout),
            ResidualBlock(8*b,8*b,dilation=2,dropout=dropout),
            ResidualBlock(8*b,8*b,dilation=4,dropout=dropout))
        self.decoder=nn.ModuleList([Up(8*b,4*b,4*b,dropout),Up(4*b,2*b,2*b,dropout),Up(2*b,b,b,dropout)])
        self.removal_head=nn.Conv2d(b,1,1); self.mouth_head=nn.Conv2d(b,1,1)
        self.confidence_head=nn.Conv2d(b,1,1)
    def forward(self,features,anchor):
        fov=features[:,-1:]; x=features; skips=[]
        for block in self.encoder: x=block(x); skips.append(x)
        x=self.context(x)
        for block,skip in zip(self.decoder,reversed(skips)): x=block(x,skip)
        raw=self.removal_head(x).sigmoid()*fov
        mouth=self.mouth_head(x).sigmoid()*fov
        confidence=self.confidence_head(x).sigmoid()*fov
        connected=connected_removal(raw,mouth,anchor[:,1:].sum(1,keepdim=True),fov,self.propagation)
        removal=self.alpha*connected*confidence
        fg=anchor[:,1:]*(1-removal)
        candidate=torch.cat([1-fg.sum(1,keepdim=True),fg],1)
        return {"raw_removal":raw,"mouth":mouth,"confidence":confidence,
                "connected_removal":connected,"removal":removal,"candidate":candidate}

def make_v6_features(anchor,image,physical_backprojection):
    """No ground truth argument is accepted here."""
    p=anchor["final"]; entropy=-(p*p.clamp_min(1e-7).log()).sum(1,keepdim=True)/1.098612288668
    channels=[p,entropy,anchor["sdf"],anchor["raw_cutout"],anchor["connected_cutout"],
        anchor["mouth"],anchor["effective_cutout"],anchor["sigma"][:,:1],
        image[:,:1],image[:,2:3],image[:,5:6],physical_backprojection,image[:,-1:]]
    result=torch.cat(channels,1)
    assert result.shape[1]==15
    return result

class DualRiskQuantileGate(nn.Module):
    def __init__(self,dropout=.1):
        super().__init__()
        self.register_buffer("feature_mean",torch.zeros(56))
        self.register_buffer("feature_std",torch.ones(56))
        self.register_buffer("calibration",torch.zeros(3,3))
        self.mlp=nn.Sequential(nn.Linear(56,128),nn.LayerNorm(128),nn.SiLU(),nn.Dropout(dropout),
            nn.Linear(128,96),nn.LayerNorm(96),nn.SiLU(),nn.Dropout(dropout),nn.Linear(96,9))
    def forward(self,features):
        raw=self.mlp((features-self.feature_mean)/self.feature_std)
        raw=raw.view(-1,3,3)
        # Ordered quantiles by construction: q20, q50, q80.
        median=raw[:,:,0]; lower=median-F.softplus(raw[:,:,1]); upper=median+F.softplus(raw[:,:,2])
        return (torch.stack([lower,median,upper],-1)+self.calibration).sort(dim=-1).values

def route(anchor,candidate,quantiles,iou_threshold=.006,deletion_threshold=.05):
    accepted=(quantiles[:,0,0]>0)&(quantiles[:,1,2]<=iou_threshold)&(quantiles[:,2,2]<=deletion_threshold)
    # Exact elementwise anchor fallback; do not reconstruct/renormalize rejected cases.
    return torch.where(accepted[:,None,None,None],candidate,anchor),accepted

