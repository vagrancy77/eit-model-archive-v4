"""Isolated experiment utilities. Original project is read-only."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import json, time, hashlib, datetime, sys
from pathlib import Path
import numpy as np
import torch
from scipy import ndimage

ROOT=Path(__file__).resolve().parent
PROJECT=ROOT.parent/'EIT_Reconstruction'
RUN=PROJECT/'runs/seed_20260911'
sys.path.insert(0,str(PROJECT))
CFG=json.loads((PROJECT/'config.json').read_text(encoding='utf-8'))
SEED=20260911
torch.set_num_threads(6)

def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def write(p,obj):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_name(p.name+'.'+str(os.getpid())+'.tmp')
    tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    os.replace(tmp,p)
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def state(method,**kw):
    p=ROOT/'results'/method/'status.json'
    s=read(p) if p.exists() else {'method':method,'started':time.time()}
    if kw.get('status') in ('RUNNING','COMPLETE','TRAINED','WAITING','QA_PENDING'):s.pop('error',None)
    s.update(kw);s.update(pid=os.getpid(),updated=time.time(),timestamp=datetime.datetime.now().isoformat())
    write(p,s)
def strict():
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    torch.backends.cudnn.benchmark=False
    torch.backends.cudnn.deterministic=True
    torch.use_deterministic_algorithms(True)

def protect():
    p=ROOT/'protected_project_sha256.json'
    files=list((PROJECT/'eit').glob('*.py'))+[PROJECT/'run_model.py',PROJECT/'config.json',PROJECT/'operators/operators.npz',PROJECT/'cache/splits.json',PROJECT/'cache/voltage_normalization.npz']
    files += [RUN/stage/name for stage in ['v4','local','gate'] for name in ['best.pt','last.pt','history.json','complete.json']]
    hashes={str(f):sha(f) for f in files}
    if p.exists():
        assert read(p)==hashes,'Original project changed since benchmark snapshot'
    else:write(p,hashes)
    return hashes

def metric(prob,truth,fov,cut,sigma=None,true_sigma=None,epsilon=None,true_epsilon=None):
    pred=(prob>=.5)&fov;truth=truth.astype(bool)&fov;cut=cut.astype(bool)&fov
    inter=int((pred&truth).sum()); union=int((pred|truth).sum())
    out={'iou':inter/max(union,1),'dice':2*inter/max(int(pred.sum()+truth.sum()),1),
         'accuracy':float((pred[fov]==truth[fov]).mean()),'lesion_recall':inter/max(int(truth.sum()),1),
         'wrong_deletion':float((truth&~pred).sum()/max(truth.sum(),1))}
    pb=pred&~ndimage.binary_erosion(pred,structure=np.ones((3,3)))
    tb=truth&~ndimage.binary_erosion(truth,structure=np.ones((3,3)))
    if pb.any() and tb.any():
        dp=ndimage.distance_transform_edt(~pb);dt=ndimage.distance_transform_edt(~tb)
        pr=float((dt[pb]<=1).mean());re=float((dp[tb]<=1).mean())
        out.update(boundary_f1=2*pr*re/max(pr+re,1e-12),hd95_pixels=float(np.percentile(np.r_[dt[pb],dp[tb]],95)))
    else:out.update(boundary_f1=0.,hd95_pixels=float(np.hypot(63,63)))
    if cut.any():
        ec=(truth|cut)&~pred
        out.update(cutout_iou=float((ec&cut).sum()/max((ec|cut).sum(),1)),cutout_recall=float((cut&~pred).sum()/cut.sum()))
    else:out.update(cutout_iou=None,cutout_recall=None)
    if sigma is not None:
        out['sigma_mae_S_per_m']=float(np.abs(sigma[:,fov]-true_sigma[:,fov]).mean()*.2)
        out['sigma_relative_l2']=float(np.linalg.norm(sigma[:,fov]-true_sigma[:,fov])/max(np.linalg.norm(true_sigma[:,fov]),1e-12))
    if epsilon is not None:
        out['epsilon_mae']=float(np.abs(epsilon[:,fov]-true_epsilon[:,fov]).mean()*50000)
    return out

def summarize(rows):
    keys=[k for k,v in rows[0].items() if isinstance(v,(float,int)) or v is None]
    def group(rr):
        return {k:{'mean':float(np.mean([r[k] for r in rr if r[k] is not None])),
                   'std':float(np.std([r[k] for r in rr if r[k] is not None])),
                   'count':sum(r[k] is not None for r in rr)}
                for k in keys if any(r[k] is not None for r in rr)}
    return {'overall':group(rows),'by_class':{c:group([r for r in rows if r['shape_class']==c]) for c in 'ABCD'},'count':len(rows)}

def pack():
    meta=read(ROOT/'data/pack.json')
    return meta,{k:np.load(ROOT/'data'/(k+'.npy'),mmap_mode='r') for k in meta['arrays']}

def save_predictions(method,ids,prob,sigma=None,epsilon=None,extra=None):
    folder=ROOT/'results'/method/'predictions';folder.mkdir(parents=True,exist_ok=True)
    for j,cid in enumerate(ids):
        d={'prob':np.asarray(prob[j],np.float32)}
        if sigma is not None:d['sigma']=np.asarray(sigma[j],np.float32)
        if epsilon is not None:d['epsilon']=np.asarray(epsilon[j],np.float32)
        if extra:
            for key,value in extra.items():d[key]=np.asarray(value[j])
        np.savez_compressed(folder/(cid+'.npz'),**d)

def finish_metrics(method,rows,**info):
    assert len(rows)==576 and len({r['case_id'] for r in rows})==576
    doc={'status':'PASS','method':method,'split':'test','seed':SEED,**info,**summarize(rows),'cases':rows}
    write(ROOT/'results'/method/'metrics.json',doc)
    state(method,status='COMPLETE',phase='完整测试已完成',completed=576,total=576,mean_iou=doc['overall']['iou']['mean'])
    return doc
