"""Rebuild homogeneous COMSOL operators with the same archived generator source."""
from pathlib import Path
import argparse,sys,subprocess,os,json,shutil
import numpy as np
from assemble_reference import assemble_reference

def hidden():
    if os.name!='nt':return {}
    info=subprocess.STARTUPINFO();info.dwFlags|=subprocess.STARTF_USESHOWWINDOW;info.wShowWindow=0
    return {'startupinfo':info,'creationflags':subprocess.CREATE_NO_WINDOW}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--project',type=Path,required=True);a=ap.parse_args()
    project=a.project;cfg=json.loads((project/'config.json').read_text(encoding='utf-8'))
    runtime=Path(cfg['runtime_root']);work=runtime/'COMSOL_reference';work.mkdir(exist_ok=True)
    source=project/'reference';build=work/'build';build.mkdir(exist_ok=True)
    sys.path.insert(0,str(source));from comsol_classpath import build_classpath,write_argfile
    comsol=Path(cfg['comsol_install'])
    for name in ('EitBatchGenerator.java','ReferenceJacobianExporter.java'):shutil.copy2(source/name,work/name)
    cp=write_argfile(work/'classpath.argfile',build_classpath(comsol/'plugins',build))
    subprocess.run([str(comsol/'java/win64/jre/bin/javac.exe'),'@'+str(cp),'-encoding','UTF-8','-d',str(build),str(work/'EitBatchGenerator.java'),str(work/'ReferenceJacobianExporter.java')],check=True,**hidden())
    root=project/'reference_exports';root.mkdir(exist_ok=True);dataset=Path(cfg['dataset'])
    rows=json.loads((dataset/'splits.json').read_text(encoding='utf-8'))['splits']
    train_ids={r['case_id'] for r in rows if r['split']=='train'}
    for cid,group in [('A_000001','Fat'),('A_000055','Muscle')]:
        if cid not in train_ids:raise RuntimeError('Reference representative must be from train')
        with np.load(dataset/'cases'/(cid+'.npz')) as z:params=json.loads(str(z['parameters_json']))
        if params['background_material']!=group:raise RuntimeError('Reference material mismatch')
        param=work/(group+'_parameters.json');param.write_text(json.dumps(params,ensure_ascii=True),encoding='ascii')
        output=root/group;output.mkdir(exist_ok=True);shutil.copy2(param,output/'reference_parameters.json')
        env=os.environ.copy();env['TEMP']=str(runtime/'temp');env['TMP']=env['TEMP'];env['OMP_NUM_THREADS']='4'
        with (output/'export.log').open('w',encoding='utf-8') as log:
            subprocess.run([str(comsol/'java/win64/jre/bin/java.exe'),'-Xmx3g','-Djava.awt.headless=true','-Djava.io.tmpdir='+str(runtime/'temp'),'-Djava.library.path='+str(comsol/'lib/win64')+';'+str(comsol/'bin/win64'),'@'+str(cp),'ReferenceJacobianExporter',str(param),str(output)],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,**hidden())
    assemble_reference(root,dataset)
if __name__=='__main__':main()
