from pathlib import Path
import struct,json,csv
import numpy as np
from scipy import sparse
def table(path):
    out=np.zeros((2,32,32),complex)
    with path.open() as f:
        for r in csv.DictReader(f):
            fi=0 if float(r['frequency_hz'])==10000 else 1
            out[fi,int(r['drive_idx'])-1,int(r['electrode_id'])-1]=complex(float(r['voltage_real_V']),float(r['voltage_imag_V']))
    neg=(np.arange(32)+1)%32
    return out-out[:,np.arange(32),neg][:,:,None]

def assemble_reference(root,dataset):
    ROOT=Path(root);MIN=Path(dataset)
    with np.load(MIN/'grid.npz') as g:
        valid=g['valid_mask'];index=np.full(valid.shape,-1);index[valid]=np.arange(valid.sum())
    out={'status':'PASS','kind':'same_COMSOL_generator_gauss_adjoint','checks':[]}
    for group in ('Fat','Muscle'):
        folder=ROOT/group;buf=(folder/'gauss_fields.bin').read_bytes();ns,ng=struct.unpack_from('>ii',buf,0)
        meta=np.frombuffer(buf,dtype=np.dtype([('x','>f8'),('y','>f8'),('element','>i4')]),count=ng,offset=8)
        offset=8+ng*20;E=np.zeros((2,32,ng,2),complex)
        for s in range(ns):
            freq,drive=struct.unpack_from('>di',buf,offset);offset+=12
            vals=np.frombuffer(buf,dtype='>f8',count=ng*4,offset=offset).reshape(ng,4);offset+=ng*32
            fi=0 if freq==10000 else 1;E[fi,drive-1,:,0]=vals[:,0]+1j*vals[:,1];E[fi,drive-1,:,1]=vals[:,2]+1j*vals[:,3]
        vertices=np.loadtxt(folder/'mesh_vertices.csv',delimiter=',');tri=np.loadtxt(folder/'mesh_triangles.csv',delimiter=',',dtype=int)
        ve=meta['element'].astype(int)-1;coords=vertices[tri[ve]];point=np.c_[meta['x'],meta['y']]
        a=coords[:,1]-coords[:,0];b=coords[:,2]-coords[:,0];q=point-coords[:,0]
        det=a[:,0]*b[:,1]-a[:,1]*b[:,0]
        u=(q[:,0]*b[:,1]-q[:,1]*b[:,0])/det;v=(a[:,0]*q[:,1]-a[:,1]*q[:,0])/det
        bary=np.c_[1-u-v,u,v];counts=np.unique(np.bincount(ve),return_counts=True)
        print(group,'gauss points',ng,'triangles',len(tri),'bary range',bary.min(),bary.max(),'counts',counts,flush=True)
        # Dunavant degree-4 triangle rule: six points, two distinct positive weights.
        from itertools import permutations
        reference=np.array(list(dict.fromkeys(permutations((.445948490915965,.445948490915965,.108103018168070))))+list(dict.fromkeys(permutations((.091576213509771,.091576213509771,.816847572980458)))))
        rank=np.argmin(((bary[:,None,:]-reference[None])**2).sum(2),axis=1)
        ref_u=reference[:,1];ref_v=reference[:,2]
        design=np.c_[np.ones(6),ref_u,ref_v,ref_u**2,ref_u*ref_v,ref_v**2]
        xy_all=np.zeros((len(tri),6,2));xy_all[ve,rank]=point
        if not all(len(set(rank[ve==e]))==6 for e in range(len(tri))):raise ValueError('Gauss correspondence is not one-to-one')
        coefficients=np.einsum('ij,tjk->tik',np.linalg.inv(design),xy_all)
        coeff=coefficients[ve];ru=ref_u[rank];rv=ref_v[rank]
        du=coeff[:,1]+2*coeff[:,3]*ru[:,None]+coeff[:,4]*rv[:,None]
        dv=coeff[:,2]+coeff[:,4]*ru[:,None]+2*coeff[:,5]*rv[:,None]
        jacdet=np.abs(du[:,0]*dv[:,1]-du[:,1]*dv[:,0])
        reference_weights=np.where(reference.min(1)>.1,.223381589678011,.109951743655322)/2
        weights=jacdet*reference_weights[rank]
        dx=.1/63;ix=np.rint((meta['x']+.05)/dx).astype(int);iy=np.rint((meta['y']+.05)/dx).astype(int)
        inside=(ix>=0)&(ix<64)&(iy>=0)&(iy<64)
        pixel=np.full(ng,-1,dtype=int);pixel[inside]=index[iy[inside],ix[inside]]
        keep=pixel>=0
        mapping=sparse.coo_matrix((weights[keep],(np.flatnonzero(keep),pixel[keep])),shape=(ng,int(valid.sum()))).tocsr()
        unit=np.zeros_like(E)
        for e in range(31):unit[:,e]=E[:,e:31].sum(1)/.00025
        J=np.zeros((2,32,32,int(valid.sum())),complex)
        for fi in range(2):
            for d in range(32):
                adj=unit[fi]-unit[fi,(d+1)%32]
                dot=-np.einsum('pk,epk->ep',E[fi,d],adj)
                J[fi,d]=np.asarray(mapping.T@dot.T).T
        ref=table(folder/'reference_electrode_voltage_complex.csv')
        params=json.loads((folder/'reference_parameters.json').read_text(encoding='utf-8'))
        with np.load(MIN/'cases'/(params['case_id']+'.npz')) as z:actual=z['background_voltage']
        without=table(folder/'without_contact_electrode_voltage_complex.csv')
        info={'reference_vs_actual_rmse':float(np.linalg.norm(ref-actual)/np.linalg.norm(actual)),'contact_removal_relative_difference':float(np.linalg.norm(ref-without)/np.linalg.norm(ref)),'group':group,'gauss_points':ng,'triangles':len(tri),'integration_order':4,'integrated_area_m2':float(weights.sum()),'probes':[]}
        for i in range(3):
            p=json.loads((folder/('probe_'+str(i)+'.json')).read_text());pix=index[p['iy'],p['ix']]
            fd=(table(folder/('probe_'+str(i)+'_electrode_voltage_complex.csv'))-ref)/p['step_S_per_m']
            predicted=J[:,:,:,pix];err=float(np.linalg.norm(fd-predicted)/np.linalg.norm(fd))
            info['probes'].append({'pixel':[p['iy'],p['ix']],'relative_error':err})
            for fi,freq in enumerate((10000,50000)):
                per_frequency=float(np.linalg.norm(fd[fi]-predicted[fi])/np.linalg.norm(fd[fi]))
                info['probes'][-1].setdefault('per_frequency',[]).append({'frequency_hz':freq,'relative_error':per_frequency})
                if per_frequency>.02:out['status']='FAIL'
            if err>.02:out['status']='FAIL'
        probe=json.loads((folder/'probe_0.json').read_text());pix=index[probe['iy'],probe['ix']]
        eps_fd=(table(folder/'probe_epsilon_electrode_voltage_complex.csv')-ref)/10
        info['epsilon_probe']=[]
        for fi,freq in enumerate((10000,50000)):
            eps_j=J[fi,:,:,pix]*(1j*2*np.pi*freq*8.8541878128e-12)
            eps_error=float(np.linalg.norm(eps_fd[fi]-eps_j)/np.linalg.norm(eps_fd[fi]))
            info['epsilon_probe'].append({'frequency_hz':freq,'relative_error':eps_error})
            if eps_error>.02:out['status']='FAIL'
        if info['reference_vs_actual_rmse']>1e-8:out['status']='FAIL'
        if abs(weights.sum()-np.pi*.05**2)/(np.pi*.05**2)>.001:out['status']='FAIL'
        print(json.dumps(info),flush=True);out['checks'].append(info)
        np.savez(folder/'gauss_reference_jacobian.npz',J=J.reshape(2,1024,-1),reference=ref)
    (ROOT/'gauss_reference_checks.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    if out['status']!='PASS':raise RuntimeError('Reference Jacobian audit failed')
    return out
