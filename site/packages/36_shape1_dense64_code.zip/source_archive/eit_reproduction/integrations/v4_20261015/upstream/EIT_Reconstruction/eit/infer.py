"""Inference accepts only terminal/background measurements and known reference material."""
from pathlib import Path
import json
import numpy as np
import torch
from .data import input_features
from .models import V4,LocalTopologyCorrectorV6,DualRiskQuantileGate,make_v6_features,route
from .physics import Physics
from .risk import extract_statistics
from .runtime import load_weights,atomic_json

@torch.no_grad()
def infer_case(project,config,input_path,background_material,seed,device,output,model='full'):
    project=Path(project);output=Path(output);output.mkdir(parents=True,exist_ok=True)
    with np.load(input_path,allow_pickle=False) as z:
        v=z['voltage'].copy() if 'voltage' in z else z['eit_voltage'].copy()
        bg=z['background_voltage'].copy() if 'background_voltage' in z else z['eit_background_voltage'].copy()
        freq=z['frequencies_hz'].copy()
    if v.shape!=(2,32,32) or bg.shape!=v.shape or not np.iscomplexobj(v) or not np.iscomplexobj(bg):raise ValueError('Require complex [2 frequencies,32 drives,32 measurements]')
    if not np.array_equal(freq,np.array([10000,50000])) or not np.isfinite(v).all() or not np.isfinite(bg).all():raise ValueError('Invalid frequency or measurement')
    negative=(np.arange(32)+1)%32
    v-=v[:,np.arange(32),negative][:,:,None];bg-=bg[:,np.arange(32),negative][:,:,None]
    with np.load(project/'operators/operators.npz') as z:
        names=list(z['group_names']);group=names.index(background_material)
        G=z['G'][group];scale=z['voltage_scale'][group];valid=z['valid']
    image,table,dv=input_features(v,bg,G,scale,valid)
    with np.load(project/'cache/voltage_normalization.npz') as z:table=(table-z['mean'])/z['std']
    image=torch.from_numpy(image[None]).to(device);table=torch.from_numpy(table[None]).to(device)
    dv=torch.from_numpy(dv[None]).to(device);groups=torch.tensor([group],device=device)
    physics=Physics(project/'operators/operators.npz',device)
    run=project/'runs'/f'seed_{seed}'
    v4=V4(config['v4_base'],config['dropout'],config['propagation_iterations']).to(device)
    load_weights(v4,run/'v4/best.pt',device);v4.eval()
    with torch.autocast(device_type=device.type,dtype=torch.bfloat16,enabled=device.type=='cuda'):
        anchor=v4(image,table);candidate=anchor['final'];final=anchor['final']
        removal=torch.zeros_like(anchor['foreground']);accepted=torch.tensor([False],device=device);quantiles=None
        if model!='v4':
            local=LocalTopologyCorrectorV6(config['local_base'],config['dropout'],config['propagation_iterations'],config['alpha']).to(device)
            load_weights(local,run/'local/best.pt',device);local.eval()
            pred=physics.predict(anchor['sigma'],anchor['epsilon'],groups)
            bp=physics.backproject(dv-pred,groups)
            corrected=local(make_v6_features(anchor,image,bp),anchor['final']);candidate=corrected['candidate']
            if model=='ungated':
                accepted=torch.tensor([True],device=device);final=candidate
            else:
                gate=DualRiskQuantileGate().to(device);load_weights(gate,run/'gate/best.pt',device);gate.eval()
                statistics=extract_statistics(anchor,corrected,image,bp,dv,pred);quantiles=gate(statistics)
                final,accepted=route(anchor['final'],candidate,quantiles,config['risk_thresholds']['iou_q80'],config['risk_thresholds']['deletion_q80'])
            removal=torch.where(accepted[:,None,None,None],corrected['removal'],removal)
    sigma=anchor['sigma']*(1-removal);epsilon=anchor['epsilon']*(1-removal)
    to_numpy=lambda x:x[0].float().cpu().numpy()
    probability=to_numpy(final)
    np.savez_compressed(output/'prediction.npz',class_probabilities=probability,
        foreground=probability[1:].sum(0,keepdims=True),predicted_mask=(probability[1:].sum(0)>=.5),
        sdf=to_numpy(anchor['sdf']),delta_sigma_S_per_m=to_numpy(sigma)*physics.sigma_scale,
        delta_epsilon=to_numpy(epsilon)*physics.epsilon_scale,
        anchor_class_probabilities=to_numpy(anchor['final']),candidate_class_probabilities=to_numpy(candidate),
        effective_removal=to_numpy(removal),linear_image=to_numpy(image[:,:1]),fov=valid,frequencies_hz=freq)
    residual=physics.predict(sigma,epsilon,groups)-dv
    result={'status':'PASS','model':model,'input':str(input_path),'background_material':background_material,
        'candidate_accepted':bool(accepted[0]),'quantiles':quantiles[0].float().cpu().tolist() if quantiles is not None else None,
        'risk_thresholds':config['risk_thresholds'],'relative_linear_voltage_residual':float(residual.square().mean().sqrt()/dv.square().mean().sqrt().clamp_min(1e-6)),
        'input_policy':'terminal and background voltages only; no truth labels or case internal FEM fields read'}
    atomic_json(output/'inference.json',result);return result
