"""Dataset adaptation and feature caching. Labels never enter input construction."""
from pathlib import Path
import json,hashlib
import numpy as np
from scipy import ndimage
import torch
from torch.utils.data import Dataset

def sha(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda:f.read(1024*1024),b""):h.update(block)
    return h.hexdigest()
def input_features(voltage,background,G,scale,valid):
    """Only terminal measurements + background + reference operator are accepted."""
    delta=(voltage-background)/scale[:,None,None]
    dv=np.concatenate([delta.real.reshape(2,-1),delta.imag.reshape(2,-1)],1).astype(np.float32)
    estimate=np.stack([G[f]@dv[f] for f in range(2)])
    n=int(valid.sum()); linear=np.zeros((64,64),dtype=np.float32)
    linear[valid]=estimate[:,:n].mean(0)
    values=linear[valid];median=float(np.median(values))
    linear[valid]-=median
    factor=max(float(np.quantile(np.abs(linear[valid]),.985)),1e-6)
    linear=(linear/factor).clip(-5,5);linear[~valid]=0
    def smooth(k):
        return ndimage.uniform_filter(linear,k)/np.maximum(ndimage.uniform_filter(valid.astype(np.float32),k),1e-6)*valid
    sm3=smooth(3);sm7=smooth(7)
    gx=ndimage.sobel(linear,axis=1)/8*valid;gy=ndimage.sobel(linear,axis=0)/8*valid
    edge=np.sqrt(gx*gx+gy*gy)*valid
    image=np.stack([linear,sm3,sm7,gx,gy,edge,valid.astype(np.float32)]).astype(np.float32)
    table=np.stack([delta[0].real.T,delta[0].imag.T,delta[1].real.T,delta[1].imag.T]).astype(np.float32)
    return image,table,dv

def prepare_cache(dataset,cache,operators,status=lambda **kw:None):
    dataset=Path(dataset);cache=Path(cache);cache.mkdir(parents=True,exist_ok=True)
    split=json.loads((dataset/"splits.json").read_text(encoding="utf-8"))
    with np.load(operators) as z:
        G=z["G"];scale=z["voltage_scale"];valid=z["valid"];names=list(z["group_names"])
        sigma_scale=float(z["sigma_scale"]);epsilon_scale=float(z["epsilon_scale"])
    signature={"source_manifest_sha256":sha(dataset/"MANIFEST.sha256.json"),
        "operator_sha256":sha(operators),"adapter_version":1}
    metadata=cache/"cache_manifest.json"
    if metadata.exists():
        saved=json.loads(metadata.read_text(encoding="utf-8"))
        if saved["signature"]!=signature:raise RuntimeError("Cache provenance differs; use a new cache directory")
        if all((cache/"cases"/(r["case_id"]+".npz")).exists() for r in split["splits"]):return saved
    (cache/"cases").mkdir(exist_ok=True)
    total=np.zeros((4,32,32),dtype=np.float64);sq=np.zeros_like(total);n=0
    for i,row in enumerate(split["splits"]):
        with np.load(dataset/row["file"],allow_pickle=False) as z:
            params=json.loads(str(z["parameters_json"]));group=names.index(params["background_material"])
            image,table,dv=input_features(z["voltage"],z["background_voltage"],G[group],scale[group],valid)
            sb=np.array([float(params["sig_b10"]),float(params["sig_b50"])])[:,None,None]
            eb=np.array([float(params["eps_b10"]),float(params["eps_b50"])])[:,None,None]
            sigma=np.where(valid,(z["conductivity_S_per_m"]-sb)/sigma_scale,0).astype(np.float32)
            epsilon=np.where(valid,(z["eps_r"]-eb)/epsilon_scale,0).astype(np.float32)
            np.savez_compressed(cache/"cases"/(row["case_id"]+".npz"),
                image=image,voltage=table,dv=dv,group=np.int64(group),
                mask=z["lesion_mask"][None].astype(np.float32),fov=valid[None].astype(np.float32),
                sdf=z["sdf"][None].astype(np.float32),cutout=z["cutout_mask"][None].astype(np.float32),
                mouth=z["mouth_mask"][None].astype(np.float32),electrical_class=z["electrical_class"].astype(np.int64),
                sigma=sigma,epsilon=epsilon)
        if row["split"]=="train":
            total+=table;sq+=table.astype(np.float64)**2;n+=1
        if i%32==0:status(phase="CACHE",completed=i+1,total=len(split["splits"]),message=row["case_id"])
    mean=total/n;std=np.sqrt(np.maximum(sq/n-mean*mean,0));std[std<1e-7]=1
    np.savez(cache/"voltage_normalization.npz",mean=mean.astype(np.float32),std=std.astype(np.float32),train_count=n)
    (cache/"splits.json").write_text(json.dumps(split,indent=2),encoding="utf-8")
    saved={"status":"PASS","signature":signature,"case_count":len(split["splits"]),"train_normalization_count":n,
        "input_keys":["image","voltage","dv","group"],"supervision_keys":["mask","sdf","cutout","mouth","class","sigma","epsilon"],
        "image_channels":["normalized_linear","smooth3","smooth7","sobel_x","sobel_y","edge","fov"],
        "voltage_channels":["real_10k","imag_10k","real_50k","imag_50k"],"voltage_axes":["channel","measuring_electrode","drive"]}
    metadata.write_text(json.dumps(saved,indent=2),encoding="utf-8")
    status(phase="CACHE",completed=len(split["splits"]),total=len(split["splits"]),message="PASS")
    return saved

class EITDataset(Dataset):
    def __init__(self,cache,split,limit=None,positions=None):
        self.cache=Path(cache)
        self.rows=[r for r in json.loads((self.cache/"splits.json").read_text(encoding="utf-8"))["splits"] if r["split"]==split]
        if positions is not None:self.rows=[r for r in self.rows if r["position_id"] in positions]
        if limit:self.rows=self.rows[:limit]
        with np.load(self.cache/"voltage_normalization.npz") as z:self.mean=z["mean"];self.std=z["std"]
    def __len__(self):return len(self.rows)
    def __getitem__(self,index):
        row=self.rows[index]
        with np.load(self.cache/"cases"/(row["case_id"]+".npz"),allow_pickle=False) as z:
            out={k:torch.from_numpy(z[k].copy()) for k in z.files if k not in ("electrical_class","group")}
            out["class"]=torch.from_numpy(z["electrical_class"].copy())
            out["group"]=torch.tensor(int(z["group"]),dtype=torch.int64)
            out["voltage"]=torch.from_numpy(((z["voltage"]-self.mean)/self.std).copy())
        out["case_id"]=row["case_id"];out["shape_class"]=row["shape_class"]
        return out

def assert_split_isolation(dataset):
    rows=json.loads((Path(dataset)/"splits.json").read_text(encoding="utf-8"))["splits"]
    groups={}
    ids=set()
    for r in rows:
        if r["case_id"] in ids:raise ValueError("Duplicate case ID")
        ids.add(r["case_id"]);groups.setdefault(r["position_id"],set()).add(r["split"])
    if any(len(x)>1 for x in groups.values()):raise ValueError("Position leakage across splits")
    return {s:sum(r["split"]==s for r in rows) for s in ("train","val","test")}

