"""Independent authorized v4 rerun; original v4/local/gate files stay intact.

Original training had a fixed 100-epoch cosine schedule, ending at zero LR.
This is a fresh same-seed experiment with a 300-epoch cosine schedule, not a
zero-LR continuation. Selection positions remain disjoint from calibration.
"""
from common import *
from eit.models import V4,LocalTopologyCorrectorV6,DualRiskQuantileGate
from eit.physics import Physics
from eit.data import EITDataset
from eit.train import loader,validation_roles
from eit.losses import v4_loss
from eit.runtime import seed_all,restore_rng,rng_state,to_device

KEY='project_v4_long_patience'
FOLDER=ROOT/'results'/KEY
POLICY={'maximum_total_epochs':300,'minimum_total_epochs':120,'patience':60,
        'minimum_iou_improvement':.0005,'selection':'selection288 mean hard IoU; FP32 TF32 false',
        'calibration_positions_reserved':True,'test_used_for_selection':False,
        'initialization':'fresh, same original seed; not a continuation',
        'learning_rate_schedule':'original AdamW 0.0003; cosine T_max extended from100 to300',
        'loss_weights_and_architecture_unchanged':True}

def init_model(cfg):
    # Match the original pipeline's RNG consumption before its first batch.
    seed_all(cfg['seed'])
    m=V4(cfg['v4_base'],cfg['dropout'],cfg['propagation_iterations']).cuda()
    local=LocalTopologyCorrectorV6(cfg['local_base'],cfg['dropout'],cfg['propagation_iterations'],cfg['alpha']).cuda()
    gate=DualRiskQuantileGate().cuda()
    del local,gate
    return m

@torch.inference_mode()
def evaluate(model,ds,cfg,physics,test=False):
    strict();model.eval();records=[];terms={};seen=0
    for b in loader(ds,cfg['batch_size']):
        b=to_device(b,'cuda');out=model(b['image'],b['voltage'])
        if not test:
            lv,lt=v4_loss(out,b,physics,cfg['loss_weights']['v4'])
            for k,v in {'total':lv,**lt}.items():terms[k]=terms.get(k,0)+float(v)*len(b['case_id'])
        prob=out['foreground'][:,0].cpu().numpy();sn=out['sigma'].cpu().numpy();en=out['epsilon'].cpu().numpy()
        if test:
            save_predictions(KEY,b['case_id'],prob,sn,en)
            volt=physics.predict(out['sigma'],out['epsilon'],b['group']).cpu().numpy()
        for j,cid in enumerate(b['case_id']):
            fov=b['fov'][j,0].cpu().numpy().astype(bool)
            m=metric(prob[j],b['mask'][j,0].cpu().numpy(),fov,b['cutout'][j,0].cpu().numpy(),sn[j],b['sigma'][j].cpu().numpy(),en[j],b['epsilon'][j].cpu().numpy())
            if test:
                dv=b['dv'][j].cpu().numpy();m['linear_voltage_residual']=float(np.linalg.norm(volt[j]-dv)/max(np.linalg.norm(dv),1e-12))
            records.append({'case_id':cid,'shape_class':b['shape_class'][j],**m})
        seen+=len(b['case_id'])
        if test:state(KEY,status='RUNNING',phase='新 v4 最佳权重完整测试',completed=seen,total=576)
    return records,summarize(records),{k:v/seen for k,v in terms.items()}

def checkpoint(path,model,opt,sched,epoch,best,best_epoch,monitor,bad,history,config):
    temp=path.with_suffix('.tmp.pt')
    torch.save({'model':model.state_dict(),'optimizer':opt.state_dict(),'scheduler':sched.state_dict(),
                'epoch':epoch,'best':best,'best_epoch':best_epoch,'monitor_best':monitor,'bad_epochs':bad,
                'history':history,'config':config,'rng':rng_state()},temp)
    os.replace(temp,path)

def main():
    protect();torch.set_num_threads(2);FOLDER.mkdir(parents=True,exist_ok=True)
    cfg=read(RUN/'resolved_config.json');roles=validation_roles(PROJECT/'cache',cfg['validation_seed'])
    config={'method':KEY,'original_config':cfg,'policy':POLICY,'validation_roles':roles,
            'parent_best_sha256':sha(RUN/'v4/best.pt'),'parent_last_sha256':sha(RUN/'v4/last.pt'),
            'cpu_threads':2,'note':'new standalone v4 only; frozen original v6 is not coupled to this anchor'}
    if (FOLDER/'config.json').exists():assert read(FOLDER/'config.json')==config
    write(FOLDER/'config.json',config)
    physics=Physics(PROJECT/'operators/operators.npz','cuda')
    train=EITDataset(PROJECT/'cache','train');val=EITDataset(PROJECT/'cache','val',positions=roles['selection_positions'])
    assert len(train)==2720 and len(val)==288
    model=init_model(cfg);opt=torch.optim.AdamW(model.parameters(),lr=cfg['lr']['v4'],weight_decay=cfg['weight_decay'])
    sched=torch.optim.lr_scheduler.CosineAnnealingLR(opt,T_max=POLICY['maximum_total_epochs'])
    last=FOLDER/'last.pt';first=1;best=-1.;monitor=-1.;bad=0;best_epoch=0;history=[];started=time.time()
    if last.exists():
        ck=torch.load(last,map_location='cuda',weights_only=False);assert ck['config']==config
        model.load_state_dict(ck['model']);opt.load_state_dict(ck['optimizer']);sched.load_state_dict(ck['scheduler']);restore_rng(ck['rng'])
        first=ck['epoch']+1;best=ck['best'];monitor=ck['monitor_best'];bad=ck['bad_epochs'];best_epoch=ck['best_epoch'];history=ck['history']
    elif not (FOLDER/'baseline_validation.json').exists():
        old=torch.load(RUN/'v4/best.pt',map_location='cuda',weights_only=False);model.load_state_dict(old['model'])
        _,summary,parts=evaluate(model,val,cfg,physics)
        write(FOLDER/'baseline_validation.json',{'original_best_epoch':old['epoch'],'precision':'strict FP32','count':288,**summary,'loss_components':parts})
        model=init_model(cfg);opt=torch.optim.AdamW(model.parameters(),lr=cfg['lr']['v4'],weight_decay=cfg['weight_decay'])
        sched=torch.optim.lr_scheduler.CosineAnnealingLR(opt,T_max=POLICY['maximum_total_epochs'])
    if not (FOLDER/'training_complete.json').exists():
        for epoch in range(first,POLICY['maximum_total_epochs']+1):
            torch.backends.cuda.matmul.allow_tf32=True;torch.backends.cudnn.allow_tf32=True
            torch.backends.cudnn.benchmark=True;torch.backends.cudnn.deterministic=False;torch.use_deterministic_algorithms(False)
            model.train();sums={};seen=0;tick=time.time();epoch_lr=opt.param_groups[0]['lr']
            for bi,b in enumerate(loader(train,cfg['batch_size'],True,cfg['seed']+epoch-1)):
                b=to_device(b,'cuda');opt.zero_grad(set_to_none=True)
                with torch.autocast('cuda',dtype=torch.bfloat16):
                    out=model(b['image'],b['voltage']);lv,lt=v4_loss(out,b,physics,cfg['loss_weights']['v4'])
                if not torch.isfinite(lv):raise RuntimeError('nonfinite v4 rerun loss')
                lv.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),cfg['gradient_clip'],error_if_nonfinite=True);opt.step()
                seen+=len(b['case_id'])
                for k,v in {'total':lv,**lt}.items():sums[k]=sums.get(k,0)+float(v.detach())*len(b['case_id'])
                if bi%10==0:
                    state(KEY,status='RUNNING',phase='独立重训 v4；校准集继续保留',epoch=epoch,epochs=300,completed=seen,total=len(train),loss=sums['total']/seen,best_validation_iou=best,patience=60,bad_epochs=bad,lr=epoch_lr)
            _,sm,vl=evaluate(model,val,cfg,physics);vi=sm['overall']['iou']['mean'];sched.step()
            history.append({'epoch':epoch,'training':{k:v/seen for k,v in sums.items()},'validation':{k:v['mean'] for k,v in sm['overall'].items()},'validation_loss':vl,'lr':epoch_lr,'seconds':time.time()-tick,'phase':'fresh300'})
            if vi>best:
                best=vi;best_epoch=epoch
                checkpoint(FOLDER/'best.pt',model,opt,sched,epoch,best,best_epoch,monitor,bad,history,config)
            if vi>=monitor+POLICY['minimum_iou_improvement']:monitor=vi;bad=0
            else:bad+=1
            checkpoint(last,model,opt,sched,epoch,best,best_epoch,monitor,bad,history,config)
            write(FOLDER/'history.json',history)
            state(KEY,status='RUNNING',phase='新 v4 验证完成',epoch=epoch,epochs=300,completed=seen,total=len(train),loss=sums['total']/seen,validation_iou=vi,validation_metrics=sm['overall'],best_validation_iou=best,best_epoch=best_epoch,patience=60,bad_epochs=bad,lr=epoch_lr)
            print('v4',epoch,'loss',round(sums['total']/seen,6),'val IoU',round(vi,6),'patience',bad,'/60',flush=True)
            if (FOLDER/'stop.request').exists():
                state(KEY,status='PAUSED',phase='用户暂停；轮末断点已保存');return
            stop=epoch>=POLICY['minimum_total_epochs'] and bad>=POLICY['patience']
            if stop or epoch==300:
                write(FOLDER/'training_complete.json',{'status':'PASS','total_epochs':epoch,'best_epoch':best_epoch,'best_validation_iou':best,'stop_reason':'validation_plateau' if stop else 'maximum_budget','policy':POLICY,'elapsed_this_process_seconds':time.time()-started,'weight_sha256':sha(FOLDER/'best.pt')})
                break
    if not (FOLDER/'metrics.json').exists():
        ck=torch.load(FOLDER/'best.pt',map_location='cuda',weights_only=False);model.load_state_dict(ck['model'])
        records,_,_=evaluate(model,EITDataset(PROJECT/'cache','test'),cfg,physics,test=True)
        finish_metrics(KEY,records,checkpoint=str(FOLDER/'best.pt'),checkpoint_sha256=sha(FOLDER/'best.pt'),best_epoch=ck['epoch'],training=read(FOLDER/'training_complete.json'),parameter_count=sum(p.numel() for p in model.parameters()),precision='strict FP32',original_project_preserved=True)
    protect()

if __name__=='__main__':
    try:main()
    except BaseException as e:state(KEY,status='FAILED',phase='新 v4 实验异常',error=repr(e));raise
