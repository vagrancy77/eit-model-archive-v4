# 历史v4训练代码与权重包

打包日期：2026-10-15（北京时间）。这是此前讨论的独立v4（7通道线性初图 + 4通道复电压、切口/开口/门控结构），不是当前4840例界面网络，也不是其三种子最终冠军。原项目说明记录该实现为依据模型文档重建的实现，不声称恢复了未提供的原作者代码或权重。

## 权重选择

| 版本 | 最佳检查点 | 训练结束 | 验证IoU |
|---|---:|---:|---:|
| original | 94轮 | 100轮 | 0.9025265773 |
| long_patience | 295轮 | 298轮 | 0.9122724276 |

两者均严格加载同一V4结构并通过CPU合成输入前向检查。验证选择/精度策略不同，表格不能视为公平最终测试比较。原版与延长版完整best/last都保留；不将延长版v4与原版局部校正器/风险门控权重混配。包内不含后续v6局部校正器及风险门控权重。

## 网络参数与数据流

参数总数：**20,450,508**；可训练参数同上。详见model_parameters.json（包括各输出张量形状）。

双频10/50 kHz复电压与配对背景电压 → 差分/尺度归一化 → 双路输入：①正则化线性逆算子生成电导率初图及平滑、梯度等7通道64×64图像；②实部/虚部组成4×32×32电压表 → 图像残差编码器64/128/256/512 + 电压编码器32/64/128/256 → 瓶颈融合 → 三层跳接解码 → 区域三分类、边界有符号距离、电导率变化(双频)、介电常数变化(双频)、切口、开口、局部门控与病例门控 → 64次连通传播和门控切除 → 最终分割。硬阈值连通支撑不是全可微，切口/开口另有直接监督。

base=64，dropout=0.05，传播次数64。sigma输出乘0.2得到S/m变化量；epsilon输出乘50000得到相对介电常数变化。绝对材料值需加对应背景。未舍弃电压虚部。

## 训练参数

监督训练；随机种子20260911，验证划分种子20261010；批量16；AdamW初始学习率0.0003、权重衰减0.0001、梯度裁剪5；余弦学习率。原版100轮；延长版上限300轮、至少120轮、耐心60轮、显著改善阈值0.0005。历史数据3872例：训练2720，验证576（选模288/校准288），测试576。未打包数据病例与缓存病例；不要直接把4840新数据替换为同一历史分布。

原版损失权重（人为固定，来自config.json）：
```json
{
  "base_ce": 1,
  "final_ce": 1,
  "dice": 1,
  "sdf": 2,
  "boundary": 0.5,
  "conductivity": 1,
  "permittivity": 0.5,
  "physics": 0.02,
  "cutout": 0.5,
  "mouth": 0.5,
  "cldice": 0.1,
  "depth": 0.1,
  "area": 0.5,
  "ordinary": 0.5,
  "gate": 0.2
}
```
几何/切口/开口/门控监督促使形状正确，电导率/介电常数监督拟合材料变化，线性物理残差权重0.02约束预测材料与电压一致。原版训练含CUDA BF16自动混合精度；延长版精度设置以归档源码为准，不应宣称全程严格FP32。

## 安装和使用

建议Python3.12。依赖见EIT_Reconstruction/requirements.txt及requirements.lock.txt。CUDA12.8版Torch用于GPU；CPU可使用匹配CPU版Torch。

```powershell
python -m pip install -r EIT_Reconstruction/requirements.txt
python v4_bundle_cli.py verify
python v4_bundle_cli.py infer --weights original --input YOUR_CASE.npz --background Fat --output prediction_original.npz --device cpu
python v4_bundle_cli.py infer --weights long_patience --input YOUR_CASE.npz --background Muscle --output prediction_long.npz --device cuda
```

输入NPZ：voltage、background_voltage为复数[2,32,32]，frequencies_hz为[10000,50000]，电压单位伏，驱动与测量排列须与原数据一致。入口执行与原infer_case一致的负端电极参考化。输出为最终分割、概率、距离、材料变化和中间门控图。背景Fat/Muscle必须由已知实验条件提供，不能猜测。

仅重新训练原版v4（会启动训练，请人工执行）：
```powershell
python v4_bundle_cli.py train-original --cache PATH_TO_PREPARED_CACHE --output NEW_RUN_FOLDER --device cuda
```
缓存须按eit/data.py预处理，并包含cases、splits.json、voltage_normalization.npz、validation_roles.json，且与包内参考算子一致。原run_model.py train会运行v4→local→gate整流水线；仅需v4请使用新增入口。数据集路径与COMSOL安装路径仍是历史配置，若重建算子需自行配置COMSOL及参考导出环境。

延长版原始训练入口EIT_Comparison/v4_long_patience.py与common.py完整归档；其protect()依赖原工程v4/local/gate文件的来源校验，本包未包含后两阶段权重，因此它不是开箱即用的迁移训练入口。若要严格继续延长版历史训练，需恢复原工程所需依赖和路径，不要绕过来源校验。其best/last可直接由便携推理入口加载。

## 文件说明

| 文件 | 说明 |
|---|---|
| `EIT_Comparison/common.py` | 原始实现源码或历史说明 |
| `EIT_Comparison/results/project_v4_long_patience/baseline_validation.json` | 原始实现源码或历史说明 |
| `EIT_Comparison/results/project_v4_long_patience/best.pt` | 完整检查点：模型权重、优化器、调度器和随机状态；best为选模权重，last为续训状态 |
| `EIT_Comparison/results/project_v4_long_patience/config.json` | 原始训练配置，保留历史路径；迁移时需调整数据集路径 |
| `EIT_Comparison/results/project_v4_long_patience/history.json` | 逐轮训练和验证记录 |
| `EIT_Comparison/results/project_v4_long_patience/last.pt` | 完整检查点：模型权重、优化器、调度器和随机状态；best为选模权重，last为续训状态 |
| `EIT_Comparison/results/project_v4_long_patience/training_complete.json` | 原始实现源码或历史说明 |
| `EIT_Comparison/v4_long_patience.py` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/BUILD_PROVENANCE.json` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/cache/cache_manifest.json` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/cache/splits.json` | 病例/位置划分与选模、校准隔离信息 |
| `EIT_Reconstruction/cache/validation_roles.json` | 病例/位置划分与选模、校准隔离信息 |
| `EIT_Reconstruction/cache/voltage_normalization.npz` | 训练集计算的电压均值和标准差，推理必需 |
| `EIT_Reconstruction/config.json` | 原始训练配置，保留历史路径；迁移时需调整数据集路径 |
| `EIT_Reconstruction/CONTACT_MODEL_ADDENDUM.md` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/eit/__init__.py` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/eit/data.py` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/eit/evaluate.py` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/eit/infer.py` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/eit/losses.py` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/eit/models.py` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/eit/physics.py` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/eit/risk.py` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/eit/runtime.py` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/eit/train.py` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/operators/operators.npz` | 双背景、双频参考前向算子与正则化线性逆算子，预处理/物理损失必需 |
| `EIT_Reconstruction/operators/physics_verification.json` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/README.md` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/reference/__init__.py` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/reference/assemble_reference.py` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/reference/comsol_classpath.py` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/reference/export_reference.py` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/requirements.lock.txt` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/requirements.txt` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/run_model.py` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/runs/seed_20260911/resolved_config.json` | 原始训练配置，保留历史路径；迁移时需调整数据集路径 |
| `EIT_Reconstruction/runs/seed_20260911/v4/best.pt` | 完整检查点：模型权重、优化器、调度器和随机状态；best为选模权重，last为续训状态 |
| `EIT_Reconstruction/runs/seed_20260911/v4/complete.json` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/runs/seed_20260911/v4/history.json` | 逐轮训练和验证记录 |
| `EIT_Reconstruction/runs/seed_20260911/v4/last.pt` | 完整检查点：模型权重、优化器、调度器和随机状态；best为选模权重，last为续训状态 |
| `EIT_Reconstruction/tests/__init__.py` | 原始实现源码或历史说明 |
| `EIT_Reconstruction/tests/test_contract.py` | 原始实现源码或历史说明 |
| `model_parameters.json` | 原始实现源码或历史说明 |
| `v4_bundle_cli.py` | 新增便携入口：校验包、指定权重推理、仅训练原v4 |

MANIFEST.sha256.json记录包内文件大小与SHA256；verify同时核验。README为本包说明，EIT_Reconstruction/README.md是原项目说明，可能描述未包含的v6后续流程。包内无数据集、密钥、远程上报令牌或新实验权重。PyTorch完整检查点使用pickle，仅加载可信来源文件。
