"""Meaningful invariants, independent of training metrics or old absent weights."""
from pathlib import Path
import json,hashlib
import numpy as np
import torch
from eit.models import V4,LocalTopologyCorrectorV6,DualRiskQuantileGate,make_v6_features,connected_removal,route
from eit.risk import extract_statistics,quantile_loss,FEATURE_NAMES
from eit.losses import v4_loss,local_loss
from eit.physics import CEM,EPS0
from eit.data import assert_split_isolation
from eit.runtime import model_counts,atomic_json

def state_hash(model):
    h=hashlib.sha256()
    for p in model.state_dict().values():h.update(p.detach().cpu().numpy().tobytes())
    return h.hexdigest()
class HeadGradientObjective:
    # Unit-test-only objective; production uses the verified full reference FEM.
    def loss(self,sigma,epsilon,dv,group):return sigma.square().mean()+epsilon.square().mean()
def run(project,config,device_string):
    torch.set_num_threads(config["cpu_threads"]);device=torch.device(device_string)
    if device.type=="cuda" and not torch.cuda.is_available():raise RuntimeError("GPU is not available")
    checks=[];torch.manual_seed(11)
    v4=V4(config["v4_base"],config["dropout"],config["propagation_iterations"]).to(device)
    local=LocalTopologyCorrectorV6(config["local_base"],config["dropout"],config["propagation_iterations"],config["alpha"]).to(device)
    gate=DualRiskQuantileGate().to(device)
    image=torch.randn(2,7,64,64,device=device);image[:,-1]=1
    voltage=torch.randn(2,4,32,32,device=device)
    with torch.autocast(device_type=device.type,dtype=torch.bfloat16,enabled=device.type=="cuda"):
        out=v4(image,voltage)
    assert out["final"].shape==(2,3,64,64)
    assert torch.allclose(out["final"].sum(1),torch.ones_like(out["final"][:,0]),atol=1e-6)
    assert out["sigma"].shape==(2,2,64,64) and out["case_gate"].shape==(2,1,1,1)
    truth=torch.zeros(2,1,64,64,device=device);truth[:,:,20:44,20:44]=1
    cut=torch.zeros_like(truth);cut[:,:,27:37,36:44]=1;truth=truth*(1-cut)
    batch={"mask":truth,"class":(truth[:,0]*2).long(),"fov":image[:,-1:],"sdf":torch.zeros_like(truth),
        "cutout":cut,"mouth":cut,"sigma":truth.repeat(1,2,1,1)*.2,
        "epsilon":truth.repeat(1,2,1,1)*.2,"dv":torch.zeros(2,2,2048,device=device),
        "group":torch.zeros(2,device=device,dtype=torch.long)}
    opt=torch.optim.AdamW(v4.parameters(),lr=1e-4)
    before=state_hash(v4)
    with torch.autocast(device_type=device.type,dtype=torch.bfloat16,enabled=device.type=="cuda"):
        loss,parts=v4_loss(out,batch,HeadGradientObjective(),config["loss_weights"]["v4"])
    assert set(parts)==set(config["loss_weights"]["v4"])
    loss.backward();assert torch.isfinite(loss)
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in v4.parameters())
    opt.step();assert state_hash(v4)!=before
    checks.append("all v4 loss terms produce finite gradients and a real optimizer update")
    v4.eval();v4.requires_grad_(False);frozen=state_hash(v4)
    with torch.no_grad():anchor=v4(image,voltage);features=make_v6_features(anchor,image,torch.zeros_like(truth))
    assert features.shape==(2,15,64,64)
    with torch.autocast(device_type=device.type,dtype=torch.bfloat16,enabled=device.type=="cuda"):
        local_out=local(features,anchor["final"])
    assert (local_out["candidate"][:,1:]<=anchor["final"][:,1:]+1e-7).all()
    opt=torch.optim.AdamW(local.parameters(),lr=1e-4)
    with torch.autocast(device_type=device.type,dtype=torch.bfloat16,enabled=device.type=="cuda"):
        loss,parts=local_loss(local_out,anchor,batch,HeadGradientObjective(),config["loss_weights"]["local"])
    loss.backward();opt.step()
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in local.parameters())
    assert state_hash(v4)==frozen and all(not p.requires_grad for p in v4.parameters())
    checks.append("frozen v4 unchanged after local update; candidate cannot add foreground")
    x=extract_statistics(anchor,local_out,image,torch.zeros_like(truth),batch["dv"],batch["dv"]).detach()
    assert x.shape==(2,56) and len(FEATURE_NAMES)==56 and torch.isfinite(x).all()
    q=gate(x);assert q.shape==(2,3,3) and (q[:,:,1:]>=q[:,:,:-1]).all()
    pinball=quantile_loss(q,torch.zeros(2,3,device=device));pinball.backward()
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in gate.parameters())
    checks.append("56 truth-blind statistics, nine ordered quantiles and pinball gradients")
    q=torch.zeros(2,3,3,device=device);q[0,0,0]=.1;q[1,0,0]=-.1
    final,accepted=route(anchor["final"],local_out["candidate"],q)
    assert accepted.tolist()==[True,False]
    assert torch.equal(final[1],anchor["final"][1])
    checks.append("rejected gate routes exactly to anchor bytes")
    fg=torch.zeros(1,1,64,64,device=device);fg[:,:,20:44,20:44]=1
    fov=torch.ones_like(fg);fov[:,:,:2]=0;fov[:,:,-2:]=0;fov[:,:,:,:2]=0;fov[:,:,:,-2:]=0
    raw=torch.zeros_like(fg);raw[:,:,31,18:31]=1;raw[:,:,35,35]=1
    mouth=torch.zeros_like(fg);mouth[:,:,31,18:23]=1
    connected=connected_removal(raw,mouth,fg,fov,64)
    assert connected[0,0,31,30]==1 and connected[0,0,35,35]==0
    checks.append("accessible cut retained, isolated internal hole rejected")
    # Independent real FEM current, reciprocity and finite-difference derivative check.
    cem=CEM(rings=8);kappa=.341+1j*2*np.pi*1e4*EPS0*26000
    basis=cem.solve_basis(kappa);table=cem.table(basis)
    assert np.all(np.abs(table[np.arange(32),(np.arange(32)+1)%32])<1e-12)
    U=basis[len(cem.xy):len(cem.xy)+32]
    transfer=U[:-1,:-1]-U[-1,:-1][None,:]
    assert np.linalg.norm(transfer-transfer.T)/np.linalg.norm(transfer)<1e-10
    mapping=np.arange(len(cem.tri));J=cem.jacobian(basis,mapping,len(mapping))
    t=len(mapping)//2;step=1e-5
    pert=np.full(len(mapping),kappa,dtype=complex);pert[t]+=step
    fd=(cem.table(cem.solve_basis(pert))-table)/step
    relative=float(np.linalg.norm(fd-J[:,:,t])/np.linalg.norm(J[:,:,t]))
    assert relative<.002
    checks.append(f"CEM reciprocity, negative-electrode reference, Jacobian finite difference {relative:.3g}")
    counts=assert_split_isolation(config["dataset"])
    assert counts=={"train":2720,"val":576,"test":576}
    report={"status":"PASS","checks":checks,"model_parameters":model_counts(v4,local,gate),
        "canonical_split_counts":counts,"device":str(device),
        "gpu":torch.cuda.get_device_name() if device.type=="cuda" else None,
        "torch_version":torch.__version__,"cuda_version":torch.version.cuda,
        "note":"Contract tests; these are not claimed reconstruction training results."}
    atomic_json(Path(project)/"self_test_report.json",report)
    print(json.dumps(report,ensure_ascii=False,indent=2))

