"""Sequential real training: v4 -> frozen v4/local -> actual candidate risk -> gate."""
from pathlib import Path
import json,time,os,traceback
import numpy as np
import torch
from torch.utils.data import DataLoader,TensorDataset
from .models import V4,LocalTopologyCorrectorV6,DualRiskQuantileGate,make_v6_features,route
from .physics import Physics,build_operators
from .data import EITDataset,prepare_cache,assert_split_isolation,sha
from .losses import v4_loss,local_loss,metrics
from .risk import extract_statistics,risk_targets,quantile_loss,FEATURE_NAMES,iou_per_case
from .runtime import Reporter,seed_all,rng_state,restore_rng,save_checkpoint,load_weights,to_device,model_counts,atomic_json

def validation_roles(cache,seed):
    path=Path(cache)/"validation_roles.json"
    if path.exists():return json.loads(path.read_text(encoding="utf-8"))
    rows=json.loads((Path(cache)/"splits.json").read_text(encoding="utf-8"))["splits"]
    positions=sorted({r["position_id"] for r in rows if r["split"]=="val"})
    rng=np.random.default_rng(seed);rng.shuffle(positions);half=len(positions)//2
    roles={"selection_positions":positions[:half],"calibration_positions":positions[half:],
        "note":"Calibration positions never used for model selection or fitting network weights."}
    atomic_json(path,roles);return roles

def loader(dataset,batch,shuffle=False,seed=0):
    generator=torch.Generator().manual_seed(seed)
    # No multiprocessing child consoles; cached NPZ loading is small and deterministic.
    return DataLoader(dataset,batch_size=batch,shuffle=shuffle,num_workers=0,
                      pin_memory=torch.cuda.is_available(),generator=generator)
@torch.no_grad()
def predict_local(v4,local,physics,batch):
    anchor=v4(batch["image"],batch["voltage"])
    predicted=physics.predict(anchor["sigma"],anchor["epsilon"],batch["group"])
    bp=physics.backproject(batch["dv"]-predicted,batch["group"])
    features=make_v6_features(anchor,batch["image"],bp)
    output=local(features,anchor["final"])
    return anchor,output,bp,predicted

@torch.no_grad()
def evaluate_network(model,dataset,config,device,physics,v4=None):
    model.eval();totals={};count=0
    for batch in loader(dataset,config["batch_size"]):
        batch=to_device(batch,device)
        with torch.autocast(device_type=device.type,dtype=torch.bfloat16,enabled=device.type=="cuda"):
            if v4 is None:prob=model(batch["image"],batch["voltage"])["final"]
            else:_,local,_,_=predict_local(v4,model,physics,batch);prob=local["candidate"]
        score=metrics(prob,batch);n=len(batch["mask"]);count+=n
        for k,v in score.items():totals[k]=totals.get(k,0)+float(v)*n
    return {k:v/count for k,v in totals.items()}

def train_network(phase,model,train_ds,val_ds,config,device,physics,run,reporter,v4=None,resume=True):
    directory=Path(run)/phase;directory.mkdir(parents=True,exist_ok=True)
    last=directory/"last.pt";bestpath=directory/"best.pt";done=directory/"complete.json"
    if done.exists():
        ck=load_weights(model,bestpath,device)
        if ck['config']!=config:raise RuntimeError('Completed run configuration differs; use a new run/project')
        return
    opt=torch.optim.AdamW(model.parameters(),lr=config["lr"][phase],weight_decay=config["weight_decay"])
    scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(opt,T_max=config["epochs"][phase])
    scaler=torch.amp.GradScaler("cuda",enabled=False) # BF16 has exponent range of FP32.
    start_epoch=0;start_batch=0;step=0;best=-float("inf");history=[]
    if resume and last.exists():
        ck=load_weights(model,last,device)
        if ck['config']!=config:raise RuntimeError('Resume configuration differs; batch/loss/physics changes require a new run/project')
        opt.load_state_dict(ck["optimizer"]);scheduler.load_state_dict(ck["scheduler"])
        start_epoch=ck["epoch"];start_batch=ck["next_batch"];step=ck["global_step"];best=ck["best"];restore_rng(ck["rng"])
    history_path=directory/"history.json"
    if history_path.exists():history=json.loads(history_path.read_text(encoding="utf-8"))
    epochs=config["epochs"][phase]
    for epoch in range(start_epoch,epochs):
        model.train()
        if v4 is not None:v4.eval()
        train_loader=loader(train_ds,config["batch_size"],True,config["seed"]+epoch)
        sums={};seen=0;epoch_start=time.time()
        for bi,batch in enumerate(train_loader):
            if epoch==start_epoch and bi<start_batch:continue
            batch=to_device(batch,device);opt.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type,dtype=torch.bfloat16,enabled=device.type=="cuda"):
                if phase=="v4":
                    out=model(batch["image"],batch["voltage"])
                    loss,parts=v4_loss(out,batch,physics,config["loss_weights"]["v4"])
                else:
                    with torch.no_grad():
                        anchor=v4(batch["image"],batch["voltage"])
                        pred=physics.predict(anchor["sigma"],anchor["epsilon"],batch["group"])
                        bp=physics.backproject(batch["dv"]-pred,batch["group"])
                        features=make_v6_features(anchor,batch["image"],bp)
                    out=model(features,anchor["final"])
                    loss,parts=local_loss(out,anchor,batch,physics,config["loss_weights"]["local"])
            if not torch.isfinite(loss):raise FloatingPointError(f"{phase} nonfinite loss at epoch {epoch+1} batch {bi+1}")
            loss.backward()
            grad=torch.nn.utils.clip_grad_norm_(model.parameters(),config["gradient_clip"],error_if_nonfinite=True)
            opt.step();step+=1;n=len(batch["mask"]);seen+=n
            for k,v in {"total":loss,**parts}.items():sums[k]=sums.get(k,0)+float(v.detach())*n
            if bi%5==0 or bi+1==len(train_loader):
                reporter(phase=phase.upper(),epoch=epoch+1,epochs=epochs,batch=bi+1,batches=len(train_loader),
                    global_step=step,loss=float(loss.detach()),loss_components={k:float(v.detach()) for k,v in parts.items()},
                    gradient_norm=float(grad),lr=opt.param_groups[0]["lr"],
                    train_cases=len(train_ds),validation_cases=len(val_ds),
                    gpu_memory_mib=torch.cuda.max_memory_allocated()/1048576 if device.type=="cuda" else 0,
                    checkpoint=str(last),message="optimizer update completed")
            if step%config["checkpoint_steps"]==0 or step==1:
                save_checkpoint(last,model,opt,scheduler,scaler,epoch,bi+1,step,best,config)
            if (Path(run)/"stop.request").exists():
                save_checkpoint(last,model,opt,scheduler,scaler,epoch,bi+1,step,best,config)
                reporter(phase="PAUSED",status="PAUSED",message="用户暂停；断点已保存")
                raise InterruptedError("User requested pause")
        validation=evaluate_network(model,val_ds,config,device,physics,v4)
        scheduler.step()
        record={"epoch":epoch+1,"training":{k:v/max(seen,1) for k,v in sums.items()},
                "validation":validation,"seconds":time.time()-epoch_start,"global_step":step}
        history.append(record);atomic_json(history_path,history)
        if validation["iou"]>best:
            best=validation["iou"];save_checkpoint(bestpath,model,opt,scheduler,scaler,epoch+1,0,step,best,config)
        save_checkpoint(last,model,opt,scheduler,scaler,epoch+1,0,step,best,config)
        reporter(phase=phase.upper(),epoch=epoch+1,epochs=epochs,batch=len(train_loader),batches=len(train_loader),
            global_step=step,validation=validation,best_validation_iou=best,message="epoch and validation complete")
        start_batch=0
    load_weights(model,bestpath,device)
    atomic_json(done,{"status":"PASS","epochs":epochs,"global_step":step,"best_validation_iou":best,"checkpoint_sha256":sha(bestpath)})

@torch.no_grad()
def create_risk_dataset(v4,local,physics,cache,config,device,run,reporter,roles):
    path=Path(run)/"risk_data.pt";signature={"v4":sha(Path(run)/"v4/best.pt"),"local":sha(Path(run)/"local/best.pt")}
    if path.exists():
        saved=torch.load(path,map_location="cpu",weights_only=False)
        if saved["signature"]!=signature:raise RuntimeError("Stale risk labels from different networks")
        return saved
    v4.eval();local.eval();saved={"signature":signature,"feature_names":FEATURE_NAMES}
    partitions=[("train","train",None),("val","val",roles["selection_positions"]),
                ("calibration","val",roles["calibration_positions"]),("test","test",None)]
    for name,canonical,positions in partitions:
        ds=EITDataset(cache,canonical,positions=positions);xs=[];ys=[];ids=[]
        for bi,batch in enumerate(loader(ds,config["batch_size"])):
            batch=to_device(batch,device)
            with torch.autocast(device_type=device.type,dtype=torch.bfloat16,enabled=device.type=="cuda"):
                a,c,bp,pred=predict_local(v4,local,physics,batch)
            x=extract_statistics(a,c,batch["image"],bp,batch["dv"],pred)
            y=risk_targets(a["final"],c["candidate"],batch["mask"],batch["cutout"])
            xs.append(x.cpu());ys.append(y.cpu());ids.extend(batch["case_id"])
            if bi%5==0:reporter(phase="RISK_LABELS",partition=name,completed=len(ids),total=len(ds),
                                message="actual frozen anchor/candidate statistics")
        saved[name]={"x":torch.cat(xs),"y":torch.cat(ys),"case_ids":ids}
    temp=path.with_suffix(".tmp.pt");torch.save(saved,temp);os.replace(temp,path);return saved

def train_gate(gate,data,config,device,run,reporter,resume=True):
    directory=Path(run)/"gate";directory.mkdir(exist_ok=True);bestpath=directory/"best.pt";last=directory/"last.pt"
    if (directory/"complete.json").exists():
        ck=load_weights(gate,bestpath,device)
        if ck['config']!=config:raise RuntimeError('Completed gate configuration differs')
        return
    train=data["train"];val=data["val"]
    gate.feature_mean.copy_(train["x"].mean(0).to(device))
    gate.feature_std.copy_(train["x"].std(0,unbiased=False).clamp_min(1e-5).to(device))
    opt=torch.optim.AdamW(gate.parameters(),lr=config["lr"]["gate"],weight_decay=config["weight_decay"])
    scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(opt,T_max=config["epochs"]["gate"])
    start=0;step=0;best=float("inf");history=[]
    if resume and last.exists():
        ck=load_weights(gate,last,device)
        if ck['config']!=config:raise RuntimeError('Gate resume configuration differs')
        opt.load_state_dict(ck["optimizer"]);scheduler.load_state_dict(ck["scheduler"])
        start=ck["epoch"];step=ck["global_step"];best=ck["best"];restore_rng(ck["rng"])
    if (directory/"history.json").exists():history=json.loads((directory/"history.json").read_text(encoding="utf-8"))
    for epoch in range(start,config["epochs"]["gate"]):
        gate.train();tot=0;n=0
        ds=TensorDataset(train["x"],train["y"])
        for bi,(x,y) in enumerate(loader(ds,128,True,config["seed"]+epoch)):
            x=x.to(device);y=y.to(device);opt.zero_grad(set_to_none=True)
            pred=gate(x);loss=quantile_loss(pred,y)
            if not torch.isfinite(loss):raise FloatingPointError("Nonfinite gate pinball loss")
            loss.backward();torch.nn.utils.clip_grad_norm_(gate.parameters(),config["gradient_clip"],error_if_nonfinite=True);opt.step()
            step+=1;tot+=float(loss.detach())*len(x);n+=len(x)
        gate.eval()
        with torch.no_grad():vl=float(quantile_loss(gate(val["x"].to(device)),val["y"].to(device)))
        scheduler.step();history.append({"epoch":epoch+1,"pinball":tot/n,"validation_pinball":vl})
        atomic_json(directory/"history.json",history)
        if vl<best:
            best=vl;save_checkpoint(bestpath,gate,opt,scheduler,None,epoch+1,0,step,best,config)
        save_checkpoint(last,gate,opt,scheduler,None,epoch+1,0,step,best,config)
        reporter(phase="GATE",epoch=epoch+1,epochs=config["epochs"]["gate"],batch=bi+1,batches=bi+1,
                 global_step=step,loss=tot/n,validation_pinball=vl,message="quantile gate optimization")
        if (Path(run)/"stop.request").exists():
            reporter(phase="PAUSED",status="PAUSED",message="用户暂停；门控断点已保存");raise InterruptedError("User requested pause")
    load_weights(gate,bestpath,device);gate.calibration.zero_();gate.eval()
    calib=data["calibration"]
    with torch.no_grad():
        q=gate(calib["x"].to(device));y=calib["y"].to(device)
        offsets=torch.stack([torch.quantile(y-q[:,:,j],level,dim=0) for j,level in enumerate([.2,.5,.8])],1)
        gate.calibration.copy_(offsets)
        calibrated=gate(calib["x"].to(device))
    save_checkpoint(bestpath,gate,None,None,None,config["epochs"]["gate"],0,step,best,config)
    report={"status":"PASS","checkpoint_sha256":sha(bestpath),"best_validation_pinball":best,"calibration_cases":len(calib["x"]),
        "calibration_offsets":offsets.cpu().tolist(),"thresholds":config["risk_thresholds"],
        "coverage":((y[:,:,None]<=calibrated).float().mean(0)).cpu().tolist(),
        "threshold_policy":"fixed from PDF; only predicted quantiles calibrated on reserved validation positions"}
    atomic_json(directory/"calibration.json",report);atomic_json(directory/"complete.json",report)

def pipeline(project,config,device_string="cuda",seeds=None,resume=True):
    project=Path(project);device=torch.device(device_string)
    if device.type=="cuda" and not torch.cuda.is_available():raise RuntimeError("CUDA requested but unavailable")
    torch.set_num_threads(config["cpu_threads"])
    torch.backends.cuda.matmul.allow_tf32=True
    torch.backends.cudnn.benchmark=True
    if seeds is None:seeds=[config["seed"]]
    for seed in seeds:
        cfg={**config,"seed":seed};run=project/"runs"/f"seed_{seed}";reporter=Reporter(run)
        try:
            reporter(phase="PREPARING",status="RUNNING",seed=seed,device=str(device),message="verifying input split")
            if (run/"stop.request").exists():raise InterruptedError("Remove stop.request to resume")
            counts=assert_split_isolation(cfg["dataset"]);atomic_json(run/"resolved_config.json",cfg)
            operators=project/"operators"/"operators.npz"
            if not operators.exists():build_operators(cfg["dataset"],operators.parent,cfg,reporter)
            else:
                audit=json.loads((operators.parent/"physics_verification.json").read_text(encoding="utf-8"))
                if audit["status"]!="PASS":raise RuntimeError("Physics audit not passed")
                if audit.get('physics_config')!=cfg['physics']:raise RuntimeError('Reference operator configuration differs; use fresh operators/cache in a new project')
            cache=project/"cache";prepare_cache(cfg["dataset"],cache,operators,reporter)
            roles=validation_roles(cache,cfg["validation_seed"]);atomic_json(run/"validation_roles.json",roles)
            seed_all(seed)
            train_ds=EITDataset(cache,"train");val_ds=EITDataset(cache,"val",positions=roles["selection_positions"])
            physics=Physics(operators,device)
            v4=V4(cfg["v4_base"],cfg["dropout"],cfg["propagation_iterations"]).to(device)
            local=LocalTopologyCorrectorV6(cfg["local_base"],cfg["dropout"],cfg["propagation_iterations"],cfg["alpha"]).to(device)
            gate=DualRiskQuantileGate().to(device);atomic_json(run/"model_parameters.json",model_counts(v4,local,gate))
            train_network("v4",v4,train_ds,val_ds,cfg,device,physics,run,reporter,resume=resume)
            v4.eval();v4.requires_grad_(False)
            v4_hash=sha(run/"v4/best.pt")
            reporter(phase="FREEZE_V4",message="loaded trained best v4; every parameter requires_grad=False",v4_checkpoint_sha256=v4_hash)
            train_network("local",local,train_ds,val_ds,cfg,device,physics,run,reporter,v4,resume)
            if sha(run/"v4/best.pt")!=v4_hash:raise RuntimeError("Frozen v4 checkpoint changed")
            local.eval();local.requires_grad_(False)
            data=create_risk_dataset(v4,local,physics,cache,cfg,device,run,reporter,roles)
            train_gate(gate,data,cfg,device,run,reporter,resume)
            from .evaluate import evaluate_all
            evaluate_all(project,cfg,device,seed,split="test",output=run/"test_evaluation")
            reporter(phase="COMPLETE",status="PASS",message="v4, local and risk gate trained; held-out test evaluated")
        except InterruptedError:
            return
        except BaseException as exc:
            reporter(status="FAILED",phase="FAILED",error=repr(exc),message="see train.error.log")
            (run/"failure_traceback.txt").write_text(traceback.format_exc(),encoding="utf-8")
            raise

