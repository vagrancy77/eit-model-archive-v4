"""Build a standalone-JVM-safe COMSOL classpath.

The COMSOL ``plugins`` directory contains OSGi bundles.  Putting every JAR on
a plain (non-OSGi) JVM classpath also loads SLF4J/logging *bindings* that
require a live OSGi context; on COMSOL 6.4 this breaks BioHeat initialisation
and loading of thermal MPH files.  This module enumerates the plugin JARs,
drops the OSGi-bound logging bindings (keeping the pure ``slf4j.api`` JAR and
every ``com.comsol.*`` JAR), and writes the result as a Java @argfile so the
Windows command-line length limit is never hit.

Used by both ``run_eit_batch.ps1`` (javac) and ``run_batch.py`` (java).
"""
from __future__ import annotations

import argparse
import os
import re
from pathlib import Path

# Logging *bindings* that need an OSGi context; the pure slf4j API is kept so
# COMSOL classes compiled against it still resolve (it then runs as a no-op).
_DEFAULT_EXCLUDE = (r"logback", r"log4j", r"pax[._-]?logging", r"slf4j", r"felix[._-]?log")
_DEFAULT_KEEP = (r"slf4j[._-]?api", r"^com\.comsol\.")


def plugin_jars(plugins: Path, exclude: list[str] | None = None, keep: list[str] | None = None) -> list[Path]:
    exclude_re = [re.compile(p, re.IGNORECASE) for p in (exclude or list(_DEFAULT_EXCLUDE))]
    keep_re = [re.compile(p, re.IGNORECASE) for p in (keep or list(_DEFAULT_KEEP))]
    jars = sorted(p for p in plugins.glob("*.jar") if p.is_file())
    if not jars:
        raise ValueError(f"no plugin JARs found under {plugins}")
    selected = []
    for jar in jars:
        name = jar.name
        if any(r.search(name) for r in keep_re) or not any(r.search(name) for r in exclude_re):
            selected.append(jar)
    if not selected:
        raise ValueError("classpath filter removed every plugin JAR; check exclude patterns")
    return selected


def normalize_plugins_dir(value: str | Path) -> Path:
    """Accept a plugins directory, or the legacy ``...\\plugins\\*`` wildcard."""
    text = str(value).strip().strip('"')
    if text.endswith("*"):
        text = text[:-1].rstrip("\\/")
    plugins = Path(text)
    if not plugins.is_dir():
        raise ValueError(f"COMSOL plugins directory not found: {plugins}")
    return plugins


def build_classpath(plugins: str | Path, classes: Path | None = None,
                    exclude: list[str] | None = None, keep: list[str] | None = None) -> str:
    entries = [str(j) for j in plugin_jars(normalize_plugins_dir(plugins), exclude, keep)]
    if classes is not None:
        entries.insert(0, str(classes))
    return os.pathsep.join(entries)


def write_argfile(path: Path, classpath: str) -> Path:
    """Write ``-cp <classpath>`` as a javac/java @argfile.

    Inside quoted argfile tokens the backslash is an escape character, so
    paths are emitted with forward slashes (valid for the JVM on Windows).
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    quoted = '"' + classpath.replace("\\", "/") + '"'
    path.write_text("-cp " + quoted + "\n", encoding="ascii")
    return path


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--plugins", required=True, help="COMSOL plugins directory (or legacy 'plugins\\*' wildcard)")
    ap.add_argument("--classes", type=Path, default=None, help="optional compiled classes directory to prepend")
    ap.add_argument("--out", type=Path, required=True, help="argfile to write (-cp ...)")
    ap.add_argument("--exclude-jar-pattern", action="append", default=None,
                    help="regex replacing the default logging-binding exclusions")
    ap.add_argument("--keep-jar-pattern", action="append", default=None,
                    help="regex replacing the default keep list (slf4j API, com.comsol.*)")
    args = ap.parse_args()
    classpath = build_classpath(args.plugins, args.classes, args.exclude_jar_pattern, args.keep_jar_pattern)
    write_argfile(args.out, classpath)
    print(f"classpath entries: {classpath.count(os.pathsep) + 1} -> {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
