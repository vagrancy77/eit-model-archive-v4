# V4 archive integration (2026-10-15)

Update 2026-10-16: the complete upstream is still immutable, but the active local
adapter now targets the FINAL 4840-case A-E release. See
[FINAL4840_ADAPTATION.md](../../FINAL4840_ADAPTATION.md) for current commands.
`verify` checks upstream integrity and **reports** authorized local adapter changes;
it no longer conflates local improvements with archive corruption. The old
3872-case conversion/training commands below are historical, not current.

The complete user-supplied `v4_training_package_20261015.zip` is preserved under
`upstream/`. Its 45 manifest-listed files plus the manifest itself are present,
including original/long-training checkpoints, source, configuration, normalization,
the 406 MB reference operator, training histories, and contract tests. The upstream
tree is immutable: `import_bundle.py` rejects changed existing files, and
`python v4_unified.py verify` checks all archived hashes and the pre-existing
local source snapshot.

## Model differences

| Component | Archived V4 | Native `comsol_v4` / calibrated study |
| --- | --- | --- |
| Input | 7-channel linear inverse image + 4-channel complex voltage table | 12-channel complex V/B/dV measurements; calibrated study replaces the redundant difference with background-relative complex change |
| Backbone | Residual dual encoder, U-Net decoder, cutout/mouth/local and case gates | Residual attention/topology backbone, learned voltage-to-image lift, dual-frequency material head, two risk gates |
| Physics | Validated homogeneous COMSOL adjoint Jacobian and Tikhonov initial image; linearized voltage loss | Was disabled because the matrix was absent from the local data package; the converted archived matrix is now available as an optional input/loss |
| Weights | Original best epoch 94; long-patience best epoch 295 | Native interface smoke weights are not a trained result; calibrated study has separately trained checkpoints |
| Outputs | Signed normalized material changes plus known Fat/Muscle background | Positive absolute conductivity/permittivity and segmentation |

These architectures and checkpoints are **not interchangeable**. The integration
adds selectable inference and a matching physical operator; it does not claim
that a fused model has been trained or that one model outperforms another.

## Use

From `E:\Codex`, with a Python environment containing PyTorch, NumPy and SciPy:

```powershell
python eit_reproduction/v4_unified.py verify
python eit_reproduction/v4_unified.py list
python eit_reproduction/v4_unified.py infer --backend imported-long --input CASE.npz --background Fat --output RESULT.npz --device cpu
python eit_reproduction/v4_unified.py infer --backend local-calibrated --input CASE.npz --output CALIBRATED.npz --device cpu
```

`CASE.npz` may use either minimal (`voltage`, `background_voltage`) or full
(`eit_voltage`, `eit_background_voltage`) field names. It must contain complex
`[2,32,32]` measurements and ordered `frequencies_hz=[10000,50000]`. The
Fat/Muscle background is known experimental metadata, not inferred from truth.
In this machine `E:\conda-envs\pytorch-gpu\python.exe` has PyTorch, while
SciPy is currently provided by Python's user site; using `-s` hides SciPy.

To regenerate the optional native physical operator from the archived real
blocks (the existing output path must be new):

```powershell
python eit_reproduction/v4_unified.py convert-physics --dataset-root E:\Codex\eit_dataset_full_v6_20261010\extracted\full3872 --output E:\Codex\eit_reproduction\integrations\v4_20261015\derived\reference_physics_v1.npz
```

The generated file has the contract required by `comsol_v4.physics.ReferencePhysics`.
It is tied to the 3872-case 10/50 kHz ADJACENT32 simulation, 64x64 grid,
250 uA current, and Fat/Muscle homogeneous references. It must not be used
for other acquisition protocols or described as a nonlinear per-case FEM/CEM
solver. The original dataset's contact impedance node had no effective
contact impedance; the metadata states that boundary model explicitly.

To train the native model with physics, use `-m comsol_v4.train` with
`--physics-operator <derived/reference_physics_v1.npz>` and a new output
directory. This starts a **new** training run; no existing checkpoint silently
gains the physical branch. The optional `--physics-weight` controls the
linearized residual term. Do not treat the prior native smoke checkpoint as
a trained physical model.

The archived `upstream/v4_bundle_cli.py train-original` remains the historical
V4-only training entry. It needs a prepared `cache/cases` directory; the ZIP
contains the normalization and split files but not the 3872 cached case files.
Its archival `run_model.py` describes a larger V4/V6 pipeline not fully
included in this V4-only package. The long-patience historical training script
also depends on files outside this bundle, although its weights load for
inference. Neither limitation is repaired by bypassing provenance checks.

## Verification performed

- All 45 manifest-listed archive files passed SHA-256 and size checks; original
  native/calibrated Python files matched the pre-import snapshot.
- Both archived best checkpoints and the calibrated local checkpoint completed
  measurement-only CPU inference for one representative case.
- Archived original V4 output for the same case read from minimal/full layouts
  matched exactly for final probabilities, conductivity, permittivity, and
  linear input image.
- Converted Jacobian was loaded by `ReferencePhysics`; backprojection was finite.
  Its complex forward result and the archived real-block operator agreed to
  relative error `1.27e-7` on a synthetic localized material perturbation.
- The archive's `tests/test_contract.py` passed on CPU against the installed
  3872-case split: V4 gradient/update, frozen local model, risk quantiles and
  routing, connected cutout, CEM reciprocity and Jacobian finite difference
  (`1.12e-5`). The machine-specific historical dataset path in config was
  overridden in memory; archived files were not changed.

These are integrity/compatibility tests, **not** reconstruction quality metrics.
Historical validation IoU 0.9025 and 0.9123 used their archived selection
split/policy; they are not directly comparable with the three-seed calibrated
study or a newly trained native physics model.
