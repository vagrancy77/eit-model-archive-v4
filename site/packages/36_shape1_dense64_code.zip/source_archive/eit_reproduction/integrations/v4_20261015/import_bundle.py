"""Import supplied ZIP as immutable hash-checked upstream; executes no archive code."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import shutil
import stat
import zipfile

ROOT = Path(__file__).resolve().parent
ARCHIVE = Path('E:/Codex/v4_training_package_20261015.zip')
PREFIX = 'v4_training_package_20261015/'


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def local_inventory():
    project = ROOT.parents[1]
    files = []
    for directory in (project / 'comsol_v4', project / 'pytorch_eit',
                      project.parent / 'eit_complex_information_study_20261013'):
        files.extend(p for p in directory.glob('*.py') if p.is_file())
    return {str(p): sha(p) for p in sorted(set(files))}


def main():
    output = ROOT / 'upstream'
    audit = ROOT / 'audit'
    audit.mkdir(parents=True, exist_ok=True)
    snapshot = audit / 'local_before.json'
    if not snapshot.exists():
        snapshot.write_text(json.dumps(local_inventory(), indent=2), encoding='utf-8')
    with zipfile.ZipFile(ARCHIVE) as z:
        entries = [e for e in z.infolist() if not e.is_dir()]
        if sum(e.file_size for e in entries) > 5 * 1024**3:
            raise ValueError('Archive exceeds expected 5 GiB safety bound')
        manifest = json.loads(z.read(PREFIX + 'MANIFEST.sha256.json'))
        seen = set()
        for entry in entries:
            if not entry.filename.startswith(PREFIX):
                raise ValueError('Unexpected archive root')
            name = entry.filename[len(PREFIX):]
            path = PurePosixPath(name)
            if (not name or '\\' in name or ':' in name or path.is_absolute()
                    or '..' in path.parts or name.casefold() in seen
                    or stat.S_ISLNK(entry.external_attr >> 16)):
                raise ValueError(f'Unsafe/duplicate archive path: {name}')
            seen.add(name.casefold())
            if name != 'MANIFEST.sha256.json' and name not in manifest:
                raise ValueError(f'Unmanifested archive member: {name}')
        if seen != {n.casefold() for n in manifest} | {'manifest.sha256.json'}:
            raise ValueError('Archive membership differs from manifest')
        records = []
        for entry in entries:
            name = entry.filename[len(PREFIX):]
            dest = output / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            if dest.exists():
                with z.open(entry) as f:
                    h = hashlib.file_digest(f, 'sha256').hexdigest()
                if sha(dest) != h:
                    raise FileExistsError(f'Refusing changed upstream file: {dest}')
            else:
                with z.open(entry) as src, dest.open('xb') as dst:
                    shutil.copyfileobj(src, dst, length=4 * 1024 * 1024)
                h = sha(dest)
            if name in manifest:
                expected = manifest[name]
                if h != expected['sha256'] or dest.stat().st_size != expected['bytes']:
                    raise ValueError(f'Hash/size mismatch: {name}')
            records.append({'path': name, 'bytes': dest.stat().st_size, 'sha256': h})
        report = {'archive': str(ARCHIVE), 'archive_sha256': sha(ARCHIVE),
                  'status': 'PASS', 'file_count': len(records),
                  'bytes': sum(r['bytes'] for r in records), 'files': records,
                  'upstream_executed': False, 'existing_code_changed': False}
        (audit / 'import.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
        print(json.dumps({k: v for k, v in report.items() if k != 'files'}, indent=2))


if __name__ == '__main__':
    main()
