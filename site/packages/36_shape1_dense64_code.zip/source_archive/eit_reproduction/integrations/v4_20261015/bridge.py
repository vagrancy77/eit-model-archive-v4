"""Measurement-only, version-aware inference with safe checkpoint loading."""
from pathlib import Path
import hashlib
import json
import sys

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[1]
UPSTREAM = ROOT / 'upstream'
RECON = UPSTREAM / 'EIT_Reconstruction'
STUDY = PROJECT.parent / 'eit_complex_information_study_20261013'
DATASET = PROJECT.parent / 'eit_dataset_final_v6_4840/extracted/V6_4840_Minimal'
CHECKPOINTS = {
    'imported-original': RECON / 'runs/seed_20260911/v4/best.pt',
    'imported-long': UPSTREAM / 'EIT_Comparison/results/project_v4_long_patience/best.pt',
    'local-calibrated': STUDY / 'runs/controlled_v2/calibrated_seed20261013/best.pt',
}


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def verified_member(path):
    path = Path(path).resolve()
    manifest = json.loads((UPSTREAM / 'MANIFEST.sha256.json').read_text(encoding='utf-8'))
    name = path.relative_to(UPSTREAM.resolve()).as_posix()
    entry = manifest[name]
    if path.stat().st_size != entry['bytes'] or sha(path) != entry['sha256']:
        raise ValueError(f'Upstream integrity mismatch: {name}')


def safe_checkpoint(path, historical=False):
    """Never fall back to unrestricted pickle loading for delivered checkpoints."""
    if historical:
        verified_member(path)
        allowed = {'numpy._core.multiarray._reconstruct', 'numpy.core.multiarray._reconstruct',
                   'numpy.dtype', 'numpy.ndarray'}
        found = set(torch.serialization.get_unsafe_globals_in_checkpoint(path))
        if not found <= allowed:
            raise ValueError(f'Unexpected checkpoint globals: {found - allowed}')
        from numpy._core.multiarray import _reconstruct
        with torch.serialization.safe_globals([
            _reconstruct, (_reconstruct, 'numpy.core.multiarray._reconstruct'),
            np.ndarray, np.dtype, type(np.dtype('uint32')),
        ]):
            return torch.load(path, map_location='cpu', weights_only=True)
    return torch.load(path, map_location='cpu', weights_only=True)


def measurements(path):
    with np.load(path, allow_pickle=False) as z:
        voltage_key = 'eit_voltage' if 'eit_voltage' in z.files else 'voltage'
        background_key = 'eit_background_voltage' if 'eit_background_voltage' in z.files else 'background_voltage'
        v = z[voltage_key].copy()
        b = z[background_key].copy()
        f = z['frequencies_hz'].copy()
    if v.shape != (2, 32, 32) or b.shape != v.shape:
        raise ValueError('Require [frequency,drive,electrode] = [2,32,32]')
    if not (np.iscomplexobj(v) and np.iscomplexobj(b)):
        raise ValueError('Complex voltages required; magnitude-only data is not equivalent')
    if not np.isfinite(v).all() or not np.isfinite(b).all():
        raise ValueError('Nonfinite measured voltage')
    if not np.array_equal(f, [10000, 50000]):
        raise ValueError('Require ordered frequencies [10000,50000] Hz')
    if not np.any(np.abs(b) > 0):
        raise ValueError('Zero background is not a valid calibration reference')
    return v, b, f


def imported_features(v, b, background):
    from .upstream.EIT_Reconstruction.eit.data import input_features
    if background not in ('Fat', 'Muscle'):
        raise ValueError('Imported model requires known background Fat or Muscle')
    negative = (np.arange(32) + 1) % 32
    v = v - v[:, np.arange(32), negative][:, :, None]
    b = b - b[:, np.arange(32), negative][:, :, None]
    with np.load(RECON / 'operators/operators.npz', allow_pickle=False) as z:
        group = z['group_names'].tolist().index(background)
        image, table, dv = input_features(v, b, z['G'][group], z['voltage_scale'][group], z['valid'])
        fov = z['valid'].copy()
        ss, es = float(z['sigma_scale']), float(z['epsilon_scale'])
    with np.load(RECON / 'cache/voltage_normalization.npz', allow_pickle=False) as z:
        table = (table - z['mean']) / z['std']
    if not np.isfinite(image).all() or not np.isfinite(table).all():
        raise ValueError('Nonfinite features')
    return image, table, dv, fov, ss, es


def controlled_module():
    if str(STUDY) not in sys.path:
        sys.path.insert(0, str(STUDY))
    import run_experiment
    return run_experiment


def load_backend(backend, device, checkpoint=None):
    path = Path(checkpoint) if checkpoint else CHECKPOINTS[backend]
    if backend.startswith('imported-'):
        if checkpoint is not None:
            raise ValueError('Use registered historical weights; no implicit architecture conversion')
        from .upstream.EIT_Reconstruction.eit.models import V4
        config = json.loads((RECON / 'config.json').read_text(encoding='utf-8'))
        ck = safe_checkpoint(path, historical=True)
        model = V4(config['v4_base'], config['dropout'], config['propagation_iterations'])
    else:
        module = controlled_module()
        ck = safe_checkpoint(path)
        if ck.get('format') != module.FORMAT or ck.get('mode') != 'calibrated':
            raise ValueError('local-calibrated requires a calibrated controlled-experiment checkpoint')
        model = module.V4Comsol(ck['fov'].numpy(), **ck['model_config'])
    model.load_state_dict(ck['model'], strict=True)
    model.to(device).eval()
    return model, ck, path


@torch.inference_mode()
def infer(backend, input_path, device='cpu', background=None, checkpoint=None):
    v, b, f = measurements(input_path)
    model, ck, path = load_backend(backend, device, checkpoint)
    meta = {'backend': backend, 'checkpoint_sha256': sha(path), 'epoch': int(ck['epoch']),
            'checkpoint_dataset': 'historical 3872-case A-D release; NOT retrained on final 4840',
            'labels_loaded': False, 'protocol': 'ADJACENT32; 250uA; 10/50kHz; radius50mm',
            'axis_order': 'frequency,y,x', 'device': str(device), 'precision': 'float32'}
    if backend.startswith('imported-'):
        image, table, _, fov, ss, es = imported_features(v, b, background)
        out = model(torch.from_numpy(image[None]).to(device), torch.from_numpy(table[None]).to(device))
        result = {k: value[0].float().cpu().numpy() for k, value in out.items()}
        report = json.loads((RECON / 'operators/physics_verification.json').read_text(encoding='utf-8'))
        group = report['groups'][background]
        sb = np.array([g['background_sigma'] for g in group])[:, None, None]
        eb = np.array([g['background_epsilon'] for g in group])[:, None, None]
        result.update(probabilities=result['final'], foreground_probability=result['foreground'],
                      delta_sigma_S_per_m=result['sigma'] * ss, delta_eps_r=result['epsilon'] * es,
                      sigma_S_per_m=(result['sigma'] * ss + sb) * fov,
                      eps_r=(result['epsilon'] * es + eb) * fov, valid_mask=fov, linear_image=image[0])
        meta.update(background=background, material_outputs='unclipped signed deltas plus known background',
                    physics='homogeneous-reference linearized COMSOL; NOT nonlinear CEM')
    else:
        feature = controlled_module().variant_features(v, b)['calibrated']
        feature = (feature - ck['normalizer']['mean'].numpy()) / ck['normalizer']['std'].numpy()
        if not np.isfinite(feature).all():
            raise ValueError('Nonfinite calibrated features')
        out = model(torch.from_numpy(feature[None]).to(device), torch.tensor(f, device=device))
        result = {k: value[0].float().cpu().numpy() for k, value in out.items()}
        result.update(sigma_S_per_m=result['sigma'], delta_sigma_S_per_m=result['delta_sigma'],
                      valid_mask=ck['fov'].numpy(), x=ck['x'].numpy(), y=ck['y'].numpy())
        meta.update(physics='not enabled for this historical calibrated checkpoint',
                    material_outputs='absolute positive conductivity and relative permittivity')
    result['predicted_mask'] = result['foreground_probability'][0] >= .5
    result['frequencies_hz'] = f
    result['metadata_json'] = json.dumps(meta, ensure_ascii=False)
    return result


def save_prediction(output, result):
    output = Path(output)
    if output.suffix.lower() != '.npz':
        raise ValueError('Output must end in .npz')
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('xb') as f:
        np.savez_compressed(f, **result)


def verify_bundle():
    import_report = json.loads((ROOT / 'audit/import.json').read_text(encoding='utf-8'))
    manifest_record = next(r for r in import_report['files'] if r['path']=='MANIFEST.sha256.json')
    if sha(UPSTREAM/'MANIFEST.sha256.json') != manifest_record['sha256']:
        raise ValueError('Upstream manifest differs from the original imported ZIP')
    manifest = json.loads((UPSTREAM / 'MANIFEST.sha256.json').read_text(encoding='utf-8'))
    for name in manifest:
        verified_member(UPSTREAM / name)
    before = json.loads((ROOT / 'audit/local_before.json').read_text(encoding='utf-8'))
    changed = [name for name, digest in before.items() if not Path(name).is_file() or sha(name) != digest]
    return {'upstream_files_verified': len(manifest), 'original_local_code_changed': changed,
            'status': 'PASS', 'upstream_integrity': 'PASS',
            'local_change_note': 'Local adapter changes are reported separately; the imported archive is byte-identical. See FINAL4840_ADAPTATION.md.'}
