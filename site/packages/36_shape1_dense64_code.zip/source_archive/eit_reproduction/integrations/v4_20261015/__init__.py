"""Additive integration; historical and calibrated V4 checkpoints stay separate."""
