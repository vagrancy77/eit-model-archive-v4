"""Recover the validated complex COMSOL derivative from archived real blocks."""
from pathlib import Path
import json

import numpy as np

from .bridge import RECON, verified_member
from comsol_v4.data_v6 import FREQUENCIES, grid_arrays, load_rows, row_case_path, signature, assert_final_dataset, full_sidecar

EPS0 = 8.8541878128e-12
GROUPS = ('Fat', 'Muscle')


def convert(dataset_root, output):
    dataset_root, output = Path(dataset_root), Path(output)
    assert_final_dataset(dataset_root)
    if output.suffix.lower() != '.npz' or output.exists():
        raise ValueError('Output must be a new .npz file; existing files are not overwritten')
    source = RECON / 'operators/operators.npz'
    report_path = RECON / 'operators/physics_verification.json'
    verified_member(source)
    verified_member(report_path)
    report = json.loads(report_path.read_text(encoding='utf-8'))
    if report.get('status') != 'PASS' or report.get('kind') != 'same_COMSOL_generator_gauss_adjoint':
        raise ValueError('Archived COMSOL finite-difference audit is not valid')
    x, y, fov = grid_arrays(dataset_root)
    if x.shape != (64,) or y.shape != (64,) or not np.allclose(x, np.linspace(-.05, .05, 64), atol=1e-9) or not np.array_equal(x, y):
        raise ValueError('Reference and dataset coordinates do not match')
    rows = load_rows(dataset_root, 'train')
    if len(rows) != 3400:
        raise ValueError('Expected 3400 final training cases')
    with np.load(source, allow_pickle=False) as z:
        valid = z['valid']
        if not np.array_equal(valid, fov) or z['group_names'].tolist() != list(GROUPS):
            raise ValueError('Archived operator and dataset FOV/background differ')
        n = int(valid.sum())
        a = z['A']
        scale = z['voltage_scale']
        ss, es = float(z['sigma_scale']), float(z['epsilon_scale'])
        if a.shape != (2, 2, 2048, 2*n) or scale.shape != (2, 2) or not np.isfinite(a).all() or not np.all(scale > 0):
            raise ValueError('Unexpected or nonfinite archived reference blocks')
        if ss != .2 or es != 50000:
            raise ValueError('Archived material normalization has changed')
        jac = np.zeros((2, 2, 32, 32, 4096), dtype=np.complex64)
        checks = []
        for gi, group in enumerate(GROUPS):
            for fi, frequency in enumerate(FREQUENCIES):
                block = a[gi, fi]
                sigma_block = block[:1024, :n] + 1j*block[1024:, :n]
                epsilon_block = block[:1024, n:] + 1j*block[1024:, n:]
                expected = sigma_block*(1j*2*np.pi*frequency*EPS0*es/ss)
                error = float(np.linalg.norm(epsilon_block-expected)/max(np.linalg.norm(epsilon_block), 1e-30))
                if error > 2e-6:
                    raise ValueError(f'Conductivity/permittivity derivative mismatch: {group}, {frequency}: {error}')
                full = jac[gi, fi].reshape(1024, 4096)
                full[:, valid.ravel()] = (sigma_block*scale[gi, fi]/ss).astype(np.complex64)
                negative = (np.arange(32)+1) % 32
                reference_error = float(np.max(np.abs(full.reshape(32, 32, 4096)[np.arange(32), negative])))
                if reference_error > 2e-8:
                    raise ValueError('Archived derivative has a different voltage gauge')
                info = report['groups'][group][fi]
                if (info['frequency_hz'] != frequency or
                        not np.isclose(info['voltage_scale'], scale[gi, fi], rtol=1e-10)):
                    raise ValueError('Operator and verification report disagree')
                checks.append({'group': group, 'frequency_hz': int(frequency),
                               'epsilon_block_relative_error': error, 'negative_electrode_max_abs': reference_error})
        for gi, group in enumerate(GROUPS):
            representative = next((r for r in rows if r['case_id'] == ('A_000001' if group == 'Fat' else 'A_000055')), None)
            if representative is None:
                raise ValueError(f'Missing archived {group} train representative')
            with np.load(row_case_path(dataset_root, representative), allow_pickle=False) as case:
                key = 'eit_background_voltage' if 'eit_background_voltage' in case.files else 'background_voltage'
                measured = case[key].copy()
            negative = (np.arange(32)+1) % 32
            measured -= measured[:, np.arange(32), negative][:, :, None]
            expected = z['reference'][gi]
            relative = float(np.linalg.norm(measured-expected)/np.linalg.norm(expected))
            if relative > 1e-8:
                raise ValueError(f'Reference voltage does not match {group} dataset: {relative}')
            checks.append({'group': group, 'background_voltage_relative_error': relative})
        background_sigma = np.array([[r['background_sigma'] for r in report['groups'][g]] for g in GROUPS], dtype=np.float32)
        background_eps = np.array([[r['background_epsilon'] for r in report['groups'][g]] for g in GROUPS], dtype=np.float32)
        reference_errors = {}
        # Same electrode protocol does not imply identical meshes. Measure, do not
        # hide, per-case homogeneous-reference FEM discrepancies, including class E.
        for i, row in enumerate(rows):
            path = row_case_path(dataset_root,row)
            with np.load(path,allow_pickle=False) as case:
                params = json.loads(case['parameters_json'].item()) if 'parameters_json' in case.files else full_sidecar(path)[1]
                key = 'eit_background_voltage' if 'eit_background_voltage' in case.files else 'background_voltage'
                measured = case[key].copy()
            gi = GROUPS.index(params['background_material'])
            if (float(params['R']) != .05 or float(params['i0_ma']) != .25 or
                    int(params['ne']) != 32 or params['drive_mode'] != 'adjacent' or
                    params['adjacent_return'] != 'next' or
                    not np.allclose(np.fromstring(params['elec_angles_deg'],sep=' '),np.arange(32)*11.25) or
                    not np.allclose(np.fromstring(params['w_deg'],sep=' '),np.full(32,5.))):
                raise ValueError('Reference acquisition differs: '+row['case_id'])
            for fi, suffix in enumerate(('10','50')):
                if (not np.isclose(float(params['sig_b'+suffix]),background_sigma[gi,fi],rtol=1e-6) or
                        not np.isclose(float(params['eps_b'+suffix]),background_eps[gi,fi],rtol=1e-6)):
                    raise ValueError('Reference material differs: '+row['case_id'])
            measured -= measured[:, np.arange(32), negative][:, :, None]
            relative = float(np.linalg.norm(measured-z['reference'][gi])/np.linalg.norm(z['reference'][gi]))
            # A predeclared guard against a different acquisition; not an accuracy claim.
            if not np.isfinite(relative) or relative > .01:
                raise ValueError(f'Reference mismatch exceeds 1% compatibility guard: {row["case_id"]}: {relative}')
            reference_errors.setdefault(row['shape_class']+'_'+GROUPS[gi],[]).append(relative)
            if (i+1)%1000 == 0: print(f'Physical reference compatibility: {i+1}/{len(rows)}',flush=True)
        checks.append({'training_reference_comparison': {
            key:{'count':len(values),'mean_relative_l2':float(np.mean(values)),'max_relative_l2':max(values)}
            for key,values in reference_errors.items()}, 'guard_relative_l2':.01})
    metadata = {'format': 'comsol_v4_reference_jacobian_v1',
                'boundary_model': 'current_terminal_no_effective_contact_impedance',
                'axis_order': 'group,frequency,drive,electrode,pixel_yx',
                'derivative': 'dV_dgamma', 'voltage_reference': 'injection_return',
                'gamma_convention': 'sigma_plus_jomega_eps0_epsr',
                'validation_status': 'PASS', 'kind': 'FEM_adjoint',
                'current_A': .00025, 'radius_m': .05,
                'source': str(source), 'source_audit': str(report_path),
                'dataset_signature': signature(dataset_root),
                'approximation': 'homogeneous-background first-order; not nonlinear FEM',
                'validation_scope': 'Original archived homogeneous FEM derivative audit plus all 3400 final training reference/protocol comparisons; NO new per-case or class-E Jacobian finite-difference audit',
                'reference_mismatch_policy': 'Per-case mesh/reference discrepancy retained; operator is optional approximate auxiliary, not exact data-consistency',
                'checks': checks}
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('xb') as f:
        np.savez_compressed(f, jacobian_gamma=jac, background_sigma=background_sigma,
                            background_eps_r=background_eps, x=x, y=y, valid_mask=fov,
                            frequencies_hz=FREQUENCIES, group_names=np.array(GROUPS),
                            metadata_json=json.dumps(metadata))
    return {'status': 'PASS', 'output': str(output), 'bytes': output.stat().st_size,
            'shape': list(jac.shape), 'checks': checks, 'dataset_signature': metadata['dataset_signature']}
