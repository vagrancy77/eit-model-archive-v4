"""Combine independently executed held-out-layer multi-frequency runs."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from train_public_multifrequency_eit import bootstrap_comparisons, save_plot


def main() -> None:
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Aggregate L1/L2/L3 public multi-frequency experiment runs.")
    parser.add_argument("inputs", nargs="+", type=Path, help="output directories containing per_sample_metrics.csv and summary.json")
    parser.add_argument("--output-dir", type=Path, default=root / "outputs_public_multifrequency_geometry_pilot")
    arguments = parser.parse_args()
    rows: list[dict[str, object]] = []
    folds: list[dict[str, object]] = []
    sources: list[str] = []
    for directory in arguments.inputs:
        with (directory / "per_sample_metrics.csv").open("r", encoding="utf-8", newline="") as handle:
            rows.extend(csv.DictReader(handle))
        with (directory / "summary.json").open("r", encoding="utf-8") as handle:
            summary = json.load(handle)
        folds.extend(summary["folds"])
        sources.append(str(directory.resolve()))
    test_layers = [str(item["test_layer"]) for item in folds]
    if sorted(test_layers) != ["L1", "L2", "L3"]:
        raise ValueError(f"expected exactly one L1/L2/L3 fold, got {test_layers}")
    arguments.output_dir.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows for key in row})
    with (arguments.output_dir / "per_sample_metrics.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    comparison = bootstrap_comparisons(rows)
    aggregate = {
        "study": "aggregated held-out-layer shared-geometry multi-frequency pilot",
        "sources": sources,
        "test_layers": test_layers,
        "folds": folds,
        "paired_comparisons": comparison,
        "interpretation": "GN pseudo-target fidelity and synthetic-noise stability only; not conductivity ground-truth accuracy",
    }
    with (arguments.output_dir / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(aggregate, handle, ensure_ascii=False, indent=2)
    save_plot(rows, arguments.output_dir / "comparison.png")
    print(json.dumps({"output": str(arguments.output_dir.resolve()), "rows": len(rows), "folds": test_layers, "comparisons": len(comparison)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
