"""Plot target, joint and factorized Edinburgh mfEIT reconstructions."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch

from pytorch_eit.multifrequency import JointFrequencyAnomalyNet, SharedGeometryFrequencyContrastAnomalyNet


def model_dimensions(state: dict[str, torch.Tensor]) -> tuple[int, int]:
    latent_dim = int(state["encoder.stem.0.weight"].shape[0])
    base_channels = int(state["decoder.project.0.weight"].shape[0] // 16)
    return latent_dim, base_channels


def load_model(path: Path, name: str, device: torch.device) -> torch.nn.Module:
    checkpoint = torch.load(path, map_location=device, weights_only=False)
    state = checkpoint["model_state"]
    config = checkpoint.get("model_config")
    if config is None:
        latent_dim, base_channels = model_dimensions(state)
    else:
        latent_dim = int(config["latent_dim"])
        base_channels = int(config["base_channels"])
    if name == "joint":
        model = JointFrequencyAnomalyNet(104, 4, latent_dim, base_channels)
    else:
        model = SharedGeometryFrequencyContrastAnomalyNet(104, 4, latent_dim, base_channels)
    model.load_state_dict(state)
    model.to(device).eval()
    return model


def main() -> None:
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Plot Edinburgh mfEIT reconstruction examples.")
    parser.add_argument("--run-dir", type=Path, default=root / "outputs_edinburgh_mfeit_balanced_long_pilot")
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "datasets" / "public" / "edinburgh_mfeit" / "edinburgh_mfeit_manifest_v1.npz",
    )
    parser.add_argument("--output-dir", type=Path, default=None)
    parser.add_argument("--cpu", action="store_true")
    arguments = parser.parse_args()
    output_dir = arguments.output_dir or arguments.run_dir / "examples"
    output_dir.mkdir(parents=True, exist_ok=True)

    manifest = np.load(arguments.manifest)
    source = Path(str(np.asarray(manifest["source_root"]).reshape(()).item()))
    mean = np.asarray(manifest["voltage_mean"], dtype=np.float32)
    scale = np.asarray(manifest["voltage_std"], dtype=np.float32)
    cases = np.asarray(manifest["test_case"], dtype=np.int8)
    indices = np.asarray(manifest["test_index"], dtype=np.int64)
    selected = [int(np.flatnonzero(cases == case)[0]) for case in (1, 2, 3)]
    device = torch.device("cpu" if arguments.cpu or not torch.cuda.is_available() else "cuda")
    joint = load_model(arguments.run_dir / "joint.pt", "joint", device)
    factorized = load_model(arguments.run_dir / "factorized.pt", "factorized", device)
    coordinate = torch.arange(1, 5, dtype=torch.float32, device=device)[None]

    for position in selected:
        case = int(cases[position])
        index = int(indices[position])
        voltage_source = np.load(source / f"V{case}.npy", mmap_mode="r")
        image_source = np.load(source / f"img{case}.npy", mmap_mode="r")
        voltage = np.array(voltage_source[index], dtype=np.float32, copy=True)
        voltage = (voltage - mean[None]) / scale[None]
        target = np.clip(-np.array(image_source[index], dtype=np.float32, copy=True).reshape(4, 64, 64), 0, 1)
        voltage_tensor = torch.from_numpy(voltage)[None].to(device)
        with torch.no_grad():
            joint_prediction = joint(voltage_tensor, coordinate)[:, :, 0].cpu().numpy()[0]
            factor_output = factorized(voltage_tensor, coordinate, return_auxiliary=True)
            factor_prediction = factor_output["reconstruction"][:, :, 0].cpu().numpy()[0]
            contrasts = factor_output["frequency_contrast"][:, :, 0].cpu().numpy()[0]
            geometry = factor_output["geometry"][:, 0].cpu().numpy()[0]

        figure, axes = plt.subplots(5, 4, figsize=(12, 14), constrained_layout=True)
        rows = [target, joint_prediction, factor_prediction, contrasts]
        labels = ["Ground truth", "Joint", "Factorized", "Frequency contrast"]
        for row, (images, label) in enumerate(zip(rows, labels)):
            for frequency in range(4):
                axes[row, frequency].imshow(images[frequency], vmin=0, vmax=1, cmap="viridis")
                axes[row, frequency].set_title(f"{label}: f{frequency + 1}")
                axes[row, frequency].axis("off")
        for frequency in range(4):
            axes[4, frequency].imshow(geometry, vmin=0, vmax=1, cmap="magma")
            axes[4, frequency].set_title("Shared geometry" if frequency == 0 else "same shared map")
            axes[4, frequency].axis("off")
        figure.suptitle(f"Edinburgh mfEIT case {case}, sample {index}", fontsize=16)
        output = output_dir / f"case_{case}_sample_{index}.png"
        figure.savefig(output, dpi=170)
        plt.close(figure)
        print(output)


if __name__ == "__main__":
    main()
