"""Plot exported predictions using NumPy/matplotlib (no PyTorch required)."""
import argparse, json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def main():
    p=argparse.ArgumentParser(); p.add_argument('--predictions',type=Path,required=True); p.add_argument('--max-cases',type=int,default=5)
    a=p.parse_args(); report=json.loads((a.predictions/'predictions.json').read_text(encoding='utf-8'))
    ids=report['case_ids'][:a.max_cases]; fig,axes=plt.subplots(len(ids),5,figsize=(17,3.1*len(ids)),squeeze=False,constrained_layout=True)
    for row,case in enumerate(ids):
        with np.load(a.predictions/f'{case}.npz') as z:
            fov=z['valid_mask'].astype(bool); extent=np.array([z['x'][0],z['x'][-1],z['y'][0],z['y'][-1]])*1000
            true=z['true_conductivity_S_per_m'] if 'true_conductivity_S_per_m' in z else None
            panels=[('True lesion',z['true_lesion_mask'][0] if true is not None else fov,0,1),
                    ('True sigma 10 kHz',true[0] if true is not None else np.zeros_like(fov),None,None),
                    ('Pred sigma 10 kHz',z['conductivity_S_per_m'][0],None,None),
                    ('Pred sigma 50 kHz',z['conductivity_S_per_m'][1],None,None),
                    ('Pred lesion probability',z['foreground_probability'][0],0,1)]
            lo=min(float(z['conductivity_S_per_m'].min()),float(true[:,fov].min()) if true is not None else 0)
            hi=max(float(z['conductivity_S_per_m'].max()),float(true[:,fov].max()) if true is not None else 1)
            for col,(title,img,vmin,vmax) in enumerate(panels):
                ax=axes[row,col]; im=ax.imshow(np.where(fov,img,np.nan),origin='lower',extent=extent,cmap='viridis',vmin=lo if vmin is None else vmin,vmax=hi if vmax is None else vmax)
                ax.set_title(f'{case}\n{title}',fontsize=10); ax.set_xlabel('x (mm)'); ax.set_ylabel('y (mm)'); fig.colorbar(im,ax=ax,shrink=.72)
    fig.suptitle('V4 / full COMSOL V6 — INTERFACE SMOKE ONLY, NOT A TRAINED RESULT' if report['smoke_checkpoint'] else 'V4 / full COMSOL V6 reconstruction',fontsize=14)
    path=a.predictions/'interface_preview.png'; fig.savefig(path,dpi=140); plt.close(fig); print(path)


if __name__=='__main__':main()
