"""Compatibility import: both minimal and full V6 use one native reader."""
from .data_v6 import (ComsolDataset, Normalizer, FREQUENCIES, CHANNELS,
                      resolve_root, row_case_path, grid_arrays, signature,
                      verify_manifest, load_rows, measurement_features,
                      read_features, full_sidecar, file_hash)
