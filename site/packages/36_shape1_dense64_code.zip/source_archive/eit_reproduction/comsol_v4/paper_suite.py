"""Serial GPU study worker with crash-safe resumable jobs and automatic reporting."""
import argparse,json,os,subprocess,sys,time
from pathlib import Path
from .paper_common import protocol,load_protocol,write_json

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--initialize',action='store_true');a=ap.parse_args()
    root=a.root.resolve();root.mkdir(parents=True,exist_ok=True)
    acceptance=json.loads((root/'acceptance.json').read_text(encoding='utf-8'))
    if acceptance['status']!='PASS':raise ValueError('Required regression acceptance missing')
    if not (root/'protocol.json').exists():write_json(root/'protocol.json',protocol())
    p,phash=load_protocol(root)
    if a.initialize:print('Protocol frozen: '+phash,flush=True);return
    lock=(root/'worker.lock').open('a+b')
    if lock.seek(0,2)==0:lock.write(b'0');lock.flush()
    lock.seek(0)
    import msvcrt
    try:msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
    except OSError:raise RuntimeError('Another suite worker owns this directory')
    logs=root/'logs';logs.mkdir(exist_ok=True);jobs=[]
    for variant in p['variants']:
        for seed in p['seeds']:
            name=f'{variant}_seed{seed}'
            jobs.append(('train',name,[sys.executable,'-B','-m','comsol_v4.paper_train','--root',str(root),'--variant',variant,'--seed',str(seed)]))
    jobs.append(('evaluate','evaluate_all',[sys.executable,'-B','-m','comsol_v4.paper_evaluate','--root',str(root)]))
    jobs.append(('report','report_all',['E:/Anaconda/python.exe','-B','-s',str(Path(__file__).with_name('paper_report.py')),str(root)]))
    for index,(phase,name,command) in enumerate(jobs):
        print(f'Job {index+1}/{len(jobs)}: {name}',flush=True)
        with (logs/(name+'.log')).open('a',encoding='utf-8') as log:
            log.write('\nRESUME/START '+time.strftime('%Y-%m-%d %H:%M:%S')+'\n');log.flush()
            process=subprocess.Popen(command,cwd=Path(__file__).resolve().parents[1],stdout=log,stderr=subprocess.STDOUT,
                                     creationflags=subprocess.CREATE_NO_WINDOW)
            while True:
                result=process.poll()
                status={'status':'running' if result is None else ('job_complete' if result==0 else 'failed'),
                        'phase':phase,'job':name,'job_index':index+1,'total_jobs':len(jobs),'worker_pid':os.getpid(),
                        'child_pid':process.pid,'protocol_sha256':phash,'updated_unix':time.time(),'exit_code':result}
                write_json(root/'status.json',status)
                if result is not None:break
                time.sleep(15)
        if result:raise RuntimeError(f'{name} failed ({result}); inspect {logs/(name+".log")}')
    write_json(root/'status.json',{'status':'complete','protocol_sha256':phash,'updated_unix':time.time(),'total_jobs':len(jobs)})
    print('ALL TRAINING, EVALUATION AND REPORTS COMPLETE',flush=True)

if __name__=='__main__':main()
