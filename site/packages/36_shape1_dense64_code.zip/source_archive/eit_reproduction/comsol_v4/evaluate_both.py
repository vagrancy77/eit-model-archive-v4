"""Run one frozen final-data checkpoint through both independently read layouts."""
import argparse,json,sys,subprocess
from pathlib import Path
import torch
from .data_v6 import FINAL_DATASET_ROOT,file_hash,signature
from .infer import main as infer
from .compare_layouts import validate_equivalence_report


def main():
    p=argparse.ArgumentParser();p.add_argument('--run-dir',type=Path,required=True)
    p.add_argument('--full-root',type=Path,required=True);p.add_argument('--output-dir',type=Path,required=True)
    p.add_argument('--equivalence-report',type=Path,required=True);p.add_argument('--batch-size',type=int,default=16)
    a=p.parse_args();torch.set_num_threads(2)
    summary=json.loads((a.run_dir/'summary.json').read_text(encoding='utf-8'))
    if summary['smoke'] or len(summary['history'])!=50 or summary['history'][-1]['epoch']!=50:
        raise ValueError('This prespecified run requires all 50 epochs; refusing premature test evaluation')
    checkpoint=a.run_dir/'best.pt';ck=torch.load(checkpoint,map_location='cpu',weights_only=True)
    if ck['args']['smoke'] or json.loads(ck['normalizer']['metadata_json']).get('input_mode')!='calibrated':
        raise ValueError('Expected formal calibrated checkpoint')
    digest=file_hash(checkpoint)
    equivalence=validate_equivalence_report(a.equivalence_report,a.full_root,ck['dataset_signature'])
    manifest={'format':'final4840_minimal_full_frozen_evaluation_v1','checkpoint':str(checkpoint.resolve()),
              'checkpoint_sha256':digest,'selected_epoch':ck['epoch'],'trained_epochs':50,'seed':ck['args']['seed'],
              'selection':ck['selection_objective'],'input_mode':'calibrated','physics_active':False,
              'batch_size':a.batch_size,'case_order':'case_id ascending','equivalence':equivalence,
              'minimal_root':str(FINAL_DATASET_ROOT),'full_root':str(a.full_root.resolve()),
              'splits':['train','val','test'],'primary_result':'test only; train and val are diagnostic',
              'single_seed':True,'test_used_for_selection':False}
    if ck['model_config']['physics_input']: raise ValueError('This runner is for the prespecified calibration-only model')
    del ck
    a.output_dir.mkdir(parents=True,exist_ok=True)
    path=a.output_dir/'run_manifest.json'
    if path.exists() and json.loads(path.read_text(encoding='utf-8'))!=manifest:
        raise ValueError('Output directory is bound to another frozen checkpoint/configuration')
    path.write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    for layout,root in [('minimal',FINAL_DATASET_ROOT),('full',a.full_root)]:
        for split in ('train','val','test'):
            target=a.output_dir/layout/split
            if (target/'predictions.json').exists():
                old=json.loads((target/'predictions.json').read_text(encoding='utf-8'))
                expected={'train':3400,'val':720,'test':720}[split]
                if (old['checkpoint_sha256']!=digest or old['dataset_signature']!=signature(root) or
                        old['case_count']!=expected or old.get('canonical_order') is not True):
                    raise ValueError('Stale or incomplete evaluation outputs')
                if not all((target/(cid+'.npz')).is_file() for cid in old['case_ids']):
                    raise FileNotFoundError('Missing prediction file in completed output')
                print('Reuse completed '+layout+'/'+split,flush=True);continue
            print('Evaluate frozen checkpoint: '+layout+'/'+split,flush=True)
            command=['--checkpoint',str(checkpoint),'--dataset-root',str(root),'--split',split,'--evaluate',
                     '--device','cuda','--batch-size',str(a.batch_size),'--canonical-order','--output-dir',str(target)]
            if layout=='full': command+=['--equivalence-report',str(a.equivalence_report)]
            infer(command)
            torch.cuda.empty_cache()
    python=Path('E:/Anaconda/python.exe')
    if not python.exists():python=Path(sys.executable)
    options=['-B','-s'] if python==Path('E:/Anaconda/python.exe') else ['-B']
    subprocess.run([str(python),*options,str(Path(__file__).with_name('report_both.py')),str(a.output_dir)],check=True)
    print('COMPLETE frozen minimal/full evaluation: '+str(a.output_dir),flush=True)


if __name__=='__main__':main()
