"""Stage the exact full inner archive; no dataset content is rewritten."""
import hashlib
from pathlib import Path
import zipfile
import argparse
import subprocess
import shutil
import json

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'eit_dataset_final_v6_4840/archives/EIT_V6_4840_full.7z'
EXPECTED='1861176a0d9471d1b75fb567aea877eae15ab73ad37f67c037a4b34ad0f74310'


def stage():
    OUT.parent.mkdir(parents=True,exist_ok=True)
    if OUT.exists():
        with OUT.open('rb') as stream: digest=hashlib.file_digest(stream,'sha256').hexdigest()
        if digest != EXPECTED: raise ValueError('Existing full archive has wrong hash')
        print('Existing archive verified: '+str(OUT),flush=True);return
    partial=OUT.with_suffix('.7z.partial')
    if partial.exists(): raise FileExistsError('Inspect existing partial archive before restarting: '+str(partial))
    digest=hashlib.sha256();total=0;last=0
    with zipfile.ZipFile(ROOT/'数据集v6_新.zip') as archive:
        matches=[i for i in archive.infolist() if i.filename.endswith('/EIT_V6_4840_full.7z')]
        if len(matches)!=1 or matches[0].file_size!=5996005825: raise ValueError('Unexpected full archive member')
        with archive.open(matches[0]) as source, partial.open('xb') as target:
            for block in iter(lambda:source.read(8*1024*1024),b''):
                target.write(block);digest.update(block);total+=len(block)
                if total-last>512*1024*1024:
                    print(f'Staging full archive {total/1e9:.2f}/6.00 GB',flush=True);last=total
    if digest.hexdigest()!=EXPECTED: raise ValueError('Full inner archive hash mismatch; partial preserved')
    if not partial.resolve().is_relative_to(OUT.parent.resolve()): raise ValueError('Unsafe staging path')
    partial.rename(OUT)
    print('PASS exact full archive SHA256 '+EXPECTED,flush=True)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--extract',action='store_true');args=parser.parse_args()
    stage()
    if not args.extract:return
    seven=shutil.which('7z')
    if not seven: raise FileNotFoundError('7z is required')
    listing=subprocess.run([seven,'l','-slt','-ba',str(OUT)],check=True,capture_output=True,encoding='utf-8',errors='replace').stdout
    destination=OUT.parent.parent/'extracted'
    total=0;count=0
    for entry in listing.split('\n\n'):
        values=dict(line.split(' = ',1) for line in entry.splitlines() if ' = ' in line)
        if 'Path' not in values:continue
        name=values['Path'].replace('\\','/')
        path=Path(name)
        if (path.is_absolute() or ':' in name or '..' in path.parts or
                path.parts[0]!='full4840' or any('Link' in key for key in values)):
            raise ValueError('Unsafe full-archive entry: '+name)
        total+=int(values.get('Size','0') or 0);count+=1
    if shutil.disk_usage(destination).free<total+2*1024**3: raise RuntimeError('Insufficient disk space')
    print(f'Validated {count} archive entries, {total/1e9:.2f} GB unpacked; extracting without overwriting',flush=True)
    subprocess.run([seven,'x',str(OUT),'-o'+str(destination),'-aos','-bsp0'],check=True)
    (OUT.parent.parent/'full_extraction.json').write_text(json.dumps({'archive':str(OUT),'sha256':EXPECTED,
        'entry_count':count,'unpacked_bytes':total,'output':str(destination/'full4840'),'status':'7z extraction PASS'},indent=2),encoding='utf-8')


if __name__=='__main__':main()
