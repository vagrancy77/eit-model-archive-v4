"""Save fixed validation snapshots independently of the plotting environment."""
import json
from pathlib import Path
import subprocess
import sys
import numpy as np
import torch

def save_progress(model,dataset,dev,physics,history,output_dir):
    from .train import move,predict
    from torch.utils.data import default_collate
    selected=[min((i for i,r in enumerate(dataset.rows) if r['shape_class']==c),
                  key=lambda i:dataset.rows[i]['case_id']) for c in sorted({r['shape_class'] for r in dataset.rows})]
    batch=move(default_collate([dataset[i] for i in selected]),dev)
    model.eval()
    with torch.no_grad(): out=predict(model,batch,physics)
    epoch=history[-1]['epoch'];path=output_dir/f'validation_epoch_{epoch:03d}.npz'
    np.savez_compressed(path,case_ids=np.array(batch['case_id']),fov=dataset.fov,
        truth_mask=batch['mask'].cpu().numpy(),truth_sigma=batch['sigma'].cpu().numpy(),
        truth_eps_r=batch['eps_r'].cpu().numpy(),probabilities=out['probabilities'].cpu().numpy(),
        sigma=out['sigma'].cpu().numpy(),eps_r=out['eps_r'].cpu().numpy(),history_json=json.dumps(history))
    python=Path('E:/Anaconda/python.exe')
    if not python.exists(): python=Path(sys.executable)
    result=subprocess.run([str(python),'-B',str(Path(__file__).with_name('render_progress.py')),str(path)],capture_output=True,text=True)
    if result.returncode:
        print('Preview arrays saved; external renderer deferred: '+result.stderr[-1200:],flush=True)
    else: print('Saved validation preview '+str(path.with_suffix('.png')),flush=True)
