"""Render actual frozen minimal/full predictions and report paired layout checks."""
import sys,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

PROJECT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(PROJECT.parent/'eit_complex_information_study_20261013'))
from analyze_experiment import boundary_metrics


def write(path,data): path.write_text(json.dumps(data,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')


def summarize(records):
    groups={'all':records,'convex_A':[r for r in records if r['shape_class']=='A'],
            'concave_BCDE':[r for r in records if r['shape_class'] in 'BCDE']}
    groups.update({c:[r for r in records if r['shape_class']==c] for c in 'ABCDE'})
    output={}
    for key,rows in groups.items():
        item={'case_count':len(rows)}
        for field in sorted(set().union(*(r.keys() for r in rows))):
            vals=[r[field] for r in rows if isinstance(r.get(field),(int,float))]
            if vals:item[field]=float(np.mean(vals))
        item['notch_direction_valid_count']=sum(isinstance(r.get('notch_direction_correct'),(int,float)) for r in rows)
        output[key]=item
    return output


def figures(root,ids,manifest,test_records):
    def read(layout,cid):
        with np.load(root/layout/'test'/(cid+'.npz'),allow_pickle=False) as z:return {k:z[k].copy() for k in z.files}
    # First two case IDs of every group; fixed without looking at scores.
    chosen=[cid for cls in 'ABCDE' for cid in sorted(i for i in ids if i.startswith(cls+'_'))[:2]]
    fig,axes=plt.subplots(len(chosen),3,figsize=(10.5,2.65*len(chosen)),squeeze=False,constrained_layout=True)
    for i,cid in enumerate(chosen):
        left,right=read('minimal',cid),read('full',cid)
        truth=left['true_lesion_mask'][0].astype(bool);fov=left['valid_mask'].astype(bool)
        for j,(title,mask) in enumerate([('Truth',truth),('Minimal',left['electrical_class']!=0),('Full',right['electrical_class']!=0)]):
            ax=axes[i,j];ax.imshow(np.where(fov,mask,np.nan),origin='lower',cmap='Greys',vmin=0,vmax=1)
            score=float((mask&truth&fov).sum()/max(((mask|truth)&fov).sum(),1))
            if j:ax.contour(truth,[.5],colors='#e03131',linewidths=.7)
            ax.set_title(title+(f' | IoU {score:.3f}' if j else ''),fontsize=10)
            ax.set_xticks([]);ax.set_yticks([])
        axes[i,0].set_ylabel(cid)
    fig.suptitle(f'FROZEN TEST | same checkpoint, selected epoch {manifest["selected_epoch"]}\nFirst two IDs per class, not best-case selection; red = truth boundary')
    fig.savefig(root/'test_shapes.png',dpi=150);plt.close(fig)
    worst=sorted(test_records,key=lambda r:(r['foreground_iou'],r['case_id']))[:5]
    fig,axes=plt.subplots(5,3,figsize=(10.5,13.25),squeeze=False,constrained_layout=True)
    for i,row in enumerate(worst):
        cid=row['case_id'];left,right=read('minimal',cid),read('full',cid)
        truth=left['true_lesion_mask'][0].astype(bool);fov=left['valid_mask'].astype(bool)
        for j,(title,mask) in enumerate([('Truth',truth),('Minimal',left['electrical_class']!=0),('Full',right['electrical_class']!=0)]):
            ax=axes[i,j];ax.imshow(np.where(fov,mask,np.nan),origin='lower',cmap='Greys',vmin=0,vmax=1)
            if j:ax.contour(truth,[.5],colors='#e03131',linewidths=.8)
            ax.set_title(title+(f' | IoU {row["foreground_iou"]:.3f}' if j else ''))
            ax.set_xticks([]);ax.set_yticks([])
        axes[i,0].set_ylabel(cid)
    fig.suptitle('FROZEN TEST | five lowest-IoU cases (diagnostic selection)\nNot a representative sample; no model tuning after inspecting test results')
    fig.savefig(root/'test_low_iou_cases.png',dpi=140);plt.close(fig)
    for field,true_field,title in [('conductivity_S_per_m','true_conductivity_S_per_m','sigma (S/m)'),('eps_r','true_eps_r','relative permittivity')]:
        one_each=chosen[::2]
        fig,axes=plt.subplots(5,6,figsize=(18,14),squeeze=False,constrained_layout=True)
        for i,cid in enumerate(one_each):
            left,right=read('minimal',cid),read('full',cid);fov=left['valid_mask'].astype(bool)
            for fi,frequency in enumerate((10,50)):
                truth=left[true_field][fi];lo,hi=float(truth[fov].min()),float(truth[fov].max())
                for j,(name,v) in enumerate([('Truth',truth),('Minimal',left[field][fi]),('Full',right[field][fi])]):
                    ax=axes[i,fi*3+j];im=ax.imshow(np.where(fov,v,np.nan),origin='lower',vmin=lo,vmax=hi,cmap='viridis')
                    ax.set_title(f'{name} {frequency} kHz',fontsize=10);ax.set_xticks([]);ax.set_yticks([])
                fig.colorbar(im,ax=list(axes[i,fi*3:fi*3+3]),shrink=.7)
            axes[i,0].set_ylabel(cid)
        fig.suptitle(f'FROZEN TEST | {title} | fixed first ID per class\nTruth-based shared color range per frequency; out-of-range predictions clipped only in visualization')
        fig.savefig(root/('test_sigma.png' if field=='conductivity_S_per_m' else 'test_eps_r.png'),dpi=135);plt.close(fig)
    # Phase is actually present in the measurements. This visualization is not a phase ablation.
    fig,axes=plt.subplots(5,4,figsize=(15,15),squeeze=False,constrained_layout=True)
    d,m=np.indices((32,32));neg=(d+1)%32
    valid=~((m==d)|((m+1)%32==d)|(m==neg)|((m+1)%32==neg))
    for i,cid in enumerate(chosen[::2]):
        with np.load(Path(manifest['minimal_root'])/'cases'/(cid+'.npz'),allow_pickle=False) as z:
            v,b=z['voltage'][0],z['background_voltage'][0]
        qv,qb=v-np.roll(v,-1,-1),b-np.roll(b,-1,-1)
        rms=np.sqrt((abs(qb)**2)[valid].mean())
        calibrated=(qv-qb)*qb.conj()/(abs(qb)**2+(.01*rms)**2)
        values=[abs(qv),np.angle(qv,deg=True),np.angle(qv*qb.conj(),deg=True),calibrated.imag]
        titles=['Voltage magnitude (V)','Voltage phase (deg)','Case/reference phase difference (deg)','Calibrated residual: imaginary']
        for j,(value,title) in enumerate(zip(values,titles)):
            ax=axes[i,j];im=ax.imshow(np.where(valid,value,np.nan),origin='lower',cmap='viridis' if j==0 else 'coolwarm')
            ax.set_title(title,fontsize=9);ax.set_xlabel('adjacent measurement pair');ax.set_ylabel(cid+' / drive');fig.colorbar(im,ax=ax,shrink=.7)
    fig.suptitle('Actual 10 kHz phase-bearing inputs | excluded drive-touching pairs masked\nThis illustrates available information, NOT evidence of a gain over a separately trained amplitude-only model')
    fig.savefig(root/'test_phase_inputs.png',dpi=135);plt.close(fig)


def main(root):
    root=Path(root);manifest=json.loads((root/'run_manifest.json').read_text())
    report={'run':manifest,'splits':{},'layout_output_comparison':{},'test':{},'limitations':[
        'Single seed, synthetic fixed-protocol dataset; no clinical or independent-device claim.',
        'Minimal and full are two layouts of the same cases, not two independent test datasets.',
        'No amplitude-only model trained in this run; phase contribution is not established by these scores.',
        'Training and validation predictions are diagnostic only; the primary result is the 720-case test partition.']}
    test_records={};test_ids=None
    fields=('conductivity_S_per_m','eps_r','probabilities','sdf','electrical_class')
    for split in ('train','val','test'):
        records={name:json.loads((root/name/split/'predictions.json').read_text()) for name in ('minimal','full')}
        if records['minimal']['case_ids']!=records['full']['case_ids']:raise ValueError('Case/batch order differs')
        ids=records['minimal']['case_ids'];maxdiff={key:0. for key in fields};unequal=0
        report['splits'][split]={layout:r['metrics'] for layout,r in records.items()}
        enriched={layout:[] for layout in records}
        for i,cid in enumerate(ids):
            with np.load(root/'minimal'/split/(cid+'.npz'),allow_pickle=False) as l,np.load(root/'full'/split/(cid+'.npz'),allow_pickle=False) as r:
                different=False
                for field in fields:
                    maxdiff[field]=max(maxdiff[field],float(np.abs(l[field].astype(np.float64)-r[field].astype(np.float64)).max()))
                    different|=not np.array_equal(l[field],r[field])
                unequal+=int(different)
                for field in ('true_conductivity_S_per_m','true_eps_r','true_lesion_mask','true_electrical_class','valid_mask','x','y'):
                    if not np.array_equal(l[field],r[field]):raise ValueError('Labels or grid changed: '+cid)
                if split=='test':
                    for layout,z in [('minimal',l),('full',r)]:
                        row=dict(records[layout]['per_case_metrics'][i])
                        if row['case_id']!=cid:raise ValueError('Metric record order mismatch')
                        row['case_gate_value']=float(z['case_gate'].mean())
                        fov=z['valid_mask'].astype(bool);truth=z['true_lesion_mask'][0]>.5;pred=z['electrical_class']!=0
                        pixel_mm=float(np.diff(z['x']).mean()*1000)
                        row.update(boundary_metrics(pred,truth,fov,pixel_mm))
                        row['lesion_area_relative_abs_error']=float(abs((pred&fov).sum()-(truth&fov).sum())/max((truth&fov).sum(),1))
                        row['centroid_error_mm']=float(np.linalg.norm(np.argwhere(pred&fov).mean(0)-np.argwhere(truth&fov).mean(0))*pixel_mm) if (pred&fov).any() else float(np.hypot(*fov.shape)*pixel_mm)
                        for name,pred_key,true_key in [('sigma','conductivity_S_per_m','true_conductivity_S_per_m'),('eps_r','eps_r','true_eps_r')]:
                            for fi,frequency in enumerate((10000,50000)):
                                pv,tv=z[pred_key][fi,truth&fov],z[true_key][fi,truth&fov]
                                row[f'{name}_lesion_nrmse_{frequency}Hz']=float(np.linalg.norm(pv-tv)/max(np.linalg.norm(tv),1e-20))
                        for fi,frequency in enumerate((10000,50000)):
                            omega_eps0=2*np.pi*frequency*8.8541878128e-12
                            pg=z['conductivity_S_per_m'][fi,fov]+1j*omega_eps0*z['eps_r'][fi,fov]
                            tg=z['true_conductivity_S_per_m'][fi,fov]+1j*omega_eps0*z['true_eps_r'][fi,fov]
                            row[f'admittivity_nrmse_{frequency}Hz']=float(np.linalg.norm(pg-tg)/max(np.linalg.norm(tg),1e-20))
                        enriched[layout].append(row)
            if (i+1)%500==0:print(f'Paired output check {split}: {i+1}/{len(ids)}',flush=True)
        report['layout_output_comparison'][split]={'case_count':len(ids),'cases_with_any_nonidentical_output':unequal,'max_abs_difference':maxdiff}
        if split=='test':
            test_ids=ids;test_records=enriched;report['test']={layout:summarize(rows) for layout,rows in enriched.items()}
    scores=np.array([r['foreground_iou'] for r in test_records['minimal']])
    report['test_iou_distribution']={'quantiles':dict(zip(('min','p05','median','p95','max'),np.quantile(scores,[0,.05,.5,.95,1]).tolist())),
                                     'count_below_0_70':int((scores<.7).sum()),'case_count':len(scores)}
    write(root/'comparison_summary.json',report);write(root/'test_per_case_metrics.json',test_records)
    figures(root,test_ids,manifest,test_records['minimal'])
    lines=['# 最终数据集：minimal / full 同权重重建结果','',
           f'训练 50 轮，随机种子 {manifest["seed"]}；仅由验证损失选择第 {manifest["selected_epoch"]} 轮检查点。两包均使用相同权重、归一化与病例批次顺序。','',
           '当前网络使用完整实虚部＋复数背景校准，不包含独立的学习式相位可信度分支。默认物理辅助关闭。本轮未另训幅值模型，所以不据此宣称相位带来多少提升。','',
           '## 独立测试集（720 例）','',
           '| 数据布局 | 分组 | 例数 | 病灶 IoU | Dice | mean IoU | SSIM 10kHz | SSIM 50kHz | σ NRMSE 10kHz | εr NRMSE 10kHz | HD95 mm |',
           '| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for layout in ('minimal','full'):
        for key in ('all','convex_A','concave_BCDE','E'):
            g=report['test'][layout][key]
            values=[g[k] for k in ('foreground_iou','foreground_dice','mean_iou_present_classes','sigma_ssim_10000Hz','sigma_ssim_50000Hz','sigma_nrmse_10000Hz','eps_r_nrmse_10000Hz','hd95_mm')]
            lines.append(f'| {layout} | {key} | {g["case_count"]} | '+' | '.join(f'{v:.4f}' for v in values)+' |')
    lines+=['','## A–E 分组及内凹指标（minimal；full 完整数值另见 JSON）','',
            '| 形状类 | IoU | Dice | HD95 mm | 内凹深度绝对误差 mm | 方向正确率 | 方向有效例数 |',
            '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
    for cls in 'ABCDE':
        g=report['test']['minimal'][cls]
        direction=f'{g["notch_direction_correct"]:.4f}' if 'notch_direction_correct' in g else '—'
        lines.append(f'| {cls} | {g["foreground_iou"]:.4f} | {g["foreground_dice"]:.4f} | {g["hd95_mm"]:.4f} | {g["concavity_depth_abs_error_mm"]:.4f} | {direction} | {g["notch_direction_valid_count"]} |')
    lines+=['','## 病灶区域材料误差（minimal）','',
            '| 分组 | σ NRMSE 10kHz | σ NRMSE 50kHz | εr NRMSE 10kHz | εr NRMSE 50kHz |',
            '| --- | ---: | ---: | ---: | ---: |']
    for cls in ('all','A','B','C','D','E'):
        g=report['test']['minimal'][cls]
        values=[g[f'{field}_lesion_nrmse_{freq}Hz'] for field in ('sigma','eps_r') for freq in (10000,50000)]
        lines.append('| '+cls+' | '+' | '.join(f'{v:.4f}' for v in values)+' |')
    unchanged=sum(abs(r['iou_change_from_base'])<1e-12 for r in test_records['minimal'])
    lines+=['','全域误差可能被面积较大的背景主导，因此另列病灶区域误差。JSON 还包括复导纳率误差、质心误差、面积误差与内凹指标。',
            '',f'门控分支诊断：{unchanged}/720 例的最终病灶 IoU 与同网络基础分支相同。平均病例门控值为 {report["test"]["minimal"]["all"]["case_gate_value"]:.6g}。这不是独立训练的消融实验，不能据此证明门控或拓扑损失的独立收益；辅助监督仍可能改变共享特征。',
            '',f'病例分布：病灶 IoU 中位数 {np.median(scores):.4f}，5% 分位数 {np.quantile(scores,.05):.4f}，最低 {scores.min():.4f}；{int((scores<.7).sum())}/720 例低于 0.70。最低五例图仅用于暴露失败模式，不用于重选模型或调整参数。',
            '','## 两包是否一致','','```json',json.dumps(report['layout_output_comparison'],indent=2),'```','',
            '输入和标签一致时，两种布局不应产生不同的学习信息。full 较大的内部场、图片及工程辅助文件并未作为网络输入。两次运行不是两份独立外部验证。','',
            '## 查看文件','','- test_shapes.png：固定每类前两个测试病例，真值 / minimal / full。',
            '- test_low_iou_cases.png：冻结评估后按 IoU 排序的最低五例，仅作失败诊断。',
            '- test_sigma.png、test_eps_r.png：两频材料图，固定每类第一个病例。',
            '- test_phase_inputs.png：实际复测量的相位和校准虚部示例；不是相位消融收益证据。',
            '- minimal/、full/：各有 train 3400、val 720、test 720 的逐病例 NPZ 与指标。',
            '- comparison_summary.json、test_per_case_metrics.json：完整分组与逐例统计。','',
            '## 指标口径与限制','','mean IoU 对真值或预测中出现的电学类别求平均；SSIM 是电导率图的有效域 7×7 窗口版本，不是 KTC-SSIM。NRMSE 是相对真值 L2 范数。HD95/ASD 用毫米。内凹方向/深度/凸包缺陷指标的定义与现有研究分析代码一致。',
            '这里只完成单种子首次正式运行，不代表多种子统计、跨设备泛化或临床验证已完成；也不保证每个内凹病例都成功。']
    (root/'RESULTS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps(report['test']['minimal']['all'],indent=2),flush=True)


if __name__=='__main__':main(sys.argv[1])
