"""Meaningful branch-gradient, matched-init, scheduler/resume checks before long runs."""
import argparse,copy,json,tempfile
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import default_collate
from .data_v6 import ComsolDataset,Normalizer,FINAL_DATASET_ROOT
from .model import V4Comsol
from .losses import compute_loss
from .train import move
from .paper_common import configure_runtime,tensor_hash,StopState,write_json

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    norm=Normalizer.load(Path('outputs/final4840_formal_calibrated_seed20261016/normalizer.npz'),FINAL_DATASET_ROOT)
    ds=ComsolDataset(FINAL_DATASET_ROOT,'train',norm,limit=5)
    b=move(default_collate([ds[i] for i in range(5)]),torch.device('cuda'))
    fov=torch.tensor(ds.fov,dtype=torch.float32,device='cuda')[None,None];checks={};hashes=[]
    for variant in ('full','no_topology','no_risk'):
        configure_runtime(123);model=V4Comsol(ds.fov,ablation=variant).cuda();hashes.append(tensor_hash(model.state_dict()))
        out=model(b['features'],b['frequencies_hz']);loss,parts=compute_loss(out,b,fov,ablation=variant)
        assert torch.isfinite(loss);loss.backward()
        def has_grad(module):return any(p.grad is not None and p.grad.abs().sum().item()>0 for p in module.parameters())
        if variant=='full':assert has_grad(model.cutout_head) and has_grad(model.action_gate_head)
        if variant=='no_topology':
            assert not has_grad(model.cutout_head) and not has_grad(model.action_gate_head)
            torch.testing.assert_close(out['foreground_probability'],out['base_foreground_probability'],atol=1e-7,rtol=1e-6)
        if variant=='no_risk':
            assert has_grad(model.cutout_head) and not has_grad(model.action_gate_head) and not has_grad(model.case_gate_head)
            torch.testing.assert_close(out['effective_cutout_probability'],out['proposal_cutout_probability'],rtol=0,atol=0)
            assert torch.all(out['case_gate']==1)
        assert has_grad(model.base_logits_head) and has_grad(model.material_head)
        expected=parts['final_ce']+parts['final_dice']+.65*parts['sigma']+.35*parts['eps_r']
        assert abs(expected-parts['selection_loss'])<1e-6
        checks[variant]={'finite_loss':float(loss.detach()),'branch_gradients':'PASS'}
        del model,out,loss;torch.cuda.empty_cache()
    assert len(set(hashes))==1;checks['matched_initialization']=hashes[0]
    # Serialize real scheduler/stopper states halfway through a plateau and compare continuation.
    x=torch.nn.Parameter(torch.zeros(1));opt=torch.optim.AdamW([x],lr=4e-4)
    sch=torch.optim.lr_scheduler.ReduceLROnPlateau(opt,patience=2,factor=.5,threshold=1e-4,threshold_mode='abs',min_lr=5e-6);stop=StopState()
    for score in [1.,.8,.8,.8]:sch.step(score);stop.step(score)
    opt2=torch.optim.AdamW([torch.nn.Parameter(torch.zeros(1))],lr=4e-4)
    sch2=torch.optim.lr_scheduler.ReduceLROnPlateau(opt2,patience=2,factor=.5,threshold=1e-4,threshold_mode='abs',min_lr=5e-6);stop2=StopState()
    opt2.load_state_dict(copy.deepcopy(opt.state_dict()));sch2.load_state_dict(copy.deepcopy(sch.state_dict()));stop2.load_state_dict(stop.state_dict())
    for score in [.8,.8,.79,.79,.79,.79]:
        sch.step(score);stop.step(score);sch2.step(score);stop2.step(score)
        assert sch.state_dict()==sch2.state_dict() and stop.state_dict()==stop2.state_dict()
        assert opt.param_groups[0]['lr']==opt2.param_groups[0]['lr']
    assert opt.param_groups[0]['lr']<4e-4;checks['scheduler_and_stopper_resume']='PASS'
    a.output.parent.mkdir(parents=True,exist_ok=True);write_json(a.output,{'status':'PASS','checks':checks})
    print(json.dumps(checks,indent=2),flush=True)

if __name__=='__main__':main()
