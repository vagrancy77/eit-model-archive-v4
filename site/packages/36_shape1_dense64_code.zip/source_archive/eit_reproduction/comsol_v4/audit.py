"""Read-only validation of all consumed V6 files; never modifies the dataset."""
import argparse
import json
from collections import Counter
from pathlib import Path
import numpy as np
import torch
from .data_v6 import (ComsolDataset, Normalizer, verify_manifest, signature,
                      row_case_path, measurement_features, assert_final_dataset)


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--dataset-root',type=Path,required=True)
    p.add_argument('--output-dir',type=Path,required=True)
    p.add_argument('--minimal-root',type=Path)
    a=p.parse_args(); a.output_dir.mkdir(parents=True,exist_ok=True)
    final_contract=assert_final_dataset(a.dataset_root)
    before=signature(a.dataset_root)
    integrity=verify_manifest(a.dataset_root)
    normalizer=Normalizer.fit_train(a.dataset_root)
    normalizer.save(a.output_dir/'normalizer.npz')
    counts={}; comparisons=0; extrema={}; shape_background=Counter()
    for split in ('train','val','test'):
        ds=ComsolDataset(a.dataset_root,split,normalizer)
        minimal=ComsolDataset(a.minimal_root,split,normalizer) if a.minimal_root else None
        minimal_index={r['case_id']:i for i,r in enumerate(minimal.rows)} if minimal else {}
        counts[split]=len(ds)
        for i,row in enumerate(ds.rows):
            item=ds[i]
            for key,value in item.items():
                if torch.is_tensor(value) and not torch.isfinite(value).all(): raise ValueError(f'{row["case_id"]}: nonfinite {key}')
            mask=item['mask'][0].bool(); sdf=item['sdf'][0]
            if not (sdf[mask]<0).all() or not (sdf[torch.from_numpy(ds.fov)&~mask]>=0).all(): raise ValueError('SDF convention mismatch')
            if (item['cutout']*item['mask']).any() or (item['mouth']>item['cutout']).any(): raise ValueError('Cutout/sidewall convention mismatch')
            for k in ('sigma','eps_r'):
                v=item[k][:,ds.fov]
                old=extrema.setdefault(k,[float('inf'),float('-inf')])
                old[0]=min(old[0],float(v.min())); old[1]=max(old[1],float(v.max()))
            if minimal:
                other=minimal[minimal_index[row['case_id']]]
                for k,v in item.items():
                    if torch.is_tensor(v) and not torch.allclose(v,other[k],rtol=1e-6,atol=1e-6): raise ValueError(f'Full/minimal mismatch {row["case_id"]} {k}')
                comparisons+=1
            shape_background[(split,row['shape_class'])]+=1
            if (i+1)%500==0: print(f'Validated native labels {split}: {i+1}/{len(ds)}',flush=True)
    # Measurement-only inference must work without lesion labels or internal fields.
    ds=ComsolDataset(a.dataset_root,'val',normalizer,limit=4,with_labels=False)
    for i in range(len(ds)):
        item=ds[i]
        if set(item)!={'features','frequencies_hz','case_id','shape_class'}: raise ValueError('Truth leaked into inference input')
    with np.load(row_case_path(a.dataset_root,ds.rows[0]),allow_pickle=False) as z:
        if 'eit_voltage' in z.files: v,b,d=z['eit_voltage'],z['eit_background_voltage'],z['eit_delta_voltage']
        else: v,b=z['voltage'],z['background_voltage']; d=v-b
        f=z['frequencies_hz']; base=measurement_features(v,b,d,f)
        shifted=measurement_features(v+(2+3j),b+(-1+2j),d+(3+1j),f)
        if not np.allclose(base,shifted,rtol=1e-9,atol=1e-12): raise ValueError('Gauge invariance failed')
    if signature(a.dataset_root)!=before: raise ValueError('Dataset signature changed')
    report={'status':'PASS','counts':counts,'total_cases':sum(counts.values()),
            'final_dataset_contract':final_contract,
            'full_minimal_case_comparisons':comparisons,'integrity':integrity,
            'ranges_in_valid_domain':extrema,'shape_split_counts':{str(k):v for k,v in shape_background.items()},
            'label_free_inputs':sorted(ds[0]),'gauge_invariance':'PASS',
            'data_unchanged':'Read-only audit; split/grid/manifest signatures unchanged',
            'normalizer_fit_split':'train only','normalizer_case_count':normalizer.metadata['case_count'],
            'physics':'Optional archived same-generator linearized Jacobian; use only a converted operator bound to this final cohort.'}
    (a.output_dir/'audit.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps(report,indent=2,ensure_ascii=False),flush=True)


if __name__=='__main__': main()
