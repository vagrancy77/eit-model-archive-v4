"""Frozen protocol, matched initialization and atomic persistence for the paper study."""
import hashlib,json,os
from pathlib import Path
import numpy as np
import torch
from .data_v6 import FINAL_DATASET_ROOT,signature,file_hash

VARIANTS={
    'calibrated':{'input_mode':'calibrated','ablation':'full'},
    'amplitude':{'input_mode':'amplitude','ablation':'full'},
    'complex':{'input_mode':'complex','ablation':'full'},
    'amplitude_calibrated':{'input_mode':'amplitude_calibrated','ablation':'full'},
    'no_topology':{'input_mode':'calibrated','ablation':'no_topology'},
    'no_risk':{'input_mode':'calibrated','ablation':'no_risk'}}
SOURCES=('paper_common.py','paper_train.py','model.py','losses.py','features.py','data_v6.py','metrics.py','../pytorch_eit/topology_residual_net.py')

def write_json(path,value):
    path=Path(path);tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8');tmp.replace(path)

def save_checkpoint(path,value):
    path=Path(path);tmp=path.with_suffix('.tmp');torch.save(value,tmp);tmp.replace(path)

def tensor_hash(state):
    h=hashlib.sha256()
    for k,t in sorted(state.items()):h.update(k.encode());h.update(t.detach().cpu().numpy().tobytes())
    return h.hexdigest()

def protocol():
    here=Path(__file__).resolve().parent
    return {'version':'final4840-paper-v1','dataset_signature':signature(FINAL_DATASET_ROOT),
        'variants':VARIANTS,'seeds':[20261016,20261017,20261018],
        'max_epochs':250,'minimum_epochs':100,'batch_size':64,'base':28,'propagation_steps':14,
        'learning_rate':4e-4,'weight_decay':1e-4,'precision':'float32','physics_input':False,
        'plateau_patience':8,'plateau_factor':.5,'min_lr':5e-6,'minimum_improvement':1e-4,
        'early_stop_patience':30,'topology_warmup_epochs':10,
        'selection':'validation final_ce + final_dice + 0.65*sigma + 0.35*eps_r',
        'selection_note':'same reconstruction objective across ablations; auxiliary losses excluded from selection',
        'test_policy':'all training finishes before suite test evaluation; prior 50-epoch exploratory test already observed',
        'normalization':'each representation fitted on all 3400 training cases only',
        'shuffle':'CPU generator seeded by seed+1000003*epoch; matched order across variants',
        'statistics':'3 paired seeds and position-cluster bootstrap; no case-wise independence assumption',
        'source_hashes':{name:file_hash(here/name) for name in SOURCES}}

def load_protocol(root):
    p=Path(root)/'protocol.json';s=json.loads(p.read_text(encoding='utf-8'))
    if s!=protocol():raise ValueError('Frozen training protocol or implementation changed; use a new study directory')
    return s,file_hash(p)

class StopState:
    def __init__(self,min_delta=1e-4):self.minimum_improvement=min_delta;self.reference=float('inf');self.bad_epochs=0
    def step(self,score):
        if score < self.reference-self.minimum_improvement:self.reference=score;self.bad_epochs=0
        else:self.bad_epochs+=1
    def state_dict(self):return vars(self).copy()
    def load_state_dict(self,state):self.__dict__.update(state)

def configure_runtime(seed):
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
    import random
    random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);torch.cuda.manual_seed_all(seed)
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    # Some existing median/quantile gradients lack deterministic CUDA kernels.
    # Record seeded reproducibility without promising cross-device bitwise identity.
