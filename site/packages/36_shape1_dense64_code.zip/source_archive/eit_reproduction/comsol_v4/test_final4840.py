"""Final-release integration regression checks. No performance claims or test fitting."""
import argparse
import ast
import json
import sys
from pathlib import Path

import numpy as np
import torch

from .data_v6 import (FINAL_DATASET_ROOT, assert_final_dataset, load_rows, row_case_path,
                      read_measurements, Normalizer, ComsolDataset, file_hash, grid_arrays)
from .features import calibrated_features, measurement_mask
from .metrics import aggregate
from .physics import ReferencePhysics, EPS0
from integrations.v4_20261015 import bridge


def rejected(fn):
    try: fn()
    except ValueError: return True
    raise AssertionError('Invalid configuration was accepted')


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output-dir',type=Path,required=True)
    p.add_argument('--normalizer',type=Path,required=True)
    p.add_argument('--physics-operator',type=Path,required=True)
    a=p.parse_args(); a.output_dir.mkdir(parents=True,exist_ok=True)
    torch.set_num_threads(2)
    root=FINAL_DATASET_ROOT
    contract=assert_final_dataset(root)
    archive=bridge.verify_bundle()
    study=bridge.controlled_module()
    from analyze_experiment import groups, paired_bootstrap, seed_sd
    rows=load_rows(root,'train')
    checks={}
    for cls in 'ABCDE':
        row=next(r for r in rows if r['shape_class']==cls)
        v,b,_,_=read_measurements(row_case_path(root,row))
        historical=study.variant_features(v,b)
        for mode in historical:
            features=calibrated_features(v,b,mode)
            np.testing.assert_array_equal(features,historical[mode])
            assert np.isfinite(features).all()
            assert not features[:,~measurement_mask()].any()
            shifted=calibrated_features(v+(2+3j),b+(-1+2j),mode)
            np.testing.assert_allclose(features,shifted,rtol=1e-5,atol=2e-6)
        # Differential phase must affect the complex branch, never the amplitude control.
        rotated=v*np.exp(.12j)
        np.testing.assert_allclose(calibrated_features(v,b,'amplitude'),
                                   calibrated_features(rotated,b,'amplitude'),rtol=1e-6,atol=1e-8)
        assert np.linalg.norm(calibrated_features(v,b)-calibrated_features(rotated,b))>1e-3
    checks['representations']='20 exact comparisons; A-E gauge/phase/no-magnitude-leak checks PASS'
    norm=Normalizer.load(a.normalizer,root); norm.validate_training_contract(root,'calibrated')
    rejected(lambda:norm.validate_training_contract(root,'complex'))
    wrong=Normalizer(norm.mean,norm.std,{**norm.metadata,'fit_split':'val'})
    rejected(lambda:wrong.validate_training_contract(root,'calibrated'))
    old=bridge.PROJECT.parent/'eit_dataset_full_v6_20261010/extracted/full3872'
    if old.exists(): rejected(lambda:assert_final_dataset(old))
    checks['normalizer']='3400 training IDs only; wrong representation/validation fit rejected'
    ds=ComsolDataset(root,'val',norm,limit=10)
    assert [r['shape_class'] for r in ds.rows]==list('ABCDE')*2
    for i in range(len(ds)):
        item=ds[i]
        assert item['features'].shape==(12,32,32)
        assert item['sigma'].shape==item['eps_r'].shape==(2,64,64)
    records=[{'case_id':c,'shape_class':c,'foreground_iou':i/5,'position_id':'P01'} for i,c in enumerate('ABCDE')]
    metrics=aggregate(records)
    assert metrics['all']['case_count']==5 and metrics['concave_all']['case_count']==4
    assert metrics['concave_BCD']['case_count']==3 and metrics['E']['case_count']==1
    assert len(groups(records,'concave_all'))==4 and len(groups(records,'concave_BCD'))==3
    assert seed_sd([.2])==0.
    base=[{'seed':1,'per_case':records}]
    assert paired_bootstrap(base,base,'E','foreground_iou',np.random.default_rng(4))['mean_difference']==0
    checks['class_E']='balanced loaders, aggregate, boundary-statistic grouping, one-seed bootstrap PASS'
    x,y,fov=grid_arrays(root)
    physics=ReferencePhysics(a.physics_operator,fov,x,y)
    assert physics.metadata['dataset_signature']==contract['signature']
    with np.load(bridge.RECON/'operators/operators.npz',allow_pickle=False) as z:
        block=z['A'][0]; scales=z['voltage_scale'][0]
        rng=np.random.default_rng(444)
        dsigma=(rng.normal(size=(2,64,64))*.001*fov).astype(np.float32)
        deps=(rng.normal(size=(2,64,64))*10*fov).astype(np.float32)
        material=np.concatenate((dsigma[:,fov]/float(z['sigma_scale']),deps[:,fov]/float(z['epsilon_scale'])),axis=1)
        vectors=np.einsum('fmp,fp->fm',block,material)
        expected=((vectors[:,:1024]+1j*vectors[:,1024:])*scales[:,None]).reshape(2,32,32)
        expected-=expected.mean(-1,keepdims=True)
    s=(physics.background_sigma[0,:,None,None]+torch.from_numpy(dsigma))[None].requires_grad_()
    e=(physics.background_eps[0,:,None,None]+torch.from_numpy(deps))[None].requires_grad_()
    group=torch.tensor([0])
    actual=physics.predict_delta(s,e,group)
    relative=float(np.linalg.norm(actual.detach().numpy()[0]-expected)/np.linalg.norm(expected))
    assert relative<1e-4,relative  # includes FP32 cancellation when adding material backgrounds
    loss=physics.loss(s,e,group,actual.detach()*.9);loss.backward()
    assert all(t.grad is not None and torch.isfinite(t.grad).all() and t.grad.abs().sum()>0 for t in (s,e))
    checks['linearized_operator']={'archived_block_relative_error':relative,'both_material_gradients_finite_nonzero':True,
                                   'scope':'arithmetic equivalence, NOT a new FEM solve'}
    reference=physics.metadata['checks'][-1]['training_reference_comparison']
    checks['reference_discrepancy']=reference
    # Parse changed Python without creating cache files. Record exact active-source hashes.
    sources=list((bridge.PROJECT/'comsol_v4').glob('*.py'))
    sources += [bridge.PROJECT/'v4_unified.py',bridge.ROOT/'bridge.py',bridge.ROOT/'convert_physics.py']
    sources += [bridge.STUDY/n for n in ('run_experiment.py','evaluate_experiment.py','analyze_experiment.py','plot_experiment.py','complex_features_prototype.py')]
    for source in sources: ast.parse(source.read_text(encoding='utf-8-sig'),filename=str(source))
    source_manifest={str(p):file_hash(p) for p in sources}
    (a.output_dir/'active_source_manifest.json').write_text(json.dumps(source_manifest,indent=2),encoding='utf-8')
    report={'status':'PASS','contract':contract,'archive':archive,'checks':checks,
            'source_files_parsed':len(sources),'test_split_performance_evaluated':False,
            'dataset_modified':False,'long_training_performed':False}
    (a.output_dir/'regression.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({'status':'PASS','checks':list(checks),'source_files':len(sources),'report':str(a.output_dir/'regression.json')},indent=2))


if __name__=='__main__': main()
