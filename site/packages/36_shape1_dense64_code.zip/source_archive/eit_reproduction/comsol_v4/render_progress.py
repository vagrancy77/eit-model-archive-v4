"""Render validation snapshots using NumPy/matplotlib, without PyTorch."""
import sys,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def render(path):
    path=Path(path)
    with np.load(path,allow_pickle=False) as z: data={k:z[k].copy() for k in z.files}
    history=json.loads(data['history_json'].item());fov=data['fov'];ids=data['case_ids']
    fig,axes=plt.subplots(len(ids),6,figsize=(18,3*len(ids)),squeeze=False,constrained_layout=True)
    for i,cid in enumerate(ids):
        truth=data['truth_mask'][i,0].astype(bool);pred=data['probabilities'][i].argmax(0)!=0
        sigma=data['truth_sigma'][i,0];eps=data['truth_eps_r'][i,0]
        values=[truth,pred,sigma,data['sigma'][i,0],eps,data['eps_r'][i,0]]
        titles=['True mask','Pred mask','True sigma 10kHz','Pred sigma 10kHz','True eps_r 10kHz','Pred eps_r 10kHz']
        iou=float((pred&truth&fov).sum()/max(((pred|truth)&fov).sum(),1))
        for j,(v,title) in enumerate(zip(values,titles)):
            lo,hi=(0,1) if j<2 else ((sigma[fov].min(),sigma[fov].max()) if j<4 else (eps[fov].min(),eps[fov].max()))
            ax=axes[i,j];ax.imshow(np.where(fov,v,np.nan),origin='lower',vmin=lo,vmax=hi,cmap='Greys' if j<2 else 'viridis')
            if j==1: ax.contour(truth,[.5],colors='red',linewidths=.7)
            ax.set_title(title+(f' / IoU {iou:.3f}' if j==1 else ''),fontsize=9);ax.set_xticks([]);ax.set_yticks([])
        axes[i,0].set_ylabel(cid)
    fig.suptitle(f'VALIDATION | epoch {history[-1]["epoch"]} | fixed first ID per class | NOT TEST RESULTS\nMaterial colors use truth range; out-of-range values clipped')
    fig.savefig(path.with_suffix('.png'),dpi=125);plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(16,4.5),constrained_layout=True)
    x=[h['epoch'] for h in history]
    field='selection_loss' if all('selection_loss' in h['val'] for h in history) else 'total_loss'
    axes[0].plot(x,[h['train'][field] for h in history],label='train')
    axes[0].plot(x,[h['val'][field] for h in history],label='val')
    axes[0].set_title('Selection objective: '+field)
    for group in ('all','convex_A','concave_all','E'):
        axes[1].plot(x,[h['val_metrics'][group]['foreground_iou'] for h in history],label=group)
    axes[1].set(title='Validation foreground IoU',ylim=(0,1))
    for field in ('sigma','eps_r'):
        axes[2].plot(x,[h['val_metrics']['all'][field+'_nrmse_10000Hz'] for h in history],label=field+' 10kHz')
    axes[2].set_title('Validation material NRMSE')
    for ax in axes: ax.set_xlabel('epoch');ax.grid(alpha=.2);ax.legend(fontsize=8)
    fig.savefig(path.parent/'training_progress.png',dpi=140);plt.close(fig)

if __name__=='__main__':render(sys.argv[1])
