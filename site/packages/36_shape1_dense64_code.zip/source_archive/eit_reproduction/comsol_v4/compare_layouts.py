"""Exhaustive training-field equivalence audit; no model selection or data edits."""
import argparse,json
from pathlib import Path
import numpy as np
import torch
from .data_v6 import (FINAL_DATASET_ROOT,assert_final_dataset,signature,verify_manifest,ComsolDataset,
                      Normalizer,row_case_path,read_measurements,file_hash)


def validate_equivalence_report(path,root,checkpoint_signature):
    report=json.loads(Path(path).read_text(encoding='utf-8'))
    if (report.get('status')!='PASS' or report.get('case_counts')!={'train':3400,'val':720,'test':720} or
            report.get('reference_signature')!=checkpoint_signature or report.get('candidate_signature')!=signature(root) or
            report.get('input_mode')!='calibrated' or report.get('all_labels_equal') is not True or
            report.get('all_calibrated_inputs_equal') is not True):
        raise ValueError('The equivalence report does not certify this checkpoint/dataset pair')
    return {'report_sha256':file_hash(path),'reference_signature':report['reference_signature'],
            'candidate_signature':report['candidate_signature'],'case_counts':report['case_counts']}


def main():
    p=argparse.ArgumentParser();p.add_argument('--full-root',type=Path,required=True)
    p.add_argument('--normalizer',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();torch.set_num_threads(2)
    for root in (FINAL_DATASET_ROOT,a.full_root): assert_final_dataset(root)
    integrity={str(root):verify_manifest(root) for root in (FINAL_DATASET_ROOT,a.full_root)}
    norm=Normalizer.load(a.normalizer,FINAL_DATASET_ROOT);norm.validate_training_contract(FINAL_DATASET_ROOT,'calibrated')
    counts={};max_voltage=0.;max_feature=0.;different_inputs=0;different_labels=0
    for split in ('train','val','test'):
        minimal=ComsolDataset(FINAL_DATASET_ROOT,split,norm)
        full=ComsolDataset(a.full_root,split,norm)
        lookup={r['case_id']:i for i,r in enumerate(full.rows)}
        for i,row in enumerate(minimal.rows):
            j=lookup[row['case_id']];left=minimal[i];right=full[j]
            for field in ('case_id','shape_class','position_id','material_combination_id'):
                if row[field]!=full.rows[j][field]: raise ValueError('Case metadata differs: '+row['case_id'])
            lv,lb,_,_=read_measurements(row_case_path(FINAL_DATASET_ROOT,row))
            rv,rb,_,_=read_measurements(row_case_path(a.full_root,full.rows[j]))
            err=max(float(np.abs(lv-rv).max()),float(np.abs(lb-rb).max()));max_voltage=max(max_voltage,err)
            if not np.array_equal(lv,rv) or not np.array_equal(lb,rb): raise ValueError('Canonical voltage differs: '+row['case_id'])
            for key,value in left.items():
                if torch.is_tensor(value):
                    if key=='features':
                        max_feature=max(max_feature,float((value-right[key]).abs().max()))
                        different_inputs+=int(not torch.equal(value,right[key]))
                    else: different_labels+=int(not torch.equal(value,right[key]))
            if (i+1)%250==0: print(f'Equivalent fields {split}: {i+1}/{len(minimal)}',flush=True)
        counts[split]=len(minimal)
    if different_inputs or different_labels: raise ValueError(f'Layout mismatch: inputs={different_inputs}, labels={different_labels}')
    report={'status':'PASS','reference_root':str(FINAL_DATASET_ROOT),'candidate_root':str(a.full_root),
            'reference_signature':signature(FINAL_DATASET_ROOT),'candidate_signature':signature(a.full_root),
            'case_counts':counts,'input_mode':'calibrated','all_labels_equal':True,'all_calibrated_inputs_equal':True,
            'maximum_canonical_voltage_difference':max_voltage,'maximum_normalized_feature_difference':max_feature,
            'normalizer_sha256':file_hash(a.normalizer),'integrity':integrity,
            'notes':['All 4840 input/label pairs compared; no test-based parameter selection.',
                     'Internal fields and images are not model inputs; full-file extras are not part of this equivalence claim.']}
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k not in ('integrity','notes')},indent=2),flush=True)


if __name__=='__main__':main()
