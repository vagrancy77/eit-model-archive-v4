"""Native reader for both the V6 minimal package and the full COMSOL package."""
from __future__ import annotations
import hashlib, json
from functools import lru_cache
from itertools import zip_longest
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import Dataset

FREQUENCIES = np.array([10000., 50000.], dtype=np.float64)
FINAL_DATASET_ROOT = Path(__file__).resolve().parents[2] / 'eit_dataset_final_v6_4840/extracted/V6_4840_Minimal'
FINAL_SIGNATURE = {'layout': 'minimal',
    'splits_sha256': '078ea4e7317a4d0b54105afc1a4309867ccd462d22f91a50e48b459db60929a7',
    'grid_sha256': '293177763bb99ddf4b3a2cbc628b8bd3414d106d2d85698eac5ef95dfc440fd3',
    'manifest_sha256': 'd1c5f8b024187ff4bd2eeebb861c67c530c38ed855c44728db67832a1df4c871'}
CHANNELS = [f"{kind}_{int(f)}Hz" for kind in ("V_real", "V_imag", "B_real", "B_imag", "dV_real", "dV_imag") for f in FREQUENCIES]

def file_hash(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''): h.update(block)
    return h.hexdigest()

@lru_cache(maxsize=16)
def resolve_root(root):
    root = Path(root).resolve()
    if (root/'cases').is_dir() and (root/'splits.json').is_file(): return root, root, 'minimal'
    if (root/'raw').is_dir() and (root/'raw'/'splits.json').is_file(): return root, root/'raw', 'full'
    if (root/'splits.json').is_file() and any(root.glob('case_*/sample_pair.npz')): return root.parent, root, 'full_raw'
    raise FileNotFoundError(f'Cannot identify V6 dataset root: {root}')

def row_case_path(root, row):
    package, data, layout = resolve_root(root)
    path = data/row['file'] if layout == 'minimal' else data/row['case_dir']/'sample_pair.npz'
    path = path.resolve()
    if not path.is_relative_to(data.resolve()): raise ValueError('Case path escapes dataset root')
    return path

def grid_arrays(root):
    package, data, layout = resolve_root(root)
    if layout == 'minimal' and (data/'grid.npz').is_file():
        with np.load(data/'grid.npz', allow_pickle=False) as z: return z['x'].copy(), z['y'].copy(), z['valid_mask'].copy()
    rows = json.loads((data/'splits.json').read_text(encoding='utf-8'))['splits']
    with np.load(row_case_path(root, rows[0]), allow_pickle=False) as z: return z['x'].copy(), z['y'].copy(), z['valid_mask'].copy()

def signature(root):
    package, data, layout = resolve_root(root); x,y,valid = grid_arrays(root)
    result = {'layout':layout, 'splits_sha256':file_hash(data/'splits.json'), 'grid_sha256':hashlib.sha256(x.tobytes()+y.tobytes()+valid.tobytes()).hexdigest()}
    if (package/'MANIFEST.sha256.json').is_file(): result['manifest_sha256'] = file_hash(package/'MANIFEST.sha256.json')
    return result

def verify_manifest(root, all_files=False):
    package, data, layout = resolve_root(root)
    manifest_path = package/'MANIFEST.sha256.json'
    entries = json.loads(manifest_path.read_text(encoding='utf-8'))['files']
    selected = entries if all_files or layout == 'minimal' else {k:v for k,v in entries.items() if
        k.replace('\\','/').endswith(('/sample_pair.npz','/case_parameters.json','/electrical_properties.npz','/metadata.json','/splits.json'))}
    # Verify actual training inputs and labels; do not report the omitted MPH/logs as verified.
    for i,(rel,record) in enumerate(selected.items(),1):
        p=(package/rel).resolve()
        if not p.is_relative_to(package) or not p.is_file() or p.stat().st_size!=record['bytes'] or file_hash(p)!=record['sha256']:
            raise ValueError(f'Manifest mismatch: {rel}')
        if i%4000==0: print(f'Verified hashes {i}/{len(selected)}',flush=True)
    supplement=package/'SUPPLEMENT_MANIFEST.sha256.json'
    supplement_count=0
    if supplement.exists():
        s=json.loads(supplement.read_text(encoding='utf-8'))
        if s['base_manifest_sha256']!=file_hash(manifest_path): raise ValueError('Supplement base manifest mismatch')
        for rel,record in s['files'].items():
            p=(package/rel).resolve()
            if not p.is_relative_to(package) or not p.is_file() or p.stat().st_size!=record['bytes'] or file_hash(p)!=record['sha256']: raise ValueError(f'Supplement mismatch: {rel}')
            supplement_count+=1
    return {'layout':layout,'signature':signature(root),'verified_files':len(selected),'supplement_verified_files':supplement_count,
            'manifest_mode':'all' if all_files or layout=='minimal' else 'training inputs, labels, metadata, splits; MPH/logs excluded',
            'effective_boundary_model':'current_terminal_no_effective_contact_impedance','internal_fields_policy':'QA only'}

@lru_cache(maxsize=16)
def load_rows(root, split):
    if split not in ('train','val','test'): raise ValueError('split must be train, val or test')
    package,data,layout = resolve_root(root); rows = json.loads((data/'splits.json').read_text(encoding='utf-8'))['splits']; ids=set(); positions={}
    for row in rows:
        if row['case_id'] in ids or row['split'] not in ('train','val','test'): raise ValueError('Invalid split rows')
        if row['shape_class'] not in tuple('ABCDE') or not row['case_id'].startswith(row['shape_class']+'_'):
            raise ValueError('Unsupported or inconsistent shape class')
        ids.add(row['case_id'])
        if positions.setdefault(row['position_id'],row['split']) != row['split']: raise ValueError('Position leakage')
        if not row_case_path(root,row).is_file(): raise FileNotFoundError(row['case_id'])
    selected=[r for r in rows if r['split']==split]
    if not selected: raise ValueError(f'Empty {split}')
    return selected

def assert_final_dataset(root):
    """Accept relocated minimal/full copies of the fixed A-E cohort, not old splits."""
    if not FINAL_DATASET_ROOT.is_dir(): raise FileNotFoundError(f'Final dataset is not installed: {FINAL_DATASET_ROOT}')
    if signature(FINAL_DATASET_ROOT) != FINAL_SIGNATURE:
        raise ValueError('Installed final reference manifest/splits/grid changed')
    if resolve_root(root)[2] == 'minimal' and signature(root) != FINAL_SIGNATURE:
        raise ValueError('This is not the pinned final minimal release')
    expected, actual = [], []
    for split in ('train', 'val', 'test'):
        expected.extend((r['case_id'], r['position_id'], r['shape_class'], split)
                        for r in load_rows(FINAL_DATASET_ROOT, split))
        actual.extend((r['case_id'], r['position_id'], r['shape_class'], split)
                      for r in load_rows(root, split))
    if len(actual) != 4840 or sorted(actual) != sorted(expected):
        raise ValueError('Training requires the final 4840-case A-E cohort and its position-group splits')
    if not all(np.array_equal(a, b) for a, b in zip(grid_arrays(FINAL_DATASET_ROOT), grid_arrays(root))):
        raise ValueError('Final dataset grid/FOV changed')
    for case_id in ('A_000001', 'A_000055', 'E_000001'):
        def measured(dataset):
            row = next(r for r in load_rows(dataset, 'train') if r['case_id'] == case_id)
            with np.load(row_case_path(dataset, row), allow_pickle=False) as z:
                prefix = 'eit_' if 'eit_voltage' in z.files else ''
                v, b = z[prefix+'voltage'].copy(), z[prefix+'background_voltage'].copy()
                negative = (np.arange(32)+1) % 32
                v -= v[:, np.arange(32), negative][:, :, None]
                b -= b[:, np.arange(32), negative][:, :, None]
                return v, b, z['lesion_mask'].copy(), z['frequencies_hz'].copy()
        if not all(np.array_equal(a, b) for a, b in zip(measured(FINAL_DATASET_ROOT), measured(root))):
            raise ValueError(f'Final dataset reference sample changed: {case_id}')
    return {'case_count': 4840, 'splits': {'train': 3400, 'val': 720, 'test': 720},
            'classes': list('ABCDE'), 'signature': signature(root)}

def measurement_features(voltage, background, delta, frequencies):
    voltage,background,delta=map(np.asarray,(voltage,background,delta))
    if voltage.shape != (2,32,32) or background.shape != voltage.shape or delta.shape != voltage.shape: raise ValueError('Expected [2,32,32] complex arrays')
    if not all(np.iscomplexobj(a) and np.isfinite(a).all() for a in (voltage,background,delta)): raise ValueError('Invalid complex measurements')
    if not np.array_equal(np.asarray(frequencies),FREQUENCIES): raise ValueError('Frequency order must be 10/50 kHz')
    if not np.allclose(delta,voltage-background,rtol=1e-9,atol=1e-12): raise ValueError('Stored delta inconsistent with V-background')
    v=voltage-voltage.mean(axis=-1,keepdims=True); b=background-background.mean(axis=-1,keepdims=True)
    d=delta-delta.mean(axis=-1,keepdims=True)
    return np.concatenate([v.real,v.imag,b.real,b.imag,d.real,d.imag],axis=0)

def read_measurements(path):
    with np.load(path,allow_pickle=False) as z:
        if 'eit_voltage' in z.files: v,b,d=z['eit_voltage'],z['eit_background_voltage'],z['eit_delta_voltage']
        else: v,b=z['voltage'],z['background_voltage']; d=v-b
        frequencies=z['frequencies_hz'].copy()
        measurement_features(v,b,d,frequencies)  # shared shape/finiteness/delta contract
        # Minimal stores the injection-return gauge; full may store another gauge.
        # Canonicalize both before differencing to avoid layout-dependent roundoff.
        negative=(np.arange(32)+1)%32
        v=v-v[:,np.arange(32),negative][:,:,None]
        b=b-b[:,np.arange(32),negative][:,:,None]
        return v, b, v-b, frequencies

def read_features(path, mode='native'):
    v,b,d,f=read_measurements(path)
    if mode == 'native': return measurement_features(v,b,d,f)
    from .features import calibrated_features
    return calibrated_features(v,b,mode)

def full_sidecar(path):
    case=Path(path).parent
    params=json.loads((case/'case_parameters.json').read_text(encoding='utf-8'))
    if params['case_id']!=case.name.removeprefix('case_'): raise ValueError('Case parameter ID mismatch')
    if params['background_material'] not in ('Fat','Muscle'): raise ValueError('Unexpected background material')
    sidecar=case.parent.parent/'detection_dataset'/params['background_material']/'cases'/params['case_id']/'electrical_properties.npz'
    return sidecar,params

class Normalizer:
    def __init__(self,mean,std,metadata):
        self.mean,self.std,self.metadata=np.asarray(mean,dtype=np.float64),np.asarray(std,dtype=np.float64),metadata
        if self.mean.shape!=(12,32,32) or self.std.shape!=self.mean.shape or not np.isfinite(self.mean).all() or not np.isfinite(self.std).all() or np.any(self.std<=0): raise ValueError('Invalid normalizer')
    @classmethod
    def fit_train(cls,root,mode='native'):
        rows=load_rows(root,'train'); mean=np.zeros((12,32,32)); m2=np.zeros_like(mean)
        for n,row in enumerate(rows,1):
            x=read_features(row_case_path(root,row),mode); d=x-mean; mean+=d/n; m2+=d*(x-mean)
            if n%500==0: print(f'Normalizer train-only: {n}/{len(rows)}',flush=True)
        std=np.sqrt(np.maximum(m2/len(rows),0)); std[std<1e-12]=1.
        return cls(mean,std,{'fit_split':'train','case_count':len(rows),'case_ids':[r['case_id'] for r in rows],'dataset_signature':signature(root),'channels':CHANNELS,'axis_order':'channel,drive,electrode','input_mode':mode,'delta_source':'stored eit_delta_voltage (full); V-background (minimal)'})
    def __call__(self,x): return ((x-self.mean)/self.std).astype(np.float32)
    def validate_training_contract(self,root,mode):
        expected_ids=[r['case_id'] for r in load_rows(root,'train')]
        if (self.metadata.get('dataset_signature') != signature(root) or
                self.metadata.get('fit_split') != 'train' or
                self.metadata.get('case_count') != len(expected_ids) or
                self.metadata.get('case_ids') != expected_ids or
                self.metadata.get('input_mode','native') != mode):
            raise ValueError('Normalizer must match this release, representation and complete training partition')
    def save(self,path): np.savez_compressed(path,mean=self.mean,std=self.std,metadata_json=json.dumps(self.metadata))
    def state(self): return {'mean':torch.from_numpy(self.mean.copy()),'std':torch.from_numpy(self.std.copy()),'metadata_json':json.dumps(self.metadata)}
    @classmethod
    def from_state(cls,state): return cls(state['mean'].cpu().numpy(),state['std'].cpu().numpy(),json.loads(state['metadata_json']))
    @classmethod
    def load(cls,path,root=None):
        with np.load(path,allow_pickle=False) as z: obj=cls(z['mean'],z['std'],json.loads(z['metadata_json'].item()))
        if root is not None and obj.metadata['dataset_signature']!=signature(root): raise ValueError('Normalizer belongs to another dataset')
        return obj

class ComsolDataset(Dataset):
    def __init__(self,root,split,normalizer,limit=0,with_labels=True,physics=False):
        self.root,self.normalizer,self.with_labels=Path(root).resolve(),normalizer,with_labels; self.rows=list(load_rows(root,split))
        self.physics=physics
        if limit < 0: raise ValueError('limit must be nonnegative')
        if limit:
            classes=sorted({r['shape_class'] for r in self.rows})
            groups=[[r for r in self.rows if r['shape_class']==c] for c in classes]
            if sum(map(len,groups))!=len(self.rows): raise ValueError('Unsupported shape class')
            self.rows=[r for group in zip_longest(*groups) for r in group if r is not None][:limit]
        self.x,self.y,self.fov=grid_arrays(root)
        self.fov=self.fov.astype(bool)
        if self.fov.shape!=(64,64) or self.x.shape!=(64,) or self.y.shape!=(64,) or not np.all(np.diff(self.x)>0) or not np.all(np.diff(self.y)>0): raise ValueError('Expected 64x64 ascending x/y grid')
    def __len__(self): return len(self.rows)
    def __getitem__(self,index):
        row=self.rows[index]; path=row_case_path(self.root,row)
        mode=getattr(self.normalizer,'metadata',{}).get('input_mode','native')
        item={'features':torch.from_numpy(self.normalizer(read_features(path,mode))),'frequencies_hz':torch.tensor(FREQUENCIES,dtype=torch.float32),'case_id':row['case_id'],'shape_class':row['shape_class']}
        if self.physics:
            with np.load(path,allow_pickle=False) as z:
                if 'eit_delta_voltage' in z.files:
                    delta=z['eit_delta_voltage']; _,params=full_sidecar(path)
                else:
                    delta=z['voltage']-z['background_voltage']; params=json.loads(z['parameters_json'].item())
                # Background is an explicit experimental reference assumption, never lesion truth.
                item['background_group']=torch.tensor(['Fat','Muscle'].index(params['background_material']),dtype=torch.int64)
                item['delta_voltage']=torch.from_numpy(delta.astype(np.complex64))
        if not self.with_labels:return item
        with np.load(path,allow_pickle=False) as z:
            if 'case_id' in z.files and str(z['case_id'].item())!=row['case_id']: raise ValueError('Case ID mismatch')
            if 'valid_mask' in z.files and not np.array_equal(z['valid_mask'],self.fov): raise ValueError('Per-case FOV changed')
            for axis,expected in [('x',self.x),('y',self.y)]:
                if axis in z.files and not np.array_equal(z[axis],expected): raise ValueError('Per-case grid changed')
            for source,dest in [('lesion_mask','mask'),('sdf','sdf'),('cutout_mask','cutout'),('mouth_mask','mouth')]:
                a=np.asarray(z[source],dtype=np.float32)
                if a.shape!=(64,64) or not np.isfinite(a).all(): raise ValueError(f'Invalid {source}')
                item[dest]=torch.from_numpy(a[None].copy())
            item['labels']=torch.from_numpy(z['electrical_class'].astype(np.int64))
            if item['labels'].shape!=(64,64) or not torch.isin(item['labels'],torch.tensor([0,1,2])).all(): raise ValueError('Invalid electrical classes')
            if not np.array_equal(item['labels'].numpy()>0,item['mask'][0].numpy()>0): raise ValueError('Class/mask mismatch')
            if 'eps_r' in z.files: eps=z['eps_r']
            else:
                sidecar,params=full_sidecar(path)
                if params['case_id']!=row['case_id']: raise ValueError('Case ID mismatch')
                with np.load(sidecar,allow_pickle=False) as electrical:
                    if not np.array_equal(electrical['lesion_mask'],z['lesion_mask']) or not np.array_equal(electrical['valid_mask'],self.fov) or not np.array_equal(electrical['frequencies_hz'],FREQUENCIES): raise ValueError('Electrical sidecar geometry/frequency mismatch')
                    if not np.array_equal(electrical['sigma_S_per_m'],z['conductivity_S_per_m'],equal_nan=True): raise ValueError('Electrical sidecar sigma mismatch')
                    eps=electrical['eps_r'].copy()
            for source,dest in [('conductivity_S_per_m','sigma'),('eps_r','eps_r')]:
                a=np.asarray(eps if source=='eps_r' else z[source],dtype=np.float32)
                if a.shape!=(2,64,64) or not np.isfinite(a[:,self.fov]).all() or np.any(a[:,self.fov]<=0): raise ValueError(f'Invalid {source}')
                item[dest]=torch.from_numpy(np.where(self.fov,a,0))
        return item
