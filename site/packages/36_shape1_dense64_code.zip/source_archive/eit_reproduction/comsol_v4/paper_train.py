"""Train one preregistered variant/seed, with validation scheduling and early stop."""
import argparse,json,random,time
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import default_collate
from .data_v6 import FINAL_DATASET_ROOT,Normalizer,ComsolDataset,assert_final_dataset,verify_manifest,signature
from .model import V4Comsol
from .losses import compute_loss
from .metrics import per_case_metrics,aggregate
from .train import FORMAT
from .paper_common import load_protocol,write_json,save_checkpoint,tensor_hash,StopState,configure_runtime

def build_cache(root,mode):
    folder=root/'cache';folder.mkdir(exist_ok=True)
    normalizer_path=folder/(mode+'_normalizer.npz')
    if normalizer_path.exists():norm=Normalizer.load(normalizer_path,FINAL_DATASET_ROOT)
    else:norm=Normalizer.fit_train(FINAL_DATASET_ROOT,mode);norm.save(normalizer_path)
    norm.validate_training_contract(FINAL_DATASET_ROOT,mode)
    cache_path=folder/(mode+'.pt')
    if not cache_path.exists():
        result={'dataset_signature':signature(FINAL_DATASET_ROOT),'input_mode':mode,'splits':{}}
        for split in ('train','val'):
            ds=ComsolDataset(FINAL_DATASET_ROOT,split,norm);items=[]
            for i in range(len(ds)):
                items.append(ds[i])
                if (i+1)%1000==0:print(f'Cache {mode}/{split}: {i+1}/{len(ds)}',flush=True)
            result['splits'][split]=default_collate(items)
        save_checkpoint(cache_path,result)
    cached=torch.load(cache_path,map_location='cpu',weights_only=True,mmap=True)
    if cached['dataset_signature']!=signature(FINAL_DATASET_ROOT) or cached['input_mode']!=mode:raise ValueError('Cache contract changed')
    data=cached['splits']
    for split,n in [('train',3400),('val',720)]:
        ds=ComsolDataset(FINAL_DATASET_ROOT,split,norm)
        if data[split]['case_id']!=[r['case_id'] for r in ds.rows] or len(data[split]['features'])!=n:raise ValueError('Cache case/order mismatch')
    return norm,data

def batches(data,batch_size,epoch,seed,training):
    n=len(data['case_id']);gen=torch.Generator().manual_seed(seed+1000003*epoch)
    order=torch.randperm(n,generator=gen) if training else torch.arange(n)
    for idx in order.split(batch_size):
        ids=idx.tolist()
        yield {k:v[idx.to(v.device)] if torch.is_tensor(v) else [v[i] for i in ids] for k,v in data.items()}

def epoch_pass(model,data,fov,epoch,p,seed,optimizer=None):
    training=optimizer is not None;model.train(training);totals={};count=0;rows=[]
    strength=min(1.,epoch/p['topology_warmup_epochs']) if training else 1.
    for batch in batches(data,p['batch_size'],epoch,seed,training):
        with torch.set_grad_enabled(training):
            out=model(batch['features'],batch['frequencies_hz'])
            loss,pieces=compute_loss(out,batch,fov,strength,ablation=model.ablation)
            if not torch.isfinite(loss):raise FloatingPointError('Nonfinite loss')
            if training:
                optimizer.zero_grad(set_to_none=True);loss.backward()
                grad=torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True)
                optimizer.step();pieces['gradient_norm_before_clip']=float(grad)
            pieces['total_loss']=float(loss.detach())
        n=len(batch['case_id']);count+=n
        for k,v in pieces.items():totals[k]=totals.get(k,0.)+v*n
        if not training:rows.extend(per_case_metrics(out,batch,fov))
    return {**{k:v/count for k,v in totals.items()},'processed_cases':count},aggregate(rows) if rows else None

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--variant',required=True)
    ap.add_argument('--seed',type=int,required=True);a=ap.parse_args();a.root=a.root.resolve()
    p,phash=load_protocol(a.root)
    if a.variant not in p['variants'] or a.seed not in p['seeds']:raise ValueError('Unregistered run')
    dest=a.root/'runs'/f'{a.variant}_seed{a.seed}';dest.mkdir(parents=True,exist_ok=True)
    done=dest/'complete.json'
    if done.exists():
        if json.loads(done.read_text())['protocol_sha256']!=phash:raise ValueError('Completed run protocol differs')
        print('Already complete: '+dest.name,flush=True);return
    configure_runtime(a.seed);contract=assert_final_dataset(FINAL_DATASET_ROOT)
    integrity=verify_manifest(FINAL_DATASET_ROOT)
    variant=p['variants'][a.variant];norm,data=build_cache(a.root,variant['input_mode'])
    ds=ComsolDataset(FINAL_DATASET_ROOT,'val',norm)
    # Re-seed after data preparation: exactly matched model initialization per seed.
    configure_runtime(a.seed)
    config={'base':p['base'],'propagation_steps':p['propagation_steps'],'physics_input':False,'ablation':variant['ablation']}
    model=V4Comsol(ds.fov,**config).cuda();initial_hash=tensor_hash(model.state_dict())
    opt=torch.optim.AdamW(model.parameters(),lr=p['learning_rate'],weight_decay=p['weight_decay'])
    scheduler=torch.optim.lr_scheduler.ReduceLROnPlateau(opt,mode='min',factor=p['plateau_factor'],patience=p['plateau_patience'],
        threshold=p['minimum_improvement'],threshold_mode='abs',min_lr=p['min_lr'])
    stop=StopState(p['minimum_improvement']);history=[];best=float('inf');start=0;best_epoch=0
    if (dest/'last.pt').exists():
        c=torch.load(dest/'last.pt',map_location='cpu',weights_only=True)
        if c['protocol_sha256']!=phash or c['model_config']!=config or c['initial_state_sha256']!=initial_hash:raise ValueError('Resume contract differs')
        model.load_state_dict(c['model']);opt.load_state_dict(c['optimizer']);scheduler.load_state_dict(c['scheduler'])
        stop.load_state_dict(c['early_stopping']);history=c['history'];start=c['epoch'];best=c['best_score'];best_epoch=c['best_epoch']
        torch.set_rng_state(c['rng_torch']);random.setstate(c['rng_python']);torch.cuda.set_rng_state_all(c['rng_cuda'])
        print(f'Resume {dest.name} at epoch {start}',flush=True);del c
    norm.save(dest/'normalizer.npz')
    for split in data:
        data[split]={k:v.cuda() if torch.is_tensor(v) else v for k,v in data[split].items()}
    fov=torch.tensor(ds.fov,dtype=torch.float32,device='cuda')[None,None]
    reason='max_epochs';terminal=start>=p['minimum_epochs'] and stop.bad_epochs>=p['early_stop_patience']
    for epoch in range(start+1,p['max_epochs']+1):
        if terminal:reason='validation_early_stopping';break
        t=time.monotonic();lr=opt.param_groups[0]['lr']
        tr,_=epoch_pass(model,data['train'],fov,epoch,p,a.seed,opt)
        va,metrics=epoch_pass(model,data['val'],fov,epoch,p,a.seed)
        if tr['processed_cases']!=3400 or va['processed_cases']!=720:raise ValueError('Incomplete epoch')
        score=va['selection_loss'];scheduler.step(score);stop.step(score)
        improved=score<best
        if improved:best=score;best_epoch=epoch
        terminal=epoch>=p['minimum_epochs'] and stop.bad_epochs>=p['early_stop_patience']
        history.append({'epoch':epoch,'train':tr,'val':va,'val_metrics':metrics,'epoch_seconds':time.monotonic()-t,
                        'learning_rate':lr,'next_learning_rate':opt.param_groups[0]['lr'],'bad_epochs':stop.bad_epochs})
        ck={'format':FORMAT,'model':model.state_dict(),'optimizer':opt.state_dict(),'scheduler':scheduler.state_dict(),'early_stopping':stop.state_dict(),
            'model_config':config,'normalizer':norm.state(),'fov':torch.from_numpy(ds.fov),'x':torch.from_numpy(ds.x),'y':torch.from_numpy(ds.y),
            'dataset_signature':signature(FINAL_DATASET_ROOT),'dataset_integrity':integrity,'final_dataset_contract':contract,
            'epoch':epoch,'history':history,'best_score':best,'best_epoch':best_epoch,'selection_objective':p['selection'],'physics':None,
            'protocol_sha256':phash,'initial_state_sha256':initial_hash,
            'args':{'smoke':False,'seed':a.seed,'batch_size':p['batch_size'],'input_mode':variant['input_mode'],'variant':a.variant,'physics_weight':0},
            'rng_torch':torch.get_rng_state(),'rng_python':random.getstate(),'rng_cuda':torch.cuda.get_rng_state_all()}
        save_checkpoint(dest/'last.pt',ck)
        if improved:save_checkpoint(dest/'best.pt',ck)
        write_json(dest/'summary.json',{'protocol_sha256':phash,'variant':a.variant,'seed':a.seed,'model_config':config,
             'initial_state_sha256':initial_hash,'history':history,'selected_epoch':best_epoch,'best_selection_loss':best,
             'test_evaluated':False,'status':'training','updated_unix':time.time()})
        print(f'{dest.name} epoch={epoch}/{p["max_epochs"]} lr={lr:.2g} val={score:.6f} IoU={metrics["all"]["foreground_iou"]:.4f} bad={stop.bad_epochs} sec={history[-1]["epoch_seconds"]:.1f}',flush=True)
        if epoch==1 or epoch%25==0 or terminal or epoch==p['max_epochs']:
            from .progress import save_progress
            save_progress(model,ds,torch.device('cuda'),None,history,dest)
    if terminal:reason='validation_early_stopping'
    summary=json.loads((dest/'summary.json').read_text(encoding='utf-8'));summary.update(status='complete',stop_reason=reason)
    write_json(dest/'summary.json',summary)
    from .data_v6 import file_hash
    write_json(done,{'protocol_sha256':phash,'variant':a.variant,'seed':a.seed,'trained_epochs':len(history),'selected_epoch':best_epoch,
                    'stop_reason':reason,'early_stop_triggered':terminal,'best_checkpoint_sha256':file_hash(dest/'best.pt'),
                    'initial_state_sha256':initial_hash,'total_epoch_seconds':sum(h['epoch_seconds'] for h in history)})
    print('TRAIN COMPLETE '+dest.name+' '+reason,flush=True)

if __name__=='__main__':main()
