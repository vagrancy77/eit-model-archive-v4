"""Supervision follows the supplied labels, including sidewall mouth and negative SDF."""
from __future__ import annotations
import torch
from torch.nn import functional as F


def region_mean(x, region):
    region = region.expand_as(x)
    return (x*region).sum() / region.sum().clamp_min(1)


def binary_fit(p, target, fov):
    p = p.clamp(1e-6, 1-1e-6)
    positive, negative = target*fov, (1-target)*fov
    raw = F.binary_cross_entropy(p, target, reduction='none')
    dims = (1, 2, 3)
    pos = (raw*positive).sum(dims) / positive.sum(dims).clamp_min(1)
    neg = (raw*negative).sum(dims) / negative.sum(dims).clamp_min(1)
    return torch.where(positive.sum(dims)>0, .5*(pos+neg), neg).mean()


def dice_loss(p, target, fov):
    p, target = p*fov, target*fov
    dims = (1, 2, 3)
    loss = 1-(2*(p*target).sum(dims)+1e-6)/(p.sum(dims)+target.sum(dims)+1e-6)
    empty_penalty = p.sum(dims)/fov.expand_as(p).sum(dims).clamp_min(1)
    return torch.where(target.sum(dims)>0, loss, empty_penalty).mean()


def soft_skeleton(x, steps=8):
    def erode(a):
        return torch.minimum(-F.max_pool2d(-a, (3, 1), 1, (1, 0)), -F.max_pool2d(-a, (1, 3), 1, (0, 1)))
    opened = F.max_pool2d(erode(x), 3, 1, 1)
    skel = F.relu(x-opened)
    for _ in range(steps):
        x = erode(x)
        delta = F.relu(x-F.max_pool2d(erode(x), 3, 1, 1))
        skel = skel+F.relu(delta-skel*delta)
    return skel


def cldice(p, target, fov):
    active = target.sum((1, 2, 3)) > 0
    if not active.any():
        return p.sum()*0
    p, target = (p*fov)[active], (target*fov)[active]
    ps, ts = soft_skeleton(p), soft_skeleton(target)
    precision = (ps*target).sum((1, 2, 3))/(ps.sum((1, 2, 3))+1e-6)
    recall = (ts*p).sum((1, 2, 3))/(ts.sum((1, 2, 3))+1e-6)
    return (1-2*precision*recall/(precision+recall+1e-6)).mean()


def soft_iou(p, target):
    return (p*target).sum((1, 2, 3))/(p+target-p*target).sum((1, 2, 3)).clamp_min(1)


def compute_loss(out, batch, fov, topology_strength=1., ablation='full'):
    if ablation not in ('full','no_topology','no_risk'): raise ValueError('Unknown ablation')
    mask, labels = batch['mask'], batch['labels']
    fg, basefg = out['foreground_probability'], out['base_foreground_probability']
    weights = fg.new_tensor([.24, 1., 1.])
    def ce(logit, log=False):
        fn = F.nll_loss if log else F.cross_entropy
        return region_mean(fn(logit, labels, weight=weights, reduction='none')[:, None], fov)
    pieces = {'base_ce': ce(out['base_logits']), 'final_ce': ce(out['logits'], True),
              'base_dice': dice_loss(basefg, mask, fov), 'final_dice': dice_loss(fg, mask, fov),
              'sdf': region_mean(F.smooth_l1_loss(out['sdf'], batch['sdf'], beta=.08, reduction='none'), fov)}
    boundary = fg.sum()*0
    for pred, weight in ((basefg, .45), (fg, .55)):
        for dim in (-1, -2):
            a, b = pred.diff(dim=dim), mask.diff(dim=dim)
            valid = fov[..., 1:]*fov[..., :-1] if dim == -1 else fov[..., 1:, :]*fov[..., :-1, :]
            boundary += weight*region_mean((a-b).abs(), valid)
    pieces['boundary'] = boundary
    for key in ('sigma', 'eps_r'):
        error = F.smooth_l1_loss(out[key].clamp_min(1e-8).log(), batch[key].clamp_min(1e-8).log(), beta=.15, reduction='none')
        pieces[key] = .5*(region_mean(error, mask*fov)+region_mean(error, (1-mask)*fov))
    cut = batch['cutout']
    has_cut = (cut.sum((1, 2, 3)) > 0).float()[:, None]
    ordinary = (1-has_cut)[:, :, None, None]
    pieces['cutout'] = binary_fit(out['raw_cutout_probability'], cut, fov)+.5*dice_loss(out['raw_cutout_probability'], cut, fov)
    pieces['mouth_sidewall'] = binary_fit(out['mouth_probability'], batch['mouth'], fov)+.5*dice_loss(out['mouth_probability'], batch['mouth'], fov)
    pieces['cldice'] = cldice(out['raw_cutout_probability'], cut, fov)
    pieces['case_gate'] = F.binary_cross_entropy_with_logits(out['class_gate_logit'], has_cut)
    proposal_fg = out['proposal_probabilities'][:, 1:].sum(1, keepdim=True)
    proposal_iou, base_iou = soft_iou(proposal_fg, mask), soft_iou(basefg, mask)
    proposal_cut = out['proposal_cutout_probability']
    cut_dice = 2*(proposal_cut*cut).sum((1, 2, 3))/(proposal_cut+cut).sum((1, 2, 3)).clamp_min(1)
    action_target = (has_cut[:, 0]*torch.sigmoid(20*(proposal_iou-base_iou+.015))*torch.sigmoid(8*(cut_dice-.12))).detach()
    pieces['action_gate'] = F.binary_cross_entropy_with_logits(out['action_gate_logit'][:, 0], action_target)
    pieces['ordinary_consistency'] = region_mean((fg-basefg).abs(), ordinary*fov)
    pieces['ordinary_gate'] = (out['case_gate']*ordinary).sum()/ordinary.sum().clamp_min(1)
    pieces['bank_protection'] = region_mean((basefg-fg).clamp_min(0), mask*fov)
    pieces['notch_fill'] = region_mean(fg, cut*fov)
    total = (pieces['base_ce']+pieces['base_dice']+.85*(pieces['final_ce']+pieces['final_dice'])
             +.32*(pieces['sdf']+pieces['boundary'])+.65*pieces['sigma']+.35*pieces['eps_r'])
    if ablation!='no_topology':
        total += topology_strength*(.48*pieces['cutout']+.24*pieces['mouth_sidewall']+.08*pieces['cldice']
                                    +.24*pieces['bank_protection']+.22*pieces['notch_fill'])
        if ablation=='full':
            total += topology_strength*(.4*pieces['case_gate']+.75*pieces['action_gate']
                                        +2.4*pieces['ordinary_consistency']+2.2*pieces['ordinary_gate'])
    pieces['selection_loss']=pieces['final_ce']+pieces['final_dice']+.65*pieces['sigma']+.35*pieces['eps_r']
    # No old KTC Jacobian, no surrogate claimed as a COMSOL physical residual.
    return total, {k: float(v.detach()) for k, v in pieces.items()}
