"""Explicitly defined metrics, NOT the challenge-specific KTC-SSIM."""
import numpy as np
import torch
from torch.nn import functional as F


@torch.no_grad()
def per_case_metrics(out, batch, fov):
    domain = fov[0, 0].bool()
    pred = out['probabilities'].argmax(1)
    base = out['base_probabilities'].argmax(1)
    truth = batch['labels']
    records = []
    # Uniform-window SSIM on sigma, separately by frequency, only all-in-FOV windows.
    x, y = out['sigma'], batch['sigma']
    mx, my = F.avg_pool2d(x, 7, 1, 3), F.avg_pool2d(y, 7, 1, 3)
    vx = (F.avg_pool2d(x*x, 7, 1, 3)-mx*mx).clamp_min(0)
    vy = (F.avg_pool2d(y*y, 7, 1, 3)-my*my).clamp_min(0)
    cov = F.avg_pool2d(x*y, 7, 1, 3)-mx*my
    yrange = (y[:, :, domain].amax(-1)-y[:, :, domain].amin(-1)).clamp_min(1e-6)[:, :, None, None]
    c1, c2 = (.01*yrange)**2, (.03*yrange)**2
    smap = ((2*mx*my+c1)*(2*cov+c2))/((mx*mx+my*my+c1)*(vx+vy+c2)).clamp_min(1e-20)
    svalid = F.avg_pool2d(fov, 7, 1, 3)[0, 0] > .999
    for i in range(len(pred)):
        gt, pr, bp = truth[i][domain], pred[i][domain], base[i][domain]
        def fg_scores(a):
            inter = ((a != 0)&(gt != 0)).sum().item()
            union = ((a != 0)|(gt != 0)).sum().item()
            return inter/max(union, 1), 2*inter/max((a != 0).sum().item()+(gt != 0).sum().item(), 1)
        iou, dice = fg_scores(pr)
        class_ious = []
        for cls in (0, 1, 2):
            union = ((gt == cls)|(pr == cls)).sum().item()
            if union:
                class_ious.append(((gt == cls)&(pr == cls)).sum().item()/union)
        rec = {'case_id': batch['case_id'][i], 'shape_class': batch['shape_class'][i],
               'foreground_iou': iou, 'foreground_dice': dice, 'mean_iou_present_classes': float(np.mean(class_ious)),
               'base_foreground_iou': fg_scores(bp)[0], 'iou_change_from_base': iou-fg_scores(bp)[0]}
        cut = batch['cutout'][i, 0].bool() & domain
        rec['cutout_background_recall'] = float((pred[i][cut] == 0).float().mean()) if cut.any() else None
        for key in ('sigma', 'eps_r'):
            p, t = out[key][i, :, domain], batch[key][i, :, domain]
            score = ((p-t).square().sum(-1)/t.square().sum(-1).clamp_min(1e-20)).sqrt()
            for j, freq in enumerate((10000, 50000)):
                rec[f'{key}_nrmse_{freq}Hz'] = float(score[j])
        for j, freq in enumerate((10000, 50000)):
            rec[f'sigma_ssim_{freq}Hz'] = float(smap[i, j][svalid].mean())
        records.append(rec)
    return records


def aggregate(records):
    result = {}
    classes = sorted({r['shape_class'] for r in records})
    groups = {'all': records, 'convex_A': [r for r in records if r['shape_class']=='A'],
              'concave_all': [r for r in records if r['shape_class']!='A'],
              'concave_BCD': [r for r in records if r['shape_class'] in 'BCD']}
    if 'E' in classes: groups['concave_BCDE'] = groups['concave_all']
    for cls in classes:
        groups[cls] = [r for r in records if r['shape_class']==cls]
    for name, rows in groups.items():
        group = {'case_count': len(rows)}
        if rows:
            for key in rows[0]:
                values = [r[key] for r in rows if isinstance(r[key], (int, float)) and r[key] is not None]
                if values:
                    group[key] = float(np.mean(values))
        result[name] = group
    return result
