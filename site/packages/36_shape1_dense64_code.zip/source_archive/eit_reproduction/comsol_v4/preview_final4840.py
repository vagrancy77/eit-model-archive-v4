"""Ground-truth and measurement preview of the pinned release, never predictions."""
import argparse
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .data_v6 import FINAL_DATASET_ROOT, assert_final_dataset, load_rows, row_case_path, grid_arrays


def main():
    p=argparse.ArgumentParser();p.add_argument('--output-dir',type=Path,required=True);a=p.parse_args()
    assert_final_dataset(FINAL_DATASET_ROOT)
    rows=load_rows(FINAL_DATASET_ROOT,'train');x,y,fov=grid_arrays(FINAL_DATASET_ROOT)
    selected=[]
    for cls in 'ABCDE':
        selected.append(min((r for r in rows if r['shape_class']==cls),key=lambda r:r['case_id']))
    a.output_dir.mkdir(parents=True,exist_ok=True)
    extent=np.array([x[0],x[-1],y[0],y[-1]])*1000
    fig,axes=plt.subplots(5,5,figsize=(16,14),constrained_layout=True)
    for i,r in enumerate(selected):
        with np.load(row_case_path(FINAL_DATASET_ROOT,r),allow_pickle=False) as z:
            fields=[z['lesion_mask'],z['conductivity_S_per_m'][0],z['eps_r'][0],z['voltage'][0].real,z['voltage'][0].imag]
            names=['Lesion mask','Sigma 10 kHz (S/m)','Relative permittivity 10 kHz','Electrode voltage Re (V)','Electrode voltage Im (V)']
            for j,(field,title) in enumerate(zip(fields,names)):
                ax=axes[i,j]
                if j<3:
                    im=ax.imshow(np.where(fov,field,np.nan),origin='lower',extent=extent,cmap='viridis')
                    ax.set(xlabel='x (mm)',ylabel='y (mm)')
                else:
                    im=ax.imshow(field,origin='lower',cmap='coolwarm')
                    ax.set(xlabel='electrode index',ylabel='drive index')
                ax.set_title(r['case_id']+' | '+title,fontsize=9);fig.colorbar(im,ax=ax,shrink=.7)
    fig.suptitle('Final 4840 dataset | fixed A-E training examples | SOURCE TRUTH, NOT MODEL PREDICTIONS')
    fig.savefig(a.output_dir/'final_dataset_AE.png',dpi=130);plt.close(fig)
    # Four new E subtypes, chosen by first case ID without reconstruction scores.
    found={}
    for r in sorted((r for r in rows if r['shape_class']=='E'),key=lambda r:r['case_id']):
        with np.load(row_case_path(FINAL_DATASET_ROOT,r),allow_pickle=False) as z:
            name=json.loads(z['parameters_json'].item())['shape_subtype']
            found.setdefault(name,(r['case_id'],z['lesion_mask'].copy()))
        if len(found)==4: break
    fig,axes=plt.subplots(1,len(found),figsize=(4*len(found),4),squeeze=False,constrained_layout=True)
    for ax,(name,(cid,mask)) in zip(axes[0],found.items()):
        ax.imshow(np.where(fov,mask,np.nan),origin='lower',extent=extent,cmap='Greys',vmin=0,vmax=1)
        ax.set(title=cid+'\n'+name,xlabel='x (mm)',ylabel='y (mm)')
    fig.suptitle('New E subtypes | original training labels, unchanged')
    fig.savefig(a.output_dir/'final_dataset_E_subtypes.png',dpi=150);plt.close(fig)
    print(a.output_dir/'final_dataset_AE.png')


if __name__=='__main__':main()
