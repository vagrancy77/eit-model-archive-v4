"""Train v4 on native COMSOL measurements. Test evaluation is a separate command."""
from __future__ import annotations
import argparse, json, random, time
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import DataLoader
from .data_v6 import (ComsolDataset, Normalizer, verify_manifest, signature,
                      FINAL_DATASET_ROOT, assert_final_dataset)
from .model import V4Comsol
from .losses import compute_loss
from .metrics import aggregate, per_case_metrics
from .physics import ReferencePhysics
from .features import MODES

FORMAT='v4-comsol-native-v2'

def seed_all(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)

def device(name):
    if name=='cuda' and not torch.cuda.is_available(): raise RuntimeError('CUDA requested but unavailable')
    return torch.device('cuda' if name=='cuda' or (name=='auto' and torch.cuda.is_available()) else 'cpu')

def move(batch, dev):
    return {k:v.to(dev,non_blocking=True) if torch.is_tensor(v) else v for k,v in batch.items()}

def predict(model,batch,physics=None):
    image=physics.backprojection(batch['delta_voltage'],batch['background_group']) if physics is not None else None
    return model(batch['features'],batch['frequencies_hz'],physical_image=image)

def run_epoch(model,loader,dev,fov,optimizer=None,topology_strength=1.,max_batches=0,physics=None,physics_weight=0.):
    training=optimizer is not None; model.train(training)
    totals,count,records={},0,[]; tick=time.monotonic()
    for bidx,raw in enumerate(loader):
        if max_batches and bidx>=max_batches: break
        batch=move(raw,dev)
        with torch.set_grad_enabled(training):
            out=predict(model,batch,physics)
            loss,pieces=compute_loss(out,batch,fov,topology_strength,ablation=getattr(model,'ablation','full'))
            if physics_weight:
                residual=physics.loss(out['sigma'],out['eps_r'],batch['background_group'],batch['delta_voltage'])
                loss=loss+physics_weight*residual; pieces['linearized_physics']=float(residual.detach())
            if not torch.isfinite(loss): raise FloatingPointError('Nonfinite training/validation loss')
            pieces['total_loss']=float(loss.detach())
            if training:
                optimizer.zero_grad(set_to_none=True); loss.backward()
                grad=torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True)
                pieces['gradient_norm_before_clip']=float(grad); optimizer.step()
        n=len(batch['features']); count+=n
        for k,v in pieces.items(): totals[k]=totals.get(k,0.)+v*n
        if not training: records.extend(per_case_metrics(out,batch,fov))
        if time.monotonic()-tick>20:
            print(f'{"train" if training else "val"} batches={bidx+1}/{len(loader)} loss={float(loss):.5f}',flush=True); tick=time.monotonic()
    if count==0: raise ValueError('No cases processed')
    return {**{k:v/count for k,v in totals.items()},'processed_cases':count},records

def load_checkpoint(path,dev,physics_path=None):
    c=torch.load(path,map_location='cpu',weights_only=True)
    if c.get('format')!=FORMAT: raise ValueError('Use a native-v2 checkpoint; legacy KTC/minimal weights are not silently converted')
    model=V4Comsol(c['fov'].numpy(),**c['model_config']).to(dev)
    model.load_state_dict(c['model']); model.eval()
    physics=None
    if c['model_config']['physics_input']:
        if physics_path is None: raise ValueError('This checkpoint requires --physics-operator')
        physics=ReferencePhysics(physics_path,c['fov'].numpy(),c['x'].numpy(),c['y'].numpy()).to(dev)
        if physics.metadata['operator_sha256']!=c['physics']['operator_sha256']: raise ValueError('Checkpoint/physical-operator mismatch')
    elif physics_path is not None: raise ValueError('This checkpoint was trained without a physical operator')
    return model,Normalizer.from_state(c['normalizer']),physics,c

def main(argv=None):
    ap=argparse.ArgumentParser()
    ap.add_argument('--dataset-root',type=Path,default=FINAL_DATASET_ROOT); ap.add_argument('--output-dir',type=Path,required=True)
    ap.add_argument('--epochs',type=int,default=50); ap.add_argument('--batch-size',type=int,default=8)
    ap.add_argument('--base',type=int,default=28); ap.add_argument('--lr',type=float,default=4e-4)
    ap.add_argument('--cpu-threads',type=int,default=2)
    ap.add_argument('--cache-data',action='store_true',help='Cache normalized training/validation tensors in RAM; no data changes')
    ap.add_argument('--preview-every',type=int,default=0,help='Save fixed validation previews every N epochs (0 disables)')
    ap.add_argument('--device',choices=['auto','cuda','cpu'],default='auto'); ap.add_argument('--seed',type=int,default=20261010)
    ap.add_argument('--max-train-batches',type=int,default=0); ap.add_argument('--max-val-batches',type=int,default=0)
    ap.add_argument('--smoke',action='store_true'); ap.add_argument('--normalizer',type=Path)
    ap.add_argument('--input-mode', choices=MODES, default='calibrated')
    ap.add_argument('--physics-operator',type=Path); ap.add_argument('--physics-weight',type=float,default=0.)
    ap.add_argument('--resume',type=Path)
    args=ap.parse_args(argv)
    if min(args.epochs,args.batch_size,args.base,args.cpu_threads)<=0 or args.lr<=0 or min(args.max_train_batches,args.max_val_batches,args.physics_weight,args.preview_every)<0: ap.error('Invalid numerical arguments')
    if args.physics_weight>0 and args.physics_operator is None: ap.error('A matching validated Jacobian FILE is required for physics loss; the report is not the operator')
    if args.physics_operator is not None and (args.physics_operator.suffix.lower()!='.npz' or not args.physics_operator.is_file()): ap.error('--physics-operator must be an existing matched NPZ matrix, not a verification report')
    if args.smoke:
        args.epochs=1; args.max_train_batches=args.max_train_batches or 4; args.max_val_batches=args.max_val_batches or 2
    if args.output_dir.exists() and any(args.output_dir.iterdir()) and args.resume is None: raise FileExistsError('Output directory is nonempty; use a new directory or --resume')
    torch.set_num_threads(args.cpu_threads)
    seed_all(args.seed); dev=device(args.device)
    final_contract=assert_final_dataset(args.dataset_root)
    integrity=verify_manifest(args.dataset_root)
    normalizer=Normalizer.load(args.normalizer,args.dataset_root) if args.normalizer else Normalizer.fit_train(args.dataset_root,args.input_mode)
    normalizer.validate_training_contract(args.dataset_root,args.input_mode)
    train=ComsolDataset(args.dataset_root,'train',normalizer,limit=30 if args.smoke else 0,physics=args.physics_operator is not None)
    val=ComsolDataset(args.dataset_root,'val',normalizer,limit=10 if args.smoke else 0,physics=args.physics_operator is not None)
    config={'base':args.base,'propagation_steps':14,'physics_input':args.physics_operator is not None}
    model=V4Comsol(train.fov,**config).to(dev)
    physics=ReferencePhysics(args.physics_operator,train.fov,train.x,train.y).to(dev) if args.physics_operator else None
    if physics is not None and physics.metadata.get('dataset_signature') != signature(args.dataset_root):
        raise ValueError('Physical operator was converted for another dataset release/layout')
    optimizer=torch.optim.AdamW(model.parameters(),lr=args.lr,weight_decay=1e-4)
    history=[]; best=float('inf'); start=0
    if args.resume:
        expected_normalizer=normalizer
        model,normalizer,physics,c=load_checkpoint(args.resume,dev,args.physics_operator)
        if c['dataset_signature']!=signature(args.dataset_root) or c['model_config']!=config: raise ValueError('Resume dataset/model mismatch')
        if (normalizer.metadata != expected_normalizer.metadata or
                not np.array_equal(normalizer.mean,expected_normalizer.mean) or
                not np.array_equal(normalizer.std,expected_normalizer.std)):
            raise ValueError('Resume normalizer/input representation differs')
        if c['args']['physics_weight']!=args.physics_weight or c['args']['smoke']!=args.smoke or c['args']['batch_size']!=args.batch_size: raise ValueError('Resume settings mismatch')
        train.normalizer=val.normalizer=normalizer
        optimizer=torch.optim.AdamW(model.parameters(),lr=args.lr,weight_decay=1e-4); optimizer.load_state_dict(c['optimizer'])
        history=c['history']; start=c['epoch']; best=c['best_score']
        torch.set_rng_state(c['rng_torch']); random.setstate(c['rng_python'])
        if dev.type=='cuda' and c['rng_cuda']: torch.cuda.set_rng_state_all(c['rng_cuda'])
        if args.epochs<=start: raise ValueError('--epochs must exceed completed epoch when resuming')
        if args.resume.resolve().parent!=args.output_dir.resolve(): raise ValueError('Resume in the checkpoint directory to preserve the selected best.pt')
    args.output_dir.mkdir(parents=True,exist_ok=True); normalizer.save(args.output_dir/'normalizer.npz')
    datasets={'train':train,'val':val}
    if args.cache_data:
        for name,ds in list(datasets.items()):
            cached=[]
            for i in range(len(ds)):
                cached.append(ds[i])
                if (i+1)%500==0: print(f'RAM cache {name}: {i+1}/{len(ds)}',flush=True)
            datasets[name]=cached
    loaders={name:DataLoader(ds,args.batch_size,shuffle=(name=='train'),num_workers=0,pin_memory=dev.type=='cuda') for name,ds in datasets.items()}
    fov=torch.from_numpy(train.fov.astype(np.float32))[None,None].to(dev)
    print(f'device={dev}; parameters={sum(p.numel() for p in model.parameters())}; physics={physics is not None}; test_split=NOT_RUN',flush=True)
    for epoch in range(start,args.epochs):
        epoch_start=time.monotonic()
        topology=min(1.,(epoch+1)/10.)
        tr,_=run_epoch(model,loaders['train'],dev,fov,optimizer,topology,args.max_train_batches,physics,args.physics_weight)
        va,rows=run_epoch(model,loaders['val'],dev,fov,None,1.,args.max_val_batches,physics,args.physics_weight)
        history.append({'epoch':epoch+1,'topology_train_strength':topology,'train':tr,'val':va,'val_metrics':aggregate(rows),
                        'epoch_seconds':time.monotonic()-epoch_start})
        score=va['total_loss']; improved=score<best; best=min(best,score)
        ckpt={'format':FORMAT,'model':model.state_dict(),'optimizer':optimizer.state_dict(),'model_config':config,
              'normalizer':normalizer.state(),'fov':torch.from_numpy(train.fov),'x':torch.from_numpy(train.x),'y':torch.from_numpy(train.y),
              'dataset_signature':signature(args.dataset_root),'dataset_integrity':integrity,'epoch':epoch+1,'history':history,'best_score':best,
              'selection_objective':'validation total_loss with fixed full topology weights','physics':physics.metadata if physics else None,
              'final_dataset_contract':final_contract,
              'args':{k:str(v) if isinstance(v,Path) else v for k,v in vars(args).items()},'rng_torch':torch.get_rng_state(),
              'rng_python':random.getstate(),'rng_cuda':torch.cuda.get_rng_state_all() if dev.type=='cuda' else []}
        torch.save(ckpt,args.output_dir/'last.pt')
        if improved: torch.save(ckpt,args.output_dir/'best.pt')
        summary={'format':FORMAT,'smoke':args.smoke,'device':str(dev),'model_config':config,'history':history,'integrity':integrity,
                 'final_dataset_contract':final_contract,
                 'physical_operator':ckpt['physics'],'test_evaluated':False,'selection_objective':ckpt['selection_objective'],
                 'limitations':['Smoke runs only verify software, not reconstruction performance.','Without a matching actual Jacobian, physical inputs and residual loss are disabled.'],
                 'updated_unix':time.time()}
        (args.output_dir/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf-8')
        print(f'epoch {epoch+1}/{args.epochs} train_loss={tr["total_loss"]:.5f} val_loss={va["total_loss"]:.5f}; saved={args.output_dir}',flush=True)
        print(f'val_IoU all={history[-1]["val_metrics"]["all"]["foreground_iou"]:.4f} A={history[-1]["val_metrics"]["convex_A"]["foreground_iou"]:.4f} E={history[-1]["val_metrics"]["E"]["foreground_iou"]:.4f}; seconds={history[-1]["epoch_seconds"]:.1f}',flush=True)
        if args.preview_every and (epoch==start or (epoch+1)%args.preview_every==0 or epoch+1==args.epochs):
            try:
                from .progress import save_progress
                save_progress(model,val,dev,physics,history,args.output_dir)
            except (ImportError,OSError) as error:
                print(f'Preview rendering deferred (checkpoint is safe): {error}',flush=True)

if __name__=='__main__': main()
