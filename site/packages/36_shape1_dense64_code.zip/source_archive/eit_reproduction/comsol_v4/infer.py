"""Checkpoint-contained inference; labels are loaded only with --evaluate."""
import argparse, json
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import DataLoader
from .data_v6 import ComsolDataset, read_features, FREQUENCIES, file_hash, signature, assert_final_dataset, verify_manifest
from .metrics import per_case_metrics, aggregate
from .train import device, move, predict, load_checkpoint


def voltage_only_batch(path,normalizer,physics=None,background_group=None):
    path=Path(path)
    batch={'features':torch.from_numpy(normalizer(read_features(path,normalizer.metadata.get('input_mode','native'))))[None],
           'frequencies_hz':torch.tensor(FREQUENCIES,dtype=torch.float32)[None],
           'case_id':[path.parent.name if path.name=='sample_pair.npz' else path.stem],
           'shape_class':['unknown']}
    if physics is not None:
        if background_group not in ('Fat','Muscle'): raise ValueError('Physical inference needs known --background-group')
        with np.load(path,allow_pickle=False) as z:
            d=z['eit_delta_voltage'] if 'eit_delta_voltage' in z else z['voltage']-z['background_voltage']
        batch['delta_voltage']=torch.from_numpy(d.astype(np.complex64))[None]
        batch['background_group']=torch.tensor([['Fat','Muscle'].index(background_group)])
    return batch


def main(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument('--checkpoint',type=Path,required=True); p.add_argument('--output-dir',type=Path,required=True)
    g=p.add_mutually_exclusive_group(required=True)
    g.add_argument('--dataset-root',type=Path); g.add_argument('--input-npz',type=Path)
    p.add_argument('--split',choices=['train','val','test'],default='val')
    p.add_argument('--limit',type=int,default=0); p.add_argument('--batch-size',type=int,default=8)
    p.add_argument('--evaluate',action='store_true'); p.add_argument('--device',choices=['auto','cuda','cpu'],default='auto')
    p.add_argument('--physics-operator',type=Path); p.add_argument('--background-group',choices=['Fat','Muscle'])
    p.add_argument('--equivalence-report',type=Path,help='Exhaustive final minimal/full field equivalence audit')
    p.add_argument('--canonical-order',action='store_true',help='Sort case IDs for identical batch composition across layouts')
    a=p.parse_args(argv)
    if a.limit<0 or a.batch_size<1: p.error('Invalid limit/batch size')
    if a.evaluate and a.input_npz: p.error('Standalone inference reads measurements only; use a dataset for evaluation')
    integrity=None
    if a.evaluate:
        assert_final_dataset(a.dataset_root)
        integrity=verify_manifest(a.dataset_root)
    if a.output_dir.exists() and any(a.output_dir.iterdir()): raise FileExistsError('Use a new output directory')
    dev=device(a.device); model,norm,physics,c=load_checkpoint(a.checkpoint,dev,a.physics_operator)
    fov=c['fov'].to(dev)[None,None].float()
    equivalence=None
    if a.dataset_root:
        if physics and physics.metadata.get('dataset_signature')!=signature(a.dataset_root):
            raise ValueError('Physical operator and dataset release differ')
        ds=ComsolDataset(a.dataset_root,a.split,norm,limit=a.limit,with_labels=a.evaluate,physics=physics is not None)
        if not np.array_equal(ds.fov,c['fov'].numpy()) or not np.array_equal(ds.x,c['x'].numpy()) or not np.array_equal(ds.y,c['y'].numpy()): raise ValueError('Inference geometry differs from checkpoint')
        if a.evaluate and signature(a.dataset_root)!=c['dataset_signature']:
            if a.equivalence_report is None: raise ValueError('Different layout requires exhaustive --equivalence-report')
            if norm.metadata.get('input_mode','native')!='calibrated': raise ValueError('Equivalence certificate only covers calibrated model inputs')
            from .compare_layouts import validate_equivalence_report
            equivalence=validate_equivalence_report(a.equivalence_report,a.dataset_root,c['dataset_signature'])
        if a.canonical_order: ds.rows.sort(key=lambda row:row['case_id'])
        loader=DataLoader(ds,a.batch_size,num_workers=0,shuffle=False)
    else: loader=[voltage_only_batch(a.input_npz,norm,physics,a.background_group)]
    a.output_dir.mkdir(parents=True,exist_ok=True)
    rows=[]; case_ids=[]
    with torch.no_grad():
        for raw in loader:
            batch=move(raw,dev); out=predict(model,batch,physics)
            if a.evaluate: rows.extend(per_case_metrics(out,batch,fov))
            for i,case_id in enumerate(batch['case_id']):
                if Path(case_id).name!=case_id or case_id in case_ids: raise ValueError('Invalid or duplicate output ID')
                data={k:out[k][i].cpu().numpy() for k in ('sigma','eps_r','probabilities','sdf','foreground_probability','raw_cutout_probability','mouth_probability','case_gate')}
                data['conductivity_S_per_m']=data.pop('sigma')
                data['electrical_class']=data['probabilities'].argmax(0).astype(np.uint8)
                data.update(x=c['x'].numpy(),y=c['y'].numpy(),valid_mask=c['fov'].numpy(),frequencies_hz=FREQUENCIES)
                if a.evaluate:
                    for source,dest in [('sigma','true_conductivity_S_per_m'),('eps_r','true_eps_r'),('mask','true_lesion_mask'),('cutout','true_cutout'),('labels','true_electrical_class')]: data[dest]=batch[source][i].cpu().numpy()
                data['metadata_json']=json.dumps({'case_id':case_id,'axis_order':'frequency,y,x','conductivity_unit':'S/m','eps_r_unit':'dimensionless','coordinate_unit':'m','smoke_checkpoint':c['args']['smoke'],'labels_loaded':a.evaluate})
                np.savez_compressed(a.output_dir/f'{case_id}.npz',**data); case_ids.append(case_id)
            if len(case_ids)%64==0: print(f'Predicted {len(case_ids)} cases',flush=True)
    report={'checkpoint_sha256':file_hash(a.checkpoint),'smoke_checkpoint':c['args']['smoke'],'case_count':len(case_ids),'case_ids':case_ids,
            'labels_loaded':a.evaluate,'split':a.split if a.dataset_root else None,'physics':c['physics'],
            'dataset_signature':signature(a.dataset_root) if a.dataset_root else None,
            'dataset_integrity':integrity,
            'layout_equivalence':equivalence,'canonical_order':a.canonical_order,
            'input_mode':norm.metadata.get('input_mode','native'),
            'metrics':aggregate(rows) if a.evaluate else None,'per_case_metrics':rows if a.evaluate else None,
            'note':'Smoke checkpoint is only for interface verification, not a trained reconstruction result.' if c['args']['smoke'] else 'Independent inference; model weights and normalization frozen.'}
    (a.output_dir/'predictions.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps({'case_count':len(case_ids),'labels_loaded':a.evaluate,'output_dir':str(a.output_dir)},ensure_ascii=False),flush=True)


if __name__=='__main__': main()
