"""Standalone NumPy/SciPy report: paired seed/position statistics and real figures."""
import hashlib,json,sys
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

PROJECT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(PROJECT.parent/'eit_complex_information_study_20261013'))
from analyze_experiment import boundary_metrics

LABELS={'calibrated':'Complex calibrated','amplitude':'Amplitude','complex':'Complex raw',
        'amplitude_calibrated':'Amplitude calibrated','no_topology':'No topology branch','no_risk':'No case risk gates'}
GROUPS={'all':tuple('ABCDE'),'A':('A',),'BCDE':tuple('BCDE'),'E':('E',)}
PAIRS=[('complex','amplitude','raw_phase'),('calibrated','complex','complex_calibration'),
       ('calibrated','amplitude_calibrated','calibrated_phase'),('calibrated','amplitude','combined_phase_calibration'),
       ('calibrated','no_topology','topology_branch'),('calibrated','no_risk','case_risk_gates')]
METRICS=('foreground_iou','foreground_dice','mean_iou_present_classes','sigma_ssim_10000Hz','sigma_ssim_50000Hz',
         'sigma_nrmse_10000Hz','eps_r_nrmse_10000Hz','sigma_lesion_nrmse_10000Hz','sigma_lesion_nrmse_50000Hz',
         'hd95_mm','concavity_depth_abs_error_mm','notch_direction_correct')

def digest(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def write(path,obj):
    path=Path(path);tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(obj,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8');tmp.replace(path)

def groups(rows,group):return [r for r in rows if r['shape_class'] in GROUPS[group]]

def enrich(root,run,position_by_id):
    folder=root/'evaluations'/run['name'];source=folder/'predictions.json'
    report=json.loads(source.read_text(encoding='utf-8'))
    if report['checkpoint_sha256']!=run['checkpoint_sha256'] or report['case_count']!=720:raise ValueError('Test output provenance mismatch')
    provenance={'checkpoint_sha256':run['checkpoint_sha256'],'predictions_json_sha256':digest(source),'analysis_source_sha256':digest(__file__)}
    target=folder/'boundary_metrics.json'
    if target.exists():
        old=json.loads(target.read_text(encoding='utf-8'))
        if old['provenance']==provenance:return old['records']
    records=[]
    for i,row0 in enumerate(report['per_case_metrics']):
        row=dict(row0);row['position_id']=position_by_id[row['case_id']]
        with np.load(folder/(row['case_id']+'.npz'),allow_pickle=False) as z:
            fov=z['valid_mask'].astype(bool);truth=z['true_lesion_mask'][0]>.5;pred=z['electrical_class']!=0
            pixel=float(np.diff(z['x']).mean()*1000);row.update(boundary_metrics(pred,truth,fov,pixel))
            row['case_gate_value']=float(z['case_gate'].mean())
            row['lesion_area_relative_abs_error']=float(abs((pred&fov).sum()-(truth&fov).sum())/max((truth&fov).sum(),1))
            row['centroid_error_mm']=float(np.linalg.norm(np.argwhere(pred&fov).mean(0)-np.argwhere(truth&fov).mean(0))*pixel) if (pred&fov).any() else float(np.hypot(*fov.shape)*pixel)
            for key,pk,tk in [('sigma','conductivity_S_per_m','true_conductivity_S_per_m'),('eps_r','eps_r','true_eps_r')]:
                for fi,freq in enumerate((10000,50000)):
                    pv,tv=z[pk][fi,truth&fov],z[tk][fi,truth&fov]
                    row[f'{key}_lesion_nrmse_{freq}Hz']=float(np.linalg.norm(pv-tv)/max(np.linalg.norm(tv),1e-20))
        records.append(row)
    write(target,{'provenance':provenance,'records':records});print('Boundary metrics: '+run['name'],flush=True)
    return records

def aggregate_seed_records(records):
    result={}
    for group in GROUPS:
        selected=[groups(rows,group) for rows in records]
        keys=sorted({k for rows in selected for r in rows for k,v in r.items() if isinstance(v,(int,float))})
        item={'case_count_per_seed':len(selected[0]),'seed_count':len(records)}
        for key in keys:
            vals=[]
            for rows in selected:
                v=[r[key] for r in rows if isinstance(r.get(key),(int,float))]
                if v:vals.append(float(np.mean(v)))
            if vals:item[key]={'mean':float(np.mean(vals)),'seed_sd':float(np.std(vals,ddof=1)) if len(vals)>1 else None,'per_seed':vals}
        item['direction_valid_per_seed']=[sum(isinstance(r.get('notch_direction_correct'),(int,float)) for r in rows) for rows in selected]
        result[group]=item
    return result

def paired_statistics(variant,base,group,metric,rng):
    arrays=[]
    for va,ba in zip(variant,base):
        v={r['case_id']:r for r in groups(va,group)};b={r['case_id']:r for r in groups(ba,group)}
        if v.keys()!=b.keys():raise ValueError('Unpaired cases')
        by_position={}
        for cid,row in v.items():
            x,y=row.get(metric),b[cid].get(metric)
            if isinstance(x,(int,float)) and isinstance(y,(int,float)):
                by_position.setdefault(row['position_id'],[]).append(x-y)
        arrays.append({k:float(np.mean(x)) for k,x in by_position.items()})
    positions=sorted(set.intersection(*(set(a) for a in arrays)))
    if len(positions)<2:return None
    matrix=np.array([[a[pos] for pos in positions] for a in arrays])
    ns,np_=matrix.shape
    seed_draw=rng.integers(ns,size=(5000,ns));pos_draw=rng.integers(np_,size=(5000,np_))
    samples=matrix[seed_draw[:,:,None],pos_draw[:,None,:]].mean((1,2))
    result={'mean_difference':float(matrix.mean()),'ci95':np.quantile(samples,[.025,.975]).tolist(),
            'seed_count':ns,'position_groups':np_,'per_seed_difference':matrix.mean(1).tolist()}
    if metric=='foreground_iou' and group=='all':
        position_effect=matrix.mean(0);observed=abs(position_effect.mean())
        signs=rng.integers(0,2,size=(50000,np_))*2-1
        null=(signs*position_effect).mean(1)
        result['position_sign_flip_p_two_sided']=float((1+(abs(null)>=observed-1e-15).sum())/50001)
    return result

def figures(root,p,records,summary,comparisons):
    out=root/'figures';out.mkdir(exist_ok=True);seed=p['seeds'][0];variants=list(p['variants'])
    ids=sorted(r['case_id'] for r in records['calibrated'][0]);chosen=[next(cid for cid in ids if cid.startswith(c+'_')) for c in 'ABCDE']
    def read(v,cid):
        with np.load(root/'evaluations'/f'{v}_seed{seed}'/(cid+'.npz'),allow_pickle=False) as z:return {k:z[k].copy() for k in z.files}
    fig,axes=plt.subplots(5,len(variants)+1,figsize=(21,14),constrained_layout=True)
    for i,cid in enumerate(chosen):
        z=read('calibrated',cid);truth=z['true_lesion_mask'][0]>.5;fov=z['valid_mask'].astype(bool)
        masks=[truth]+[read(v,cid)['electrical_class']!=0 for v in variants]
        for j,(name,mask) in enumerate(zip(['Truth']+[LABELS[v] for v in variants],masks)):
            ax=axes[i,j];ax.imshow(np.where(fov,mask,np.nan),origin='lower',cmap='Greys',vmin=0,vmax=1)
            iou=float((mask&truth&fov).sum()/max(((mask|truth)&fov).sum(),1))
            if j:ax.contour(truth,[.5],colors='red',linewidths=.7)
            ax.set_title(name+(f'\nIoU={iou:.3f}' if j else ''),fontsize=9);ax.set_xticks([]);ax.set_yticks([])
        axes[i,0].set_ylabel(cid)
    fig.suptitle(f'Frozen test | prespecified first seed {seed}, first ID per class | red = truth boundary')
    fig.savefig(out/'ablation_cases.png',dpi=150);plt.close(fig)
    for kind in ('selection','lr'):
        fig,axes=plt.subplots(2,3,figsize=(16,9),constrained_layout=True)
        for ax,v in zip(axes.flat,variants):
            for s in p['seeds']:
                h=json.loads((root/'runs'/f'{v}_seed{s}'/'summary.json').read_text(encoding='utf-8'))['history']
                y=[r['val']['selection_loss'] if kind=='selection' else r['learning_rate'] for r in h]
                ax.plot([r['epoch'] for r in h],y,label=str(s))
            ax.set(title=LABELS[v],xlabel='Epoch',ylabel='Validation selection loss' if kind=='selection' else 'Learning rate')
            if kind=='lr':ax.set_yscale('log')
            ax.grid(alpha=.25);ax.legend(fontsize=8)
        fig.savefig(out/('learning_curves.png' if kind=='selection' else 'learning_rates.png'),dpi=150);plt.close(fig)
    fig,axes=plt.subplots(5,6,figsize=(18,14),constrained_layout=True)
    for i,cid in enumerate(chosen):
        z=read('calibrated',cid);fov=z['valid_mask'].astype(bool)
        for j,(tk,pk,title) in enumerate([('true_conductivity_S_per_m','conductivity_S_per_m','sigma 10kHz'),('true_eps_r','eps_r','eps_r 10kHz')]):
            t,pred=z[tk][0],z[pk][0];lo,hi=t[fov].min(),t[fov].max()
            for k,(name,a) in enumerate([('Truth',t),('Prediction',pred),('Absolute error',abs(pred-t))]):
                ax=axes[i,j*3+k];im=ax.imshow(np.where(fov,a,np.nan),origin='lower',cmap='magma' if k==2 else 'viridis',vmin=0 if k==2 else lo,vmax=None if k==2 else hi)
                ax.set_title(name+' '+title,fontsize=9);ax.set_xticks([]);ax.set_yticks([]);fig.colorbar(im,ax=ax,shrink=.65)
            axes[i,0].set_ylabel(cid)
    fig.suptitle('Complex calibrated | fixed first seed/cases | truth-based material color limits')
    fig.savefig(out/'material_reconstruction.png',dpi=140);plt.close(fig)
    worst=sorted(records['calibrated'][0],key=lambda r:(r['foreground_iou'],r['case_id']))[:5]
    fig,axes=plt.subplots(2,5,figsize=(15,7),constrained_layout=True)
    for j,row in enumerate(worst):
        z=read('calibrated',row['case_id']);t=z['true_lesion_mask'][0]>.5;pred=z['electrical_class']!=0
        yy,xx=np.where(t|pred);xlim=(max(0,xx.min()-4),min(63,xx.max()+4));ylim=(max(0,yy.min()-4),min(63,yy.max()+4))
        for i,(name,a) in enumerate([('Truth',t),('Prediction',pred)]):
            ax=axes[i,j];ax.imshow(a,origin='lower',cmap='Greys',vmin=0,vmax=1);ax.set_xlim(*xlim);ax.set_ylim(*ylim)
            if i:ax.contour(t,[.5],colors='red',linewidths=1.)
            ax.set_title(row['case_id']+'\n'+name+(f' IoU {row["foreground_iou"]:.3f}' if i else ''));ax.set_xticks([]);ax.set_yticks([])
    fig.suptitle('Five lowest-IoU cases of prespecified first calibrated seed | zoomed diagnostics')
    fig.savefig(out/'low_iou_cases.png',dpi=150);plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(17,6),constrained_layout=True)
    for ax,g in zip(axes,('all','A','BCDE')):
        for i,(_,_,label) in enumerate(PAIRS):
            r=comparisons[label][g]['foreground_iou'];mean=r['mean_difference'];lo,hi=r['ci95']
            ax.errorbar(mean,i,xerr=[[max(0,mean-lo)],[max(0,hi-mean)]],fmt='o',capsize=4)
        ax.axvline(0,color='black',lw=.8);ax.set_yticks(range(len(PAIRS)),[x[2] for x in PAIRS]);ax.set_title(g);ax.set_xlabel('Paired IoU difference (95% cluster bootstrap CI)');ax.grid(axis='x',alpha=.2)
    fig.savefig(out/'ablation_effects.png',dpi=150);plt.close(fig)

def main(root):
    root=Path(root);p=json.loads((root/'protocol.json').read_text(encoding='utf-8'));frozen=json.loads((root/'frozen_evaluation.json').read_text(encoding='utf-8'))
    if digest(root/'protocol.json')!=frozen['protocol_sha256']:raise ValueError('Protocol hash mismatch')
    splitfile=PROJECT.parent/'eit_dataset_final_v6_4840/extracted/V6_4840_Minimal/splits.json'
    positions={r['case_id']:r['position_id'] for r in json.loads(splitfile.read_text(encoding='utf-8'))['splits'] if r['split']=='test'}
    records={v:[] for v in p['variants']}
    for run in frozen['runs']:records[run['variant']].append(enrich(root,run,positions))
    summary={v:aggregate_seed_records(rows) for v,rows in records.items()}
    comparisons={};rng=np.random.default_rng(20261016)
    for va,ba,name in PAIRS:
        comparisons[name]={g:{m:paired_statistics(records[va],records[ba],g,m,rng) for m in METRICS} for g in GROUPS}
    raw=[comparisons[name]['all']['foreground_iou']['position_sign_flip_p_two_sided'] for _,_,name in PAIRS]
    order=np.argsort(raw);adjusted=np.empty(len(raw));running=0.
    for rank,index in enumerate(order):running=max(running,min(1.,raw[index]*(len(raw)-rank)));adjusted[index]=running
    for i,(_,_,name) in enumerate(PAIRS):comparisons[name]['all']['foreground_iou']['holm_p_six_primary_comparisons']=float(adjusted[i])
    result={'protocol_sha256':frozen['protocol_sha256'],'runs':frozen['runs'],'summary':summary,'paired_comparisons':comparisons,
        'limitations':['Previously inspected internal test cohort; no external blind-test claim.',
        'Three training seeds and 18 test position clusters; confidence intervals remain uncertain.',
        'All runs disable the optional physical operator; this study does not establish a physical-loss contribution.',
        'No-topology removes the cutout branch and its auxiliary losses, retaining SDF and boundary supervision.',
        'No-risk removes case/action gates, retaining pixel proposal modulation.',
        'Holm correction applies to six all-case IoU sign-flip tests only; other intervals are descriptive.']}
    write(root/'summary_statistics.json',result);figures(root,p,records,summary,comparisons)
    lines=['# 最终数据集：长训、多随机种子与消融结果','',
           '数据：train 3400 / val 720 / test 720；每组 3 个随机种子。各组仅按相同验证重建损失选模。测试集此前用于探索，本轮训练期间没有按测试成绩调参。','',
           '## 训练完成情况','', '| 组别 | 种子 | 实际轮数 | 最佳轮数 | 停止原因 |','| --- | ---: | ---: | ---: | --- |']
    for r in frozen['runs']:lines.append(f'| {r["variant"]} | {r["seed"]} | {r["trained_epochs"]} | {r["selected_epoch"]} | {r["stop_reason"]} |')
    lines+=['','达到最大轮数但没有触发早停的运行，只能认为预算用完，不能确认已经收敛。','',
            '## 测试集性能（种子均值 ± 种子标准差）','',
            '| 组别 | 分组 | 病灶 IoU | Dice | mean IoU | SSIM 10kHz | SSIM 50kHz | 病灶 σ NRMSE 10kHz | HD95 mm |',
            '| --- | --- | --- | --- | --- | --- | --- | --- | --- |']
    fields=('foreground_iou','foreground_dice','mean_iou_present_classes','sigma_ssim_10000Hz','sigma_ssim_50000Hz','sigma_lesion_nrmse_10000Hz','hd95_mm')
    for v in p['variants']:
        for g in GROUPS:
            values=[f'{summary[v][g][k]["mean"]:.4f} ± {summary[v][g][k]["seed_sd"]:.4f}' for k in fields]
            lines.append('| '+v+' | '+g+' | '+' | '.join(values)+' |')
    lines+=['','## 配对消融：IoU 差值','',
            '差值为前者减后者，正值表示前者更好。95% 区间同时按种子和位置组配对 bootstrap（5000 次）；不是把 720 例当成独立样本。','',
            '| 比较 | 分组 | 平均差值 | 95% CI |','| --- | --- | ---: | --- |']
    for va,ba,name in PAIRS:
        for g in GROUPS:
            r=comparisons[name][g]['foreground_iou'];lo,hi=r['ci95']
            lines.append(f'| {va} − {ba} | {g} | {r["mean_difference"]:+.4f} | [{lo:+.4f}, {hi:+.4f}] |')
    lines+=['','全部病例 IoU 的六项比较另给出位置组符号翻转检验和 Holm 校正 p 值，见 JSON。其余分组和指标区间作为描述性分析，不据此选择性宣称显著。','',
            '## 门控与内凹诊断','', '| 组别 | 全部平均 IoU 相对同网络基础分支变化 | BCDE 内凹方向正确率 | BCDE 深度误差 mm |','| --- | ---: | ---: | ---: |']
    for v in p['variants']:
        g=summary[v]['BCDE'];lines.append(f'| {v} | {summary[v]["all"]["iou_change_from_base"]["mean"]:+.6f} | {g["notch_direction_correct"]["mean"]:.4f} | {g["concavity_depth_abs_error_mm"]["mean"]:.4f} |')
    lines+=['','方向正确使用预先已有的凸包缺陷方向偏差小于 60° 判据。达到这个判据不表示边界形状或电导率数值完全准确。',
            '','## 图与文件','', '- figures/ablation_cases.png：固定第一种子、每类首个测试病例，所有组逐列比较。',
            '- figures/learning_curves.png、learning_rates.png：所有组/种子的验证选模曲线与学习率。',
            '- figures/ablation_effects.png：总体、普通病例和内凹病例的配对收益及置信区间。',
            '- figures/material_reconstruction.png：主模型的材料真值、预测与绝对误差。',
            '- figures/low_iou_cases.png：预先固定第一种子下主模型最低分五例。',
            '- summary_statistics.json：所有分组指标、种子分数、配对统计及运行信息。',
            '- evaluations/*/boundary_metrics.json：逐病例边界、材料、门控与分割指标。',
            '','## 结论边界','',
            '保留全部对照和负结果。若拓扑或门控的区间跨越零，应报告其独立贡献尚未得到明确支持；若普通 A 类下降，也必须同时报告。当前数据仍是固定协议的仿真数据，无真实临床或跨设备结论。SSIM 为项目的有效域窗口电导率 SSIM，不是 KTC-SSIM。',
            '三种子、长训、消融和统计完成，并不自动证明方法创新性或保证期刊录用。']
    (root/'RESULTS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    write(root/'report_complete.json',{'status':'complete','protocol_sha256':frozen['protocol_sha256'],'results_sha256':digest(root/'RESULTS.md'),'run_count':len(frozen['runs'])})
    print('PAPER STUDY REPORT COMPLETE',flush=True)

if __name__=='__main__':main(sys.argv[1])
