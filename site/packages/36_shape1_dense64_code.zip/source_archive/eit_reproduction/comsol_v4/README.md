# v4 模型：COMSOL 完整 V6 数据接口

## 当前版本（2026-10-16）

**以下原文是 3,872 例版本的历史记录，旧路径与旧训练命令已停用，请勿直接执行。**
现在统一使用 `E:\Codex\eit_dataset_final_v6_4840\extracted\V6_4840_Minimal`，
4,840 例 A–E，train/val/test = 3400/720/720；默认输入为完整复电压的背景校准表示。
当前说明与有效命令在 [FINAL4840_ADAPTATION.md](../FINAL4840_ADAPTATION.md)。
所有新训练都会校验最终数据版本；旧归一化及旧权重不能伪装成该版本的新结果。
本机运行需使用 `E:\conda-envs\pytorch-gpu\python.exe -B`，**不要加 `-s`**，因为 SciPy 位于用户站点。
已完成两条 GPU 短程验证（校准版、校准＋线性物理版），不是完整训练或论文结果。

---

## 历史记录（以下不再是当前运行说明）

本目录是基于历史 v4 的独立适配。数据集格式不改变，历史 v4/v6 工程保留。这里的“数据 V6”不代表换成了 v6 网络。

当前完整数据根目录：
`E:\Codex\eit_dataset_full_v6_20261010\extracted\full3872`

## 已核验的接口

- 3,872 例：train 2,720、val 576、test 576，保持原始 position_id 分组划分。
- 完整版从 `raw/case_*/sample_pair.npz` 读取电压、几何及电导率；从 `detection_dataset/Fat|Muscle/cases/<ID>/electrical_properties.npz` 读取介电常数，并交叉核对标签。
- 同一加载器也支持之前的 `V6_3872_Minimal`。不需要另建转换后的数据集。
- 输入原始电压为复数 `[2,32,32]`，频率顺序为 10/50 kHz。网络使用电压、背景电压、差分电压的实/虚部，共 `[B,12,32,32]`。每个驱动去电极平均，保留电压差，避免依赖任意参考电势。
- 输出电导率和介电常数均为 `[B,2,64,64]`；坐标为原始升序 x/y，轴为 frequency,y,x，不转置、不上下翻转。单位分别是 S/m、无量纲。
- 仍用残差注意力 U-Net、双解码分支、SDF/切除区域辅助头和双重风险门控。新增复电压编码器、学习式电压到图像映射和双频材料输出头。
- SDF 保留“内部为负，距离/64”。mouth 保留数据包的凹陷侧壁带语义，不当作开口种子。
- 训练只用 train 拟合归一化。checkpoint 自带归一化、坐标、模型配置、优化器和随机状态；仅加载 checkpoint 即可进行无标签推理。
- 内部电势、病灶掩膜及材料真值不进入 forward。测试集不参与训练选模。

## 运行

在 PowerShell 中先进入工程目录：

```powershell
Set-Location E:\Codex\eit_reproduction
```

已经安装可用的 GPU Python 是 `E:\conda-envs\pytorch-gpu\python.exe`。使用 `-s` 避免用户级 Python 包覆盖该环境。

短程接口测试（输出目录应为空）：

```powershell
& E:\conda-envs\pytorch-gpu\python.exe -s -m comsol_v4.train `
  --dataset-root E:\Codex\eit_dataset_full_v6_20261010\extracted\full3872 `
  --output-dir E:\Codex\eit_reproduction\outputs\comsol_v4_my_smoke `
  --normalizer E:\Codex\eit_reproduction\outputs\comsol_v4_full_v6_audit\normalizer.npz `
  --smoke --base 28 --batch-size 4 --device cuda
```

正式训练示例（本轮未执行）：

```powershell
& E:\conda-envs\pytorch-gpu\python.exe -s -m comsol_v4.train `
  --dataset-root E:\Codex\eit_dataset_full_v6_20261010\extracted\full3872 `
  --output-dir E:\Codex\eit_reproduction\outputs\comsol_v4_full_v6_train `
  --normalizer E:\Codex\eit_reproduction\outputs\comsol_v4_full_v6_audit\normalizer.npz `
  --epochs 50 --base 28 --batch-size 8 --device cuda
```

显存不足可减小 batch-size。默认验证集全量评估，以固定权重的验证总损失选择 best.pt。训练不会自动评估测试集。

续训：在原输出目录增加 `--resume <原目录>/last.pt`，保持 base、batch-size、物理配置和数据根目录一致，epochs 表示累计目标轮数。不得用 smoke checkpoint 充当正式训练的 resume。

预测并单独评估测试集：

```powershell
& E:\conda-envs\pytorch-gpu\python.exe -s -m comsol_v4.infer `
  --checkpoint E:\Codex\eit_reproduction\outputs\comsol_v4_full_v6_train\best.pt `
  --dataset-root E:\Codex\eit_dataset_full_v6_20261010\extracted\full3872 `
  --split test --evaluate --batch-size 8 --device cuda `
  --output-dir E:\Codex\eit_reproduction\outputs\comsol_v4_full_v6_test
```

移除 `--evaluate` 就不读取真值。也可使用 `--input-npz <单病例测量NPZ>` 替代 dataset-root：只需两频复电压、背景电压（完整版还需一致的差分电压）及 frequencies_hz，不需要掩膜/内部电势。这要求采集协议、几何、电极顺序与训练数据一致，不能保证任意其他设备数据直接适用。

使用 `--limit 8` 时会从 A/B/C/D 轮流抽取病例，适合预览，不是正式全量评估。结果中分别报告普通 A 与内凹 B/C/D。SSIM 是电导率图的 7×7 窗口 SSIM，**不是 KTC-SSIM**。

全量输入标签审计：
`python -s -m comsol_v4.audit --dataset-root <根目录> --output-dir <新目录>`

接口与保存重载检查：
`python -s -m comsol_v4.verify --dataset-root <根目录> --checkpoint <best.pt> --output <检查JSON>`

绘图：
`E:\Anaconda\python.exe -s -m comsol_v4.plot --predictions <infer输出目录> --max-cases 4`

## 物理限制

完整包的 CONTACT_MODEL_ADDENDUM.md 和验证 JSON 确认，原模型的 ContactImpedance 节点没有实际改变电压。实际有效边界为电流端子、未生效有限接触阻抗。历史元数据仍可能写接触阻抗，不能据此宣称是有限接触阻抗 CEM。

原完整版数据包只有均匀参考伴随 Jacobian 的验证报告，**不含对应矩阵**，因此默认物理反投影和物理残差仍关闭。2026-10-15 提供的独立 v4 训练包另外包含同一生成器构建、经过有限差分验证的算子；其复数矩阵已按归一化、电压参考和像素坐标核对后转换为可选文件，见 `integrations/v4_20261015/README.md`。此算子不是旧 KTC Jacobian，也不自动改变此前训练的权重。

`physics.py` 已提供严格的可选接口。只有提供匹配、验证过的复数算子，才可以使用 `--physics-operator <NPZ> --physics-weight <非负数>`。报告不接受为算子文件，无文件却设正权重会报错。即使提供算子，该损失也只是均匀背景一阶线性化，不是每次训练的非线性 FEM。

算子 NPZ 契约见 `ReferencePhysics.__init__`：复数 jacobian_gamma 为 [2背景,2频率,32驱动,32电极,4096像素]，另含背景 sigma/eps、x/y/FOV、频率和验证元数据。启用后的 checkpoint 会核对算子哈希。

当前本目录的测试模型仅跑了 4 个训练 batch，**不是新数据上已经训练好的最终模型，也不证明内凹精度改善**。要使用新算子须重新训练并独立评估。
