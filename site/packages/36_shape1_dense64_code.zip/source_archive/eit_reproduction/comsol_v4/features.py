"""Measurement-only representations, preserving both frequency bands and phase."""
import numpy as np

MODES = ('native', 'amplitude', 'complex', 'calibrated', 'amplitude_calibrated')

def measurement_mask():
    # qV[d,m] = V[d,m]-V[d,m+1]; exclude pairs touching the two drive electrodes.
    d, m = np.indices((32,32))
    negative = (d+1) % 32
    return ~((m==d)|((m+1)%32==d)|(m==negative)|((m+1)%32==negative))

def calibrated_features(v,b,mode='calibrated'):
    if mode not in MODES[1:]: raise ValueError(f'Unknown adjacent representation: {mode}')
    if v.shape != (2,32,32) or b.shape != v.shape or not np.iscomplexobj(v) or not np.iscomplexobj(b):
        raise ValueError('Complex [2,32,32] case/background voltages are required')
    if not np.isfinite(v).all() or not np.isfinite(b).all(): raise ValueError('Nonfinite measurements')
    valid=measurement_mask()[None]
    qv,qb=v-np.roll(v,-1,axis=-1),b-np.roll(b,-1,axis=-1)
    rms=np.sqrt((np.abs(qb)**2*valid).sum((1,2),keepdims=True)/valid.sum())
    if np.any(rms<=0): raise ValueError('Zero background cannot calibrate complex measurements')
    if mode in ('amplitude','amplitude_calibrated'):
        out=np.zeros((12,32,32),np.float32)
        out[:2]=np.abs(qv)*valid;out[4:6]=np.abs(qb)*valid
        diff=np.abs(qv)-np.abs(qb)
        if mode=='amplitude_calibrated': diff=diff*np.abs(qb)/(np.abs(qb)**2+(.01*rms)**2)
        out[8:10]=diff*valid
        return out
    diff=qv-qb
    if mode=='calibrated': diff=diff*qb.conj()/(np.abs(qb)**2+(.01*rms)**2)
    return (np.concatenate((qv.real,qv.imag,qb.real,qb.imag,diff.real,diff.imag))*valid).astype(np.float32)
