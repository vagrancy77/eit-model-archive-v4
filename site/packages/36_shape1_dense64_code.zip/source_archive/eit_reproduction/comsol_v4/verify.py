"""Behavioral checks for checkpoint-contained, label-free native inference."""
import argparse,json,tempfile,contextlib,io
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import DataLoader
from .data_v6 import ComsolDataset,row_case_path,file_hash,measurement_features
from .train import load_checkpoint,device,move,predict,main as train_main
from .infer import voltage_only_batch
from .physics import ReferencePhysics,EPS0


def main():
    p=argparse.ArgumentParser(); p.add_argument('--dataset-root',type=Path,required=True)
    p.add_argument('--checkpoint',type=Path,required=True); p.add_argument('--output',type=Path,required=True)
    p.add_argument('--physics-operator',type=Path)
    p.add_argument('--device',choices=['cuda','cpu','auto'],default='auto'); a=p.parse_args(); dev=device(a.device)
    m,n,phys,c=load_checkpoint(a.checkpoint,dev,a.physics_operator)
    ds=ComsolDataset(a.dataset_root,'val',n,limit=10,physics=phys is not None)
    raw=next(iter(DataLoader(ds,batch_size=10))); batch=move(raw,dev)
    with torch.no_grad(): expected=predict(m,batch,phys)
    single_batch={k:v[:1] for k,v in batch.items()}
    with torch.no_grad(): expected_single=predict(m,single_batch,phys)
    second,_,_,_=load_checkpoint(a.checkpoint,dev,a.physics_operator)
    with torch.no_grad(): reloaded=predict(second,batch,phys)
    for k in expected:
        if not torch.equal(expected[k],reloaded[k]): raise AssertionError('Reload changed prediction '+k)
        if not torch.isfinite(expected[k]).all(): raise AssertionError('Nonfinite output '+k)
    torch.testing.assert_close(expected['probabilities'].sum(1),torch.ones_like(expected['probabilities'][:,0]),atol=1e-6,rtol=0)
    original_path=row_case_path(a.dataset_root,ds.rows[0]); original_hash=file_hash(original_path)
    with np.load(original_path,allow_pickle=False) as z:
        if 'eit_voltage' in z.files:
            payload={k:z[k].copy() for k in ('eit_voltage','eit_background_voltage','eit_delta_voltage','frequencies_hz')}
            voltage,background,delta=payload['eit_voltage'],payload['eit_background_voltage'],payload['eit_delta_voltage']
        else:
            payload={k:z[k].copy() for k in ('voltage','background_voltage','frequencies_hz')}
            voltage,background=payload['voltage'],payload['background_voltage'];delta=voltage-background
    # Temporary files deliberately omit ALL spatial truth/metadata. Inference must still work.
    background_group=['Fat','Muscle'][int(raw['background_group'][0])] if phys is not None else None
    with tempfile.TemporaryDirectory(dir=a.output.parent) as temporary:
        path=Path(temporary)/'voltage_only.npz'; np.savez_compressed(path,**payload)
        inputs=move(voltage_only_batch(path,n,phys,background_group),dev)
        with torch.no_grad(): out=predict(m,inputs,phys)
        for k in ('sigma','eps_r','probabilities','sdf','case_gate'):
            # Compare the same batch size: CUDA kernels may round differently for B=1 vs B=8.
            torch.testing.assert_close(out[k],expected_single[k],atol=0,rtol=0)
        # Irrelevant and even corrupted truth fields must have no effect on model input.
        np.savez_compressed(path,**payload,lesion_mask=np.full((64,64),np.nan),potential_real_V=np.full((2,64,64),1e30))
        other=voltage_only_batch(path,n,phys,background_group)
        if not torch.equal(inputs['features'].cpu(),other['features']): raise AssertionError('Truth/internal potential leakage')
        if phys is not None and not torch.equal(inputs['delta_voltage'].cpu(),other['delta_voltage']): raise AssertionError('Physics truth leakage')
    if original_hash!=file_hash(original_path): raise AssertionError('Source was changed')
    rejected=[]
    def must_reject(name,fn):
        try: fn()
        except (ValueError,FileNotFoundError): rejected.append(name); return
        raise AssertionError('Did not reject '+name)
    must_reject('reversed frequencies',lambda:measurement_features(voltage,background,delta,[50000,10000]))
    must_reject('corrupted delta',lambda:measurement_features(voltage,background,delta+1,[10000,50000]))
    must_reject('wrong voltage table',lambda:measurement_features(voltage[:,:,:31],background,delta,[10000,50000]))
    must_reject('legacy feature shape',lambda:m(torch.zeros((1,1,76,31),device=dev)))
    must_reject('wrong forward frequency',lambda:m(batch['features'],torch.tensor([50000,10000],device=dev)))
    if phys is None:
        must_reject('unconfigured physical input',lambda:m(batch['features'],physical_image=torch.zeros((len(ds),4,64,64),device=dev)))
    else:
        must_reject('missing physical input',lambda:m(batch['features']))
    with contextlib.redirect_stderr(io.StringIO()):
        try:
            train_main(['--dataset-root',str(a.dataset_root),'--output-dir',str(a.output.parent),'--physics-weight','0.1'])
        except SystemExit as error:
            if error.code!=2: raise
            rejected.append('physical loss without actual operator')
        else: raise AssertionError('Missing operator was not rejected')
    if c['args']['smoke'] and c['history'][0]['train']['gradient_norm_before_clip']<=0: raise AssertionError('No training gradient')
    # Software-only check of complex arithmetic and gradients. This is NOT a FEM validation.
    toy=ReferencePhysics.__new__(ReferencePhysics); torch.nn.Module.__init__(toy)
    jac=torch.zeros((2,2,1024,4096),dtype=torch.complex64,device=dev)
    pixel=int(np.flatnonzero(c['fov'].numpy())[100])
    jac[:,:,0,pixel]=1; jac[:,:,1,pixel]=-1
    toy.register_buffer('jacobian',jac)
    toy.register_buffer('background_sigma',torch.full((2,2),.1,device=dev))
    toy.register_buffer('background_eps',torch.full((2,2),10000.,device=dev))
    toy.register_buffer('fov',c['fov'].to(dev).float()[None,None])
    toy.register_buffer('omega_eps0',torch.tensor([10000,50000],device=dev,dtype=torch.float32)[None,:,None,None]*2*np.pi*EPS0)
    sigma=torch.full((1,2,64,64),.12,device=dev,requires_grad=True)
    eps=torch.full((1,2,64,64),12000.,device=dev,requires_grad=True); group=torch.tensor([0],device=dev)
    target=toy.predict_delta(sigma,eps,group)
    torch.testing.assert_close(target[0,:,0,0].real,torch.full((2,),.02,device=dev),atol=1e-7,rtol=1e-6)
    torch.testing.assert_close(target[0,:,0,0].imag,toy.omega_eps0[0,:,0,0]*2000,atol=1e-7,rtol=1e-6)
    residual=toy.loss(sigma,eps,group,target.detach()*.9); residual.backward()
    if not torch.isfinite(sigma.grad).all() or not torch.isfinite(eps.grad).all() or sigma.grad.abs().sum()==0 or eps.grad.abs().sum()==0: raise AssertionError('Complex physics derivative failed')
    if not torch.isfinite(toy.backprojection(target.detach(),group)).all(): raise AssertionError('Complex backprojection failed')
    report={'status':'PASS','device':str(dev),'checkpoint_safe_weights_only_load':True,'reload_prediction_exact':True,
            'input_mode':n.metadata.get('input_mode','native'),'physical_branch':phys is not None,
            'classes_checked':sorted(set(raw['shape_class'])),
            'measurement_only_matches_labeled_inference':True,'corrupted_truth_does_not_change_inputs':True,
            'batch_size_roundoff_max_sigma_difference':float((expected_single['sigma']-expected['sigma'][:1]).abs().max()),
            'original_sample_hash_unchanged':True,'native_output_shapes':{k:list(expected[k].shape) for k in ('sigma','eps_r','probabilities','sdf','case_gate')},
            'rejected_invalid_inputs':rejected,'finite_training_gradients':True,'test_split_used_for_model_selection':False}
    report['optional_physics_math_check']='PASS: synthetic in-memory software fixture only, not a validated real operator'
    a.output.write_text(json.dumps(report,indent=2),encoding='utf-8'); print(json.dumps(report,indent=2),flush=True)


if __name__=='__main__':main()
