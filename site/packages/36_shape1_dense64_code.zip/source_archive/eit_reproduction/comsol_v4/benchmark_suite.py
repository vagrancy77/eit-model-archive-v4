"""Hardware-only training benchmark; discarded weights, training cases only."""
import argparse,json,time,gc
from pathlib import Path
import torch
from torch.utils.data import default_collate
from .data_v6 import ComsolDataset,Normalizer,FINAL_DATASET_ROOT
from .model import V4Comsol
from .losses import compute_loss
from .train import move,seed_all

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    torch.set_num_threads(2)
    norm=Normalizer.load(Path('outputs/final4840_formal_calibrated_seed20261016/normalizer.npz'),FINAL_DATASET_ROOT)
    ds=ComsolDataset(FINAL_DATASET_ROOT,'train',norm)
    items=[ds[i] for i in range(64)]
    report=[]
    for n in (16,32,64):
        seed_all(20261016);model=V4Comsol(ds.fov).cuda();optimizer=torch.optim.AdamW(model.parameters(),lr=4e-4)
        batch=move(default_collate(items[:n]),torch.device('cuda'))
        fov=torch.tensor(ds.fov,dtype=torch.float32,device='cuda')[None,None]
        try:
            torch.cuda.reset_peak_memory_stats();times=[]
            for step in range(8):
                torch.cuda.synchronize();start=time.perf_counter()
                out=model(batch['features'],batch['frequencies_hz']);loss,_=compute_loss(out,batch,fov)
                optimizer.zero_grad(set_to_none=True);loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True);optimizer.step()
                torch.cuda.synchronize();times.append(time.perf_counter()-start)
            report.append({'batch_size':n,'seconds_per_step':sum(times[2:])/6,'peak_allocated_GB':torch.cuda.max_memory_allocated()/1e9})
        except torch.cuda.OutOfMemoryError:
            report.append({'batch_size':n,'out_of_memory':True})
        print(report[-1],flush=True)
        del model,optimizer,batch
        if 'out' in locals():del out,loss
        gc.collect();torch.cuda.empty_cache()
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(report,indent=2),encoding='utf-8')

if __name__=='__main__':main()
