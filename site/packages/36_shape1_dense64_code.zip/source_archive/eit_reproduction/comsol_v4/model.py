"""v4 backbone with native dual-frequency complex measurements and native labels."""
from __future__ import annotations
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from pytorch_eit.topology_residual_net import TopologyResidualEITNet, ResidualBlock


class ComplexVoltageEncoder(nn.Module):
    def __init__(self, base):
        super().__init__()
        self.layers = nn.Sequential(
            ResidualBlock(12, base), nn.Conv2d(base, base*2, 3, 2, 1),
            ResidualBlock(base*2, base*2), nn.Conv2d(base*2, base*4, 3, 2, 1),
            ResidualBlock(base*4, base*4), nn.Conv2d(base*4, base*8, 3, 2, 1),
            ResidualBlock(base*8, base*8), nn.Conv2d(base*8, base*16, 1))

    def forward(self, features):
        return self.layers(features)


class V4Comsol(TopologyResidualEITNet):
    """Inherited v4 spatial/topology decoders and risk gates, NOT a v6 corrector.

    The learned lift is not a FEM inverse or a Jacobian. No truth tensor enters forward.
    """
    def __init__(self, fov_mask, base=28, propagation_steps=14, physics_input=False, ablation='full'):
        super().__init__(fov_mask, base=base, propagation_steps=propagation_steps, risk_aware=True)
        if ablation not in ('full','no_topology','no_risk'): raise ValueError('Unknown ablation')
        self.ablation=ablation
        self.voltage_encoder = ComplexVoltageEncoder(base)
        self.physics_input=physics_input
        if physics_input:
            self.physics_projection=nn.Sequential(nn.Conv2d(4,8,3,padding=1),nn.SiLU(),nn.Conv2d(8,1,3,padding=1))
        self.learned_lift = nn.Sequential(nn.Flatten(), nn.Linear(12*32*32, 16*16),
                                          nn.Unflatten(1, (1, 16, 16)), nn.Upsample(size=(64, 64), mode='bilinear', align_corners=False),
                                          nn.Conv2d(1, 8, 3, padding=1), nn.SiLU(), nn.Conv2d(8, 1, 3, padding=1))
        del self.delta_head  # Replaced, not silently reused as a single-frequency KTC contrast.
        self.material_head = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 4, 1))
        self.background_head = nn.Linear(base*16, 4)
        with torch.no_grad():
            self.material_head[-1].bias.copy_(torch.tensor([-2.252168, -2.252168, .541325, .541325]))
            self.background_head.bias.copy_(torch.tensor([-2.252168, -2.252168, .541325, .541325]))
        self.register_buffer('frequencies_hz', torch.tensor([10000., 50000.]))

    def forward(self, features, frequencies_hz=None, physical_image=None):
        if features.ndim != 4 or tuple(features.shape[1:]) != (12, 32, 32):
            raise ValueError('V4Comsol expects normalized [batch,12,32,32] measurement features')
        if frequencies_hz is not None and (frequencies_hz.shape not in ((2,),(len(features),2)) or not torch.all(frequencies_hz == self.frequencies_hz)):
            raise ValueError('Expected ordered frequencies 10 kHz and 50 kHz')
        image = self.learned_lift(features) * self.fov_mask
        if self.physics_input:
            if physical_image is None or physical_image.shape!=(len(features),4,64,64):
                raise ValueError('This checkpoint requires the matched physical backprojection')
            image = image+self.physics_projection(physical_image)*self.fov_mask
        elif physical_image is not None:
            raise ValueError('Physical input not configured in this model')
        adapted = self.adapter(image)
        e0 = self.stem(adapted)
        e1 = self.enc1(F.max_pool2d(e0, 2))
        e2 = self.enc2(F.max_pool2d(e1, 2))
        e3 = self.enc3(F.max_pool2d(e2, 2))
        latent = self.fusion(torch.cat((self.bottleneck(F.max_pool2d(e3, 2)), self.voltage_encoder(features)), 1))
        base_features = self._decode_base(latent, e3, e2, e1, e0)
        raw_logits = self.base_logits_head(base_features)
        # Dataset-native SDF: negative INSIDE, distance / 64. Change MODEL bias, not targets.
        sdf = torch.tanh(self.sdf_head(base_features)) * self.fov_mask
        geometry_bias = -1.20 * sdf
        base_logits = torch.cat((raw_logits[:, :1]-geometry_bias, raw_logits[:, 1:]+.5*geometry_bias), 1)
        base_prob = torch.softmax(base_logits, 1)
        foreground = base_prob[:, 1:].sum(1, keepdim=True) * self.fov_mask
        topo = self._decode_topology(latent, e3, e2, e1, e0)
        topo = self.topology_fusion(torch.cat((topo, foreground.detach(), sdf.detach()), 1))
        cutout_logit, mouth_logit = self.cutout_head(topo), self.mouth_head(topo)
        cutout = torch.sigmoid(cutout_logit) * self.fov_mask
        mouth = torch.sigmoid(mouth_logit) * self.fov_mask
        local_gate = torch.sigmoid(self.local_gate_head(topo))
        class_gate_logit = self.case_gate_head(latent)
        class_gate = torch.sigmoid(class_gate_logit)[:, :, None, None]
        # mouth is the supplied SIDEWALL-band label, NOT an exterior-opening seed.
        # Keep v4's soft reachability from predicted background only; not a hard guarantee.
        reachable = cutout * (1. - foreground).detach()
        for _ in range(self.propagation_steps):
            reachable = torch.maximum(reachable, F.max_pool2d(reachable, 3, 1, 1) * cutout)
        connected = cutout * reachable.clamp_min(1e-6).sqrt()
        proposal = connected * local_gate
        entropy = -(base_prob * base_prob.clamp_min(1e-7).log()).sum(1, keepdim=True)
        statistic_maps = (cutout, mouth, connected, proposal, entropy)
        statistics = torch.cat(tuple(v.mean((2, 3)) for v in statistic_maps) + tuple(v.amax((2, 3)) for v in statistic_maps), 1)
        pooled = latent.mean((2, 3))
        action_gate_logit = self.action_gate_head(torch.cat((pooled, statistics), 1))
        action_gate = torch.sigmoid(action_gate_logit)[:, :, None, None]
        effective = proposal * class_gate * action_gate
        applied_gate = class_gate * action_gate
        if self.ablation=='no_risk':
            applied_gate = torch.ones_like(applied_gate)
            effective = proposal
        elif self.ablation=='no_topology':
            applied_gate = torch.zeros_like(applied_gate)
            effective = torch.zeros_like(proposal)
        final_fg = (foreground * (1-.98*effective)).clamp(1e-7, 1-1e-7) * self.fov_mask
        proposal_fg = (foreground * (1-.98*proposal)).clamp(1e-7, 1-1e-7) * self.fov_mask
        conditional = base_prob[:, 1:] / base_prob[:, 1:].sum(1, keepdim=True).clamp_min(1e-7)
        probs = torch.cat((1-final_fg, final_fg*conditional), 1)
        proposal_probs = torch.cat((1-proposal_fg, proposal_fg*conditional), 1)
        raw_material = self.material_head(base_features)
        raw_background = self.background_head(pooled)[:, :, None, None]
        lesion_sigma = F.softplus(raw_material[:, :2]) + 1e-6
        background_sigma = F.softplus(raw_background[:, :2]) + 1e-6
        lesion_eps = (F.softplus(raw_material[:, 2:]) + 1e-6) * 10000.
        background_eps = (F.softplus(raw_background[:, 2:]) + 1e-6) * 10000.
        sigma = (background_sigma + final_fg*(lesion_sigma-background_sigma)) * self.fov_mask
        eps = (background_eps + final_fg*(lesion_eps-background_eps)) * self.fov_mask
        return {'learned_image': image, 'base_logits': base_logits, 'base_probabilities': base_prob,
                'base_foreground_probability': foreground, 'sdf': sdf, 'cutout_logit': cutout_logit,
                'raw_cutout_probability': cutout, 'mouth_logit': mouth_logit, 'mouth_probability': mouth,
                'connected_cutout_probability': connected, 'proposal_cutout_probability': proposal,
                'effective_cutout_probability': effective, 'foreground_probability': final_fg,
                'probabilities': probs, 'logits': probs.clamp_min(1e-7).log(), 'proposal_probabilities': proposal_probs,
                'class_gate_logit': class_gate_logit, 'class_gate': class_gate, 'action_gate_logit': action_gate_logit,
                'action_gate': action_gate, 'case_gate': applied_gate, 'sigma': sigma, 'eps_r': eps,
                'background_sigma': background_sigma, 'background_eps_r': background_eps,
                'delta_sigma': (sigma-background_sigma)*self.fov_mask}
