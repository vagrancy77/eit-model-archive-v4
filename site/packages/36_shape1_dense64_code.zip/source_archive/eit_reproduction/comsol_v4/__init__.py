"""Dataset-native COMSOL adaptation of v4; the historical v4 is unchanged."""

FORMAT_VERSION = "v4-comsol-native-v2"
