"""Strict interface for a separately delivered complex, homogeneous-reference Jacobian.

The optional matrix comes from the separately imported V4 model package, not
from dataset labels or the dataset's verification report. Final-release conversion
records background mesh discrepancies; this remains a homogeneous linearization.
"""
import json
import numpy as np
import torch
from torch import nn
from .data_v6 import file_hash, FREQUENCIES

EPS0 = 8.8541878128e-12


class ReferencePhysics(nn.Module):
    """Linearized deltaV = J_gamma @ (sigma-sigma0 + i*omega*eps0*(epsr-epsr0))."""
    def __init__(self, path, fov, x, y):
        super().__init__()
        with np.load(path, allow_pickle=False) as z:
            meta = json.loads(z['metadata_json'].item())
            required = {'format': 'comsol_v4_reference_jacobian_v1',
                        'boundary_model': 'current_terminal_no_effective_contact_impedance',
                        'axis_order': 'group,frequency,drive,electrode,pixel_yx',
                        'derivative': 'dV_dgamma', 'voltage_reference': 'injection_return',
                        'gamma_convention': 'sigma_plus_jomega_eps0_epsr'}
            for k, value in required.items():
                if meta.get(k) != value: raise ValueError(f'Unsupported physical operator {k}: {meta.get(k)}')
            if meta.get('validation_status') != 'PASS' or meta.get('kind') != 'FEM_adjoint':
                raise ValueError('A validated FEM adjoint matrix is required; empirical regressions are not accepted')
            if meta.get('current_A') != .00025 or meta.get('radius_m') != .05:
                raise ValueError('Physical operator current/domain does not match this dataset')
            if not np.array_equal(z['frequencies_hz'], FREQUENCIES) or not np.array_equal(z['valid_mask'], fov):
                raise ValueError('Physics frequency/FOV mismatch')
            if not np.array_equal(z['x'], x) or not np.array_equal(z['y'], y):
                raise ValueError('Physics coordinates differ; no implicit transpose or interpolation')
            self.group_names = z['group_names'].tolist()
            if self.group_names != ['Fat', 'Muscle']: raise ValueError('Expected ordered Fat/Muscle references')
            jac = z['jacobian_gamma']
            if jac.shape != (2, 2, 32, 32, 4096) or not np.iscomplexobj(jac) or not np.isfinite(jac).all():
                raise ValueError('Invalid complex Jacobian dimensions/data')
            sb, eb = z['background_sigma'], z['background_eps_r']
            if sb.shape != (2,2) or eb.shape != (2,2) or not np.all(sb>0) or not np.all(eb>0):
                raise ValueError('Invalid reference material arrays')
            # Convert the reference used by the generator to our gauge-independent measurement space.
            jac = jac-jac.mean(axis=3,keepdims=True)
            self.register_buffer('jacobian', torch.from_numpy(jac.reshape(2,2,1024,4096).astype(np.complex64)))
            self.register_buffer('background_sigma', torch.from_numpy(sb.astype(np.float32)))
            self.register_buffer('background_eps', torch.from_numpy(eb.astype(np.float32)))
        self.register_buffer('fov', torch.from_numpy(np.asarray(fov,dtype=np.float32))[None,None])
        self.register_buffer('omega_eps0', torch.tensor(FREQUENCIES*2*np.pi*EPS0,dtype=torch.float32)[None,:,None,None])
        self.metadata = {**meta, 'operator_sha256':file_hash(path), 'approximation':'homogeneous-background first-order; not nonlinear FEM'}

    def predict_delta(self, sigma, eps, group):
        sb = self.background_sigma[group][:,:,None,None]
        eb = self.background_eps[group][:,:,None,None]
        dg = torch.complex((sigma-sb)*self.fov, (eps-eb)*self.omega_eps0*self.fov).flatten(2)
        outputs = []
        for i in range(len(sigma)):
            outputs.append(torch.einsum('fmp,fp->fm',self.jacobian[group[i]],dg[i]))
        return torch.stack(outputs).reshape(-1,2,32,32)

    def loss(self, sigma, eps, group, delta):
        predicted = self.predict_delta(sigma,eps,group)
        measured = delta-delta.mean(dim=-1,keepdim=True)
        mse = (predicted-measured).abs().square().mean(dim=(-1,-2))
        scale = measured.abs().square().mean(dim=(-1,-2)).clamp_min(1e-16)
        return (mse/scale).mean()

    @torch.no_grad()
    def backprojection(self, delta, group):
        measured = (delta-delta.mean(dim=-1,keepdim=True)).flatten(2)
        values = []
        for i in range(len(delta)):
            jac = self.jacobian[group[i]]
            raw = torch.einsum('fmp,fm->fp',jac.conj(),measured[i])
            raw /= jac.abs().square().sum(dim=1).clamp_min(1e-16).sqrt()
            values.append(raw.reshape(2,64,64))
        raw = torch.stack(values)
        image = torch.cat((raw.real,raw.imag),dim=1)*self.fov
        scale=image.abs().flatten(2).quantile(.99,dim=2)[:,:,None,None].clamp_min(1e-12)
        return (image/scale).clamp(-5,5)
