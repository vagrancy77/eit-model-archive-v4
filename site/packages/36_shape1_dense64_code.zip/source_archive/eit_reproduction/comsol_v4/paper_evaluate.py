"""Freeze every validation-selected checkpoint before reading test tensors."""
import argparse,json
from pathlib import Path
import torch
from .paper_common import load_protocol,write_json
from .data_v6 import FINAL_DATASET_ROOT,file_hash
from .infer import main as infer

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);a=ap.parse_args();root=a.root.resolve()
    p,phash=load_protocol(root);torch.set_num_threads(2);runs=[]
    for variant in p['variants']:
        for seed in p['seeds']:
            name=f'{variant}_seed{seed}';folder=root/'runs'/name
            done=json.loads((folder/'complete.json').read_text(encoding='utf-8'))
            digest=file_hash(folder/'best.pt')
            if done['protocol_sha256']!=phash or done['best_checkpoint_sha256']!=digest:raise ValueError('Checkpoint/protocol changed')
            runs.append({'name':name,'checkpoint_sha256':digest,**done})
    for seed in p['seeds']:
        if len({r['initial_state_sha256'] for r in runs if r['seed']==seed})!=1:raise ValueError('Variant initializations differ')
    frozen={'protocol_sha256':phash,'runs':runs,'prior_exploratory_test_seen':True,'suite_test_used_for_selection':False}
    dest=root/'frozen_evaluation.json'
    if dest.exists() and json.loads(dest.read_text(encoding='utf-8'))!=frozen:raise ValueError('Frozen models changed')
    write_json(dest,frozen)
    for run in runs:
        out=root/'evaluations'/run['name'];checkpoint=root/'runs'/run['name']/'best.pt'
        if (out/'predictions.json').exists():
            old=json.loads((out/'predictions.json').read_text(encoding='utf-8'))
            if old['checkpoint_sha256']!=run['checkpoint_sha256'] or old['case_count']!=720:raise ValueError('Evaluation provenance changed')
            if not all((out/(cid+'.npz')).exists() for cid in old['case_ids']):raise ValueError('Missing predictions')
            continue
        if out.exists() and any(out.iterdir()):
            # Preserve interrupted output before regenerating the same frozen inference.
            k=1
            while out.with_name(out.name+f'_interrupted_{k}').exists():k+=1
            out.rename(out.with_name(out.name+f'_interrupted_{k}'))
        infer(['--checkpoint',str(checkpoint),'--dataset-root',str(FINAL_DATASET_ROOT),'--split','test','--evaluate',
               '--device','cuda','--batch-size',str(p['batch_size']),'--canonical-order','--output-dir',str(out)])
        torch.cuda.empty_cache()
    print('All 18 test evaluations complete',flush=True)

if __name__=='__main__':main()
