# 公开数据与超声-EIT融合说明

## 资料核验结论

目前能直接支持本工程的公开数据分成三类，不能混为一种“真实配对训练集”。

| 数据 | 公开内容 | 适合用途 | 重要限制 |
|---|---|---|---|
| [Sagar 2026 US-EIT Zenodo](https://zenodo.org/records/19558489), DOI [10.5281/zenodo.19558489](https://doi.org/10.5281/zenodo.19558489) | 鸡肉分层 phantom；16 电极；每组 208 个 CSV 测量；12 个频率/电压/层厚组合；作者 GN/Tikhonov/BP/GREIT/EIDORS 重建、FEM 模型和一张原始超声图；CC BY 4.0 | 真实 EIT 域适配、协议核对、超声输入接口和论文级可视化 | 只有一张共享超声图，不是 12 张逐帧配准 US 图；GN 重建是伪标签，不是独立电导率真值；样本量不足以训练 7M 参数网络 |
| [KTC2023 v3](https://zenodo.org/records/10986692), DOI [10.5281/zenodo.10986692](https://doi.org/10.5281/zenodo.10986692) | UEF 水槽 phantom；训练 phantom、完整/受限测量、校正后的 ground-truth 图像；Matlab 和 Python 代码；CC BY 4.0 | 真实 EIT 单模态基准、跨协议测试和后续域适配 | 没有同步超声 |
| [UEF/KIT4 2D EIT](https://doi.org/10.5281/zenodo.1203914) | 盐水圆槽、导电/绝缘 inclusion 的电流电压和照片；MATLAB 读取代码；CC BY 4.0 | 真实水槽外部验证 | 照片不是超声，协议和几何与本工程 CEM 不同 |
| [Breast Ultrasound Image](https://data.mendeley.com/datasets/wmy84gzngw/1), DOI [10.17632/wmy84gzngw.1](https://doi.org/10.17632/wmy84gzngw.1) | 250 张乳腺 B-mode 图（100 benign、150 malignant）；CC BY 4.0 | 单独预训练超声 encoder、纹理/分类/分割辅助头 | 与 EIT 不配对，不能直接按样本拼接训练 |

检索到的超声先验 EIT 论文（例如 2006 年的 *Electrical impedance tomography imaging using a priori ultrasound information*）证明了融合思路，但论文并没有提供可直接训练的大规模、逐样本、空间配准 US-EIT 数据。Sagar 数据是目前核验到的最接近该需求、且可公开下载的实验数据。

## 本工程已经下载和解析的文件

```text
datasets/public_us_eit/Supplementary_Files.zip
datasets/public_us_eit/raw/                          # 解压后的作者文件
datasets/public_us_eit/public_us_eit_v1.npz          # 解析后的 12 组真实数据
datasets/public_us_eit/public_us_eit_v1.json
```

压缩包 MD5 为 `22e96c2dc08794381ea62e35c7fc2951`，与 Zenodo 页面一致。解析后的真实 NPZ 包含：

- `voltage_features`：12×416，按每个样本保存 208 个实部和 208 个虚部（按 Vpp 归一化前的原始 CSV 通道）；
- `baseline_tikhonov`：作者 Tikhonov 差分重建加背景 1；
- `pseudo_target_gn`：作者 GN 差分重建加背景 1，仅作为伪标签/域适配参考；
- `ultrasound`：裁剪、归一化到 64×64 的原始超声图，12 个样本共享同一张图；
- `metadata_json`：层号、频率和激励电压。

## 训练数据和网络

由于真实配对样本太少，训练主线使用已有的 1024 例非线性 CEM 模拟数据。每个电导率 phantom 通过确定性代理渲染器生成一个几何一致的 B-mode 风格图：电导率界面产生回波、加入深度衰减和 speckle。这个代理图只用于开发和预训练，不能声称是真实声学仿真。

网络在 `pytorch_eit/models.py` 中实现，输入为：

```text
208 维电压特征 ── VoltageConditioner/FiLM ──────────────┐
物理 CEM/Tikhonov 图 ── Residual U-Net 编码器 ────────────┼─ 多尺度门控融合 ── 瓶颈 Cross-Attention ── 解码器 ── 电导率图
超声图像 ───────────── Ultrasound U-Net 编码器 ──────────┘
```

实现的复杂结构包括：残差卷积块、Squeeze-Excitation、双分支 U-Net、多尺度空间门控、瓶颈多头 cross-attention、原始电压 MLP 条件化、模态 dropout、正值/上界约束和辅助 inclusion segmentation head。将 `ultrasound_available` 设为 0 或传入 `ultrasound=None`，同一权重即可退化为 EIT-only 推理。

## 可复现实验结果

正式训练产物在 `outputs_pytorch_multimodal/`：

```text
参数量                         6,929,432
GPU                            CUDA
合成测试集相关系数 EIT-only    0.9711
合成测试集相关系数 US-EIT      0.9746
合成测试集相对 L2 EIT-only     0.1167
合成测试集相对 L2 US-EIT       0.1093
```

对公开 12 组真实实验数据的结果在 `outputs_public_us_eit/summary.json`。由于公开 GN 只是伪标签，结果只能作为域适配证据：

```text
与公开 GN 伪标签的相关系数 EIT-only  0.5570
与公开 GN 伪标签的相关系数 US-EIT     0.6180
```

## 后续获得真正 US-EIT 配对数据后的替换方式

1. 可先用 [Breast Ultrasound Image](https://data.mendeley.com/datasets/wmy84gzngw/1) 训练超声 encoder 的纹理/分割能力；这一步不接 EIT 标签。
2. 将每次 EIT 帧对应的原始 RF/B-mode 图注册到 EIT 圆域，生成 `N×1×H×W`；不要重复使用一张与帧无关的超声图。
3. 保持 `voltage_features`、`baseline_grid`、`target_grid`、`ultrasound_grid` 的同一索引。
4. 用真实 US 图替换 `ultrasound_grid`，保留 `ultrasound_available` 的缺失模态训练。
5. 若有组织分割或层界面标注，将其作为 segmentation head 的监督；若只有 EIT 真值，关闭该辅助项即可。
6. 若 EIT 协议变化（电极数、激励、测量顺序、接触阻抗），重新计算物理 Jacobian/重建算子并重新训练 voltage conditioner，不要直接加载当前权重当作临床模型。
