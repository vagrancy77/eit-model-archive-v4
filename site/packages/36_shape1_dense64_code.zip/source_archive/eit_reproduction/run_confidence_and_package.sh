#!/usr/bin/env bash
set -euo pipefail

source ~/miniforge3/etc/profile.d/conda.sh
conda activate gn4ip-env
cd /mnt/e/Codex/eit_reproduction

python evaluate_confidence_reliability.py \
  --data datasets/multimodal_cem_v2.npz \
  --checkpoint outputs_registration_robust_multimodal_warmstart/model.pt \
  --output-dir outputs_confidence_reliability \
  --split test \
  --batch-size 48

python build_paper_package.py \
  --output-dir paper_final_package \
  --robust outputs_registration_robust_multimodal_warmstart \
  --multiseed outputs_registration_robust_multimodal_multiseed \
  --crossdomain outputs_registration_robust_crossdomain \
  --stress outputs_registration_robust_stress \
  --bootstrap outputs_registration_robust_bootstrap \
  --confidence outputs_confidence_reliability \
  --public-real outputs_public_us_eit_robust \
  --no-registration outputs_registration_ablation_no_registration \
  --no-confidence outputs_registration_ablation_no_confidence
