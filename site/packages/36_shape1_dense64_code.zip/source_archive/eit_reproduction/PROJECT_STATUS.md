# 工程交付状态

## 已完成

- [x] 16 电极、208 测量的相邻协议
- [x] 正问题细网格与逆问题粗网格
- [x] 心肺幻影和随机多异常幻影
- [x] 点电极模型对照
- [x] 有限宽度电极 CEM
- [x] 接触阻抗
- [x] SciPy 手工有限元装配
- [x] FEniCSX/UFL 有限元装配
- [x] 后端电压与 Jacobian 交叉验证
- [x] 精确 SNR 噪声
- [x] 互易伴随 Jacobian
- [x] 线性 Tikhonov/NOSER 重建
- [x] 非线性绝对 EIT
- [x] Gauss–Newton / LM
- [x] 对数电导率正值约束
- [x] 电导率上下界
- [x] TV-IRLS
- [x] 回溯线搜索和自动停止
- [x] 批量非线性 CEM 数据集
- [x] 固定训练/验证/测试划分
- [x] 物理重建 + 残差 MLP
- [x] 模型保存、加载和单帧推理
- [x] CSV/NPY/NPZ 测量接口
- [x] 数值图、训练曲线和评价指标
- [x] Windows 测试与 WSL FEniCSX 测试
- [x] 一键流程、制品校验和 SHA-256 清单
- [x] 公开 GN4IP 代码、训练集、测试集和预训练权重
- [x] 作者 Conv U-Net 输出机器精度复现
- [x] 公开训练代码短训练验证
- [x] 当前 CEM 数据到 GN4IP 格式适配
- [x] 公开 Conv U-Net 在当前 CEM 独立测试集上训练与评估

## 需要外部条件，不能由软件自动补出的部分

- [ ] 真实 EIT 硬件及其驱动
- [ ] 设备电流、电压增益、相位和通道标定
- [ ] 与设备一致的真实电极位置和接触阻抗
- [ ] 真实背景参考帧和同步标签
- [ ] 患者/志愿者数据及伦理许可
- [ ] 临床评价和跨设备验证

工程已经提供真实测量文件入口，但不会伪造这些数据或假定当前模拟模型可以直接用于临床。

## 可选研究扩展，不属于当前二维完整闭环的缺陷

- 三维胸腔和器官网格；
- 复数电导率与多频 EIT；
- 电极位置/接触阻抗联合反演；
- U-Net、图 U-Net、Transformer 或扩散模型；
- UEF2017、KTC2023 等真实公开数据域适配；
- 不确定性量化和实时硬件部署。
## 2026-07-27：公开数据与多模态 PyTorch 阶段

- [x] 核验并下载 Zenodo 10.5281/zenodo.19558489 真实 US-EIT 数据（39.8 MB，MD5 已校验）
- [x] 解压和解析 12 个 208 通道 CSV、作者 GN/Tikhonov 重建、FEM 文件和共享超声图
- [x] 生成 `datasets/multimodal_cem_v1.npz`（1024 例 CEM + 几何一致超声代理）
- [x] 实现约 693 万参数 PyTorch 双分支、多尺度门控、cross-attention、FiLM、模态 dropout 网络
- [x] CUDA 20 epoch 正式训练，保存 checkpoint、历史曲线、测试重建图和指标
- [x] 真实公开数据推理和 EIT-only/US-EIT ablation
- [x] 新增 `scripts/validate_pytorch_multimodal.py` 和 PyTorch 单元测试

当前真实数据的边界：公开数据不是 12 个严格逐帧 US-EIT 对。只有一张共享超声图，作者 GN 结果为伪标签。因此当前网络的定量训练指标来自合成 CEM 数据，真实数据指标仅用于域适配证据，不能解释成临床真值精度。

## 2026-07-29：Edinburgh 四频真值与共享几何实验

- [x] 核验 Edinburgh mfEIT Dataset、论文、DOI 和 CC BY 4.0 许可
- [x] 下载并 CRC 验证 47,576,486 字节官方数据包
- [x] 解压 12,414 个四频电压/电导率真值 phantom
- [x] 逐一验证全部样本的病灶支持区域跨频完全共享
- [x] 建立固定 8700/1900/1814 划分及训练集归一化统计
- [x] 实现严格单频、频率条件化、普通联合和共享几何分解四种 PyTorch 模型
- [x] 修正有限样本截取偏差，按 1/2/3 病灶比例完成 2048/512/512 分层 pilot
- [x] 完成三随机种子与按 512 个独立 phantom 的配对 bootstrap
- [x] 共享几何模型显著改善定位、轮廓、背景抑制和跨频一致性
- [x] 确认当前简单乘法分解使病灶内部对比度 MAE 变差约 5.3%
- [ ] 增加病灶级频谱校准分支，修复结构改善与强度定量之间的权衡
- [ ] 使用完整 8700 训练样本与至少 5 个随机种子完成正式实验
- [ ] 生成有明确 10/50 kHz 和接触阻抗的 CEM 补充集做 forward-model shift
- [ ] 将 6 个公开 10/50 kHz 实体样本接入协议适配器做域外验证

当前关键边界：Edinburgh 的四个通道只标为 `f1`--`f4`，没有公开实际 kHz；它是 COMSOL 仿真而非临床数据。详见 `EDINBURGH_MFEIT_EXPERIMENT.md`。

## 2026-08-03：不确定性感知超声先验鲁棒网络

- [x] 新增受限仿射超声—EIT 配准模块
- [x] 新增多尺度 confidence gate 和 EIT fallback
- [x] 训练时加入平移、旋转、模糊、假病灶和 modality dropout
- [x] baseline warm-start 正式训练（20 epochs，24 channels）
- [x] 三随机种子统计、误差棒图和测试样本重建图
- [x] registration-only / confidence-only 机制消融
- [x] 生成 `REGISTRATION_ROBUST_MULTIMODAL_NETWORK.md`
- [x] 生成 confidence reliability / risk-coverage / AUROC 分析
- [x] 生成最终论文包 `paper_final_package/FINAL_PAPER_PACKAGE.md`

当前 pilot 结论：在 1024 例 CEM + 几何一致超声 proxy 上，受损超声条件的平均 relative L2 从 0.10872 降到 0.10617，MAE 从 0.04268 降到 0.03611；主要收益来自 confidence-aware fallback。超声仍是合成 proxy，尚不能替代真实配准超声数据验证。

公开 12 例 US-EIT 域外检查也已完成：鲁棒 fusion 对作者 GN pseudo-label 的 correlation 为 0.608，而已有 baseline 为 0.618。该结果确认当前主要瓶颈是 CEM/真实设备域差异，不能把合成数据提升直接解释成临床提升。

- [x] 生成独立随机种子 CEM v2（2048 例）并完成 cross-domain 测试
- [x] 完成 0–20 px 平移、0–20° 旋转和多级模糊连续应力曲线
- [x] 形成完整论文初稿 `PAPER_DRAFT_UNCERTAINTY_AWARE_US_EIT.md`
- [x] 完成 v2 测试 phantom 的配对 bootstrap 95% 置信区间统计

## 2026-08-03：v3 独立测试闭环完成

- [x] 重新生成完全独立的 v3 CEM 测试集
- [x] 扩展病灶形状、数量、位置和噪声等级
- [x] 增加更大范围配准误差、局部形变和超声缺失
- [x] 在同一测试集统一比较 EIT-only、baseline、硬约束、软约束和鲁棒模型
- [x] 完成多随机种子与 bootstrap 统计
- [x] 完成 confidence map 可靠性分析
- [x] 更新论文草稿到 v3 最终结果
- [x] 重写最终 paper package 为独立 v3 版本

当前最终结论：robust 模型在独立 v3 测试集上更稳定，尤其在受损先验下 MAE 更低；confidence map 只能作为 weak prior-reliability gate，不能被当成已充分校准的不确定性估计。
