"""Plot a fixed mfEIT phantom and its lesion-level spectral curves."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch

from evaluate_edinburgh_instance_spectra import forward, load_model
from train_edinburgh_mfeit import EdinburghDataset


def main() -> None:
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Plot joint, factorized and instance-dispersion mfEIT reconstructions.")
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "datasets" / "public" / "edinburgh_mfeit" / "edinburgh_mfeit_manifest_v1.npz",
    )
    parser.add_argument("--joint", type=Path, required=True)
    parser.add_argument("--factorized", type=Path, required=True)
    parser.add_argument("--instance-dispersion", type=Path, required=True)
    parser.add_argument("--case", type=int, default=3)
    parser.add_argument("--sample-index", type=int, default=None)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--cpu", action="store_true")
    arguments = parser.parse_args()

    manifest = np.load(arguments.manifest)
    source = Path(str(np.asarray(manifest["source_root"]).reshape(()).item()))
    cases = np.asarray(manifest["test_case"], dtype=np.int8)
    indices = np.asarray(manifest["test_index"], dtype=np.int64)
    candidates = np.flatnonzero(cases == arguments.case)
    if not len(candidates):
        raise ValueError(f"no test phantom for case {arguments.case}")
    if arguments.sample_index is None:
        position = int(candidates[0])
    else:
        matches = np.flatnonzero(np.logical_and(cases == arguments.case, indices == arguments.sample_index))
        if not len(matches):
            raise ValueError(f"sample {arguments.sample_index} is not in the case-{arguments.case} test split")
        position = int(matches[0])
    case = int(cases[position])
    sample_index = int(indices[position])
    mean = np.asarray(manifest["voltage_mean"], dtype=np.float32)
    std = np.asarray(manifest["voltage_std"], dtype=np.float32)
    voltage = np.array(np.load(source / f"V{case}.npy", mmap_mode="r")[sample_index], dtype=np.float32, copy=True)
    target = np.clip(
        -np.array(np.load(source / f"img{case}.npy", mmap_mode="r")[sample_index], dtype=np.float32, copy=True).reshape(4, 64, 64),
        0.0,
        1.0,
    )
    voltage = (voltage - mean[None]) / std[None]
    device = torch.device("cpu" if arguments.cpu or not torch.cuda.is_available() else "cuda")
    models = dict(
        load_model(path, device)
        for path in (arguments.joint, arguments.factorized, arguments.instance_dispersion)
    )
    coordinate = torch.arange(1, 5, dtype=torch.float32, device=device)[None]
    voltage_tensor = torch.from_numpy(voltage)[None].to(device)
    reconstructions: dict[str, np.ndarray] = {}
    instance_masks: np.ndarray | None = None
    with torch.no_grad():
        for name, model in models.items():
            reconstruction, auxiliary = forward(name, model, voltage_tensor, coordinate)
            reconstructions[name] = reconstruction[0, :, 0].cpu().numpy()
            if name == "instance_dispersion" and auxiliary is not None:
                instance_masks = auxiliary["instance_masks"][0].cpu().numpy()

    arguments.output_dir.mkdir(parents=True, exist_ok=True)
    rows = [("Ground truth", target), ("Joint", reconstructions["joint"]), ("Factorized", reconstructions["factorized"]), ("Instance dispersion", reconstructions["instance_dispersion"])]
    figure, axes = plt.subplots(5, 4, figsize=(12, 14), constrained_layout=True)
    for row, (label, images) in enumerate(rows):
        for frequency in range(4):
            axes[row, frequency].imshow(images[frequency], vmin=0.0, vmax=1.0, cmap="viridis")
            axes[row, frequency].set_title(f"{label}: f{frequency + 1}")
            axes[row, frequency].axis("off")
    for slot in range(3):
        axes[4, slot].imshow(instance_masks[slot] if instance_masks is not None else np.zeros((64, 64)), vmin=0.0, vmax=1.0, cmap="magma")
        axes[4, slot].set_title(f"Predicted instance mask {slot + 1}")
        axes[4, slot].axis("off")
    axes[4, 3].axis("off")
    figure.suptitle(f"Edinburgh mfEIT: {case} lesions, sample {sample_index}", fontsize=16)
    image_path = arguments.output_dir / f"case_{case}_sample_{sample_index}_comparison.png"
    figure.savefig(image_path, dpi=180)
    plt.close(figure)

    target_masks, target_spectra, valid = EdinburghDataset.instance_targets(target)
    figure, axes = plt.subplots(1, int(valid.sum()), figsize=(4.5 * int(valid.sum()), 3.8), sharey=True, constrained_layout=True)
    axes = np.atleast_1d(axes)
    colours = {"joint": "tab:blue", "factorized": "tab:orange", "instance_dispersion": "tab:red"}
    for slot, axis in enumerate(axes):
        lesion = target_masks[slot].astype(bool)
        axis.plot(range(1, 5), target_spectra[slot], marker="o", color="black", label="Ground truth")
        for name, reconstruction in reconstructions.items():
            curve = reconstruction[:, lesion].mean(axis=1)
            axis.plot(range(1, 5), curve, marker="o", color=colours[name], label=name.replace("_", " "))
        axis.set_title(f"Lesion {slot + 1}")
        axis.set_xlabel("Frequency channel")
        axis.set_xticks(range(1, 5))
        axis.set_ylim(0.0, 1.0)
        axis.grid(alpha=0.25)
    axes[0].set_ylabel("Normalized anomaly magnitude")
    axes[0].legend(fontsize=8)
    spectrum_path = arguments.output_dir / f"case_{case}_sample_{sample_index}_spectra.png"
    figure.savefig(spectrum_path, dpi=180)
    plt.close(figure)
    print(image_path)
    print(spectrum_path)


if __name__ == "__main__":
    main()
