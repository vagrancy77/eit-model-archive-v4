from __future__ import annotations

import argparse
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from pytorch_eit.data import MultimodalCEMDataset
from pytorch_eit.models import MultiModalEITNet, RegistrationRobustMultiModalEITNet
from train_registration_robust_multimodal import corrupt_ultrasound


def main() -> None:
    parser = argparse.ArgumentParser(description="Plot baseline/robust EIT reconstructions under US corruption.")
    parser.add_argument("--data", type=Path, default=ROOT / "datasets" / "multimodal_cem_v1.npz")
    parser.add_argument("--baseline", type=Path, default=ROOT / "outputs_pytorch_multimodal" / "model.pt")
    parser.add_argument("--robust", type=Path, default=ROOT / "outputs_registration_robust_multimodal_warmstart" / "model.pt")
    parser.add_argument("--output", type=Path, default=ROOT / "outputs_registration_robust_multimodal_warmstart" / "examples_comparison.png")
    parser.add_argument("--base-channels", type=int, default=24)
    parser.add_argument("--sample", type=int, default=0)
    parser.add_argument("--cpu", action="store_true")
    args = parser.parse_args()

    device = torch.device("cpu" if args.cpu or not torch.cuda.is_available() else "cuda")
    data = np.load(args.data)
    train_voltage = np.asarray(data["voltage_features"], dtype=np.float32)[data["train_indices"]]
    voltage_mean = train_voltage.mean(0)
    voltage_std = np.maximum(train_voltage.std(0), np.median(train_voltage.std(0)) * 1e-3 + 1e-6)
    dataset = MultimodalCEMDataset(args.data, "test", modality_dropout=0.0)
    dataset.voltages = (dataset.voltages - voltage_mean) / voltage_std
    sample = {key: torch.from_numpy(value) if isinstance(value, np.ndarray) else value for key, value in dataset[args.sample].items()}
    eit = sample["eit_image"].unsqueeze(0).to(device=device, dtype=torch.float32)
    voltages = sample["voltages"].unsqueeze(0).to(device=device, dtype=torch.float32)
    target = sample["target"][0].numpy()
    eit_image = sample["eit_image"][0].numpy()
    ultrasound = sample["ultrasound"].unsqueeze(0).to(device=device, dtype=torch.float32)
    baseline = MultiModalEITNet(voltage_dim=train_voltage.shape[1], base_channels=args.base_channels).to(device)
    robust = RegistrationRobustMultiModalEITNet(voltage_dim=train_voltage.shape[1], base_channels=args.base_channels).to(device)
    baseline.load_state_dict(torch.load(args.baseline, map_location=device, weights_only=False)["model_state"], strict=False)
    robust.load_state_dict(torch.load(args.robust, map_location=device, weights_only=False)["model_state"], strict=False)
    baseline.eval()
    robust.eval()
    conditions = ["clean", "shift10px", "rotate10deg", "blur_sigma4", "false_positive"]
    rows = []
    with torch.no_grad():
        for condition in conditions:
            corrupted = corrupt_ultrasound(ultrasound, condition)
            base_prediction = baseline(eit, voltages, corrupted, torch.ones((1, 1), device=device))["reconstruction"][0, 0].cpu().numpy()
            robust_output = robust(eit, voltages, corrupted, torch.ones((1, 1), device=device))
            robust_prediction = robust_output["reconstruction"][0, 0].cpu().numpy()
            confidence = robust_output["confidence_map"][0, 0].cpu().numpy()
            rows.append((condition, corrupted[0, 0].cpu().numpy(), base_prediction, robust_prediction, confidence))

    figure, axes = plt.subplots(len(rows), 7, figsize=(17, 2.65 * len(rows)), squeeze=False, constrained_layout=True)
    conductivity_images = [target, eit_image] + [item for row in rows for item in row[2:4]]
    vmin = float(np.nanpercentile(conductivity_images, 1))
    vmax = float(np.nanpercentile(conductivity_images, 99))
    for row_index, (condition, corrupted, base_prediction, robust_prediction, confidence) in enumerate(rows):
        panels = [target, eit_image, corrupted, base_prediction, robust_prediction, confidence, np.abs(robust_prediction - target)]
        titles = ["target", "EIT baseline", f"US: {condition}", "baseline recon", "robust recon", "learned confidence", "robust abs. error"]
        for col, (panel, title) in enumerate(zip(panels, titles, strict=True)):
            if col == 2:
                axes[row_index, col].imshow(panel, cmap="gray", vmin=0, vmax=1)
            elif col == 5:
                axes[row_index, col].imshow(panel, cmap="magma", vmin=0, vmax=1)
            elif col == 6:
                axes[row_index, col].imshow(panel, cmap="inferno", vmin=0, vmax=max(vmax - vmin, 1e-3))
            else:
                axes[row_index, col].imshow(panel, cmap="viridis", vmin=vmin, vmax=vmax)
            axes[row_index, col].set_title(title, fontsize=9)
            axes[row_index, col].axis("off")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(args.output, dpi=180)
    plt.close(figure)
    print(args.output.resolve())


if __name__ == "__main__":
    main()
