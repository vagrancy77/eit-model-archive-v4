# COMSOL Untitled EIT sample

This package was re-solved from the supplied `Untitled.mph`. `sample_pair.npz` contains the measured-style complex electrode voltage vector for the 16-electrode current-drive case and frequency-dependent conductivity/mask labels.

Use `eit_voltage` as the neural-network input. The FEM potential field is retained only for visualization/QA. The model has one drive pattern (E1=1 mA, E2=ground, other terminals zero current), so this is a validated single-case export and not yet a complete multi-pattern training set.
