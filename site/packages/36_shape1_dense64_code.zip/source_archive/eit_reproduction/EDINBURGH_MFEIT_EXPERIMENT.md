# Edinburgh 四频 mfEIT 真值实验

## 为什么使用这个公开数据集

本阶段优先使用爱丁堡大学公开的 **Edinburgh mfEIT Dataset**，而不是立即重新生成 CEM 数据。

- 数据页：<https://doi.org/10.7488/ds/3464>
- 论文：Chen et al., *MMV-Net: A Multiple Measurement Vector Network for Multifrequency Electrical Impedance Tomography*
- 许可：CC BY 4.0
- 样本数：12,414 个 phantom
- 每例输入：4 个频率通道 × 104 个归一化电压
- 每例真值：4 × 64 × 64 的归一化电导率变化
- 病灶数：1、2 或 3 个圆形 inclusion
- 关键性质：同一 phantom 的位置和尺寸在四个频率完全相同，电导率对比度随频率改变

这恰好对应当前假设：**共享病灶几何，保留频率专属电导率对比度**。工程已经逐一核验全部 12,414 例，四帧非零支持区域全部一致。

重要限制：公开文件只把四个通道标为 `f1`–`f4`，没有给出它们对应的实际 kHz。因此当前网络使用 1–4 的序号条件，不能把结果写成某个具体频率上的性能。公开包也没有 MMV-Net 官方训练代码，只有 `.npy` 数据和 README；本工程实现的是独立、可复现的 PyTorch 对照实验。

## 原始量和训练目标

公开图像保存的是：

```text
delta_sigma_normalized = (sigma_measured - sigma_reference) / sigma_reference
```

背景盐水为 2 S/m。目标物比背景低导电，所以公开真值位于约 `[-0.995, 0]`。训练时转换成非负病灶幅值：

```text
anomaly_magnitude = clip(-delta_sigma_normalized, 0, 1)
```

论文给出的三种跨频导电率组为：

| 组 | f1 | f2 | f3 | f4 |
|---|---:|---:|---:|---:|
| 1 | 0.01 | 0.6 | 1.2 | 1.8 S/m |
| 2 | 0.4 | 0.6 | 0.8 | 1.0 S/m |
| 3 | 0.8 | 1.0 | 1.2 | 1.4 S/m |

## 工程文件

- `download_edinburgh_mfeit.py`：从 Edinburgh DataShare 下载、断点续传、CRC 检查和解压。
- `prepare_edinburgh_mfeit.py`：验证全部样本、建立固定 8700/1900/1814 划分、计算训练集电压归一化统计。
- `pytorch_eit/multifrequency.py`：四频单帧、联合和共享几何模型。
- `train_edinburgh_mfeit.py`：训练、早停、噪声增强、指标、检查点和逐样本 CSV。
- `aggregate_edinburgh_mfeit_runs.py`：多随机种子均值/标准差和按独立 phantom 做的配对 bootstrap。

数据没有被复制成另一个 1.6 GB 文件。训练器直接以内存映射读取官方 `.npy`，小型清单位于：

```text
datasets/public/edinburgh_mfeit/edinburgh_mfeit_manifest_v1.npz
datasets/public/edinburgh_mfeit/edinburgh_mfeit_manifest_v1.json
```

## 四个对照模型

| 模型 | 推理时能看到什么 | 目的 |
|---|---|---|
| `independent` | 每个头只看自己的一个频率 | 严格单频基线，四个网络互不共享 |
| `conditional` | 单帧电压 + 频率序号 | 共享参数，但推理时看不到其他频率 |
| `joint` | 同一 phantom 的四帧电压 | 普通多频共享编码器、注意力和专属头 |
| `factorized` | 同一 phantom 的四帧电压 | 显式输出一个共享几何和四个频率对比度 |

最后一个模型被强制写成：

```text
reconstruction_f(x) = shared_geometry(x) * frequency_contrast_f(x)
```

因此每个频率可以改变病灶强度，但不能单独移动病灶位置。

## 如何运行

```powershell
cd E:\Codex\eit_reproduction

python download_edinburgh_mfeit.py
python prepare_edinburgh_mfeit.py --full-validation

E:\conda-envs\pytorch-gpu\python.exe train_edinburgh_mfeit.py --smoke `
  --output-dir outputs_edinburgh_mfeit_smoke

E:\conda-envs\pytorch-gpu\python.exe train_edinburgh_mfeit.py `
  --models independent,conditional,joint,factorized `
  --epochs 40 --batch-size 64 --latent-dim 64 --base-channels 8 `
  --max-train-samples 2048 --max-validation-samples 512 --max-test-samples 512 `
  --output-dir outputs_edinburgh_mfeit_stratified_20260729
```

## 三随机种子 pilot 结果

三个随机种子为 20260729、20260730、20260731；数据划分固定不变。有限样本按原数据比例同时包含 1、2、3 病灶 case，而不是简单截取清单开头。这里展示普通联合模型与结构分解模型的均值 ± 样本标准差：

| 指标 | 普通联合 | 共享几何分解 | 相对变化 |
|---|---:|---:|---:|
| MAE ↓ | 0.03314 ± 0.00179 | **0.02767 ± 0.00072** | 降低 16.5% |
| RMSE ↓ | 0.10389 ± 0.00269 | **0.09637 ± 0.00167** | 降低 7.2% |
| SSIM ↑ | 0.58791 ± 0.01506 | **0.65990 ± 0.00821** | 提高 12.2% |
| Dice ↑ | 0.58515 ± 0.01599 | **0.64739 ± 0.00652** | 提高 10.6% |
| IoU ↑ | 0.43188 ± 0.01620 | **0.49307 ± 0.00770** | 提高 14.2% |
| 质心误差/像素 ↓ | 3.002 ± 0.047 | **2.485 ± 0.185** | 降低 17.2% |
| 背景假阳性 ↓ | 0.02717 ± 0.00192 | **0.02104 ± 0.00074** | 降低 22.6% |
| 跨频支持一致性 ↑ | 0.92503 ± 0.00204 | **0.96500 ± 0.00225** | 提高 4.3% |
| 病灶内部对比度 MAE ↓ | **0.13313 ± 0.00281** | 0.14021 ± 0.00259 | 分解模型差 5.3% |

对 512 个独立测试 phantom 做配对 bootstrap 后，MAE、RMSE、SSIM、Dice、IoU、质心误差和背景假阳性的 95% 区间都完全位于“分解模型更好”的方向。病灶内部对比度 MAE 的改进区间为 `[-0.00905, -0.00513]`，完全位于负方向，说明当前分解模型的强度定量确实较差，而不是随机波动。

完整结果位于：

```text
outputs_edinburgh_mfeit_stratified_multiseed/summary.json
outputs_edinburgh_mfeit_stratified_multiseed/runs.csv
```

## 当前可以得出的结论

当前证据支持：显式分离共享几何和频率专属对比度，能稳定提高病灶定位、轮廓、背景抑制和跨频结构一致性。可视化还显示，它比普通联合模型更不容易把相邻病灶粘连。

当前证据也明确指出：这个简单乘法分解会损害病灶内部的逐频强度定量。因而“共享几何”本身是有价值的中间表示，但还不能单独作为完整方法宣称全面优于普通联合模型。更有潜力的论文创新是：**共享几何 + 病灶级频谱校准/不确定性分支**，使结构先验不牺牲每个病灶的频率响应。

当前还不能得出：该模型已经在真实人体或具体 10/50 kHz 数据上有效。原因是 Edinburgh 数据为 COMSOL 仿真，四个频率没有公开物理值；UCLH 临床数据虽然有 17 个频率和影像学资料，但没有逐像素电导率真值，并且是不同的头部电极协议。

## 最合理的后续实验

1. 在现有分解后增加病灶级 pooling 和每个连通病灶的频谱标量/曲线校准，优先修复强度 MAE。
2. 把训练规模从 2048 提升到完整 8700，至少做 5 个随机种子。
3. 按 1/2/3 病灶、尺寸、间距和 SNR 分层报告，特别检查相邻病灶粘连与小病灶漏检。
4. 用当前 CEM/FEniCSX 生成具有明确 10/50 kHz、接触阻抗和频散参数的补充数据，做 forward-model shift 测试。
5. 为 6 个公开 10/50 kHz 实体样本训练一个测量协议适配器，只作为域外定性/稳定性验证，不使用 GN 伪标签声称真值精度。
6. 以后引入超声时，让超声只约束 `shared_geometry`；频谱校准仍由 EIT 电压完成，避免超声先验把电导率强度也错误固定。
