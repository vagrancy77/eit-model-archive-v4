from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader

from pytorch_eit.data import MultimodalCEMDataset
from pytorch_eit.models import MultiModalEITNet, RegistrationRobustMultiModalEITNet


def affine_corrupt(image: torch.Tensor, tx: float, ty: float, angle: float) -> torch.Tensor:
    batch = image.shape[0]
    theta = image.new_zeros((batch, 2, 3))
    theta[:, 0, 0] = np.cos(angle)
    theta[:, 0, 1] = -np.sin(angle)
    theta[:, 1, 0] = np.sin(angle)
    theta[:, 1, 1] = np.cos(angle)
    theta[:, 0, 2] = tx
    theta[:, 1, 2] = ty
    grid = F.affine_grid(theta, image.shape, align_corners=False)
    return F.grid_sample(image, grid, mode="bilinear", padding_mode="zeros", align_corners=False)


def evaluate_model(model, loader, device, mask, transform):
    model.eval()
    correlations, relative_l2, mae = [], [], []
    with torch.no_grad():
        for batch in loader:
            batch = {key: value.to(device=device, dtype=torch.float32) for key, value in batch.items()}
            ultrasound = transform(batch["ultrasound"])
            output = model(batch["eit_image"], batch["voltages"], ultrasound, torch.ones_like(batch["ultrasound_available"]))
            prediction = output["reconstruction"][:, 0] * mask
            target = batch["target"][:, 0] * mask
            p = prediction.flatten(1) - prediction.flatten(1).mean(1, keepdim=True)
            t = target.flatten(1) - target.flatten(1).mean(1, keepdim=True)
            correlations.extend(((p * t).sum(1) / (torch.linalg.vector_norm(p, dim=1) * torch.linalg.vector_norm(t, dim=1)).clamp_min(1e-6)).cpu().numpy().tolist())
            relative_l2.extend((torch.linalg.vector_norm((prediction - target).flatten(1), dim=1) / torch.linalg.vector_norm(target.flatten(1), dim=1).clamp_min(1e-6)).cpu().numpy().tolist())
            mae.extend((torch.abs(prediction - target).sum(dim=(1, 2)) / mask.sum()).cpu().numpy().tolist())
    return {"correlation": float(np.mean(correlations)), "relative_l2": float(np.mean(relative_l2)), "mae": float(np.mean(mae))}


def main() -> None:
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Continuous US corruption stress test on independent CEM data.")
    parser.add_argument("--data", type=Path, default=root / "datasets" / "multimodal_cem_v2.npz")
    parser.add_argument("--robust-checkpoint", type=Path, default=root / "outputs_registration_robust_multimodal_warmstart" / "model.pt")
    parser.add_argument("--baseline-checkpoint", type=Path, default=root / "outputs_pytorch_multimodal" / "model.pt")
    parser.add_argument("--output-dir", type=Path, default=root / "outputs_registration_robust_stress")
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--cpu", action="store_true")
    args = parser.parse_args()
    device = torch.device("cpu" if args.cpu or not torch.cuda.is_available() else "cuda")
    robust_ckpt = torch.load(args.robust_checkpoint, map_location=device, weights_only=False)
    baseline_ckpt = torch.load(args.baseline_checkpoint, map_location=device, weights_only=False)
    voltage_mean = np.asarray(robust_ckpt["voltage_mean"], dtype=np.float32)
    voltage_std = np.asarray(robust_ckpt["voltage_std"], dtype=np.float32)
    dataset = MultimodalCEMDataset(args.data, "test", modality_dropout=0.0)
    dataset.voltages = (dataset.voltages - voltage_mean) / voltage_std
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=0)
    data = np.load(args.data)
    mask = torch.from_numpy(np.asarray(data["mask"], dtype=np.float32)).to(device)
    robust = RegistrationRobustMultiModalEITNet(voltage_dim=dataset.voltages.shape[1], base_channels=int(robust_ckpt["base_channels"])).to(device)
    robust.load_state_dict(robust_ckpt["model_state"], strict=False)
    baseline = MultiModalEITNet(voltage_dim=dataset.voltages.shape[1], base_channels=int(baseline_ckpt["base_channels"])).to(device)
    baseline.load_state_dict(baseline_ckpt["model_state"], strict=False)
    shifts = [0, 5, 10, 15, 20]
    rotations = [0, 5, 10, 15, 20]
    blurs = [1, 3, 5, 7, 9]
    result = {"shift_px": [], "rotation_deg": [], "blur_kernel": []}
    for px in shifts:
        tx = 0.22 * px / 10.0
        transform = lambda image, tx=tx: affine_corrupt(image, tx, 0.0, 0.0)
        result["shift_px"].append({"severity": px, "baseline": evaluate_model(baseline, loader, device, mask, transform), "robust": evaluate_model(robust, loader, device, mask, transform)})
    for degree in rotations:
        angle = np.deg2rad(degree)
        transform = lambda image, angle=angle: affine_corrupt(image, 0.0, 0.0, angle)
        result["rotation_deg"].append({"severity": degree, "baseline": evaluate_model(baseline, loader, device, mask, transform), "robust": evaluate_model(robust, loader, device, mask, transform)})
    for kernel in blurs:
        if kernel == 1:
            transform = lambda image: image
        else:
            transform = lambda image, kernel=kernel: F.avg_pool2d(image, kernel_size=kernel, stride=1, padding=kernel // 2)
        result["blur_kernel"].append({"severity": kernel, "baseline": evaluate_model(baseline, loader, device, mask, transform), "robust": evaluate_model(robust, loader, device, mask, transform)})
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    figure, axes = plt.subplots(1, 3, figsize=(15, 4.5), constrained_layout=True)
    for ax, key, xlabel in zip(axes, ("shift_px", "rotation_deg", "blur_kernel"), ("translation (px)", "rotation (deg)", "blur kernel"), strict=True):
        x = [row["severity"] for row in result[key]]
        for method, color, label in (("baseline", "0.45", "baseline"), ("robust", "tab:blue", "robust")):
            ax.plot(x, [row[method]["relative_l2"] for row in result[key]], "o-", color=color, label=label)
        ax.set_xlabel(xlabel)
        ax.set_ylabel("relative L2 ↓")
        ax.grid(alpha=0.25)
        ax.set_title(key)
    axes[0].legend()
    figure.savefig(args.output_dir / "stress_curves.png", dpi=180)
    plt.close(figure)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
