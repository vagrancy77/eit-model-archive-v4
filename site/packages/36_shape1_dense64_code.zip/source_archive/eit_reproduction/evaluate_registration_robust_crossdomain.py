from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from torch.utils.data import DataLoader

from pytorch_eit.data import MultimodalCEMDataset
from pytorch_eit.models import MultiModalEITNet, RegistrationRobustMultiModalEITNet
from train_registration_robust_multimodal import corrupt_ultrasound, evaluate


def main() -> None:
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Evaluate trained EIT models on an independent CEM distribution.")
    parser.add_argument("--data", type=Path, default=root / "datasets" / "multimodal_cem_v2.npz")
    parser.add_argument("--robust-checkpoint", type=Path, default=root / "outputs_registration_robust_multimodal_warmstart" / "model.pt")
    parser.add_argument("--baseline-checkpoint", type=Path, default=root / "outputs_pytorch_multimodal" / "model.pt")
    parser.add_argument("--output-dir", type=Path, default=root / "outputs_registration_robust_crossdomain")
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--cpu", action="store_true")
    args = parser.parse_args()
    device = torch.device("cpu" if args.cpu or not torch.cuda.is_available() else "cuda")
    robust_ckpt = torch.load(args.robust_checkpoint, map_location=device, weights_only=False)
    baseline_ckpt = torch.load(args.baseline_checkpoint, map_location=device, weights_only=False)
    voltage_mean = np.asarray(robust_ckpt["voltage_mean"], dtype=np.float32)
    voltage_std = np.asarray(robust_ckpt["voltage_std"], dtype=np.float32)
    dataset = MultimodalCEMDataset(args.data, "test", modality_dropout=0.0)
    dataset.voltages = (dataset.voltages - voltage_mean) / voltage_std
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=0)
    data = np.load(args.data)
    mask = torch.from_numpy(np.asarray(data["mask"], dtype=np.float32)).to(device)
    robust = RegistrationRobustMultiModalEITNet(voltage_dim=dataset.voltages.shape[1], base_channels=int(robust_ckpt["base_channels"])).to(device)
    robust.load_state_dict(robust_ckpt["model_state"], strict=False)
    baseline = MultiModalEITNet(voltage_dim=dataset.voltages.shape[1], base_channels=int(baseline_ckpt["base_channels"])).to(device)
    baseline.load_state_dict(baseline_ckpt["model_state"], strict=False)
    conditions = ["clean", "shift10px", "rotate10deg", "blur_sigma4", "false_positive"]
    robust_metrics = [evaluate(robust, loader, device, mask, condition) for condition in conditions]
    baseline_metrics = [evaluate(baseline, loader, device, mask, condition) for condition in conditions]
    args.output_dir.mkdir(parents=True, exist_ok=True)
    summary = {"data": str(args.data.resolve()), "device": str(device), "samples": len(dataset), "robust_metrics": robust_metrics, "baseline_metrics": baseline_metrics, "warning": "independent synthetic CEM distribution; ultrasound remains a geometry-consistent proxy"}
    (args.output_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    figure, axes = plt.subplots(1, 2, figsize=(11, 4), constrained_layout=True)
    x = np.arange(len(conditions))
    for ax, metric, title in zip(axes, ("correlation", "relative_l2"), ("Correlation ↑", "Relative L2 ↓"), strict=True):
        axes_values = [[row[metric] for row in baseline_metrics], [row[metric] for row in robust_metrics]]
        width = 0.36
        ax.bar(x - width / 2, axes_values[0], width, label="baseline", color="0.5")
        ax.bar(x + width / 2, axes_values[1], width, label="robust", color="tab:blue")
        ax.set_xticks(x, conditions, rotation=28, ha="right")
        ax.set_title(title)
        ax.grid(axis="y", alpha=0.25)
    axes[0].legend()
    figure.savefig(args.output_dir / "crossdomain_metrics.png", dpi=180)
    plt.close(figure)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
