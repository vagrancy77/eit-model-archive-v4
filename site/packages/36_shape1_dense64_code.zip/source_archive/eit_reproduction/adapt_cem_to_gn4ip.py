from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.io import savemat
from scipy.spatial import cKDTree


def parse_arguments() -> argparse.Namespace:
    project_root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(
        description="Convert the local CEM dataset to GN4IP Conv U-Net fields."
    )
    parser.add_argument(
        "--input",
        type=Path,
        default=project_root / "datasets" / "synthetic_cem_v1.npz",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=project_root / "datasets" / "cem_gn4ip_v1.mat",
    )
    parser.add_argument("--pixels", type=int, default=32)
    return parser.parse_args()


def main() -> None:
    arguments = parse_arguments()
    data = np.load(arguments.input)
    nodes = np.asarray(data["inverse_nodes"], dtype=float)[:, :2]
    elements = np.asarray(data["inverse_elements"], dtype=np.int64)[:, :3]
    centers = nodes[elements].mean(axis=1)
    radius = float(np.max(np.linalg.norm(nodes, axis=1)))
    pixel_edges = np.linspace(-radius, radius, arguments.pixels + 1)
    pixel_centers_1d = pixel_edges[:-1] + 0.5 * np.diff(pixel_edges)
    grid_x, grid_y = np.meshgrid(pixel_centers_1d, pixel_centers_1d)
    pixel_points = np.column_stack(
        [
            grid_x.reshape(-1, order="F"),
            grid_y.reshape(-1, order="F"),
        ]
    )
    closest_elements = cKDTree(centers).query(pixel_points)[1]
    closest_pixels = cKDTree(pixel_points).query(centers)[1]

    linear_delta = np.asarray(data["linear_reconstructions"], dtype=float)
    truth = np.asarray(data["conductivity_inverse"], dtype=float)
    n_samples, n_elements = truth.shape
    output_fields = {
        "VSIM": np.asarray(data["voltages_noisy"], dtype=float),
        "X0": np.ones((n_samples, n_elements), dtype=float),
        "X1": linear_delta,
        "X2": 1.0 + linear_delta,
        "Y": truth,
        "closest_elements": (closest_elements + 1).astype(np.uint16)[:, None],
        "closest_pixels": (closest_pixels + 1).astype(np.uint16)[:, None],
        "n_pixels": np.array([[arguments.pixels]], dtype=np.uint16),
        "train_indices": (data["train_indices"] + 1).astype(np.int32)[:, None],
        "validation_indices": (
            data["validation_indices"] + 1
        ).astype(np.int32)[:, None],
        "test_indices": (data["test_indices"] + 1).astype(np.int32)[:, None],
        "inverse_nodes": nodes,
        "inverse_elements": (elements + 1).astype(np.int32),
    }
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    savemat(arguments.output, output_fields, do_compression=True)
    summary = {
        "source": str(arguments.input.resolve()),
        "output": str(arguments.output.resolve()),
        "samples": n_samples,
        "elements": n_elements,
        "grid": [arguments.pixels, arguments.pixels],
        "measurements": int(output_fields["VSIM"].shape[1]),
        "field_mapping": {
            "X0": "homogeneous conductivity 1",
            "X1": "linear CEM conductivity update",
            "X2": "absolute linear CEM reconstruction 1 + X1",
            "Y": "inverse-mesh ground truth conductivity",
        },
        "indexing": "MATLAB-compatible one-based closest_elements/closest_pixels",
    }
    with arguments.output.with_suffix(".json").open(
        "w",
        encoding="utf-8",
    ) as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    print(arguments.output.resolve())


if __name__ == "__main__":
    main()
