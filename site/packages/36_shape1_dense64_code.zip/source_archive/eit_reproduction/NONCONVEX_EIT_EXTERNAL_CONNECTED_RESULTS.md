# 非凸/凹陷目标 EIT 重建阶段报告

## 目标

本阶段不再复现 DIP+TV，而是解决新的问题：当目标包含深凹口、U/C 形开口、再入角或窄间隙时，EIT 重建不应把凹口平滑填满，同时也不能通过过度腐蚀主体来制造“看起来有凹陷”的假改进。

## 数据

- KTC2023 v3 公开数据已完整下载到 `datasets/ktc2023_full/v3`，共 21 个真实案例；固定非凸判据下 17 个案例至少含一个明显非凸目标。
- 独立非凸 stress 数据为 `datasets/ktc_deep_concavity_stress_v1.npz`，含 800 个 nonlinear-CEM 样本、8 类结构；固定划分为 520/120/160，test 未参与训练和参数选择。
- 原 KTC2023-ABC2 四例仅作为 calibration-case 对照，不作为独立泛化证据。

## 文献依据

方法吸收了以下公开工作的共同思想，而不是继续限制在原 DIP 网络内：

1. Parametric/B-spline level-set EIT：用连续隐式场表示边界，而不是对像素做独立分类。
2. Boolean EIT shape reconstruction：将复杂目标表示为外包络与凹入背景的布尔组合。
3. Moving morphable components 与 shape-driven EIT：显式结构变量可减少平滑正则对再入角的填充。
4. clDice/topology-aware segmentation：连通关系需要显式监督，但单独 skeleton loss 不能保证凹陷深度或 bank 宽度。

详细文献清单见 `NONCONVEX_EIT_METHOD_NOTE.md`。

## 最终保留方法

最终候选为：

```text
输入电压/线性重建
  -> 冻结的隐式 Boolean 网络
  -> support 外包络
  -> cutout 凹入背景
  -> mouth/contact 入口概率
  -> 仅保留含高置信 mouth 的 cutout 连通分量
  -> reconstruction = support AND NOT external-connected-cutout
```

所有 support/cutout/mouth 阈值、最小连通域和案例门控均只在 synthetic validation 上选择。test、21 个 KTC 标签和四例 truth 均在参数冻结后才用于评估。

核心代码：

- `scripts/train_ktc_implicit_boolean_network.py`
- `scripts/evaluate_ktc_external_connected_support.py`
- `scripts/compare_ktc_external_connected.py`

## 原四例结果

| case | DIP+TV IoU | 新方法 IoU | DIP+TV B-F1 | 新方法 B-F1 | 新方法 notch preservation |
|---|---:|---:|---:|---:|---:|
| data1 | 0.762 | 0.938 | 0.310 | 0.832 | 0.551 |
| data2 | 0.811 | 0.932 | 0.150 | 0.800 | 0.468 |
| data3 | 0.665 | 0.895 | 0.050 | 0.629 | 0.682 |
| data4 | 0.304 | 0.875 | 0.019 | 0.794 | 0.926 |

data4 不再被重建成凸圆块，四个再入区域已经可见。前三例没有因为凹陷模块而退化。

图像：`E:/Codex/ktc_external_connected_support_seed20260820/official_four_case_comparison.png`

## 独立非凸 stress test

160 个固定 test 样本上的 paired bootstrap（10,000 次）结果：

| 指标 | stable | 新方法 | 配对差 | 95% CI |
|---|---:|---:|---:|---:|
| foreground IoU | 0.621 | 0.589 | -0.032 | [-0.041, -0.023] |
| open deep cutout | 0.474 | 0.668 | +0.194 | [+0.150, +0.241] |
| bank retention | 0.747 | 0.659 | -0.089 | [-0.106, -0.071] |
| topology joint | 0.490 | 0.580 | +0.089 | [+0.056, +0.123] |

结论很明确：凹陷/开口恢复是统计显著的真实增益；但该增益仍以一部分主体和 bank 损失为代价。因此当前版本可以证明方向有效，但尚不能宣称已经全面优于 stable 模型。

统计图：`E:/Codex/ktc_external_connected_support_seed20260820/paired_bootstrap.png`

## KTC2023 v3 的 21 个真实案例

| 方法 | foreground IoU | KTC-SSIM | notch preservation |
|---|---:|---:|---:|
| stable Boolean | 0.5164 | 0.6557 | 0.5095 |
| 新方法 | 0.5162 | 0.6548 | 0.5076 |

新方法基本保持整体指标，但没有在全部真实分布上产生显著改进。部分强非凸案例有凹口趋势，位置、尺度和多目标结构仍受 synthetic-to-real 域差影响。

图像：

- `E:/Codex/ktc_external_connected_support_seed20260820/real_all_21_comparison.png`
- `E:/Codex/ktc_external_connected_support_seed20260820/real_most_concave_comparison.png`
- `E:/Codex/ktc_external_connected_support_seed20260820/test_external_connected_montage.png`

## 已否决的训练层版本

将 soft flood-fill 直接放入网络前向后，最佳 validation 轮的开口恢复达到 0.709，但独立 test 的 foreground IoU 降至 0.550、bank retention 降至 0.572。该版本过度开口，已保留为负消融，不进入最终方法。

checkpoint 和曲线位于：`E:/Codex/ktc_external_connect_train_seed20260820`。

## 下一技术问题

下一步不能继续单纯增加 cutout/mouth loss。需要显式建模 bank：预测左右 bank 的距离场或最小厚度，并在 differentiable external-connectivity decoder 中加入 bank-preservation constraint。目标是保留当前 `+0.194` 的开口增益，同时把 bank retention 恢复到至少 0.70、foreground IoU 恢复到至少 0.61。只有满足这个条件并在 21 个真实案例上不下降，才适合作为完整方法论文的主模型。
