from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
import matplotlib.tri as mtri
import numpy as np


def parse_arguments() -> argparse.Namespace:
    project_root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(
        description="Plot SciPy-CEM and FEniCSX-CEM validation results."
    )
    parser.add_argument(
        "--reference",
        type=Path,
        default=project_root / "outputs" / "simulation_data.npz",
    )
    parser.add_argument(
        "--fenicsx",
        type=Path,
        default=project_root / "outputs_fenicsx" / "fenicsx_results.npz",
    )
    parser.add_argument(
        "--summary",
        type=Path,
        default=project_root / "outputs_fenicsx" / "summary.json",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=project_root
        / "outputs_fenicsx"
        / "fenicsx_comparison.png",
    )
    return parser.parse_args()


def add_mesh_image(
    axis: plt.Axes,
    triangulation: mtri.Triangulation,
    values: np.ndarray,
    title: str,
    vmin: float,
    vmax: float,
) -> None:
    image = axis.tripcolor(
        triangulation,
        facecolors=values,
        shading="flat",
        cmap="RdBu_r",
        vmin=vmin,
        vmax=vmax,
    )
    axis.set_title(title)
    axis.set_aspect("equal")
    axis.set_axis_off()
    plt.colorbar(image, ax=axis, fraction=0.046, pad=0.04)


def main() -> None:
    arguments = parse_arguments()
    reference = np.load(arguments.reference)
    fenicsx = np.load(arguments.fenicsx)
    summary = json.loads(arguments.summary.read_text(encoding="utf-8"))

    nodes = reference["inverse_nodes"][:, :2]
    elements = reference["inverse_elements"][:, :3]
    triangulation = mtri.Triangulation(nodes[:, 0], nodes[:, 1], elements)
    truth = reference["truth_delta"]
    scipy_reconstruction = reference["reconstruction_delta"]
    fenicsx_reconstruction = fenicsx["reconstruction_delta"]
    color_limit = float(
        np.max(
            np.abs(
                np.concatenate(
                    [truth, scipy_reconstruction, fenicsx_reconstruction]
                )
            )
        )
    )

    figure, axes = plt.subplots(2, 3, figsize=(15, 9), constrained_layout=True)
    add_mesh_image(
        axes[0, 0],
        triangulation,
        truth,
        "Ground-truth conductivity change",
        -color_limit,
        color_limit,
    )
    add_mesh_image(
        axes[0, 1],
        triangulation,
        scipy_reconstruction,
        "SciPy CEM reconstruction",
        -color_limit,
        color_limit,
    )
    add_mesh_image(
        axes[0, 2],
        triangulation,
        fenicsx_reconstruction,
        "FEniCSX CEM reconstruction",
        -color_limit,
        color_limit,
    )

    reference_difference = (
        reference["voltage_clean"] - reference["voltage_background"]
    )
    fenicsx_difference = (
        fenicsx["voltage_clean"] - fenicsx["voltage_background"]
    )
    measurement_indices = np.arange(reference_difference.size)
    axes[1, 0].plot(
        measurement_indices,
        reference_difference,
        linewidth=1.4,
        label="SciPy CEM",
    )
    axes[1, 0].plot(
        measurement_indices,
        fenicsx_difference,
        linestyle="--",
        linewidth=1.0,
        label="FEniCSX CEM",
    )
    axes[1, 0].set_title("Differential boundary voltages")
    axes[1, 0].set_xlabel("Measurement index")
    axes[1, 0].set_ylabel("Voltage change")
    axes[1, 0].grid(alpha=0.25)
    axes[1, 0].legend()

    voltage_error = np.abs(reference_difference - fenicsx_difference)
    voltage_error_floor = max(
        float(np.max(voltage_error)) * 1e-4,
        1e-18,
    )
    axes[1, 1].semilogy(
        measurement_indices,
        np.maximum(voltage_error, voltage_error_floor),
        linewidth=1.0,
    )
    axes[1, 1].set_title("Absolute voltage difference between backends")
    axes[1, 1].set_xlabel("Measurement index")
    axes[1, 1].set_ylabel("Absolute error")
    axes[1, 1].grid(alpha=0.25)

    reconstruction_error = np.abs(
        scipy_reconstruction - fenicsx_reconstruction
    )
    positive_floor = max(
        float(np.max(reconstruction_error)) * 1e-6,
        np.finfo(float).tiny,
    )
    error_image = axes[1, 2].tripcolor(
        triangulation,
        facecolors=np.maximum(reconstruction_error, positive_floor),
        shading="flat",
        cmap="viridis",
        norm=LogNorm(
            vmin=positive_floor,
            vmax=max(float(np.max(reconstruction_error)), positive_floor * 10.0),
        ),
    )
    axes[1, 2].set_title("Absolute reconstruction difference")
    axes[1, 2].set_aspect("equal")
    axes[1, 2].set_axis_off()
    plt.colorbar(error_image, ax=axes[1, 2], fraction=0.046, pad=0.04)

    comparison = summary["comparison_with_scipy_cem"]
    figure.suptitle(
        "FEniCSX-CEM validation | "
        f"voltage rel. error={comparison['background_voltage_relative_error']:.2e}, "
        f"Jacobian rel. error={comparison['jacobian_relative_error']:.2e}, "
        f"reconstruction correlation={summary['reconstruction_correlation']:.4f}",
        fontsize=13,
    )
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(arguments.output, dpi=180)
    plt.close(figure)
    print(arguments.output.resolve())


if __name__ == "__main__":
    main()
