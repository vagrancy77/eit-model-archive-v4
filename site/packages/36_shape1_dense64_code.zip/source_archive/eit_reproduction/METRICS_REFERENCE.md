# EIT 项目指标总表

本文件整理本项目在基础 EIT、DeepEIT/DIP、KTC2023-ABC2、凹陷边界网络、Edinburgh 多频 EIT、10/50 kHz 公共数据、超声先验和 v6 风险门控实验中出现过的指标。

## 0. 先区分两类任务

项目中有两种不同的评价对象，不能混用指标：

1. **连续电导率场重建**：预测值和真值是浮点图像，主要用 MAE、RMSE、相对 L2、相关系数、SSIM、PSNR、RE。
2. **离散病灶/类别分割**：预测值和真值是标签图，主要用 IoU、Dice、像素准确率、边界 F1，以及凹陷/拓扑指标。

同名指标也可能属于不同版本。例如 DeepEIT 的 `SSIM` 衡量连续归一化电导率图；KTC 的 `KTC-SSIM` 是针对离散标签和论文评分公式的专用指标，二者不能直接当作同一指标比较。

方向约定：`↑` 表示越大越好，`↓` 表示越小越好。

---

## 1. 连续电导率场指标

| 指标 | 方向 | 含义与计算 | 作用和注意事项 |
|---|---:|---|---|
| `MSE` / `mse` | ↓ | `mean((prediction-target)^2)` | 对大误差平方放大，适合训练和检查明显异常。 |
| `MAE` / `mae` | ↓ | `mean(abs(prediction-target))` | 平均绝对误差，直观、对离群点比 MSE 稳健；本项目最常用的定量误差之一。 |
| `RMSE` / `rmse` | ↓ | `sqrt(MSE)` | 与原数据同量纲，比 MAE 更强调大误差。 |
| `relative L2` / `relative_l2` | ↓ | `||p-t||_2 / ||t||_2` | 消除场幅值尺度影响，适合不同病灶强度之间比较。 |
| `RE` / `relative_error` | ↓ | DeepEIT 中同样是 `||p-t||_2 / ||t||_2` | 论文 DeepEIT 的命名；通常可视为 relative L2。 |
| `CC` / `correlation` | ↑ | 预测图和真值图展平后中心化的 Pearson 型相关系数 | 衡量空间变化趋势是否一致，不代表幅值一定准确。 |
| `SSIM` / `global_ssim` | ↑ | 基于均值、方差、协方差的结构相似度 | 评价连续图像的局部/整体结构；通常范围约为 `[-1,1]` 或 `[0,1]`，实现需固定归一化方式。 |
| `windowed_ssim` / `ssim_windowed` | ↑ | 在滑动窗口内计算 SSIM，再按 mask 平均 | 对局部结构更敏感；和 global SSIM 不应混报。 |
| `PSNR` / `psnr` | ↑ | `20 log10(MAX/sqrt(MSE))`，本项目归一化图像通常 `MAX=1` | 越大越好，单位 dB；高度依赖 min-max 归一化和动态范围。 |
| `relative MSE` / `relative_mse` | ↓ | MSE 按真值能量归一化 | 与相对 L2 类似，但平方误差更强调异常点。 |
| `absolute error` / `maximum_absolute_error` / `delta_max_abs_error` | ↓ | 像素或场上的绝对误差，后两者分别取最大误差或变化量最大值 | 用于发现局部严重错误，不适合作为唯一总体指标。 |
| `correlation_loss` / `mse_loss` / `smooth_l1_loss` | ↓ | 训练阶段对应的损失函数 | 是优化目标，不等于最终评价指标。 |

### 区域化连续场指标

| 指标 | 方向 | 含义 |
|---|---:|---|
| `lesion_mae` | ↓ | 只在真值病灶区域计算 MAE | 衡量病灶内部重建误差。 |
| `background_mae` | ↓ | 只在背景区域计算 MAE | 衡量背景是否被错误改变。 |
| `lesion_rmse` / `background_rmse` | ↓ | 病灶/背景区域 RMSE | 分别检查病灶强度和背景大误差。 |
| `balanced_mae` / `balanced_rmse` | ↓ | 例如 `0.6*lesion + 0.4*background` 的加权误差 | 防止大面积背景支配总体误差；权重必须在论文中说明。 |
| `lesion_contrast_mae` | ↓ | 真值病灶内部的电导率对比度 MAE | 多频分解模型的关键强度指标；几何变好但该指标变差，说明定位变好而定量强度变差。 |
| `background_false_positive` | ↓ | 真值背景中预测异常幅值的平均值 | 越低表示背景抑制越好，直接反映假阳性。 |
| `frequency_contrast` | 视定义 | 频率专属病灶对比度/幅值图 | 不能单独作为统一质量指标，通常结合 lesion contrast MAE、频谱误差使用。 |
| `spectrum_error` / `spectrum_loss` | ↓ | 每个病灶跨频电导率谱与真值谱的平均绝对差 | 衡量频率响应曲线是否被恢复。 |
| `instance_spectrum_mae` | ↓ | 按连通病灶实例计算的频谱 MAE，再平均 | 比全图频谱误差更能发现相邻病灶被混合的问题。 |

---

## 2. 分割和标签图指标

设 `A` 是真值区域，`B` 是预测区域，`I=|A∩B|`，`U=|A∪B|`。

| 指标 | 方向 | 公式/含义 | 作用 |
|---|---:|---|---|
| `IoU` / `intersection over union` | ↑ | `I/U` | 最基本的区域重叠指标。 |
| `Dice` / `F1` | ↑ | `2I/(|A|+|B|)` | 对小病灶通常比 IoU 更直观；Dice 和 IoU 单调相关但数值不同。 |
| `pixel_accuracy` | ↑ | 所有像素中标签预测正确的比例 | 背景占比很大时可能虚高，不能单独证明病灶重建好。 |
| `class1_iou`, `class2_iou` | ↑ | 对标签 1、2 分别计算 IoU | KTC2023-ABC2 中用于分别评价两类目标；`mean_iou` 是两者平均，不含背景。 |
| `class1_dice`, `class2_dice` | ↑ | 对标签 1、2 分别计算 Dice | 检查某一类别是否被另一类别吞并或漏检。 |
| `mean_iou` | ↑ | `(class1_iou + class2_iou)/2` | ABC2 旧 DIP+TV 复现的主要汇总指标。 |
| `mean_dice` | ↑ | `(class1_dice + class2_dice)/2` | ABC2 的类别平均 Dice。 |
| `foreground_iou` | ↑ | 把所有非零类别合并为前景后计算 IoU | 凹陷网络/v6 的主体区域指标，不区分类别 1 和 2。 |
| `foreground_dice` | ↑ | 合并所有非零类别后的 Dice | 与 foreground IoU 配套。 |
| `support_iou` / `support_dice` | ↑ | 对二值病灶支持区域计算 IoU/Dice | 多频模型中常用于比较病灶位置，不考虑电导率强度。 |
| `geometry_iou`, `geometry_dice`, `shared_geometry_dice` | ↑ | 预测共享几何 mask 与真值几何 mask 的重叠 | 专门评价“病灶在哪里”，与频率对比度分开。 |
| `instance_mask_dice` | ↑ | 每个病灶实例 mask 的 Dice | 检查多病灶是否被粘连、拆分或漏掉。 |
| `pair_iou`, `group_iou`, `pool_iou`, `case_iou` | ↑ | 对某一病例对、病灶组、候选池或病例级别计算 IoU | 是分组统计版本，不是新的数学指标。 |
| `raw_iou`, `proposal_iou`, `candidate_iou`, `routed_iou`, `oracle_iou` | ↑ | 分别对应原始、候选、候选输出、门控输出、真值选择上限 | 必须同时注明生成这些预测的流程。 |
| `class_1_iou`, `class_2_iou` | ↑ | 下划线命名版本，与 `class1_iou` 等价 | 仅是不同脚本的字段命名。 |
| `cldice` / `cutout_cldice` | ↑ | 中心线/骨架保持型 Dice | 对细长、开口、通道状凹陷比普通 Dice 更敏感。 |

### 分割指标的关键陷阱

- `foreground_iou` 高，不代表凹陷边界正确；一个填平凹陷的实心圆也可能有较高 IoU。
- `pixel_accuracy` 高，不代表病灶质量高，因为背景像素很多。
- `mean_iou` 可能把一个类别的严重失败掩盖在另一个类别的高分中，因此论文中应同时报告 class-wise IoU。
- 连续场指标和标签指标必须分别报告，不能把 SSIM 与 Dice 放在同一列解释。

---

## 3. 边界、凹陷和拓扑指标

这是本项目标题“面向内凹边界重建”最核心的一组指标。

| 指标 | 方向 | 含义与计算 | 作用 |
|---|---:|---|---|
| `boundary_f1` | ↑ | 在给定像素容差内匹配真值边界和预测边界的 precision/recall 的 F1 | 评价边界位置，比区域 IoU 更敏感。 |
| `boundary_precision` | ↑ | 预测边界中落在真值边界容差内的比例 | 低时说明预测边界有大量假边缘。 |
| `boundary_recall` | ↑ | 真值边界中被预测边界覆盖的比例 | 低时说明边界缺失或过度平滑。 |
| `notch_pixels` | 仅计数 | 真值内凹区域像素数量 | 不是质量分数，用于说明该病例是否有足够大的凹陷。 |
| `notch_preservation` | ↑ | 内凹区域中仍被预测为背景的比例；代码为 `mean(~predicted_foreground[notch])` | 直接衡量凹陷是否被保留。接近 0 表示凹陷被填平，接近 1 表示凹陷保留。 |
| `concavity_score` | ↑ | 当前实现为 `sqrt(foreground_iou * notch_preservation)` | 同时要求整体前景和凹陷都好，比单独 IoU 更适合选模型。 |
| `indentation_preservation` | ↑ | `notch_preservation` 的同义/早期命名 | 论文中统一使用一个名称即可。 |
| `bank_retention` | ↑ | 真值病灶“主体/堤岸”区域中仍预测为前景的比例 | 防止为了挖凹陷而把病灶本体削掉。是“凹陷恢复”和“病灶保留”的安全约束。 |
| `false_negative_fraction` | ↓ | 真值前景中未被预测为前景的比例 | 与 bank retention 互补；约等于前景漏检比例。 |
| `spurious_hole_fraction` | ↓ | 预测产生但真值不存在的孔洞面积 / 真值面积 | 检查网络是否为了制造凹陷而产生假孔洞。 |
| `cutout_recovery` | ↑ | 预测背景覆盖真值 cutout/凹陷区域的比例 | 评价普通凹陷恢复，不强调深度或是否与外界相连。 |
| `deep_cutout_recovery` | ↑ | 对凹陷深部像素加权后的恢复率 | 防止模型只恢复凹陷浅边缘而没有恢复最深处。 |
| `open_cutout_recovery` | ↑ | 只统计与图像外部背景连通的凹陷恢复率 | 检查开口型内凹边界是否真正打开，而不是制造孤立内孔。 |
| `open_deep_cutout_recovery` | ↑ | 同时考虑“外部连通”和“深部权重”的凹陷恢复率 | v2/v3 拓扑模型最重要的压力测试指标之一。 |
| `cutout_connectivity` | ↑ | 被恢复的凹陷背景中，与外部背景连通的比例 | 评价拓扑是否正确，防止孤立洞。 |
| `mouth_closure` | ↓（作为损失）/ ↑（作为恢复率时） | 凹陷开口处的 foreground 概率或开口闭合程度 | 训练时通常作为惩罚项；评价时要明确是 closure 还是 recovery。 |
| `mouth_contact_closure` | ↓（作为损失） | 凹陷与外部边界接触区域的闭合程度 | 比普通 mouth 更严格，直接针对边界接触点。 |
| `structural_joint` | ↑ | 几何平均 `foreground_iou × deep_cutout_recovery × bank_retention` | 同时奖励整体区域、深部凹陷和病灶主体保留。 |
| `topology_structural_joint` | ↑ | 几何平均 `foreground_iou × open_deep_cutout_recovery × bank_retention` | 比 structural joint 更严格地要求凹陷与外部背景连通。 |
| `bay_iou` | ↑ | 单个实例内凹 bay 区域的 IoU | 面向实例级内凹区域。 |
| `bay_depth_score` / `depth_score` | ↑ | `min(true_depth,pred_depth)/max(true_depth,pred_depth)` | 评价凹陷深度比例是否正确。 |
| `bay_direction_score` / `direction_score` | ↑ | 真值和预测凹陷方向余弦相似度映射到 `[0,1]` | 判断凹陷朝向是否正确，避免“方向反了”。 |
| `shortest_path_to_boundary` | ↓ | 凹陷或孔洞到外边界的最短路径长度 | 用于判定开口/外部连通，不是最终质量分数。 |
| `foreground_components` | 趋势指标 | 前景连通区域数 | 过多表示碎裂，过少可能表示病灶粘连。 |
| `holes` | 趋势指标 | 前景内部孔洞数 | 与真值对比，检查假洞或缺洞。 |
| `euler_characteristic` | 趋势指标 | `foreground_components - holes` | 粗粒度拓扑签名；应与真值拓扑一致。 |
| `class_1_components`, `class_2_components` | 趋势指标 | 每类连通组件数 | 检查类别级粘连/分裂。 |

### 凹陷联合评分如何解释

`foreground_iou` 负责“病灶整体有没有找对”；`notch_preservation`/`open_deep_cutout_recovery` 负责“内凹有没有挖出来”；`bank_retention` 负责“有没有把病灶主体误删”。因此本项目不应只用单一 IoU 宣称凹陷重建成功。

---

## 4. 多频 EIT 和频谱指标

| 指标 | 方向 | 含义与作用 |
|---|---:|---|
| `cross_frequency_support_consistency` | ↑ | 同一 phantom 各频率预测病灶支持区域之间的平均 Dice/一致性 | 检查频率改变的是电学强度，而不是病灶位置。 |
| `cross_frequency_prediction_correlation` | 视任务 | 不同频率预测场之间的相关性 | 过低可能表示几何漂移；过高也可能表示网络没有学到真实频散。 |
| `shared_geometry_dice` | ↑ | 共享几何分支与真实共享病灶支持的 Dice | 评价“共享几何”是否正确。 |
| `shared_geometry_frequency_contrast` | 组合表示 | `shared_geometry × frequency_contrast_f` | 不是单独分数，而是模型的结构分解形式。 |
| `frequency_contrast` | 视定义 | 每个频率的病灶电导率对比度 | 应与 lesion contrast MAE 或 spectrum MAE 一起看。 |
| `instance_mask_dice` | ↑ | 每个实例几何 mask 的 Dice | 评价多病灶定位和分离。 |
| `instance_spectrum_mae` | ↓ | 每个实例的跨频谱误差 | 评价逐病灶频散定量，避免全图平均掩盖病灶之间的差异。 |
| `lesion_count_accuracy` | ↑ | 预测病灶数量与真值一致的比例 | 检查多病灶漏检/粘连。 |
| `family_accuracy` / `stress_family_selection_accuracy` | ↑ | 形状族或压力测试类别预测正确率 | 仅在有形状族分类/选择器时使用。 |
| `noise_output_std` | ↓ | 对同一输入加入噪声后，输出场的标准差 | 越低表示对测量噪声越稳定，但过低可能表示过度平滑。 |

### Edinburgh 多频实验中使用的核心指标

`MAE`、`RMSE`、`SSIM`、`Dice`、`IoU`、`centroid_error_pixels`、`lesion_contrast_mae`、`background_false_positive`、`cross_frequency_support_consistency`，另有 `shared_geometry_dice`、`instance_mask_dice`、`instance_spectrum_mae`。

### 10/50 kHz 公共实体数据中使用的指标

`pseudo_gn_mae`、`pseudo_gn_relative_l2`、`pseudo_gn_correlation`、`pseudo_gn_ssim`、`noise_output_std`。这里的 `pseudo_gn_*` 是和公开作者 Gauss–Newton 重建的伪目标比较，不是真实电导率真值，因此只能解释为伪目标一致性和噪声稳定性，不能宣称真实病灶精度。

---

## 5. EIT 物理一致性和优化过程指标

### 5.1 电压/前向模型一致性

| 指标 | 方向 | 含义 |
|---|---:|---|
| `voltage_mse` | ↓ | 候选电导率经 forward solver 预测的电压与测量电压之间的 MSE | 评价候选形状是否符合测量数据。 |
| `relative_voltage_error` | ↓ | `||U_pred-U_measured||/||U_measured||` | 非线性 Gauss–Newton 的主要数据拟合指标。 |
| `clean_voltage_relative_error` | ↓ | 干净测量条件下的相对电压误差 | 诊断模型是否在正常输入上拟合。 |
| `background_voltage_relative_error` | ↓ | 背景电导率 forward 结果与参考电压的相对误差 | 验证 CEM/FEniCSX 背景实现和参考数据一致性。 |
| `voltage_error` | ↓ | 电压残差的泛称 | 需要查看具体脚本确认是 MAE、MSE 还是相对误差。 |
| `jacobian_relative_error` | ↓ | 两套 Jacobian 的相对差 | 用于验证 FEniCSX/CEM 与参考 Jacobian 是否一致，不是病灶重建质量。 |
| `predicted_voltage` | 诊断量 | 当前电导率重建 forward 得到的电压 | 与 measured voltage 一起检查残差。 |
| `physics_backprojection` | 中间量 | 将电压残差通过 Jacobian 回投影成图像 | 是 v6 的输入特征，不是最终指标。 |

### 5.2 非线性 Gauss–Newton / LM / TV 过程

| 指标 | 方向 | 含义与作用 |
|---|---:|---|
| `objective` / `total_loss` | ↓ | 总目标函数 | 通常等于 data + TV + L2 或其他加权项。 |
| `data_objective` / `data_loss` | ↓ | 电压数据拟合项 | 越低说明 forward 预测更贴近测量。 |
| `tv_objective` / `tv_loss` | ↓ | 总变分正则项 | 抑制噪声和局部振荡，过大权重会过度平滑。 |
| `l2_objective` / `l2_loss` | ↓ | 电导率或对数电导率的 L2 正则 | 稳定病态逆问题，抑制过大参数。 |
| `anchor_loss` | ↓ | 与初始/锚定重建的偏离惩罚 | 像素 refinement 中用于防止无约束漂移。 |
| `relative_step_norm` | ↓ | 当前 Gauss–Newton 更新步相对大小 | 变小通常表示接近收敛。 |
| `step_length` | 诊断量 | 线搜索接受的步长 | 经常变小说明目标面或初值困难。 |
| `damping` | 诊断量 | Levenberg–Marquardt 阻尼 | 大阻尼表示需要更保守更新。 |
| `min_conductivity`, `max_conductivity` | 约束量 | 当前重建电导率的最小/最大值 | 检查正值约束和物理范围是否生效。 |
| `converged` / `stop_reason` | 状态量 | 是否达到停止条件以及停止原因 | 不能只看最终 loss，还要知道是否线搜索失败或达到迭代上限。 |
| `final_total_loss` | ↓ | 最后一次迭代的总损失 | 只用于同一设置下比较，不能跨不同归一化直接比较。 |

### 5.3 DeepEIT/DIP+TV 专用过程量

| 指标 | 含义 |
|---|---|
| `DIP data_loss` | 网络输出经 CEM forward 后与测量电压的拟合项。 |
| `DIP tv_loss` | 网络输出图像的 TV 正则。 |
| `DIP total_loss` | `data_loss + tv_loss`（按实现中的权重）。 |
| `accepted/rejected iteration` | LSP/线搜索是否接受当前网络更新；拒绝点多或 loss 尖峰说明优化不稳定。 |
| `best_loss` / `minimum_loss` | 训练过程中达到的最小目标值。 |

---

## 6. v6 局部拓扑修正器的训练损失

这些是训练诊断，不应直接替代测试集指标。

| 字段 | 含义 |
|---|---|
| `raw_bce`, `raw_dice` | 原始 removal 场与真值 cutout 的 BCE/Dice 损失。 |
| `effective_bce`, `effective_dice` | 经过连通性和 local confidence 后的有效 removal 场损失。 |
| `mouth` / `mouth_bce` / `mouth_dice` | 凹陷开口区域预测损失。 |
| `final_bce`, `final_dice` | 最终 candidate 前景与真值前景的分割损失。 |
| `bank_loss` | 删除量落在真值病灶主体上的惩罚，防止挖凹陷时削掉病灶。 |
| `notch_fill` | 内凹区域仍被前景填充的惩罚；越低表示凹陷被挖出。 |
| `deep_fill` | 对凹陷深处加权后的填充惩罚。 |
| `outside_edit` | 在真实 cutout 之外发生删除的惩罚。 |
| `ordinary_edit` | 对没有凹陷的普通病例发生编辑的惩罚，保护普通病例。 |
| `area_budget` | 预测删除面积与目标删除面积之间的差异。 |
| `boundary` | 预测前景梯度与真值边界梯度的 L1 差异。 |
| `corrector_loss` / `training_loss` | 上述分量按权重加和的总训练损失。 |

---

## 7. 置信度、风险和选择器指标

v6 的最终输出不是强制使用 candidate，而是根据 truth-blind 特征决定使用 anchor 还是 candidate。

| 指标 | 方向 | 含义与作用 |
|---|---:|---|
| `confidence` / `mean_confidence` | ↑ | 模型对输出区域或病例的平均置信度 | 只能在校准良好时解释为质量信号。 |
| `local_confidence` | ↑ | 每个像素的局部置信度图 | 用于定位模型不确定区域，不等于真实概率。 |
| `confidence_vs_mae_pearson` | 理想为负 | 置信度与 MAE 的 Pearson 相关；高置信度应对应低 MAE | 若为正，说明置信度方向或校准存在问题。 |
| `confidence_vs_relative_l2_pearson` | 理想为负 | 置信度与相对 L2 的相关 | 同上。 |
| `confidence_corruption_auc` | ↑ | 用置信度区分 clean 与 prior-corrupted 样本的 ROC-AUC | 评价置信度是否能识别先验损坏。 |
| `mae_ece_like` | ↓ | 将 MAE 转为质量分数后，预测置信度与经验质量之间的分箱校准误差 | 越小越可靠。 |
| `selective_mae` | ↓ | 只保留最高置信度样本时的 MAE | 用于“选择性预测/拒答”性能。 |
| `coverage` | — | 被保留/接受的样本比例 | 必须与 selective MAE 一起看，不能只报告低误差。 |
| `mae_at_25pct/50pct/75pct/100pct` | ↓ | 在对应 coverage 下的 selective MAE | 反映置信度排序是否有用。 |
| `predicted_benefit_q20` | ↑ | gate 预测的 candidate 相对 anchor 的 notch benefit 的 20% 分位数 | 低分位数保证“最差情况下也可能有收益”。 |
| `predicted_iou_loss_q80` | ↓ | candidate 可能造成的 IoU 损失的 80% 分位数 | 作为风险上界；越小越安全。 |
| `predicted_bank_loss_q80` | ↓ | candidate 可能造成的 bank retention 损失的 80% 分位数 | 保护病灶主体。 |
| `gate_selected` / `selected_fraction` | — | 是否启用 candidate，以及启用比例 | 启用比例太高可能伤害普通病例，太低则方法退化为 anchor。 |
| `ordinary_severe` / `severe_iou_loss` | ↓ | 普通病例中 IoU 下降超过阈值的比例 | v6 的普通病例安全性指标。 |
| `harm_probability` / `max_harm_probability` | ↓ | 选择器估计 candidate 造成伤害的概率 | 用于安全门控。 |
| `component_removal` / `max_component_removal` | ↓ | candidate 删除完整病灶连通组件的比例/上限 | 防止错误删除主体。 |
| `risk_adjusted_selection_score` | ↑ | 收益减去风险惩罚后的选择分数 | 仅用于候选选择，不是普适物理指标。 |
| `safe_fallback` | 状态量 | 无候选满足安全条件时是否退回 anchor | 安全策略是否生效。 |

注意：本项目某些 confidence 实验使用的是“合成超声污染标签”，因此不能把 confidence 直接解释为临床不确定性。

---

## 8. 超声先验/配准鲁棒性指标

| 指标 | 方向 | 含义 |
|---|---:|---|
| `registration_loss` | ↓ | 学习 EIT 与超声之间空间变换的损失 | 训练目标，不等于重建误差。 |
| `theta_tx`, `theta_ty` | 接近真实变换 | 估计平移参数 | 是配准诊断量。 |
| `theta_a00`, `theta_a01`, `theta_a10`, `theta_a11` | 接近真实变换矩阵 | 估计旋转、缩放、剪切等仿射参数 | 用于检查网络是否学到配准。 |
| `correlation`, `relative_l2`, `mae` | 见第 1 节 | 在 clean、shift、rotate、blur、false-positive 条件下评价重建 | 比较鲁棒模型和 baseline。 |
| `mean_confidence` | ↑ | 各损坏条件下的平均信心 | 应与误差变化一起解释。 |
| `condition_summary` | — | 每个污染条件的样本数、均值误差和均值置信度 | 用于压力测试分层报告。 |

配准压力条件本身不是指标：`shift10px`、`rotate10deg`、`blur_sigma4`、`false_positive` 是测试条件。

---

## 9. 统计、复现和模型选择指标

| 指标/字段 | 含义与作用 |
|---|---|
| `mean` | 多样本或多随机种子的平均值。 |
| `std` / `std_iou` | 样本标准差或种子波动；报告稳定性。 |
| `median` | 中位数，降低异常病例影响。 |
| `delta` / `difference` | candidate - baseline 或 robust - baseline 的绝对变化。 |
| `relative_improvement_percent` | 相对改善百分比；对于误差指标应明确是下降。 |
| `bootstrap_ci95` / `bootstrap_95_ci` | bootstrap 得到的 95% 置信区间。 |
| `bootstrap_probability_improvement` / `P(>0)` | bootstrap 重采样中改善大于 0 的比例。 |
| `paired_win_rate` | 成对病例中候选方法优于基线的比例。 |
| `n` / `samples_total` / `independent_test_samples` | 统计样本量；样本量太小会使均值不稳定。 |
| `validation_loss` / `best_validation_loss` | 验证集损失，用于 checkpoint/early stopping 选择。 |
| `best_epoch` | 验证集最优 epoch。 |
| `parameters` | 网络参数量，用于复杂度和公平比较。 |
| `num_iter` / `epochs` | DIP 迭代次数或训练 epoch，不是质量指标，但决定可复现性。 |
| `selected_fraction` / `changed_cases` | 选择器实际改变了多少病例。 |
| `oracle_iou`, `oracle_score`, `oracle_accuracy` | 用真值选择最佳候选的上限分析；不能作为部署结果。 |
| `validation_score`, `selection_score`, `challenge_score`, `utility` | 加权综合分数，只能在相同定义、相同数据划分内比较。 |
| `author/bundled/reproduced score` | 作者输出、打包结果和本地复现结果的分数；用于复现对照。 |
| `mean_reproduced_mean_iou`, `mean_bundled_mean_iou` | ABC2 四例的平均 mean IoU。 |
| `reference_ktc_ssim`, `reproduced_ktc_ssim` | KTC 官方参考输出和本地复现的 KTC-SSIM。 |

### 前缀和后缀不是新指标

- 前缀 `base_`、`biological_`、`stress_`、`public_`、`ordinary_`、`concave_`：表示数据子集。
- 前缀 `anchor_`、`candidate_`、`gated_`、`routed_`、`direct_`、`raw_`、`protected_`、`oracle_`：表示预测路径。
- 后缀 `_mean`、`_std`、`_median`、`_delta`、`_ci95`：表示聚合方式。
- `strict_iou`、`oof_iou`、`pool_iou`、`ridge_iou`、`public_mean_iou` 等：表示评估协议或候选池不同，不能脱离协议直接横向比较。

---

## 10. 此前主要实验的指标快照

### 10.1 DeepEIT Case 1，5000 次迭代

| 方法 | SSIM | CC | PSNR (dB) | RE |
|---|---:|---:|---:|---:|
| 论文目标 | 0.870 | 0.960 | 23.0 | 0.016 |
| 本地 DeepEIT | 0.870 | 0.881 | 18.1 | 0.221 |
| NOSER | 0.784 | 0.803 | 14.5 | 0.338 |
| L2 | 0.062 | 0.123 | 10.7 | 0.521 |
| TV | 0.863 | 0.874 | 16.3 | 0.272 |

结论：SSIM 定性复现较好，但 CC、PSNR、RE 仍受网格、phantom、随机种子和未公开实现影响。

### 10.2 KTC2023-ABC2 旧 DIP+TV 本地复现

| 病例 | mean IoU | mean Dice | KTC-SSIM |
|---|---:|---:|---:|
| data1 | 0.7609 | 0.8641 | 0.8239 |
| data2 | 0.8076 | 0.8936 | 0.8936 |
| data3 | 0.8327 | 0.8996 | 0.8618 |
| data4 | 0.6522 | 0.7334 | 0.6304 |
| 平均 | 0.7634 | 0.8477 | 0.8024 |

### 10.3 corrected-v6 在同四例、4 个冻结种子上的 gated 结果

| 病例 | mean IoU | mean Dice | KTC-SSIM | 说明 |
|---|---:|---:|---:|---|
| data1 | 0.6175 ± 0.0752 | 0.7598 ± 0.0583 | 0.6624 ± 0.0915 | 明显低于旧 DIP+TV |
| data2 | 0.7028 ± 0.0598 | 0.8224 ± 0.0432 | 0.7764 ± 0.0750 | 低于旧 DIP+TV |
| data3 | 0.8732 ± 0.0242 | 0.9269 ± 0.0160 | 0.9066 ± 0.0285 | 高于旧 DIP+TV |
| data4 | 0.6517 ± 0.0213 | 0.7320 ± 0.0244 | 0.6493 ± 0.0386 | IoU 基本持平，SSIM 略高 |
| 平均 | 0.7113 | 0.8103 | 0.7487 | 尚未全面超过旧 DIP+TV |

### 10.4 Edinburgh 多频共享几何分解 pilot

| 指标 | 普通联合模型 | 共享几何分解 |
|---|---:|---:|
| MAE | 0.03314 ± 0.00179 | **0.02767 ± 0.00072** |
| RMSE | 0.10389 ± 0.00269 | **0.09637 ± 0.00167** |
| SSIM | 0.58791 ± 0.01506 | **0.65990 ± 0.00821** |
| Dice | 0.58515 ± 0.01599 | **0.64739 ± 0.00652** |
| IoU | 0.43188 ± 0.01620 | **0.49307 ± 0.00770** |
| 质心误差/像素 | 3.002 ± 0.047 | **2.485 ± 0.185** |
| 背景假阳性 | 0.02717 ± 0.00192 | **0.02104 ± 0.00074** |
| 跨频支持一致性 | 0.92503 ± 0.00204 | **0.96500 ± 0.00225** |
| 病灶内部对比度 MAE | **0.13313 ± 0.00281** | 0.14021 ± 0.00259 |

这说明共享几何改善定位和结构一致性，但简单乘法分解可能损害病灶内部频率强度定量。

---

## 11. 推荐论文最终报告的最小指标集合

如果最终写“面向内凹边界重建的物理与拓扑感知深度 EIT”，建议主表至少包含：

1. `foreground_iou`、`foreground_dice`：总体病灶区域。
2. `boundary_f1`：边界位置。
3. `notch_preservation` 或 `open_deep_cutout_recovery`：内凹趋势是否恢复。
4. `bank_retention`：病灶主体是否被保护。
5. `spurious_hole_fraction`、`false_negative_fraction`：拓扑副作用和漏检。
6. `KTC-SSIM`：若使用 ABC2，保留与旧论文复现的一致性指标。
7. `MAE`、`RMSE`、`relative L2`：若输出是连续电导率场。
8. `mean ± std`、bootstrap 95% CI、paired win rate：多种子和病例统计。
9. 普通病例与凹陷病例分层结果：不能只报凹陷测试集平均值。
10. `oracle` 结果只能作为上限分析，不能放在最终方法主结果列中。

最重要的判读原则是：**整体 IoU 证明“找到了病灶”，边界 F1 证明“边界位置较准”，凹陷恢复指标证明“凹进去的趋势被保留”，bank retention 证明“没有为了挖凹陷而毁掉病灶主体”，物理电压误差证明“结果仍然符合 EIT 测量”。**

