# Registration-Robust and Uncertainty-Aware Ultrasound-Guided EIT

## 1. 研究问题

超声先验在真实场景中可能存在平移、旋转、模糊、假病灶和分割错误。如果网络把超声当成绝对正确的 mask，先验错误会直接把重建结果拉向错误位置。本阶段验证一个更稳健的方案：

1. EIT 图像和电压特征由共享的物理引导网络编码；
2. 超声经过一个有边界的仿射空间变换模块，学习小范围配准；
3. 每个多尺度融合层预测空间置信度图；
4. 置信度低时抑制超声特征，自动回退到 EIT 分支；
5. 训练时随机注入配准扰动、模糊、假病灶和 modality dropout。

模型实现位于 `pytorch_eit/models.py` 的 `RegistrationRobustMultiModalEITNet`，训练脚本为 `train_registration_robust_multimodal.py`。

## 2. 数据和公平性

当前数据为 `datasets/multimodal_cem_v1.npz`，是由 CEM 仿真生成的多模态 proxy 数据：EIT 电压、EIT 基线图、目标电导率图和几何一致的超声样式图像。超声图像不是实测声学数据，因此本结果是方法学 pilot，不应表述为真实临床验证。

baseline 使用已有的 `outputs_pytorch_multimodal/model.pt`。鲁棒网络从该 baseline warm-start，仅新增配准与置信度模块随机初始化，从而避免“网络变复杂导致性能变化”与“鲁棒机制带来的收益”混淆。

测试条件：

| 条件 | 模拟退化 |
|---|---|
| clean | 超声 proxy 未扰动 |
| shift10px | 归一化坐标约 10 px 平移 |
| rotate10deg | 10° 旋转 |
| blur_sigma4 | 7×7 平均模糊，近似较强散斑/分辨率下降 |
| false_positive | 额外加入一个不对应 EIT 真值的亮斑 |

指标在圆形有效域内计算：相关系数越高越好，relative L2 和 MAE 越低越好。

## 3. 三随机种子结果

三次训练使用 seed=1、2、3，每次 20 epochs、24 个 base channels。下表为 mean ± standard deviation；baseline 是同一个冻结 checkpoint，因此其标准差为 0。

| 条件 | baseline corr | robust corr | baseline L2 | robust L2 | baseline MAE | robust MAE |
|---|---:|---:|---:|---:|---:|---:|
| clean | 0.97582 | 0.97355 ± 0.00011 | 0.10127 | 0.10606 ± 0.00027 | 0.03960 | 0.03607 ± 0.00017 |
| shift10px | 0.96670 | **0.97341 ± 0.00012** | 0.11969 | **0.10636 ± 0.00027** | 0.04738 | **0.03621 ± 0.00017** |
| rotate10deg | 0.97262 | **0.97351 ± 0.00011** | 0.10833 | **0.10614 ± 0.00028** | 0.04225 | **0.03610 ± 0.00017** |
| blur_sigma4 | 0.97438 | 0.97351 ± 0.00011 | 0.10430 | 0.10614 ± 0.00029 | 0.04055 | **0.03612 ± 0.00017** |
| false_positive | 0.97528 | 0.97357 ± 0.00012 | 0.10257 | 0.10603 ± 0.00029 | 0.04055 | **0.03603 ± 0.00016** |

五种条件平均：

- correlation：0.97296 → **0.97351**；
- relative L2：0.10723 → **0.10614**，下降约 1.0%；
- MAE：0.04207 → **0.03610**，下降约 14.2%。

只看四种受损超声条件时，relative L2 从 0.10872 降到 0.10617，MAE 从 0.04268 降到 0.03611。最明显的收益出现在平移和旋转误差：baseline 的性能下降被鲁棒模型大部分消除。

## 4. 机制消融

在同一个 seed=20260802 上进一步关闭一个模块：

| 变体 | registration | confidence gate | 平均 corr | 平均 relative L2 | 平均 MAE |
|---|---:|---:|---:|---:|---:|
| baseline | — | — | 0.97296 | 0.10723 | 0.04207 |
| robust full | ✓ | ✓ | **0.97357** | **0.10604** | 0.03612 |
| no registration | ✗ | ✓ | 0.97355 | 0.10611 | **0.03611** |
| no confidence | ✓ | ✗ | 0.97345 | 0.10627 | 0.03630 |

该消融说明当前数据上主要收益来自 confidence-aware fallback；registration 带来的增益较小，但在 relative L2 上仍略优于关闭 registration 的变体。后续扩大配准误差范围后，registration 分支才有可能体现更明显的独立贡献。

## 5. 图像结果

多条件的误差棒图：

![multi-seed metrics](outputs_registration_robust_multimodal_multiseed/multiseed_metrics.png)

同一个测试样本在五种条件下的 target、EIT baseline、受损超声、baseline 重建、robust 重建、学习到的 confidence map 和 robust 误差：

![example comparison](outputs_registration_robust_multimodal_warmstart/examples_comparison.png)

图中可以看到，robust 分支在超声平移/旋转时仍把两个病灶保持在正确位置；假病灶没有被直接复制到输出中。confidence map 不是人工指定的 mask，而是网络根据 EIT-US 特征一致性学习得到的软权重。

## 6. 当前能得到的论文结论

在当前仿真 proxy 数据上，可以支持如下较谨慎的结论：

> 通过 baseline warm-start、受限空间配准和多尺度不确定性门控，网络在超声存在配准误差或假阳性时，比直接使用超声融合的 baseline 更稳定；同时 MAE 在所有测试条件下降低。

不能声称“已经完成真实数据验证”或“在所有指标上全面优于 baseline”：clean 条件的相关系数和 relative L2 略差，blur 条件的相关系数也略差。当前更准确的创新表述是“退化超声先验下的性能保持和风险控制”，而非绝对精度全面提升。

## 6.1 公开真实 US-EIT 域外检查

工程中已有 12 个公开 US-EIT 样本。由于它们没有逐帧电导率真值，只能把作者提供的 GN 重建作为 pseudo-label，不能作为临床精度验证。将鲁棒 checkpoint 直接迁移到该数据后：

- 公开 baseline 多模态模型与 pseudo-GN 的 correlation：0.61797；
- 鲁棒模型 fusion correlation：0.60802；
- 鲁棒模型 EIT-only correlation：0.60455。

在同一个 robust checkpoint 上关闭 confidence gate 后，fusion correlation 降至 0.58573；这说明门控确实能缓解一部分域差异，但尚不足以超过专门训练的 synthetic baseline（0.61797）。

这说明当前模型存在明显的 CEM→真实设备域差异，不能把合成数据的提升直接外推到真实数据。图像输出见 `outputs_public_us_eit_robust/examples.png`。因此论文中应把这部分写成“域外可运行性检查和失败边界”，后续需要设备标定、真实 US-EIT 配准和无真值域适配，不能把 0.608 当成临床性能。

## 7. 下一步投稿级实验

1. 将单一固定 proxy 数据扩展为至少数百个 CEM phantom，改变病灶数量、位置、形状和电导率；
2. 用独立随机种子生成训练/验证/测试，不让测试 phantom 与训练分布重复；
3. 加入 2、5、10 mm 配准误差、不同模糊强度、缺失分割和多个假病灶；
4. 增加 EIT-only、直接拼接、硬 mask、软 mask、DIP+TV 和本方法六类对照；
5. 对 confidence map 做可靠性评估：把超声退化程度作为外部标签，计算 AUROC、风险-覆盖率曲线和 selective MAE；
6. 最后才接入真实或公开超声图像，先做跨模态域外测试，再考虑多频 EIT。

## 8. 可复现实验命令

```bash
source ~/miniforge3/etc/profile.d/conda.sh
conda activate gn4ip-env
cd /mnt/e/Codex/eit_reproduction

python train_registration_robust_multimodal.py \
  --epochs 20 --batch-size 32 --base-channels 24 \
  --output-dir outputs_registration_robust_multimodal_warmstart

python plot_registration_robust_examples.py

python aggregate_registration_robust_runs.py \
  --run outputs_registration_robust_multimodal_warm_seed1 \
  --run outputs_registration_robust_multimodal_warm_seed2 \
  --run outputs_registration_robust_multimodal_warm_seed3 \
  --output-dir outputs_registration_robust_multimodal_multiseed

python infer_public_us_eit_robust.py
```

完整论文式整理见 `PAPER_DRAFT_UNCERTAINTY_AWARE_US_EIT.md`。该版本进一步加入独立 v2 CEM 分布和连续平移/旋转/模糊应力测试。

独立 v2 结果位于 `outputs_registration_robust_crossdomain`，连续应力测试位于 `outputs_registration_robust_stress`，配对 bootstrap 统计位于 `outputs_registration_robust_bootstrap`。
