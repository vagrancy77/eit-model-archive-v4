function result = recompute_case_eidors(dataset_dir,case_id)
% Recompute a saved case through the unmodified public EIDORS fwd_solve API.
% mesh.fmdl is a TEMPLATE: insert case current, contact and sheet admittivity.
source_dir=fileparts(mfilename('fullpath')); addpath(fileparts(source_dir));
setup_third_party(false); eidors_msg('log_level',0);
if isnumeric(case_id); case_id=sprintf('case_%06d',case_id); end
d=load(fullfile(dataset_dir,'cases',[case_id '.mat']));
loaded=load(fullfile(dataset_dir,sprintf('mesh_%d.mat',d.meta.mesh_id)));
f=loaded.mesh.fmdl;
for e=1:16
    f.electrode(e).z_contact=d.meta.contact_impedance_ohm_m2(e)/d.meta.thickness_m;
    f.stimulation(e).stim_pattern=f.stimulation(e).stim_pattern*d.meta.current_A;
end
voltage=complex(zeros(208,2)); reference=voltage;
for k=1:2
    im=mk_image(f,1); im.elem_data=d.admittivity_elem(:,k)*d.meta.thickness_m;
    v=fwd_solve(im); voltage(:,k)=v.meas;
    im.elem_data(:)=d.meta.material_gamma_Sm(1,k)*d.meta.thickness_m;
    v=fwd_solve(im); reference(:,k)=v.meas;
end
result=struct('case_id',case_id, ...
    'voltage_relative_error',norm(voltage-d.voltage_clean,'fro')/norm(d.voltage_clean,'fro'), ...
    'reference_relative_error',norm(reference-d.voltage_reference,'fro')/norm(d.voltage_reference,'fro'));
assert(result.voltage_relative_error<1e-9 && result.reference_relative_error<1e-9);
fprintf('RECOMPUTE %s voltage=%.3g reference=%.3g\n',case_id,result.voltage_relative_error,result.reference_relative_error);
end
