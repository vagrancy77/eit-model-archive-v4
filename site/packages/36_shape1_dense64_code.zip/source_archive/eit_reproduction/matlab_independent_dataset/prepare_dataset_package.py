"""Prepare a portable dataset delivery, document contents, hash every file."""
from pathlib import Path
import argparse
import json
import hashlib
import shutil


def digest(file):
    h=hashlib.sha256()
    with file.open('rb') as f:
        for block in iter(lambda:f.read(2**20),b''):h.update(block)
    return h.hexdigest()


def main(root):
    root=root.resolve();source=Path(__file__).parent
    assert json.loads((root/'audit_summary.json').read_text())['audited_cases']==20000
    assert json.loads((root/'visual_review'/'browser_check.json').read_text())['status']=='passed'
    for name in ['build_visual_review.py','dataset_viewer.html','dataset_viewer.js','verify_viewer.cjs','prepare_dataset_package.py','start_here.html','verify_dataset_archive.py']:
        shutil.copy2(source/name,root/'source'/name)
    (root/'source_sha256.json').write_text(json.dumps({p.name:digest(p) for p in (root/'source').iterdir() if p.is_file()},indent=2),encoding='utf-8')
    # Relative links make the copied report readable after extraction elsewhere.
    report=(root/'DATASET_REPORT.md').read_text(encoding='utf-8')
    (root/'数据集报告_便携版.md').write_text(report.replace(root.as_posix()+'/',''),encoding='utf-8')
    shutil.copy2(source/'start_here.html',root/'开始查看.html')
    (root/'打包说明.txt').write_text('''EIDORS 独立内凹边界数据集：完整交付包

1. 请先把整个 ZIP 解压到一个目录。不要只在压缩包内双击页面。
2. 双击“开始查看.html”，或打开 visual_review/index.html。
   可以查看全部 20,000 个病例，按形状和数据划分筛选，或输入病例编号。
   查看图片与页面不需要安装 MATLAB、Python，也不需要联网。
3. 六张中文大图位于 visual_review：形状总览、复杂内凹、完整病例与拓扑标签、
   质量边缘病例、全量统计、噪声影响。原有英文预览保留在 previews。
4. cases 中有 20,000 个原始 MAT 文件；topology_targets 保存凹陷和距离图标签。
   manifest.csv 是固定划分；mesh_1/2/3.mat 是网格、电极和测量协议。
5. source 中保留生成、读取、审核与可视化脚本。MATLAB、EIDORS 和 Python 库
   本身不包含在压缩包中。读取 MAT 可使用 scipy.io.loadmat。
   source/dataset_loader.py 可作为 PyTorch 数据读取器；重跑 MATLAB 生成器
   仍需按 README 配置现有 EIDORS 工程路径。source 是代码快照，不是软件安装包。
6. PACKAGE_CONTENTS.sha256 记录包内每个数据/代码/图片文件的 SHA-256；
   PACKAGE_MANIFEST.json 记录数量。外部 ZIP.sha256 文件用于核验整个压缩包。

本版为二维、单病灶、均匀背景合成数据；器官名称只是几何启发。
图像中的蓝色形状和电导率是仿真真值，不是神经网络重建结果。
显示用导出的电压为 float32、边界坐标精度 0.01 mm；训练和定量分析以原始 MAT 为准。
旧 DATASET_REPORT.md 保留原绝对路径，“数据集报告_便携版.md”使用相对图片路径。
''',encoding='utf-8')
    files=[p for p in root.rglob('*') if p.is_file() and p.name not in ('PACKAGE_CONTENTS.sha256','PACKAGE_MANIFEST.json')]
    files.sort(key=lambda p:p.relative_to(root).as_posix())
    counts={'case_mat':len(list((root/'cases').glob('case_*.mat'))),
            'topology_npz':len(list((root/'topology_targets').glob('targets_*.npz'))),
            'viewer_case_shards':len(list((root/'visual_review'/'viewer_data').glob('cases_*.js')))}
    assert counts=={'case_mat':20000,'topology_npz':79,'viewer_case_shards':79}
    entries=[]
    for i,p in enumerate(files,1):
        entries.append(digest(p)+'  '+p.relative_to(root).as_posix())
        if i%5000==0:print(f'HASH {i}/{len(files)}',flush=True)
    (root/'PACKAGE_CONTENTS.sha256').write_text('\n'.join(entries)+'\n',encoding='utf-8')
    manifest={'dataset_name':root.name,'counts':counts,'hashed_files':len(files),'archive_expected_file_count':len(files)+2,
              'uncompressed_bytes_before_package_indexes':sum(p.stat().st_size for p in files),
              'raw_simulation_modified':False,'entry_page':'开始查看.html','browser_index':'visual_review/index.html'}
    (root/'PACKAGE_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(manifest,ensure_ascii=False,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);a=p.parse_args();main(a.root)
