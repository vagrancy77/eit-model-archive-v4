# 独立 EIDORS 内凹边界 EIT 仿真数据集

这个目录建立了与 KTC2023、此前 COMSOL 导出数据和旧线性化数据分开的生成流程。目标是比较算法在平滑内凹边界和普通凸形病例上的重建能力。本次只生成并审核数据，不训练网络。

## 输出位置与规模

正式目录：`E:/Codex/eit_reproduction/datasets/matlab_eidors_concave_v1`。

| 划分 | 独立病例数 | 用途 |
|---|---:|---|
| train | 14,000 | 训练；拟合归一化或其他统计量 |
| validation | 2,000 | 调参、早停、选择阈值 |
| test_id | 2,000 | 与训练同一采样规则的新几何 |
| test_ood | 2,000 | 椭圆/卵形外边界、更宽的位置/大小/材料参数及接触阻抗分布 |
| 合计 | 20,000 | 20,000 个独立几何，不把频率和噪声副本算作新病例 |

是否真正生成完，以 `generation_complete.json` 与 `audit_summary.json` 为准。`progress_worker_*.json` 只是进度。试跑的两个 pilot 目录不是正式训练集，正式种子与两批 pilot 均不同。

正式病例每例有 2 个频率和 4 档噪声。全部 16 个形状采样配置等量分配，每个配置 1,250 例，其中 25% 为凸形对照，75% 为内凹形状。

## 几何和生物学含义

形状包含椭圆、长椭圆、轻微分叶的凸形、卵巢启发椭圆、月牙、深月牙、宽 U、深 U、不对称 C、肾样、肺样、心形启发形状、切口椭圆、分叶内凹、凹陷内凸起、复合凹边变式。**这些是 16 种采样配置，部分几何分布有重叠；不是 16 类真实器官分割。**

生成器用椭圆/平滑分叶主体与椭圆切口的布尔差构造边界，再以约 1.8 mm 的形态学开运算圆滑尖端，并对边界弧长采样和平滑。局部改变切口的半径可以生成凹陷中的二级凸起。随机改变大小、长宽比、位置、方向和局部形变。

每例检查：一个连通病灶、无孔洞、没有孤立像素、与外边界有间隔、设计形状经过约 1.5 mm 腐蚀后不分裂、设计掩膜与实际 FEM 栅格标签 IoU 至少 0.88。后者是**标签离散化质量**，不是神经网络重建 IoU。亚毫米结构不属于本数据的可靠分辨尺度。

器官名称仅表示几何启发。没有临床图像或组织学证据，因此不能声称这些形状、电学参数对应确诊病灶，或代表真实器官解剖。本版每例一个病灶、均匀背景；不包含多病灶、血管、分层器官背景或超声图像。

## EIT 正问题

- MATLAB R2024b、EIDORS 3.12，二维一阶三角形完整电极模型 CEM。
- 圆形基准域半径 0.1 m；等效均匀挤出厚度 0.02 m。
- 44 层网格，7,744 个三角形、3,961 个组织节点。
- 16 个有限宽度电极，每个电极多个边界节点；每例独立的非零接触阻抗。
- 相邻注流、相邻电极差分测量；排除涉及注流电极的测量，保留互易重复，共 16 × 13 = 208 项。
- 10 kHz 与 50 kHz；电流约 1 mA，病例间轻微变化。
- 每个病例每个频率分别求解病灶与匹配背景参考，共 4 次完整正问题。不是 Jacobian 线性化生成，也没有复用固定病例的电压模板。

二维单位采用薄片形式：传入 EIDORS 的单元参数为 `h * gamma`，单位 S；二维接触阻抗为 `z_3d / h`，单位 Ω·m；注入电流为真实电流 A。保存的 `admittivity_elem` 与 `sigma_grid` 是物理材料参数 S/m，**不包含厚度因子**。`contact_impedance_ohm_m2` 是三维面比接触阻抗 Ω·m²。不要把这套参数直接混用到忽略厚度的二维正问题中。

电极电势保存为每次注流下的电极均值为零；所有 EIT 输入均由差分电压组成，与参考电势选择无关。内部电势未作为网络输入或必需字段。

`eidors_forward_cached.m` 只缓存 EIDORS 的几何矩阵 `system_mat_fields`；每例重新组装复系数 CEM 矩阵并解方程。启动时在三个外边界上逐一与原生 `fwd_solve` 对照；每例检查离散方程残差和互易性。它是同一离散 EIDORS 方程的批量计算实现，不是近似代理网络。

## 双频材料和噪声

背景和病灶均采用被动的单松弛频散模型：

\[
\gamma(f)=\sigma_\infty+\frac{\sigma_0-\sigma_\infty}{1+jf/f_c}+j2\pi f\epsilon_0\epsilon_\infty.
\]

两频率共享病灶几何，电导率 `real(gamma)` 和虚部一般不同。参数按病例采样；这是一套受约束的合成材料假设，不是从真实组织数据库拟合的 Cole–Cole 参数。双频可以验证重建或融合，不足以唯一反演全部四个材料参数。

保存 clean 测量和 40/50/60/70 dB 的复高斯噪声版本。SNR 定义为每个频率全部 208 个绝对电压的二范数比；每次生成后缩放噪声到精确目标 SNR。病灶和参考噪声分别独立生成，所以相减后噪声更大。**这里的 40 dB 不是病灶差分信号的 40 dB**，不能混淆。噪声暂未包含电子学漂移、通道相关误差或系统性伪影。

## 每个 MAT 文件有什么

全部使用 MATLAB v7 格式，Python `scipy.io.loadmat(..., simplify_cells=True)` 可直接读取。

| 字段 | 形状 | 含义 |
|---|---|---|
| voltage_clean | 208 × 2 complex | 病灶病例的绝对边界差分电压，V |
| voltage_reference | 208 × 2 complex | 同频率、同接触阻抗、同电流的均匀参考，V |
| voltage_difference | 208 × 2 complex | clean 病灶减 clean 参考 |
| voltage_noisy / reference_noisy | 208 × 2 × 4 complex | 按 noise_snr_db 的四档噪声版本 |
| electrode_voltage / electrode_reference | 16 × 16 × 2 complex | 电极 × 注流 × 频率的完整电极电压，V |
| admittivity_elem | 7,744 × 2 complex | 正问题实际使用的材料复导纳率，S/m |
| lesion_elem | 7,744 | 0=背景，1=病灶 |
| mask_fem | 128 × 128 uint8 | 将实际 FEM 标签投影到图像网格，建议作为监督真值 |
| mask_design | 128 × 128 uint8 | 原始平滑多边形的设计真值，供形状/离散化分析 |
| sigma_grid | 128 × 128 × 2 float32 | 实际 FEM 电导率栅格，S/m |
| admittivity_imag_grid | 同上 | 复导纳率虚部，S/m，不是介电常数 |
| polygon_m | N × 2 | 平滑设计边界，单位 m |
| meta | struct | 病例 ID、划分、种子、频率、电流、厚度、材料参数、接触阻抗和质检指标 |

三个 `mesh_*.mat` 保存完整 EIDORS `fmdl`、节点/三角形、域掩膜、坐标轴、电极位置、长度、注流/测量矩阵，以及 `measurement_table`。后者每行为 `[注流序号, 正注流电极, 负注流电极, 正测量电极, 负测量电极]`，电极编号从 1 开始。

其中 `mesh.fmdl` 是单位电流、单位二维接触阻抗的**模板**。重算某病例时必须从 `meta` 写入实际电流、接触阻抗与厚度，并把物理导纳率乘厚度；不能直接把模板与 `sigma_grid` 交给求解器。`recompute_case_eidors(dataset_dir, case_id)` 已完整实现这一过程，并与原文件逐项对照。

图像行方向对应从小到大的 y，列方向对应从小到大的 x。显示时使用 `origin='lower'`。域外的电导率以零占位，必须用 `domain_mask` 排除域外损失和统计。不同模型的域掩膜不同。

## 复现与读取

在 MATLAB 中：

```matlab
addpath('E:/Codex/eit_reproduction/matlab_independent_dataset');
generate_eidors_concave_dataset( ...
  'E:/Codex/eit_reproduction/datasets/my_new_eidors_dataset', ...
  [14000 2000 2000 2000], 20261006);
```

每例随机种子为 `base_seed + case_index * 7919`。增加数据量请使用新的输出目录和种子；现有目录只支持相同配置下续跑。每个划分的数量需为 16 的倍数。源代码快照保存在数据目录 `source/`，续跑会检查生成代码一致。

大批量可在独立 MATLAB 进程中用末尾两个参数 `(worker_index, workers)` 切分互不重叠的病例编号。先启动 worker 1，确认目录/config 已创建后再启动其他 worker。所有 worker 完成后：

```powershell
python matlab_independent_dataset/finalize_dataset.py datasets/matlab_eidors_concave_v1 --workers 6
python matlab_independent_dataset/audit_and_preview.py datasets/matlab_eidors_concave_v1
```

PyTorch 读取器：

```python
from matlab_independent_dataset.dataset_loader import EIDORSConcavityDataset
from torch.utils.data import DataLoader
ds = EIDORSConcavityDataset('datasets/matlab_eidors_concave_v1',
                           split='train', noise_db=50)
batch = next(iter(DataLoader(ds, batch_size=16, shuffle=True)))
print(batch['voltage'].shape)       # [16, 8, 208]
print(batch['sigma_target'].shape)  # [16, 2, 128, 128]
```

输入通道为两频率的绝对电压实/虚部及差分实/虚部，以各频率参考测量 RMS 归一化。返回的标签和 `domain_mask` 是独立字段，不进入电压输入。训练划分中的统计量才能用于拟合全局预处理。既有 KTC/v6 网络若使用不同电极数量/输入维度，必须修改输入适配并重新训练；本数据不能假定与原检查点直接兼容。

**如果预测绝对电导率，网络还必须接收 `measurement_context`**：两个参考 RMS 的 log10、电流/1mA、厚度/20mm。只取归一化后的 `voltage` 会丢失绝对尺度信息；不能再假定绝对电导率可辨识。`reference_rms_V` 也单独返回，方便恢复原始电压。以上都是已知测量/仪器信息，没有提供病灶真值参数。

`topology_targets/` 另存设计凸包、凸包减病灶得到的凹陷区，以及实际 FEM 掩膜的有符号距离图（内部为负，单位 mm）。这些是从真值派生的**监督标签**，不是额外可测输入。生成命令为 `python matlab_independent_dataset/generate_topology_targets.py datasets/matlab_eidors_concave_v1`。读取器设置 `topology_targets=True` 时返回 `concavity_target` 和 `sdf_target_mm`；默认关闭以简化基本 EIT 读取。

所有同一病例的频率和噪声版本必须留在同一划分。OOD 集改变的是域和参数分布，形状族仍有重叠；不能将其描述为完全未见形状类别或跨仿真器/临床外部验证。正式论文还应固定测试集、给出凸形与内凹分组指标，并避免在测试集上选规则。

## 主要脚本

- `generate_eidors_concave_dataset.m`：采样参数、调用正问题、生成噪声、保存数据/进度/清单。
- `make_biological_shape.m`：形状构建、圆滑、连通性和设计/FEM 一致性筛选。
- `eidors_mesh.m`：三个域的 CEM 网格、电极与测量协议。
- `eidors_forward_cached.m`：缓存几何后的逐例完整 CEM 组装与求解。
- `validate_mesh_refinement.m`：相同设计几何在 30,976 单元网格上重算，量化离散敏感性。
- `finalize_dataset.py`：合并 worker 清单，确认编号、数量、种子和文件齐全，保存代码校验和。
- `audit_and_preview.py`：逐例核对复数电压、标签、拓扑、噪声、重复掩膜并输出图片。
- `dataset_loader.py`：MAT 数据的 NumPy/PyTorch 读取。
- `recompute_case_eidors.m`：从保存的数据恢复病例，通过 EIDORS 原生入口重算。
- `generate_topology_targets.py` / `audit_topology_targets.py`：派生并审核凹陷区域和边界距离监督标签。
- `verify_saved_cases.m`：对 32 个固定病例执行原生重算和网格细化检查。
- `write_final_report.py`：确认全量检查完成后生成交付报告。

EIDORS 来源：<https://eidors3d.sourceforge.net/>；本地版本源码位于 `third_party/eidors/eidors`。公开数据或论文结果未混入这一独立仿真集。
