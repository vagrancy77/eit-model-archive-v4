function ctx = eidors_mesh(rings, domain_kind, grid_size)
% EIDORS first-order CEM, 16 finite-width electrodes, physical SI units.
% 2D formulation uses sheet admittivity h*gamma (S) and z_2d=z_3d/h (ohm m).
f=mk_circ_tank(rings,[],16);
angle=atan2(f.nodes(:,2),f.nodes(:,1));
r=sqrt(sum(f.nodes.^2,2));
half_width=4*pi/176; % 8.18 degrees total arc; identical ends on 44/88 rings
for e=1:16
    a=(e-1)*2*pi/16;
    da=atan2(sin(angle-a),cos(angle-a));
    f.electrode(e).nodes=find(r>.999 & abs(da)<half_width+1e-8)';
    assert(numel(f.electrode(e).nodes)>=3);
    f.electrode(e).z_contact=1; % unit z_2d for precomputed CEM factors
end
f.nodes=.1*f.nodes;
if strcmp(domain_kind,'ellipse')
    f.nodes=f.nodes.*[1.08 .90];
elseif strcmp(domain_kind,'ovoid')
    a=atan2(f.nodes(:,2),f.nodes(:,1));
    f.nodes=f.nodes.*(1+.065*cos(3*a)+.035*sin(2*a));
end
f.stimulation=mk_stim_patterns(16,1,[0 1],[0 1], ...
    {'no_meas_current','no_rotate_meas','do_redundant'},1);
f.normalize_measurements=0;
f.solve=@fwd_solve_1st_order; f.system_mat=@system_mat_1st_order;
f.jacobian=@jacobian_adjoint;
ctx.fmdl=f; ctx.FC=system_mat_fields(f);
ctx.pp=fwd_model_parameters(f,'skip_VOLUME');
ctx.ne=size(f.elems,1); ctx.nn=size(f.nodes,1);
ctx.keep=setdiff(1:size(ctx.FC,2),f.gnd_node);
ctx.cem_electrode=zeros(size(ctx.FC,1)-2*ctx.ne,1);
k=0;
for e=1:16
    hit=all(ismember(f.boundary,f.electrode(e).nodes),2);
    n=2*sum(hit); ctx.cem_electrode(k+(1:n))=e; k=k+n;
end
assert(k==numel(ctx.cem_electrode) && all(ctx.cem_electrode>0));
ctx.elem_xy=(f.nodes(f.elems(:,1),:)+f.nodes(f.elems(:,2),:)+f.nodes(f.elems(:,3),:))/3;
ctx.axis_m=linspace(-.115,.115,grid_size);
[xx,yy]=meshgrid(ctx.axis_m); ctx.grid_xy=[xx(:) yy(:)];
tr=triangulation(f.elems,f.nodes); ids=pointLocation(tr,ctx.grid_xy);
ctx.domain_mask=reshape(~isnan(ids),grid_size,grid_size);
ids(isnan(ids))=1; ctx.grid_elem=ids;
ctx.boundary_xy=f.nodes(unique(f.boundary(:)),:);
[~,o]=sort(atan2(ctx.boundary_xy(:,2),ctx.boundary_xy(:,1)));
ctx.boundary_xy=ctx.boundary_xy(o,:);
ctx.electrode_xy=zeros(16,2); ctx.electrode_length_m=zeros(16,1);
for e=1:16
    ctx.electrode_xy(e,:)=mean(f.nodes(f.electrode(e).nodes,:),1);
    b=f.boundary(all(ismember(f.boundary,f.electrode(e).nodes),2),:);
    ctx.electrode_length_m(e)=sum(vecnorm(f.nodes(b(:,1),:)-f.nodes(b(:,2),:),2,2));
end
ctx.current_pattern=full(horzcat(f.stimulation.stim_pattern));
ctx.measurement_pattern=zeros(13,16,16); ctx.measurement_table=zeros(208,5); k=0;
for s=1:16
    m=full(f.stimulation(s).meas_pattern); ctx.measurement_pattern(:,:,s)=m;
    for q=1:size(m,1)
        k=k+1; ctx.measurement_table(k,:)=[s find(ctx.current_pattern(:,s)>0) find(ctx.current_pattern(:,s)<0) find(m(q,:)>0) find(m(q,:)<0)];
    end
end
end
