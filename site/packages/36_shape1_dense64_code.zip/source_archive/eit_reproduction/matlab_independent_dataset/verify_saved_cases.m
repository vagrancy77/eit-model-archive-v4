function verify_saved_cases(out_dir)
indices=[1:16 18001:18016]; results=cell(size(indices));
for k=1:numel(indices)
    results{k}=recompute_case_eidors(out_dir,indices(k));
end
fid=fopen(fullfile(out_dir,'native_eidors_recomputation.json'),'w');
fprintf(fid,'%s',jsonencode(results,'PrettyPrint',true)); fclose(fid);
validate_mesh_refinement(out_dir,indices);
end
