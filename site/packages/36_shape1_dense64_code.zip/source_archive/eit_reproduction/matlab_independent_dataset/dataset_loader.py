"""MAT v7 -> NumPy/PyTorch. All frequencies/noise versions share one case split."""
import csv
import json
from pathlib import Path
import numpy as np
from scipy.io import loadmat


class EIDORSConcavityDataset:
    """Duck-typed torch Dataset; no torch import required for file validation.

    Input: 8 x 208 measured voltage channels, normalized with reference RMS.
    Channels: real(v)[2], imag(v)[2], real(v-vref)[2], imag(v-vref)[2].
    Targets: 2 x 128 x 128 physical conductivity and 1 x 128 x 128 FEM mask.
    No internal potential, lesion parameters, or truth masks enter the input.
    noise_db=None selects clean data; otherwise 40, 50, 60, or 70.
    """
    def __init__(self, root, split="train", noise_db=None, as_torch=True, topology_targets=False):
        self.root=Path(root); self.noise_db=noise_db; self.as_torch=as_torch
        with (self.root/"manifest.csv").open(encoding="utf-8-sig",newline="") as f:
            self.rows=[r for r in csv.DictReader(f) if r["split"]==split]
        if not self.rows: raise ValueError(f"No cases for split {split}")
        if noise_db not in (None,40,50,60,70): raise ValueError("noise_db must be None, 40, 50, 60, or 70")
        self.meshes={i:loadmat(self.root/f"mesh_{i}.mat",simplify_cells=True)["mesh"] for i in (1,2,3)}
        self.topology_index=json.loads((self.root/'topology_targets'/'index.json').read_text()) if topology_targets else None
        self._topology_file=None; self._topology_data=None

    def __len__(self): return len(self.rows)

    def __getitem__(self, index):
        row=self.rows[index]; d=loadmat(self.root/row["file"],simplify_cells=True)
        if self.noise_db is None:
            v,vh=d["voltage_clean"].T,d["voltage_reference"].T
        else:
            j=[40,50,60,70].index(self.noise_db)
            v,vh=d["voltage_noisy"][:,:,j].T,d["reference_noisy"][:,:,j].T
        scale=np.maximum(np.sqrt(np.mean(abs(vh)**2,axis=1,keepdims=True)),1e-12)
        vv=v/scale; dv=(v-vh)/scale
        x=np.concatenate([vv.real,vv.imag,dv.real,dv.imag],axis=0).astype(np.float32)
        result={"voltage":x,"sigma_target":d["sigma_grid"].transpose(2,0,1).astype(np.float32),
                "mask_target":d["mask_fem"][None].astype(np.float32),
                "domain_mask":self.meshes[int(row["mesh_id"])]["domain_mask"][None].astype(np.float32),
                "reference_rms_V":scale[:,0].astype(np.float32),
                "measurement_context":np.array([*np.log10(scale[:,0]),d['meta']['current_A']/.001,d['meta']['thickness_m']/.02],dtype=np.float32),
                "frequency_hz":np.array([10000,50000],dtype=np.float32),"case_id":row["case_id"]}
        if self.topology_index is not None:
            item=self.topology_index[row['case_id']]
            if self._topology_file!=item['file']:
                with np.load(self.root/item['file']) as z:
                    self._topology_data={k:z[k] for k in ('concavity_design','sdf_fem_mm')}
                self._topology_file=item['file']
            result['concavity_target']=self._topology_data['concavity_design'][item['offset']][None].astype(np.float32)
            result['sdf_target_mm']=self._topology_data['sdf_fem_mm'][item['offset']][None].astype(np.float32)
        if self.as_torch:
            import torch
            result={k:torch.from_numpy(v.copy()) if isinstance(v,np.ndarray) else v for k,v in result.items()}
        return result
