function generate_eidors_concave_dataset(out_dir,counts,base_seed,worker_index,workers)
% Generate independent, reproducible nonlinear EIDORS CEM cases. No training.
% counts=[train validation test_id test_ood]; resume existing complete cases.
if nargin<1; out_dir=fullfile(fileparts(fileparts(mfilename('fullpath'))),'datasets','matlab_eidors_concave_v1'); end
if nargin<2; counts=[14000 2000 2000 2000]; end
if nargin<3; base_seed=20261004; end
if nargin<4; worker_index=1; end
if nargin<5; workers=1; end
source_dir=fileparts(mfilename('fullpath')); root=fileparts(source_dir);
addpath(root); setup_third_party(false); eidors_msg('log_level',0);
eidors_cache('cache_size',64*1024^2); maxNumCompThreads(2);
assert(exist('bwconncomp','file')==2,'Image Processing Toolbox is required for topology checks.');
assert(numel(counts)==4 && all(counts>=0) && all(mod(counts,16)==0));
assert(worker_index>=1 && worker_index<=workers);
if ~isfolder(out_dir); mkdir(out_dir); end
if ~isfolder(fullfile(out_dir,'cases')); mkdir(fullfile(out_dir,'cases')); end
if ~isfolder(fullfile(out_dir,'source')); mkdir(fullfile(out_dir,'source')); end
config=struct('schema_version','1.0','counts',counts,'seed',base_seed, ...
    'frequency_hz',[10000 50000],'grid_size',128,'rings',44, ...
    'thickness_m',.02,'current_A',.001,'solver','EIDORS 3.12 first-order CEM; cached FC assembly', ...
    'material_model','passive single-Debye admittivity; synthetic parameters, not tissue measurements', ...
    'intended_use','simulation methodology; boundary voltage to conductivity reconstruction', ...
    'limits','2D extrusion, one lesion, isotropic piecewise-constant material; no ultrasound or clinical claims');
cfg_path=fullfile(out_dir,'configuration.json');
if isfile(cfg_path)
    old=jsondecode(fileread(cfg_path));
    assert(isequal(old.counts(:),counts(:)) && old.seed==base_seed,'Existing dataset configuration differs. Use a new directory.');
else; write_json(cfg_path,config); end
if worker_index==1
    source_files=dir(fullfile(source_dir,'*.m'));
    for s=1:numel(source_files)
        original=fullfile(source_dir,source_files(s).name); snapshot=fullfile(out_dir,'source',source_files(s).name);
        if isfile(snapshot)
            assert(strcmp(fileread(original),fileread(snapshot)),'Generator changed since dataset creation. Use a new output directory.');
        else; copyfile(original,snapshot); end
    end
end
families={'ellipse','oval','convex_lobule','ovary_like','crescent','deep_crescent', ...
    'wide_U','deep_U','asymmetric_C','kidney_like','lung_like','heart_like', ...
    'notched_oval','lobulated_notch','crescent_bulge','compound_notch'};
split_names={'train','validation','test_id','test_ood'};
contexts={eidors_mesh(44,'circle',128),eidors_mesh(44,'ellipse',128),eidors_mesh(44,'ovoid',128)};
for m=1:3
    c=contexts{m}; mesh=rmfield(c,{'FC','pp','keep','cem_electrode','grid_xy','elem_xy','grid_elem'}); %#ok<NASGU>
    if worker_index==1; save(fullfile(out_dir,sprintf('mesh_%d.mat',m)),'mesh','-v7'); end
end
% This test is independent of the morphology seeds and compares against the
% public EIDORS fwd_solve entry point, not only an internal residual.
rng(77); checks=cell(1,3);
for m=1:3
    c=contexts{m}; gamma=.3+.5*rand(c.ne,1)+1i*.05*rand(c.ne,1);
    z=.001+rand(16,1)*.003; [vc,~,ck]=eidors_forward_cached(c,gamma,z,.02,.001);
    f=c.fmdl;
    for e=1:16; f.electrode(e).z_contact=z(e)/.02; f.stimulation(e).stim_pattern=f.stimulation(e).stim_pattern*.001; end
    im=mk_image(f,1); im.elem_data=gamma*.02; ve=fwd_solve(im);
    ck.eidors_relative_error=norm(vc-ve.meas)/norm(ve.meas);
    assert(ck.eidors_relative_error<1e-9 && ck.residual<1e-9 && ck.reciprocity<1e-9);
    checks{m}=ck;
end
write_json(fullfile(out_dir,sprintf('solver_verification_worker_%d.json',worker_index)),checks);
fprintf('VERIFIED cached solver vs EIDORS: max relative error %.3g\n',max(cellfun(@(x)x.eidors_relative_error,checks)));
N=sum(counts); started=tic; new_count=0; last_print=tic;
indices=(worker_index-1)*ceil(N/workers)+1:min(worker_index*ceil(N/workers),N);
rows=cell(numel(indices),16); completed=0;
for i=indices
    sp=find(i<=cumsum(counts),1); is_ood=sp==4;
    family=families{mod(i-1,16)+1}; seed=base_seed+i*7919;
    case_name=sprintf('case_%06d',i); file=fullfile(out_dir,'cases',[case_name '.mat']);
    if isfile(file)
        a=load(file,'meta'); meta=a.meta;
    else
        rng(seed,'twister');
        mesh_id=1;
        if is_ood; mesh_id=2+mod(i,2); end
        c=contexts{mesh_id}; shape=make_biological_shape(family,is_ood,c);
        material=zeros(2,4); % sigma0 S/m, sigma_inf S/m, relaxation Hz, epsilon_inf
        material(1,:)=[.28+.32*rand 0 10000+70000*rand 50+200*rand];
        material(1,2)=material(1,1)*(.10+.45*rand)+material(1,1);
        if rand<.5; ratio=.25+.50*rand; else; ratio=1.30+1.10*rand; end
        material(2,:)=[material(1,1)*ratio 0 8000+90000*rand 70+280*rand];
        material(2,2)=material(2,1)*(1.10+.75*rand);
        if is_ood; material(:,3)=material(:,3).*(.65+1.4*rand(2,1)); end
        f_hz=config.frequency_hz; material_gamma=complex(zeros(2,2));
        for k=1:2
            material_gamma(:,k)=material(:,2)+(material(:,1)-material(:,2))./(1+1i*f_hz(k)./material(:,3))+1i*2*pi*f_hz(k)*8.8541878128e-12*material(:,4);
        end
        z3d=.0015*exp((.20+.25*is_ood)*randn(16,1));
        current=.001*(1+.04*(rand-.5)); h=config.thickness_m;
        gamma_elem=material_gamma(double(shape.lesion_elem)+1,:);
        voltage_clean=complex(zeros(208,2)); voltage_reference=voltage_clean;
        electrode_voltage=complex(zeros(16,16,2)); electrode_reference=electrode_voltage;
        residual=0; reciprocity=0;
        for k=1:2
            [voltage_clean(:,k),electrode_voltage(:,:,k),ck]=eidors_forward_cached(c,gamma_elem(:,k),z3d,h,current);
            [voltage_reference(:,k),electrode_reference(:,:,k),cr]=eidors_forward_cached(c,repmat(material_gamma(1,k),c.ne,1),z3d,h,current);
            residual=max([residual ck.residual cr.residual]); reciprocity=max([reciprocity ck.reciprocity cr.reciprocity]);
        end
        assert(all(isfinite(voltage_clean),'all') && residual<1e-9 && reciprocity<1e-9);
        noise_snr_db=[40 50 60 70];
        voltage_noisy=complex(zeros(208,2,4)); reference_noisy=voltage_noisy;
        for j=1:4
            for k=1:2
                eta=randn(208,1)+1i*randn(208,1); eta=eta/norm(eta)*norm(voltage_clean(:,k))*10^(-noise_snr_db(j)/20);
                voltage_noisy(:,k,j)=voltage_clean(:,k)+eta;
                eta=randn(208,1)+1i*randn(208,1); eta=eta/norm(eta)*norm(voltage_reference(:,k))*10^(-noise_snr_db(j)/20);
                reference_noisy(:,k,j)=voltage_reference(:,k)+eta;
            end
        end
        sigma_grid=reshape(real(gamma_elem(c.grid_elem,:)),128,128,2);
        admittivity_imag_grid=reshape(imag(gamma_elem(c.grid_elem,:)),128,128,2);
        sigma_grid(repmat(~c.domain_mask,1,1,2))=0; admittivity_imag_grid(repmat(~c.domain_mask,1,1,2))=0;
        meta=struct('case_id',case_name,'index',i,'seed',seed,'split',split_names{sp}, ...
            'family',family,'mesh_id',mesh_id,'frequency_hz',f_hz,'current_A',current, ...
            'thickness_m',h,'contact_impedance_ohm_m2',z3d,'material_parameters',material, ...
            'material_gamma_Sm',material_gamma,'parameters',shape.parameters, ...
            'is_concave',shape.is_concave,'concavity_fraction',shape.concavity_fraction, ...
            'concavity_depth_mm',shape.depth_m*1000,'area_mm2',shape.area_m2*1e6, ...
            'design_fem_iou',shape.shape_iou,'shape_attempts',shape.attempts, ...
            'residual_relative',residual,'reciprocity_relative',reciprocity, ...
            'voltage_change_relative',norm(voltage_clean-voltage_reference,'fro')/norm(voltage_reference,'fro'));
        data=struct('meta',meta,'voltage_clean',voltage_clean,'voltage_reference',voltage_reference, ...
            'voltage_difference',voltage_clean-voltage_reference,'voltage_noisy',voltage_noisy, ...
            'reference_noisy',reference_noisy,'noise_snr_db',noise_snr_db, ...
            'electrode_voltage',electrode_voltage,'electrode_reference',electrode_reference, ...
            'admittivity_elem',gamma_elem,'lesion_elem',shape.lesion_elem, ...
            'mask_design',shape.mask_design,'mask_fem',shape.mask_fem, ...
            'sigma_grid',single(sigma_grid),'admittivity_imag_grid',single(admittivity_imag_grid), ...
            'polygon_m',shape.polygon_m);
        tmp=[file '.partial']; save(tmp,'-struct','data','-v7'); movefile(tmp,file);
        new_count=new_count+1;
    end
    completed=completed+1;
    rows(completed,:)={meta.case_id,meta.split,meta.family,meta.seed,meta.mesh_id,meta.is_concave, ...
        meta.concavity_fraction,meta.concavity_depth_mm,meta.area_mm2,meta.design_fem_iou, ...
        meta.shape_attempts,meta.residual_relative,meta.reciprocity_relative, ...
        meta.voltage_change_relative,meta.current_A,['cases/' meta.case_id '.mat']};
    if completed==1 || mod(completed,128)==0 || toc(last_print)>30 || completed==numel(indices)
        elapsed=toc(started); seconds_case=elapsed/max(new_count,1);
        fprintf('PROGRESS worker=%d %d/%d case=%d new=%d elapsed=%.1fs sec/new=%.3f estimated_remaining=%.1fmin\n',worker_index,completed,numel(indices),i,new_count,elapsed,seconds_case,(numel(indices)-completed)*seconds_case/60);
        write_json(fullfile(out_dir,sprintf('progress_worker_%d.json',worker_index)),struct('completed',completed,'total',numel(indices),'elapsed_seconds',elapsed,'seconds_per_new_case',seconds_case));
        last_print=tic;
    end
end
headers={'case_id','split','family','seed','mesh_id','is_concave','concavity_fraction', ...
    'concavity_depth_mm','area_mm2','design_fem_iou','shape_attempts','residual_relative', ...
    'reciprocity_relative','voltage_change_relative','current_A','file'};
writecell([headers;rows],fullfile(out_dir,sprintf('manifest_worker_%d.csv',worker_index)));
write_json(fullfile(out_dir,sprintf('generation_complete_worker_%d.json',worker_index)),struct('count',numel(indices),'elapsed_seconds',toc(started),'new_count',new_count));
if workers==1
    copyfile(fullfile(out_dir,'manifest_worker_1.csv'),fullfile(out_dir,'manifest.csv'));
    copyfile(fullfile(out_dir,'generation_complete_worker_1.json'),fullfile(out_dir,'generation_complete.json'));
end
fprintf('COMPLETE worker=%d %d cases in %s\n',worker_index,numel(indices),out_dir);
end

function write_json(path,value)
fid=fopen([path '.partial'],'w'); assert(fid>=0); fprintf(fid,'%s',jsonencode(value,'PrettyPrint',true)); fclose(fid); movefile([path '.partial'],path);
end
