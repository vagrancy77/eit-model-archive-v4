"""Validate every derived supervision mask and signed-distance map."""
import argparse
import json
from pathlib import Path
import numpy as np
from scipy.io import loadmat
from scipy import ndimage


def audit(root):
    index=json.loads((root/'topology_targets'/'index.json').read_text())
    seen=set(); checked=0; recomputed=0
    for file in sorted((root/'topology_targets').glob('targets_*.npz')):
        with np.load(file) as z:
            ids=z['case_index']; hulls=z['hull_design']; bays=z['concavity_design']; sdf=z['sdf_fem_mm']; dx=float(z['pixel_spacing_mm'])
            assert hulls.shape==bays.shape==sdf.shape==(len(ids),128,128)
            assert np.isfinite(sdf).all() and np.max(abs(sdf))<400
            for offset,i in enumerate(ids):
                key=f'case_{i:06d}'; assert key not in seen; seen.add(key)
                assert index[key]['file']==str(file.relative_to(root)).replace('\\','/')
                assert index[key]['offset']==offset
                d=loadmat(root/'cases'/f'{key}.mat',simplify_cells=True,variable_names=['mask_design','mask_fem'])
                design=d['mask_design'].astype(bool); fem=d['mask_fem'].astype(bool)
                assert np.array_equal(hulls[offset].astype(bool)&~design,bays[offset].astype(bool))
                assert np.array_equal(sdf[offset]<0,fem)
                assert np.all(hulls[offset][design])
                if offset==0:
                    expected=(ndimage.distance_transform_edt(~fem)-ndimage.distance_transform_edt(fem))*dx
                    assert np.allclose(sdf[offset],expected,rtol=1e-6,atol=1e-5); recomputed+=1
                checked+=1
        if checked%2048==0: print(f'TOPOLOGY AUDIT {checked}',flush=True)
    expected=sum(json.loads((root/'configuration.json').read_text())['counts'])
    assert checked==expected==len(index)
    summary={'cases_checked':checked,'case_index_and_sign_consistency':'passed','concavity_mask_consistency':'passed',
             'distance_maps_fully_recomputed':recomputed,'status':'passed'}
    (root/'topology_targets'/'audit.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('root',type=Path); a=p.parse_args(); audit(a.root)
