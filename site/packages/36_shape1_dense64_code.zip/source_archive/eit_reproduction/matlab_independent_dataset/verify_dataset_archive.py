"""Read every ZIP member, check SHA-256 against the packaged source manifest."""
from pathlib import Path
import hashlib
import json
import zipfile
import argparse


def digest_stream(stream):
    h=hashlib.sha256()
    for block in iter(lambda:stream.read(2**20),b''):h.update(block)
    return h.hexdigest()


def verify(archive):
    prefix='matlab_eidors_concave_v1/'
    with zipfile.ZipFile(archive) as z:
        names=[info.filename for info in z.infolist() if not info.is_dir()]
        assert len(names)==len(set(names)), 'Duplicate archive entries'
        lines=z.read(prefix+'PACKAGE_CONTENTS.sha256').decode('utf-8').splitlines()
        expected={name:sha for sha,name in (line.split('  ',1) for line in lines)}
        manifest=json.loads(z.read(prefix+'PACKAGE_MANIFEST.json'))
        assert set(names)=={prefix+p for p in expected}|{prefix+'PACKAGE_CONTENTS.sha256',prefix+'PACKAGE_MANIFEST.json'}
        assert len(names)==manifest['archive_expected_file_count']
        for i,(name,sha) in enumerate(expected.items(),1):
            with z.open(prefix+name) as f:
                actual=digest_stream(f)  # Also triggers ZIP CRC checks on read.
            assert sha==actual, f'Hash mismatch: {name}'
            if i%5000==0:print(f'ARCHIVE VERIFIED {i}/{len(expected)}',flush=True)
        assert sum(n.startswith(prefix+'cases/case_') and n.endswith('.mat') for n in names)==20000
    with archive.open('rb') as f:sha=digest_stream(f)
    archive.with_suffix(archive.suffix+'.sha256').write_text(sha+'  '+archive.name+'\n',encoding='utf-8')
    result={'status':'passed','archive':str(archive.resolve()),'archive_bytes':archive.stat().st_size,
            'sha256':sha,'archive_files':len(names),'content_hashes_verified':len(expected),
            'case_mat_files':20000,'crc_check':'all file entries read successfully'}
    archive.with_suffix('.verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('archive',type=Path);a=p.parse_args();verify(a.archive)
