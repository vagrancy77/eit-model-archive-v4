"""Optional LABELS for concavity/SDF supervision. No forward data are modified."""
import argparse
import json
from pathlib import Path
import numpy as np
from scipy.io import loadmat
from scipy import ndimage
from scipy.spatial import ConvexHull
from matplotlib.path import Path as PolygonPath


def generate(root, ready_only=False, chunk_size=256):
    config=json.loads((root/"configuration.json").read_text())
    total=sum(config['counts']); dest=root/"topology_targets"; dest.mkdir(exist_ok=True)
    axis=np.linspace(-.115,.115,128); xx,yy=np.meshgrid(axis,axis)
    points=np.column_stack([xx.ravel(),yy.ravel()]); step_mm=(axis[1]-axis[0])*1000
    index={}; completed=0
    for lo in range(1,total+1,chunk_size):
        hi=min(lo+chunk_size,total+1); ids=list(range(lo,hi))
        target=dest/f"targets_{lo:06d}_{hi-1:06d}.npz"
        paths=[root/"cases"/f"case_{i:06d}.mat" for i in ids]
        if not all(p.is_file() for p in paths):
            if ready_only: continue
            raise FileNotFoundError(f"Incomplete block beginning {lo}")
        if not target.exists():
            hulls=[]; bays=[]; distances=[]
            for path in paths:
                d=loadmat(path,simplify_cells=True,variable_names=['polygon_m','mask_design','mask_fem'])
                polygon=d['polygon_m']; h=polygon[ConvexHull(polygon).vertices]
                h=np.vstack([h,h[:1]])
                hull=PolygonPath(h).contains_points(points,radius=1e-12).reshape(128,128)
                design=d['mask_design'].astype(bool); fem=d['mask_fem'].astype(bool)
                hull |= design
                bay=hull & ~design
                # Convention: negative inside lesion, positive outside, units mm.
                sdf=(ndimage.distance_transform_edt(~fem)-ndimage.distance_transform_edt(fem))*step_mm
                hulls.append(hull.astype(np.uint8)); bays.append(bay.astype(np.uint8)); distances.append(sdf.astype(np.float32))
            with target.with_suffix('.partial').open('wb') as f:
                np.savez_compressed(f,case_index=np.array(ids,dtype=np.int32),
                                    hull_design=np.stack(hulls),concavity_design=np.stack(bays),
                                    sdf_fem_mm=np.stack(distances),pixel_spacing_mm=np.float64(step_mm))
            target.with_suffix('.partial').replace(target)
        for offset,i in enumerate(ids):
            index[f'case_{i:06d}']={'file':str(target.relative_to(root)).replace('\\','/'),'offset':offset}
        completed+=len(ids)
        print(f'TOPOLOGY {completed}/{total}',flush=True)
    (dest/'index.json').write_text(json.dumps(index,separators=(',',':')),encoding='utf-8')
    (dest/'description.json').write_text(json.dumps({
        'cases':completed,'expected':total,'complete':completed==total,'chunk_size':chunk_size,
        'concavity_design':'convex hull of analytic design polygon minus design mask; label only',
        'sdf_fem_mm':'signed Euclidean distance transform of FEM mask; negative inside; label only',
        'limits':'Distances on a 128x128 raster, not subpixel geometric distances. Not an independent modality.'},indent=2),encoding='utf-8')


if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('root',type=Path); p.add_argument('--ready-only',action='store_true')
    a=p.parse_args(); generate(a.root,a.ready_only)
