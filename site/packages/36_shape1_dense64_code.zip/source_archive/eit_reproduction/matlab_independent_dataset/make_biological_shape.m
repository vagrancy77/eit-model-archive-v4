function g = make_biological_shape(family,is_ood,ctx)
% Smooth synthetic morphology, not segmented clinical anatomy.
t=(0:255)'*2*pi/256;
for attempt=1:250
    concave=~ismember(family,{'ellipse','oval','convex_lobule','ovary_like'});
    a=.021+.018*rand; b=a*(.70+.4*rand);
    if strcmp(family,'lung_like'); a=.85*a; b=1.20*b; end
    if strcmp(family,'ovary_like'); b=.72*a; end
    if is_ood; a=a*(.80+.40*rand); end
    radial=ones(size(t));
    if ismember(family,{'lobulated_notch','lung_like','heart_like','compound_notch'})
        radial=1+(.045+.035*rand)*cos(3*t+2*pi*rand)+.025*sin(2*t+2*pi*rand);
    elseif strcmp(family,'convex_lobule')
        radial=1+.025*cos(3*t+2*pi*rand);
    elseif strcmp(family,'oval')
        b=.56*a;
    end
    body=polyshape(a*radial.*cos(t),b*radial.*sin(t),'Simplify',false);
    cut=struct('cx',0,'cy',0,'ax',0,'ay',0,'bump',0);
    if concave
        cx=.68+.14*rand; ax=.75+.08*rand; ay=.58+.12*rand;
        switch family
            case 'crescent'; cx=.58+.16*rand; ax=.83; ay=.83;
            case 'deep_crescent'; cx=.38+.12*rand; ax=.87; ay=.81;
            case 'wide_U'; cx=.70; ax=1.02; ay=.52+.08*rand;
            case 'deep_U'; cx=.58; ax=1.12; ay=.43+.12*rand;
            case 'asymmetric_C'; cx=.54; ax=.91; ay=.74;
            case 'kidney_like'; cx=1.25; ax=.78; ay=.64;
            case 'lung_like'; cx=1.20; ax=.83; ay=.53;
            case 'heart_like'; cx=1.12; ax=.64; ay=.46;
            case 'notched_oval'; cx=1.00; ax=.76; ay=.46;
            case 'lobulated_notch'; cx=.83; ax=.94; ay=.58;
            case 'crescent_bulge'; cx=.46; ax=.88; ay=.80;
            case 'compound_notch'; cx=.64; ax=.95; ay=.61;
        end
        cy=(rand-.5)*.16;
        cut=struct('cx',cx*a,'cy',cy*b,'ax',ax*a,'ay',ay*b,'bump',0);
        rr=ones(size(t));
        if ismember(family,{'crescent_bulge','compound_notch','lobulated_notch'})
            % Reduce the cutting ellipse locally: tissue bulges into the indentation.
            phi=pi+(.65*rand-.325); d=atan2(sin(t-phi),cos(t-phi));
            amp=.13+.12*rand; rr=rr-amp*exp(-(d/.32).^2);
            if is_ood || strcmp(family,'compound_notch')
                d2=atan2(sin(t-pi-.58),cos(t-pi-.58)); rr=rr-.10*exp(-(d2/.25).^2);
            end
            cut.bump=amp;
        end
        hole=polyshape(cut.cx+cut.ax*rr.*cos(t),cut.cy+cut.ay*rr.*sin(t),'Simplify',false);
        body=subtract(body,hole);
    end
    if body.NumRegions~=1 || body.NumHoles~=0; continue; end
    % Morphological opening imposes a millimetre-scale rounded tip instead
    % of retaining the sharp cusps from subtracting two ellipses.
    body=polybuffer(polybuffer(body,-.0018),.0018);
    if body.NumRegions~=1 || body.NumHoles~=0; continue; end
    % Arc-length resampling + periodic Gaussian smoothing round Boolean corners.
    xy=body.Vertices; xy=[xy;xy(1,:)]; ds=[0;cumsum(vecnorm(diff(xy),2,2))];
    [ds,iu]=unique(ds); xy=xy(iu,:);
    s=linspace(0,ds(end),385)'; s(end)=[];
    p=interp1(ds,xy,s,'linear'); w=(-7:7)'; w=exp(-w.^2/(2*3^2)); w=w/sum(w);
    q=zeros(size(p));
    for k=1:numel(w); q=q+w(k)*circshift(p,k-8,1); end
    body=polyshape(q(:,1),q(:,2));
    if body.NumRegions~=1 || body.NumHoles~=0; continue; end
    % Reject bridges smaller than approximately 3 mm in the design geometry.
    eroded=polybuffer(body,-.0015);
    if eroded.NumRegions~=1; continue; end
    h=convhull(q); hullarea=polyarea(q(h,1),q(h,2));
    concavity=1-area(body)/hullarea;
    if concave && (concavity<.035 || concavity>.64); continue; end
    if ~concave && concavity>.004; continue; end
    rot=2*pi*rand; R=[cos(rot) -sin(rot);sin(rot) cos(rot)];
    centre=(rand(1,2)-.5)*.088;
    if is_ood; centre=(rand(1,2)-.5)*.104; end
    q=q*R'+centre;
    if max(vecnorm(q,2,2))>.085; continue; end
    mask=inpolygon(ctx.grid_xy(:,1),ctx.grid_xy(:,2),q(:,1),q(:,2));
    le=inpolygon(ctx.elem_xy(:,1),ctx.elem_xy(:,2),q(:,1),q(:,2));
    if nnz(le)<80; continue; end
    fem=le(ctx.grid_elem)&ctx.domain_mask(:);
    iou=nnz(mask&fem)/nnz(mask|fem);
    if iou<.88; continue; end
    gm=reshape(mask,size(ctx.domain_mask)); fm=reshape(fem,size(gm));
    if bwconncomp(gm,8).NumObjects~=1 || bwconncomp(fm,8).NumObjects~=1; continue; end
    if any(imfill(gm,'holes')~=gm,'all') || any(imfill(fm,'holes')~=fm,'all'); continue; end
    ch=convhull(q); hp=q(ch,:); depth=zeros(size(q,1),1);
    for k=1:size(q,1)
        u=hp(1:end-1,:); v=hp(2:end,:)-u;
        z=max(0,min(1,sum((q(k,:)-u).*v,2)./sum(v.^2,2)));
        depth(k)=min(vecnorm(q(k,:)-(u+z.*v),2,2));
    end
    if concave && max(depth)<.002; continue; end
    g=struct('polygon_m',q,'lesion_elem',uint8(le),'mask_design',uint8(gm), ...
        'mask_fem',uint8(fm),'family',family,'is_concave',concave, ...
        'shape_iou',iou,'concavity_fraction',concavity,'depth_m',max(depth), ...
        'area_m2',polyarea(q(:,1),q(:,2)),'attempts',attempt, ...
        'parameters',struct('axes_m',[a b],'centre_m',centre,'rotation_rad',rot,'cut',cut));
    return
end
error('dataset:ShapeFailed','Could not produce valid %s shape after 250 attempts',family);
end
