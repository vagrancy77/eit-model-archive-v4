"""Merge disjoint MATLAB worker manifests and verify completion before publishing."""
import argparse
import csv
import hashlib
import json
from pathlib import Path


def finalize(root, workers):
    config=json.loads((root/"configuration.json").read_text())
    rows=[]; timings=[]
    for worker in range(1,workers+1):
        timings.append(json.loads((root/f"generation_complete_worker_{worker}.json").read_text()))
        with (root/f"manifest_worker_{worker}.csv").open(encoding="utf-8-sig",newline="") as f:
            reader=csv.DictReader(f); fields=reader.fieldnames; rows.extend(reader)
    rows.sort(key=lambda r:r["case_id"])
    expected=sum(config["counts"])
    assert len(rows)==expected and len({r['case_id'] for r in rows})==expected
    assert len({r['seed'] for r in rows})==expected
    for i,row in enumerate(rows,1):
        assert row['case_id']==f'case_{i:06d}' and (root/row['file']).is_file()
    with (root/"manifest.csv").open("w",encoding="utf-8",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=fields); writer.writeheader(); writer.writerows(rows)
    checksums={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/"source").glob("*") if p.is_file()}
    (root/"source_sha256.json").write_text(json.dumps(checksums,indent=2),encoding="utf-8")
    summary={"count":expected,"workers":workers,"worker_timings":timings,
             "sample_bytes":sum((root/r['file']).stat().st_size for r in rows)}
    (root/"generation_complete.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
    print(json.dumps(summary,indent=2))


if __name__=="__main__":
    parser=argparse.ArgumentParser(); parser.add_argument("root",type=Path); parser.add_argument("--workers",type=int,default=3)
    args=parser.parse_args(); finalize(args.root,args.workers)
