function validate_mesh_refinement(out_dir,case_indices)
% Independent mesh-resolution check on exactly the same analytic polygons.
source_dir=fileparts(mfilename('fullpath')); addpath(fileparts(source_dir));
setup_third_party(false); eidors_msg('log_level',0); maxNumCompThreads(2);
eidors_cache('cache_size',64*1024^2);
if nargin<2; case_indices=[1:16 18001:18016]; end
fine={eidors_mesh(88,'circle',128),eidors_mesh(88,'ellipse',128),eidors_mesh(88,'ovoid',128)};
rows=cell(numel(case_indices),6);
for j=1:numel(case_indices)
    d=load(fullfile(out_dir,'cases',sprintf('case_%06d.mat',case_indices(j))));
    m=d.meta; c=fine{m.mesh_id}; p=d.polygon_m;
    label=inpolygon(c.elem_xy(:,1),c.elem_xy(:,2),p(:,1),p(:,2));
    v=complex(zeros(208,2)); vh=v;
    for k=1:2
        gamma=m.material_gamma_Sm(double(label)+1,k);
        v(:,k)=eidors_forward_cached(c,gamma,m.contact_impedance_ohm_m2,m.thickness_m,m.current_A);
        vh(:,k)=eidors_forward_cached(c,repmat(m.material_gamma_Sm(1,k),c.ne,1),m.contact_impedance_ohm_m2,m.thickness_m,m.current_A);
    end
    relative=norm(v-d.voltage_clean,'fro')/norm(v,'fro');
    reference=norm(vh-d.voltage_reference,'fro')/norm(vh,'fro');
    differential=norm((v-vh)-d.voltage_difference,'fro')/norm(v-vh,'fro');
    rows(j,:)={m.case_id,m.family,m.split,relative,reference,differential};
    fprintf('REFINEMENT %s abs=%.3f%% ref=%.3f%% delta=%.3f%%\n',m.case_id,100*relative,100*reference,100*differential);
end
writecell([{'case_id','family','split','voltage_relative_error','reference_relative_error','difference_relative_error'};rows],fullfile(out_dir,'mesh_refinement.csv'));
summary=struct('coarse_elements',7744,'fine_elements',30976,'cases',numel(case_indices), ...
    'max_absolute_voltage_relative_error',max(cell2mat(rows(:,4))), ...
    'median_absolute_voltage_relative_error',median(cell2mat(rows(:,4))), ...
    'max_difference_voltage_relative_error',max(cell2mat(rows(:,6))), ...
    'median_difference_voltage_relative_error',median(cell2mat(rows(:,6))), ...
    'interpretation','Resolution sensitivity, not proof of continuum convergence. Fine/coarse share physical electrodes and design geometry.');
fid=fopen(fullfile(out_dir,'mesh_refinement_summary.json'),'w'); fprintf(fid,'%s',jsonencode(summary,'PrettyPrint',true)); fclose(fid);
end
