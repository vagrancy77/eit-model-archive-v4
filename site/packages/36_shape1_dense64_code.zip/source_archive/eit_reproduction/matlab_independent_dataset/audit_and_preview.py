"""Independent numerical/file audit and scientific previews; never trains a model."""
from __future__ import annotations

import argparse
import collections
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy import ndimage
from scipy.io import loadmat


def read(path):
    return loadmat(path, simplify_cells=True)


def audit(root: Path, limit: int | None):
    files = sorted((root / "cases").glob("case_*.mat"))
    if limit:
        files = files[:limit]
    meshes = {i: read(root / f"mesh_{i}.mat")["mesh"] for i in (1, 2, 3)}
    families, splits, hashes, examples = collections.Counter(), collections.Counter(), {}, {}
    rows, failures, duplicates = [], [], []
    error_max = collections.defaultdict(float)
    for i, path in enumerate(files):
        d = read(path)
        m = d["meta"]
        mesh = meshes[int(m["mesh_id"])]
        try:
            v, vh = d["voltage_clean"], d["voltage_reference"]
            assert v.shape == (208, 2) and np.isfinite(v).all()
            assert np.isfinite(vh).all() and np.iscomplexobj(v)
            assert d["voltage_noisy"].shape == (208, 2, 4)
            assert d["sigma_grid"].shape == (128, 128, 2)
            assert np.min(d["admittivity_elem"].real) > 0
            assert np.min(d["admittivity_elem"].imag) >= 0
            assert np.linalg.norm(v[:, 0] - v[:, 1]) > 1e-12
            assert np.array_equal(d["voltage_difference"], v - vh)
            el = d["lesion_elem"].astype(int)
            mg = m["material_gamma_Sm"]
            assert np.allclose(d["admittivity_elem"], mg[el], rtol=1e-12, atol=1e-14)
            for key in ("mask_design", "mask_fem"):
                a = d[key].astype(bool)
                assert ndimage.label(a, np.ones((3, 3)))[1] == 1, key + " disconnected"
                assert np.array_equal(ndimage.binary_fill_holes(a), a), key + " has holes"
                assert not np.any(a & ~mesh["domain_mask"].astype(bool))
            a, b = d["mask_design"].astype(bool), d["mask_fem"].astype(bool)
            iou = np.sum(a & b) / np.sum(a | b)
            assert abs(iou - m["design_fem_iou"]) < 1e-10 and iou >= .88
            domain = mesh["domain_mask"].astype(bool)
            for f in range(2):
                truth = mg[d["mask_fem"].astype(int), f].real
                assert np.allclose(d["sigma_grid"][..., f][domain], truth[domain], rtol=1e-6)
            meas = mesh["measurement_pattern"]
            for key, vk in (("electrode_voltage", v), ("electrode_reference", vh)):
                for f in range(2):
                    recovered = np.concatenate([meas[:, :, s] @ d[key][:, s, f] for s in range(16)])
                    rel = np.linalg.norm(recovered-vk[:, f])/np.linalg.norm(vk[:, f])
                    error_max["electrode_to_measurement_relative"] = max(error_max["electrode_to_measurement_relative"], float(rel))
                    assert rel < 1e-10
            for key, clean in (("voltage_noisy", v), ("reference_noisy", vh)):
                eta = d[key] - clean[..., None]
                snr = 20*np.log10(np.linalg.norm(clean, axis=0)[:, None]/np.linalg.norm(eta, axis=0))
                error = np.max(np.abs(snr-d["noise_snr_db"]))
                error_max["snr_error_db"] = max(error_max["snr_error_db"], float(error))
                assert error < 1e-6
            assert float(m["residual_relative"]) < 1e-9
            assert float(m["reciprocity_relative"]) < 1e-9
            for key in ("residual_relative", "reciprocity_relative"):
                error_max[key] = max(error_max[key], float(m[key]))
            key = hashlib.sha256(np.packbits(d["mask_design"]).tobytes()).hexdigest()
            if key in hashes:
                duplicates.append([hashes[key], m["case_id"]])
            hashes[key] = m["case_id"]
        except Exception as exc:
            failures.append({"file": path.name, "error": str(exc) or type(exc).__name__})
        families[m["family"]] += 1
        splits[m["split"]] += 1
        examples.setdefault(m["family"], []).append(path)
        rows.append({k: m[k] for k in ("case_id", "family", "split", "concavity_fraction", "concavity_depth_mm", "design_fem_iou", "voltage_change_relative")})
        if (i+1) % 1000 == 0:
            print(f"AUDIT {i+1}/{len(files)} failures={len(failures)}", flush=True)
    summary = {"audited_cases": len(files), "complete_generation": (root/"generation_complete.json").exists(),
               "failures": failures, "duplicate_design_masks": duplicates, "families": dict(families),
               "splits": dict(splits), "max_errors": dict(error_max),
               "design_fem_iou": {"min": float(min(r["design_fem_iou"] for r in rows)),
                                  "mean": float(np.mean([r["design_fem_iou"] for r in rows]))},
               "concavity_depth_mm": {"min": float(min(r["concavity_depth_mm"] for r in rows)),
                                       "max": float(max(r["concavity_depth_mm"] for r in rows))}}
    (root/"audit_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)
    make_previews(root, examples, meshes, rows)
    assert not failures and not duplicates, "Dataset audit failed; inspect audit_summary.json"
    return summary


def draw_shape(ax, d, mesh, title, crop=False):
    x = mesh["axis_m"]*1000
    a = np.ma.masked_where(~mesh["domain_mask"].astype(bool), d["mask_fem"])
    ax.imshow(a, origin="lower", extent=[x[0],x[-1],x[0],x[-1]], cmap="Blues", vmin=0, vmax=1, interpolation="nearest")
    p = d["polygon_m"]*1000
    ax.plot(*np.vstack([p,p[:1]]).T, color="#e66d28", lw=1)
    if crop:
        lo, hi = p.min(axis=0)-6, p.max(axis=0)+6
        width = max(hi-lo)
        centre = (lo+hi)/2
        ax.set_xlim(centre[0]-width/2,centre[0]+width/2)
        ax.set_ylim(centre[1]-width/2,centre[1]+width/2)
    else:
        b = mesh["boundary_xy"]*1000
        ax.plot(*np.vstack([b,b[:1]]).T, color="#63758a", lw=.7)
        e=mesh["electrode_xy"]*1000
        ax.scatter(e[:,0],e[:,1],s=8,c="#566575",zorder=3)
    ax.set_aspect("equal"); ax.set_title(title, fontsize=9); ax.set_xticks([]); ax.set_yticks([])


def make_previews(root, examples, meshes, rows):
    out = root/"previews"; out.mkdir(exist_ok=True)
    fig, axes = plt.subplots(4,4,figsize=(12,12),layout="constrained")
    for ax,(family,paths) in zip(axes.flat,examples.items()):
        d = read(paths[0]); m = d["meta"]
        draw_shape(ax,d,meshes[int(m["mesh_id"])],f"{family}\n{m['case_id']} | depth {m['concavity_depth_mm']:.1f} mm")
    fig.suptitle("16 smooth morphology families | blue: FEM truth; orange: design boundary",fontsize=14)
    fig.savefig(out/"shape_family_catalog.png",dpi=160); plt.close(fig)
    complex_names = ["deep_U","deep_crescent","crescent_bulge","compound_notch","lobulated_notch","kidney_like"]
    fig,axes=plt.subplots(6,6,figsize=(14,14),layout="constrained")
    for row,family in enumerate(complex_names):
        paths=examples[family]
        picks=np.linspace(0,len(paths)-1,6).astype(int)
        for col,k in enumerate(picks):
            d=read(paths[k]); m=d["meta"]
            draw_shape(axes[row,col],d,meshes[int(m["mesh_id"])],f"{family}\n{m['case_id']} ({m['split']})",crop=True)
    fig.suptitle("Concave geometry detail | smooth synthetic shapes, not clinical segmentations",fontsize=14)
    fig.savefig(out/"complex_concavity_gallery.png",dpi=160); plt.close(fig)
    selected=["ellipse","deep_U","crescent_bulge","lung_like"]
    fig,axes=plt.subplots(4,4,figsize=(16,13),layout="constrained")
    for row,family in enumerate(selected):
        d=read(examples[family][0]); m=d["meta"]; mesh=meshes[int(m["mesh_id"])]; x=mesh["axis_m"]*1000
        draw_shape(axes[row,0],d,mesh,f"{family}\n{m['case_id']}")
        for f in range(2):
            z=np.ma.masked_where(~mesh["domain_mask"].astype(bool),d["sigma_grid"][...,f])
            im=axes[row,f+1].imshow(z,origin="lower",extent=[x[0],x[-1],x[0],x[-1]],cmap="viridis",vmin=d['sigma_grid'][mesh['domain_mask'].astype(bool)].min(),vmax=d['sigma_grid'].max())
            axes[row,f+1].set_title(f"{[10,50][f]} kHz conductivity (S/m)"); axes[row,f+1].set_xticks([]); axes[row,f+1].set_yticks([])
            fig.colorbar(im,ax=axes[row,f+1],shrink=.7)
        for f,color in enumerate(["#2761ad","#ce6928"]):
            dv=d["voltage_difference"][:,f]*1000
            axes[row,3].plot(dv.real,color=color,lw=.8,label=f"{[10,50][f]} kHz real")
            axes[row,3].plot(dv.imag,color=color,lw=.7,ls="--",label=f"{[10,50][f]} kHz imag")
        axes[row,3].set_title("Lesion - reference voltage (mV)"); axes[row,3].set_xlabel("measurement index (208)"); axes[row,3].legend(fontsize=7)
    fig.suptitle("Paired nonlinear CEM outputs | same geometry, frequency-dependent admittivity",fontsize=14)
    fig.savefig(out/"paired_eit_examples.png",dpi=160); plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(14,4),layout="constrained")
    axes[0].hist([r['concavity_depth_mm'] for r in rows],bins=35,color="#297dad"); axes[0].set_xlabel("Geometric concavity depth (mm)")
    axes[1].hist([r['design_fem_iou'] for r in rows],bins=35,color="#659b72"); axes[1].set_xlabel("Design / FEM mask IoU")
    axes[2].hist([r['voltage_change_relative']*100 for r in rows],bins=35,color="#d59a49"); axes[2].set_xlabel("Voltage change / reference (%)")
    for ax in axes: ax.set_ylabel("Number of cases")
    fig.suptitle(f"Audit of {len(rows):,} independently sampled cases")
    fig.savefig(out/"dataset_statistics.png",dpi=170); plt.close(fig)
    d=read(examples['deep_U'][0]); mesh=meshes[int(d['meta']['mesh_id'])]
    fig,axes=plt.subplots(2,2,figsize=(11,10),layout='constrained')
    draw_shape(axes[0,0],d,mesh,'16 finite-width electrodes | deep-U example')
    e=mesh['electrode_xy']*1000
    for i,(ex,ey) in enumerate(e,1): axes[0,0].text(ex*1.08,ey*1.08,str(i),ha='center',va='center',fontsize=8)
    u=d['electrode_voltage'][:,:,0].real.T*1000
    im=axes[0,1].imshow(u,origin='lower',aspect='auto',cmap='RdBu_r',extent=[.5,16.5,.5,16.5])
    axes[0,1].set_title('10 kHz electrode potentials (mV)'); axes[0,1].set_xlabel('Electrode'); axes[0,1].set_ylabel('Drive pattern'); fig.colorbar(im,ax=axes[0,1])
    for f in range(2):
        voltage=d['voltage_clean'][:,f].real.reshape(16,13)*1000
        im=axes[1,f].imshow(voltage,origin='lower',aspect='auto',cmap='viridis',extent=[.5,13.5,.5,16.5])
        axes[1,f].set_title(f'{[10,50][f]} kHz boundary measurements (mV)')
        axes[1,f].set_xlabel('Valid measurement order within each drive'); axes[1,f].set_ylabel('Drive pattern'); fig.colorbar(im,ax=axes[1,f])
    fig.suptitle('Protocol check | 16 drives x 13 measurements = 208 complex values per frequency',fontsize=12)
    fig.savefig(out/'protocol_and_measurement.png',dpi=160); plt.close(fig)


if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("root",type=Path); parser.add_argument("--limit",type=int)
    args=parser.parse_args(); audit(args.root,args.limit)
