function [v,U,checks] = eidors_forward_cached(ctx,gamma_Sm,z3d,thickness,current_A)
% Same EIDORS FC.'*diag(material)*FC assembly as system_mat_1st_order.
% Cache only geometry factors. Reassemble and solve full CEM for every case.
sheet=gamma_Sm(:)*thickness;
z2d=z3d(:)/thickness;
weights=[reshape([sheet.';sheet.'],[],1);1./z2d(ctx.cem_electrode)];
E=ctx.FC.'*spdiags(weights,0,numel(weights),numel(weights))*ctx.FC;
E=(E+E.')/2;
rhs=full(ctx.pp.QQ)*current_A;
w=complex(zeros(size(E,1),16));
w(ctx.keep,:)=E(ctx.keep,ctx.keep)\rhs(ctx.keep,:);
U=ctx.pp.N2E*w;
v=ctx.pp.v2meas*U(:);
U=U-mean(U,1); % zero-mean electrode gauge; differential measurements invariant
T=ctx.current_pattern.'*U/current_A;
checks.reciprocity=norm(T-T.','fro')/max(norm(T,'fro'),eps);
checks.residual=norm(E*w-rhs,'fro')/max(norm(rhs,'fro'),eps);
end
