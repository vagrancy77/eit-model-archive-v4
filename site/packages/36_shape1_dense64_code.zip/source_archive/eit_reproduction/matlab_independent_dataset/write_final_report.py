"""Create the human-readable delivery report only after generation and audit."""
import argparse
import hashlib
import json
import shutil
from pathlib import Path


def finish(root):
    root=root.resolve()
    src=Path(__file__).resolve().parent
    audit=json.loads((root/'audit_summary.json').read_text())
    complete=json.loads((root/'generation_complete.json').read_text())
    refine=json.loads((root/'mesh_refinement_summary.json').read_text())
    native=json.loads((root/'native_eidors_recomputation.json').read_text())
    topology=json.loads((root/'topology_targets'/'description.json').read_text())
    topo_audit=json.loads((root/'topology_targets'/'audit.json').read_text())
    assert audit['audited_cases']==complete['count']==topology['cases']==20000
    assert not audit['failures'] and not audit['duplicate_design_masks'] and topology['complete']
    assert topo_audit['status']=='passed' and topo_audit['cases_checked']==20000
    # Existing generation snapshots must match; add documentation/readers/checks.
    for file in src.iterdir():
        if file.suffix not in ('.m','.py','.md'): continue
        target=root/'source'/file.name
        if target.exists() and file.suffix=='.m':
            assert target.read_bytes()==file.read_bytes(), f'Source snapshot mismatch: {file.name}'
        shutil.copy2(file,target)
    shutil.copy2(src/'README.md',root/'README.md')
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'source').iterdir() if p.is_file()}
    (root/'source_sha256.json').write_text(json.dumps(hashes,indent=2),encoding='utf-8')
    eig=src.parent/'third_party'/'eidors'/'eidors'
    files=['models/mk_circ_tank.m','models/mk_stim_patterns.m','solvers/forward/system_mat_fields.m','solvers/forward/fwd_solve_1st_order.m']
    (root/'eidors_source_sha256.json').write_text(json.dumps({f:hashlib.sha256((eig/f).read_bytes()).hexdigest() for f in files},indent=2))
    native_max=max(max(x['voltage_relative_error'],x['reference_relative_error']) for x in native)
    size=sum(p.stat().st_size for p in root.rglob('*') if p.is_file())/1024**3
    text=f'''# MATLAB/EIDORS 独立内凹边界数据集：交付报告

已完成 **20,000 个独立病例**，并逐例通过数值与标签审核。没有训练神经网络。数据体积约 **{size:.2f} GiB**（含派生标签和预览）。

## 数据构成

| 项目 | 数量/内容 |
|---|---|
| 训练 / 验证 / 同分布测试 / 分布变化测试 | 14,000 / 2,000 / 2,000 / 2,000 |
| 凸形对照 / 内凹病例 | 5,000 / 15,000 |
| 形状采样配置 | 16 种，各 1,250 例；不等于 16 类真实解剖 |
| 每例频率 | 10 kHz、50 kHz |
| 每频率边界测量 | 208 项复电压 |
| 电极与网格 | 16 个有限宽度 CEM 电极，7,744 个三角单元 |
| 噪声 | clean + 40/50/60/70 dB，病灶与参考分别加噪 |
| 真值 | FEM 电导率、复导纳率、病灶掩膜、平滑设计边界 |
| 拓扑监督 | 凹陷区域、凸包、FEM 掩膜有符号距离图 |

## 审核结果

- 完整审核：{audit['audited_cases']:,} 例；失败 {len(audit['failures'])} 例；完全重复设计掩膜 {len(audit['duplicate_design_masks'])} 对。
- 派生标签：20,000 例的病例索引、凹陷掩膜关系和距离图符号全部通过；另逐块重算了 {topo_audit['distance_maps_fully_recomputed']} 张完整距离图。
- 电极电势重组测量电压的最大相对误差：{audit['max_errors']['electrode_to_measurement_relative']:.3e}。
- 方程残差 / 互易性最大相对误差：{audit['max_errors']['residual_relative']:.3e} / {audit['max_errors']['reciprocity_relative']:.3e}。
- 噪声 SNR 最大偏差：{audit['max_errors']['snr_error_db']:.3e} dB。
- 设计掩膜与 FEM 栅格掩膜 IoU：均值 {audit['design_fem_iou']['mean']:.4f}，最低 {audit['design_fem_iou']['min']:.4f}。**这是离散化一致性，不是模型重建成绩。**
- 32 例通过原生 EIDORS 重新加载计算，病灶/参考最大相对误差：{native_max:.3e}。
- 32 例细化到 30,976 单元：总电压差异中位数 {100*refine['median_absolute_voltage_relative_error']:.3f}%，最大 {100*refine['max_absolute_voltage_relative_error']:.3f}%；病灶差分电压差异中位数 {100*refine['median_difference_voltage_relative_error']:.3f}%，最大 {100*refine['max_difference_voltage_relative_error']:.3f}%。这是有限样本的网格敏感性检查，并非无限精细网格下的严格误差界。

## 看图

![形状目录]({root.as_posix()}/previews/shape_family_catalog.png)

![复杂内凹细节]({root.as_posix()}/previews/complex_concavity_gallery.png)

![双频电导率与电压]({root.as_posix()}/previews/paired_eit_examples.png)

![统计分布]({root.as_posix()}/previews/dataset_statistics.png)

## 如何使用

病例位于 `cases/case_000001.mat` 至 `cases/case_020000.mat`；固定划分在 `manifest.csv`。Python/MATLAB 的详细字段、单位、代码入口和示例见同目录 `README.md`。读取器已在现有 Python 3.13 / PyTorch 2.13.0+cpu 环境完成实际 DataLoader 加载检查。

网络输入应使用边界电压和已知测量信息。预测绝对电导率时，归一化电压必须与读取器返回的 `measurement_context` 联合输入，以保留参考电压尺度、电流和厚度。掩膜、凹陷标签、距离图及病灶材料参数只能用于监督或评估。

## 适用范围

本版适合内凹边界 EIT 重建的仿真对照实验，包含平滑月牙、深 U、凹陷内凸起、分叶和器官启发形状，没有十字或五角星。形状与材料是合成假设，不是临床证实的病灶，也没有真实超声图像。每例一个病灶、均匀背景、二维等效厚度模型。

OOD 测试改变外域和参数范围，但仍与训练共享部分形状族、同一仿真器及网格构造方式。它不能替代跨仿真器、全新解剖类别或真实实验验证。能生成高质量输入与真值，也不自动意味着某个网络一定能重建出凹陷；这需要后续对照训练和冻结测试来证明。

原始 EIDORS 工具位于工程 `third_party/eidors/eidors`；数据目录 `source/` 保存本次生成/读取/审核代码，`source_sha256.json` 和 `eidors_source_sha256.json` 保存代码指纹。
'''
    (root/'DATASET_REPORT.md').write_text(text,encoding='utf-8')
    print(f'REPORT {root / "DATASET_REPORT.md"} size={size:.2f} GiB')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);a=p.parse_args();finish(a.root)
