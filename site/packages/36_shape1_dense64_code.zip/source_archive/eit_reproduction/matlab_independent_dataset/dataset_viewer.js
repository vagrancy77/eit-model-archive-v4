(() => {
'use strict';
const D=window.EIT_INDEX, $=id=>document.getElementById(id);
if(!D){$('error').textContent='未找到查看数据。请先完整解压压缩包，保留 index.html 同级的 viewer_data 文件夹。';return;}
window.EIT_STORE=window.EIT_STORE||{};
const family=$('family'), split=$('split'), cache=new Map(), domainCache={};
let filtered=D.records, current=null, currentRow=null, ticket=0;
D.families.forEach((name,i)=>family.add(new Option(name,i)));
D.splits.forEach((name,i)=>split.add(new Option(name,i)));
function expand(runs){const a=new Uint8Array(128*128);for(let i=0;i<runs.length;i+=2)a.fill(1,runs[i],runs[i]+runs[i+1]);return a;}
function decode(s,type){const u=Uint8Array.from(atob(s),c=>c.charCodeAt(0)),v=new DataView(u.buffer),n=type==='i16'?2:4,out=[];for(let i=0;i<u.length;i+=n)out.push(n===2?v.getInt16(i,true):v.getFloat32(i,true));return out;}
async function load(id){const shard=Math.floor((id-1)/256);if(!window.EIT_STORE[shard]){if(!cache.has(shard))cache.set(shard,new Promise((resolve,reject)=>{const s=document.createElement('script');s.src=`viewer_data/cases_${String(shard).padStart(3,'0')}.js`;s.onload=resolve;s.onerror=()=>{cache.delete(shard);reject(new Error('病例文件读取失败，请完整解压后重新打开页面。'));};document.body.append(s);}));await cache.get(shard);}return window.EIT_STORE[shard][(id-1)%256];}
function frame(id,height){const canvas=$(id),w=Math.max(240,Math.floor(canvas.getBoundingClientRect().width)),dpr=window.devicePixelRatio||1;canvas.style.height=height+'px';canvas.width=w*dpr;canvas.height=height*dpr;const c=canvas.getContext('2d');c.scale(dpr,dpr);c.fillStyle='#fff';c.fillRect(0,0,w,height);c.font='12px "Microsoft YaHei",sans-serif';return{c,w,h:height};}
function rgb(v){const stops=[[68,1,84],[59,82,139],[33,145,140],[94,201,98],[253,231,37]],q=Math.max(0,Math.min(1,v))*4,a=Math.min(3,Math.floor(q)),f=q-a;return stops[a].map((x,i)=>Math.round(x+(stops[a+1][i]-x)*f));}
function drawImage(id,freq){
 const {c,w,h}=frame(id,330),p=current.polyXY,margin={l:48,r:12,t:12,b:freq<0?35:60};
 let bounds=[-116,116,-116,116];
 if($('zoom').checked){const xs=p.map(a=>a[0]),ys=p.map(a=>a[1]),cx=(Math.min(...xs)+Math.max(...xs))/2,cy=(Math.min(...ys)+Math.max(...ys))/2,span=Math.max(Math.max(...xs)-Math.min(...xs),Math.max(...ys)-Math.min(...ys))+14;bounds=[cx-span/2,cx+span/2,cy-span/2,cy+span/2];}
 const side=Math.min(w-margin.l-margin.r,h-margin.t-margin.b),left=margin.l+(w-margin.l-margin.r-side)/2,top=margin.t;
 const X=v=>left+(v-bounds[0])/(bounds[1]-bounds[0])*side,Y=v=>top+(bounds[3]-v)/(bounds[3]-bounds[2])*side;
 const a=document.createElement('canvas');a.width=a.height=128;const ac=a.getContext('2d'),im=ac.createImageData(128,128),dom=domainCache[currentRow[5]],range=current.sigma.flat(),lo=Math.min(...range),hi=Math.max(...range);
 for(let y=0;y<128;y++)for(let x=0;x<128;x++){let k=y*128+x,j=((127-y)*128+x)*4,col=[250,252,254];if(dom[k]){col=freq<0?(current.maskA[k]?[27,78,130]:[239,246,251]):rgb((current.sigma[current.maskA[k]][freq]-lo)/(hi-lo||1));}im.data.set([...col,255],j);}ac.putImageData(im,0,0);
 c.save();c.beginPath();c.rect(left,top,side,side);c.clip();c.imageSmoothingEnabled=false;
 const ext=115+115/127;c.drawImage(a,X(-ext),Y(ext),X(ext)-X(-ext),Y(-ext)-Y(ext));
 function line(points,color,width){c.strokeStyle=color;c.lineWidth=width;c.beginPath();points.forEach((q,i)=>i?c.lineTo(X(q[0]),Y(q[1])):c.moveTo(X(q[0]),Y(q[1])));c.closePath();c.stroke();}
 const mesh=D.meshes[currentRow[5]];line(mesh.boundary,'#8d9daa',.8);
 if(freq<0){line(p,'#df7326',1.35);c.fillStyle='#51677b';mesh.electrodes.forEach(q=>{c.beginPath();c.arc(X(q[0]),Y(q[1]),2,0,2*Math.PI);c.fill();});}
 c.restore();c.strokeStyle='#ccd7e0';c.lineWidth=1;c.strokeRect(left,top,side,side);c.fillStyle='#425b71';c.textAlign='center';
 for(let j=0;j<3;j++){let q=bounds[0]+j*(bounds[1]-bounds[0])/2;c.fillText(q.toFixed(0),X(q),top+side+16);}
 c.fillText('x (mm)',left+side/2,top+side+32);c.textAlign='right';for(let j=0;j<3;j++){let q=bounds[2]+j*(bounds[3]-bounds[2])/2;c.fillText(q.toFixed(0),left-6,Y(q)+4);}
 c.save();c.translate(12,top+side/2);c.rotate(-Math.PI/2);c.textAlign='center';c.fillText('y (mm)',0,0);c.restore();
 if(freq>=0){const yy=h-16;for(let i=0;i<100;i++){c.fillStyle=`rgb(${rgb(i/99).join(',')})`;c.fillRect(left+i*side/100,yy-8,side/100+1,7);}c.fillStyle='#425b71';c.textAlign='left';c.fillText(lo.toFixed(3),left,yy-12);c.textAlign='right';c.fillText(hi.toFixed(3)+' S/m',left+side,yy-12);}
}
function drawPlot(id,part){
 const{c,w,h}=frame(id,270),l=62,r=16,t=14,b=47,W=w-l-r,H=h-t-b,mode=$('mode').value;
 let data=mode==='dv'?current.dvA:mode==='v'?current.vA:current.vA.map((v,i)=>v-current.dvA[i]);
 const ys=[data.slice(part*208,part*208+208).map(x=>x*1000),data.slice(416+part*208,416+part*208+208).map(x=>x*1000)];
 const all=ys.flat(),low=Math.min(...all),high=Math.max(...all),pad=Math.max((high-low)*.08,1e-10),lo=low-pad,hi=high+pad;
 const X=i=>l+i/207*W,Y=v=>t+(hi-v)/(hi-lo)*H;c.fillStyle='#425b71';c.strokeStyle='#e3e9ee';c.lineWidth=1;
 for(let j=0;j<4;j++){let v=lo+(hi-lo)*j/3,y=Y(v);c.beginPath();c.moveTo(l,y);c.lineTo(l+W,y);c.stroke();c.textAlign='right';c.fillText(Math.abs(v)<.001?v.toExponential(1):v.toPrecision(3),l-8,y+4);}
 [0,69,138,207].forEach(i=>{c.textAlign='center';c.fillText(String(i+1),X(i),t+H+18);});
 c.strokeStyle='#bbcbd7';c.strokeRect(l,t,W,H);c.save();c.beginPath();c.rect(l,t,W,H);c.clip();
 ys.forEach((vals,f)=>{c.strokeStyle=['#245e97','#cc711f'][f];c.lineWidth=1.3;c.beginPath();vals.forEach((v,i)=>i?c.lineTo(X(i),Y(v)):c.moveTo(X(i),Y(v)));c.stroke();});c.restore();
 c.fillStyle='#425b71';c.textAlign='center';c.fillText('测量序号（1–208）',l+W/2,h-7);c.save();c.translate(15,t+H/2);c.rotate(-Math.PI/2);c.fillText('电压（mV）',0,0);c.restore();
}
function render(){if(!current)return;drawImage('shape',-1);drawImage('sigma10',0);drawImage('sigma50',1);drawPlot('real',0);drawPlot('imag',1);}
async function choose(id){
 if(!Number.isInteger(id)||id<1||id>D.n){$('error').textContent='请输入 1 至 20000 之间的整数编号。';return;}
 const token=++ticket;$('error').textContent='';$('status').textContent=`正在读取 case_${String(id).padStart(6,'0')}…`;
 try{const item=await load(id);if(token!==ticket)return;current=item;currentRow=D.records[id-1];current.maskA=expand(item.mask);const q=decode(item.poly,'i16');current.polyXY=[];for(let i=0;i<q.length;i+=2)current.polyXY.push([q[i]/100,q[i+1]/100]);current.vA=decode(item.v,'f32');current.dvA=decode(item.dv,'f32');
 if(!domainCache[currentRow[5]])domainCache[currentRow[5]]=expand(D.meshes[currentRow[5]].domain);
 $('number').value=id;const name='case_'+String(id).padStart(6,'0');$('status').textContent=`${name} · ${D.families[currentRow[1]]} · ${D.splits[currentRow[2]]} · 当前筛选 ${filtered.length.toLocaleString()} 例`;
 $('summary').textContent=`凹陷深度 ${currentRow[3].toFixed(2)} mm　｜　设计/FEM IoU ${currentRow[4].toFixed(4)}　｜　差分/背景电压范数 ${(currentRow[6]*100).toFixed(3)}%　｜　病灶面积 ${current.area.toFixed(0)} mm²　｜　电流 ${(current.current*1000).toFixed(3)} mA`;
 for(let f=0;f<2;f++)$('sigma'+[10,50][f]+'text').textContent=`背景 ${current.sigma[0][f].toFixed(4)} S/m；病灶 ${current.sigma[1][f].toFixed(4)} S/m`;
 $('fileinfo').textContent=`原始数据：cases/${name}.mat；网格：mesh_${currentRow[5]}.mat。`;
 render();window.EIT_CURRENT=id;location.hash=String(id);
 }catch(e){$('error').textContent=e.message;$('status').textContent='加载未完成';}
}
function filter(){filtered=D.records.filter(r=>(family.value==='all'||r[1]===+family.value)&&(split.value==='all'||r[2]===+split.value));if(filtered.length)choose(filtered[0][0]);}
family.onchange=filter;split.onchange=filter;
$('go').onclick=()=>{const id=+$('number').value;if(!filtered.some(r=>r[0]===id)){family.value=split.value='all';filtered=D.records;}choose(id);};
$('number').onkeydown=e=>{if(e.key==='Enter')$('go').click();};
function move(d){let i=filtered.findIndex(r=>r[0]===window.EIT_CURRENT);choose(filtered[(i+d+filtered.length)%filtered.length][0]);}
$('prev').onclick=()=>move(-1);$('next').onclick=()=>move(1);$('random').onclick=()=>choose(filtered[Math.floor(Math.random()*filtered.length)][0]);
$('zoom').onchange=render;$('mode').onchange=render;let timer;window.addEventListener('resize',()=>{clearTimeout(timer);timer=setTimeout(render,120);});
choose(Number(location.hash.slice(1))||8);
})();
