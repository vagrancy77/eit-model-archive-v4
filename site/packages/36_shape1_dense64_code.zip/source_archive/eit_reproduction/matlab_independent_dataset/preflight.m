function preflight()
root=fileparts(fileparts(mfilename('fullpath'))); cd(root); setup_third_party(false);
eidors_msg('log_level',0); eidors_cache('cache_size',128*1024^2);
fprintf('IMAGE_TOOLBOX %d\n',exist('bwconncomp','file'));
for code={'h2C','k2C'}
    t=tic; m=mk_common_model(code{1},16); f=m.fwd_model;
    f.nodes=f.nodes*.1;
    f.stimulation=mk_stim_patterns(16,1,[0 1],[0 1],{'no_meas_current','no_rotate_meas','do_redundant'},.001/.02);
    for e=1:16; f.electrode(e).z_contact=.002; end
    img=mk_image(f,.5+1i*.01); img.fwd_solve.get_all_nodes=1;
    d=fwd_solve(img); warm=toc(t); t=tic;
    for q=1:8
        img.elem_data=.45+.05*rand(size(f.elems,1),1)+1i*.01;
        d=fwd_solve(img);
    end
    fprintf('MODEL %s elements=%d nodes=%d electrodes=%s meas=%d first=%.3f solve=%.4f voltage=[%.6g,%.6g]\n',code{1},size(f.elems,1),size(f.nodes,1),mat2str(arrayfun(@(e)numel(e.nodes),f.electrode)),numel(d.meas),warm,toc(t)/8,min(abs(d.meas)),max(abs(d.meas)));
end
p=subtract(polyshape(cos(linspace(0,2*pi,256)),sin(linspace(0,2*pi,256))),polyshape(.4+.8*cos(linspace(0,2*pi,256)),.8*sin(linspace(0,2*pi,256))));
b=polybuffer(p,-.01); fprintf('POLYSHAPE regions=%d holes=%d buffered=%d\n',p.NumRegions,p.NumHoles,b.NumRegions);
end
