"""Export all 20,000 cases to an offline viewer and draw Chinese scientific figures."""
from __future__ import annotations
import base64
import csv
import json
import shutil
from pathlib import Path
import argparse
import numpy as np
from scipy.io import loadmat
from scipy.spatial import ConvexHull
from scipy import ndimage
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.path import Path as MPath

FAMILIES={'ellipse':'椭圆对照','oval':'长椭圆对照','convex_lobule':'轻微分叶凸形','ovary_like':'卵巢启发凸形',
 'crescent':'月牙','deep_crescent':'深月牙','wide_U':'宽 U 形','deep_U':'深 U 形','asymmetric_C':'不对称 C 形',
 'kidney_like':'肾样内凹','lung_like':'肺样内凹','heart_like':'心形启发内凹','notched_oval':'切口椭圆',
 'lobulated_notch':'分叶内凹','crescent_bulge':'凹陷内有凸起','compound_notch':'复合凹边'}
SPLITS={'train':'训练集','validation':'验证集','test_id':'同分布测试','test_ood':'分布变化测试'}

def mat(path): return loadmat(path,simplify_cells=True)
def b64(a,dtype): return base64.b64encode(np.asarray(a,dtype=dtype).tobytes()).decode('ascii')
def rle(mask):
    a=np.r_[0,mask.astype(np.int8).ravel(),0]; edges=np.flatnonzero(np.diff(a))
    pairs=np.stack([edges[::2],edges[1::2]-edges[::2]],axis=1)
    check=np.zeros(mask.size,dtype=np.uint8)
    for start,length in pairs: check[start:start+length]=1
    assert np.array_equal(check.reshape(mask.shape),mask)
    return pairs.ravel().tolist()

def export_viewer(root,out,rows,meshes):
    assets=out/'viewer_data'; assets.mkdir(exist_ok=True)
    family_list=list(FAMILIES); split_list=list(SPLITS)
    idx=[]; selected=[]; errors=[]
    for start in range(0,len(rows),256):
        records=[]
        for row in rows[start:start+256]:
            d=mat(root/row['file']); m=d['meta']; i=int(m['index'])
            voltage=np.stack([d['voltage_clean'].real.T,d['voltage_clean'].imag.T],axis=1)
            delta=np.stack([d['voltage_difference'].real.T,d['voltage_difference'].imag.T],axis=1)
            mg=m['material_gamma_Sm']
            polygon=np.rint(d['polygon_m']*1e5).astype('<i2')
            assert np.max(abs(polygon.astype(float)/1e5-d['polygon_m']))<=5.00001e-6
            assert np.allclose(voltage.astype('<f4'),voltage,rtol=1e-6,atol=1e-12)
            records.append({'id':i,'mask':rle(d['mask_fem']),'poly':b64(polygon,'<i2'),
                'v':b64(voltage,'<f4'),'dv':b64(delta,'<f4'),
                'sigma':mg.real.tolist(),'gamma_imag':mg.imag.tolist(),
                'current':float(m['current_A']),'area':float(m['area_mm2'])})
            idx.append([i,family_list.index(m['family']),split_list.index(m['split']),
                float(m['concavity_depth_mm']),float(m['design_fem_iou']),int(m['mesh_id']),
                float(m['voltage_change_relative']),float(m['concavity_fraction'])])
        shard=start//256
        (assets/f'cases_{shard:03d}.js').write_text('window.EIT_STORE=window.EIT_STORE||{};window.EIT_STORE['+str(shard)+']='+json.dumps(records,separators=(',',':'))+';\n',encoding='utf-8')
        if (start//256)%8==0: print(f'VIEWER {min(start+256,len(rows))}/{len(rows)}',flush=True)
    mesh_data={str(i):{'domain':rle(m['domain_mask']),'boundary':(m['boundary_xy']*1000).round(3).tolist(),
        'electrodes':(m['electrode_xy']*1000).round(3).tolist()} for i,m in meshes.items()}
    data={'families':[FAMILIES[f] for f in family_list],'family_codes':family_list,'splits':list(SPLITS.values()),
          'records':idx,'meshes':mesh_data,'n':len(rows),'chunk_size':256,'axis_mm':[-115,115]}
    (assets/'index.js').write_text('window.EIT_INDEX='+json.dumps(data,ensure_ascii=False,separators=(',',':'))+';\n',encoding='utf-8')
    source=Path(__file__).parent
    shutil.copy2(source/'dataset_viewer.html',out/'index.html')
    shutil.copy2(source/'dataset_viewer.js',out/'viewer.js')
    (out/'viewer_export_check.json').write_text(json.dumps({'cases_exported':len(idx),'shards':(len(rows)+255)//256,
        'fem_masks':'all losslessly round-trip checked','voltages':'float32 display export checked against original doubles',
        'polygon_coordinate_display_max_error_m':5e-6,'original_mat_files':'unchanged'},indent=2),encoding='utf-8')

def plot_mask(ax,d,m,title,crop=True,hull=False):
    x=m['axis_m']*1000; step=x[1]-x[0]; extent=[x[0]-step/2,x[-1]+step/2,x[0]-step/2,x[-1]+step/2]
    a=np.ma.masked_where(~m['domain_mask'].astype(bool),d['mask_fem'])
    ax.imshow(a,origin='lower',extent=extent,cmap='Blues',vmin=0,vmax=1,interpolation='nearest')
    p=d['polygon_m']*1000
    if hull:
        h=p[ConvexHull(p).vertices]; ax.plot(*np.vstack([h,h[:1]]).T,color='#8c969a',ls='--',lw=1)
    ax.plot(*np.vstack([p,p[:1]]).T,color='#e77727',lw=1.05)
    if crop:
        centre=(p.max(axis=0)+p.min(axis=0))/2; width=max(np.ptp(p,axis=0))+12
        ax.set_xlim(centre[0]-width/2,centre[0]+width/2);ax.set_ylim(centre[1]-width/2,centre[1]+width/2)
    else:
        b=m['boundary_xy']*1000; ax.plot(*np.vstack([b,b[:1]]).T,color='#6c7f91',lw=.8)
        e=m['electrode_xy']*1000;ax.scatter(e[:,0],e[:,1],s=9,color='#516778')
    ax.set_aspect('equal');ax.set_title(title,fontsize=10);ax.tick_params(labelsize=8)
    ax.set_xlabel('x（mm）',fontsize=9);ax.set_ylabel('y（mm）',fontsize=9)

def figures(root,out,rows,meshes):
    font_manager.fontManager.addfont('C:/Windows/Fonts/msyh.ttc')
    plt.rcParams.update({'font.family':'Microsoft YaHei','axes.unicode_minus':False,'font.size':10})
    by={f:[r for r in rows if r['family']==f] for f in FAMILIES}
    rng=np.random.default_rng(20261004)
    picks={f:items[int(rng.integers(len(items)))] for f,items in by.items()}
    fig,axs=plt.subplots(4,4,figsize=(14,14),layout='constrained')
    for ax,(fam,row) in zip(axs.flat,picks.items()):
        d=mat(root/row['file']);m=d['meta']
        plot_mask(ax,d,meshes[int(m['mesh_id'])],f"{FAMILIES[fam]} · {m['case_id']}\n凹陷深度 {m['concavity_depth_mm']:.1f} mm")
    fig.suptitle('16 类形状采样配置｜蓝色：实际 FEM 真值；橙线：平滑设计边界',fontsize=16)
    fig.supxlabel('各小图分别放大，比例不完全相同；这些是仿真真值，不是神经网络重建结果。',fontsize=11)
    fig.savefig(out/'01_形状总览.png',dpi=165);plt.close(fig)
    fams=['deep_U','deep_crescent','crescent_bulge','compound_notch','lobulated_notch','kidney_like']
    fig,axs=plt.subplots(3,4,figsize=(14,11),layout='constrained')
    for n,fam in enumerate(fams):
        for j,ix in enumerate(rng.choice(len(by[fam]),2,replace=False)):
            row=by[fam][int(ix)];d=mat(root/row['file']);m=d['meta']
            plot_mask(axs.flat[2*n+j],d,meshes[int(m['mesh_id'])],f"{FAMILIES[fam]} · {m['case_id']}\n{SPLITS[m['split']]}｜深度 {m['concavity_depth_mm']:.1f} mm",hull=True)
    fig.suptitle('复杂内凹细节｜灰虚线为凸包，凹陷位于凸包与病灶之间',fontsize=16)
    fig.savefig(out/'02_复杂内凹细节.png',dpi=165);plt.close(fig)
    # One complete case: all panels use the exact same stored sample.
    row=picks['crescent_bulge'];d=mat(root/row['file']);m=d['meta'];mesh=meshes[int(m['mesh_id'])]
    x=mesh['axis_m']*1000;dx=x[1]-x[0];extent=[x[0]-dx/2,x[-1]+dx/2,x[0]-dx/2,x[-1]+dx/2]
    fig,axs=plt.subplots(2,3,figsize=(16,10),layout='constrained')
    plot_mask(axs[0,0],d,mesh,'实际 FEM 病灶真值与电极',crop=False)
    lo=d['sigma_grid'][mesh['domain_mask'].astype(bool)].min();hi=d['sigma_grid'].max()
    for f in range(2):
        z=np.ma.masked_where(~mesh['domain_mask'].astype(bool),d['sigma_grid'][...,f])
        im=axs[0,f+1].imshow(z,origin='lower',extent=extent,cmap='viridis',vmin=lo,vmax=hi)
        axs[0,f+1].set_title(f'{[10,50][f]} kHz 电导率真值');axs[0,f+1].set_xlabel('x（mm）');axs[0,f+1].set_ylabel('y（mm）')
        fig.colorbar(im,ax=axs[0,f+1],shrink=.75,label='S/m')
    poly=d['polygon_m'];h=poly[ConvexHull(poly).vertices];xx,yy=np.meshgrid(x/1000,x/1000)
    hull=MPath(np.vstack([h,h[:1]])).contains_points(np.column_stack([xx.ravel(),yy.ravel()]),radius=1e-12).reshape(128,128)|d['mask_design'].astype(bool)
    codes=d['mask_design'].astype(int)*2+(hull&~d['mask_design'].astype(bool)).astype(int)
    from matplotlib.colors import ListedColormap
    axs[1,0].imshow(codes,origin='lower',extent=extent,cmap=ListedColormap(['#f5f7f9','#eca74b','#214f88']),vmin=0,vmax=2)
    axs[1,0].set_title('凹陷监督标签：黄色为凹陷区，蓝色为病灶');axs[1,0].set_xlabel('x（mm）');axs[1,0].set_ylabel('y（mm）')
    fm=d['mask_fem'].astype(bool);sdf=(ndimage.distance_transform_edt(~fm)-ndimage.distance_transform_edt(fm))*dx
    sdf=np.ma.masked_where(~mesh['domain_mask'].astype(bool),sdf)
    im=axs[1,1].imshow(sdf,origin='lower',extent=extent,cmap='RdBu_r',vmin=-25,vmax=25)
    axs[1,1].contour(x,x,d['mask_fem'],levels=[.5],colors='black',linewidths=.6)
    axs[1,1].set_title('边界距离图：病灶内部为负');axs[1,1].set_xlabel('x（mm）');axs[1,1].set_ylabel('y（mm）')
    fig.colorbar(im,ax=axs[1,1],shrink=.75,extend='both',label='mm（显示截断至 ±25）')
    for f,c in enumerate(['#2464ad','#d87924']):
        dv=d['voltage_difference'][:,f]*1000
        axs[1,2].plot(np.arange(1,209),dv.real,c=c,lw=.9,label=f'{[10,50][f]} kHz 实部')
        axs[1,2].plot(np.arange(1,209),dv.imag,c=c,ls='--',lw=.8,label=f'{[10,50][f]} kHz 虚部')
    axs[1,2].set_title('病灶电压 − 匹配背景电压');axs[1,2].set_xlabel('测量序号（1–208）');axs[1,2].set_ylabel('电压差（mV）');axs[1,2].legend(fontsize=9)
    fig.suptitle(f"一个完整病例：{m['case_id']}｜{FAMILIES[m['family']]}｜同一几何对应双频电学响应",fontsize=16)
    fig.savefig(out/'03_完整病例与拓扑标签.png',dpi=160);plt.close(fig)
    # Show difficult examples too; selection is declared, not cherry-picked.
    worst=sorted(rows,key=lambda r:float(r['design_fem_iou']))[:4]
    deepest=sorted(rows,key=lambda r:float(r['concavity_depth_mm']),reverse=True)[:4]
    fig,axs=plt.subplots(2,4,figsize=(15,8),layout='constrained')
    for n,row in enumerate(worst+deepest):
        d=mat(root/row['file']);m=d['meta']
        title=('设计/FEM 一致性最低' if n<4 else '凹陷最深')+f" · {m['case_id']}\nIoU {m['design_fem_iou']:.4f}｜深度 {m['concavity_depth_mm']:.1f} mm"
        plot_mask(axs.flat[n],d,meshes[int(m['mesh_id'])],title,hull=True)
    fig.suptitle('质量边缘病例也展示｜此处 IoU 衡量标签离散化，不是重建成绩',fontsize=16)
    fig.savefig(out/'04_质量边缘病例.png',dpi=160);plt.close(fig)
    fig,axs=plt.subplots(2,2,figsize=(13,9),layout='constrained')
    depths=np.array([float(r['concavity_depth_mm']) for r in rows]);ious=np.array([float(r['design_fem_iou']) for r in rows]);changes=np.array([float(r['voltage_change_relative']) for r in rows])
    axs[0,0].hist(depths,bins=45,color='#2c72a0');axs[0,0].set_xlabel('凹陷深度（mm；凸形约为 0）')
    axs[0,1].hist(ious,bins=45,color='#4c9473');axs[0,1].set_xlabel('平滑设计掩膜 / 实际 FEM 掩膜 IoU')
    axs[1,0].hist(changes*100,bins=45,color='#cd9242');axs[1,0].set_xlabel('病灶差分电压范数 / 背景电压范数（%）')
    counts=[sum(r['split']==sp for r in rows) for sp in SPLITS];bars=axs[1,1].bar(list(SPLITS.values()),counts,color='#578ab2')
    axs[1,1].bar_label(bars,padding=3);axs[1,1].set_ylim(0,max(counts)*1.15)
    for ax in axs.flat:ax.set_ylabel('病例数')
    fig.suptitle('20,000 例全量统计｜分布与离散化质量',fontsize=16)
    fig.savefig(out/'05_全量质量统计.png',dpi=165);plt.close(fig)
    ordered=sorted(rows,key=lambda r:float(r['voltage_change_relative']))
    cases=[ordered[0],ordered[len(rows)//2],ordered[int(.9*len(rows))]]
    fig,axs=plt.subplots(3,2,figsize=(14,11),layout='constrained')
    snr_results=[]
    for r,row in enumerate(cases):
        d=mat(root/row['file'])
        for col,noise_idx in enumerate([0,3]):
            clean=d['voltage_difference'][:,0];measured=d['voltage_noisy'][:,0,noise_idx]-d['reference_noisy'][:,0,noise_idx]
            actual_snr=20*np.log10(np.linalg.norm(clean)/np.linalg.norm(measured-clean));snr_results.append([row['case_id'],[40,70][col],float(actual_snr)])
            ax=axs[r,col];ax.plot(np.arange(1,209),measured.real*1000,color='#aeb8c1',lw=.8,label='含噪差分实部')
            ax.plot(np.arange(1,209),clean.real*1000,color='#225d98',lw=1,label='无噪差分实部')
            ax.set_title(f"{['信号变化最弱','信号变化中位数','信号变化第90百分位'][r]} · {row['case_id']}\n绝对测量 SNR {[40,70][col]} dB → 此例差分 SNR {actual_snr:.1f} dB")
            ax.set_xlabel('测量序号');ax.set_ylabel('10 kHz 电压差（mV）');ax.legend(fontsize=8)
    fig.suptitle('噪声影响：绝对电压的 SNR 不等于病灶差分信号的 SNR',fontsize=16)
    fig.savefig(out/'06_噪声对病灶信号的影响.png',dpi=160);plt.close(fig)
    (out/'figure_selection.json').write_text(json.dumps({'selection_seed':20261004,'family_overview':{k:v['case_id'] for k,v in picks.items()},'boundary_quality_lowest':[r['case_id'] for r in worst],'deepest':[r['case_id'] for r in deepest],'noise_examples':snr_results},ensure_ascii=False,indent=2),encoding='utf-8')

def main(root):
    root=root.resolve();out=root/'visual_review';out.mkdir(exist_ok=True)
    with (root/'manifest.csv').open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
    assert len(rows)==20000
    meshes={i:mat(root/f'mesh_{i}.mat')['mesh'] for i in (1,2,3)}
    export_viewer(root,out,rows,meshes);figures(root,out,rows,meshes)
    print(f'COMPLETE {out}',flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);a=p.parse_args();main(a.root)
