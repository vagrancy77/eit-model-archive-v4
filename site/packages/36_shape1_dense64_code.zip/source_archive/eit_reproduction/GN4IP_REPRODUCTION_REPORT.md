# GN4IP 深度 EIT 成像论文复现报告

## 选定论文与公开资源

本工程选择复现 GN4IP：Graph Networks for Inverse Problems 相关工作。

- 论文：<https://arxiv.org/abs/2305.05020>
- 公开代码：<https://github.com/wherzberg/GN4IP>
- 本地代码固定版本：`0f744d41e87616b08bbaab9f7a8a48ef201d8c62`
- 许可证：GPL-3.0

选择原因：该仓库同时公开 EIT 仿真代码、神经网络代码、训练数据、测试数据、Conv U-Net 预训练权重，以及作者保存的 Conv U-Net 测试输出。因此它不是只能“照着论文重写”，而是可以对作者公开输出做严格数值复现。

## 数据集与模型

公开数据位于：

- `E:\Codex\eit_reproduction\external\GN4IP\data\training_data_v0.mat`
- `E:\Codex\eit_reproduction\external\GN4IP\data\test_data_v0.mat`
- `E:\Codex\eit_reproduction\external\GN4IP\data\conv_unet_model.pt`
- `E:\Codex\eit_reproduction\external\GN4IP\data\conv_unet_test_output_v0.mat`
- `E:\Codex\eit_reproduction\external\GN4IP\data\conv_unet_train_output.mat`

数据规模：

| 项目 | 数值 |
|---|---:|
| 训练样本 | 300 |
| 测试样本 | 10 |
| 每个样本边界电压测量 | 256 |
| 重建网格单元数 | 4204 |
| CNN 嵌入网格 | 32×32 |

主要字段：

| 字段 | 含义 |
|---|---|
| `VSIM` | EIT 边界电压测量 |
| `X0` | 均匀初始化 |
| `X1` | 第一次 Levenberg-Marquardt/Gauss-Newton 类更新 |
| `X2` | 3 次 LM 更新后的重建，也是 Conv U-Net 输入 |
| `Y` | 真值电导率分布 |
| `closest_elements` | FEM 网格到 32×32 图像网格的映射 |
| `closest_pixels` | 32×32 图像网格回 FEM 网格的映射 |

## 已完成的严格复现

运行命令：

```bash
source ~/miniforge3/etc/profile.d/conda.sh
conda activate gn4ip-env
cd /mnt/e/Codex/eit_reproduction
python reproduce_gn4ip.py
python scripts/plot_gn4ip_paper_style.py
python scripts/validate_gn4ip_reproduction.py
```

或者一键执行：

```bash
bash scripts/run_gn4ip_reproduction_full.sh
```

核心结果：

| 指标 | 结果 |
|---|---:|
| 本地推理输出 vs 作者公开 `yhat` 相对 L2 误差 | `6.247986537845038e-16` |
| 本地推理输出 vs 作者公开 `yhat` 最大绝对误差 | `1.582067810090848e-15` |
| 3-step LM 平均相关系数 | `0.5130046352873003` |
| GN4IP Conv U-Net 平均相关系数 | `0.9138783238492149` |
| 3-step LM 平均相对 L2 | `0.18312328575712294` |
| GN4IP Conv U-Net 平均相对 L2 | `0.078596062129587` |

结论：公开 Conv U-Net 分支已经达到机器精度级复现；网络输出与作者公开测试输出在数值上等价，并且在公开测试集上显著优于 3-step LM 输入重建。

## 输出文件

主要复现输出：

- `E:\Codex\eit_reproduction\outputs_gn4ip\summary.json`
- `E:\Codex\eit_reproduction\outputs_gn4ip\gn4ip_reproduction.npz`
- `E:\Codex\eit_reproduction\outputs_gn4ip\gn4ip_conv_unet_reproduction.png`

论文式图像输出：

- `E:\Codex\eit_reproduction\outputs_gn4ip\paper_style_figures\gn4ip_conv_unet_sample_0_paper_style.png`
- `E:\Codex\eit_reproduction\outputs_gn4ip\paper_style_figures\gn4ip_conv_unet_sample_1_paper_style.png`
- `E:\Codex\eit_reproduction\outputs_gn4ip\paper_style_figures\gn4ip_conv_unet_sample_2_paper_style.png`
- `E:\Codex\eit_reproduction\outputs_gn4ip\paper_style_figures\gn4ip_conv_unet_training_loss.png`
- `E:\Codex\eit_reproduction\outputs_gn4ip\paper_style_figures\per_sample_metrics.csv`
- `E:\Codex\eit_reproduction\outputs_gn4ip\paper_style_figures\paper_style_summary.json`

## 复现边界

严格一致部分：Conv U-Net 预训练权重、公开测试集、作者公开 `conv_unet_test_output_v0.mat`，已经实现逐数值校验。

需要注意的部分：仓库代码还包含 Graph U-Net 和 GCNM/迭代图网络，但当前公开数据目录没有对应的 `graph_unet_model.pt`、`graph_gcnm_model_*.pt`、`graph_unet_test_output_v0.mat`、`graph_gcnm_test_output_*.mat` 权重/输出文件。也就是说，这些图网络分支可以按公开代码重新训练，但在没有作者公开权重和随机环境锁定的情况下，不能承诺达到 Conv U-Net 这种 1e-15 级完全一致。

因此，本报告中“完全一致”的结论严格指向仓库公开且可校验的 Conv U-Net 深度 EIT 成像分支。
