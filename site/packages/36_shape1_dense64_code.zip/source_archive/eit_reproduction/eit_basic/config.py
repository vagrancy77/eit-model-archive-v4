from dataclasses import dataclass


@dataclass(frozen=True)
class EITConfig:
    """Configuration for the EIT simulation."""

    n_electrodes: int = 16
    forward_model: str = "cem"
    forward_mesh_size: float = 0.05
    inverse_mesh_size: float = 0.11
    electrode_width: float = 2.5 / 14.0
    contact_impedance: float = 0.01
    current_amplitude: float = 1.0
    background_conductivity: float = 1.0
    lung_conductivity: float = 0.25
    heart_conductivity: float = 1.5
    snr_db: float = 60.0
    random_seed: int = 20260716
    jacobian_p: float = 0.5
    lambda_reg: float = 0.01
