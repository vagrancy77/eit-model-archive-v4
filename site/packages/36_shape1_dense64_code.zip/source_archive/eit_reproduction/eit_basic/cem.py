from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import scipy.linalg
import scipy.sparse as sparse
import scipy.sparse.linalg as sparse_linalg
from pyeit.eit.protocol import PyEITProtocol
from pyeit.mesh.wrapper import PyEITMesh


@dataclass(frozen=True)
class CEMElectrodeGeometry:
    """Boundary edges assigned to finite-width CEM electrodes."""

    edge_nodes: np.ndarray
    edge_electrode_ids: np.ndarray
    electrode_lengths: np.ndarray


@dataclass(frozen=True)
class CEMProtocolSolution:
    """CEM potentials and boundary measurements for a protocol."""

    node_potentials: np.ndarray
    electrode_potentials: np.ndarray
    measurements: np.ndarray


def _triangle_geometry(mesh: PyEITMesh) -> tuple[np.ndarray, np.ndarray]:
    """Return triangle areas and gradients of linear basis functions."""

    elements = mesh.element[:, :3]
    coordinates = mesh.node[elements, :2]
    x0, y0 = coordinates[:, 0, 0], coordinates[:, 0, 1]
    x1, y1 = coordinates[:, 1, 0], coordinates[:, 1, 1]
    x2, y2 = coordinates[:, 2, 0], coordinates[:, 2, 1]

    twice_signed_area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0)
    if np.any(np.abs(twice_signed_area) < np.finfo(float).eps):
        raise ValueError("mesh contains a degenerate triangular element")

    areas = 0.5 * np.abs(twice_signed_area)
    gradients = np.empty((mesh.n_elems, 3, 2), dtype=float)
    gradients[:, 0, 0] = y1 - y2
    gradients[:, 0, 1] = x2 - x1
    gradients[:, 1, 0] = y2 - y0
    gradients[:, 1, 1] = x0 - x2
    gradients[:, 2, 0] = y0 - y1
    gradients[:, 2, 1] = x1 - x0
    gradients /= twice_signed_area[:, None, None]
    return areas, gradients


def _boundary_edges(mesh: PyEITMesh) -> np.ndarray:
    elements = mesh.element[:, :3]
    all_edges = np.concatenate(
        [
            elements[:, [0, 1]],
            elements[:, [1, 2]],
            elements[:, [2, 0]],
        ],
        axis=0,
    )
    sorted_edges = np.sort(all_edges, axis=1)
    unique_edges, counts = np.unique(sorted_edges, axis=0, return_counts=True)
    return unique_edges[counts == 1]


def build_cem_electrodes(
    mesh: PyEITMesh,
    n_electrodes: int,
    electrode_width: float,
) -> CEMElectrodeGeometry:
    """Assign boundary mesh edges to finite-width electrodes."""

    if electrode_width <= 0.0:
        raise ValueError("electrode_width must be positive")

    boundary_edges = _boundary_edges(mesh)
    boundary_points = mesh.node[boundary_edges, :2]
    midpoints = boundary_points.mean(axis=1)
    midpoint_angles = np.arctan2(midpoints[:, 1], midpoints[:, 0])

    electrode_positions = mesh.node[mesh.el_pos[:n_electrodes], :2]
    electrode_angles = np.arctan2(
        electrode_positions[:, 1], electrode_positions[:, 0]
    )
    boundary_radius = float(np.mean(np.linalg.norm(electrode_positions, axis=1)))
    half_angular_width = electrode_width / (2.0 * boundary_radius)

    angle_difference = midpoint_angles[:, None] - electrode_angles[None, :]
    wrapped_difference = np.arctan2(
        np.sin(angle_difference),
        np.cos(angle_difference),
    )
    closest_electrode = np.argmin(np.abs(wrapped_difference), axis=1)
    closest_difference = np.min(np.abs(wrapped_difference), axis=1)
    selected = closest_difference <= half_angular_width

    edge_nodes = boundary_edges[selected]
    edge_electrode_ids = closest_electrode[selected]
    edge_lengths = np.linalg.norm(
        mesh.node[edge_nodes[:, 0], :2] - mesh.node[edge_nodes[:, 1], :2],
        axis=1,
    )
    electrode_lengths = np.bincount(
        edge_electrode_ids,
        weights=edge_lengths,
        minlength=n_electrodes,
    )
    if np.any(electrode_lengths <= 0.0):
        missing = np.flatnonzero(electrode_lengths <= 0.0).tolist()
        raise ValueError(
            "mesh is too coarse for the requested electrode width; "
            f"electrodes without boundary edges: {missing}"
        )

    return CEMElectrodeGeometry(
        edge_nodes=edge_nodes,
        edge_electrode_ids=edge_electrode_ids,
        electrode_lengths=electrode_lengths,
    )


class CEMForward:
    """Linear triangular FEM solver for the complete electrode model."""

    def __init__(
        self,
        mesh: PyEITMesh,
        protocol: PyEITProtocol,
        electrode_width: float,
        contact_impedance: float,
        current_amplitude: float = 1.0,
    ) -> None:
        if contact_impedance <= 0.0:
            raise ValueError("contact_impedance must be positive")
        if current_amplitude <= 0.0:
            raise ValueError("current_amplitude must be positive")

        self.mesh = mesh
        self.protocol = protocol
        self.n_electrodes = protocol.n_el
        self.electrode_width = float(electrode_width)
        self.contact_impedance = float(contact_impedance)
        self.current_amplitude = float(current_amplitude)
        self.areas, self.basis_gradients = _triangle_geometry(mesh)
        self.electrodes = build_cem_electrodes(
            mesh,
            n_electrodes=self.n_electrodes,
            electrode_width=self.electrode_width,
        )

    def _validate_conductivity(self, conductivity: np.ndarray | float) -> np.ndarray:
        if np.isscalar(conductivity):
            values = np.full(self.mesh.n_elems, conductivity, dtype=float)
        else:
            values = np.asarray(conductivity, dtype=float)
        if values.shape != (self.mesh.n_elems,):
            raise ValueError(
                "conductivity must contain one value per triangular element"
            )
        if np.any(values <= 0.0):
            raise ValueError("CEM conductivity values must be positive")
        return values

    def _assemble_system(self, conductivity: np.ndarray | float) -> sparse.csc_matrix:
        conductivity_values = self._validate_conductivity(conductivity)
        elements = self.mesh.element[:, :3]

        gradient_products = np.einsum(
            "eid,ejd->eij",
            self.basis_gradients,
            self.basis_gradients,
        )
        local_stiffness = (
            conductivity_values[:, None, None]
            * self.areas[:, None, None]
            * gradient_products
        )
        row_indices = np.repeat(elements, 3, axis=1).reshape(-1)
        column_indices = np.tile(elements, (1, 3)).reshape(-1)
        node_matrix = sparse.coo_matrix(
            (local_stiffness.reshape(-1), (row_indices, column_indices)),
            shape=(self.mesh.n_nodes, self.mesh.n_nodes),
        ).tocsr()

        edge_nodes = self.electrodes.edge_nodes
        electrode_ids = self.electrodes.edge_electrode_ids
        edge_lengths = np.linalg.norm(
            self.mesh.node[edge_nodes[:, 0], :2]
            - self.mesh.node[edge_nodes[:, 1], :2],
            axis=1,
        )
        inverse_contact = 1.0 / self.contact_impedance

        edge_mass_rows: list[int] = []
        edge_mass_columns: list[int] = []
        edge_mass_values: list[float] = []
        coupling_rows: list[int] = []
        coupling_columns: list[int] = []
        coupling_values: list[float] = []
        electrode_diagonal = np.zeros(self.n_electrodes, dtype=float)

        for edge, electrode_id, edge_length in zip(
            edge_nodes,
            electrode_ids,
            edge_lengths,
            strict=True,
        ):
            first_node, second_node = int(edge[0]), int(edge[1])
            local_mass = inverse_contact * edge_length / 6.0
            edge_mass_rows.extend(
                [first_node, first_node, second_node, second_node]
            )
            edge_mass_columns.extend(
                [first_node, second_node, first_node, second_node]
            )
            edge_mass_values.extend(
                [2.0 * local_mass, local_mass, local_mass, 2.0 * local_mass]
            )

            coupling_value = -inverse_contact * edge_length / 2.0
            coupling_rows.extend([first_node, second_node])
            coupling_columns.extend([int(electrode_id), int(electrode_id)])
            coupling_values.extend([coupling_value, coupling_value])
            electrode_diagonal[int(electrode_id)] += inverse_contact * edge_length

        node_matrix = node_matrix + sparse.coo_matrix(
            (edge_mass_values, (edge_mass_rows, edge_mass_columns)),
            shape=(self.mesh.n_nodes, self.mesh.n_nodes),
        ).tocsr()
        coupling_matrix = sparse.coo_matrix(
            (coupling_values, (coupling_rows, coupling_columns)),
            shape=(self.mesh.n_nodes, self.n_electrodes),
        ).tocsr()
        electrode_matrix = sparse.diags(electrode_diagonal, format="csr")

        node_constraint = sparse.csr_matrix((self.mesh.n_nodes, 1))
        electrode_constraint = sparse.csr_matrix(
            np.ones((self.n_electrodes, 1), dtype=float)
        )
        scalar_zero = sparse.csr_matrix((1, 1))
        return sparse.bmat(
            [
                [node_matrix, coupling_matrix, node_constraint],
                [
                    coupling_matrix.transpose(),
                    electrode_matrix,
                    electrode_constraint,
                ],
                [
                    node_constraint.transpose(),
                    electrode_constraint.transpose(),
                    scalar_zero,
                ],
            ],
            format="csc",
        )

    def solve_pairs(
        self,
        conductivity: np.ndarray | float,
        electrode_pairs: np.ndarray,
        amplitudes: float | np.ndarray = 1.0,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Solve CEM fields for arbitrary current electrode pairs."""

        pairs = np.asarray(electrode_pairs, dtype=int)
        if pairs.ndim != 2 or pairs.shape[1] != 2:
            raise ValueError("electrode_pairs must have shape (n_patterns, 2)")

        amplitude_values = np.broadcast_to(
            np.asarray(amplitudes, dtype=float),
            (pairs.shape[0],),
        )
        factorization = sparse_linalg.splu(self._assemble_system(conductivity))
        right_hand_side = np.zeros(
            (self.mesh.n_nodes + self.n_electrodes + 1, pairs.shape[0]),
            dtype=float,
        )
        for pattern_index, (pair, amplitude) in enumerate(
            zip(pairs, amplitude_values, strict=True)
        ):
            first_electrode, second_electrode = int(pair[0]), int(pair[1])
            right_hand_side[self.mesh.n_nodes + first_electrode, pattern_index] = (
                amplitude
            )
            right_hand_side[self.mesh.n_nodes + second_electrode, pattern_index] = (
                -amplitude
            )

        solution = factorization.solve(right_hand_side)
        node_potentials = solution[: self.mesh.n_nodes]
        electrode_potentials = solution[
            self.mesh.n_nodes : self.mesh.n_nodes + self.n_electrodes
        ]
        return node_potentials, electrode_potentials

    def solve_protocol(
        self,
        conductivity: np.ndarray | float,
    ) -> CEMProtocolSolution:
        node_potentials, electrode_potentials = self.solve_pairs(
            conductivity,
            self.protocol.ex_mat,
            amplitudes=self.current_amplitude,
        )
        measurements = np.empty(
            (self.protocol.n_exc, self.protocol.n_meas),
            dtype=float,
        )
        for excitation_index in range(self.protocol.n_exc):
            measurement_pairs = self.protocol.meas_mat[excitation_index]
            measurements[excitation_index] = (
                electrode_potentials[
                    measurement_pairs[:, 0], excitation_index
                ]
                - electrode_potentials[
                    measurement_pairs[:, 1], excitation_index
                ]
            )
        return CEMProtocolSolution(
            node_potentials=node_potentials,
            electrode_potentials=electrode_potentials,
            measurements=measurements.reshape(-1),
        )

    def compute_jacobian(self, conductivity: np.ndarray | float) -> np.ndarray:
        """Compute the CEM Jacobian with reciprocal adjoint fields."""

        flattened_measurements = self.protocol.meas_mat.reshape(-1, 2)
        unique_measurement_pairs, measurement_pair_indices = np.unique(
            flattened_measurements,
            axis=0,
            return_inverse=True,
        )
        combined_pairs = np.vstack(
            [self.protocol.ex_mat, unique_measurement_pairs]
        )
        combined_amplitudes = np.concatenate(
            [
                np.full(self.protocol.n_exc, self.current_amplitude),
                np.ones(unique_measurement_pairs.shape[0]),
            ]
        )
        node_potentials, _ = self.solve_pairs(
            conductivity,
            combined_pairs,
            amplitudes=combined_amplitudes,
        )

        excitation_potentials = node_potentials[:, : self.protocol.n_exc]
        adjoint_potentials = node_potentials[:, self.protocol.n_exc :]
        elements = self.mesh.element[:, :3]
        excitation_element_values = excitation_potentials[elements]
        adjoint_element_values = adjoint_potentials[elements]
        excitation_gradients = np.einsum(
            "eip,eid->epd",
            excitation_element_values,
            self.basis_gradients,
        )
        adjoint_gradients = np.einsum(
            "eip,eid->epd",
            adjoint_element_values,
            self.basis_gradients,
        )

        jacobian = np.empty(
            (self.protocol.n_exc * self.protocol.n_meas, self.mesh.n_elems),
            dtype=float,
        )
        row_index = 0
        for excitation_index in range(self.protocol.n_exc):
            for _ in range(self.protocol.n_meas):
                adjoint_index = measurement_pair_indices[row_index]
                gradient_product = np.einsum(
                    "ed,ed->e",
                    excitation_gradients[:, excitation_index],
                    adjoint_gradients[:, adjoint_index],
                )
                jacobian[row_index] = -self.areas * gradient_product
                row_index += 1
        return jacobian


def reconstruct_cem_tikhonov(
    jacobian: np.ndarray,
    difference_voltage: np.ndarray,
    lambda_reg: float,
    p: float = 0.5,
) -> np.ndarray:
    """Solve a NOSER/Kotre-style regularized linearized CEM inverse problem."""

    if lambda_reg <= 0.0:
        raise ValueError("lambda_reg must be positive")
    jacobian_matrix = np.asarray(jacobian, dtype=float)
    voltage_vector = np.asarray(difference_voltage, dtype=float)
    normal_matrix = jacobian_matrix.T @ jacobian_matrix
    diagonal = np.diag(normal_matrix)
    diagonal_floor = max(float(np.max(diagonal)) * 1e-12, np.finfo(float).eps)
    regularizer = np.maximum(diagonal, diagonal_floor) ** p
    system = normal_matrix + lambda_reg * np.diag(regularizer)
    right_hand_side = jacobian_matrix.T @ voltage_vector
    return scipy.linalg.solve(
        system,
        right_hand_side,
        assume_a="pos",
        check_finite=False,
    )


def build_cem_tikhonov_operator(
    jacobian: np.ndarray,
    lambda_reg: float,
    p: float = 0.5,
) -> np.ndarray:
    """Build the reusable linear map from voltage differences to conductivity."""

    if lambda_reg <= 0.0:
        raise ValueError("lambda_reg must be positive")
    jacobian_matrix = np.asarray(jacobian, dtype=float)
    normal_matrix = jacobian_matrix.T @ jacobian_matrix
    diagonal = np.diag(normal_matrix)
    diagonal_floor = max(float(np.max(diagonal)) * 1e-12, np.finfo(float).eps)
    regularizer = np.maximum(diagonal, diagonal_floor) ** p
    system = normal_matrix + lambda_reg * np.diag(regularizer)
    return scipy.linalg.solve(
        system,
        jacobian_matrix.T,
        assume_a="pos",
        check_finite=False,
    )
