from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Protocol

import numpy as np
import scipy.linalg
import scipy.sparse as sparse


class AbsoluteEITForward(Protocol):
    """Minimal interface required by the nonlinear inverse solver."""

    def solve_protocol(self, conductivity: np.ndarray): ...

    def compute_jacobian(self, conductivity: np.ndarray) -> np.ndarray: ...


@dataclass(frozen=True)
class NonlinearEITConfig:
    """Configuration for log-conductivity Gauss-Newton reconstruction."""

    max_iterations: int = 30
    tv_weight: float = 1e-4
    l2_weight: float = 1e-4
    tv_epsilon: float = 1e-3
    lm_damping: float = 1e-2
    min_conductivity: float = 0.05
    max_conductivity: float = 3.0
    line_search_decay: float = 0.5
    minimum_step_length: float = 1.0 / 128.0
    maximum_damping_trials: int = 5
    relative_step_tolerance: float = 1e-3
    relative_objective_tolerance: float = 5e-4
    data_scale: float | None = None

    def __post_init__(self) -> None:
        if self.max_iterations <= 0:
            raise ValueError("max_iterations must be positive")
        if self.tv_weight < 0.0 or self.l2_weight < 0.0:
            raise ValueError("regularization weights must be non-negative")
        if self.tv_epsilon <= 0.0 or self.lm_damping <= 0.0:
            raise ValueError("tv_epsilon and lm_damping must be positive")
        if not 0.0 < self.min_conductivity < self.max_conductivity:
            raise ValueError("conductivity bounds are invalid")
        if not 0.0 < self.line_search_decay < 1.0:
            raise ValueError("line_search_decay must be between zero and one")
        if not 0.0 < self.minimum_step_length <= 1.0:
            raise ValueError("minimum_step_length must be in (0, 1]")


@dataclass(frozen=True)
class NonlinearIteration:
    iteration: int
    objective: float
    data_objective: float
    tv_objective: float
    l2_objective: float
    relative_voltage_error: float
    relative_step_norm: float
    step_length: float
    damping: float
    min_conductivity: float
    max_conductivity: float


@dataclass(frozen=True)
class NonlinearEITResult:
    conductivity: np.ndarray
    predicted_voltage: np.ndarray
    history: tuple[NonlinearIteration, ...]
    converged: bool
    stop_reason: str
    data_scale: float


class CellGraphTV:
    """Smoothed isotropic-like TV on the dual graph of a 2D triangle mesh."""

    def __init__(self, nodes: np.ndarray, elements: np.ndarray) -> None:
        nodes_2d = np.asarray(nodes, dtype=float)[:, :2]
        triangles = np.asarray(elements, dtype=np.int64)[:, :3]
        edge_to_cells: dict[tuple[int, int], list[int]] = {}
        for cell_index, triangle in enumerate(triangles):
            for first, second in (
                (triangle[0], triangle[1]),
                (triangle[1], triangle[2]),
                (triangle[2], triangle[0]),
            ):
                edge = tuple(sorted((int(first), int(second))))
                edge_to_cells.setdefault(edge, []).append(cell_index)

        centers = nodes_2d[triangles].mean(axis=1)
        cell_pairs: list[tuple[int, int]] = []
        base_weights: list[float] = []
        for edge, adjacent_cells in edge_to_cells.items():
            if len(adjacent_cells) == 1:
                continue
            if len(adjacent_cells) != 2:
                raise ValueError("mesh is not manifold at an interior edge")
            first_cell, second_cell = adjacent_cells
            edge_length = float(
                np.linalg.norm(nodes_2d[edge[0]] - nodes_2d[edge[1]])
            )
            center_distance = float(
                np.linalg.norm(centers[first_cell] - centers[second_cell])
            )
            if center_distance <= 0.0:
                raise ValueError("adjacent cells have identical centers")
            cell_pairs.append((first_cell, second_cell))
            base_weights.append(edge_length / center_distance)

        self.cell_pairs = np.asarray(cell_pairs, dtype=np.int64)
        self.base_weights = np.asarray(base_weights, dtype=float)
        self.n_cells = int(triangles.shape[0])
        n_edges = int(self.cell_pairs.shape[0])
        rows = np.repeat(np.arange(n_edges, dtype=np.int64), 2)
        columns = self.cell_pairs.reshape(-1)
        values = np.tile(np.array([-1.0, 1.0]), n_edges)
        self.difference = sparse.coo_matrix(
            (values, (rows, columns)),
            shape=(n_edges, self.n_cells),
        ).tocsr()

    def value(self, conductivity: np.ndarray, epsilon: float) -> float:
        differences = self.difference @ np.asarray(conductivity, dtype=float)
        return float(
            np.sum(
                self.base_weights
                * np.sqrt(differences**2 + epsilon**2)
            )
        )

    def lagged_laplacian(
        self,
        conductivity: np.ndarray,
        epsilon: float,
    ) -> sparse.csr_matrix:
        differences = self.difference @ np.asarray(conductivity, dtype=float)
        lagged_weights = self.base_weights / np.sqrt(
            differences**2 + epsilon**2
        )
        return (
            self.difference.T
            @ sparse.diags(lagged_weights, format="csr")
            @ self.difference
        ).tocsr()


def _objective_components(
    predicted: np.ndarray,
    measured: np.ndarray,
    conductivity: np.ndarray,
    log_conductivity: np.ndarray,
    reference_log_conductivity: np.ndarray,
    data_scale: float,
    tv: CellGraphTV,
    config: NonlinearEITConfig,
) -> tuple[float, float, float, float]:
    scaled_residual = (predicted - measured) / data_scale
    data_objective = 0.5 * float(scaled_residual @ scaled_residual)
    tv_objective = config.tv_weight * tv.value(
        conductivity,
        config.tv_epsilon,
    )
    reference_difference = log_conductivity - reference_log_conductivity
    l2_objective = 0.5 * config.l2_weight * float(
        reference_difference @ reference_difference
    )
    total = data_objective + tv_objective + l2_objective
    return total, data_objective, tv_objective, l2_objective


def solve_absolute_eit(
    forward_solver: AbsoluteEITForward,
    measured_voltage: np.ndarray,
    initial_conductivity: np.ndarray,
    nodes: np.ndarray,
    elements: np.ndarray,
    config: NonlinearEITConfig | None = None,
    callback: Callable[[NonlinearIteration, np.ndarray], None] | None = None,
) -> NonlinearEITResult:
    """Solve absolute EIT using log-conductivity Gauss-Newton and TV-IRLS.

    The log parameterization and clipping enforce strict positivity. TV is
    optimized by a lagged-diffusivity/IRLS Hessian, while a backtracking line
    search checks the true nonlinear CEM objective after every trial step.
    """

    settings = config or NonlinearEITConfig()
    measured = np.asarray(measured_voltage, dtype=float).reshape(-1)
    initial = np.asarray(initial_conductivity, dtype=float).copy()
    n_cells = np.asarray(elements).shape[0]
    if initial.shape != (n_cells,):
        raise ValueError("initial_conductivity must contain one value per cell")
    if np.any(initial <= 0.0):
        raise ValueError("initial_conductivity must be strictly positive")

    lower_log = float(np.log(settings.min_conductivity))
    upper_log = float(np.log(settings.max_conductivity))
    log_conductivity = np.clip(np.log(initial), lower_log, upper_log)
    reference_log = log_conductivity.copy()
    conductivity = np.exp(log_conductivity)
    tv = CellGraphTV(nodes, elements)

    if settings.data_scale is None:
        data_scale = float(np.linalg.norm(measured) / np.sqrt(measured.size))
    else:
        data_scale = float(settings.data_scale)
    if not np.isfinite(data_scale) or data_scale <= 0.0:
        raise ValueError("data_scale must be positive and finite")

    predicted = np.asarray(
        forward_solver.solve_protocol(conductivity).measurements,
        dtype=float,
    )
    if predicted.shape != measured.shape:
        raise ValueError("forward solver and measured voltage shapes disagree")
    objective = _objective_components(
        predicted,
        measured,
        conductivity,
        log_conductivity,
        reference_log,
        data_scale,
        tv,
        settings,
    )
    history: list[NonlinearIteration] = []
    damping = settings.lm_damping
    converged = False
    stop_reason = "maximum_iterations"

    for iteration_index in range(1, settings.max_iterations + 1):
        jacobian_sigma = np.asarray(
            forward_solver.compute_jacobian(conductivity),
            dtype=float,
        )
        if jacobian_sigma.shape != (measured.size, n_cells):
            raise ValueError("forward solver returned an invalid Jacobian shape")
        jacobian_log = jacobian_sigma * conductivity[None, :]
        scaled_jacobian = jacobian_log / data_scale
        scaled_target = (measured - predicted) / data_scale
        data_normal = scaled_jacobian.T @ scaled_jacobian
        data_right_hand_side = scaled_jacobian.T @ scaled_target

        tv_laplacian = tv.lagged_laplacian(
            conductivity,
            settings.tv_epsilon,
        )
        conductivity_diagonal = sparse.diags(conductivity, format="csr")
        tv_hessian = (
            conductivity_diagonal
            @ tv_laplacian
            @ conductivity_diagonal
        ).toarray()
        tv_gradient = conductivity * (tv_laplacian @ conductivity)
        l2_difference = log_conductivity - reference_log
        base_hessian = (
            data_normal
            + settings.tv_weight * tv_hessian
            + settings.l2_weight * np.eye(n_cells)
        )
        base_right_hand_side = (
            data_right_hand_side
            - settings.tv_weight * tv_gradient
            - settings.l2_weight * l2_difference
        )
        diagonal_scale = np.maximum(
            np.diag(data_normal),
            max(float(np.max(np.diag(data_normal))) * 1e-8, 1e-10),
        )

        accepted = False
        accepted_step = 0.0
        accepted_delta = np.zeros_like(log_conductivity)
        accepted_objective = objective
        accepted_prediction = predicted
        accepted_log = log_conductivity
        accepted_conductivity = conductivity
        trial_damping = damping

        for _ in range(settings.maximum_damping_trials):
            system = base_hessian + trial_damping * np.diag(diagonal_scale)
            try:
                delta = scipy.linalg.solve(
                    system,
                    base_right_hand_side,
                    assume_a="pos",
                    check_finite=False,
                )
            except scipy.linalg.LinAlgError:
                trial_damping *= 10.0
                continue

            step_length = 1.0
            while step_length >= settings.minimum_step_length:
                trial_log = np.clip(
                    log_conductivity + step_length * delta,
                    lower_log,
                    upper_log,
                )
                trial_conductivity = np.exp(trial_log)
                trial_prediction = np.asarray(
                    forward_solver.solve_protocol(
                        trial_conductivity
                    ).measurements,
                    dtype=float,
                )
                trial_objective = _objective_components(
                    trial_prediction,
                    measured,
                    trial_conductivity,
                    trial_log,
                    reference_log,
                    data_scale,
                    tv,
                    settings,
                )
                if trial_objective[0] < objective[0]:
                    accepted = True
                    accepted_step = step_length
                    accepted_delta = trial_log - log_conductivity
                    accepted_objective = trial_objective
                    accepted_prediction = trial_prediction
                    accepted_log = trial_log
                    accepted_conductivity = trial_conductivity
                    break
                step_length *= settings.line_search_decay
            if accepted:
                break
            trial_damping *= 10.0

        if not accepted:
            stop_reason = "line_search_failed"
            break

        previous_total = objective[0]
        relative_step = float(
            np.linalg.norm(accepted_delta)
            / max(np.linalg.norm(log_conductivity), np.sqrt(n_cells))
        )
        log_conductivity = accepted_log
        conductivity = accepted_conductivity
        predicted = accepted_prediction
        objective = accepted_objective
        damping = max(settings.lm_damping * 1e-3, trial_damping * 0.5)
        relative_voltage_error = float(
            np.linalg.norm(predicted - measured) / np.linalg.norm(measured)
        )
        record = NonlinearIteration(
            iteration=iteration_index,
            objective=objective[0],
            data_objective=objective[1],
            tv_objective=objective[2],
            l2_objective=objective[3],
            relative_voltage_error=relative_voltage_error,
            relative_step_norm=relative_step,
            step_length=accepted_step,
            damping=trial_damping,
            min_conductivity=float(np.min(conductivity)),
            max_conductivity=float(np.max(conductivity)),
        )
        history.append(record)
        if callback is not None:
            callback(record, conductivity.copy())

        relative_objective_change = (previous_total - objective[0]) / max(
            abs(previous_total),
            np.finfo(float).eps,
        )
        if relative_step <= settings.relative_step_tolerance:
            converged = True
            stop_reason = "relative_step_tolerance"
            break
        if relative_objective_change <= settings.relative_objective_tolerance:
            converged = True
            stop_reason = "relative_objective_tolerance"
            break

    return NonlinearEITResult(
        conductivity=conductivity,
        predicted_voltage=predicted,
        history=tuple(history),
        converged=converged,
        stop_reason=stop_reason,
        data_scale=data_scale,
    )
