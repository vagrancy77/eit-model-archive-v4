from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class EllipticInclusion:
    center_x: float
    center_y: float
    axis_x: float
    axis_y: float
    angle: float
    conductivity: float


@dataclass(frozen=True)
class DiverseInclusion:
    kind: str
    center_x: float
    center_y: float
    axis_x: float
    axis_y: float
    angle: float
    conductivity: float


SHAPE_KIND_TO_CODE = {
    "ellipse": 0,
    "circle": 1,
    "rectangle": 2,
    "triangle": 3,
    "capsule": 4,
}


def sample_random_inclusions(
    rng: np.random.Generator,
    minimum_count: int = 1,
    maximum_count: int = 4,
) -> tuple[EllipticInclusion, ...]:
    """Sample simple but diverse inclusions inside the unit disk."""

    if minimum_count <= 0 or maximum_count < minimum_count:
        raise ValueError("invalid inclusion-count range")
    count = int(rng.integers(minimum_count, maximum_count + 1))
    inclusions: list[EllipticInclusion] = []
    for _ in range(count):
        axis_x = float(rng.uniform(0.12, 0.30))
        axis_y = float(rng.uniform(0.10, 0.27))
        maximum_center_radius = max(0.15, 0.88 - max(axis_x, axis_y))
        center_radius = maximum_center_radius * np.sqrt(float(rng.uniform()))
        center_angle = float(rng.uniform(-np.pi, np.pi))
        center_x = center_radius * np.cos(center_angle)
        center_y = center_radius * np.sin(center_angle)
        angle = float(rng.uniform(-np.pi, np.pi))
        if rng.uniform() < 0.68:
            conductivity = float(rng.uniform(0.15, 0.75))
        else:
            conductivity = float(rng.uniform(1.25, 2.10))
        inclusions.append(
            EllipticInclusion(
                center_x=center_x,
                center_y=center_y,
                axis_x=axis_x,
                axis_y=axis_y,
                angle=angle,
                conductivity=conductivity,
            )
        )
    return tuple(inclusions)


def apply_inclusions(
    nodes: np.ndarray,
    elements: np.ndarray,
    inclusions: tuple[EllipticInclusion, ...],
    background: float = 1.0,
) -> np.ndarray:
    """Rasterize the same analytic inclusions on an arbitrary triangle mesh."""

    if background <= 0.0:
        raise ValueError("background must be positive")
    nodes_2d = np.asarray(nodes, dtype=float)[:, :2]
    triangles = np.asarray(elements, dtype=np.int64)[:, :3]
    centers = nodes_2d[triangles].mean(axis=1)
    conductivity = np.full(triangles.shape[0], background, dtype=float)
    for inclusion in inclusions:
        shifted_x = centers[:, 0] - inclusion.center_x
        shifted_y = centers[:, 1] - inclusion.center_y
        cosine = np.cos(inclusion.angle)
        sine = np.sin(inclusion.angle)
        local_x = cosine * shifted_x + sine * shifted_y
        local_y = -sine * shifted_x + cosine * shifted_y
        mask = (
            (local_x / inclusion.axis_x) ** 2
            + (local_y / inclusion.axis_y) ** 2
            <= 1.0
        )
        conductivity[mask] = inclusion.conductivity
    return conductivity


def inclusions_to_arrays(
    inclusions: tuple[EllipticInclusion, ...],
    maximum_count: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    centers = np.full((maximum_count, 2), np.nan, dtype=np.float32)
    axes = np.full((maximum_count, 2), np.nan, dtype=np.float32)
    angles = np.full(maximum_count, np.nan, dtype=np.float32)
    conductivities = np.full(maximum_count, np.nan, dtype=np.float32)
    for index, inclusion in enumerate(inclusions):
        centers[index] = [inclusion.center_x, inclusion.center_y]
        axes[index] = [inclusion.axis_x, inclusion.axis_y]
        angles[index] = inclusion.angle
        conductivities[index] = inclusion.conductivity
    return centers, axes, angles, conductivities


def sample_diverse_inclusions(
    rng: np.random.Generator,
    minimum_count: int = 1,
    maximum_count: int = 5,
) -> tuple[DiverseInclusion, ...]:
    """Sample a broader family of lesion geometries for independent tests."""

    if minimum_count <= 0 or maximum_count < minimum_count:
        raise ValueError("invalid inclusion-count range")
    count = int(rng.integers(minimum_count, maximum_count + 1))
    kind_names = ("ellipse", "circle", "rectangle", "triangle", "capsule")
    kind_probabilities = np.asarray([0.30, 0.18, 0.22, 0.18, 0.12], dtype=float)
    kind_probabilities = kind_probabilities / kind_probabilities.sum()
    inclusions: list[DiverseInclusion] = []
    for _ in range(count):
        kind = str(rng.choice(kind_names, p=kind_probabilities))
        if kind == "circle":
            axis_x = axis_y = float(rng.uniform(0.10, 0.24))
        elif kind == "ellipse":
            axis_x = float(rng.uniform(0.12, 0.30))
            axis_y = float(rng.uniform(0.08, min(axis_x, 0.26)))
        elif kind == "rectangle":
            axis_x = float(rng.uniform(0.12, 0.28))
            axis_y = float(rng.uniform(0.08, 0.22))
        elif kind == "triangle":
            axis_x = float(rng.uniform(0.11, 0.27))
            axis_y = float(rng.uniform(0.10, 0.25))
        elif kind == "capsule":
            axis_y = float(rng.uniform(0.05, 0.13))
            axis_x = float(rng.uniform(axis_y * 2.4, 0.32))
        else:
            raise ValueError(f"unknown kind {kind}")
        maximum_center_radius = max(0.18, 0.90 - max(axis_x, axis_y))
        center_radius = maximum_center_radius * np.sqrt(float(rng.uniform()))
        center_angle = float(rng.uniform(-np.pi, np.pi))
        center_x = center_radius * np.cos(center_angle)
        center_y = center_radius * np.sin(center_angle)
        angle = float(rng.uniform(-np.pi, np.pi))
        if rng.uniform() < 0.55:
            conductivity = float(rng.uniform(0.12, 0.80))
        else:
            conductivity = float(rng.uniform(1.22, 2.35))
        inclusions.append(
            DiverseInclusion(
                kind=kind,
                center_x=center_x,
                center_y=center_y,
                axis_x=axis_x,
                axis_y=axis_y,
                angle=angle,
                conductivity=conductivity,
            )
        )
    return tuple(inclusions)


def apply_diverse_inclusions(
    nodes: np.ndarray,
    elements: np.ndarray,
    inclusions: tuple[DiverseInclusion, ...],
    background: float = 1.0,
) -> np.ndarray:
    """Rasterize a heterogeneous inclusion family on a triangle mesh."""

    if background <= 0.0:
        raise ValueError("background must be positive")
    nodes_2d = np.asarray(nodes, dtype=float)[:, :2]
    triangles = np.asarray(elements, dtype=np.int64)[:, :3]
    centers = nodes_2d[triangles].mean(axis=1)
    conductivity = np.full(triangles.shape[0], background, dtype=float)

    def rotate_points(points: np.ndarray, angle: float) -> np.ndarray:
        cosine = np.cos(angle)
        sine = np.sin(angle)
        rotation = np.asarray([[cosine, -sine], [sine, cosine]], dtype=float)
        return points @ rotation.T

    from matplotlib.path import Path as MplPath

    for inclusion in inclusions:
        shifted_x = centers[:, 0] - inclusion.center_x
        shifted_y = centers[:, 1] - inclusion.center_y
        cosine = np.cos(inclusion.angle)
        sine = np.sin(inclusion.angle)
        local_x = cosine * shifted_x + sine * shifted_y
        local_y = -sine * shifted_x + cosine * shifted_y
        if inclusion.kind in {"ellipse", "circle"}:
            mask = (
                (local_x / inclusion.axis_x) ** 2
                + (local_y / inclusion.axis_y) ** 2
                <= 1.0
            )
        elif inclusion.kind == "rectangle":
            mask = (np.abs(local_x) <= inclusion.axis_x) & (np.abs(local_y) <= inclusion.axis_y)
        elif inclusion.kind == "triangle":
            vertices = np.asarray(
                [
                    [0.0, inclusion.axis_y],
                    [-inclusion.axis_x, -inclusion.axis_y],
                    [inclusion.axis_x, -inclusion.axis_y],
                ],
                dtype=float,
            )
            polygon = rotate_points(vertices, inclusion.angle) + np.asarray(
                [inclusion.center_x, inclusion.center_y], dtype=float
            )
            mask = MplPath(polygon).contains_points(centers)
        elif inclusion.kind == "capsule":
            half_length = max(inclusion.axis_x - inclusion.axis_y, 0.0)
            rect = (np.abs(local_x) <= half_length) & (np.abs(local_y) <= inclusion.axis_y)
            cap_left = (local_x + half_length) ** 2 + local_y**2 <= inclusion.axis_y**2
            cap_right = (local_x - half_length) ** 2 + local_y**2 <= inclusion.axis_y**2
            mask = rect | cap_left | cap_right
        else:
            raise ValueError(f"unknown inclusion kind {inclusion.kind}")
        conductivity[mask] = inclusion.conductivity
    return conductivity


def diverse_inclusions_to_arrays(
    inclusions: tuple[DiverseInclusion, ...],
    maximum_count: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    centers = np.full((maximum_count, 2), np.nan, dtype=np.float32)
    axes = np.full((maximum_count, 2), np.nan, dtype=np.float32)
    angles = np.full(maximum_count, np.nan, dtype=np.float32)
    conductivities = np.full(maximum_count, np.nan, dtype=np.float32)
    kinds = np.full(maximum_count, -1, dtype=np.int16)
    for index, inclusion in enumerate(inclusions):
        centers[index] = [inclusion.center_x, inclusion.center_y]
        axes[index] = [inclusion.axis_x, inclusion.axis_y]
        angles[index] = inclusion.angle
        conductivities[index] = inclusion.conductivity
        kinds[index] = SHAPE_KIND_TO_CODE[inclusion.kind]
    return centers, axes, angles, conductivities, kinds
