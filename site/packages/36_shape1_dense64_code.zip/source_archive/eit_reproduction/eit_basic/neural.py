from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from pathlib import Path

import numpy as np


@dataclass(frozen=True)
class MLPConfig:
    hidden_units: int = 128
    epochs: int = 220
    batch_size: int = 32
    learning_rate: float = 1e-3
    weight_decay: float = 1e-5
    patience: int = 30
    seed: int = 20260717

    def __post_init__(self) -> None:
        if self.hidden_units <= 0 or self.epochs <= 0 or self.batch_size <= 0:
            raise ValueError("network dimensions and training lengths must be positive")
        if self.learning_rate <= 0.0 or self.weight_decay < 0.0:
            raise ValueError("invalid optimizer parameters")
        if self.patience <= 0:
            raise ValueError("patience must be positive")


@dataclass(frozen=True)
class TrainingHistory:
    train_loss: np.ndarray
    validation_loss: np.ndarray
    best_epoch: int


class ResidualMLP:
    """One-hidden-layer residual MLP implemented only with NumPy.

    The network learns a correction to a physics-based linear CEM
    reconstruction. This keeps the baseline small, reproducible and usable in
    the existing Python 3.14 environment where PyTorch wheels are unavailable.
    """

    def __init__(self, input_size: int, output_size: int, hidden_units: int) -> None:
        self.input_size = int(input_size)
        self.output_size = int(output_size)
        self.hidden_units = int(hidden_units)
        self.input_mean = np.zeros(self.input_size, dtype=np.float32)
        self.input_scale = np.ones(self.input_size, dtype=np.float32)
        self.output_mean = np.zeros(self.output_size, dtype=np.float32)
        self.output_scale = np.float32(1.0)
        self.weight_1 = np.empty(
            (self.input_size, self.hidden_units),
            dtype=np.float32,
        )
        self.bias_1 = np.zeros(self.hidden_units, dtype=np.float32)
        self.weight_2 = np.empty(
            (self.hidden_units, self.output_size),
            dtype=np.float32,
        )
        self.bias_2 = np.zeros(self.output_size, dtype=np.float32)

    def _initialize(self, rng: np.random.Generator) -> None:
        self.weight_1[:] = rng.normal(
            0.0,
            np.sqrt(2.0 / self.input_size),
            size=self.weight_1.shape,
        ).astype(np.float32)
        self.weight_2[:] = rng.normal(
            0.0,
            np.sqrt(1.0 / self.hidden_units),
            size=self.weight_2.shape,
        ).astype(np.float32)
        self.bias_1.fill(0.0)
        self.bias_2.fill(0.0)

    def _normalize_input(self, features: np.ndarray) -> np.ndarray:
        return (
            (np.asarray(features, dtype=np.float32) - self.input_mean)
            / self.input_scale
        )

    def _normalize_output(self, targets: np.ndarray) -> np.ndarray:
        return (
            np.asarray(targets, dtype=np.float32) - self.output_mean
        ) / self.output_scale

    def _forward_normalized(
        self,
        normalized_features: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray]:
        hidden_pre_activation = normalized_features @ self.weight_1 + self.bias_1
        hidden = np.maximum(hidden_pre_activation, 0.0)
        prediction = hidden @ self.weight_2 + self.bias_2
        return prediction, hidden

    def fit(
        self,
        train_features: np.ndarray,
        train_targets: np.ndarray,
        validation_features: np.ndarray,
        validation_targets: np.ndarray,
        config: MLPConfig | None = None,
        callback=None,
    ) -> TrainingHistory:
        settings = config or MLPConfig(hidden_units=self.hidden_units)
        if settings.hidden_units != self.hidden_units:
            raise ValueError("config hidden_units does not match the model")
        train_x = np.asarray(train_features, dtype=np.float32)
        train_y = np.asarray(train_targets, dtype=np.float32)
        validation_x = np.asarray(validation_features, dtype=np.float32)
        validation_y = np.asarray(validation_targets, dtype=np.float32)
        if train_x.ndim != 2 or train_x.shape[1] != self.input_size:
            raise ValueError("invalid training feature shape")
        if train_y.shape != (train_x.shape[0], self.output_size):
            raise ValueError("invalid training target shape")
        if validation_x.shape[1:] != (self.input_size,) or validation_y.shape != (
            validation_x.shape[0],
            self.output_size,
        ):
            raise ValueError("invalid validation shapes")

        self.input_mean = train_x.mean(axis=0)
        self.input_scale = train_x.std(axis=0)
        scale_floor = max(float(np.median(self.input_scale)) * 1e-3, 1e-6)
        self.input_scale = np.maximum(self.input_scale, scale_floor)
        self.output_mean = train_y.mean(axis=0)
        self.output_scale = np.float32(max(float(train_y.std()), 1e-6))
        normalized_train_x = self._normalize_input(train_x)
        normalized_train_y = self._normalize_output(train_y)
        normalized_validation_x = self._normalize_input(validation_x)
        normalized_validation_y = self._normalize_output(validation_y)

        rng = np.random.default_rng(settings.seed)
        self._initialize(rng)
        parameters = [self.weight_1, self.bias_1, self.weight_2, self.bias_2]
        first_moments = [np.zeros_like(parameter) for parameter in parameters]
        second_moments = [np.zeros_like(parameter) for parameter in parameters]
        beta_1, beta_2 = 0.9, 0.999
        epsilon = 1e-8
        optimizer_step = 0
        train_losses: list[float] = []
        validation_losses: list[float] = []
        best_validation = float("inf")
        best_epoch = 0
        best_parameters = [parameter.copy() for parameter in parameters]
        epochs_without_improvement = 0

        for epoch in range(1, settings.epochs + 1):
            order = rng.permutation(train_x.shape[0])
            for start in range(0, train_x.shape[0], settings.batch_size):
                batch_indices = order[start : start + settings.batch_size]
                batch_x = normalized_train_x[batch_indices]
                batch_y = normalized_train_y[batch_indices]
                prediction, hidden = self._forward_normalized(batch_x)
                error = prediction - batch_y
                gradient_prediction = (2.0 / error.size) * error
                gradient_weight_2 = (
                    hidden.T @ gradient_prediction
                    + settings.weight_decay * self.weight_2
                )
                gradient_bias_2 = gradient_prediction.sum(axis=0)
                gradient_hidden = gradient_prediction @ self.weight_2.T
                gradient_hidden[hidden <= 0.0] = 0.0
                gradient_weight_1 = (
                    batch_x.T @ gradient_hidden
                    + settings.weight_decay * self.weight_1
                )
                gradient_bias_1 = gradient_hidden.sum(axis=0)
                gradients = [
                    gradient_weight_1,
                    gradient_bias_1,
                    gradient_weight_2,
                    gradient_bias_2,
                ]

                optimizer_step += 1
                for index, (parameter, gradient) in enumerate(
                    zip(parameters, gradients, strict=True)
                ):
                    first_moments[index] = (
                        beta_1 * first_moments[index]
                        + (1.0 - beta_1) * gradient
                    )
                    second_moments[index] = (
                        beta_2 * second_moments[index]
                        + (1.0 - beta_2) * gradient**2
                    )
                    corrected_first = first_moments[index] / (
                        1.0 - beta_1**optimizer_step
                    )
                    corrected_second = second_moments[index] / (
                        1.0 - beta_2**optimizer_step
                    )
                    parameter -= settings.learning_rate * corrected_first / (
                        np.sqrt(corrected_second) + epsilon
                    )

            train_prediction, _ = self._forward_normalized(normalized_train_x)
            validation_prediction, _ = self._forward_normalized(
                normalized_validation_x
            )
            train_loss = float(np.mean((train_prediction - normalized_train_y) ** 2))
            validation_loss = float(
                np.mean((validation_prediction - normalized_validation_y) ** 2)
            )
            train_losses.append(train_loss)
            validation_losses.append(validation_loss)
            if callback is not None:
                callback(epoch, train_loss, validation_loss)

            if validation_loss < best_validation - 1e-7:
                best_validation = validation_loss
                best_epoch = epoch
                best_parameters = [parameter.copy() for parameter in parameters]
                epochs_without_improvement = 0
            else:
                epochs_without_improvement += 1
                if epochs_without_improvement >= settings.patience:
                    break

        for parameter, best in zip(parameters, best_parameters, strict=True):
            parameter[:] = best
        return TrainingHistory(
            train_loss=np.asarray(train_losses, dtype=float),
            validation_loss=np.asarray(validation_losses, dtype=float),
            best_epoch=best_epoch,
        )

    def predict_correction(self, features: np.ndarray) -> np.ndarray:
        normalized = self._normalize_input(features)
        prediction, _ = self._forward_normalized(normalized)
        return prediction * self.output_scale + self.output_mean

    def save(self, path: Path, config: MLPConfig) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(
            path,
            input_size=np.array(self.input_size),
            output_size=np.array(self.output_size),
            hidden_units=np.array(self.hidden_units),
            input_mean=self.input_mean,
            input_scale=self.input_scale,
            output_mean=self.output_mean,
            output_scale=np.array(self.output_scale),
            weight_1=self.weight_1,
            bias_1=self.bias_1,
            weight_2=self.weight_2,
            bias_2=self.bias_2,
            config_json=np.array(json.dumps(asdict(config))),
        )

    @classmethod
    def load(cls, path: Path) -> "ResidualMLP":
        saved = np.load(path)
        model = cls(
            input_size=int(saved["input_size"]),
            output_size=int(saved["output_size"]),
            hidden_units=int(saved["hidden_units"]),
        )
        for name in (
            "input_mean",
            "input_scale",
            "output_mean",
            "weight_1",
            "bias_1",
            "weight_2",
            "bias_2",
        ):
            setattr(model, name, np.asarray(saved[name], dtype=np.float32))
        model.output_scale = np.float32(saved["output_scale"])
        return model


def sample_correlation(truth: np.ndarray, prediction: np.ndarray) -> np.ndarray:
    truth_centered = truth - truth.mean(axis=1, keepdims=True)
    prediction_centered = prediction - prediction.mean(axis=1, keepdims=True)
    numerator = np.sum(truth_centered * prediction_centered, axis=1)
    denominator = np.linalg.norm(truth_centered, axis=1) * np.linalg.norm(
        prediction_centered,
        axis=1,
    )
    return np.divide(
        numerator,
        denominator,
        out=np.full_like(numerator, np.nan, dtype=float),
        where=denominator > 0.0,
    )


def sample_relative_l2(truth: np.ndarray, prediction: np.ndarray) -> np.ndarray:
    denominator = np.linalg.norm(truth, axis=1)
    return np.divide(
        np.linalg.norm(prediction - truth, axis=1),
        denominator,
        out=np.full_like(denominator, np.nan, dtype=float),
        where=denominator > 0.0,
    )
