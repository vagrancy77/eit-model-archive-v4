from __future__ import annotations

import copy

import numpy as np
from pyeit.mesh.wrapper import PyEITMesh


def element_centers(mesh: PyEITMesh) -> np.ndarray:
    """Return the two-dimensional center of every triangular element."""

    triangles = mesh.element[:, :3]
    return mesh.node[triangles, :2].mean(axis=1)


def ellipse_mask(
    points: np.ndarray,
    center: tuple[float, float],
    radii: tuple[float, float],
    angle_degrees: float = 0.0,
) -> np.ndarray:
    """Return a boolean mask for a possibly rotated ellipse."""

    translated = points - np.asarray(center, dtype=float)
    angle = np.deg2rad(angle_degrees)
    cosine = np.cos(angle)
    sine = np.sin(angle)
    x_rotated = cosine * translated[:, 0] + sine * translated[:, 1]
    y_rotated = -sine * translated[:, 0] + cosine * translated[:, 1]
    radius_x, radius_y = radii
    return (x_rotated / radius_x) ** 2 + (y_rotated / radius_y) ** 2 <= 1.0


def circle_mask(
    points: np.ndarray,
    center: tuple[float, float],
    radius: float,
) -> np.ndarray:
    """Return a boolean mask for a circle."""

    displacement = points - np.asarray(center, dtype=float)
    return np.sum(displacement**2, axis=1) <= radius**2


def build_heart_lung_phantom(
    mesh: PyEITMesh,
    background: float = 1.0,
    lung: float = 0.25,
    heart: float = 1.5,
) -> tuple[PyEITMesh, np.ndarray]:
    """Create a simple lung-heart conductivity distribution.

    Conductivity is defined per triangular element. The geometry is chosen to
    resemble the first circular simulation in the SDEIT paper while remaining
    well separated on a coarse teaching mesh.
    """

    centers = element_centers(mesh)
    conductivity = np.full(mesh.n_elems, background, dtype=float)

    left_lung = ellipse_mask(
        centers,
        center=(-0.38, 0.16),
        radii=(0.22, 0.42),
        angle_degrees=-8.0,
    )
    right_lung = ellipse_mask(
        centers,
        center=(0.38, 0.16),
        radii=(0.22, 0.42),
        angle_degrees=8.0,
    )
    heart_region = circle_mask(centers, center=(0.0, -0.38), radius=0.19)

    conductivity[left_lung | right_lung] = lung
    conductivity[heart_region] = heart

    phantom_mesh = copy.deepcopy(mesh)
    phantom_mesh.perm = conductivity
    return phantom_mesh, conductivity

