from __future__ import annotations

from pathlib import Path

import numpy as np


def load_measurement_vector(
    path: Path,
    expected_size: int,
    key: str = "voltage",
    csv_column: str = "noisy",
) -> np.ndarray:
    """Load one measurement frame from NPY, NPZ or a named CSV column."""

    suffix = path.suffix.lower()
    if suffix == ".npy":
        values = np.load(path)
    elif suffix == ".npz":
        archive = np.load(path)
        if key not in archive:
            raise KeyError(f"NPZ file does not contain key {key!r}")
        values = archive[key]
    elif suffix == ".csv":
        table = np.genfromtxt(path, delimiter=",", names=True)
        if table.dtype.names is None or csv_column not in table.dtype.names:
            raise KeyError(f"CSV file does not contain column {csv_column!r}")
        values = table[csv_column]
    else:
        raise ValueError("measurement file must be .npy, .npz or .csv")

    vector = np.asarray(values, dtype=float).reshape(-1)
    if vector.size != expected_size:
        raise ValueError(
            f"expected {expected_size} measurements, received {vector.size}"
        )
    if not np.all(np.isfinite(vector)):
        raise ValueError("measurement vector contains NaN or infinity")
    return vector
