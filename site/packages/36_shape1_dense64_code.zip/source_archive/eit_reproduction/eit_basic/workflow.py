from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pyeit.mesh as mesh
import pyeit.eit.protocol as protocol
from pyeit.eit.fem import EITForward
from pyeit.eit.jac import JAC
from pyeit.eit.protocol import PyEITProtocol
from pyeit.mesh.wrapper import PyEITMesh

from .cem import CEMForward, reconstruct_cem_tikhonov
from .config import EITConfig
from .noise import add_gaussian_noise_at_snr
from .phantom import build_heart_lung_phantom


@dataclass
class EITResult:
    config: EITConfig
    forward_mesh: PyEITMesh
    inverse_mesh: PyEITMesh
    forward_phantom_mesh: PyEITMesh
    inverse_truth_mesh: PyEITMesh
    protocol: PyEITProtocol
    conductivity_true_forward: np.ndarray
    conductivity_true_inverse: np.ndarray
    voltage_background: np.ndarray
    voltage_clean: np.ndarray
    voltage_noisy: np.ndarray
    voltage_noise: np.ndarray
    actual_snr_db: float
    first_excitation_potential: np.ndarray
    reconstruction_delta: np.ndarray
    jacobian: np.ndarray | None
    truth_delta: np.ndarray
    reconstruction_correlation: float
    forward_electrode_edges: np.ndarray | None
    forward_electrode_ids: np.ndarray | None
    forward_electrode_lengths: np.ndarray | None
    inverse_electrode_lengths: np.ndarray | None


def _safe_correlation(first: np.ndarray, second: np.ndarray) -> float:
    if np.std(first) == 0.0 or np.std(second) == 0.0:
        return float("nan")
    return float(np.corrcoef(first, second)[0, 1])


def run_eit_pipeline(config: EITConfig) -> EITResult:
    """Run mesh creation, forward simulation, noise and JAC reconstruction."""

    forward_mesh = mesh.create(
        n_el=config.n_electrodes,
        h0=config.forward_mesh_size,
    )
    inverse_mesh = mesh.create(
        n_el=config.n_electrodes,
        h0=config.inverse_mesh_size,
    )
    forward_mesh.perm = np.full(
        forward_mesh.n_elems,
        config.background_conductivity,
        dtype=float,
    )
    inverse_mesh.perm = np.full(
        inverse_mesh.n_elems,
        config.background_conductivity,
        dtype=float,
    )
    forward_phantom_mesh, conductivity_true_forward = build_heart_lung_phantom(
        forward_mesh,
        background=config.background_conductivity,
        lung=config.lung_conductivity,
        heart=config.heart_conductivity,
    )
    inverse_truth_mesh, conductivity_true_inverse = build_heart_lung_phantom(
        inverse_mesh,
        background=config.background_conductivity,
        lung=config.lung_conductivity,
        heart=config.heart_conductivity,
    )

    protocol_object = protocol.create(
        n_el=config.n_electrodes,
        dist_exc=1,
        step_meas=1,
        parser_meas="std",
    )

    if config.forward_model == "cem":
        forward_solver = CEMForward(
            forward_mesh,
            protocol_object,
            electrode_width=config.electrode_width,
            contact_impedance=config.contact_impedance,
            current_amplitude=config.current_amplitude,
        )
        background_solution = forward_solver.solve_protocol(forward_mesh.perm)
        phantom_solution = forward_solver.solve_protocol(conductivity_true_forward)
        voltage_background = background_solution.measurements
        voltage_clean = phantom_solution.measurements
        first_excitation_potential = phantom_solution.node_potentials[:, 0]

        inverse_solver = CEMForward(
            inverse_mesh,
            protocol_object,
            electrode_width=config.electrode_width,
            contact_impedance=config.contact_impedance,
            current_amplitude=config.current_amplitude,
        )
        jacobian = inverse_solver.compute_jacobian(inverse_mesh.perm)
        forward_electrode_edges = forward_solver.electrodes.edge_nodes
        forward_electrode_ids = forward_solver.electrodes.edge_electrode_ids
        forward_electrode_lengths = forward_solver.electrodes.electrode_lengths
        inverse_electrode_lengths = inverse_solver.electrodes.electrode_lengths
    elif config.forward_model == "point":
        forward_solver = EITForward(forward_mesh, protocol_object)
        voltage_background = np.real(
            forward_solver.solve_eit(perm=forward_mesh.perm)
        )
        voltage_clean = np.real(
            forward_solver.solve_eit(perm=conductivity_true_forward)
        )
        forward_solver.assemble_pde(conductivity_true_forward)
        first_excitation_potential = np.real(
            forward_solver.solve(protocol_object.ex_mat[0])
        )

        inverse_solver = JAC(inverse_mesh, protocol_object)
        inverse_solver.setup(
            p=config.jacobian_p,
            lamb=config.lambda_reg,
            method="kotre",
            perm=config.background_conductivity,
        )
        jacobian = None
        forward_electrode_edges = None
        forward_electrode_ids = None
        forward_electrode_lengths = None
        inverse_electrode_lengths = None
    else:
        raise ValueError("forward_model must be either 'cem' or 'point'")

    voltage_noisy, voltage_noise, actual_snr_db = add_gaussian_noise_at_snr(
        voltage_clean,
        snr_db=config.snr_db,
        random_seed=config.random_seed,
    )

    if config.forward_model == "cem":
        reconstruction_delta = reconstruct_cem_tikhonov(
            jacobian,
            voltage_noisy - voltage_background,
            lambda_reg=config.lambda_reg,
            p=config.jacobian_p,
        )
    else:
        reconstruction_delta = np.real(
            inverse_solver.solve(
                voltage_noisy,
                voltage_background,
                normalize=False,
            )
        )

    truth_delta = conductivity_true_inverse - config.background_conductivity
    reconstruction_correlation = _safe_correlation(
        truth_delta,
        reconstruction_delta,
    )

    return EITResult(
        config=config,
        forward_mesh=forward_mesh,
        inverse_mesh=inverse_mesh,
        forward_phantom_mesh=forward_phantom_mesh,
        inverse_truth_mesh=inverse_truth_mesh,
        protocol=protocol_object,
        conductivity_true_forward=conductivity_true_forward,
        conductivity_true_inverse=conductivity_true_inverse,
        voltage_background=voltage_background,
        voltage_clean=voltage_clean,
        voltage_noisy=voltage_noisy,
        voltage_noise=voltage_noise,
        actual_snr_db=actual_snr_db,
        first_excitation_potential=first_excitation_potential,
        reconstruction_delta=reconstruction_delta,
        jacobian=jacobian,
        truth_delta=truth_delta,
        reconstruction_correlation=reconstruction_correlation,
        forward_electrode_edges=forward_electrode_edges,
        forward_electrode_ids=forward_electrode_ids,
        forward_electrode_lengths=forward_electrode_lengths,
        inverse_electrode_lengths=inverse_electrode_lengths,
    )
