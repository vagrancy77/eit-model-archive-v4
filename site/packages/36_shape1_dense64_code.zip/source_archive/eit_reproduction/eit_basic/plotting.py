from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np

from .workflow import EITResult


def _draw_electrodes(ax: plt.Axes, result: EITResult) -> None:
    electrode_nodes = result.forward_mesh.el_pos
    electrode_positions = result.forward_mesh.node[electrode_nodes, :2]
    if result.forward_electrode_edges is not None:
        for edge in result.forward_electrode_edges:
            edge_coordinates = result.forward_mesh.node[edge, :2]
            ax.plot(
                edge_coordinates[:, 0],
                edge_coordinates[:, 1],
                color="crimson",
                linewidth=4.0,
                solid_capstyle="round",
                zorder=3,
            )
    else:
        ax.scatter(
            electrode_positions[:, 0],
            electrode_positions[:, 1],
            s=32,
            c="crimson",
            edgecolors="white",
            linewidths=0.5,
            zorder=3,
        )
    for index, position in enumerate(electrode_positions):
        ax.text(
            position[0] * 1.08,
            position[1] * 1.08,
            str(index),
            ha="center",
            va="center",
            fontsize=7,
        )


def save_pipeline_figure(result: EITResult, output_path: Path) -> None:
    """Save a compact visual summary of the complete stage-1 pipeline."""

    output_path.parent.mkdir(parents=True, exist_ok=True)
    forward_nodes = result.forward_mesh.node[:, :2]
    forward_elements = result.forward_mesh.element[:, :3]
    inverse_nodes = result.inverse_mesh.node[:, :2]
    inverse_elements = result.inverse_mesh.element[:, :3]

    figure, axes = plt.subplots(2, 3, figsize=(15, 9), constrained_layout=True)

    mesh_axis = axes[0, 0]
    mesh_axis.triplot(
        forward_nodes[:, 0],
        forward_nodes[:, 1],
        forward_elements,
        color="0.82",
        linewidth=0.25,
        label="forward mesh",
    )
    mesh_axis.triplot(
        inverse_nodes[:, 0],
        inverse_nodes[:, 1],
        inverse_elements,
        color="#2468a2",
        linewidth=0.45,
        alpha=0.78,
        label="inverse mesh",
    )
    _draw_electrodes(mesh_axis, result)
    mesh_axis.set_title(
        "Independent forward/inverse meshes\n"
        f"forward: {result.forward_mesh.n_nodes}/{result.forward_mesh.n_elems}, "
        f"inverse: {result.inverse_mesh.n_nodes}/{result.inverse_mesh.n_elems}"
    )
    mesh_axis.legend(loc="lower center", fontsize=8)

    truth_axis = axes[0, 1]
    truth_image = truth_axis.tripcolor(
        forward_nodes[:, 0],
        forward_nodes[:, 1],
        forward_elements,
        facecolors=result.conductivity_true_forward,
        shading="flat",
        cmap="turbo",
        vmin=min(result.config.lung_conductivity, result.config.background_conductivity),
        vmax=max(result.config.heart_conductivity, result.config.background_conductivity),
    )
    truth_axis.set_title("Ground-truth conductivity")
    figure.colorbar(truth_image, ax=truth_axis, shrink=0.82)

    potential_axis = axes[0, 2]
    potential_image = potential_axis.tripcolor(
        forward_nodes[:, 0],
        forward_nodes[:, 1],
        forward_elements,
        result.first_excitation_potential,
        shading="gouraud",
        cmap="coolwarm",
    )
    first_pair = result.protocol.ex_mat[0]
    potential_axis.set_title(
        f"Potential field, excitation {first_pair[0]} -> {first_pair[1]}"
    )
    figure.colorbar(potential_image, ax=potential_axis, shrink=0.82)

    voltage_axis = axes[1, 0]
    difference_clean = result.voltage_clean - result.voltage_background
    difference_noisy = result.voltage_noisy - result.voltage_background
    voltage_axis.plot(difference_clean, label="clean", linewidth=1.2)
    voltage_axis.plot(
        difference_noisy,
        label="noisy",
        linewidth=0.8,
        alpha=0.75,
    )
    voltage_axis.set_title(
        f"Difference voltages ({difference_clean.size} measurements)"
    )
    voltage_axis.set_xlabel("Measurement index")
    voltage_axis.set_ylabel("Voltage difference (a.u.)")
    voltage_axis.grid(alpha=0.25)
    voltage_axis.legend()

    reconstruction_axis = axes[1, 1]
    scale = float(np.percentile(np.abs(result.reconstruction_delta), 99.0))
    scale = max(scale, np.finfo(float).eps)
    reconstruction_image = reconstruction_axis.tripcolor(
        inverse_nodes[:, 0],
        inverse_nodes[:, 1],
        inverse_elements,
        facecolors=result.reconstruction_delta,
        shading="flat",
        cmap="coolwarm",
        vmin=-scale,
        vmax=scale,
    )
    reconstruction_axis.set_title(
        "JAC/Tikhonov reconstruction\n"
        f"correlation with truth = {result.reconstruction_correlation:.3f}"
    )
    figure.colorbar(reconstruction_image, ax=reconstruction_axis, shrink=0.82)

    comparison_axis = axes[1, 2]
    comparison_axis.scatter(
        result.truth_delta,
        result.reconstruction_delta,
        s=8,
        alpha=0.45,
    )
    comparison_axis.axhline(0.0, color="0.4", linewidth=0.7)
    comparison_axis.axvline(0.0, color="0.4", linewidth=0.7)
    comparison_axis.set_title("Element-wise truth vs reconstruction")
    comparison_axis.set_xlabel("True conductivity change")
    comparison_axis.set_ylabel("Reconstructed change")
    comparison_axis.grid(alpha=0.25)

    for axis in axes.flat[:3]:
        axis.set_aspect("equal")
        axis.set_xlim(-1.15, 1.15)
        axis.set_ylim(-1.15, 1.15)
        axis.set_xlabel("x")
        axis.set_ylabel("y")

    figure.suptitle(
        f"{result.config.forward_model.upper()} EIT pipeline | "
        f"adjacent drive/measure | "
        f"target SNR {result.config.snr_db:.1f} dB",
        fontsize=14,
    )
    figure.savefig(output_path, dpi=180)
    plt.close(figure)
