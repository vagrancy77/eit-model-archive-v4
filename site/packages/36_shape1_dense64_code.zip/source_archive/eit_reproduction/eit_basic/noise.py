from __future__ import annotations

import numpy as np


def measured_snr_db(signal: np.ndarray, noise: np.ndarray) -> float:
    """Compute the L2 signal-to-noise ratio in decibels."""

    signal_norm = np.linalg.norm(signal)
    noise_norm = np.linalg.norm(noise)
    if noise_norm == 0.0:
        return float("inf")
    return float(20.0 * np.log10(signal_norm / noise_norm))


def add_gaussian_noise_at_snr(
    signal: np.ndarray,
    snr_db: float,
    random_seed: int,
) -> tuple[np.ndarray, np.ndarray, float]:
    """Add zero-mean Gaussian noise rescaled to an exact L2 SNR."""

    signal_array = np.asarray(signal)
    if signal_array.size == 0:
        raise ValueError("signal must not be empty")

    rng = np.random.default_rng(random_seed)
    raw_noise = rng.standard_normal(signal_array.shape)
    raw_norm = np.linalg.norm(raw_noise)
    signal_norm = np.linalg.norm(signal_array)
    if raw_norm == 0.0 or signal_norm == 0.0:
        raise ValueError("signal and generated noise must have non-zero norm")

    target_noise_norm = signal_norm / (10.0 ** (snr_db / 20.0))
    noise = raw_noise * (target_noise_norm / raw_norm)
    noisy_signal = signal_array + noise
    return noisy_signal, noise, measured_snr_db(signal_array, noise)

