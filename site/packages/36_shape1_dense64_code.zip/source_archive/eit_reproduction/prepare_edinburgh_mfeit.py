"""Validate Edinburgh mfEIT and create deterministic, leakage-free splits.

The original arrays remain memory mapped in place.  This adapter writes only a
small manifest containing split indices, voltage normalization statistics and
the circular reconstruction mask.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


CASE_SIZES = {1: 3000, 2: 4000, 3: 5414}
TRAIN_COUNT = 8700
VALIDATION_COUNT = 1900
TEST_COUNT = 1814


def circular_mask(pixels: int = 64) -> np.ndarray:
    coordinate = np.linspace(-1.0 + 1.0 / pixels, 1.0 - 1.0 / pixels, pixels)
    x, y = np.meshgrid(coordinate, coordinate, indexing="xy")
    return (x * x + y * y <= 1.0).astype(np.float32)


def largest_remainder(total: int, sizes: list[int]) -> list[int]:
    raw = np.asarray(sizes, dtype=np.float64) * (float(total) / float(sum(sizes)))
    result = np.floor(raw).astype(np.int64)
    remainder = total - int(result.sum())
    order = np.argsort(-(raw - result), kind="stable")
    result[order[:remainder]] += 1
    return result.tolist()


def validate_source(source: Path, full_validation: bool) -> dict[str, object]:
    information: dict[str, object] = {}
    for case, expected_samples in CASE_SIZES.items():
        image = np.load(source / f"img{case}.npy", mmap_mode="r")
        voltage = np.load(source / f"V{case}.npy", mmap_mode="r")
        if image.shape != (expected_samples, 256, 64):
            raise ValueError(f"img{case}.npy has unexpected shape {image.shape}")
        if voltage.shape != (expected_samples, 4, 104):
            raise ValueError(f"V{case}.npy has unexpected shape {voltage.shape}")
        if image.dtype != np.float64 or voltage.dtype != np.float64:
            raise ValueError(f"case {case} is expected to contain float64 arrays")

        if full_validation:
            indices = np.arange(expected_samples, dtype=np.int64)
        else:
            indices = np.unique(np.linspace(0, expected_samples - 1, 128, dtype=np.int64))
        shared = True
        finite = True
        for start in range(0, len(indices), 32):
            chunk_indices = indices[start : start + 32]
            target = np.asarray(image[chunk_indices]).reshape(-1, 4, 64, 64)
            measured = np.asarray(voltage[chunk_indices])
            finite = finite and bool(np.isfinite(target).all() and np.isfinite(measured).all())
            support = np.abs(target) > 1e-8
            shared = shared and bool(np.all(support == support[:, :1]))
        if not finite:
            raise ValueError(f"case {case} contains non-finite values")
        if not shared:
            raise ValueError(f"case {case} violates the shared-geometry assumption")
        information[f"case_{case}"] = {
            "samples": expected_samples,
            "image_shape": list(image.shape),
            "voltage_shape": list(voltage.shape),
            "shared_support_validated": True,
            "validation_samples": int(len(indices)),
        }
    return information


def build_splits(seed: int) -> dict[str, np.ndarray]:
    cases = sorted(CASE_SIZES)
    sizes = [CASE_SIZES[case] for case in cases]
    train_per_case = largest_remainder(TRAIN_COUNT, sizes)
    validation_per_case = largest_remainder(VALIDATION_COUNT, sizes)
    result: dict[str, list[np.ndarray]] = {
        "train_case": [],
        "train_index": [],
        "validation_case": [],
        "validation_index": [],
        "test_case": [],
        "test_index": [],
    }
    rng = np.random.default_rng(seed)
    for case, size, train_count, validation_count in zip(cases, sizes, train_per_case, validation_per_case):
        permutation = rng.permutation(size).astype(np.int64)
        partitions = {
            "train": permutation[:train_count],
            "validation": permutation[train_count : train_count + validation_count],
            "test": permutation[train_count + validation_count :],
        }
        for split, indices in partitions.items():
            result[f"{split}_case"].append(np.full(indices.shape, case, dtype=np.int8))
            result[f"{split}_index"].append(indices)
    joined = {name: np.concatenate(parts) for name, parts in result.items()}
    if len(joined["train_index"]) != TRAIN_COUNT:
        raise RuntimeError("training split size mismatch")
    if len(joined["validation_index"]) != VALIDATION_COUNT:
        raise RuntimeError("validation split size mismatch")
    if len(joined["test_index"]) != TEST_COUNT:
        raise RuntimeError("testing split size mismatch")
    return joined


def voltage_statistics(source: Path, case_ids: np.ndarray, sample_indices: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    total = np.zeros(104, dtype=np.float64)
    total_squared = np.zeros(104, dtype=np.float64)
    observations = 0
    for case in sorted(CASE_SIZES):
        selected = sample_indices[case_ids == case]
        voltage = np.load(source / f"V{case}.npy", mmap_mode="r")
        for start in range(0, len(selected), 512):
            chunk = np.asarray(voltage[selected[start : start + 512]], dtype=np.float64)
            total += chunk.sum(axis=(0, 1))
            total_squared += np.square(chunk).sum(axis=(0, 1))
            observations += chunk.shape[0] * chunk.shape[1]
    mean = total / observations
    variance = np.maximum(total_squared / observations - np.square(mean), 1e-12)
    return mean.astype(np.float32), np.sqrt(variance).astype(np.float32)


def main() -> None:
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Prepare the public Edinburgh four-frequency mfEIT dataset.")
    parser.add_argument(
        "--source",
        type=Path,
        default=root / "datasets" / "public" / "edinburgh_mfeit" / "raw" / "Edinburgh_mfEIT_Dataset",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=root / "datasets" / "public" / "edinburgh_mfeit" / "edinburgh_mfeit_manifest_v1.npz",
    )
    parser.add_argument("--seed", type=int, default=20260729)
    parser.add_argument("--full-validation", action="store_true")
    arguments = parser.parse_args()

    required = [arguments.source / f"{prefix}{case}.npy" for case in CASE_SIZES for prefix in ("img", "V")]
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise FileNotFoundError(f"missing Edinburgh files: {missing}")

    source_information = validate_source(arguments.source, arguments.full_validation)
    splits = build_splits(arguments.seed)
    voltage_mean, voltage_std = voltage_statistics(
        arguments.source, splits["train_case"], splits["train_index"]
    )
    mask = circular_mask(64)
    if int(mask.sum()) != 3228:
        raise RuntimeError(f"unexpected reconstruction-mask size: {int(mask.sum())}")

    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        arguments.output,
        **splits,
        voltage_mean=voltage_mean,
        voltage_std=voltage_std,
        frequency_coordinate=np.arange(1, 5, dtype=np.float32),
        reconstruction_mask=mask,
        source_root=np.asarray(str(arguments.source.resolve())),
    )
    summary = {
        "name": "Edinburgh mfEIT Dataset",
        "doi": "10.7488/ds/3464",
        "license": "CC BY 4.0",
        "citation": "Chen, Zhou; Yang, Yunjie; Xiang, Jinxi; Bagnaninchi, Pierre (2022)",
        "source_root": str(arguments.source.resolve()),
        "manifest": str(arguments.output.resolve()),
        "samples": sum(CASE_SIZES.values()),
        "split_sizes": {"train": TRAIN_COUNT, "validation": VALIDATION_COUNT, "test": TEST_COUNT},
        "split_seed": arguments.seed,
        "frequencies": {
            "published_labels": ["f1", "f2", "f3", "f4"],
            "physical_values": None,
            "warning": "The release does not identify f1-f4 in kHz; models use ordinal coordinates only.",
        },
        "target": {
            "stored_quantity": "normalized conductivity change (sigma_mea - sigma_ref) / sigma_ref",
            "background_conductivity_s_per_m": 2.0,
            "training_quantity": "anomaly magnitude = clip(-normalized conductivity change, 0, 1)",
            "shared_geometry": "object size and position are fixed across all four channels",
        },
        "conductivity_groups_s_per_m": [
            [0.01, 0.6, 1.2, 1.8],
            [0.4, 0.6, 0.8, 1.0],
            [0.8, 1.0, 1.2, 1.4],
        ],
        "forward_model": "COMSOL Multiphysics and MATLAB, 16 electrodes, adjacent protocol, 104 measurements",
        "source_validation": source_information,
        "suitable_for": [
            "supervised four-channel mfEIT reconstruction",
            "shared-lesion-geometry versus frequency-specific-contrast ablation",
            "single-frame versus paired multi-frequency comparison",
        ],
        "not_suitable_for": [
            "claiming performance at a named physical kHz value",
            "clinical generalization without an independent real-data experiment",
            "validating a CEM forward model because the public release used COMSOL and omits contact parameters",
        ],
    }
    with arguments.output.with_suffix(".json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
