import numpy as np
import scipy as sp
import torch
import torch.nn.functional as F
from PIL import Image
from utils import KTCMeshing
from utils import KTCFwd
from utils import KTCScoring
from utils import DIPAux

try:
    from torchmetrics.image import TotalVariation
except ModuleNotFoundError:
    class TotalVariation(torch.nn.Module):
        """Minimal fallback for torchmetrics.image.TotalVariation."""

        def forward(self, image: torch.Tensor) -> torch.Tensor:
            vertical = torch.abs(image[:, :, 1:, :] - image[:, :, :-1, :]).sum()
            horizontal = torch.abs(image[:, :, :, 1:] - image[:, :, :, :-1]).sum()
            return vertical + horizontal

# Use of GPU
if torch.cuda.is_available():
  torch.backends.cudnn.enabled = True
  torch.backends.cudnn.benchmark = True
  dtype = torch.cuda.DoubleTensor
  map_location = 'cuda:0'
else:
  torch.backends.cudnn.enabled = False
  torch.backends.cudnn.benchmark = False
  dtype = torch.DoubleTensor
  map_location = 'cpu'

def solve(
    inputData,
    categoryNbr,
    num_iter_override=None,
    progress_every=0,
    return_details=False,
    prior_mask=None,
    prior_reliability=None,
    geo_lambda=0.0,
    hard_prior=False,
    learn_reliability=False,
    reliability_reg=0.0,
    learn_registration=False,
    registration_reg=0.0,
    registration_max_shift=12.0,
    registration_max_angle=15.0,
    registration_max_log_scale=0.12,
    reliability_fallback=False,
    tv_weight=5e-8,
    tv_mode="l1",
    tv_epsilon=1e-3,
    tv_power=0.5,
    input_noise_std=0.04,
    upsample_mode="bilinear",
    opening_iterations=10,
    interpolation_mode="lowpass",
    interpolation_sigma=8e-3,
    architecture_num_scales=6,
    solver_matrices_override=None,
    reference_data_path=None,
):
    img_resolution = 128
    linpoint = 0.7927
    deltaU_fac = 2
    dist_mode = interpolation_mode
    if dist_mode not in ("lowpass", "nearest"):
        raise ValueError("interpolation_mode must be 'lowpass' or 'nearest'")
    dist_sigma = float(interpolation_sigma)

    skip_n11=32
    num_scales = int(architecture_num_scales)
    if not 2 <= num_scales <= 6:
        raise ValueError("architecture_num_scales must be between 2 and 6")
    skip_n33d=[16, 16, 32, 32, 64, 64][:num_scales]
    skip_n33u=[16, 16, 32, 32, 64, 64][:num_scales]

    solver_dict = (
        get_solver_matrices(
            inputData,
            categoryNbr,
            linpoint,
            reference_data_path=reference_data_path,
        )
        if solver_matrices_override is None
        else solver_matrices_override
    )
    J = torch.from_numpy(solver_dict['J']).type(dtype)
    deltaU = torch.from_numpy(solver_dict['deltaU']).type(dtype) * deltaU_fac

    dist = calc_dist(solver_dict['coordinates'], x_d=img_resolution,
                    y_d=img_resolution, mode=dist_mode, sigma=dist_sigma)
    dist = torch.from_numpy(dist).type(dtype)

    c_mask = get_mask(img_resolution)
    c_mask = torch.from_numpy(c_mask).type(dtype)

    # Optional ultrasound-style geometric prior.  With no prior, the
    # original DIP+TV objective is unchanged.  A hard prior gates the image;
    # a soft prior adds an outside-support penalty.  Reliability is an
    # elementwise confidence map in [0, 1].
    prior_mask_tensor = None
    prior_reliability_tensor = None
    reliability_logits = None
    registration_raw = None
    if prior_mask is not None:
        prior_array = np.asarray(prior_mask, dtype=np.float64)
        if prior_array.ndim == 2:
            prior_array = prior_array[None, None, :, :]
        elif prior_array.ndim == 3:
            prior_array = prior_array[None, :, :, :]
        if prior_array.shape[-2:] != (img_resolution, img_resolution):
            prior_array = F.interpolate(
                torch.from_numpy(prior_array),
                size=(img_resolution, img_resolution),
                mode="bilinear",
                align_corners=False,
            ).numpy()
        prior_mask_tensor = torch.from_numpy(np.clip(prior_array, 0.0, 1.0)).type(dtype)
        if prior_reliability is None:
            prior_reliability = np.ones_like(prior_array, dtype=np.float64)
        reliability_array = np.asarray(prior_reliability, dtype=np.float64)
        if reliability_array.ndim == 2:
            reliability_array = reliability_array[None, None, :, :]
        elif reliability_array.ndim == 3:
            reliability_array = reliability_array[None, :, :, :]
        if reliability_array.shape[-2:] != (img_resolution, img_resolution):
            reliability_array = F.interpolate(
                torch.from_numpy(reliability_array),
                size=(img_resolution, img_resolution),
                mode="bilinear",
                align_corners=False,
            ).numpy()
        prior_reliability_tensor = torch.from_numpy(np.clip(reliability_array, 0.0, 1.0)).type(dtype)
        if learn_reliability:
            initial_reliability = np.clip(reliability_array, 0.05, 0.95)
            initial_logits = np.log(initial_reliability / (1.0 - initial_reliability))
            reliability_logits = torch.nn.Parameter(torch.from_numpy(initial_logits).type(dtype))
        if learn_registration:
            # Raw parameters are mapped through tanh to bounded translations,
            # rotation, and log-scale changes.  Bounds keep the learned warp
            # physically plausible and prevent the prior from leaving the
            # circular EIT field of view.
            registration_raw = torch.nn.Parameter(
                torch.zeros(4, dtype=torch.float64, device=("cuda" if torch.cuda.is_available() else "cpu"))
            )
   
    # Parameters
    input_depth = 32 #16
    input_type = 'noise'
    OPT_OVER = 'net'

    # Optimization Parameters
    OPTIMIZER = 'adam'
    pad = 'reflection'
    NET_TYPE = 'skip'
    LR = 3.5e-3
    reg_noise_std = float(input_noise_std)
    num_iter = 3000 if num_iter_override is None else int(num_iter_override)
    w_tv = float(tv_weight)
    tv = TotalVariation().to(map_location)

    deblur_input = DIPAux.get_noise(input_depth,input_type,
                (img_resolution,img_resolution)).type(dtype).detach()

    deblur_net = DIPAux.get_net(input_depth, NET_TYPE, pad,
            skip_n33d = skip_n33d,
            skip_n33u = skip_n33u,
            skip_n11 = skip_n11,
            n_channels=1,
            num_scales = num_scales,
            upsample_mode=upsample_mode,
            need_sigmoid=False).type(dtype)

    net_input_saved = deblur_input.detach().clone()
    noise = deblur_input.detach().clone()

    p = DIPAux.get_params(OPT_OVER,deblur_net,deblur_input)

    optimizer_parameters = list(p)
    if reliability_logits is not None:
        optimizer_parameters.append(reliability_logits)
    if registration_raw is not None:
        optimizer_parameters.append(registration_raw)
    optimizer = torch.optim.Adam(optimizer_parameters, lr=LR)

    loss_history = []
    geo_loss_history = []

    for i in range(num_iter):
        optimizer.zero_grad()

        if reg_noise_std > 0:
            deblur_input = net_input_saved + (noise.normal_() * reg_noise_std)
        else:
            deblur_input = net_input_saved

        raw_pixels = c_mask * deblur_net(deblur_input)
        warped_prior_mask = prior_mask_tensor
        warped_prior_reliability = prior_reliability_tensor
        if registration_raw is not None and prior_mask_tensor is not None:
            normalized_shift = torch.tanh(registration_raw[:2])
            normalized_angle = torch.tanh(registration_raw[2])
            normalized_log_scale = torch.tanh(registration_raw[3])
            shift_x = normalized_shift[0] * (registration_max_shift / img_resolution) * 2.0
            shift_y = normalized_shift[1] * (registration_max_shift / img_resolution) * 2.0
            angle = normalized_angle * (registration_max_angle * np.pi / 180.0)
            scale = torch.exp(normalized_log_scale * registration_max_log_scale)
            cosine = torch.cos(angle) * scale
            sine = torch.sin(angle) * scale
            theta = torch.stack(
                [
                    torch.stack([cosine, -sine, shift_x]),
                    torch.stack([sine, cosine, shift_y]),
                ]
            )[None]
            grid = F.affine_grid(theta, prior_mask_tensor.shape, align_corners=False)
            warped_prior_mask = F.grid_sample(
                prior_mask_tensor, grid, mode="bilinear", padding_mode="zeros", align_corners=False
            )
            warped_prior_reliability = F.grid_sample(
                prior_reliability_tensor, grid, mode="bilinear", padding_mode="zeros", align_corners=False
            )
        if reliability_logits is not None:
            effective_reliability = torch.sigmoid(reliability_logits)
        else:
            effective_reliability = warped_prior_reliability
        if reliability_fallback and warped_prior_mask is not None:
            # EIT-only fallback: when reliability is low, the raw EIT/DIP
            # image is retained; when it is high, the ultrasound support is
            # applied.  This implements M = R*M_US + (1-R)*M_EIT with the
            # current raw DIP support as the EIT branch.
            fallback_gate = 1.0 - effective_reliability * (1.0 - warped_prior_mask)
            cond_pixels = raw_pixels * fallback_gate
        elif hard_prior and warped_prior_mask is not None:
            cond_pixels = raw_pixels * warped_prior_mask
        else:
            cond_pixels = raw_pixels
        cond_nodes = dist @ cond_pixels[0,0].reshape((-1,1))

        data_loss = F.mse_loss(J @ cond_nodes, deltaU)
        tv_loss = w_tv * spatial_regularizer(
            cond_pixels,
            mode=tv_mode,
            tv_module=tv,
            epsilon=tv_epsilon,
            power=tv_power,
        )
        if warped_prior_mask is not None and geo_lambda > 0:
            geo_loss = geo_lambda * torch.mean(
                effective_reliability
                * torch.square(1.0 - warped_prior_mask)
                * torch.square(raw_pixels)
            )
        else:
            geo_loss = torch.zeros_like(data_loss)
        if reliability_logits is not None and reliability_reg > 0:
            reliability_loss = reliability_reg * torch.mean(torch.square(1.0 - effective_reliability))
        else:
            reliability_loss = torch.zeros_like(data_loss)
        if registration_raw is not None and registration_reg > 0:
            registration_loss = registration_reg * torch.mean(torch.square(registration_raw))
        else:
            registration_loss = torch.zeros_like(data_loss)
        total_loss = data_loss + tv_loss + geo_loss + reliability_loss + registration_loss

        total_loss.backward()

        optimizer.step()

        loss_value = float(total_loss.detach().cpu().item())
        data_loss_value = float(data_loss.detach().cpu().item())
        tv_loss_value = float(tv_loss.detach().cpu().item())
        geo_loss_value = float(geo_loss.detach().cpu().item())
        loss_history.append(loss_value)
        geo_loss_history.append(geo_loss_value)
        if progress_every and ((i + 1) % progress_every == 0 or i == 0 or i + 1 == num_iter):
            print(
                "iter "
                f"{i + 1}/{num_iter}: total={loss_value:.8f}, "
                f"data={data_loss_value:.8f}, tv={tv_loss_value:.8f}, geo={geo_loss_value:.8f}"
            )
    
    cond_pixels_np = np.flipud(cond_pixels[0,0].clone().detach().cpu().numpy())
    cond_pixels_np = np.array(Image.fromarray(cond_pixels_np).resize((256,256)))

    cond_pixels_np_segmented = segment(
        cond_pixels_np,
        opening_iterations=opening_iterations,
    )

    if return_details:
        return cond_pixels_np_segmented, {
            "loss_history": loss_history,
            "geo_loss_history": geo_loss_history,
            "final_total_loss": loss_history[-1] if loss_history else None,
            "continuous_image": cond_pixels_np,
            "segmented_before_opening": segment(
                cond_pixels_np,
                opening_iterations=0,
            ),
            "final_reliability": (
                torch.sigmoid(reliability_logits).detach().cpu().numpy()
                if reliability_logits is not None
                else None
            ),
            "final_registration_raw": (
                registration_raw.detach().cpu().numpy() if registration_raw is not None else None
            ),
        }

    return cond_pixels_np_segmented


def spatial_regularizer(image, mode="l1", tv_module=None, epsilon=1e-3, power=0.5):
    """Spatial priors used by the concavity-preservation experiments.

    ``l1`` is exactly the public solver's anisotropic TV.  ``lp`` and ``log``
    grow sub-linearly for established edges, so they suppress small noisy
    gradients without charging the same linear cost for a sharp, non-convex
    boundary.  Keeping this switch inside the solver lets every variant use
    the identical EIT data term and DIP architecture.
    """
    if mode == "l1":
        if tv_module is None:
            vertical = torch.abs(image[:, :, 1:, :] - image[:, :, :-1, :]).sum()
            horizontal = torch.abs(image[:, :, :, 1:] - image[:, :, :, :-1]).sum()
            return vertical + horizontal
        return tv_module(image)

    vertical = torch.abs(image[:, :, 1:, :] - image[:, :, :-1, :])
    horizontal = torch.abs(image[:, :, :, 1:] - image[:, :, :, :-1])
    epsilon = float(epsilon)
    if epsilon <= 0:
        raise ValueError("tv_epsilon must be positive")

    if mode == "lp":
        power = float(power)
        if not 0 < power < 1:
            raise ValueError("tv_power must lie between 0 and 1 for lp TV")
        vertical_penalty = (vertical + epsilon).pow(power) - epsilon**power
        horizontal_penalty = (horizontal + epsilon).pow(power) - epsilon**power
    elif mode == "log":
        vertical_penalty = epsilon * torch.log1p(vertical / epsilon)
        horizontal_penalty = epsilon * torch.log1p(horizontal / epsilon)
    else:
        raise ValueError(f"unknown tv_mode: {mode}")
    return vertical_penalty.sum() + horizontal_penalty.sum()

def get_solver_matrices(inputData, categoryNbr, lin_point=1, reference_data_path=None):
    Nel = 32  # number of electrodes
    z = (1e-6) * np.ones((Nel, 1))  # contact impedances
    reference_data_path = (
        'utils/reference_files/ref.mat'
        if reference_data_path is None
        else str(reference_data_path)
    )
    mat_dict = sp.io.loadmat(reference_data_path) #load the reference data
    Injref = mat_dict["Injref"] #current injections
    Uelref = mat_dict["Uelref"] #measured voltages from water chamber
    Mpat = mat_dict["Mpat"] #voltage measurement pattern
    vincl = np.ones(((Nel - 1),76), dtype=bool) #which measurements to include in the inversion
    rmind = np.arange(0,2 * (categoryNbr - 1),1) #electrodes whose data is removed

    #remove measurements according to the difficulty level
    for ii in range(0,75):
        for jj in rmind:
            if Injref[jj,ii]:
                vincl[:,ii] = 0
            vincl[jj,:] = 0

    # load premade finite element mesh (made using Gmsh, exported to Matlab and saved into a .mat file)
    mat_dict_mesh = sp.io.loadmat('utils/reference_files/Mesh_sparse.mat')
    g = mat_dict_mesh['g'] #node coordinates
    H = mat_dict_mesh['H'] #indices of nodes making up the triangular elements
    elfaces = mat_dict_mesh['elfaces'][0].tolist() #indices of nodes making up the boundary electrodes

    #Element structure
    ElementT = mat_dict_mesh['Element']['Topology'].tolist()
    for k in range(len(ElementT)):
        ElementT[k] = ElementT[k][0].flatten()
    ElementE = mat_dict_mesh['ElementE'].tolist() #marks elements which are next to boundary electrodes
    for k in range(len(ElementE)):
        if len(ElementE[k][0]) > 0:
            ElementE[k] = [ElementE[k][0][0][0], ElementE[k][0][0][1:len(ElementE[k][0][0])]]
        else:
            ElementE[k] = []

    #Node structure
    NodeC = mat_dict_mesh['Node']['Coordinate']
    NodeE = mat_dict_mesh['Node']['ElementConnection'] #marks which elements a node belongs to
    nodes = [KTCMeshing.NODE(coord[0].flatten(), []) for coord in NodeC]
    for k in range(NodeC.shape[0]):
        nodes[k].ElementConnection = NodeE[k][0].flatten()
    elements = [KTCMeshing.ELEMENT(ind, []) for ind in ElementT]
    for k in range(len(ElementT)):
        elements[k].Electrode = ElementE[k]

    #2nd order mesh data
    H2 = mat_dict_mesh['H2']
    g2 = mat_dict_mesh['g2']
    elfaces2 = mat_dict_mesh['elfaces2'][0].tolist()
    ElementT2 = mat_dict_mesh['Element2']['Topology']
    ElementT2 = ElementT2.tolist()
    for k in range(len(ElementT2)):
        ElementT2[k] = ElementT2[k][0].flatten()
    ElementE2 = mat_dict_mesh['Element2E']
    ElementE2 = ElementE2.tolist()
    for k in range(len(ElementE2)):
        if len(ElementE2[k][0]) > 0:
            ElementE2[k] = [ElementE2[k][0][0][0], ElementE2[k][0][0][1:len(ElementE2[k][0][0])]]
        else:
            ElementE2[k] = []

    NodeC2 = mat_dict_mesh['Node2']['Coordinate']  # ok
    NodeE2 = mat_dict_mesh['Node2']['ElementConnection']  # ok
    nodes2 = [KTCMeshing.NODE(coord[0].flatten(), []) for coord in NodeC2]
    for k in range(NodeC2.shape[0]):
        nodes2[k].ElementConnection = NodeE2[k][0].flatten()
    elements2 = [KTCMeshing.ELEMENT(ind, []) for ind in ElementT2]
    for k in range(len(ElementT2)):
        elements2[k].Electrode = ElementE2[k]

    Mesh = KTCMeshing.Mesh(H,g,elfaces,nodes,elements)
    Mesh2 = KTCMeshing.Mesh(H2,g2,elfaces2,nodes2,elements2)

    sigma0 = np.ones((len(Mesh.g), 1))*lin_point #linearization point
    corrlength = 1 * 0.115 #used in the prior
    var_sigma = 0.05 ** 2 #prior variance
    mean_sigma = sigma0

    # set up the forward solver for inversion
    solver = KTCFwd.EITFEM(Mesh2, Injref, Mpat, vincl)

    vincl = vincl.T.flatten()

    # set up the noise model for inversion
    noise_std1 = 0.05;  # standard deviation for first noise component (relative to each voltage measurement)
    noise_std2 = 0.01;  # standard deviation for second noise component (relative to the largest voltage measurement)
    solver.SetInvGamma(noise_std1, noise_std2, Uelref)

    mat_dict2 = sp.io.loadmat(inputData)
    Uel = mat_dict2["Uel"]
    deltaU = Uel[vincl] - Uelref[vincl]

    Usim = solver.SolveForward(sigma0, z) #forward solution at the linearization point
    J = solver.Jacobian(sigma0, z)

    outputs = {"J": J,
                "deltaU": deltaU,
                "coordinates":np.array([coord[0].flatten() for coord in NodeC]),
                # Exposed for nonlinear/model-mismatch diagnostics.  The
                # standard DIP path only consumes the three arrays above.
                "forward_solver": solver,
                "sigma0": sigma0,
                "contact_impedance": z,
                "reference_forward": Usim,
              }

    return outputs

def calc_dist(nodes_coordinates, x_d=256, y_d=256, mode='nearest', sigma=5e-7):
    nodes_coordinates = nodes_coordinates.copy().T
    nodes_coordinates = nodes_coordinates[[1,0],:]
    n_elements = nodes_coordinates.shape[1]

    x_min = np.min(nodes_coordinates[0,:])
    y_min = np.min(nodes_coordinates[1,:])

    x_max = np.max(nodes_coordinates[0,:])
    y_max = np.max(nodes_coordinates[1,:])

    b = [x_min, y_min]
    a = [0, 0]
    a[0] = (x_max - x_min) / x_d
    a[1] = (y_max - y_min) / y_d

    xp = np.zeros((x_d,y_d))
    yp = np.zeros((x_d,y_d))

    for i in range(x_d):
        for j in range(y_d):
            xp[i,j] = a[0]*i + b[0]
            yp[i,j] = a[1]*j + b[1]

    xp = xp.reshape(-1)
    yp = yp.reshape(-1)

    dist = np.zeros((n_elements, y_d*x_d))

    if(mode=='nearest'):
        for i in range(n_elements):
            dist[i,:] = ((nodes_coordinates[:,i][:,None] - [xp,yp])**2).sum(axis=0)
            dist[i,:] = dist[i,:] == dist[i,:].min()

    elif(mode=='lowpass'):
        for i in range(n_elements):
            dist[i,:] = ((nodes_coordinates[:,i][:,None] - [xp,yp])**2).sum(axis=0)

        dist = np.exp(-dist**2/(2*sigma**2))
        dist /= (dist.sum(axis=1)+np.finfo(float).eps).reshape(-1,1)

    return dist

def get_mask(n_img):
    Y, X = np.mgrid[0:n_img,0:n_img]

    r = n_img//2 + 1
    xc = n_img//2 - 1
    yc = n_img//2 - 1

    c_mask = (X-xc)**2 + (Y-yc)**2 < r**2

    c_mask = c_mask[None,None,:,:]

    return c_mask

def segment(cond_pixels_np, opening_iterations=10):
    level, x = KTCScoring.Otsu2(cond_pixels_np.flatten(), 256, 7)

    cond_pixels_np_segmented = np.zeros_like(cond_pixels_np)

    ind0 = cond_pixels_np < x[level[0]]
    ind1 = np.logical_and(cond_pixels_np >= x[level[0]],cond_pixels_np <= x[level[1]])
    ind2 = cond_pixels_np > x[level[1]]
    inds = [np.count_nonzero(ind0),np.count_nonzero(ind1),np.count_nonzero(ind2)]
    bgclass = inds.index(max(inds)) #background class

    match bgclass:
        case 0:
            cond_pixels_np_segmented[ind1] = 2
            cond_pixels_np_segmented[ind2] = 2
        case 1:
            cond_pixels_np_segmented[ind0] = 1
            cond_pixels_np_segmented[ind2] = 2
        case 2:
            cond_pixels_np_segmented[ind0] = 1
            cond_pixels_np_segmented[ind1] = 1

    if opening_iterations > 0:
        opening_mask = sp.ndimage.binary_opening(
            cond_pixels_np_segmented,
            iterations=int(opening_iterations),
        )
        cond_pixels_np_segmented = opening_mask * cond_pixels_np_segmented
  
    return cond_pixels_np_segmented
