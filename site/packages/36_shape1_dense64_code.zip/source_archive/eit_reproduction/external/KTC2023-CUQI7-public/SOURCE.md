# KTC2023-CUQI7 public source snapshot

- Upstream: https://github.com/CUQI-DTU/KTC2023-CUQI7
- Retrieved: 2026-08-19
- Purpose: inspect and adapt the published SR-TV-LS nonlinear level-set method.

The files in this directory remain upstream reference material. Project-specific
changes belong under `scripts/` so the source snapshot stays auditable.
