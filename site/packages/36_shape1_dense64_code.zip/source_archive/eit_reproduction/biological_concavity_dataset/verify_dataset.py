"""Audit the released biological-concavity EIT dataset without training."""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import binary_fill_holes, label


ROOT = Path(__file__).resolve().parents[1]
DATASET = ROOT / "datasets" / "biological_concavity_unified_v2"
ID_FAMILIES = {
    "smooth_oval",
    "asymmetric_nodule",
    "smooth_capsule",
    "gentle_lobulated",
    "organ_ovary",
    "smooth_crescent",
    "deep_u",
    "kidney_hilum",
    "asymmetric_bay",
    "organ_lung_lobe",
    "organ_heart",
    "organ_kidney",
}
OOD_FAMILIES = {
    "fused_nodule",
    "scalloped_crescent",
    "double_bay",
    "keyhole_bay",
}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def audit() -> dict[str, object]:
    manifest = json.loads((DATASET / "manifest.json").read_text(encoding="utf-8"))
    expected_samples = int(manifest["synthetic_samples"])

    with (DATASET / "synthetic_metadata.csv").open(
        "r", encoding="utf-8", newline=""
    ) as stream:
        metadata = list(csv.DictReader(stream))
    require(len(metadata) == expected_samples, "metadata row count mismatch")

    with np.load(DATASET / "synthetic_training.npz") as arrays:
        per_sample = (
            "labels",
            "primary_masks",
            "support_masks",
            "cutout_masks",
            "indentation_masks",
            "delta_sigma",
            "signed_distance",
            "family_codes",
            "is_concave",
            "split_codes",
            "snr_db",
            "sample_gain",
            "voltages",
            "linear_images",
        )
        for key in per_sample:
            require(arrays[key].shape[0] == expected_samples, f"{key} sample count mismatch")

        for key in arrays.files:
            value = arrays[key]
            if np.issubdtype(value.dtype, np.floating):
                require(bool(np.isfinite(value).all()), f"{key} contains NaN or Inf")

        split_names = ("train", "validation", "test_id", "test_ood")
        split_index_names = (
            "train_indices",
            "validation_indices",
            "test_id_indices",
            "test_ood_indices",
        )
        split_indices = [arrays[name].astype(np.int64) for name in split_index_names]
        concatenated = np.concatenate(split_indices)
        require(
            np.array_equal(np.sort(concatenated), np.arange(expected_samples)),
            "split indices are not a disjoint cover of all samples",
        )
        for code, (name, indices) in enumerate(zip(split_names, split_indices)):
            require(bool((arrays["split_codes"][indices] == code).all()), f"{name} code mismatch")

        family_by_row = np.asarray([row["family"] for row in metadata])
        organ_families = {"organ_lung_lobe", "organ_heart", "organ_kidney", "organ_ovary"}
        organ_counts = {
            family: int((family_by_row == family).sum()) for family in sorted(organ_families)
        }
        require(
            all(count == 1000 for count in organ_counts.values()),
            f"organ family counts mismatch: {organ_counts}",
        )
        require(
            set(family_by_row[split_indices[0]]).issubset(ID_FAMILIES),
            "OOD family leaked into training",
        )
        require(
            set(family_by_row[split_indices[1]]).issubset(ID_FAMILIES),
            "OOD family leaked into validation",
        )
        require(
            set(family_by_row[split_indices[2]]).issubset(ID_FAMILIES),
            "OOD family leaked into ID test",
        )
        require(
            set(family_by_row[split_indices[3]]) == OOD_FAMILIES,
            "OOD test does not contain exactly the held-out families",
        )

        concave = arrays["is_concave"].astype(bool)
        ordinary = ~concave
        indentation_area = arrays["indentation_masks"].reshape(expected_samples, -1).sum(axis=1)
        cutout_area = arrays["cutout_masks"].reshape(expected_samples, -1).sum(axis=1)
        require(bool((indentation_area[ordinary] == 0).all()), "ordinary cases have indentation targets")
        require(bool((cutout_area[concave] > 0).all()), "concave cases lack cutout targets")
        for family in {"organ_lung_lobe", "organ_heart", "organ_kidney"}:
            indices = np.flatnonzero(family_by_row == family)
            require(bool(concave[indices].all()), f"{family} lacks concavity role")
            require(bool((indentation_area[indices] > 0).all()), f"{family} lacks indentation targets")
        ovary_indices = np.flatnonzero(family_by_row == "organ_ovary")
        require(bool(ordinary[ovary_indices].all()), "organ_ovary is not an ordinary control")
        require(bool((indentation_area[ovary_indices] == 0).all()), "organ_ovary has indentation targets")

        disconnected = 0
        enclosed_holes = 0
        for mask in arrays["primary_masks"].astype(bool):
            disconnected += int(label(mask, structure=np.ones((3, 3), dtype=np.uint8))[1] != 1)
            enclosed_holes += int((binary_fill_holes(mask) & ~mask).sum() > 5)
        require(disconnected == 0, f"{disconnected} primary lesions are disconnected")
        require(enclosed_holes == 0, f"{enclosed_holes} primary lesions contain enclosed holes")

        counts = {
            name: int(len(indices)) for name, indices in zip(split_names, split_indices)
        }
        concave_count = int(concave.sum())

    for filename, record in manifest["files"].items():
        path = DATASET / filename
        require(path.stat().st_size == int(record["bytes"]), f"{filename} size mismatch")
        require(sha256(path) == record["sha256"], f"{filename} SHA-256 mismatch")

    with np.load(DATASET / "benchmark_boolean_paper.npz") as benchmark:
        require(benchmark["labels"].shape[0] == 10, "Boolean benchmark count mismatch")
        require(bool((benchmark["role"] == "benchmark_only").all()), "Boolean role mismatch")
    with np.load(DATASET / "benchmark_ktc2023_biological_subset.npz") as benchmark:
        require(benchmark["voltages"].shape == (6, 2356), "KTC benchmark shape mismatch")
        require(bool((benchmark["role"] == "external_test_only").all()), "KTC role mismatch")
    with np.load(DATASET / "benchmark_act3_style.npz") as benchmark:
        require(benchmark["labels"].shape[0] == 24, "ACT3-style benchmark count mismatch")
        require(
            bool((benchmark["source_type"] == "synthetic_act3_style_not_measurement").all()),
            "ACT3-style provenance is ambiguous",
        )

    return {
        "status": "PASS",
        "synthetic_samples": expected_samples,
        "concave_samples": concave_count,
        "ordinary_samples": expected_samples - concave_count,
        "split_counts": counts,
        "held_out_ood_families": sorted(OOD_FAMILIES),
        "organ_inspired_families": sorted(
            {"organ_lung_lobe", "organ_heart", "organ_kidney", "organ_ovary"}
        ),
        "organ_family_counts": organ_counts,
        "boolean_benchmark_cases": 10,
        "ktc2023_external_cases": 6,
        "act3_style_synthetic_cases": 24,
        "genuine_act3_measurements_included": False,
        "all_manifest_hashes_verified": True,
        "all_float_arrays_finite": True,
        "all_primary_lesions_connected_and_hole_free": True,
    }


if __name__ == "__main__":
    report = audit()
    print(json.dumps(report, indent=2))
