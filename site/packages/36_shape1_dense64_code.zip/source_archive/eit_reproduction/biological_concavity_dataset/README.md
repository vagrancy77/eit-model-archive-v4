# Biological Concavity EIT Dataset

This project generates a unified, auditable dataset for studying concave lesion
reconstruction without mixing training data and external benchmarks.

## Dataset roles

- `synthetic_training.npz`: biologically plausible smooth lesions only. It
  contains both deliberately concave lesions and ordinary outward/convex
  controls. Stars, crosses, letters and sharp polygons are forbidden.
- `benchmark_boolean_paper.npz`: the ten cases from *Shape Reconstruction Using
  Boolean Operations in Electrical Impedance Tomography*. Cases 4-8 are marked
  as analytic approximations of the published photographs because the original
  tank voltages and masks are not public in the local workspace.
- `benchmark_ktc2023_biological_subset.npz`: six untouched public KTC2023
  evaluation cases whose targets are smooth circle, heart/kidney or crescent-like
  shapes. Cases containing stars, crosses, triangles or rectangles are excluded.
  These measurements are never training data.
- `benchmark_act3_style.npz`: smooth circular-tank phantom geometries inspired
  by common ACT3 validation configurations. These are synthetic geometry and
  KTC-physics surrogates, not ACT3 measurements.
- `act3_external/README.md`: explicit import slot for genuine ACT3 files. The
  generator never relabels a surrogate as real ACT3 data.

## Generate

From `E:\Codex\eit_reproduction`:

```powershell
python biological_concavity_dataset\generate_dataset.py --samples 16000
```

The default output is
`datasets\biological_concavity_unified_v2`. Version 2 adds 1,000 cases each of
smooth lung-lobe, heart, kidney and ovary-inspired morphology while preserving
the version-1 family weights. No neural network is trained.

## Split policy

Eight shape families have independent train, validation and in-distribution
test samples. Four additional families are held out entirely for the OOD test
split. Boolean, KTC2023 and ACT3-style data are benchmark-only shards.

## Important scope

Synthetic voltages use the KTC2023 linearized CEM Jacobian at the public
reference conductivity. This first release is intended for geometry review and
controlled baseline experiments. Nonlinear CEM voltages can later replace the
physics shard without changing any lesion masks or split assignments.
