from __future__ import annotations

import unittest

import numpy as np
from scipy.ndimage import binary_fill_holes, label

from generate_dataset import CONCAVE_FAMILIES, FAMILIES, ORGAN_FAMILIES, draw_family, valid_geometry


class GeometryTests(unittest.TestCase):
    def test_every_family_generates_valid_connected_shapes(self) -> None:
        coordinates = np.linspace(-1.0, 1.0, 64, dtype=np.float32)
        x, y = np.meshgrid(coordinates, coordinates)
        fov = x * x + y * y <= 0.97**2
        for code, family in enumerate(FAMILIES):
            rng = np.random.default_rng(1000 + code)
            accepted = 0
            for _ in range(80):
                geometry = draw_family(family, x, y, rng)
                if valid_geometry(geometry, fov, family in CONCAVE_FAMILIES):
                    accepted += 1
                    self.assertEqual(label(geometry.foreground)[1], 1)
                    self.assertLessEqual(int((binary_fill_holes(geometry.foreground) & ~geometry.foreground).sum()), 5)
                    if family in CONCAVE_FAMILIES:
                        self.assertGreater(int(geometry.cutout.sum()), 0)
                    break
            self.assertGreater(accepted, 0, family)

    def test_forbidden_shape_names_are_absent(self) -> None:
        forbidden = {"star", "cross", "letter", "random_polygon"}
        self.assertFalse(any(token in family for family in FAMILIES for token in forbidden))

    def test_organ_families_and_topology_roles_are_explicit(self) -> None:
        self.assertEqual(
            ORGAN_FAMILIES,
            {"organ_lung_lobe", "organ_heart", "organ_kidney", "organ_ovary"},
        )
        self.assertTrue({"organ_lung_lobe", "organ_heart", "organ_kidney"} <= CONCAVE_FAMILIES)
        self.assertNotIn("organ_ovary", CONCAVE_FAMILIES)


if __name__ == "__main__":
    unittest.main()
