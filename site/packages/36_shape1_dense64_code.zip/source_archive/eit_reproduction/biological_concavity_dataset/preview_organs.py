"""Render a fast geometry-only preview of the organ-inspired families."""
from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from generate_dataset import CONCAVE_FAMILIES, ORGAN_FAMILIES, draw_family, valid_geometry


def main() -> None:
    resolution = 64
    coordinates = np.linspace(-1.0, 1.0, resolution, dtype=np.float32)
    x, y = np.meshgrid(coordinates, coordinates)
    fov = x * x + y * y <= 0.97**2
    families = ("organ_lung_lobe", "organ_heart", "organ_kidney", "organ_ovary")
    assert set(families) == ORGAN_FAMILIES
    figure, axes = plt.subplots(len(families), 10, figsize=(18.0, 7.7), squeeze=False)
    for row, family in enumerate(families):
        rng = np.random.default_rng(20260910 + row)
        accepted = []
        while len(accepted) < axes.shape[1]:
            geometry = draw_family(family, x, y, rng)
            if valid_geometry(geometry, fov, family in CONCAVE_FAMILIES):
                accepted.append(geometry)
        for column, geometry in enumerate(accepted):
            axes[row, column].imshow(geometry.foreground, cmap="magma", vmin=0, vmax=1)
            if family in CONCAVE_FAMILIES:
                axes[row, column].contour(
                    geometry.cutout, levels=[0.5], colors=["#31b6c8"], linewidths=0.8
                )
            axes[row, column].set_axis_off()
        axes[row, 0].set_ylabel(
            family.removeprefix("organ_").replace("_", "\n"),
            rotation=0,
            ha="right",
            va="center",
            fontsize=11,
        )
    figure.suptitle("Organ-family geometry preflight (no EIT projection, no training)", fontsize=16)
    figure.tight_layout(rect=(0.06, 0.01, 1, 0.95))
    output = Path(__file__).resolve().parent / "organ_geometry_preflight.png"
    figure.savefig(output, dpi=180)
    plt.close(figure)
    print(output)


if __name__ == "__main__":
    main()
