"""Generate a large biological-style concavity EIT dataset and benchmarks.

The generator deliberately separates four concepts:

1. smooth biological lesion masks that are legal training data;
2. non-biological shapes retained only for paper benchmarking;
3. untouched public KTC2023 measurements used only for external testing;
4. ACT3-style synthetic phantoms, which are never represented as real ACT3.

No neural-network code is imported or executed by this script.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import (
    binary_closing,
    binary_erosion,
    binary_fill_holes,
    binary_opening,
    distance_transform_edt,
    gaussian_filter,
    label as connected_components,
)
from scipy.spatial import ConvexHull, QhullError


ID_FAMILIES = (
    "smooth_oval",
    "asymmetric_nodule",
    "smooth_capsule",
    "gentle_lobulated",
    "organ_ovary",
    "smooth_crescent",
    "deep_u",
    "kidney_hilum",
    "asymmetric_bay",
    "organ_lung_lobe",
    "organ_heart",
    "organ_kidney",
)
OOD_FAMILIES = (
    "fused_nodule",
    "scalloped_crescent",
    "double_bay",
    "keyhole_bay",
)
FAMILIES = ID_FAMILIES + OOD_FAMILIES
FAMILY_TO_CODE = {name: index for index, name in enumerate(FAMILIES)}
ORGAN_FAMILIES = {
    "organ_lung_lobe",
    "organ_heart",
    "organ_kidney",
    "organ_ovary",
}
CONCAVE_FAMILIES = {
    "smooth_crescent",
    "deep_u",
    "kidney_hilum",
    "asymmetric_bay",
    "scalloped_crescent",
    "double_bay",
    "keyhole_bay",
    "organ_lung_lobe",
    "organ_heart",
    "organ_kidney",
}
KTC_BIOLOGICAL_IDS = (
    "level_1/1",
    "level_1/2",
    "level_2/1",
    "level_2/3",
    "level_3/2",
    "level_5/2",
)


@dataclass
class Geometry:
    foreground: np.ndarray
    support: np.ndarray
    cutout: np.ndarray
    mouth_fraction: float
    depth_fraction: float


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--samples", type=int, default=16000)
    parser.add_argument("--resolution", type=int, default=64)
    parser.add_argument("--seed", type=int, default=20260826)
    parser.add_argument(
        "--base-dataset",
        type=Path,
        default=root / "datasets" / "ktc_shape_nonlinear_v1.npz",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=root / "datasets" / "biological_concavity_unified_v2",
    )
    parser.add_argument("--voltage-scale", type=float, default=2.0)
    parser.add_argument("--snr-min-db", type=float, default=24.0)
    parser.add_argument("--snr-max-db", type=float, default=58.0)
    parser.add_argument("--secondary-lesion-probability", type=float, default=0.24)
    return parser.parse_args()


def rotate(x: np.ndarray, y: np.ndarray, angle: float) -> tuple[np.ndarray, np.ndarray]:
    cosine, sine = math.cos(angle), math.sin(angle)
    return cosine * x + sine * y, -sine * x + cosine * y


def local_frame(
    x: np.ndarray,
    y: np.ndarray,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray, float, float, float, float, float]:
    sx = float(rng.uniform(0.20, 0.36))
    sy = float(rng.uniform(0.18, 0.34))
    if rng.uniform() < 0.50:
        sx, sy = max(sx, sy), min(sx, sy)
    limit = max(0.08, 0.73 - max(sx, sy))
    radius = limit * math.sqrt(float(rng.uniform()))
    direction = float(rng.uniform(-math.pi, math.pi))
    cx, cy = radius * math.cos(direction), radius * math.sin(direction)
    angle = float(rng.uniform(-math.pi, math.pi))
    lx, ly = rotate(x - cx, y - cy, angle)
    return lx, ly, sx, sy, cx, cy, angle


def ellipse(lx: np.ndarray, ly: np.ndarray, ax: float, ay: float) -> np.ndarray:
    return (lx / max(ax, 1e-6)) ** 2 + (ly / max(ay, 1e-6)) ** 2 <= 1.0


def superellipse(
    lx: np.ndarray,
    ly: np.ndarray,
    ax: float,
    ay: float,
    exponent: float,
) -> np.ndarray:
    return (np.abs(lx / max(ax, 1e-6)) ** exponent + np.abs(ly / max(ay, 1e-6)) ** exponent) <= 1.0


def largest_component(mask: np.ndarray) -> np.ndarray:
    components, count = connected_components(mask, structure=np.ones((3, 3), dtype=np.uint8))
    if count <= 1:
        return mask.astype(bool)
    sizes = np.bincount(components.ravel())
    sizes[0] = 0
    return components == int(np.argmax(sizes))


def smooth_mask(mask: np.ndarray, sigma: float = 0.62) -> np.ndarray:
    result = gaussian_filter(mask.astype(np.float32), sigma=sigma) >= 0.50
    result = binary_closing(result, iterations=1)
    return largest_component(result)


def convex_hull_mask(mask: np.ndarray) -> np.ndarray:
    rows, columns = np.nonzero(mask)
    if len(rows) < 3:
        return mask.copy()
    points = np.column_stack((columns, rows))
    try:
        hull = ConvexHull(points)
    except QhullError:
        return mask.copy()
    canvas = Image.new("1", (mask.shape[1], mask.shape[0]), 0)
    ImageDraw.Draw(canvas).polygon([tuple(point) for point in points[hull.vertices]], fill=1)
    return np.asarray(canvas, dtype=bool)


def signed_distance(mask: np.ndarray) -> np.ndarray:
    inside = distance_transform_edt(mask)
    outside = distance_transform_edt(~mask)
    return np.clip((inside - outside) / 10.0, -1.0, 1.0).astype(np.float16)


def radial_nodule(
    lx: np.ndarray,
    ly: np.ndarray,
    sx: float,
    sy: float,
    rng: np.random.Generator,
    amplitude: tuple[float, float],
    harmonics: tuple[int, ...],
) -> np.ndarray:
    theta = np.arctan2(ly / sy, lx / sx)
    radius = np.hypot(lx / sx, ly / sy)
    boundary = np.ones_like(radius)
    for harmonic in harmonics:
        phase = float(rng.uniform(-math.pi, math.pi))
        boundary += float(rng.uniform(*amplitude)) * np.cos(harmonic * theta + phase)
    return radius <= boundary


def draw_family(
    family: str,
    x: np.ndarray,
    y: np.ndarray,
    rng: np.random.Generator,
) -> Geometry:
    lx, ly, sx, sy, _, _, _ = local_frame(x, y, rng)
    base = ellipse(lx, ly, sx, sy)
    mouth = 0.0
    depth = 0.0

    if family == "smooth_oval":
        foreground = radial_nodule(lx, ly, sx, sy, rng, (0.012, 0.030), (2,))
        support = foreground.copy()
    elif family == "asymmetric_nodule":
        foreground = radial_nodule(lx, ly, sx, sy, rng, (0.018, 0.050), (2, 3))
        support = foreground.copy()
    elif family == "smooth_capsule":
        horizontal = sx >= sy
        if horizontal:
            radius = sy * float(rng.uniform(0.72, 0.92))
            half = max(sx - radius, 0.04)
            foreground = ((np.abs(lx) <= half) & (np.abs(ly) <= radius)) | (
                (np.abs(lx) - half).clip(0.0) ** 2 + ly**2 <= radius**2
            )
        else:
            radius = sx * float(rng.uniform(0.72, 0.92))
            half = max(sy - radius, 0.04)
            foreground = ((np.abs(ly) <= half) & (np.abs(lx) <= radius)) | (
                (np.abs(ly) - half).clip(0.0) ** 2 + lx**2 <= radius**2
            )
        support = foreground.copy()
    elif family == "gentle_lobulated":
        foreground = radial_nodule(lx, ly, sx, sy, rng, (0.025, 0.060), (2, 3))
        support = foreground.copy()
    elif family == "organ_ovary":
        # Ovarian morphology is normally ovoid or almond-like with a gently
        # lobulated capsule. Internal follicles are not cut out because this
        # target represents the organ/lesion boundary, not histology.
        organ_scale = 0.5 * (sx + sy)
        ox = organ_scale * float(rng.uniform(1.05, 1.22))
        oy = organ_scale * float(rng.uniform(0.68, 0.82))
        foreground = radial_nodule(lx, ly, ox, oy, rng, (0.012, 0.032), (2, 3, 4))
        support = foreground.copy()
    elif family == "fused_nodule":
        offset = sx * float(rng.uniform(0.18, 0.30))
        first = ellipse(lx + offset, ly - sy * 0.05, sx * 0.82, sy * 0.92)
        second = ellipse(lx - offset, ly + sy * 0.05, sx * 0.82, sy * 0.92)
        foreground = binary_closing(first | second, iterations=1)
        support = foreground.copy()
    elif family == "smooth_crescent":
        support = base
        shift_x = sx * float(rng.uniform(0.36, 0.55))
        shift_y = sy * float(rng.uniform(-0.14, 0.14))
        inner = ellipse(
            lx - shift_x,
            ly - shift_y,
            sx * float(rng.uniform(0.64, 0.80)),
            sy * float(rng.uniform(0.68, 0.84)),
        )
        foreground = support & ~inner
        mouth = float(rng.uniform(0.30, 0.55))
        depth = shift_x / sx
    elif family == "deep_u":
        support = superellipse(lx, ly, sx, sy, float(rng.uniform(2.2, 3.0)))
        half_width = sx * float(rng.uniform(0.34, 0.56))
        floor_y = -sy * float(rng.uniform(0.46, 0.72))
        round_y = sy * float(rng.uniform(0.20, 0.34))
        cavity = ((np.abs(lx) <= half_width) & (ly >= floor_y)) | ellipse(
            lx, ly - floor_y, half_width, round_y
        )
        foreground = support & ~cavity
        mouth = half_width / sx
        depth = (sy - floor_y) / (2.0 * sy)
    elif family == "kidney_hilum":
        support = radial_nodule(lx, ly, sx, sy, rng, (0.010, 0.026), (2,))
        notch_x = sx * float(rng.uniform(0.66, 0.86))
        notch_y = sy * float(rng.uniform(-0.22, 0.22))
        notch_ax = sx * float(rng.uniform(0.38, 0.56))
        notch_ay = sy * float(rng.uniform(0.36, 0.62))
        cavity = ellipse(lx - notch_x, ly - notch_y, notch_ax, notch_ay)
        foreground = support & ~cavity
        mouth = notch_ay / sy
        depth = notch_ax / sx
    elif family == "asymmetric_bay":
        support = radial_nodule(lx, ly, sx, sy, rng, (0.012, 0.032), (2, 3))
        notch_x = sx * float(rng.uniform(0.66, 0.90))
        notch_y = sy * float(rng.uniform(-0.42, 0.42))
        notch_ax = sx * float(rng.uniform(0.30, 0.50))
        notch_ay = sy * float(rng.uniform(0.25, 0.50))
        cavity = ellipse(lx - notch_x, ly - notch_y, notch_ax, notch_ay)
        foreground = support & ~cavity
        mouth = notch_ay / sy
        depth = notch_ax / sx
    elif family == "organ_lung_lobe":
        # A single smooth lung lobe with an open medial cardiac notch. A lung
        # pair remains a multi-object benchmark rather than a disconnected
        # primary lesion.
        organ_scale = 0.5 * (sx + sy)
        width = organ_scale * float(rng.uniform(0.62, 0.76))
        height = organ_scale * float(rng.uniform(1.23, 1.42))
        side = -1.0 if rng.uniform() < 0.5 else 1.0
        tx = side * lx
        upper = ellipse(tx + width * 0.08, ly + height * 0.12, width * 0.88, height * 0.84)
        basal = ellipse(tx - width * 0.14, ly - height * 0.44, width * 0.88, height * 0.43)
        support = binary_closing(upper | basal, iterations=1)
        notch_ax = width * float(rng.uniform(0.36, 0.50))
        notch_ay = height * float(rng.uniform(0.20, 0.31))
        notch_x = width * float(rng.uniform(0.72, 0.86))
        notch_y = height * float(rng.uniform(-0.08, 0.20))
        cavity = ellipse(tx - notch_x, ly - notch_y, notch_ax, notch_ay)
        foreground = support & ~cavity
        mouth = notch_ay / height
        depth = notch_ax / width
    elif family == "organ_heart":
        # A continuous implicit cardiac silhouette retains two superior lobes
        # at low resolution. Mild shear introduces anatomical asymmetry, and a
        # small apical cap avoids the sharp point of a symbolic heart icon.
        organ_scale = 0.5 * (sx + sy)
        width = organ_scale * float(rng.uniform(1.02, 1.17))
        height = organ_scale * float(rng.uniform(1.08, 1.24))
        shear = float(rng.uniform(-0.13, 0.13))
        u = (lx + shear * ly) / width
        v = -ly / height
        implicit = (u * u + v * v - 1.0) ** 3 - u * u * v**3
        raw_heart = implicit <= 0.0
        apex = ellipse(
            lx - shear * height * 0.78,
            ly - height * 0.78,
            width * float(rng.uniform(0.14, 0.19)),
            height * float(rng.uniform(0.13, 0.18)),
        )
        raw_heart |= apex
        notch_ax = width * float(rng.uniform(0.19, 0.26))
        notch_ay = height * float(rng.uniform(0.34, 0.44))
        notch_y = -height * float(rng.uniform(0.84, 0.94))
        cavity = ellipse(lx, ly - notch_y, notch_ax, notch_ay)
        # Fill only the superior sulcus to define the latent outer support,
        # then remove the same smooth cavity as the supervised indentation.
        support = smooth_mask(raw_heart | cavity)
        foreground = support & ~cavity
        mouth = notch_ax / width
        depth = notch_ay / height
    elif family == "organ_kidney":
        # Unequal upper/lower poles and a broad medial hilum create a smoother,
        # more anatomical renal outline than a simple ellipse subtraction.
        organ_scale = 0.5 * (sx + sy)
        width = organ_scale * float(rng.uniform(0.68, 0.82))
        height = organ_scale * float(rng.uniform(1.16, 1.34))
        side = -1.0 if rng.uniform() < 0.5 else 1.0
        tx = side * lx
        middle = ellipse(tx + width * 0.10, ly, width * 0.86, height * 0.91)
        upper = ellipse(tx - width * 0.13, ly + height * 0.28, width * 0.80, height * 0.62)
        lower = ellipse(tx - width * 0.08, ly - height * 0.30, width * 0.76, height * 0.58)
        support = binary_closing(middle | upper | lower, iterations=1)
        notch_ax = width * float(rng.uniform(0.40, 0.54))
        notch_ay = height * float(rng.uniform(0.25, 0.38))
        notch_x = width * float(rng.uniform(0.67, 0.82))
        notch_y = height * float(rng.uniform(-0.12, 0.14))
        cavity = ellipse(tx - notch_x, ly - notch_y, notch_ax, notch_ay)
        foreground = support & ~cavity
        mouth = notch_ay / height
        depth = notch_ax / width
    elif family == "scalloped_crescent":
        support = base
        shift_x = sx * float(rng.uniform(0.34, 0.50))
        shift_y = sy * float(rng.uniform(-0.12, 0.12))
        inner_ax = sx * float(rng.uniform(0.68, 0.80))
        inner_ay = sy * float(rng.uniform(0.70, 0.84))
        cavity = ellipse(lx - shift_x, ly - shift_y, inner_ax, inner_ay)
        foreground = support & ~cavity
        # A smooth, connected tissue tongue grows back into the indentation.
        tongue_x = shift_x - inner_ax * float(rng.uniform(0.72, 0.86))
        tongue_y = shift_y + sy * float(rng.uniform(-0.26, 0.26))
        tongue = ellipse(
            lx - tongue_x,
            ly - tongue_y,
            sx * float(rng.uniform(0.15, 0.23)),
            sy * float(rng.uniform(0.13, 0.22)),
        )
        foreground |= tongue & support
        mouth = inner_ay / sy
        depth = inner_ax / sx
    elif family == "double_bay":
        support = radial_nodule(lx, ly, sx, sy, rng, (0.010, 0.025), (2,))
        x0 = sx * float(rng.uniform(0.72, 0.90))
        separation = sy * float(rng.uniform(0.26, 0.44))
        bay1 = ellipse(
            lx - x0,
            ly - separation,
            sx * float(rng.uniform(0.28, 0.44)),
            sy * float(rng.uniform(0.22, 0.38)),
        )
        bay2 = ellipse(
            lx - x0 * float(rng.uniform(0.90, 1.05)),
            ly + separation,
            sx * float(rng.uniform(0.26, 0.42)),
            sy * float(rng.uniform(0.22, 0.38)),
        )
        foreground = support & ~(bay1 | bay2)
        mouth = 0.40
        depth = 0.45
    elif family == "keyhole_bay":
        support = base
        chamber_x = sx * float(rng.uniform(0.06, 0.26))
        chamber_y = sy * float(rng.uniform(-0.18, 0.18))
        chamber_r = min(sx, sy) * float(rng.uniform(0.25, 0.38))
        chamber = (lx - chamber_x) ** 2 + (ly - chamber_y) ** 2 <= chamber_r**2
        neck_half = sy * float(rng.uniform(0.10, 0.17))
        corridor = (lx >= chamber_x) & (lx <= sx * 1.15) & (np.abs(ly - chamber_y) <= neck_half)
        cap = ellipse(lx - chamber_x, ly - chamber_y, chamber_r * 1.05, neck_half * 1.2)
        foreground = support & ~(chamber | corridor | cap)
        mouth = neck_half / sy
        depth = (sx - chamber_x) / (2.0 * sx)
    else:
        raise ValueError(f"unknown family: {family}")

    foreground = smooth_mask(foreground)
    support = smooth_mask(support)
    support |= foreground
    cutout = support & ~foreground
    return Geometry(foreground, support, cutout, mouth, depth)


def valid_geometry(geometry: Geometry, fov: np.ndarray, concave: bool) -> bool:
    foreground = geometry.foreground & fov
    support = geometry.support & fov
    area = int(foreground.sum())
    if area < 45 or area > int(fov.sum() * 0.23):
        return False
    _, components = connected_components(foreground, structure=np.ones((3, 3), dtype=np.uint8))
    if components != 1:
        return False
    holes = binary_fill_holes(foreground) & ~foreground
    if holes.sum() > 5:
        return False
    if distance_transform_edt(foreground).max() < 2.2:
        return False
    border = fov & ~binary_erosion(fov, iterations=2)
    if np.any(foreground & border):
        return False
    cutout = support & ~foreground
    if concave:
        if cutout.sum() < 12:
            return False
        ratio = cutout.sum() / max(support.sum(), 1)
        if not 0.045 <= ratio <= 0.62:
            return False
    return True


def add_secondary_lesion(
    labels: np.ndarray,
    delta: np.ndarray,
    x: np.ndarray,
    y: np.ndarray,
    rng: np.random.Generator,
    probability: float,
) -> int:
    if rng.uniform() >= probability:
        return 0
    for _ in range(12):
        radius = float(rng.uniform(0.075, 0.145))
        direction = float(rng.uniform(-math.pi, math.pi))
        distance = float(rng.uniform(0.35, 0.67))
        cx, cy = distance * math.cos(direction), distance * math.sin(direction)
        sx = radius * float(rng.uniform(0.85, 1.28))
        sy = radius * float(rng.uniform(0.82, 1.22))
        angle = float(rng.uniform(-math.pi, math.pi))
        lx, ly = rotate(x - cx, y - cy, angle)
        lesion = ellipse(lx, ly, sx, sy)
        lesion &= distance_transform_edt(labels == 0) >= 3.0
        if lesion.sum() < 16:
            continue
        lesion_class = 2 if rng.uniform() < 0.68 else 1
        contrast = float(rng.uniform(0.24, 0.82))
        if lesion_class == 1:
            contrast *= -1.0
        labels[lesion] = lesion_class
        delta[lesion] = contrast
        return 1
    return 0


def geometry_metrics(foreground: np.ndarray, support: np.ndarray, cutout: np.ndarray) -> dict[str, float]:
    hull = convex_hull_mask(foreground)
    boundary = foreground & ~binary_erosion(foreground)
    area = float(foreground.sum())
    perimeter = float(boundary.sum())
    return {
        "area_pixels": area,
        "support_pixels": float(support.sum()),
        "cutout_pixels": float(cutout.sum()),
        "solidity": area / max(float(hull.sum()), 1.0),
        "cutout_ratio": float(cutout.sum()) / max(float(support.sum()), 1.0),
        "compactness": 4.0 * math.pi * area / max(perimeter * perimeter, 1.0),
        "maximum_half_thickness": float(distance_transform_edt(foreground).max()),
    }


def allocate_families(samples: int) -> dict[str, int]:
    if samples < 1600:
        raise ValueError("at least 1600 samples are required")
    # At the 16,000-case release size this preserves the v1 family weight
    # (1,250 generic ID and 500 held-out OOD) and adds 1,000 per organ family.
    weights = {
        family: (1.0 if family in ORGAN_FAMILIES else 1.25)
        for family in ID_FAMILIES
    }
    weights.update({family: 0.50 for family in OOD_FAMILIES})
    total_weight = sum(weights.values())
    raw = {family: samples * weight / total_weight for family, weight in weights.items()}
    counts = {family: int(math.floor(value)) for family, value in raw.items()}
    remainder = samples - sum(counts.values())
    order = sorted(FAMILIES, key=lambda family: raw[family] - counts[family], reverse=True)
    for family in order[:remainder]:
        counts[family] += 1
    return counts


def generate_training_geometry(args: argparse.Namespace) -> tuple[dict[str, np.ndarray], list[dict[str, object]]]:
    rng = np.random.default_rng(args.seed)
    coordinates = np.linspace(-1.0, 1.0, args.resolution, dtype=np.float32)
    x, y = np.meshgrid(coordinates, coordinates)
    fov = x * x + y * y <= 0.97**2
    family_counts = allocate_families(args.samples)

    labels = np.zeros((args.samples, args.resolution, args.resolution), dtype=np.uint8)
    primary_masks = np.zeros_like(labels)
    support_masks = np.zeros_like(labels)
    cutout_masks = np.zeros_like(labels)
    indentation_masks = np.zeros_like(labels)
    delta_sigma = np.zeros(labels.shape, dtype=np.float16)
    signed_distances = np.zeros(labels.shape, dtype=np.float16)
    family_codes = np.zeros(args.samples, dtype=np.int16)
    is_concave = np.zeros(args.samples, dtype=np.uint8)
    split_codes = np.zeros(args.samples, dtype=np.uint8)
    snr_db = rng.uniform(args.snr_min_db, args.snr_max_db, size=args.samples).astype(np.float32)
    sample_gain = rng.uniform(0.92, 1.08, size=args.samples).astype(np.float32)
    metadata: list[dict[str, object]] = []

    index = 0
    for family in FAMILIES:
        count = family_counts[family]
        local_order = rng.permutation(count)
        if family in OOD_FAMILIES:
            local_splits = np.full(count, 3, dtype=np.uint8)  # OOD test
        else:
            train_end = int(round(0.70 * count))
            val_end = train_end + int(round(0.15 * count))
            local_splits = np.full(count, 2, dtype=np.uint8)
            local_splits[local_order[:train_end]] = 0
            local_splits[local_order[train_end:val_end]] = 1
        for local_index in range(count):
            concave = family in CONCAVE_FAMILIES
            for attempt in range(120):
                geometry = draw_family(family, x, y, rng)
                geometry = Geometry(
                    geometry.foreground & fov,
                    geometry.support & fov,
                    geometry.cutout & fov,
                    geometry.mouth_fraction,
                    geometry.depth_fraction,
                )
                if valid_geometry(geometry, fov, concave):
                    break
            else:
                raise RuntimeError(f"could not generate valid {family} geometry")

            lesion_class = 2 if rng.uniform() < 0.68 else 1
            contrast = float(rng.uniform(0.24, 0.88))
            if lesion_class == 1:
                contrast *= -1.0
            sample_labels = np.zeros_like(fov, dtype=np.uint8)
            sample_delta = np.zeros_like(x, dtype=np.float32)
            sample_labels[geometry.foreground] = lesion_class
            sample_delta[geometry.foreground] = contrast
            secondary_count = add_secondary_lesion(
                sample_labels,
                sample_delta,
                x,
                y,
                rng,
                args.secondary_lesion_probability,
            )
            # The topology target represents an intentional inward bay, not
            # tiny convex-hull deficits caused by rasterization or lobulation.
            indentation = geometry.cutout if concave else np.zeros_like(geometry.cutout)
            metrics = geometry_metrics(geometry.foreground, geometry.support, geometry.cutout)

            labels[index] = sample_labels
            primary_masks[index] = geometry.foreground
            support_masks[index] = geometry.support
            cutout_masks[index] = geometry.cutout
            indentation_masks[index] = indentation
            delta_sigma[index] = sample_delta.astype(np.float16)
            signed_distances[index] = signed_distance(sample_labels != 0)
            family_codes[index] = FAMILY_TO_CODE[family]
            is_concave[index] = int(concave)
            split_codes[index] = local_splits[local_index]
            metadata.append(
                {
                    "sample_id": f"bio_{index:05d}",
                    "family": family,
                    "family_code": FAMILY_TO_CODE[family],
                    "morphology_group": "organ_inspired" if family in ORGAN_FAMILIES else "generic",
                    "split": ("train", "validation", "test_id", "test_ood")[int(local_splits[local_index])],
                    "is_concave": int(concave),
                    "primary_class": int(lesion_class),
                    "primary_contrast": contrast,
                    "secondary_lesions": secondary_count,
                    "mouth_fraction": geometry.mouth_fraction,
                    "depth_fraction": geometry.depth_fraction,
                    "snr_db": float(snr_db[index]),
                    **metrics,
                }
            )
            index += 1
            if index % 1000 == 0 or index == args.samples:
                print(f"geometry {index}/{args.samples}", flush=True)

    arrays = {
        "labels": labels,
        "primary_masks": primary_masks,
        "support_masks": support_masks,
        "cutout_masks": cutout_masks,
        "indentation_masks": indentation_masks,
        "delta_sigma": delta_sigma,
        "signed_distance": signed_distances,
        "family_codes": family_codes,
        "is_concave": is_concave,
        "split_codes": split_codes,
        "snr_db": snr_db,
        "sample_gain": sample_gain,
        "fov_mask": fov.astype(np.uint8),
    }
    return arrays, metadata


def project_physics(
    arrays: dict[str, np.ndarray],
    base: np.lib.npyio.NpzFile,
    args: argparse.Namespace,
) -> None:
    jacobian = np.asarray(base["jacobian"], dtype=np.float32)
    reconstruction = np.asarray(base["reconstruction_operator"], dtype=np.float32)
    node_to_raw = np.asarray(base["node_to_raw_pixel"], dtype=np.int64)
    raw_to_node = np.asarray(base["raw_pixel_to_node"], dtype=np.int64)
    count = arrays["labels"].shape[0]
    raw_delta = np.flip(arrays["delta_sigma"].astype(np.float32), axis=1).reshape(count, -1)
    node_delta = raw_delta[:, node_to_raw]
    voltages = np.empty((count, jacobian.shape[0]), dtype=np.float32)
    linear_images = np.empty((count, args.resolution, args.resolution), dtype=np.float16)
    rng = np.random.default_rng(args.seed + 991)
    batch_size = 256
    for start in range(0, count, batch_size):
        stop = min(start + batch_size, count)
        clean = args.voltage_scale * (node_delta[start:stop] @ jacobian.T)
        clean *= arrays["sample_gain"][start:stop, None]
        noisy = clean.copy()
        for local, sample_index in enumerate(range(start, stop)):
            rms = float(np.sqrt(np.mean(clean[local] ** 2)))
            noise_rms = rms / (10.0 ** (float(arrays["snr_db"][sample_index]) / 20.0))
            white = rng.normal(0.0, noise_rms + 1e-10, size=clean.shape[1])
            correlated = gaussian_filter(rng.normal(size=clean.shape[1]), sigma=6.0)
            correlated /= max(float(np.std(correlated)), 1e-8)
            noisy[local] += white + 0.18 * noise_rms * correlated
        voltages[start:stop] = noisy
        nodes = noisy @ reconstruction.T
        raw = nodes[:, raw_to_node].reshape(stop - start, args.resolution, args.resolution)
        linear_images[start:stop] = np.flip(raw, axis=1).astype(np.float16)
        print(f"physics {stop}/{count}", flush=True)
    arrays["voltages"] = voltages
    arrays["linear_images"] = linear_images
    arrays["jacobian"] = jacobian
    arrays["reconstruction_operator"] = reconstruction
    arrays["node_to_raw_pixel"] = node_to_raw
    arrays["raw_pixel_to_node"] = raw_to_node
    arrays["node_coordinates"] = np.asarray(base["node_coordinates"], dtype=np.float32)
    arrays["train_indices"] = np.flatnonzero(arrays["split_codes"] == 0)
    arrays["validation_indices"] = np.flatnonzero(arrays["split_codes"] == 1)
    arrays["test_id_indices"] = np.flatnonzero(arrays["split_codes"] == 2)
    arrays["test_ood_indices"] = np.flatnonzero(arrays["split_codes"] == 3)


def primitive_masks(resolution: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    coordinates = np.linspace(-1.0, 1.0, resolution, dtype=np.float32)
    x, y = np.meshgrid(coordinates, coordinates)
    fov = x * x + y * y <= 0.97**2
    return x, y, fov


def paper_boolean_cases(resolution: int) -> tuple[np.ndarray, np.ndarray, np.ndarray, list[str], list[str]]:
    x, y, fov = primitive_masks(resolution)

    def rect(cx: float, cy: float, wx: float, wy: float) -> np.ndarray:
        return (np.abs(x - cx) <= wx / 2.0) & (np.abs(y - cy) <= wy / 2.0)

    def tri(cx: float, cy: float, width: float, height: float) -> np.ndarray:
        yy = y - (cy - height / 2.0)
        half = width * (1.0 - yy / height) / 2.0
        return (yy >= 0.0) & (yy <= height) & (np.abs(x - cx) <= half)

    def lung_pair(with_heart: bool) -> np.ndarray:
        left = ellipse(x + 0.34, y + 0.02, 0.24, 0.57)
        right = ellipse(x - 0.34, y + 0.02, 0.24, 0.57)
        left &= ~ellipse(x + 0.09, y - 0.02, 0.18, 0.25)
        right &= ~ellipse(x - 0.09, y - 0.02, 0.18, 0.25)
        result = left | right
        if with_heart:
            result |= ellipse(x, y - 0.38, 0.17, 0.20)
        return result

    l_shape = rect(-0.05, 0.02, 0.26, 0.76) | rect(0.10, -0.23, 0.56, 0.26)
    t_shape = rect(0.15, 0.25, 0.72, 0.26) | rect(0.15, -0.02, 0.26, 0.78)
    left_l = (rect(-0.47, 0.02, 0.23, 0.70) | rect(-0.34, -0.22, 0.48, 0.24))
    right_t = (rect(0.43, 0.24, 0.58, 0.23) | rect(0.43, -0.02, 0.22, 0.75))
    i_shape = rect(-0.45, 0.02, 0.24, 0.74)
    outer = ellipse(x, y, 0.52, 0.68)
    crescent = outer & ~ellipse(x - 0.20, y - 0.04, 0.47, 0.58)

    masks = [
        l_shape,
        t_shape,
        left_l | right_t,
        tri(0.0, 0.05, 0.55, 0.62),
        ellipse(x + 0.38, y + 0.02, 0.18, 0.20) | tri(0.30, 0.04, 0.48, 0.50),
        tri(0.05, 0.34, 0.44, 0.42) | rect(-0.34, -0.22, 0.34, 0.30) | ellipse(x - 0.35, y + 0.31, 0.17, 0.18),
        lung_pair(False),
        lung_pair(True),
        i_shape | right_t,
        crescent,
    ]
    ids = [f"boolean_case_{case}" for case in range(1, 11)]
    provenance = [
        "paper_exact_analytic" if case in {1, 2, 3, 9, 10} else "paper_figure_analytic_approximation"
        for case in range(1, 11)
    ]
    labels = np.stack([(mask & fov).astype(np.uint8) for mask in masks])
    delta = np.where(labels != 0, -0.75, 0.0).astype(np.float32)
    # Case 9 has two inclusion phases.
    labels[8, i_shape & fov] = 2
    delta[8, i_shape & fov] = -0.50
    support = np.stack([convex_hull_mask(mask.astype(bool)) & fov for mask in labels != 0])
    return labels, delta, support.astype(np.uint8), ids, provenance


def act3_style_cases(resolution: int, seed: int = 20260827) -> tuple[np.ndarray, np.ndarray, list[str]]:
    """Return clearly labelled synthetic ACT3-style tank phantoms.

    These configurations support protocol-development while genuine ACT3 files
    are absent. They must never be reported as measured ACT3 data.
    """

    x, y, fov = primitive_masks(resolution)
    rng = np.random.default_rng(seed)
    labels = []
    ids = []
    for index in range(24):
        family = index % 4
        mask = np.zeros_like(fov)
        if family == 0:
            cx, cy = rng.uniform(-0.45, 0.45, size=2)
            radius = float(rng.uniform(0.12, 0.23))
            mask = ellipse(x - cx, y - cy, radius, radius * float(rng.uniform(0.88, 1.12)))
            token = "single_smooth_inclusion"
        elif family == 1:
            angle = float(rng.uniform(-math.pi, math.pi))
            distance = float(rng.uniform(0.24, 0.42))
            cx, cy = distance * math.cos(angle), distance * math.sin(angle)
            mask = ellipse(x - cx, y - cy, 0.16, 0.21) | ellipse(x + cx, y + cy, 0.14, 0.18)
            token = "two_smooth_inclusions"
        elif family == 2:
            left = ellipse(x + 0.32, y + 0.02, 0.23, 0.52)
            right = ellipse(x - 0.32, y + 0.02, 0.23, 0.52)
            mask = (left & ~ellipse(x + 0.08, y - 0.01, 0.17, 0.23)) | (
                right & ~ellipse(x - 0.08, y - 0.01, 0.17, 0.23)
            )
            token = "thorax_lung_pair"
        else:
            outer = ellipse(x, y, 0.47, 0.61)
            mask = outer & ~ellipse(x - 0.19, y, 0.42, 0.51)
            token = "concave_crescent"
        labels.append((mask & fov).astype(np.uint8))
        ids.append(f"act3_style_{token}_{index:02d}")
    label_array = np.stack(labels)
    delta = np.where(label_array != 0, -0.75, 0.0).astype(np.float32)
    return label_array, delta, ids


def project_benchmark(
    delta: np.ndarray,
    base: np.lib.npyio.NpzFile,
    voltage_scale: float,
) -> tuple[np.ndarray, np.ndarray]:
    jacobian = np.asarray(base["jacobian"], dtype=np.float32)
    reconstruction = np.asarray(base["reconstruction_operator"], dtype=np.float32)
    node_to_raw = np.asarray(base["node_to_raw_pixel"], dtype=np.int64)
    raw_to_node = np.asarray(base["raw_pixel_to_node"], dtype=np.int64)
    raw_delta = np.flip(delta, axis=1).reshape(len(delta), -1)
    node_delta = raw_delta[:, node_to_raw]
    voltage = voltage_scale * (node_delta @ jacobian.T)
    nodes = voltage @ reconstruction.T
    raw = nodes[:, raw_to_node].reshape(len(delta), delta.shape[1], delta.shape[2])
    return voltage.astype(np.float32), np.flip(raw, axis=1).astype(np.float32)


def save_metadata(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def select_examples(arrays: dict[str, np.ndarray], per_family: int = 3) -> list[int]:
    selected = []
    for code in range(len(FAMILIES)):
        candidates = np.flatnonzero(arrays["family_codes"] == code)
        if len(candidates) == 0:
            continue
        positions = np.linspace(0, len(candidates) - 1, per_family, dtype=int)
        selected.extend(candidates[positions].tolist())
    return selected


def save_family_catalog(path: Path, arrays: dict[str, np.ndarray]) -> None:
    indices = select_examples(arrays, per_family=3)
    figure, axes = plt.subplots(len(FAMILIES), 6, figsize=(12.8, 2.05 * len(FAMILIES)), squeeze=False)
    for row, family in enumerate(FAMILIES):
        family_indices = [index for index in indices if arrays["family_codes"][index] == row]
        index = family_indices[1]
        scale = max(float(np.percentile(np.abs(arrays["linear_images"][index]), 99)), 1e-5)
        panels = (
            (arrays["labels"][index], "lesion truth", "viridis", None, None),
            (arrays["support_masks"][index], "outer support", "gray", 0, 1),
            (arrays["cutout_masks"][index], "true indentation", "magma", 0, 1),
            (arrays["indentation_masks"][index], "topology target", "magma", 0, 1),
            (arrays["delta_sigma"][index], "conductivity change", "coolwarm", -0.9, 0.9),
            (arrays["linear_images"][index], "linear EIT image", "coolwarm", -scale, scale),
        )
        for column, (image, title, cmap, vmin, vmax) in enumerate(panels):
            axes[row, column].imshow(image, cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest")
            axes[row, column].set_axis_off()
            axes[row, column].set_title(title if row == 0 else "", fontsize=9)
        axes[row, 0].set_ylabel(family.replace("_", "\n"), fontsize=9, rotation=0, ha="right", va="center")
    figure.suptitle("Biological concavity EIT dataset: one audited example per family", fontsize=15)
    figure.tight_layout(rect=(0.07, 0.01, 1, 0.985))
    figure.savefig(path, dpi=190)
    plt.close(figure)


def save_variants(path: Path, arrays: dict[str, np.ndarray], concave: bool) -> None:
    families = [family for family in FAMILIES if (family in CONCAVE_FAMILIES) == concave]
    columns = 6
    figure, axes = plt.subplots(len(families), columns, figsize=(12.0, 2.05 * len(families)), squeeze=False)
    for row, family in enumerate(families):
        code = FAMILY_TO_CODE[family]
        candidates = np.flatnonzero(arrays["family_codes"] == code)
        choices = candidates[np.linspace(0, len(candidates) - 1, columns, dtype=int)]
        for column, index in enumerate(choices):
            axes[row, column].imshow(arrays["primary_masks"][index], cmap="magma", vmin=0, vmax=1)
            axes[row, column].contour(arrays["cutout_masks"][index], levels=[0.5], colors=["#31b6c8"], linewidths=0.75)
            axes[row, column].set_axis_off()
        axes[row, 0].set_ylabel(family.replace("_", "\n"), fontsize=9, rotation=0, ha="right", va="center")
    title = "Complex smooth concavity variants" if concave else "Ordinary outward-boundary controls"
    figure.suptitle(title + " (cyan: explicit inward background)", fontsize=15)
    figure.tight_layout(rect=(0.07, 0.01, 1, 0.98))
    figure.savefig(path, dpi=200)
    plt.close(figure)


def save_organ_catalog(path: Path, arrays: dict[str, np.ndarray]) -> None:
    families = [family for family in FAMILIES if family in ORGAN_FAMILIES]
    columns = 8
    figure, axes = plt.subplots(len(families), columns, figsize=(16.0, 2.35 * len(families)), squeeze=False)
    for row, family in enumerate(families):
        code = FAMILY_TO_CODE[family]
        candidates = np.flatnonzero(arrays["family_codes"] == code)
        choices = candidates[np.linspace(0, len(candidates) - 1, columns, dtype=int)]
        for column, index in enumerate(choices):
            axes[row, column].imshow(arrays["primary_masks"][index], cmap="magma", vmin=0, vmax=1)
            if family in CONCAVE_FAMILIES:
                axes[row, column].contour(
                    arrays["cutout_masks"][index], levels=[0.5], colors=["#31b6c8"], linewidths=0.75
                )
            axes[row, column].set_axis_off()
        axes[row, 0].text(
            0.03,
            0.04,
            family.removeprefix("organ_").replace("_", " "),
            transform=axes[row, 0].transAxes,
            color="white",
            fontsize=10,
            ha="left",
            va="bottom",
            bbox={"facecolor": "black", "alpha": 0.72, "edgecolor": "none", "pad": 2.0},
        )
    figure.suptitle("Organ-inspired smooth lesion families (cyan: explicit anatomical concavity)", fontsize=15)
    figure.tight_layout(rect=(0.07, 0.01, 1, 0.965))
    figure.savefig(path, dpi=200)
    plt.close(figure)


def save_benchmarks(
    path: Path,
    boolean: dict[str, np.ndarray],
    act3: dict[str, np.ndarray],
    base: np.lib.npyio.NpzFile,
) -> None:
    all_ktc_ids = [str(value) for value in base["real_ids"]]
    ktc_indices = np.asarray([all_ktc_ids.index(case_id) for case_id in KTC_BIOLOGICAL_IDS])
    ktc_labels = np.asarray(base["real_labels"], dtype=np.uint8)[ktc_indices]
    ktc_small = np.stack(
        [np.asarray(Image.fromarray(image).resize((64, 64), Image.Resampling.NEAREST)) for image in ktc_labels]
    )
    figure, axes = plt.subplots(3, 10, figsize=(16.0, 5.4), squeeze=False)
    for column in range(10):
        axes[0, column].imshow(boolean["labels"][column], cmap="viridis", vmin=0, vmax=2)
        axes[0, column].set_title(f"Boolean {column + 1}", fontsize=8)
        if column < len(KTC_BIOLOGICAL_IDS):
            axes[1, column].imshow(ktc_small[column], cmap="viridis", vmin=0, vmax=2)
            axes[1, column].set_title(KTC_BIOLOGICAL_IDS[column], fontsize=8)
        else:
            axes[1, column].set_visible(False)
        axes[2, column].imshow(act3["labels"][column], cmap="viridis", vmin=0, vmax=1)
        axes[2, column].set_title(f"ACT3-style {column + 1}", fontsize=8)
        for row in range(3):
            axes[row, column].set_axis_off()
    axes[0, 0].set_ylabel("Boolean paper\nbenchmark", rotation=0, ha="right", va="center")
    axes[1, 0].set_ylabel("KTC2023 real\nexternal test", rotation=0, ha="right", va="center")
    axes[2, 0].set_ylabel("ACT3-style synthetic\nnot measured ACT3", rotation=0, ha="right", va="center")
    figure.suptitle("Benchmark shards are isolated from biological training data", fontsize=15)
    figure.tight_layout(rect=(0.09, 0.01, 1, 0.96))
    figure.savefig(path, dpi=190)
    plt.close(figure)


def save_statistics(path: Path, rows: list[dict[str, object]]) -> None:
    by_family: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in rows:
        by_family[str(row["family"])].append(row)
    counts = [len(by_family[family]) for family in FAMILIES]
    solidity = [np.mean([float(row["solidity"]) for row in by_family[family]]) for family in FAMILIES]
    cutout = [np.mean([float(row["cutout_ratio"]) for row in by_family[family]]) for family in FAMILIES]
    figure, axes = plt.subplots(1, 3, figsize=(14.0, 4.2))
    colors = ["#2a9d8f" if family in CONCAVE_FAMILIES else "#457b9d" for family in FAMILIES]
    axes[0].barh(FAMILIES, counts, color=colors)
    axes[0].set_title("Sample count")
    axes[1].barh(FAMILIES, solidity, color=colors)
    axes[1].set_xlim(0.45, 1.02)
    axes[1].set_title("Mean solidity")
    axes[2].barh(FAMILIES, cutout, color=colors)
    axes[2].set_xlim(0.0, max(cutout) * 1.12)
    axes[2].set_title("Mean explicit cutout ratio")
    for axis in axes:
        axis.grid(axis="x", alpha=0.25)
        axis.tick_params(labelsize=8)
    figure.suptitle("Dataset balance and concavity audit")
    figure.tight_layout()
    figure.savefig(path, dpi=190)
    plt.close(figure)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_act3_slot(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    text = """# Genuine ACT3 external data slot

No genuine ACT3 measurement file was present in the workspace when this
dataset was built. Network retrieval was blocked by the local certificate
chain, so no unverified download was used.

`benchmark_act3_style.npz` is explicitly synthetic and must not be cited as
ACT3 experimental evidence. Put verified ACT3 files and their license/source
record here before enabling an ACT3 real-data experiment. A future importer
must preserve the native electrode protocol instead of silently reshaping raw
voltages to the KTC2023 protocol.
"""
    (path / "README.md").write_text(text, encoding="utf-8")


def main() -> None:
    args = parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    (output / "previews").mkdir(exist_ok=True)
    base_path = args.base_dataset.resolve()
    print("generating biologically constrained lesion geometry", flush=True)
    arrays, metadata = generate_training_geometry(args)
    with np.load(base_path, allow_pickle=False) as base:
        print("projecting KTC linearized CEM measurements", flush=True)
        project_physics(arrays, base, args)
        training_path = output / "synthetic_training.npz"
        np.savez_compressed(training_path, **arrays)
        save_metadata(output / "synthetic_metadata.csv", metadata)

        boolean_labels, boolean_delta, boolean_support, boolean_ids, provenance = paper_boolean_cases(args.resolution)
        boolean_voltage, boolean_linear = project_benchmark(boolean_delta, base, args.voltage_scale)
        boolean = {
            "labels": boolean_labels,
            "delta_sigma": boolean_delta,
            "support_masks": boolean_support,
            "voltages": boolean_voltage,
            "linear_images": boolean_linear,
            "case_ids": np.asarray(boolean_ids),
            "provenance": np.asarray(provenance),
            "role": np.asarray(["benchmark_only"] * len(boolean_ids)),
        }
        boolean_path = output / "benchmark_boolean_paper.npz"
        np.savez_compressed(boolean_path, **boolean)

        act3_labels, act3_delta, act3_ids = act3_style_cases(args.resolution)
        act3_voltage, act3_linear = project_benchmark(act3_delta, base, args.voltage_scale)
        act3 = {
            "labels": act3_labels,
            "delta_sigma": act3_delta,
            "voltages": act3_voltage,
            "linear_images": act3_linear,
            "case_ids": np.asarray(act3_ids),
            "source_type": np.asarray(["synthetic_act3_style_not_measurement"] * len(act3_ids)),
            "role": np.asarray(["benchmark_only"] * len(act3_ids)),
        }
        act3_path = output / "benchmark_act3_style.npz"
        np.savez_compressed(act3_path, **act3)

        all_ktc_ids = [str(value) for value in base["real_ids"]]
        ktc_indices = np.asarray([all_ktc_ids.index(case_id) for case_id in KTC_BIOLOGICAL_IDS])
        ktc_path = output / "benchmark_ktc2023_biological_subset.npz"
        np.savez_compressed(
            ktc_path,
            voltages=np.asarray(base["real_voltages"], dtype=np.float32)[ktc_indices],
            linear_images=np.asarray(base["real_linear_images"], dtype=np.float32)[ktc_indices],
            labels=np.asarray(base["real_labels"], dtype=np.uint8)[ktc_indices],
            case_ids=np.asarray(KTC_BIOLOGICAL_IDS),
            excluded_shape_policy=np.asarray(["no_star_cross_letter_triangle_rectangle"]),
            role=np.asarray(["external_test_only"] * len(ktc_indices)),
        )

        save_family_catalog(output / "previews" / "family_catalog.png", arrays)
        save_variants(output / "previews" / "concave_variants.png", arrays, concave=True)
        save_variants(output / "previews" / "ordinary_controls.png", arrays, concave=False)
        save_organ_catalog(output / "previews" / "organ_families.png", arrays)
        save_benchmarks(output / "previews" / "benchmark_catalog.png", boolean, act3, base)
        save_statistics(output / "previews" / "dataset_statistics.png", metadata)

    write_act3_slot(output / "act3_external")
    split_counts = Counter(row["split"] for row in metadata)
    family_counts = Counter(row["family"] for row in metadata)
    concave_count = sum(int(row["is_concave"]) for row in metadata)
    summary = {
        "name": output.name,
        "created": "2026-08-26",
        "synthetic_samples": args.samples,
        "resolution": args.resolution,
        "family_counts": dict(family_counts),
        "split_counts": dict(split_counts),
        "concave_samples": concave_count,
        "ordinary_samples": args.samples - concave_count,
        "concave_fraction": concave_count / args.samples,
        "id_families": list(ID_FAMILIES),
        "held_out_ood_families": list(OOD_FAMILIES),
        "organ_inspired_families": list(sorted(ORGAN_FAMILIES)),
        "forbidden_training_shapes": ["star", "cross", "letters", "sharp_random_polygon"],
        "boolean_benchmark_cases": 10,
        "ktc2023_real_external_cases": len(KTC_BIOLOGICAL_IDS),
        "ktc2023_biological_case_ids": list(KTC_BIOLOGICAL_IDS),
        "ktc2023_nonbiological_cases_excluded": True,
        "act3_style_synthetic_cases": 24,
        "genuine_act3_measurements_included": False,
        "act3_status": "import slot created; genuine files unavailable and surrogates explicitly labelled",
        "forward_model": "KTC2023 linearized complete-electrode-model Jacobian at public reference",
        "voltage_scale": args.voltage_scale,
        "snr_db_range": [args.snr_min_db, args.snr_max_db],
        "training_leakage": {
            "boolean_used_for_training": False,
            "ktc2023_real_used_for_training": False,
            "act3_style_used_for_training": False,
        },
        "seed": args.seed,
    }
    files = [
        output / "synthetic_training.npz",
        output / "synthetic_metadata.csv",
        output / "benchmark_boolean_paper.npz",
        output / "benchmark_ktc2023_biological_subset.npz",
        output / "benchmark_act3_style.npz",
    ]
    summary["files"] = {
        path.name: {"bytes": path.stat().st_size, "sha256": sha256(path)} for path in files
    }
    (output / "manifest.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
