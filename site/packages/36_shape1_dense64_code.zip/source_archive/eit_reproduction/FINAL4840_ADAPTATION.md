# 最终 4,840 例数据集：v4 完整工程适配说明

更新：2026-10-16。原则：**不修改数据集，让模型适配数据；保留历史源码、权重及结果；所有新主线训练采用最终数据。**

## 本轮正式运行已完成

- GPU 正式训练 50 轮，seed=20261016，train 3400 / val 720；按验证总损失选中第 48 轮，未按测试成绩挑选。
- 当前正式权重：`outputs/final4840_formal_calibrated_seed20261016/best.pt`，SHA-256 `b3b7d52eec6fc161eebbc34e0b0db732fcab2d6b8c662399b6ac367d8d4781ce`。
- minimal/full 分别完成 train 3400、val 720、test 720 全病例推理，两包的电导率、介电常数、分割概率、SDF 和硬类别逐元素一致。
- [完整正式报告](outputs/final4840_minimal_full_comparison/RESULTS.md)；[汇总 JSON](outputs/final4840_minimal_full_comparison/comparison_summary.json)。720 例测试病灶 IoU=0.886133、Dice=0.938670、mean IoU=0.938445，电导率 SSIM（10/50 kHz）=0.935680/0.935847。
- 当前启用复数实虚部与背景校准、已有拓扑辅助监督与风险门控；物理算子辅助关闭。本轮没有幅值对照重训，不能量化相位收益。最终硬分割 IoU 与同网络基础分支在 720 例上相同，不能据此声称门控有独立收益。
- 图像包括固定病例、低分病例、双频材料图及相位输入图。病灶区域电导率 NRMSE（10/50 kHz）=0.347939/0.287589，不能只看全域 SSIM 判断定量电导率已准确。
- full 首次评估因会话中断留下 2288 个训练预测，原样保留在 `outputs/final4840_minimal_full_comparison/full/train_interrupted_20261016`；不纳入统计。正式 `full/train` 已重新完整运行。

重跑同一冻结评估可用：

```powershell
& E:\conda-envs\pytorch-gpu\python.exe -B -m comsol_v4.evaluate_both --run-dir outputs/final4840_formal_calibrated_seed20261016 --full-root E:/Codex/eit_dataset_final_v6_4840/extracted/full4840 --output-dir outputs/final4840_minimal_full_comparison --equivalence-report outputs/final4840_minimal_full_comparison/layout_equivalence.json --batch-size 16
```

以上命令校验并复用已完成预测，重新生成报告。以下接口验收及历史兼容性说明继续保留；旧模型/旧数据结果不冒充本轮成绩。

## 1. 当前应使用哪个工程、数据和入口

| 项目 | 完整位置 | 状态 |
| --- | --- | --- |
| 主工程 | `E:\Codex\eit_reproduction` | 当前维护的 v4 主线 |
| 最终原始交付 | `E:\Codex\数据集v6_新.zip` | 原文件不变 |
| 实际训练数据 | `E:\Codex\eit_dataset_final_v6_4840\extracted\V6_4840_Minimal` | 原 ZIP 内作者提供的 minimal 包，原样解压；不是自行裁剪或改写的数据集 |
| 最终 minimal 内包 | `E:\Codex\eit_dataset_final_v6_4840\archives\EIT_V6_4840_minimal.7z` | SHA-256 `b2f017274ad68dee5bc7e6af4d2555716ecc2a06afbebacb64d89a03e7c386c9` |
| 全部导入模型文件 | `E:\Codex\eit_reproduction\integrations\v4_20261015\upstream` | 原模型 ZIP 的 45 个清单文件＋清单，共 46 个文件，1,390,433,275 字节 |
| 统一入口 | `E:\Codex\eit_reproduction\v4_unified.py` | 数据核对、归档核对、主线训练/推理、受控比较、统计 |
| 原生模型 | `E:\Codex\eit_reproduction\comsol_v4` | 复数校准与可选物理辅助可在同一主线训练 |
| 受控消融训练 | `E:\Codex\eit_complex_information_study_20261013` | 保留，已适配最终数据及 E 类 |

后续正式运行已把 full 内包完整展开至 `E:\Codex\eit_dataset_final_v6_4840\extracted\full4840`（约 50.51 GB，184436 个文件），内包 SHA-256 与解压 CRC 通过。全 4,840 对病例的模型实际输入及监督标签逐元素一致，报告见 `outputs/final4840_minimal_full_comparison/layout_equivalence.json`。minimal 的 4,870 个清单文件及 full 中 24,248 个训练相关清单文件完成逐文件校验；**不表示单独审核过 full 全部 MPH/内部场文件的建模质量**。minimal 已包含复边界电压、复背景电压、sigma/eps_r 及全部监督标签，训练不需要内部电势场。两包是同一批病例的两种交付布局，不是两个独立测试集。

| 形状分组 | 训练 | 验证 | 测试 | 总计 |
| --- | ---: | ---: | ---: | ---: |
| A | 680 | 144 | 144 | 968 |
| B | 680 | 144 | 144 | 968 |
| C | 680 | 144 | 144 | 968 |
| D | 680 | 144 | 144 | 968 |
| E：凹陷内带凸起 | 680 | 144 | 144 | 968 |
| 合计 | 3400 | 720 | 720 | 4840 |

保持原始 position_id 分组划分，不重新拆分。A–E 是几何分组，**不是把输出分割改成五类**：electrical_class 仍是背景/低导/高导三个类别。

## 2. “完整”不是把不同权重强行拼成一个网络

| 内容 | 导入训练包 | 本机主线 | 本次处理 |
| --- | --- | --- | --- |
| 网络 | 约 2,045 万参数，线性初像＋电压双编码器 | 22,376,674 参数，学习式映射＋电压编码器、残差注意力/拓扑双解码器 | 两者并列保留，不能互换检查点 |
| 原始/长训权重 | 原始 best/last、long-patience best/last | 既有复数校准研究权重 | 全部保留；明确为旧 3,872 例版本，不称最终数据训练结果 |
| 电压输入 | 线性物理初像及复电压表 | 12 通道复电压表示 | 新主线默认增加背景复数校准；保留 native、amplitude、complex、amplitude_calibrated 对照 |
| 物理算子 | 原始 A/G、归一化、参考与有限差分报告 | 可选复杂 Jacobian 接口 | 转换并绑定最终数据版本，检查全部 3,400 个训练病例的背景与协议 |
| 形状与风险 | 切除/边界预测、门控 | SDF、侧壁、切除区域、局部及病例风险门控、普通病例保护损失 | 保留已有修正；不把数据中的 mouth 侧壁带错当开口 |
| 训练入口 | 历史脚本部分依赖外部工程/未包含的旧缓存 | 主线与受控比较入口完整 | 最终数据请走下方新入口，不直接运行归档中的旧路径脚本 |

`upstream` 的源码、配置、归一化、算子、权重、日志、测试均未覆盖修改。旧架构的单病例推理继续可用；本次并没有声称原 ZIP 内所有历史训练脚本脱离原外部工程就能直接长训。当前正式开发/训练入口是已经验收的 `train-native` 与 `train-calibrated`。

## 3. 具体适配了什么

- `comsol_v4/data_v6.py`：识别原 minimal/full 字段，固定最终数据签名；A–E 平衡抽样；归一化只拟合完整 train 3400；拒绝旧 3872 版本。保持 `[频率,驱动,电极]=[2,32,32]`、`[频率,y,x]=[2,64,64]`，10/50 kHz 原顺序。
- `comsol_v4/features.py`：将已验证的复数校准实现整合进主线。相邻测量差 `qV=V_l-V_(l+1)`，排除触及激励/返回电极的测量对，每频率有效 928 对。保留 Re/Im(qV)、Re/Im(qB)，把冗余差分四通道换成 `r=(qV-qB)conj(qB)/(|qB|²+tau²)`；`tau=0.01*RMS(qB)`。合计仍为 12 通道，不丢相位。
- 幅值对照用 `|qV|-|qB|`，**不是**含有相位差的 `|qV-qB|`。同一条校准复输入与旧研究脚本在五类病例上逐元素一致。
- `model.py` 保留已完成修正：残差注意力骨干、U-Net 式双解码器、学习式电压到图像映射、SDF/切除/侧壁辅助头、双重风险门控；双频正值 sigma/eps_r 输出。`mouth_mask` 是凹陷侧壁带，SDF 是内部负值、距离/64，不改标签迎合网络。当前模型已有这些修正，本次没有重写成另一种网络。
- 数据中的 `conductivity_S_per_m` 是实电导率，`eps_r` 是相对介电常数。复导纳率可由 `gamma=sigma+j*2*pi*f*eps0*eps_r` 得到，**不能把 eps_r 数值直接当作电导率虚部**。复电压实/虚部都保留。
- `train.py`：默认 calibrated；最终数据和归一化校验；续训检查数据/输入表示/统计量/模型配置；物理文件版本校验；输出目录保护。smoke 权重不能直接作为正式训练 resume。
- `infer.py`、`verify.py`：校准表示跟随检查点自动重建，支持有/无物理分支的无标签推理、重载与梯度检查；评估验证数据清单，拒绝旧数据检查点冒充最终版本。
- `metrics.py`：普通 A、全部内凹 BCDE、旧 BCD、E 单独报告；保留 IoU/Dice、材料误差、SSIM，SSIM 不是 KTC 定义。
- 受控研究的 `run_experiment.py / evaluate_experiment.py / analyze_experiment.py / plot_experiment.py`：切换最终数据、补上 E 类图与统计、移除硬编码 576/2720/四类；保持按种子与位置配对 bootstrap；防止评估目录混入旧数据/旧检查点/旧扰动结果；修正校准幅值位于主实验时的读取路径。
- `v4_unified.py` 与 `integrations/.../bridge.py`：统一入口，原始/长训/旧校准三个检查点保留，输出标注历史来源。源码修改与原 ZIP 完整性分别报告，不再将授权适配误判为归档损坏。

病灶掩膜、SDF、sigma/eps_r 真值只用于监督和评价，不输入 forward；内部电势不作为测量。物理分支使用已知背景材料类别这一实验元数据，不使用病灶真值选择背景。

## 4. 物理分支的实际边界

文件：`integrations/v4_20261015/derived/reference_physics_final4840.npz`。

该文件恢复自导入包真实 A 矩阵，包含复 Jacobian、两背景材料、频率、网格及最终数据签名；不是从测试标签拟合得到。原始有限差分验证来自归档报告，本次新增的是转换算术检查和全部训练病例背景/协议相容性检查，**没有对新 E 病例重新计算 FEM 导数**。

固定参考与逐病例背景存在网格相关差异：E/Fat 平均相对 L2 为 0.213%，最大 0.357%；E/Muscle 平均 0.220%，最大 0.417%；全训练集最大约 0.706%。转换器的 1% 阈值只是拒绝明显协议不一致的兼容性保护，不能解释成“重建误差小于 1%”。

因此默认主线关闭物理分支，允许显式启用并单独做消融。它是**均匀背景一阶线性化辅助**，不是精确逐病例非线性 CEM，也不保证添加后更好。当前数据有效边界是电流端子；接触阻抗节点未实际改变电压，不能宣称为有限接触阻抗 CEM。数据也没有真实超声配对，`bioheat=false`；保留的材料参数不代表有实际生物热训练场。

## 5. 接口适配阶段的验收结果（历史记录）

- `outputs/final4840_audit/audit.json`：4,870 个训练包清单文件 SHA-256/大小检查；4,840 例所有输入及标签检查；原始划分不变；train-only 归一化；有效域材料范围与 SDF/侧壁语义检查，PASS。
- `outputs/final4840_acceptance/regression.json`：归档完整性、20 组输入实现精确相等、参考电势平移不变性、相位敏感/幅值不敏感、错误归一化拒绝、E 分组、复数算子算术与材料梯度，PASS。算子实块与复数实现比较包含浮点背景相减，误差约 `5.8e-6`；这不是重建误差。
- `calibrated_smoke` 与 `calibrated_physics_smoke`：各在 GPU 上训练 1 轮、6 个 batch × 5 例，共 30 例；验证 10 例 A–E；base=28，全尺寸网络，实际反向传播、梯度裁剪和保存。
- `verify_calibrated.json`、`verify_calibrated_physics.json`：同 batch 重载预测完全一致；仅电压推理与有标签文件推理一致；加入伪造/损坏的真值字段不改变输入；错误频率/尺寸/物理配置拒绝，PASS。不同 batch size 的 GPU 浮点舍入差另有记录，不承诺跨设备字节级相同。
- `inference_val_smoke`：统一入口成功导出 10 例验证预测及指标，包含 E。**这些只是接口测试，不用于证明算法性能。**
- `historical_E_compatibility`：导入原始/长训/本机旧校准三个模型都可读取 `E_000001` 输出有限值；这些模型仍是旧数据训练的，不是新数据重训结果，也不是性能对照证据。
- `previews/final_dataset_AE.png` 与 `final_dataset_E_subtypes.png`：来自原始训练数据的真值/测量预览，不是重建结果。

以上是正式训练之前的接口验收，不是重建性能证据。后续已按用户选择完成最终 train 3400 / val 720 的 50 轮正式训练，并完成同一冻结权重的 minimal/full 独立读取评估；正式报告见本文件顶部。旧 3872 例 IoU/SSIM 不会改名为最终数据结果。

## 6. 当前运行命令

本机 PowerShell；Python 已有 GPU PyTorch，SciPy 位于用户站点，**不要加 `-s`**。所有输出目录必须新建，避免覆盖既有结果。

```powershell
Set-Location E:\Codex\eit_reproduction
$py = 'E:\conda-envs\pytorch-gpu\python.exe'
& $py -B v4_unified.py dataset-info
& $py -B v4_unified.py verify

# 正式主线训练命令示例：默认最终数据、默认复数校准；实际本轮为 seed=20261016、batch=16。
& $py -B v4_unified.py train-native -- --output-dir outputs/final4840_formal_calibrated --epochs 50 --batch-size 8 --device cuda

# 可选物理组：参数仅为示例，不代表已证明有效的最优配置。
& $py -B v4_unified.py train-native -- --output-dir outputs/final4840_formal_physics --epochs 50 --batch-size 8 --device cuda --physics-operator integrations/v4_20261015/derived/reference_physics_final4840.npz --physics-weight 0.01

# 四种输入的同结构、同预算、三种子受控对照。
& $py -B v4_unified.py train-calibrated -- --output-dir E:/Codex/eit_complex_information_study_20261013/runs/final4840_controlled --modes amplitude complex calibrated amplitude_calibrated --seeds 20261013 20261014 20261015 --epochs 40 --batch-size 64
```

主线正式训练完成后的独立测试（如使用物理分支，另加相同 `--physics-operator`）：

```powershell
& $py -B v4_unified.py infer-native -- --checkpoint outputs/final4840_formal_calibrated/best.pt --dataset-root E:/Codex/eit_dataset_final_v6_4840/extracted/V6_4840_Minimal --split test --evaluate --device cuda --output-dir outputs/final4840_formal_calibrated_test
& $py -B -m comsol_v4.plot --predictions outputs/final4840_formal_calibrated_test --max-cases 10
```

受控对照全部训练结束后：

```powershell
& $py -B v4_unified.py evaluate-calibrated -- --run-root E:/Codex/eit_complex_information_study_20261013/runs/final4840_controlled --output-dir E:/Codex/eit_complex_information_study_20261013/evaluations/final4840_controlled --split test
& $py -B v4_unified.py analyze-calibrated -- --evaluation-root E:/Codex/eit_complex_information_study_20261013/evaluations/final4840_controlled
```

已有模型的查看/旧架构单病例推理仍通过 `list`、`infer --backend imported-original|imported-long|local-calibrated`，它们是历史基线，不取代上述正式训练。主线新权重用 `infer-native`，不要将不同架构/格式的权重相互加载。

复验：

```powershell
& $py -B -m comsol_v4.test_final4840 --output-dir outputs/final4840_acceptance --normalizer outputs/final4840_acceptance/calibrated_smoke/normalizer.npz --physics-operator integrations/v4_20261015/derived/reference_physics_final4840.npz
```

迁移电脑时要连同最终 minimal 原包一起复制；当前默认数据位置相对 `E:\Codex` 这一项目父目录解析，可整体迁移目录。代码保留最终数据签名，不接受换成旧数据后沿用新数据名称。历史独立工程和旧命令保留为档案，不属于本次承诺的最终数据训练入口。
