"""Frozen-stage predictions and actual nonlinear FEM residuals, with provenance."""
import json,time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import torch
from torch.utils.data import DataLoader
from torch.nn import functional as F
from comsol_v4.data_v6 import FINAL_DATASET_ROOT,ComsolDataset,row_case_path,read_measurements,load_rows
from comsol_v4.train import load_checkpoint
from comsol_v4.paper_common import write_json,save_checkpoint
from .fem import TerminalFEM,EPS0
from .verify import background_parameters


def cache_split(root,split,checkpoint,protocol_hash):
    root=Path(root);dest=root/'cache'/split;dest.mkdir(parents=True,exist_ok=True)
    final=dest/'complete.json'
    if final.exists():
        marker=json.loads(final.read_text())
        if marker['protocol_sha256']!=protocol_hash:raise ValueError('Cache protocol changed')
        return
    model,norm,_,ck=load_checkpoint(checkpoint,torch.device('cuda'),None)
    model.eval();ds=ComsolDataset(FINAL_DATASET_ROOT,split,norm,with_labels=False)
    solver=TerminalFEM(ds.x,ds.y,ds.fov);refs={}
    # Only known homogeneous background parameters, no lesion parameters.
    row_by_id={r['case_id']:r for r in ds.rows}
    parameters={}
    for row in ds.rows:
        with np.load(row_case_path(FINAL_DATASET_ROOT,row),allow_pickle=False) as z:
            p=json.loads(z['parameters_json'].item());bg=background_parameters(p)
        parameters[row['case_id']]=bg
        for g in bg:
            if g not in refs:refs[g]=solver.solve(np.full((64,64),g))[0]
    buffer={}
    def hook(_module,_args,output):buffer['raw']=output.detach()
    handle=model.material_head.register_forward_hook(hook)
    def process(item):
        cid,state=item;path=dest/(cid+'.npz')
        v,b,_,_=read_measurements(row_case_path(FINAL_DATASET_ROOT,row_by_id[cid]))
        residuals=[];hints=[];errors=[];preds=[]
        for fi,freq in enumerate((10000,50000)):
            gamma=state['sigma'][fi]+1j*2*np.pi*freq*EPS0*state['eps_r'][fi]
            ref=refs[parameters[cid][fi]]
            predicted,r,h,error=solver.residual_hint(gamma,v[fi]-b[fi]+ref,b[fi])
            residuals.append(r);errors.append(error);preds.append(predicted-ref+b[fi])
            # Scale the adjoint directions in log-material units, separately by frequency.
            hs=h.real*state['sigma'][fi];he=h.imag*(2*np.pi*freq*EPS0)*state['eps_r'][fi]
            hints.append((hs,he))
        h=np.stack([hints[0][0],hints[1][0],hints[0][1],hints[1][1]])
        scales=np.quantile(np.abs(h[:,ds.fov]),.99,axis=1).clip(1e-12)
        h=np.clip(h/scales[:,None,None],-5,5).astype(np.float32)
        r=np.stack(residuals)
        state.update(residual=np.concatenate((r.real,r.imag)).astype(np.float32),hint=h,
                     voltage_error=np.asarray(errors),predicted_voltage=np.stack(preds),
                     protocol_sha256=np.array(protocol_hash),case_id=np.array(cid))
        tmp=path.with_suffix('.tmp.npz');np.savez_compressed(tmp,**state);tmp.replace(path)
        return cid
    processed=0;start=time.monotonic()
    with ThreadPoolExecutor(max_workers=3) as pool,torch.no_grad():
        for batch in DataLoader(ds,batch_size=24,shuffle=False,num_workers=0):
            ids=batch['case_id'];needed=[i for i,cid in enumerate(ids) if not (dest/(cid+'.npz')).exists()]
            if needed:
                features=batch['features'][needed].cuda();out=model(features)
                raw=buffer['raw'];ls=F.softplus(raw[:,:2])+1e-6;le=(F.softplus(raw[:,2:])+1e-6)*10000
                conditional=out['base_probabilities'][:,1:]/out['base_probabilities'][:,1:].sum(1,keepdim=True).clamp_min(1e-7)
                fields={'features':features,'fg':out['foreground_probability'],'conditional':conditional,
                        'sigma':out['sigma'],'eps_r':out['eps_r'],'lesion_sigma':ls,'lesion_eps':le,
                        'background_sigma':out['background_sigma'],'background_eps':out['background_eps_r']}
                arrays={k:v.cpu().numpy() for k,v in fields.items()}
                tasks=[(ids[j],{k:v[i] for k,v in arrays.items()}) for i,j in enumerate(needed)]
                list(pool.map(process,tasks))
            processed+=len(ids)
            print(f'CACHE {split} {processed}/{len(ds)} seconds={time.monotonic()-start:.1f}',flush=True)
            write_json(root/'status.json',{'phase':'physics_cache','split':split,'processed':processed,'total':len(ds),'updated_unix':time.time()})
    handle.remove()
    for cid in row_by_id:
        with np.load(dest/(cid+'.npz'),allow_pickle=False) as z:
            if z['protocol_sha256'].item()!=protocol_hash or z['case_id'].item()!=cid:raise ValueError('Invalid cached provenance')
            for k in ('sigma','eps_r','residual','hint','predicted_voltage'):
                if not np.isfinite(z[k]).all():raise ValueError('Nonfinite cache')
    write_json(final,{'protocol_sha256':protocol_hash,'case_count':len(ds),'case_ids':list(row_by_id),'seconds':time.monotonic()-start})
    del model;torch.cuda.empty_cache()


def load_split(root,split,normalizer,device):
    from torch.utils.data import default_collate
    root=Path(root);ds=ComsolDataset(FINAL_DATASET_ROOT,split,normalizer)
    items=[]
    for i,row in enumerate(ds.rows):
        with np.load(root/'cache'/split/(row['case_id']+'.npz'),allow_pickle=False) as z:
            state={k:torch.from_numpy(z[k].copy()) for k in ('features','fg','conditional','sigma','eps_r','lesion_sigma','lesion_eps','background_sigma','background_eps','residual','hint')}
        target=ds[i];state['target']={k:v for k,v in target.items() if k not in ('features','frequencies_hz')}
        state.update(case_id=row['case_id'],shape_class=row['shape_class']);items.append(state)
    def move(a):
        if torch.is_tensor(a):return a.to(device)
        if isinstance(a,dict):return {k:move(v) for k,v in a.items()}
        return a
    return move(default_collate(items)),ds
