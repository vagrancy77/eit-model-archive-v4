"""One learned bidirectional correction after a freshly evaluated FEM residual.

The pretrained first stage is frozen in this feasibility experiment. Cached
first-stage FEM quantities are exact for that frozen stage, not a surrogate.
No per-case optimization, ground-truth mask, or material labels enter forward.
"""
import torch
from torch import nn
from torch.nn import functional as F
from pytorch_eit.topology_residual_net import ResidualBlock


class FeedbackRefiner(nn.Module):
    def __init__(self,fov,base=24,feedback=True):
        super().__init__();self.feedback=feedback
        self.register_buffer('fov',torch.as_tensor(fov,dtype=torch.float32)[None,None])
        self.lift=nn.Sequential(nn.Flatten(),nn.Linear(16*32*32,256),nn.Unflatten(1,(1,16,16)),
                                nn.Upsample(size=(64,64),mode='bilinear',align_corners=False),nn.Conv2d(1,4,3,padding=1),nn.SiLU())
        self.e0=ResidualBlock(15,base);self.e1=ResidualBlock(base,base*2)
        self.e2=ResidualBlock(base*2,base*4);self.e3=ResidualBlock(base*4,base*8)
        self.d2=ResidualBlock(base*12,base*4);self.d1=ResidualBlock(base*6,base*2);self.d0=ResidualBlock(base*3,base)
        self.head=nn.Conv2d(base,7,1);self.background=nn.Linear(base*8,4)
        nn.init.zeros_(self.head.weight);nn.init.zeros_(self.head.bias)
        nn.init.zeros_(self.background.weight);nn.init.zeros_(self.background.bias)

    def forward(self,b):
        residual=b['residual'] if self.feedback else torch.zeros_like(b['residual'])
        hint=b['hint'] if self.feedback else torch.zeros_like(b['hint'])
        lift=self.lift(torch.cat((b['features'],(residual/.05).clamp(-10,10)),1))*self.fov
        # 1 probability + 2 conditional classes + 4 log material maps + 4 adjoint hints + 4 learned maps.
        material=torch.cat(((b['sigma'].clamp_min(1e-6)/.1).log(),(b['eps_r'].clamp_min(1)/10000).log()),1)*self.fov
        x=torch.cat((b['fg'],b['conditional'],material,hint,lift),1)
        e0=self.e0(x);e1=self.e1(F.avg_pool2d(e0,2));e2=self.e2(F.avg_pool2d(e1,2));e3=self.e3(F.avg_pool2d(e2,2))
        up=lambda a,b:F.interpolate(a,size=b.shape[-2:],mode='bilinear',align_corners=False)
        d2=self.d2(torch.cat((up(e3,e2),e2),1));d1=self.d1(torch.cat((up(d2,e1),e1),1));d0=self.d0(torch.cat((up(d1,e0),e0),1))
        raw=self.head(d0);bg=self.background(e3.mean((2,3)))[:,:,None,None]
        # At zero correction preserve the original p exactly, while avoiding a
        # saturated input preventing additions: use a calibrated logit offset.
        clipped=b['fg'].clamp(.005,.995)
        shifted=torch.sigmoid(torch.logit(clipped)+8*torch.tanh(raw[:,:1]))
        fg=(b['fg']+shifted-clipped).clamp(1e-6,1-1e-6)*self.fov
        conditional=torch.softmax(b['conditional'].clamp_min(1e-8).log()+2*torch.tanh(raw[:,1:3]),1)
        ls=b['lesion_sigma']*torch.exp(.5*torch.tanh(raw[:,3:5]))
        le=b['lesion_eps']*torch.exp(.5*torch.tanh(raw[:,5:7]))
        bs=b['background_sigma']*torch.exp(.25*torch.tanh(bg[:,:2]))
        be=b['background_eps']*torch.exp(.25*torch.tanh(bg[:,2:]))
        sigma=(bs+fg*(ls-bs))*self.fov;eps=(be+fg*(le-be))*self.fov
        probs=torch.cat((1-fg,fg*conditional),1)
        base_probs=torch.cat((1-b['fg'],b['fg']*b['conditional']),1)
        return {'foreground_probability':fg,'probabilities':probs,'logits':probs.clamp_min(1e-8).log(),
                'base_probabilities':base_probs,'sigma':sigma,'eps_r':eps,
                'lesion_sigma':ls,'lesion_eps':le,'background_sigma':bs,'background_eps':be,
                'conditional':conditional,'fg':fg}


def loss(out,b,fov):
    from comsol_v4.losses import region_mean,dice_loss
    target=b['target'];p=out['foreground_probability']
    ce=region_mean(F.nll_loss(out['logits'],target['labels'],weight=p.new_tensor([.24,1.,1.]),reduction='none')[:,None],fov)
    dice=dice_loss(p,target['mask'],fov);pieces={'ce':ce,'dice':dice}
    for key in ('sigma','eps_r'):
        error=F.smooth_l1_loss(out[key].clamp_min(1e-8).log(),target[key].clamp_min(1e-8).log(),beta=.15,reduction='none')
        pieces[key]=.5*(region_mean(error,target['mask']*fov)+region_mean(error,(1-target['mask'])*fov))
    boundary=p.sum()*0
    for dim in (-1,-2):
        valid=fov[...,1:]*fov[...,:-1] if dim==-1 else fov[...,1:,:]*fov[...,:-1,:]
        boundary+=region_mean((p.diff(dim=dim)-target['mask'].diff(dim=dim)).abs(),valid)
    score=ce+dice+.65*pieces['sigma']+.35*pieces['eps_r']
    total=score+.15*boundary+.01*region_mean((p-b['fg']).abs(),fov)
    return total,score
