"""Fast implementation tests before full-cohort training."""
import unittest
import numpy as np
import torch
from .model import FeedbackRefiner,loss

class ModelTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(2);torch.manual_seed(42)
        fov=np.ones((64,64),bool);self.model=FeedbackRefiner(fov,base=8)
        p=torch.rand(2,1,64,64)*.98+.01
        bs=torch.full((2,2,1,1),.1);be=torch.full((2,2,1,1),10000.)
        ls=torch.full((2,2,64,64),.2);le=torch.full_like(ls,20000.)
        self.b={'features':torch.randn(2,12,32,32),'residual':torch.randn(2,4,32,32)*.01,
                'hint':torch.randn(2,4,64,64),'fg':p,'conditional':torch.full((2,2,64,64),.5),
                'lesion_sigma':ls,'lesion_eps':le,'background_sigma':bs,'background_eps':be,
                'sigma':bs+p*(ls-bs),'eps_r':be+p*(le-be)}
    def test_identity(self):
        o=self.model(self.b)
        for a,b in [('fg','fg'),('sigma','sigma'),('eps_r','eps_r')]:
            torch.testing.assert_close(o[a],self.b[b],rtol=1e-5,atol=1e-6)
    def test_both_directions_and_positive_materials(self):
        for bias,sign in ((.2,1),(-.2,-1)):
            with torch.no_grad():self.model.head.bias[0]=bias
            o=self.model(self.b)
            self.assertTrue(bool(((o['fg']-self.b['fg'])*sign>=-1e-6).all()))
            self.assertTrue(bool((o['sigma']>0).all()));self.assertTrue(bool((o['eps_r']>0).all()))
    def test_no_labels_in_forward(self):
        a=self.model(self.b);self.b['target']={'mask':torch.randn(2,1,64,64)}
        b=self.model(self.b);torch.testing.assert_close(a['fg'],b['fg'])
    def test_backward(self):
        p=self.b['fg'];mask=(p>.5).float()
        self.b['target']={'mask':mask,'labels':mask[:,0].long(),'sigma':self.b['sigma'],'eps_r':self.b['eps_r']}
        total,_=loss(self.model(self.b),self.b,self.model.fov);total.backward()
        self.assertTrue(bool(torch.isfinite(self.model.head.weight.grad).all()))
        self.assertGreater(float(self.model.head.weight.grad.abs().sum()),0.)
    def test_no_feedback_control_ignores_physics(self):
        self.model.feedback=False
        with torch.no_grad():self.model.head.weight.normal_(0,.01)
        a=self.model(self.b);self.b['hint']*=100;self.b['residual']*=100
        b=self.model(self.b);torch.testing.assert_close(a['fg'],b['fg'])

if __name__=='__main__':unittest.main()
