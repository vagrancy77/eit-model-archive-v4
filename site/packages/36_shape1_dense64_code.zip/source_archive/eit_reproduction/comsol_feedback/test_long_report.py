import unittest
import numpy as np
from .long_report import paired_statistics


class StatisticsTests(unittest.TestCase):
    def test_zero_difference(self):
        r = paired_statistics(np.zeros((3, 6)), [0, 0, 1, 1, 2, 2], draws=100)
        self.assertEqual(r["mean_difference"], 0)
        self.assertEqual(r["crossed_seed_position_bootstrap_95ci"], [0, 0])

    def test_constant_difference_unequal_cluster_sizes(self):
        r = paired_statistics(np.full((3, 6), .125), [0, 0, 0, 1, 1, 2], draws=100)
        np.testing.assert_allclose(r["crossed_seed_position_bootstrap_95ci"], [.125, .125])
        self.assertEqual(r["mean_difference"], .125)

    def test_paired_seed_variability(self):
        a = np.array([[-1.] * 6, [0.] * 6, [1.] * 6])
        r = paired_statistics(a, [0, 0, 1, 1, 2, 2], draws=1000)
        self.assertEqual(r["seed_sd"], 1.)
        self.assertLess(r["crossed_seed_position_bootstrap_95ci"][0], 0)
        self.assertGreater(r["crossed_seed_position_bootstrap_95ci"][1], 0)


if __name__ == "__main__":
    unittest.main()
