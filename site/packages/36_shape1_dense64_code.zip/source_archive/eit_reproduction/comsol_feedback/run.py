"""One-seed, full-cohort feedback feasibility experiment, safe to resume.

Stage 1 frozen; K=1 learned feedback update; no end-to-end FEM loss in this
first experiment. Both residual and no-feedback capacity-control are trained.
All weights selected on validation before test access. Previous test results
have been seen in this research project: this is not a virgin confirmatory set.
"""
import argparse,json,time,random,os
from pathlib import Path
import numpy as np
import torch
from .cache import cache_split,load_split
from .model import FeedbackRefiner,loss
from .verify import run as verify
from comsol_v4.data_v6 import FINAL_DATASET_ROOT,assert_final_dataset,signature,file_hash,Normalizer,grid_arrays
from comsol_v4.paper_common import write_json,save_checkpoint,configure_runtime,StopState
from comsol_v4.metrics import per_case_metrics,aggregate

PROJECT=Path(__file__).resolve().parents[1]
BASE=PROJECT/'outputs/final4840_paper_suite/runs/calibrated_seed20261016/best.pt'
SOURCES=('fem.py','model.py','cache.py','run.py','verify.py')

def protocol():
    return {'version':'complex-feedback-v1','dataset_signature':signature(FINAL_DATASET_ROOT),
            'baseline_checkpoint':str(BASE),'baseline_sha256':file_hash(BASE),'baseline_policy':'first preregistered seed; not chosen by test',
            'seed':20261020,'variants':['feedback','no_feedback'],'K':1,'base':24,
            'max_epochs':60,'minimum_epochs':20,'patience':12,'minimum_improvement':1e-4,
            'batch_size':24,'learning_rate':1e-4,'weight_decay':1e-4,
            'lr_patience':4,'lr_factor':.5,'min_lr':2e-6,
            'fem_spacing_m':.0016,'first_stage_frozen':True,'end_to_end_physics_loss':False,
            'selection':'validation CE + Dice + .65 log_sigma + .35 log_eps; common to both variants',
            'test_policy':'evaluate only after both variants frozen; historical test already observed; exploratory',
            'background_assumption':'measured V0 plus known homogeneous background material constants',
            'source_hashes':{s:file_hash(Path(__file__).parent/s) for s in SOURCES},
            'base_sources':{s:file_hash(PROJECT/'comsol_v4'/s) for s in ('model.py','features.py','data_v6.py','metrics.py','losses.py')}}

def select(data,idx):
    if torch.is_tensor(data):return data[idx.to(data.device)]
    if isinstance(data,dict):return {k:select(v,idx) for k,v in data.items()}
    return [data[i] for i in idx.tolist()]

def epoch_run(model,data,p,epoch,optimizer=None):
    train=optimizer is not None;model.train(train);n=len(data['case_id'])
    gen=torch.Generator().manual_seed(p['seed']+epoch*1000003)
    order=torch.randperm(n,generator=gen) if train else torch.arange(n)
    sums=np.zeros(2);rows=[]
    for idx in order.split(p['batch_size']):
        b=select(data,idx)
        with torch.set_grad_enabled(train):
            out=model(b);total,score=loss(out,b,model.fov)
            if not torch.isfinite(total):raise FloatingPointError('Nonfinite training loss')
            if train:
                optimizer.zero_grad(set_to_none=True);total.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True);optimizer.step()
            sums+=np.array([float(total.detach()),float(score.detach())])*len(idx)
        if not train:rows.extend(per_case_metrics(out,b['target'],model.fov))
    return {'loss':float(sums[0]/n),'selection_loss':float(sums[1]/n),'processed_cases':n},aggregate(rows) if rows else None

def preview(model,data,root,name,epoch):
    # Fixed first two validation cases per class, never selected for good results.
    ids=[]
    for cls in 'ABCDE':ids.extend([i for i,c in enumerate(data['shape_class']) if c==cls][:2])
    batch=select(data,torch.tensor(ids))
    with torch.no_grad():out=model(batch)
    np.savez_compressed(root/'runs'/name/f'validation_{epoch:03d}.npz',
                        truth=batch['target']['mask'].cpu().numpy(),base=batch['fg'].cpu().numpy(),
                        prediction=out['foreground_probability'].cpu().numpy(),case_ids=np.array(batch['case_id']),
                        sigma=out['sigma'].cpu().numpy(),true_sigma=batch['target']['sigma'].cpu().numpy())

def train(root,p,phash):
    c=torch.load(BASE,map_location='cpu',weights_only=True);norm=Normalizer.from_state(c['normalizer']);del c
    data={};ds=None
    for split in ('train','val'):data[split],ds=load_split(root,split,norm,'cuda')
    for name in p['variants']:
        dest=root/'runs'/name;dest.mkdir(parents=True,exist_ok=True)
        if (dest/'complete.json').exists():
            done=json.loads((dest/'complete.json').read_text())
            if done['protocol_sha256']!=phash or done['checkpoint_sha256']!=file_hash(dest/'best.pt'):raise ValueError('Completed checkpoint differs')
            continue
        configure_runtime(p['seed']);model=FeedbackRefiner(ds.fov,p['base'],name=='feedback').cuda()
        opt=torch.optim.AdamW(model.parameters(),lr=p['learning_rate'],weight_decay=p['weight_decay'])
        scheduler=torch.optim.lr_scheduler.ReduceLROnPlateau(opt,patience=p['lr_patience'],factor=p['lr_factor'],min_lr=p['min_lr'],threshold=p['minimum_improvement'],threshold_mode='abs')
        stop=StopState(p['minimum_improvement']);history=[];start=0;best_epoch=0
        initial,_=epoch_run(model,data['val'],p,0);best=float(initial['selection_loss'])
        def checkpoint(epoch):
            return {'protocol_sha256':phash,'model':model.state_dict(),'optimizer':opt.state_dict(),'scheduler':scheduler.state_dict(),
                    'early_stop':stop.state_dict(),'history':history,'epoch':epoch,'best_score':best,'best_epoch':best_epoch,
                    'rng_cpu':torch.get_rng_state(),'rng_cuda':torch.cuda.get_rng_state_all()}
        if (dest/'last.pt').exists():
            ck=torch.load(dest/'last.pt',map_location='cpu',weights_only=True)
            if ck['protocol_sha256']!=phash:raise ValueError('Resume source/config differs')
            model.load_state_dict(ck['model']);opt.load_state_dict(ck['optimizer']);scheduler.load_state_dict(ck['scheduler']);stop.load_state_dict(ck['early_stop'])
            history=ck['history'];start=ck['epoch'];best=ck['best_score'];best_epoch=ck['best_epoch']
            torch.set_rng_state(ck['rng_cpu']);torch.cuda.set_rng_state_all(ck['rng_cuda']);del ck
        else:
            stop.step(best);save_checkpoint(dest/'best.pt',checkpoint(0))
        reason='max_epochs'
        for epoch in range(start+1,p['max_epochs']+1):
            if epoch>p['minimum_epochs'] and stop.bad_epochs>=p['patience']:reason='validation_early_stopping';break
            t=time.monotonic();tr,_=epoch_run(model,data['train'],p,epoch,opt);va,metrics=epoch_run(model,data['val'],p,epoch)
            score=va['selection_loss'];scheduler.step(score);stop.step(score)
            improved=score<best
            if improved:best=float(score);best_epoch=epoch
            history.append({'epoch':epoch,'train':tr,'val':va,'val_metrics':metrics,'lr':opt.param_groups[0]['lr'],'seconds':time.monotonic()-t})
            if improved:save_checkpoint(dest/'best.pt',checkpoint(epoch))
            save_checkpoint(dest/'last.pt',checkpoint(epoch))
            write_json(dest/'history.json',history)
            write_json(root/'status.json',{'phase':'training','variant':name,'epoch':epoch,'max_epochs':p['max_epochs'],
                        'selected_epoch':best_epoch,'val_iou':metrics['all']['foreground_iou'],'seconds_per_epoch':history[-1]['seconds'],'updated_unix':time.time()})
            print(f'TRAIN {name} {epoch}/{p["max_epochs"]} val={score:.6f} IoU={metrics["all"]["foreground_iou"]:.5f} sec={history[-1]["seconds"]:.1f}',flush=True)
            if epoch==1 or epoch%10==0:preview(model,data['val'],root,name,epoch)
        if len(history)>=p['minimum_epochs'] and stop.bad_epochs>=p['patience']:reason='validation_early_stopping'
        write_json(dest/'complete.json',{'protocol_sha256':phash,'epochs':len(history),'selected_epoch':best_epoch,
                   'stop_reason':reason,'best_score':best,'checkpoint_sha256':file_hash(dest/'best.pt')})
        del model,opt,scheduler;torch.cuda.empty_cache()
    del data;torch.cuda.empty_cache()

def evaluate(root,p,phash):
    frozen={name:json.loads((root/'runs'/name/'complete.json').read_text()) for name in p['variants']}
    for name,d in frozen.items():
        if d['protocol_sha256']!=phash or d['checkpoint_sha256']!=file_hash(root/'runs'/name/'best.pt'):raise ValueError('Frozen check failed')
    write_json(root/'frozen_evaluation.json',frozen)
    cache_split(root,'test',BASE,phash)
    c=torch.load(BASE,map_location='cpu',weights_only=True);norm=Normalizer.from_state(c['normalizer']);del c
    data,ds=load_split(root,'test',norm,'cuda')
    for name in ['baseline']+p['variants']:
        folder=root/'evaluations'/name;folder.mkdir(parents=True,exist_ok=True)
        model=None
        if name!='baseline':
            model=FeedbackRefiner(ds.fov,p['base'],name=='feedback').cuda()
            ck=torch.load(root/'runs'/name/'best.pt',map_location='cpu',weights_only=True);model.load_state_dict(ck['model']);model.eval();del ck
        rows=[]
        with torch.no_grad():
            for idx in torch.arange(len(ds)).split(p['batch_size']):
                b=select(data,idx)
                if model is None:
                    probs=torch.cat((1-b['fg'],b['fg']*b['conditional']),1)
                    out={'probabilities':probs,'base_probabilities':probs,'sigma':b['sigma'],'eps_r':b['eps_r'],'foreground_probability':b['fg']}
                else:out=model(b)
                rows.extend(per_case_metrics(out,b['target'],torch.tensor(ds.fov,device='cuda')[None,None].float()))
                for i,cid in enumerate(b['case_id']):
                    np.savez_compressed(folder/(cid+'.npz'),fg=out['foreground_probability'][i].cpu().numpy(),
                                        probabilities=out['probabilities'][i].cpu().numpy(),sigma=out['sigma'][i].cpu().numpy(),
                                        eps_r=out['eps_r'][i].cpu().numpy(),truth=b['target']['mask'][i].cpu().numpy(),
                                        true_sigma=b['target']['sigma'][i].cpu().numpy())
        write_json(folder/'metrics.json',{'protocol_sha256':phash,'case_count':len(rows),'aggregate':aggregate(rows),'records':rows})
        print('EVALUATED '+name,flush=True)
        del model;torch.cuda.empty_cache()
    del data;torch.cuda.empty_cache()
    from .report import physical_evaluation,report
    physical_evaluation(root,p);report(root,p)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path('E:/Codex/complex_feedback_v1'));a=ap.parse_args();root=a.root.resolve();root.mkdir(parents=True,exist_ok=True)
    # Lifetime Windows byte lock; OS releases it on exit, no stale PID deletion.
    import msvcrt
    lock=(root/'worker.lock').open('a+b');lock.seek(0)
    try:msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
    except OSError:raise RuntimeError('Feedback worker is already running')
    try:
        configure_runtime(20261020);assert_final_dataset(FINAL_DATASET_ROOT)
        p=protocol();path=root/'protocol.json'
        if path.exists() and json.loads(path.read_text())!=p:raise ValueError('Protocol/source changed; new output directory required')
        if not path.exists():write_json(path,p)
        phash=file_hash(path)
        if (root/'complete.json').exists():print('Already complete');return
        qa=root/'qa'/'physics_acceptance.json'
        if not qa.exists():verify(root/'qa')
        if json.loads(qa.read_text())['status']!='PASS':raise ValueError('Physics acceptance not passed')
        for split in ('train','val'):cache_split(root,split,BASE,phash)
        train(root,p,phash);evaluate(root,p,phash)
        write_json(root/'complete.json',{'protocol_sha256':phash,'finished_unix':time.time(),'single_seed_feasibility':True})
        write_json(root/'status.json',{'phase':'complete','updated_unix':time.time()})
    except Exception as e:
        write_json(root/'status.json',{'phase':'failed','error':repr(e),'updated_unix':time.time()});raise
    finally:lock.close()

if __name__=='__main__':main()
