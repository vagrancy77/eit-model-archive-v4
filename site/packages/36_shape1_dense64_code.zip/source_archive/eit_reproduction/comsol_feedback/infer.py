"""Measurement-only inference: frozen V4 -> nonlinear FEM -> one correction.

Known homogeneous background constants are explicit experimental metadata.
Internal fields, lesion masks and lesion material parameters are never read.
This checkpoint is trained for K=1; do not silently repeat it more times.
"""
import argparse,json
from pathlib import Path
import numpy as np
import torch
from torch.nn import functional as F
from .fem import TerminalFEM,EPS0
from .model import FeedbackRefiner
from .verify import background_parameters
from comsol_v4.data_v6 import read_measurements,file_hash
from comsol_v4.features import calibrated_features
from comsol_v4.train import load_checkpoint


def physical_inputs(solver,state,v,b,background):
    residuals=[];hints=[];errors=[];preds=[]
    for fi,freq in enumerate((10000,50000)):
        ref=solver.solve(np.full((64,64),background[fi]))[0]
        gamma=state['sigma'][fi]+1j*2*np.pi*freq*EPS0*state['eps_r'][fi]
        predicted,r,h,error=solver.residual_hint(gamma,v[fi]-b[fi]+ref,b[fi])
        residuals.append(r);errors.append(error);preds.append(predicted-ref+b[fi])
        hints.append((h.real*state['sigma'][fi],h.imag*(2*np.pi*freq*EPS0)*state['eps_r'][fi]))
    h=np.stack([hints[0][0],hints[1][0],hints[0][1],hints[1][1]])
    scales=np.quantile(np.abs(h[:,solver.fov]),.99,axis=1).clip(1e-12)
    r=np.stack(residuals)
    return {'residual':np.concatenate((r.real,r.imag)).astype(np.float32),
            'hint':np.clip(h/scales[:,None,None],-5,5).astype(np.float32),
            'voltage_error':np.asarray(errors),'predicted_voltage':np.stack(preds)}


@torch.no_grad()
def reconstruct(root,input_path,variant='feedback',verify_cache=False):
    root=Path(root);input_path=Path(input_path);p=json.loads((root/'protocol.json').read_text())
    # Match training precision; default CUDA TF32 settings can otherwise change
    # boundary probabilities and their physical residual, even with same weights.
    from comsol_v4.paper_common import configure_runtime
    configure_runtime(p['seed'])
    if p['K']!=1:raise ValueError('This implementation/checkpoint is validated for K=1 only')
    base=Path(p['baseline_checkpoint'])
    if file_hash(base)!=p['baseline_sha256']:raise ValueError('Baseline checkpoint changed')
    model,norm,_,c=load_checkpoint(base,torch.device('cuda'),None)
    model.eval();v,b,_,freq=read_measurements(input_path)
    features=torch.from_numpy(norm(calibrated_features(v,b)))[None].cuda()
    # Access only background metadata, never labels or lesion parameters.
    with np.load(input_path,allow_pickle=False) as z:
        params=json.loads(z['parameters_json'].item()) if 'parameters_json' in z.files else None
    if params is None:params=json.loads((input_path.parent/'case_parameters.json').read_text(encoding='utf-8'))
    known=background_parameters(params);buf={}
    def hook(_m,_a,o):buf['raw']=o
    handle=model.material_head.register_forward_hook(hook);out=model(features);handle.remove()
    raw=buf['raw'];conditional=out['base_probabilities'][:,1:]/out['base_probabilities'][:,1:].sum(1,keepdim=True).clamp_min(1e-7)
    values={'features':features,'fg':out['foreground_probability'],'conditional':conditional,
            'sigma':out['sigma'],'eps_r':out['eps_r'],'lesion_sigma':F.softplus(raw[:,:2])+1e-6,
            'lesion_eps':(F.softplus(raw[:,2:])+1e-6)*10000,
            'background_sigma':out['background_sigma'],'background_eps':out['background_eps_r']}
    state={k:v[0].cpu().numpy() for k,v in values.items()}
    solver=TerminalFEM(c['x'].numpy(),c['y'].numpy(),c['fov'].numpy());physics=physical_inputs(solver,state,v,b,known)
    state.update({k:physics[k] for k in ('hint','residual')})
    if verify_cache:
        found=list((root/'cache').glob('*/'+input_path.stem+'.npz'))
        if len(found)!=1:raise ValueError('Expected exactly one matching cache')
        with np.load(found[0],allow_pickle=False) as z:
            for key in ('fg','sigma','eps_r','residual','hint'):
                np.testing.assert_allclose(state[key],z[key],rtol=2e-3,atol=3e-4,err_msg=key)
    refined=FeedbackRefiner(c['fov'].numpy(),p['base'],variant=='feedback').cuda()
    ckpath=root/'runs'/variant/'best.pt'
    complete=json.loads((root/'runs'/variant/'complete.json').read_text())
    if complete['checkpoint_sha256']!=file_hash(ckpath):raise ValueError('Refiner checkpoint changed')
    ck=torch.load(ckpath,map_location='cpu',weights_only=True)
    if ck['protocol_sha256']!=file_hash(root/'protocol.json'):raise ValueError('Refiner protocol mismatch')
    refined.load_state_dict(ck['model']);refined.eval()
    result=refined({k:torch.as_tensor(value)[None].cuda() for k,value in state.items()})
    fields={k:value[0].cpu().numpy() for k,value in result.items()}
    final_physics=physical_inputs(solver,fields,v,b,known)
    return {**fields,'initial_sigma':state['sigma'],'initial_fg':state['fg'],
            'initial_voltage_error':physics['voltage_error'],'final_voltage_error':final_physics['voltage_error'],
            'predicted_voltage':final_physics['predicted_voltage'],'measured_voltage':v,
            'valid_mask':c['fov'].numpy(),'x':c['x'].numpy(),'y':c['y'].numpy(),
            'metadata_json':json.dumps({'K':1,'variant':variant,'labels_used_as_input':False,'protocol_sha256':file_hash(root/'protocol.json')})}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--input-npz',required=True)
    ap.add_argument('--output',required=True);ap.add_argument('--variant',choices=['feedback','no_feedback'],default='feedback');ap.add_argument('--verify-cache',action='store_true')
    a=ap.parse_args();torch.set_num_threads(2)
    result=reconstruct(a.root,a.input_npz,a.variant,a.verify_cache)
    path=Path(a.output)
    if path.exists():raise FileExistsError(path)
    path.parent.mkdir(parents=True,exist_ok=True);np.savez_compressed(path,**result)
    print(json.dumps({'output':str(path),'initial_voltage_error':result['initial_voltage_error'].tolist(),'final_voltage_error':result['final_voltage_error'].tolist()}))
