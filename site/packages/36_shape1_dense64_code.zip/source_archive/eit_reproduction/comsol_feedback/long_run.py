"""Three paired seeds, full-cohort long training; no test access before freezing."""
import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

from . import run as engine
from .cache import cache_split
from .verify import run as verify
from .audit import audit
from comsol_v4.data_v6 import FINAL_DATASET_ROOT, assert_final_dataset, file_hash
from comsol_v4.paper_common import write_json, configure_runtime

HERE = Path(__file__).resolve().parent
SEEDS = (20261016, 20261017, 20261018)


def seed_protocol(seed):
    engine.BASE = engine.PROJECT / f"outputs/final4840_paper_suite/runs/calibrated_seed{seed}/best.pt"
    p = engine.protocol()
    p.update(
        version="complex-feedback-long-v1",
        seed=seed,
        baseline_policy="matching preregistered V4 seed; all three included",
        max_epochs=250,
        minimum_epochs=100,
        patience=40,
        minimum_improvement=1e-5,
        lr_patience=15,
        min_lr=1e-6,
        test_policy="all six refiners frozen before any new test evaluation; historically observed test, exploratory",
        initialization="new zero-output refiner, not warm-started from short experiment",
    )
    for name in ("long_run.py", "long_report.py", "report.py", "audit.py"):
        p["source_hashes"][name] = file_hash(HERE / name)
    # Capture transitive training dependencies, including reproducibility settings.
    for name in ("paper_common.py", "train.py", "../pytorch_eit/topology_residual_net.py"):
        p["base_sources"][name] = file_hash(engine.PROJECT / "comsol_v4" / name)
    return p


def fixed_json(path, value):
    if path.exists():
        if json.loads(path.read_text(encoding="utf-8")) != value:
            raise ValueError(f"Frozen configuration/source changed: {path}; use a new study directory")
    else:
        write_json(path, value)


def prepare(root):
    assert_final_dataset(FINAL_DATASET_ROOT)
    protocols = {}
    for seed in SEEDS:
        dest = root / f"seed{seed}"
        dest.mkdir(parents=True, exist_ok=True)
        p = seed_protocol(seed)
        fixed_json(dest / "protocol.json", p)
        protocols[str(seed)] = file_hash(dest / "protocol.json")
    p = {
        "version": "complex-feedback-long-v1", "seeds": list(SEEDS),
        "seed_protocol_sha256": protocols,
        "variants": ["feedback", "no_feedback"], "trained_runs": 6,
        "dataset": str(FINAL_DATASET_ROOT),
        "split_counts": {"train": 3400, "val": 720, "test": 720},
        "statistics": "paired seeds and crossed seed/position-cluster bootstrap; only 3 seeds, exploratory intervals",
        "selection": "validation reconstruction loss only; epoch 0 identity is eligible",
        "architecture": "frozen V4 + K=1 refiner, true nonlinear FEM inputs, no end-to-end FEM training loss",
    }
    fixed_json(root / "protocol.json", p)
    return p


def frozen_check(root, suite):
    out = {}
    for seed in SEEDS:
        dest = root / f"seed{seed}"
        ph = suite["seed_protocol_sha256"][str(seed)]
        for variant in suite["variants"]:
            folder = dest / "runs" / variant
            done = json.loads((folder / "complete.json").read_text())
            if done["protocol_sha256"] != ph or done["checkpoint_sha256"] != file_hash(folder / "best.pt"):
                raise ValueError(f"Checkpoint provenance mismatch: {folder}")
            history = json.loads((folder / "history.json").read_text())
            if not 100 <= len(history) <= 250:
                raise ValueError("Long training budget not satisfied")
            if any(h["train"]["processed_cases"] != 3400 or h["val"]["processed_cases"] != 720 for h in history):
                raise ValueError("Partial-cohort epoch detected")
            out[f"{seed}/{variant}"] = done
    return out


def child(root, seed, mode):
    suite = prepare(root)
    dest = root / f"seed{seed}"
    p = seed_protocol(seed)
    ph = suite["seed_protocol_sha256"][str(seed)]
    configure_runtime(seed)
    if mode == "train":
        qa = root / "qa" / "physics_acceptance.json"
        if not qa.exists() or json.loads(qa.read_text())["status"] != "PASS":
            raise ValueError("Physics QA missing or failed")
        for split in ("train", "val"):
            cache_split(dest, split, engine.BASE, ph)
        engine.train(dest, p, ph)
    else:
        frozen = frozen_check(root, suite)
        if json.loads((root / "frozen_evaluation.json").read_text()) != frozen:
            raise ValueError("Suite freeze changed")
        if (dest / "complete.json").exists():
            if json.loads((dest / "complete.json").read_text())["protocol_sha256"] != ph:
                raise ValueError("Completion provenance changed")
            audit(dest)
            return
        engine.evaluate(dest, p, ph)
        audit(dest)
        write_json(dest / "complete.json", {"protocol_sha256": ph, "finished_unix": time.time()})


def launch(root, seed, mode):
    args = [sys.executable, "-u", "-m", "comsol_feedback.long_run", "--root", str(root),
            "--mode", mode, "--seed", str(seed)]
    with (root / f"seed{seed}" / f"{mode}.log").open("ab") as log:
        proc = subprocess.Popen(args, cwd=engine.PROJECT, stdout=log, stderr=subprocess.STDOUT,
                                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
        while True:
            status = {"phase": mode, "seed": seed, "pid": proc.pid, "updated_unix": time.time(),
                      "completed_training_runs": len(list(root.glob("seed*/runs/*/complete.json"))),
                      "total_training_runs": 6}
            path = root / f"seed{seed}" / "status.json"
            if path.exists():
                try:
                    status["detail"] = json.loads(path.read_text())
                except (OSError, ValueError):
                    pass
            write_json(root / "status.json", status)
            try:
                code = proc.wait(timeout=30)
                break
            except subprocess.TimeoutExpired:
                continue
        if code:
            raise RuntimeError(f"{mode} seed {seed} failed, exit {code}; inspect seed log")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, default=Path("E:/Codex/complex_feedback_long_v1"))
    ap.add_argument("--mode", choices=("suite", "prepare", "train", "evaluate"), default="suite")
    ap.add_argument("--seed", type=int, choices=SEEDS)
    args = ap.parse_args()
    root = args.root.resolve()
    root.mkdir(parents=True, exist_ok=True)
    if args.mode in ("train", "evaluate"):
        if args.seed is None:
            ap.error("--seed required for child mode")
        # Per-seed OS lock also protects against an orphan child after parent failure.
        import msvcrt
        with (root / f"seed{args.seed}" / "worker.lock").open("a+b") as lock:
            lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
            child(root, args.seed, args.mode)
        return
    import msvcrt
    with (root / "worker.lock").open("a+b") as lock:
        lock.seek(0)
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        try:
            suite = prepare(root)
            if args.mode == "prepare":
                print("PREPARED", root, flush=True)
                return
            if (root / "complete.json").exists():
                print("Already complete", flush=True)
                return
            write_json(root / "status.json", {"phase": "physics_qa", "updated_unix": time.time()})
            qa = root / "qa" / "physics_acceptance.json"
            if not qa.exists():
                verify(root / "qa")
            if json.loads(qa.read_text())["status"] != "PASS":
                raise ValueError("Physics QA failed")
            for seed in SEEDS:
                print(f"LONG TRAIN SEED {seed}", flush=True)
                launch(root, seed, "train")
            fixed_json(root / "frozen_evaluation.json", frozen_check(root, suite))
            for seed in SEEDS:
                print(f"FROZEN TEST SEED {seed}", flush=True)
                launch(root, seed, "evaluate")
            subprocess.run(["E:/Anaconda/python.exe", "-s", str(HERE / "long_report.py"),
                            "--root", str(root)], check=True,
                           creationflags=subprocess.CREATE_NO_WINDOW)
            write_json(root / "complete.json", {"protocol_sha256": file_hash(root / "protocol.json"),
                       "trained_runs": 6, "evaluated_seed_pairs": 3, "finished_unix": time.time()})
            write_json(root / "status.json", {"phase": "complete", "updated_unix": time.time()})
        except Exception as exc:
            write_json(root / "status.json", {"phase": "failed", "error": repr(exc), "updated_unix": time.time()})
            raise


if __name__ == "__main__":
    main()
