# 非线性复数物理反馈：首轮可行性实验

原始 comsol_v4 和 final4840_paper_suite 不作任何覆盖。本目录是新增模块。
输出目录：`E:/Codex/complex_feedback_v1`（原 outputs 目录当前不可写）。

## 实际实现边界

- 固定最终 `数据集v6_新.zip` 对应的 4840 例数据，3400/720/720 原始位置组划分。
- 基础模型固定为原协议第一种子 calibrated_seed20261016 的验证选择权重；不是按测试选择种子。
- 保留病例与背景电压的实虚部、原有复数校准与训练集归一化。
- 独立 P1 非线性复数有限元，32 个有限宽度等电势理想电流端子，每次重新组装和求解。
- 数据实际未实现有限接触阻抗，因此不冒称有限阻抗 CEM。端子模型按数据实际行为匹配。
- 预测电压采用背景锚定：观测背景 + FEM(当前场) - FEM(已知背景场)。已知背景是明确实验假设，不读病灶真值。
- 同校准空间内计算复数残差；重新求解的伴随梯度映射为四通道空间提示。
- 新 U-Net 输入原始复数特征、当前状态、残差与提示，双向修正几何，并修正两频率材料参数。
- 本次 **K=1**：一次实际物理反馈修正。基础网络冻结，因此首次物理残差可缓存，非学习代理、非固定背景 Jacobian。
- 修正后的电学输出在测试中再次进行非线性求解，报告电压残差是否改善。
- 为控制额外网络容量，训练同结构 no_feedback 对照：残差和伴随提示全部置零，其他一致。
- 本轮监督训练修正网络，不进行端到端 FEM 损失反传；可微 FEM 已实现并通过梯度检查，但不混淆两者。
- 目前只是一种子首轮实验；不得称为多种子最终论文结果、不得保证普通病例不下降。

## 入口与文件

- fem.py：非线性正问题、伴随 VJP、PyTorch 一阶梯度接口。
- verify.py：仅用训练病例的物理与梯度验收。
- cache.py：冻结基础网络的预测与非线性残差，病例级原子保存与协议校验。
- model.py：反馈修正 U-Net、几何—材料耦合、监督损失。
- test_model.py：初始恒等、双向修改、正值、梯度、标签隔离和无反馈对照测试。
- run.py：固定协议、全量训练、验证调度/早停、冻结后测试、断点恢复和 Windows 生命周期锁。
- report.py：独立统计、位置组配对 bootstrap、固定病例及失败病例图，禁止参与模型选择。
- infer.py：真正从病例测量重建、在线求解并修正的独立入口，不依赖训练缓存。

## 运行

在 `E:/Codex/eit_reproduction` 执行：

```powershell
& E:/conda-envs/pytorch-gpu/python.exe -m unittest comsol_feedback.test_model -v
& E:/conda-envs/pytorch-gpu/python.exe -m comsol_feedback.verify --output E:/Codex/complex_feedback_v1/qa
& E:/conda-envs/pytorch-gpu/python.exe -u -m comsol_feedback.run --root E:/Codex/complex_feedback_v1
```

不允许为恢复而改旧协议/源码哈希。已有有效进程时不得重复启动。源码改变须新实验目录。
训练在 CUDA；有限元稀疏求解在 CPU；绘图使用 E:/Anaconda/python.exe -s。
依赖 scipy、numpy、torch、threadpoolctl；绘图环境另需 matplotlib。

## 验收与解释

先核对 qa/physics_acceptance.json，验证覆盖五类形状及两种背景。
背景锚定并不消除非线性离散和像素化误差；误差须公开。
训练/验证标签仅进入损失与指标。正问题预测和网络输入不得读病灶标签。
测试集在本研究历史中已经被观察，当前结果仍属于探索性验证，不声称全新外部验证。
若 no_feedback 同样改善，则不能把总提升全部归因于物理反馈。
达到 60 轮上限不等于已收敛。E 类整体指标不等于小凸起恢复率，需结合局部图像判断。
