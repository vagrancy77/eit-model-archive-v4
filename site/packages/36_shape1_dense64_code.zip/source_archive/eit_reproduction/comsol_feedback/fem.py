"""Nonlinear complex P1 FEM with ideal equipotential current terminals.

Matches the effective final dataset boundary model, not inactive contact metadata.
SI units, 1 m depth, 32 adjacent 0.25 mA drives, 5 degree electrode arcs.
Independent discretization, NOT COMSOL itself; each call rebuilds the system.
"""
import numpy as np
import torch
from scipy import sparse
from scipy.sparse.linalg import splu
from scipy.spatial import Delaunay, cKDTree
from threadpoolctl import threadpool_limits

EPS0 = 8.8541878128e-12


class TerminalFEM:
    def __init__(self, x, y, fov, spacing=.0016, boundary_points=512):
        self.x, self.y, self.fov = np.asarray(x), np.asarray(y), np.asarray(fov, bool)
        radius=.05
        centers=np.arange(32)*2*np.pi/32
        angles=np.unique(np.round(np.r_[np.arange(boundary_points)*2*np.pi/boundary_points,
                                        (centers-np.deg2rad(2.5))%(2*np.pi),
                                        (centers+np.deg2rad(2.5))%(2*np.pi)],12))
        axis=np.arange(-radius+spacing,radius,spacing)
        xx,yy=np.meshgrid(axis,axis)
        interior=np.c_[xx.ravel(),yy.ravel()]
        interior=interior[np.linalg.norm(interior,axis=1)<radius-.55*spacing]
        boundary=radius*np.c_[np.cos(angles),np.sin(angles)]
        xy=np.vstack((interior,boundary));tri=Delaunay(xy).simplices
        coords=xy[tri]
        a,b=coords[:,1]-coords[:,0],coords[:,2]-coords[:,0]
        det=a[:,0]*b[:,1]-a[:,1]*b[:,0];area=np.abs(det)/2
        grad=np.stack([np.c_[coords[:,1,1]-coords[:,2,1],coords[:,2,0]-coords[:,1,0]],
                       np.c_[coords[:,2,1]-coords[:,0,1],coords[:,0,0]-coords[:,2,0]],
                       np.c_[coords[:,0,1]-coords[:,1,1],coords[:,1,0]-coords[:,0,0]]],1)/det[:,None,None]
        self.element=area[:,None,None]*np.einsum('tik,tjk->tij',grad,grad)
        mapping=np.arange(len(xy));electrode_nodes=[]
        for center in centers:
            dist=np.abs((angles-center+np.pi)%(2*np.pi)-np.pi)
            ids=np.flatnonzero(dist<=np.deg2rad(2.5)+1e-10)+len(interior)
            if len(ids)<2: raise ValueError('Unresolved electrode')
            mapping[ids]=ids[0];electrode_nodes.append(ids[0])
        _,mapping=np.unique(mapping,return_inverse=True);el=mapping[electrode_nodes]
        ground=el[-1];free=np.arange(mapping.max()+1)!=ground
        reindex=np.full(len(free),-1);reindex[free]=np.arange(free.sum())
        self.tri=reindex[mapping[tri]];self.electrodes=reindex[el];self.n=int(free.sum())
        rr=np.broadcast_to(self.tri[:,:,None],self.element.shape).ravel()
        cc=np.broadcast_to(self.tri[:,None,:],self.element.shape).ravel()
        self.keep=(rr>=0)&(cc>=0);self.rows,self.cols=rr[self.keep],cc[self.keep]
        self.rhs=np.zeros((self.n,32),complex)
        for d in range(32):
            for e,sign in ((d,1),((d+1)%32,-1)):
                if self.electrodes[e]>=0:self.rhs[self.electrodes[e],d]+=sign*.00025
        gx,gy=np.meshgrid(self.x,self.y);valid_indices=np.flatnonzero(self.fov.ravel())
        tree=cKDTree(np.c_[gx[self.fov],gy[self.fov]])
        self.pixel=valid_indices[tree.query(coords.mean(1))[1]]
        self.info={'kind':'nonlinear_P1_FEM','boundary':'ideal_equipotential_current_terminal',
                   'nodes':len(xy),'free_unknowns':self.n,'triangles':len(tri),
                   'spacing_m':spacing,'depth_m':1.,'radius_m':radius,
                   'current_A':.00025,'electrodes':32,'arc_width_deg':5.,
                   'field_mapping':'nearest_valid_pixel_at_triangle_centroid',
                   'contact_impedance_effective':0.,'voltage_gauge':'last_electrode'}

    def solve(self, gamma):
        g=np.asarray(gamma,dtype=np.complex128).reshape(-1)[self.pixel]
        if not np.isfinite(g).all() or np.any(g.real<=0):raise ValueError('Invalid admittivity')
        values=(self.element*g[:,None,None]).ravel()[self.keep]
        A=sparse.coo_matrix((values,(self.rows,self.cols)),shape=(self.n,self.n)).tocsc()
        with threadpool_limits(limits=1):lu=splu(A);u=lu.solve(self.rhs)
        electrode=np.zeros((32,32),complex);electrode[:31]=u[self.electrodes[:31]]
        return electrode.T, (lu,u)

    def vjp(self, state, gradient_voltage):
        """Complex gradient convention: dL=Re(conj(g)*dx)."""
        lu,u=state;rhs=np.zeros((self.n,32),complex)
        rhs[self.electrodes[:31]]=np.asarray(gradient_voltage).T[:31]
        with threadpool_limits(limits=1):adj=lu.solve(rhs,trans='H')
        up=np.vstack((u,np.zeros((1,32),complex)))[self.tri]
        ap=np.vstack((adj,np.zeros((1,32),complex)))[self.tri]
        derivative=-np.einsum('tid,tij,tjd->t',ap.conj(),self.element,up).conj()
        out=np.bincount(self.pixel,weights=derivative.real,minlength=4096)+1j*np.bincount(self.pixel,weights=derivative.imag,minlength=4096)
        return out.reshape(64,64)

    def residual_hint(self, gamma, observed, background):
        """Calibrated residual and negative adjoint gradient; no lesion truth."""
        from comsol_v4.features import measurement_mask
        valid=measurement_mask();pred,state=self.solve(gamma)
        qb=background-np.roll(background,-1,axis=-1)
        qp=pred-np.roll(pred,-1,axis=-1);qo=observed-np.roll(observed,-1,axis=-1)
        rms=np.sqrt(np.mean(np.abs(qb[valid])**2))
        scale=qb.conj()/(np.abs(qb)**2+(.01*rms)**2)*valid
        residual=(qo-qp)*scale
        gq=-residual*scale.conj()/valid.sum();gv=gq-np.roll(gq,1,axis=-1)
        gradient=self.vjp(state,gv)
        return pred,residual,-gradient,float(np.mean(np.abs(residual[valid])**2))


class _FEMFunction(torch.autograd.Function):
    @staticmethod
    def forward(ctx,gamma,solver):
        array=gamma.detach().cpu().numpy();solved=[solver.solve(g) for g in array.reshape(-1,64,64)]
        ctx.states=[s[1] for s in solved];ctx.solver=solver;ctx.shape=gamma.shape
        return torch.as_tensor(np.stack([s[0] for s in solved]).reshape(*array.shape[:-2],32,32),device=gamma.device,dtype=gamma.dtype)
    @staticmethod
    def backward(ctx,grad):
        array=grad.detach().cpu().numpy().reshape(-1,32,32)
        result=np.stack([ctx.solver.vjp(s,g) for s,g in zip(ctx.states,array)])
        return torch.as_tensor(result.reshape(ctx.shape),device=grad.device,dtype=grad.dtype),None


def forward_voltage(gamma,solver):
    """First-order differentiable nonlinear FEM; no higher-order derivatives."""
    return _FEMFunction.apply(gamma,solver)
