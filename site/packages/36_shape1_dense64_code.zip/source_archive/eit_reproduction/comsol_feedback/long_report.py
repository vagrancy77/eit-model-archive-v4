"""Post-freeze multi-seed statistics and figures, never used for selection."""
import argparse
import json
from pathlib import Path
import numpy as np

VARIANTS = ("baseline", "feedback", "no_feedback")
GROUPS = {"all": "ABCDE", "ordinary_A": "A", "concave_BCDE": "BCDE"}


def paired_statistics(arr, positions, draws=5000, seed=20261020):
    """arr: paired deltas [training seed, case]; crossed bootstrap."""
    arr = np.asarray(arr, dtype=float)
    positions = np.asarray(positions)
    clusters = np.unique(positions)
    sums = np.stack([arr[:, positions == pos].sum(1) for pos in clusters], axis=1)
    counts = np.array([(positions == pos).sum() for pos in clusters])
    rng = np.random.default_rng(seed)
    si = rng.integers(0, len(arr), (draws, len(arr)))
    ci = rng.integers(0, len(clusters), (draws, len(clusters)))
    boot = sums[si[:, :, None], ci[:, None, :]].sum((1, 2)) / (len(arr) * counts[ci].sum(1))
    per_seed = arr.mean(1)
    return {"mean_difference": float(arr.mean()), "per_seed_difference": per_seed.tolist(),
            "seed_sd": float(per_seed.std(ddof=1)),
            "crossed_seed_position_bootstrap_95ci": np.quantile(boot, [.025, .975]).tolist(),
            "seed_count": len(arr), "position_groups": len(clusters), "case_count": arr.shape[1],
            "fraction_seed_case_pairs_better": float((arr > 1e-10).mean()),
            "fraction_seed_case_pairs_worse": float((arr < -1e-10).mean())}


def report(root):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    p = json.loads((root / "protocol.json").read_text())
    seeds = p["seeds"]
    data = []
    physics = []
    stop = {}
    for seed in seeds:
        dest = root / f"seed{seed}"
        if json.loads((dest / "delivery_audit.json").read_text())["status"] != "PASS":
            raise ValueError("Unaudited seed")
        data.append(json.loads((dest / "per_case_metrics.json").read_text()))
        physics.append(json.loads((dest / "test_physics.json").read_text())["records"])
        for name in p["variants"]:
            stop[f"{seed}/{name}"] = json.loads((dest / "runs" / name / "complete.json").read_text())
    metrics = list(json.loads((root / f"seed{seeds[0]}" / "summary_statistics.json").read_text())
                   ["aggregate"]["baseline"]["all"])
    indexed = [{v: {r["case_id"]: r for r in s[v]} for v in VARIANTS} for s in data]
    ids = sorted(indexed[0]["baseline"])
    if len(ids) != 720 or any(set(s[v]) != set(ids) for s in indexed for v in VARIANTS):
        raise ValueError("Unpaired test memberships")
    aggregate, paired = {}, {}
    for v in VARIANTS:
        aggregate[v] = {}
        for g, classes in GROUPS.items():
            selected = [cid for cid in ids if indexed[0][v][cid]["shape_class"] in classes]
            aggregate[v][g] = {}
            for m in metrics:
                values = np.array([[s[v][cid][m] for cid in selected] for s in indexed]).mean(1)
                aggregate[v][g][m] = {"mean": float(values.mean()), "seed_sd": float(values.std(ddof=1)),
                                      "per_seed": values.tolist()}
    for target, reference in (("feedback", "baseline"), ("feedback", "no_feedback"), ("no_feedback", "baseline")):
        label = target + " minus " + reference
        paired[label] = {}
        for g, classes in GROUPS.items():
            selected = [cid for cid in ids if indexed[0][target][cid]["shape_class"] in classes]
            positions = [indexed[0][target][cid]["position_id"] for cid in selected]
            paired[label][g] = {}
            for m in metrics:
                delta = [[s[target][cid][m] - s[reference][cid][m] for cid in selected] for s in indexed]
                r = paired_statistics(delta, positions)
                r["direction"] = "lower_is_better" if ("nrmse" in m or "_mm" in m) else "higher_is_better"
                # Avoid ambiguous 'better' for error metrics.
                r["fraction_positive_differences"] = r.pop("fraction_seed_case_pairs_better")
                r["fraction_negative_differences"] = r.pop("fraction_seed_case_pairs_worse")
                paired[label][g][m] = r
    phys = {}
    for v in VARIANTS:
        values = np.array([np.array([r[v] for r in s]).mean(0) for s in physics])
        phys[v] = {"per_seed_10_50kHz": values.tolist(), "mean_10_50kHz": values.mean(0).tolist(),
                   "seed_sd_10_50kHz": values.std(0, ddof=1).tolist()}
    summary = {"seeds": seeds, "aggregate": aggregate, "paired": paired, "physics": phys,
               "training": stop, "limitations": [
                   "Historically observed test set: exploratory, not an untouched confirmatory test.",
                   "Three training seeds only; bootstrap intervals are exploratory.",
                   "Frozen original V4, K=1 correction, no end-to-end nonlinear FEM loss.",
                   "Reaching 250 epochs is not proof of convergence.",
                   "A-class performance is a proxy for ordinary cases, not proof of clinical generalization.",
                   "Group-average improvements do not imply every case improves."]}
    (root / "summary_statistics.json").write_text(json.dumps(summary, indent=2, allow_nan=False), encoding="utf-8")
    lines = ["# 复数物理反馈模型：三种子长训练", "",
             "固定最终 4,840 例：训练 3,400、验证 720、测试 720。原 V4 冻结；新修正网络从零初始化。",
             "所有 6 个修正网络训练完成并冻结后才统一评估测试集。以下为均值 ± 种子标准差。", "",
             "| 指标（全测试集） | 原 V4 | 物理反馈 | 同容量无反馈 |", "|---|---:|---:|---:|"]
    for m in metrics:
        cells = [f'{aggregate[v]["all"][m]["mean"]:.6f} ± {aggregate[v]["all"][m]["seed_sd"]:.6f}' for v in VARIANTS]
        lines.append("| " + m + " | " + " | ".join(cells) + " |")
    lines += ["", "## 配对差异", "", "差值为前者减后者。IoU/SSIM 越大越好，NRMSE/距离越小越好。",
              "置信区间同时重采样配对种子与测试位置组，不能将 2,160 个种子—病例组合视为独立病例。", "",
              "| 对比 | 子组 | IoU 差值 | 95% bootstrap 区间 |", "|---|---|---:|---|"]
    for label, groups in paired.items():
        for g, vals in groups.items():
            r = vals["foreground_iou"]
            lines.append(f'| {label} | {g} | {r["mean_difference"]:+.6f} | {r["crossed_seed_position_bootstrap_95ci"]} |')
    lines += ["", "## 训练与收敛记录", ""]
    for label, d in stop.items():
        lines.append(f'- {label}: 实际训练 {d["epochs"]} 轮，验证选择 {d["selected_epoch"]} 轮；{d["stop_reason"]}。')
    lines += ["", "## 限制", ""] + ["- " + x for x in summary["limitations"]]
    lines += ["", "## 可视化", "", "- overall_comparison.png：三种子逐点指标，不只显示平均值。",
              "- training_curves.png：全部 6 次训练的验证目标与学习率。",
              "- 每个 seed 目录：fixed_cases.png、material_comparison.png、失败/提升病例及完整指标。",
              "", "本报告不预设物理反馈必然有效。只有反馈优于同容量无反馈对照，才能支持反馈信息的额外贡献。"]
    (root / "RESULTS.md").write_text("\n".join(lines), encoding="utf-8")
    fig, axes = plt.subplots(1, 3, figsize=(14, 4), constrained_layout=True)
    for ax, g in zip(axes, GROUPS):
        for i, v in enumerate(VARIANTS):
            y = aggregate[v][g]["foreground_iou"]["per_seed"]
            ax.scatter(np.full(3, i), y)
            ax.errorbar(i, np.mean(y), yerr=np.std(y, ddof=1), fmt="_", capsize=5, color="black")
        ax.set_xticks(range(3), ["V4", "Feedback", "No feedback"]); ax.set_title(g); ax.set_ylabel("Foreground IoU")
    fig.savefig(root / "overall_comparison.png", dpi=170); plt.close(fig)
    fig, axes = plt.subplots(3, 2, figsize=(12, 11), constrained_layout=True)
    for i, seed in enumerate(seeds):
        for v in p["variants"]:
            h = json.loads((root / f"seed{seed}" / "runs" / v / "history.json").read_text())
            epochs = [r["epoch"] for r in h]
            axes[i, 0].plot(epochs, [r["val"]["selection_loss"] for r in h], label=v)
            axes[i, 1].plot(epochs, [r["lr"] for r in h], label=v)
        axes[i, 0].set_title(f"Seed {seed}: validation selection objective")
        axes[i, 1].set_title("Learning rate"); axes[i, 1].set_yscale("log")
        for ax in axes[i]: ax.legend(); ax.set_xlabel("Epoch")
    fig.savefig(root / "training_curves.png", dpi=160); plt.close(fig)
    print("LONG STUDY REPORT COMPLETE", root, flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    report(parser.parse_args().root)
