"""Training-only FEM acceptance tests. Does not inspect test outcomes."""
import argparse,json,time
from pathlib import Path
import numpy as np
import torch
from .fem import TerminalFEM,EPS0,forward_voltage
from comsol_v4.data_v6 import FINAL_DATASET_ROOT,grid_arrays,load_rows,row_case_path
from comsol_v4.features import measurement_mask
from comsol_v4.paper_common import write_json

def background_parameters(params):
    return np.array([float(params['sig_b'+f])+1j*2*np.pi*hz*EPS0*float(params['eps_b'+f])
                     for f,hz in [('10',10000),('50',50000)]])

def run(output,spacing=.0016):
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    x,y,fov=grid_arrays(FINAL_DATASET_ROOT);solver=TerminalFEM(x,y,fov,spacing)
    mask=measurement_mask();selected={};records=[];bgcache={}
    for row in load_rows(FINAL_DATASET_ROOT,'train'):
        with np.load(row_case_path(FINAL_DATASET_ROOT,row),allow_pickle=False) as z:
            p=json.loads(z['parameters_json'].item());key=(row['shape_class'],p['background_material'])
            if key in selected:continue
            selected[key]=row['case_id'];gamma=z['conductivity_S_per_m']+1j*np.array([10000,50000])[:,None,None]*2*np.pi*EPS0*z['eps_r']
            v,b=z['voltage'],z['background_voltage'];bg=background_parameters(p)
            for fi in range(2):
                t=time.monotonic()
                if bg[fi] not in bgcache:bgcache[bg[fi]]=solver.solve(np.full((64,64),bg[fi]))[0]
                ref=bgcache[bg[fi]];pred=solver.solve(gamma[fi])[0]
                q=lambda a:(a-np.roll(a,-1,-1))[mask]
                bgerr=np.linalg.norm(q(ref-b[fi]))/np.linalg.norm(q(b[fi]))
                deltaerr=np.linalg.norm(q(pred-ref-(v[fi]-b[fi])))/np.linalg.norm(q(v[fi]-b[fi]))
                qpred=q(pred);current_transfers=(pred-np.roll(pred,-1,-1))/.00025
                reciprocity=np.linalg.norm(current_transfers-current_transfers.T)/np.linalg.norm(current_transfers)
                records.append({'case_id':row['case_id'],'class':key[0],'background':key[1],'frequency':int([10000,50000][fi]),
                                'raw_background_relative_error':float(bgerr),'anchored_delta_relative_error':float(deltaerr),
                                'reciprocity_error':float(reciprocity),'seconds':time.monotonic()-t})
                print(records[-1],flush=True)
        if len(selected)==10:break
    # Complex real/imag directional gradient, differentiated through nonlinear solve.
    rng=np.random.default_rng(19);g=np.full((64,64),.1+.02j)
    g[20:34,20:32]=.17+.03j
    gt=torch.tensor(g,dtype=torch.complex128,requires_grad=True)
    w=torch.tensor(rng.normal(size=(32,32))+1j*rng.normal(size=(32,32)),dtype=torch.complex128)
    def objective(t):
        v=forward_voltage(t,solver);q=v-torch.roll(v,-1,-1)
        return (q*w.conj()).real.sum()
    loss=objective(gt);loss.backward();checks=[]
    for imaginary in (False,True):
        direction=rng.normal(size=(64,64))*fov*(1j if imaginary else 1.)
        step=1e-6;d=torch.as_tensor(direction,dtype=torch.complex128)
        fd=float((objective(gt.detach()+step*d)-objective(gt.detach()-step*d))/(2*step))
        analytic=float((gt.grad.conj()*d).real.sum())
        error=abs(fd-analytic)/max(abs(fd),abs(analytic),1e-10)
        checks.append({'imaginary_direction':imaginary,'finite_difference':fd,'adjoint':analytic,'relative_error':error})
    thresholds={'background_relative_error':.03,'anchored_delta_relative_error':.25,'gradient_relative_error':1e-4,'reciprocity_error':1e-8}
    passed=(len(selected)==10 and all(r['raw_background_relative_error']<.03 and r['anchored_delta_relative_error']<.25 and r['reciprocity_error']<1e-8 for r in records)
            and all(c['relative_error']<1e-4 for c in checks))
    report={'status':'PASS' if passed else 'FAIL','solver':solver.info,'scope':'10 training cases, five classes x two backgrounds; no test tuning',
            'thresholds':thresholds,'checks':records,'autograd':checks,
            'anchoring':'Vpred = Vbackground_observed + FEM(gamma_pred) - FEM(gamma_background_known)',
            'limitation':'Independent P1 mesh and rasterized conductivity; not exact original curved COMSOL geometry'}
    write_json(output/'physics_acceptance.json',report)
    print(json.dumps({'status':report['status'],'autograd':checks}),flush=True)
    if not passed:raise RuntimeError('Physics acceptance failed; do not launch training')
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--spacing',type=float,default=.0016)
    a=p.parse_args();run(a.output,a.spacing)
