"""Independent metric/figure reporting; never used for checkpoint selection."""
import argparse,json,sys,time,subprocess,os
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import numpy as np

DATASET=Path('E:/Codex/eit_dataset_final_v6_4840/extracted/V6_4840_Minimal')

def write(path,obj):
    path=Path(path);tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(obj,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8');tmp.replace(path)

def physical_evaluation(root,p):
    from .fem import TerminalFEM,EPS0
    from .verify import background_parameters
    from comsol_v4.data_v6 import grid_arrays,load_rows,row_case_path,read_measurements
    from comsol_v4.features import measurement_mask
    root=Path(root);x,y,fov=grid_arrays(DATASET);solver=TerminalFEM(x,y,fov)
    rows=load_rows(DATASET,'test');refs={};known={};mask=measurement_mask()
    for row in rows:
        with np.load(row_case_path(DATASET,row),allow_pickle=False) as z:bg=background_parameters(json.loads(z['parameters_json'].item()))
        known[row['case_id']]=bg
        for g in bg:
            if g not in refs:refs[g]=solver.solve(np.full((64,64),g))[0]
    def compute(row):
        cid=row['case_id'];v,b,_,_=read_measurements(row_case_path(DATASET,row));res={'case_id':cid,'shape_class':row['shape_class']}
        for name in ['baseline']+p['variants']:
            with np.load(root/'evaluations'/name/(cid+'.npz'),allow_pickle=False) as z:
                sigma,eps=z['sigma'],z['eps_r']
            errors=[]
            for fi,freq in enumerate((10000,50000)):
                gamma=sigma[fi]+1j*2*np.pi*freq*EPS0*eps[fi]
                pred=solver.solve(gamma)[0]-refs[known[cid][fi]]+b[fi]
                qb=b[fi]-np.roll(b[fi],-1,-1);qo=v[fi]-np.roll(v[fi],-1,-1);qp=pred-np.roll(pred,-1,-1)
                rms=np.sqrt(np.mean(np.abs(qb[mask])**2));weight=qb.conj()/(np.abs(qb)**2+(.01*rms)**2)
                errors.append(float(np.mean(np.abs(((qo-qp)*weight)[mask])**2)))
            res[name]=errors
        return res
    results=[]
    with ThreadPoolExecutor(max_workers=3) as pool:
        for i,item in enumerate(pool.map(compute,rows),1):
            results.append(item)
            if i%24==0:
                print(f'TEST PHYSICS {i}/720',flush=True)
                write(root/'status.json',{'phase':'test_physics','processed':i,'total':720,'updated_unix':time.time()})
    write(root/'test_physics.json',{'metric':'mean squared stabilized complex-relative residual; background-anchored independent FEM','records':results})

def report(root,p):
    args=['E:/Anaconda/python.exe','-s',str(Path(__file__).resolve()),'--root',str(root)]
    options={'creationflags':subprocess.CREATE_NO_WINDOW} if os.name=='nt' else {}
    subprocess.run(args,check=True,**options)

def plot(root):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from scipy.ndimage import binary_erosion,distance_transform_edt
    root=Path(root);p=json.loads((root/'protocol.json').read_text())
    variants=['baseline']+p['variants'];titles={'baseline':'Frozen V4','feedback':'Nonlinear physics feedback','no_feedback':'Same refiner, no feedback'}
    positions={r['case_id']:r['position_id'] for r in json.loads((DATASET/'splits.json').read_text())['splits']}
    with np.load(DATASET/'grid.npz') as z:fov=z['valid_mask'].astype(bool);step=float(np.diff(z['x']).mean()*1000)
    records={};byid={};groups={'all':tuple('ABCDE'),'ordinary_A':('A',),'concave_BCDE':tuple('BCDE'),'E_local_bump':('E',)}
    for name in variants:
        data=json.loads((root/'evaluations'/name/'metrics.json').read_text());records[name]=data['records']
        for r in records[name]:
            with np.load(root/'evaluations'/name/(r['case_id']+'.npz')) as z:
                pred=(z['probabilities'].argmax(0)>0)&fov;truth=(z['truth'][0]>.5)&fov
            a=pred^binary_erosion(pred);b=truth^binary_erosion(truth)
            d=np.r_[distance_transform_edt(~a)[b],distance_transform_edt(~b)[a]]*step if a.any() and b.any() else np.array([np.hypot(64,64)*step])
            r['hd95_mm']=float(np.quantile(d,.95));r['boundary_mean_mm']=float(d.mean());r['position_id']=positions[r['case_id']]
        byid[name]={r['case_id']:r for r in records[name]}
    metrics=['foreground_iou','foreground_dice','mean_iou_present_classes','sigma_ssim_10000Hz','sigma_ssim_50000Hz',
             'sigma_nrmse_10000Hz','sigma_nrmse_50000Hz','eps_r_nrmse_10000Hz','eps_r_nrmse_50000Hz','hd95_mm','boundary_mean_mm']
    aggregate={name:{group:{m:float(np.mean([r[m] for r in records[name] if r['shape_class'] in classes])) for m in metrics}
                     for group,classes in groups.items()} for name in variants}
    rng=np.random.default_rng(20261020);paired={}
    for target,base in [('feedback','baseline'),('feedback','no_feedback'),('no_feedback','baseline')]:
        tag=target+' minus '+base;paired[tag]={}
        for group,classes in groups.items():
            ids=[cid for cid,r in byid[target].items() if r['shape_class'] in classes];clusters=sorted({positions[cid] for cid in ids})
            draw=rng.integers(0,len(clusters),(2000,len(clusters)));item={}
            for metric in metrics:
                delta={c:np.array([byid[target][cid][metric]-byid[base][cid][metric] for cid in ids if positions[cid]==c]) for c in clusters}
                sums=np.array([delta[c].sum() for c in clusters]);sizes=np.array([len(delta[c]) for c in clusters])
                boot=sums[draw].sum(1)/sizes[draw].sum(1)
                item[metric]={'mean_difference':float(sums.sum()/sizes.sum()),'position_cluster_95ci':np.quantile(boot,[.025,.975]).tolist(),
                              'position_groups':len(clusters),'case_count':len(ids)}
            paired[tag][group]=item
    phys=json.loads((root/'test_physics.json').read_text())['records'];physics={}
    for name in variants:
        a=np.array([r[name] for r in phys]);b=np.array([r['baseline'] for r in phys])
        physics[name]={'mean_calibrated_voltage_mse_10_50':a.mean(0).tolist(),'fraction_cases_better_than_baseline':float((a.mean(1)<b.mean(1)).mean())}
    summary={'single_seed':True,'seed':p['seed'],'K':1,'test_cases':720,'aggregate':aggregate,'paired':paired,'physics':physics,
             'limitations':['Exploratory evaluation on historically observed test set','Frozen first stage and one learned feedback correction',
                            'Independent rasterized P1 FEM with background anchoring, not exact COMSOL','No end-to-end FEM loss during refiner training',
                            'Bootstrap reflects test position variability, not training-seed uncertainty','E-class metrics are not a dedicated bump recovery score']}
    write(root/'summary_statistics.json',summary);write(root/'per_case_metrics.json',records)
    fig,axes=plt.subplots(1,2,figsize=(10,4.5),constrained_layout=True)
    before=np.array([np.mean(r['baseline']) for r in phys])
    for ax,name in zip(axes,p['variants']):
        after=np.array([np.mean(r[name]) for r in phys]);e=np.array([r['shape_class']=='E' for r in phys])
        ax.scatter(before[~e],after[~e],s=8,alpha=.4,label='A-D');ax.scatter(before[e],after[e],s=12,alpha=.65,label='E')
        lo=max(min(before.min(),after.min())*.7,1e-12);hi=max(before.max(),after.max())*1.4
        ax.plot([lo,hi],[lo,hi],color='gray',lw=.8,label='No change');ax.set_xscale('log');ax.set_yscale('log')
        ax.set_xlim(lo,hi);ax.set_ylim(lo,hi);ax.set_xlabel('Before: calibrated complex voltage MSE')
        ax.set_ylabel('After: calibrated complex voltage MSE');ax.set_title(titles[name],fontsize=10);ax.legend(fontsize=8)
    fig.savefig(root/'voltage_residual_comparison.png',dpi=160);plt.close(fig)
    def draw_cases(ids,filename,zoom=False):
        fig,axes=plt.subplots(len(ids),4,figsize=(12,2.3*len(ids)),squeeze=False,constrained_layout=True)
        for i,cid in enumerate(ids):
            with np.load(root/'evaluations/baseline'/(cid+'.npz')) as z:truth=z['truth'][0]
            axes[i,0].imshow(np.where(fov,truth,np.nan),origin='lower',cmap='gray_r',vmin=0,vmax=1);axes[i,0].set_title(cid+' / Truth',fontsize=9)
            for j,name in enumerate(variants,1):
                with np.load(root/'evaluations'/name/(cid+'.npz')) as z:im=z['probabilities'].argmax(0)>0
                ax=axes[i,j];ax.imshow(np.where(fov,im,np.nan),origin='lower',cmap='gray_r',vmin=0,vmax=1)
                ax.contour(truth,levels=[.5],colors=['red'],linewidths=.6,origin='lower')
                ax.set_title(titles[name]+f'\nIoU={byid[name][cid]["foreground_iou"]:.3f}',fontsize=9)
            for ax in axes[i]:
                ax.set_xticks([]);ax.set_yticks([])
                if zoom:
                    yy,xx=np.where(truth>.5)
                    ax.set_xlim(max(0,xx.min()-5),min(63,xx.max()+5));ax.set_ylim(max(0,yy.min()-5),min(63,yy.max()+5))
        fig.savefig(root/filename,dpi=160);plt.close(fig)
    fixed=[]
    for cls in 'ABCDE':fixed.extend(sorted(cid for cid in byid['baseline'] if cid.startswith(cls+'_'))[:2])
    draw_cases(fixed,'fixed_cases.png')
    eids=sorted((cid for cid in byid['baseline'] if cid.startswith('E_')),key=lambda cid:byid['feedback'][cid]['foreground_iou']-byid['baseline'][cid]['foreground_iou'])
    draw_cases(eids[:3]+eids[-3:],'E_worst_and_best_changes.png',zoom=True)
    # Material comparison uses identical per-row scale, avoiding deceptive color limits.
    fig,axes=plt.subplots(5,4,figsize=(12,12),constrained_layout=True)
    for i,cid in enumerate(fixed[::2]):
        with np.load(root/'evaluations/baseline'/(cid+'.npz')) as z:truth=z['true_sigma'][0]
        images=[truth]
        for name in variants:
            with np.load(root/'evaluations'/name/(cid+'.npz')) as z:images.append(z['sigma'][0])
        lo=min(a[fov].min() for a in images);hi=max(a[fov].max() for a in images)
        for j,im in enumerate(images):
            artist=axes[i,j].imshow(np.where(fov,im,np.nan),origin='lower',vmin=lo,vmax=hi,cmap='viridis')
            axes[i,j].set_title(cid+' / '+(['True sigma 10 kHz']+[titles[n] for n in variants])[j],fontsize=8)
            axes[i,j].set_xticks([]);axes[i,j].set_yticks([])
        fig.colorbar(artist,ax=axes[i,:],shrink=.6,label='S/m')
    fig.savefig(root/'material_comparison.png',dpi=160);plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11,4),constrained_layout=True)
    for name in p['variants']:
        history=json.loads((root/'runs'/name/'history.json').read_text());ep=[h['epoch'] for h in history]
        axes[0].plot(ep,[h['val']['selection_loss'] for h in history],label=titles[name])
        axes[1].plot(ep,[h['val_metrics']['all']['foreground_iou'] for h in history],label=titles[name])
    for ax,label in zip(axes,['Validation selection loss','Validation foreground IoU']):ax.set_xlabel('Epoch');ax.set_ylabel(label);ax.legend(fontsize=8);ax.grid(alpha=.2)
    fig.savefig(root/'training_curves.png',dpi=160);plt.close(fig)
    lines=['# 复数非线性物理反馈：首轮完整数据实验','',
           '固定最终数据：3400 训练 / 720 验证 / 720 测试。基础模型冻结，单种子、一次反馈修正。',
           '对照：原始 V4、真实非线性物理反馈、相同网络但关闭物理残差和伴随提示。','',
           '|模型|IoU|Dice|mean IoU|SSIM 10 kHz|SSIM 50 kHz|HD95 mm|','|---|---:|---:|---:|---:|---:|---:|']
    for name in variants:
        a=aggregate[name]['all'];lines.append('|'+name+'|'+'|'.join(f'{a[m]:.5f}' for m in ['foreground_iou','foreground_dice','mean_iou_present_classes','sigma_ssim_10000Hz','sigma_ssim_50000Hz','hd95_mm'])+'|')
    lines+=['','## 分组及配对差值','', '|比较|组别|IoU差值|位置组 bootstrap 95% CI|','|---|---|---:|---|']
    for pair in paired:
        for group in groups:
            d=paired[pair][group]['foreground_iou'];ci=d['position_cluster_95ci'];lines.append(f'|{pair}|{group}|{d["mean_difference"]:+.5f}|[{ci[0]:+.5f}, {ci[1]:+.5f}]|')
    lines+=['','## 检查点与训练停止','']
    for name in p['variants']:
        d=json.loads((root/'runs'/name/'complete.json').read_text());lines.append(f'- {name}: 训练 {d["epochs"]} 轮，验证选择第 {d["selected_epoch"]} 轮；停止原因 {d["stop_reason"]}。')
    lines+=['','## 限制','']+['- '+s for s in summary['limitations']]
    lines+=['','## 图像','', '- fixed_cases.png：每类按 ID 固定选择的两个病例。',
            '- E_worst_and_best_changes.png：E 类下降最大的三例与提升最大的三例，均公开展示。',
            '- material_comparison.png：共享色标的电导率对照。','- training_curves.png：验证曲线。',
            '- voltage_residual_comparison.png：重新求解后，预测电压对测量电压的残差对照。','',
            '是否有提升必须依据上表，不根据图片挑选模型。若反馈不优于同容量无反馈对照，不能把提升归因于物理反馈。']
    (root/'RESULTS.md').write_text('\n'.join(lines),encoding='utf-8')
    print('REPORT COMPLETE '+str(root),flush=True)

def preview(root):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    root=Path(root);files=sorted((root/'runs'/'feedback').glob('validation_*.npz'))
    if not files:print('No validation preview yet');return
    with np.load(files[-1],allow_pickle=False) as z:
        truth,base,pred,ids=z['truth'],z['base'],z['prediction'],z['case_ids']
    fig,axes=plt.subplots(len(ids),3,figsize=(10,2.2*len(ids)),squeeze=False,constrained_layout=True)
    for i,cid in enumerate(ids):
        for j,(title,im) in enumerate([('Truth',truth[i,0]),('Frozen V4 probability',base[i,0]),('Feedback probability',pred[i,0])]):
            axes[i,j].imshow(im,origin='lower',cmap='gray_r',vmin=0,vmax=1)
            axes[i,j].contour(truth[i,0],levels=[.5],colors=['red'],linewidths=.6,origin='lower')
            axes[i,j].set_title(str(cid)+' / '+title,fontsize=9);axes[i,j].set_xticks([]);axes[i,j].set_yticks([])
    fig.suptitle('Fixed validation cases / '+files[-1].stem+' / not final test results')
    fig.savefig(root/'latest_validation.png',dpi=130);plt.close(fig);print(root/'latest_validation.png')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--preview',action='store_true');a=ap.parse_args()
    preview(Path(a.root)) if a.preview else plot(Path(a.root))
