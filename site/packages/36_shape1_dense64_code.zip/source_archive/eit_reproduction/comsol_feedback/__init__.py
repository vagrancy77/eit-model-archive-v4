"""Nonlinear, dataset-matched physics feedback; separate from frozen V4 runs."""
