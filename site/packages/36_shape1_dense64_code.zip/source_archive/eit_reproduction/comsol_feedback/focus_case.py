"""Render the user's previously discussed case, not selected for improvement."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def main():
    root=Path('E:/Codex/complex_feedback_v1');cid='E_000003'
    with np.load(root/'evaluations/baseline'/(cid+'.npz')) as z:truth=z['truth'][0]>.5
    fig,axes=plt.subplots(1,3,figsize=(11,3.7),constrained_layout=True)
    yy,xx=np.where(truth);panels=[('Truth',truth)]
    for name,title in [('baseline','Original V4'),('feedback','V4 + physics feedback')]:
        records=json.loads((root/'evaluations'/name/'metrics.json').read_text())['records']
        row=next(r for r in records if r['case_id']==cid)
        with np.load(root/'evaluations'/name/(cid+'.npz')) as z:pred=z['probabilities'].argmax(0)>0
        panels.append((title+f' / IoU={row["foreground_iou"]:.4f}',pred))
    for ax,(title,im) in zip(axes,panels):
        ax.imshow(im,origin='lower',cmap='gray_r',vmin=0,vmax=1,interpolation='nearest')
        ax.contour(truth.astype(float),levels=[.5],colors=['red'],linewidths=.8,origin='lower')
        ax.set_xlim(xx.min()-5,xx.max()+5);ax.set_ylim(yy.min()-5,yy.max()+5)
        ax.set_xticks([]);ax.set_yticks([]);ax.set_title(title,fontsize=11)
    fig.suptitle(cid+' / same case as the earlier discussion / red = true boundary',fontsize=11)
    fig.savefig(root/'case_E_000003_comparison.png',dpi=160);plt.close(fig)

if __name__=='__main__':main()
