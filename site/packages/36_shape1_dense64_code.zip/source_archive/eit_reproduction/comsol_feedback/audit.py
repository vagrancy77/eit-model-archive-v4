"""Read-only delivery checks, writing a new audit record beside the experiment."""
import argparse,json
from pathlib import Path
import numpy as np
from comsol_v4.data_v6 import file_hash,FINAL_DATASET_ROOT,load_rows,grid_arrays
from comsol_v4.paper_common import write_json

def audit(root):
    root=Path(root);p=json.loads((root/'protocol.json').read_text());ph=file_hash(root/'protocol.json')
    here=Path(__file__).parent;checks=[]
    for name,digest in p['source_hashes'].items():
        if file_hash(here/name)!=digest:raise ValueError('Training source changed: '+name)
    if file_hash(p['baseline_checkpoint'])!=p['baseline_sha256']:raise ValueError('Baseline checkpoint changed')
    for name in p['variants']:
        d=json.loads((root/'runs'/name/'complete.json').read_text())
        if d['protocol_sha256']!=ph or file_hash(root/'runs'/name/'best.pt')!=d['checkpoint_sha256']:raise ValueError('Frozen checkpoint differs')
        history=json.loads((root/'runs'/name/'history.json').read_text())
        if any(h['train']['processed_cases']!=3400 or h['val']['processed_cases']!=720 for h in history):raise ValueError('Partial epoch')
        checks.append({'variant':name,'trained_epochs':len(history),'selected_epoch':d['selected_epoch']})
    for split in ('train','val','test'):
        done=json.loads((root/'cache'/split/'complete.json').read_text());ids=[r['case_id'] for r in load_rows(FINAL_DATASET_ROOT,split)]
        if done['protocol_sha256']!=ph or done['case_ids']!=ids:raise ValueError('Cache split mismatch')
        for cid in ids:
            with np.load(root/'cache'/split/(cid+'.npz'),allow_pickle=False) as z:
                if z['protocol_sha256'].item()!=ph:raise ValueError('Cache provenance mismatch')
                for field in ('residual','hint','predicted_voltage'):
                    if not np.isfinite(z[field]).all():raise ValueError('Nonfinite cache')
    fov=grid_arrays(FINAL_DATASET_ROOT)[2].astype(bool);ids={r['case_id'] for r in load_rows(FINAL_DATASET_ROOT,'test')}
    count=0
    for name in ['baseline']+p['variants']:
        metrics=json.loads((root/'evaluations'/name/'metrics.json').read_text())
        if metrics['protocol_sha256']!=ph or {r['case_id'] for r in metrics['records']}!=ids:raise ValueError('Test membership/protocol mismatch')
        for r in metrics['records']:
            with np.load(root/'evaluations'/name/(r['case_id']+'.npz'),allow_pickle=False) as z:
                pred=z['probabilities'].argmax(0)>0;gt=z['truth'][0]>.5
                iou=np.sum(pred & gt & fov)/max(np.sum((pred | gt) & fov),1)
                if abs(iou-r['foreground_iou'])>1e-8:raise ValueError('Recomputed IoU mismatch')
                if np.any(z['sigma'][:,fov]<=0) or np.any(z['eps_r'][:,fov]<=0):raise ValueError('Nonpositive material')
                if not np.isfinite(z['sigma']).all() or not np.isfinite(z['eps_r']).all():raise ValueError('Nonfinite prediction')
            count+=1
    for name in ('summary_statistics.json','test_physics.json','RESULTS.md','fixed_cases.png','E_worst_and_best_changes.png','material_comparison.png','training_curves.png'):
        if not (root/name).is_file():raise FileNotFoundError(name)
    report={'status':'PASS','protocol_sha256':ph,'cache_cases_checked':4840,'test_predictions_recomputed':count,'training':checks}
    write_json(root/'delivery_audit.json',report);print(json.dumps(report))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',required=True);a=p.parse_args();audit(Path(a.root))
