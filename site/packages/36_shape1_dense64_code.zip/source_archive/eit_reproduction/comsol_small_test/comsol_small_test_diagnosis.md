# Untitled.mph 电势/电压问题诊断

检查对象：`C:\Users\luandingyu\Desktop\Untitled.mph`

## 已确认的模型设置

- `ec` 物理场只有一个 `Ground`，选择的是边界 `22`（模型中的 E2）。
- 共有 15 个 `Terminal`：E1、E3–E16，选择边界分别为
  `20, 26, 32, 34, 36, 38, 37, 35, 33, 31, 25, 21, 19, 17, 18`。
- 所有这些 Terminal 的类型都是 `Current`，不是 `Voltage`。
- E1 的激励电流为 `1 mA`；E3–E16 的 `I0` 为 `0 A`。
- 参数为：背景 `sig_b=0.50 S/m`，病灶在低频 `sig_l10=0.20 S/m`、高频
  `sig_l50=0.35 S/m`，相对介电常数 `eps_r=80`。
- 材料表达式为：病灶 `if(freq<30[kHz],sig_l10,sig_l50)`，因此频率依赖本身
  是合理的。
- Study 的频率列表是 `range(10[kHz],40[kHz],50[kHz])`，实际是 **10、40、50 kHz**，
  不是只有 10 和 50 kHz。

## 根本问题

你看到的“电压值明显不对”，最可能不是求解器坏了，而是把不同物理量混用了：

1. `V0=1` 是 Terminal 特征的默认参考/初始电压参数，不是当前电流驱动下每个
   电极真正求解得到的电极电位；
2. `I0=1 mA` 只施加在 E1，E3–E16 的零电流端子不会产生各自独立的激励模式；
3. 电极电位应从求解场 `V` 在电极边界上的平均值读取，或使用 COMSOL 的终端
   电压后处理变量，不能直接把 `V0` 列当作测量电压；
4. 如果希望每个电极依次激励，应为每个模式只保留一个正电流端子、一个负电流
   端子（或接地），其余边界设置为电绝缘，然后逐模式求解并导出全部电极电位。

## 已导出的诊断结果

- [诊断报告 JSON](E:/Codex/eit_reproduction/comsol_small_test/Untitled_diagnosis.json)
- [模型端子设置](E:/Codex/eit_reproduction/comsol_small_test/Untitled_terminal_settings.txt)
- [重新求解后的第一个电势图](E:/Codex/eit_reproduction/comsol_small_test/Untitled_potential_solution1.png)
- [重新求解后的第二个电势图](E:/Codex/eit_reproduction/comsol_small_test/Untitled_potential_solution2.png)
- [诊断副本模型](E:/Codex/eit_reproduction/comsol_small_test/Untitled_diagnostic.mph)

重新求解得到的电势场呈现从 E1 电流端到 E2 接地端的连续梯度，月牙病灶边界也
能看到电势梯度变化。这说明模型的场求解是正常的；真正不正确的是端子配置/电压
提取逻辑。

## 推荐的修改顺序

1. 把 Study 改成 `10[kHz] 50[kHz]`；
2. 先只保留 E1 的 `Current` 端子和 E2 的 `Ground`，删除 E3–E16 的零电流
   Terminal；
3. 在 E1/E2 模式求解后，对 16 个电极边界分别做 `aveop` 或边界积分除以边界
   长度，得到真正的 `V_electrode`；
4. 再循环改变正负电流电极，生成 `[frequency, drive_pattern, measurement]`
   的矩阵；
5. 最后再考虑接触阻抗和完整 CEM。

当前组合模型中的电势图不是“完全错误”：图中显示的是一个 1 mA 电流从 E1
流向 E2 的单次正问题解。若你期望的是 16 个电极同时有合理不同的电压，当前
模型并没有定义这样的测量协议。
