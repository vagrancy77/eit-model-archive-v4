import com.comsol.model.*;
import com.comsol.model.physics.*;
import com.comsol.model.util.*;

/** Print the electrical model settings that determine voltage magnitude/shape. */
public class InspectUntitled {
  static void prop(PhysicsFeature f, String key) {
    try { System.out.println("    " + key + " = " + f.getString(key)); return; } catch(Exception e) {}
    try { System.out.println("    " + key + " = " + f.getDouble(key)); return; } catch(Exception e) {}
    try { System.out.println("    " + key + " = " + java.util.Arrays.toString(f.getStringArray(key))); return; } catch(Exception e) {}
    try { System.out.println("    " + key + " = " + java.util.Arrays.toString(f.getDoubleArray(key))); return; } catch(Exception e) {}
    System.out.println("    " + key + " = <unreadable>");
  }
  public static void main(String[] args) throws Exception {
    ModelUtil.initStandalone(true);
    String path=args.length>0?args[0]:"C:\\Users\\luandingyu\\Desktop\\Untitled.mph";
    Model m=ModelUtil.load("u",path);
    String[] geomTags=m.component("comp1").geom().tags();
    System.out.println("MODEL="+path);
    System.out.println("GEOM FEATURES="+java.util.Arrays.toString(m.component("comp1").geom("geom1").feature().tags()));
    System.out.println("PHYSICS="+java.util.Arrays.toString(m.component("comp1").physics().tags()));
    Physics ec=m.component("comp1").physics("ec");
    for(String tag:ec.feature().tags()) {
      PhysicsFeature f=ec.feature(tag);
      System.out.println("FEATURE "+tag+" type="+f.getType());
      try { System.out.println("  selection dim1="+java.util.Arrays.toString(f.selection().entities(1))); } catch(Exception e) { System.out.println("  selection unavailable"); }
      for(String key:new String[]{"TerminalName","TerminalType","V0","I0","P0","I","Q0scal","sigma","epsilonr","StudyStep","constraintType","constraintMethod","rhos","ds","Csr"}) prop(f,key);
    }
    for(String tag:m.component("comp1").material().tags()) {
      Material mat=m.component("comp1").material(tag); System.out.println("MATERIAL "+tag+" domains="+java.util.Arrays.toString(mat.selection().entities(2)));
      for(String pg:m.component("comp1").material(tag).propertyGroup().tags()) {
        Object g=mat.propertyGroup(pg); System.out.println("  GROUP "+pg+"="+g.toString());
      }
    }
    for(String st:m.study().tags()) {
      Study s=m.study(st); System.out.println("STUDY "+st+" FEATURES="+java.util.Arrays.toString(s.feature().tags()));
      for(String ft:s.feature().tags()) { StudyFeature sf=s.feature(ft); System.out.println("  STEP "+ft+" type="+sf.getType()); for(String key:new String[]{"plist","plistarr","punit","solnum","studystep"}) { try{System.out.println("    "+key+"="+sf.getString(key));}catch(Exception e){}} }
    }
    for(String mesh:m.component("comp1").mesh().tags()) { MeshSequence ms=m.component("comp1").mesh(mesh); System.out.println("MESH "+mesh+" features="+java.util.Arrays.toString(ms.feature().tags())); }
    ModelUtil.clear();
  }
}
