import com.comsol.model.*;
import com.comsol.model.util.*;

public class InspectModel {
    public static void main(String[] args) throws Exception {
        ModelUtil.initStandalone(true);
        String path = args.length > 0 ? args[0] : "E:\\Codex\\comsol_small_test_crescent_eit.mph";
        Model m = ModelUtil.load("m", path);
        System.out.println("components=" + java.util.Arrays.toString(m.component().tags()));
        for (String c : m.component().tags()) {
            System.out.println("comp=" + c + " geoms=" + java.util.Arrays.toString(m.component(c).geom().tags()));
            for (String g : m.component(c).geom().tags()) {
                System.out.println("geom " + g + " features=" + java.util.Arrays.toString(m.component(c).geom(g).feature().tags()));
                System.out.println("geom dim=" + m.component(c).geom(g).getSDim() + " type=" + m.component(c).geom(g).getType());
                int[][] ud = m.component(c).geom(g).getUpDown();
                for (int b=0; b<ud[0].length; b++) System.out.println("  bnd="+(b+1)+" up="+ud[0][b]+" down="+ud[1][b]);
            }
            System.out.println("phys=" + java.util.Arrays.toString(m.component(c).physics().tags()));
            for (String p : m.component(c).physics().tags()) {
                System.out.println("phys " + p + " features=" + java.util.Arrays.toString(m.component(c).physics(p).feature().tags()));
                for (String f : m.component(c).physics(p).feature().tags()) {
                    System.out.println("  feature " + f + " type=" + m.component(c).physics(p).feature(f).getType() + " props=" + java.util.Arrays.toString(m.component(c).physics(p).feature(f).properties()));
                }
            }
            System.out.println("mats=" + java.util.Arrays.toString(m.component(c).material().tags()));
            for (String ma : m.component(c).material().tags()) {
                System.out.println("mat " + ma + " features=" + java.util.Arrays.toString(m.component(c).material(ma).propertyGroup().tags()));
            }
            System.out.println("meshes=" + java.util.Arrays.toString(m.component(c).mesh().tags()));
        }
        System.out.println("studies=" + java.util.Arrays.toString(m.study().tags()));
        for (String s : m.study().tags()) System.out.println("study " + s + " features=" + java.util.Arrays.toString(m.study(s).feature().tags()));
        System.out.println("results=" + java.util.Arrays.toString(m.result().tags()));
    }
}
