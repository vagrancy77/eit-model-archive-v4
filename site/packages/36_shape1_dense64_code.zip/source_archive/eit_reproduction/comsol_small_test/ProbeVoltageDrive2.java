import com.comsol.model.*; import com.comsol.model.physics.*; import com.comsol.model.util.*;
public class ProbeVoltageDrive2 { public static void main(String[] a)throws Exception{
 ModelUtil.initStandalone(true); String p=a.length>0?a[0]:"E:\\Codex\\eit_reproduction\\comsol_small_test\\comsol_small_test_crescent_eit.mph"; Model m=ModelUtil.load("m",p); Physics ec=m.component("comp1").physics("ec");
 ec.feature("pot1").selection().set(new int[]{}); ec.feature("gnd1").selection().set(new int[]{});
 PhysicsFeature term=ec.feature().create("term0","Terminal",1);term.selection().set(new int[]{1});term.set("TerminalName","drive");term.set("TerminalType","Voltage");term.set("V0","1[V]");
 PhysicsFeature g=ec.feature().create("gnd0","Ground",1);g.selection().set(new int[]{15});
 System.out.println("before solve"); m.study("std1").run(); System.out.println("solved");
 m.result().numerical().create("ip","Interp");m.result().numerical("ip").set("expr",new String[]{"V"});double[][]xy=new double[2][16];for(int k=0;k<16;k++){double a0=2*Math.PI*(k+.5)/16;xy[0][k]=.995*Math.cos(a0);xy[1][k]=.995*Math.sin(a0);}m.result().numerical("ip").setInterpolationCoordinates(xy);double[][][]d=m.result().numerical("ip").getData();for(int k=0;k<16;k++)System.out.println((k+1)+" "+d[0][0][k]);
 }}
