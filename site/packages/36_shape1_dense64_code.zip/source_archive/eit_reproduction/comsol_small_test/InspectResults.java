import com.comsol.model.*;
import com.comsol.model.util.*;

public class InspectResults {
  static void tryS(ResultFeature f,String k){try{System.out.println("    "+k+"="+f.getString(k));}catch(Exception e){}}
  public static void main(String[] args)throws Exception{
    ModelUtil.initStandalone(true); String p=args.length>0?args[0]:"C:\\Users\\luandingyu\\Desktop\\Untitled.mph";
    Model m=ModelUtil.load("r",p); System.out.println("datasets="+java.util.Arrays.toString(m.result().dataset().tags()));
    for(String d:m.result().dataset().tags()){ResultFeature f=m.result().dataset(d);System.out.println("DATA "+d+" type="+f.getType()+" props="+java.util.Arrays.toString(f.properties())); for(String k:new String[]{"solution","studies","study","solnum","level","data","outersolnum","innerinput"})tryS(f,k);}
    System.out.println("plots="+java.util.Arrays.toString(m.result().feature().tags()));
    for(String x:m.result().feature().tags()){ResultFeature f=m.result().feature(x);System.out.println("PLOT "+x+" type="+f.getType()+" props="+java.util.Arrays.toString(f.properties())); for(String k:new String[]{"expr","descr","data","colortable","resolution","title","unit","looplevel","solnum"})tryS(f,k); for(String ch:f.feature().tags()){ResultFeature q=f.feature(ch);System.out.println("  CHILD "+ch+" type="+q.getType()+" props="+java.util.Arrays.toString(q.properties())); for(String k:new String[]{"expr","descr","data","colortable","resolution","title","unit","looplevel","solnum"})tryS(q,k);}}
    // solve and evaluate common global terminal variables
    try{m.study("std1").run();System.out.println("SOLVED");}catch(Exception e){System.out.println("SOLVE_ERROR "+e);}
    String[] expr={"V","ec.V0","ec.I0","ec.I","ec.Jx","ec.Jy","ec.normJ"};
    for(String e:expr){try{Numerical n=m.result().numerical().create("tmp"+Math.abs(e.hashCode()),"EvalGlobal");n.set("expr",new String[]{e});double[][] z=n.getData();System.out.println("EVAL "+e+" rows="+z.length+" cols="+(z.length>0?z[0].length:0)+" first="+(z.length>0?java.util.Arrays.toString(z[0]):"[]"));n.remove();}catch(Exception ex){System.out.println("EVAL_FAIL "+e+" "+ex.getMessage());}}
    ModelUtil.clear();
  }
}
