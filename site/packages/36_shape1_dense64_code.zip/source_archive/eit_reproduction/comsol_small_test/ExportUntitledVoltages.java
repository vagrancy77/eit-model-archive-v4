import com.comsol.model.*;
import com.comsol.model.util.*;

/** Export potential at the centers of the 16 outer electrode arcs. */
public class ExportUntitledVoltages {
  public static void main(String[] args)throws Exception {
    ModelUtil.initStandalone(true);
    String in=args.length>0?args[0]:"C:\\Users\\luandingyu\\Desktop\\Untitled.mph";
    String out=args.length>1?args[1]:"E:\\Codex\\eit_reproduction\\comsol_small_test\\Untitled_electrode_potential.csv";
    Model m=ModelUtil.load("v",in);
    try {m.study("std1").run();} catch(Exception e){System.out.println("solve "+e);}
    // Actual outer arc boundary IDs in this model, clockwise from top-ish order.
    int[] b={17,18,19,20,21,22,25,26,31,32,33,34,35,36,37,38};
    // Sample at a point just inside each segment; angles are chosen from the
    // midpoint of the 16 equally spaced arcs, starting at +x and CCW.
    double[][] xy=new double[2][16];
    for(int k=0;k<16;k++){double a=2*Math.PI*(k+0.5)/16.;xy[0][k]=.999*Math.cos(a);xy[1][k]=.999*Math.sin(a);}
    m.result().numerical().create("ipV","Interp");
    m.result().numerical("ipV").set("expr",new String[]{"V"});
    m.result().numerical("ipV").setInterpolationCoordinates(xy);
    double[][][] d=m.result().numerical("ipV").getData();
    java.io.PrintWriter pw=new java.io.PrintWriter(out);
    pw.println("electrode,outer_boundary_id,angle_deg,V_solution1,V_solution2,V_solution3");
    for(int k=0;k<16;k++){
      double a=360.*(k+.5)/16.; double v1=d[0][0][k]; double v2=d[0].length>1?d[0][1][k]:Double.NaN; double v3=d[0].length>2?d[0][2][k]:Double.NaN;
      pw.println((k+1)+","+b[k]+","+a+","+v1+","+v2+","+v3);
      System.out.println("E"+(k+1)+" b="+b[k]+" angle="+a+" V="+v1+"/"+v2+"/"+v3);
    }
    pw.close();
    // Print the potential at a coarse interior cross section to expose scale.
    System.out.println("interp dims "+d.length+"x"+d[0].length+"x"+d[0][0].length);
    ModelUtil.clear(); System.exit(0);
  }
}
