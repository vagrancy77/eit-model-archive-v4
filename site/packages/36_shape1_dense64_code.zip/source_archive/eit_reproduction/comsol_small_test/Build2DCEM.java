import com.comsol.model.*;
import com.comsol.model.physics.*;
import com.comsol.model.util.*;

/**
 * Optional strict-boundary smoke test.  It reuses the crescent geometry from
 * comsol_small_test_crescent_eit.mph and replaces the single ElectricPotential
 * boundary with one current Terminal, one Ground, and FloatingPotential on the
 * remaining outer arcs.  This is an ideal-electrode CEM smoke test; contact
 * impedance is intentionally left for the next validated step.
 */
public class Build2DCEM {
    private static final String DIR = "E:\\Codex\\eit_reproduction\\comsol_small_test\\";
    private static final int[] OUTER = {1,2,3,4,5,6,9,10,15,16,19,20,21,22,23,24};

    public static void main(String[] args) throws Exception {
        ModelUtil.initStandalone(true);
        Model m = ModelUtil.load("m", DIR + "comsol_small_test_crescent_eit.mph");
        Physics ec = m.component("comp1").physics("ec");
        try { ec.feature().remove("pot1"); } catch (Exception ignored) {}
        try { ec.feature().remove("gnd1"); } catch (Exception ignored) {}

        PhysicsFeature term = ec.feature().create("term1", "Terminal", 1);
        term.selection().set(new int[]{OUTER[0]});
        term.set("TerminalName", "1");
        term.set("TerminalType", "Current");
        term.set("I0", "1[mA]");

        PhysicsFeature gnd = ec.feature().create("gnd1", "Ground", 1);
        gnd.selection().set(new int[]{OUTER[8]});

        int[] floating = new int[OUTER.length - 2];
        int j = 0;
        for (int b : OUTER) if (b != OUTER[0] && b != OUTER[8]) floating[j++] = b;
        PhysicsFeature fp = ec.feature().create("fp1", "FloatingPotential", 1);
        fp.selection().set(floating);

        System.out.println("CEM boundary selections: terminal=" + OUTER[0] +
                " ground=" + OUTER[8] + " floating=" + floating.length);
        m.study("std1").run();
        System.out.println("CEM study solved");

        m.result().numerical().create("intCEM", "Interp");
        m.result().numerical("intCEM").set("expr", new String[]{"V"});
        double[][] xy = new double[2][16];
        for (int k = 0; k < 16; k++) {
            double a = 2.0*Math.PI*(k+0.5)/16.0;
            xy[0][k] = 0.995*Math.cos(a); xy[1][k] = 0.995*Math.sin(a);
        }
        m.result().numerical("intCEM").setInterpolationCoordinates(xy);
        double[][][] dat = m.result().numerical("intCEM").getData();
        java.io.PrintWriter pw = new java.io.PrintWriter(DIR + "comsol_small_test_cem_ideal_voltage.csv");
        pw.println("electrode,V_10kHz,V_50kHz");
        for (int k = 0; k < 16; k++) {
            double v10 = dat[0][0][k];
            double v50 = dat[0][1][k];
            pw.println((k+1)+","+v10+","+v50);
            System.out.println("E"+(k+1)+" V10="+v10+" V50="+v50);
        }
        pw.close();
        m.save(DIR + "comsol_small_test_crescent_cem_ideal.mph");
        System.out.println("CEM model saved");
        ModelUtil.clear();
        System.out.println("done");
    }
}
