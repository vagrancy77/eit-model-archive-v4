"""Compare the user's Untitled.mph exports against the reference sample geometry.

This does not alter the COMSOL model. It reports matrix/field ranges and writes a
side-by-side plot if a potential CSV/NPZ export is available.
"""
from pathlib import Path
import csv, json
import numpy as np

ROOT = Path(__file__).resolve().parent

def read_csv_numbers(path):
    rows=[]
    with path.open(errors="ignore") as f:
        for line in f:
            if line.lstrip().startswith("%") or not line.strip(): continue
            try: rows.append([float(x) for x in line.strip().split(",")])
            except ValueError: continue
    return np.asarray(rows)

def main():
    report = {"reference": {}, "user_model_diagnosis": {}}
    ref = np.load(ROOT / "eit_voltage_matrix.npz")["voltage"]
    report["reference"] = {"shape": list(ref.shape), "min_V": float(ref.min()), "max_V": float(ref.max()), "range_V": float(ref.max()-ref.min())}
    term = ROOT / "Untitled_terminal_settings.txt"
    if term.exists():
        lines = [x.strip() for x in term.read_text(errors="ignore").splitlines() if x.strip()]
        report["user_model_diagnosis"]["terminal_lines"] = lines[1:]
        report["user_model_diagnosis"]["terminal_count"] = sum(",Terminal," in x for x in lines)
        report["user_model_diagnosis"]["current_terminal_count"] = sum(",Terminal," in x and ",Current," in x for x in lines)
        report["user_model_diagnosis"]["ground_count"] = sum(",Ground," in x for x in lines)
    report["interpretation"] = [
      "The user's file uses current terminals: E1 is the only terminal with a nonzero I0 in the COMSOL GUI export, while E3-E16 show I0=0 A.",
      "One ground is present (E2 boundary in the user's naming), so the resulting field is a single current-drive solution, not 16 simultaneous voltage-driven electrodes.",
      "The study plist is range(10[kHz],40[kHz],50[kHz]), i.e. 10, 40 and 50 kHz, not just 10 and 50 kHz.",
      "To obtain electrode voltages, evaluate V on each electrode boundary (or terminal voltage variables), not the Terminal feature parameter V0."
    ]
    out=ROOT/"Untitled_diagnosis.json"; out.write_text(json.dumps(report,indent=2),encoding="utf-8")
    print(json.dumps(report,indent=2,ensure_ascii=False)); print("saved",out)

if __name__ == "__main__": main()
