$ErrorActionPreference = 'Stop'
$py = 'C:\Users\luandingyu\AppData\Local\Programs\Python\Python313\python.exe'
& $py 'E:\Codex\eit_reproduction\comsol_small_test\assemble_eit_matrix.py'
& $py 'E:\Codex\eit_reproduction\comsol_small_test\make_eit_us_preview.py'
