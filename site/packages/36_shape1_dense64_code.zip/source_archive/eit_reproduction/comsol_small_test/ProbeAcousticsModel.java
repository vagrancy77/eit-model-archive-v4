import com.comsol.model.*; import com.comsol.model.physics.*; import com.comsol.model.util.*;
public class ProbeAcousticsModel { public static void main(String[] a)throws Exception{
 ModelUtil.initStandalone(true); Model m=ModelUtil.load("m",a.length>0?a[0]:"E:\\Codex\\eit_reproduction\\comsol_small_test\\comsol_small_test_crescent_eit.mph");
 Physics ac=m.component("comp1").physics().create("acpr","PressureAcoustics","geom1");
 System.out.println("tags="+java.util.Arrays.toString(ac.feature().tags()));
 for(String t:ac.feature().tags()){PhysicsFeature f=ac.feature(t);System.out.println(t+" type="+f.getType()+" props="+java.util.Arrays.toString(f.properties())); try{System.out.println(" bnd="+java.util.Arrays.toString(f.selection().entities(1)));}catch(Exception e){}}
 ModelUtil.clear();
}}
