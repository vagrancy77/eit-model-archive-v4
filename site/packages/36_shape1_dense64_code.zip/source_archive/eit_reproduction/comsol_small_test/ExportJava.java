import com.comsol.model.*;
import com.comsol.model.util.*;

public class ExportJava {
    public static void main(String[] args) throws Exception {
        ModelUtil.initStandalone(true);
        String in = args.length > 0 ? args[0] : "C:\\Users\\luandingyu\\Desktop\\Untitled.mph";
        String out = args.length > 1 ? args[1] : "E:\\Codex\\eit_reproduction\\comsol_small_test\\Untitled_export.java";
        Model m = ModelUtil.load("m", in);
        try {
            m.save(out);
            System.out.println("saved");
        } catch (Exception e) {
            System.out.println("save exception: " + e);
        }
    }
}
