"""Package one paired COMSOL EIT + ultrasound sample for downstream learning.

The COMSOL acoustic export contains values on an unstructured set of mesh
nodes.  This script preserves that raw export and additionally creates a
regular 128 x 128 tensor using inverse-distance interpolation.  The analytic
crescent mask is generated on exactly the same grid, so EIT, ultrasound, and
ground truth remain spatially paired.
"""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.spatial import cKDTree


ROOT = Path(__file__).resolve().parent
GRID_N = 128
RADIUS = 1.0


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def load_acoustic_nodes(path: Path) -> np.ndarray:
    """Read numeric x,y,real(p),imag(p),abs(p) rows from COMSOL CSV."""
    rows: list[list[float]] = []
    with path.open("r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            if not line.strip() or line.lstrip().startswith("%"):
                continue
            try:
                vals = [float(v.strip()) for v in line.split(",")]
            except ValueError:
                continue
            if len(vals) >= 5:
                rows.append(vals[:5])
    arr = np.asarray(rows, dtype=np.float64)
    if arr.ndim != 2 or arr.shape[1] != 5 or len(arr) == 0:
        raise RuntimeError(f"No acoustic samples found in {path}")
    return arr


def idw_grid(nodes: np.ndarray, xx: np.ndarray, yy: np.ndarray, k: int = 8) -> np.ndarray:
    """Inverse-distance interpolation from mesh nodes to a regular grid."""
    xy = nodes[:, :2]
    tree = cKDTree(xy)
    query = np.column_stack((xx.ravel(), yy.ravel()))
    dist, idx = tree.query(query, k=k, workers=-1)
    dist = np.maximum(np.asarray(dist), 1.0e-12)
    weights = 1.0 / dist
    weights /= weights.sum(axis=1, keepdims=True)
    out = (weights * nodes[idx, 2]).sum(axis=1)
    return out.reshape(xx.shape)


def crescent_mask(xx: np.ndarray, yy: np.ndarray) -> np.ndarray:
    """Analytic outer-ellipse minus inner-ellipse lesion used in COMSOL."""
    outer = ((xx + 0.10) / 0.30) ** 2 + ((yy - 0.05) / 0.20) ** 2 <= 1.0
    inner = ((xx - 0.03) / 0.24) ** 2 + ((yy - 0.05) / 0.145) ** 2 <= 1.0
    return outer & ~inner


def main() -> None:
    eit_path = ROOT / "eit_voltage_matrix.npz"
    us_path = ROOT / "ultrasound_pressure_mesh.csv"
    eit = np.load(eit_path)
    voltage = np.asarray(eit["voltage"], dtype=np.float64)
    frequencies = np.asarray(eit["frequencies_hz"], dtype=np.float64)
    nodes = load_acoustic_nodes(us_path)

    axis = np.linspace(-RADIUS, RADIUS, GRID_N, dtype=np.float64)
    xx, yy = np.meshgrid(axis, axis, indexing="xy")
    valid = xx**2 + yy**2 <= RADIUS**2
    p_real = idw_grid(nodes, xx, yy)
    # The current pressure export is real-valued, but retain a complex channel
    # so later COMSOL runs with non-zero imaginary pressure use the same format.
    p_imag = idw_grid(np.column_stack((nodes[:, :2], nodes[:, 3], nodes[:, 4])), xx, yy)
    p_abs = np.hypot(p_real, p_imag)
    phase = np.arctan2(p_imag, p_real)
    for arr in (p_real, p_imag, p_abs, phase):
        arr[~valid] = np.nan
    lesion = crescent_mask(xx, yy) & valid
    conductivity = np.where(lesion, 1.0, 0.5).astype(np.float32)

    grid_npz = ROOT / "ultrasound_pressure_grid.npz"
    np.savez_compressed(
        grid_npz,
        x=axis,
        y=axis,
        pressure_real=p_real.astype(np.float32),
        pressure_imag=p_imag.astype(np.float32),
        pressure_abs=p_abs.astype(np.float32),
        pressure_phase=phase.astype(np.float32),
        valid_mask=valid,
        lesion_mask=lesion,
        conductivity_S_per_m=conductivity,
        frequency_hz=np.array(50000.0),
    )
    np.save(ROOT / "lesion_mask_grid.npy", lesion)
    np.save(ROOT / "conductivity_grid_S_per_m.npy", conductivity)

    # One-file representation for a PyTorch Dataset or a quick np.load call.
    pair_npz = ROOT / "sample_pair_eit_us.npz"
    np.savez_compressed(
        pair_npz,
        eit_voltage=voltage.astype(np.float32),
        eit_frequencies_hz=frequencies.astype(np.float32),
        ultrasound_pressure_real=p_real.astype(np.float32),
        ultrasound_pressure_imag=p_imag.astype(np.float32),
        ultrasound_pressure_abs=p_abs.astype(np.float32),
        ultrasound_pressure_phase=phase.astype(np.float32),
        x=axis.astype(np.float32),
        y=axis.astype(np.float32),
        valid_mask=valid,
        lesion_mask=lesion,
        conductivity_S_per_m=conductivity,
        ultrasound_frequency_hz=np.array(50000.0, dtype=np.float32),
    )

    # Human-readable regular-grid CSV (one row per pixel).
    grid_csv = ROOT / "ultrasound_pressure_grid.csv"
    with grid_csv.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["x_m", "y_m", "pressure_real_Pa", "pressure_imag_Pa", "pressure_abs_Pa", "pressure_phase_rad", "valid", "lesion"])
        for j in range(GRID_N):
            for i in range(GRID_N):
                w.writerow([
                    f"{xx[j, i]:.8g}", f"{yy[j, i]:.8g}",
                    f"{p_real[j, i]:.8g}", f"{p_imag[j, i]:.8g}",
                    f"{p_abs[j, i]:.8g}", f"{phase[j, i]:.8g}",
                    int(valid[j, i]), int(lesion[j, i]),
                ])

    # QA figure: geometry/ground truth and the paired fields in one coordinate frame.
    fig, ax = plt.subplots(2, 3, figsize=(14, 8), constrained_layout=True)
    extent = [-RADIUS, RADIUS, -RADIUS, RADIUS]
    im = ax[0, 0].imshow(lesion, origin="lower", extent=extent, cmap="gray_r", vmin=0, vmax=1)
    ax[0, 0].set_title("Ground-truth crescent mask")
    ax[0, 0].set_xlabel("x (m)"); ax[0, 0].set_ylabel("y (m)")
    im = ax[0, 1].imshow(p_abs, origin="lower", extent=extent, cmap="magma")
    ax[0, 1].contour(xx, yy, lesion.astype(float), levels=[0.5], colors="cyan", linewidths=1.0)
    ax[0, 1].set_title("Ultrasound |p| at 50 kHz")
    ax[0, 1].set_xlabel("x (m)"); ax[0, 1].set_ylabel("y (m)"); fig.colorbar(im, ax=ax[0, 1], label="Pa")
    im = ax[0, 2].imshow(p_real, origin="lower", extent=extent, cmap="RdBu_r")
    ax[0, 2].contour(xx, yy, lesion.astype(float), levels=[0.5], colors="black", linewidths=1.0)
    ax[0, 2].set_title("Ultrasound real pressure")
    ax[0, 2].set_xlabel("x (m)"); ax[0, 2].set_ylabel("y (m)"); fig.colorbar(im, ax=ax[0, 2], label="Pa")
    for row, f_hz in enumerate(frequencies):
        im = ax[1, row].imshow(voltage[row], origin="lower", aspect="auto", cmap="viridis")
        ax[1, row].set_title(f"EIT voltage matrix ({f_hz/1000:g} kHz)")
        ax[1, row].set_xlabel("measurement electrode"); ax[1, row].set_ylabel("drive pattern")
        fig.colorbar(im, ax=ax[1, row], fraction=0.046)
    ax[1, 2].axis("off")
    fig.suptitle("Paired COMSOL sample: EIT + ultrasound + lesion truth", fontsize=15)
    preview = ROOT / "sample_eit_us_complete_preview.png"
    fig.savefig(preview, dpi=180)
    plt.close(fig)

    manifest = {
        "sample_id": "crescent_001",
        "generator": "COMSOL Multiphysics 6.3.0.290",
        "geometry": {
            "domain": "2-D unit circle",
            "radius_m": RADIUS,
            "lesion": "outer ellipse minus inner ellipse",
            "outer_ellipse": {"center_m": [-0.10, 0.05], "semi_axes_m": [0.30, 0.20]},
            "inner_cutout": {"center_m": [0.03, 0.05], "semi_axes_m": [0.24, 0.145]},
            "electrodes": 16,
        },
        "eit": {
            "raw_matrix": "eit_voltage_matrix.npz",
            "csv_matrix": "eit_voltage_matrix.csv",
            "matrix_shape": list(voltage.shape),
            "axis_order": ["frequency", "drive_pattern", "measurement_electrode"],
            "frequencies_hz": frequencies.astype(int).tolist(),
            "protocol": "1 V ideal voltage terminal on electrode i; adjacent electrode i+1 grounded; other boundaries insulated",
            "electrode_boundary_ids": [1, 2, 3, 4, 5, 6, 9, 10, 15, 16, 19, 20, 21, 22, 23, 24],
            "background_conductivity_S_per_m": 0.5,
            "lesion_conductivity_S_per_m": 1.0,
            "contact_impedance_included": False,
            "strict_cem": False,
        },
        "ultrasound": {
            "raw_mesh_csv": "ultrasound_pressure_mesh.csv",
            "regular_grid_npz": "ultrasound_pressure_grid.npz",
            "regular_grid_csv": "ultrasound_pressure_grid.csv",
            "grid_shape": [GRID_N, GRID_N],
            "frequency_hz": 50000,
            "channels": ["pressure_real_Pa", "pressure_imag_Pa", "pressure_abs_Pa", "pressure_phase_rad"],
            "background": {"density_kg_per_m3": 1000, "sound_speed_m_per_s": 1500},
            "lesion": {"density_kg_per_m3": 1050, "sound_speed_m_per_s": 1560},
            "excitation": "1 Pa pressure on boundary arc 1",
            "raw_mesh_node_count": int(len(nodes)),
            "regular_grid_interpolation": "8-nearest inverse-distance weighting",
        },
        "ground_truth": {"lesion_mask_grid": "lesion_mask_grid.npy", "mask_shape": [GRID_N, GRID_N]},
        "conductivity_ground_truth": {
            "file": "conductivity_grid_S_per_m.npy",
            "shape": [GRID_N, GRID_N],
            "background_S_per_m": 0.5,
            "lesion_S_per_m": 1.0,
        },
        "single_file_pair": {
            "file": "sample_pair_eit_us.npz",
            "description": "EIT voltage + ultrasound channels + coordinates + masks + conductivity in one NPZ",
        },
        "preview": "sample_eit_us_complete_preview.png",
        "files": {
            name: {"bytes": p.stat().st_size, "sha256": sha256(p)}
            for name, p in {
                "eit_voltage_matrix.npz": eit_path,
                "ultrasound_pressure_mesh.csv": us_path,
                "ultrasound_pressure_grid.npz": grid_npz,
                "lesion_mask_grid.npy": ROOT / "lesion_mask_grid.npy",
                "conductivity_grid_S_per_m.npy": ROOT / "conductivity_grid_S_per_m.npy",
                "sample_pair_eit_us.npz": pair_npz,
            }.items()
        },
        "limitations": [
            "EIT is a 16-pattern ideal voltage-drive sanity dataset, not a clinical current-drive contact-impedance CEM acquisition.",
            "The current material conductivities are frequency independent, so 10 kHz and 50 kHz EIT matrices are numerically almost identical.",
            "The ultrasound field is a 50 kHz pressure-acoustics simulation; its analytic lesion mask is supplied for pairing and evaluation.",
        ],
    }
    (ROOT / "sample_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps({"grid": list(p_abs.shape), "raw_nodes": len(nodes), "lesion_pixels": int(lesion.sum()), "preview": str(preview), "manifest": str(ROOT / 'sample_manifest.json')}, indent=2))


if __name__ == "__main__":
    main()
