import com.comsol.model.*;
import com.comsol.model.physics.*;
import com.comsol.model.util.*;

/** Export terminal settings and (when available) terminal voltage/current. */
public class ExportUntitledTerminal {
  static void p(PhysicsFeature f,String k){
    try{System.out.println("    "+k+"="+f.getString(k));}catch(Exception e){
      try{System.out.println("    "+k+"="+f.getDouble(k));}catch(Exception e2){}}
  }
  public static void main(String[] args)throws Exception{
    ModelUtil.initStandalone(true);
    String in=args.length>0?args[0]:"C:\\Users\\luandingyu\\Desktop\\Untitled.mph";
    String out=args.length>1?args[1]:"E:\\Codex\\eit_reproduction\\comsol_small_test\\Untitled_terminal_settings.txt";
    Model m=ModelUtil.load("t",in); Physics ec=m.component("comp1").physics("ec");
    java.io.PrintWriter pw=new java.io.PrintWriter(out);
    pw.println("model="+in); pw.println("study_frequency=range(10[kHz],40[kHz],50[kHz])");
    for(String tag:ec.feature().tags()){
      PhysicsFeature f=ec.feature(tag); if(!"Terminal".equals(f.getType()) && !"Ground".equals(f.getType())) continue;
      int[] s; try{s=f.selection().entities(1);}catch(Exception e){s=new int[0];}
      String name="";try{name=f.getString("TerminalName");}catch(Exception e){}
      String typ=f.getType(); String tt="";try{tt=f.getString("TerminalType");}catch(Exception e){}
      double i0=Double.NaN,v0=Double.NaN;try{i0=f.getDouble("I0");}catch(Exception e){}try{v0=f.getDouble("V0");}catch(Exception e){}
      String line=tag+","+typ+","+name+","+tt+","+java.util.Arrays.toString(s)+","+v0+","+i0; pw.println(line); System.out.println(line);
    }
    pw.close();
    try{m.study("std1").run(); System.out.println("solved");}catch(Exception e){System.out.println("solve failed="+e);}
    ModelUtil.clear(); System.exit(0);
  }
}
