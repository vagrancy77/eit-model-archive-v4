import com.comsol.model.*;
import com.comsol.model.physics.*;
import com.comsol.model.util.*;

/**
 * Generate one paired EIT + ultrasound sample on the crescent geometry.
 *
 * EIT: 16 voltage-drive / ground patterns (adjacent boundary arcs), with
 * 16 boundary-interior voltage samples at 10 and 50 kHz.
 * Ultrasound: 2-D pressure-acoustics frequency-domain field at 50 kHz on the
 * same mesh and the same two-domain material geometry.
 */
public class BuildEITUSGroup {
    private static final String DIR = "E:\\Codex\\eit_reproduction\\comsol_small_test\\";
    private static final String BASE = DIR + "comsol_small_test_crescent_eit.mph";
    private static final int[] OUTER = {1,2,3,4,5,6,9,10,15,16,19,20,21,22,23,24};
    private static final int N = 16;
    private static final int GRID = 81;

    private static int[] except(int a, int b) {
        int[] x = new int[N-2]; int j = 0;
        for (int q : OUTER) if (q != a && q != b) x[j++] = q;
        return x;
    }

    private static double[][] ringCoordinates() {
        double[][] xy = new double[2][N];
        for (int k=0; k<N; k++) {
            double a = 2.0*Math.PI*(k+0.5)/N;
            xy[0][k] = 0.995*Math.cos(a);
            xy[1][k] = 0.995*Math.sin(a);
        }
        return xy;
    }

    private static void writeEitCsv(double[][][] eit) throws Exception {
        java.io.PrintWriter pw = new java.io.PrintWriter(DIR + "eit_voltage_matrix.csv");
        pw.println("drive_electrode,ground_electrode,measurement_electrode,V_10kHz,V_50kHz");
        for (int d=0; d<N; d++) for (int q=0; q<N; q++)
            pw.println((d+1)+","+(((d+1)%N)+1)+","+(q+1)+","+eit[0][d][q]+","+eit[1][d][q]);
        pw.close();
    }

    private static void writeMetadata() throws Exception {
        java.io.PrintWriter pw = new java.io.PrintWriter(DIR + "sample_metadata.json");
        pw.println("{");
        pw.println("  \"sample_id\": \"crescent_001\",");
        pw.println("  \"geometry\": \"unit circle with crescent lesion (ellipse difference)\",");
        pw.println("  \"electrodes\": 16,");
        pw.println("  \"eit_drive\": \"voltage terminal 1 V on arc i, ground on adjacent arc i+1\",");
        pw.println("  \"eit_frequencies_hz\": [10000, 50000],");
        pw.println("  \"eit_voltage_shape\": [2, 16, 16],");
        pw.println("  \"ultrasound\": \"2-D Pressure Acoustics, frequency domain\",");
        pw.println("  \"ultrasound_frequency_hz\": 50000,");
        pw.println("  \"ultrasound_source\": \"1 Pa pressure on drive-electrode arc 1\",");
        pw.println("  \"ultrasound_grid\": [81, 81],");
        pw.println("  \"units\": {\"length\": \"m\", \"conductivity\": \"S/m\", \"voltage\": \"V\", \"pressure\": \"Pa\"},");
        pw.println("  \"note\": \"This is one smoke-test group. EIT uses ideal voltage-drive boundaries; contact impedance and current-drive CEM are not yet included.\"");
        pw.println("}");
        pw.close();
    }

    public static void main(String[] args) throws Exception {
        System.out.println("init"); System.out.flush();
        ModelUtil.initStandalone(true);
        System.out.println("loading"); System.out.flush();
        Model m = ModelUtil.load("m", BASE);
        System.out.println("loaded"); System.out.flush();
        Physics ec = m.component("comp1").physics("ec");
        // Keep the original feature nodes but empty their selections.
        ec.feature("pot1").selection().set(new int[]{});
        ec.feature("gnd1").selection().set(new int[]{});
        System.out.println("base physics ready"); System.out.flush();
        PhysicsFeature term = ec.feature().create("eitTerm", "Terminal", 1);
        System.out.println("term created"); System.out.flush();
        term.set("TerminalName", "drive");
        term.set("TerminalType", "Voltage");
        term.set("V0", "1[V]");
        System.out.println("term configured"); System.out.flush();
        PhysicsFeature gnd = ec.feature().create("eitGround", "Ground", 1);
        System.out.println("ground created"); System.out.flush();

        double[][][] eit = new double[2][N][N];
        for (int d=0; d<N; d++) {
            int drive = OUTER[d];
            int ground = OUTER[(d+1)%N];
            term.selection().set(new int[]{drive});
            gnd.selection().set(new int[]{ground});
            ec.feature("ein1").selection().set(except(drive, ground));
            System.out.println("EIT pattern " + (d+1) + "/" + N + " drive=" + drive + " ground=" + ground);
            System.out.flush();
            m.study("std1").run();
            if (d == 0) {
                m.result().numerical().create("eitInterp", "Interp");
                m.result().numerical("eitInterp").set("expr", new String[]{"V"});
                m.result().numerical("eitInterp").setInterpolationCoordinates(ringCoordinates());
            }
            double[][][] dat = m.result().numerical("eitInterp").getData();
            for (int q=0; q<N; q++) {
                eit[0][d][q] = dat[0][0][q];
                eit[1][d][q] = dat[0][1][q];
            }
        }
        writeEitCsv(eit);
        System.out.println("EIT matrix written: " + DIR + "eit_voltage_matrix.csv");

        // Add the acoustic field only after the EIT matrix has been generated.
        Physics ac = m.component("comp1").physics().create("acpr", "PressureAcoustics", "geom1");
        Material ma = m.component("comp1").material().create("matAc", "Common");
        ma.selection().set(new int[]{1,2});
        ma.propertyGroup("def").set("density", "1000[kg/m^3]");
        ma.propertyGroup("def").set("soundspeed", "1500[m/s]");
        PhysicsFeature wall = ac.feature("shb1");
        wall.selection().set(except(OUTER[0], -1));
        PhysicsFeature src = ac.feature().create("usSource", "Pressure", 1);
        src.selection().set(new int[]{OUTER[0]});
        src.set("p0", "1[Pa]");
        m.component("comp1").mesh("mesh1").autoMeshSize(3);
        m.study().create("stdUS");
        m.study("stdUS").create("freqUS", "Frequency");
        m.study("stdUS").feature("freqUS").set("plist", "50[kHz]");
        System.out.println("Running ultrasound study at 50 kHz");
        m.study("stdUS").run();

        // Evaluate pressure on a regular grid. Points outside the circle are NaN.
        double[][] xy = new double[2][GRID*GRID];
        int z=0;
        for (int iy=0; iy<GRID; iy++) for (int ix=0; ix<GRID; ix++) {
            xy[0][z] = -1.0 + 2.0*ix/(GRID-1.0);
            xy[1][z] = -1.0 + 2.0*iy/(GRID-1.0);
            z++;
        }
        m.result().numerical().create("usInterp", "Interp");
        m.result().numerical("usInterp").set("expr", new String[]{"real(p)", "imag(p)", "abs(p)", "arg(p)"});
        m.result().numerical("usInterp").setInterpolationCoordinates(xy);
        double[][][] pd = m.result().numerical("usInterp").getData();
        java.io.PrintWriter up = new java.io.PrintWriter(DIR + "ultrasound_pressure_grid.csv");
        up.println("x_m,y_m,p_real_Pa,p_imag_Pa,p_abs_Pa,p_phase_rad");
        for (int k=0; k<GRID*GRID; k++) {
            double xx=xy[0][k], yy=xy[1][k];
            up.println(xx+","+yy+","+pd[0][0][k]+","+pd[1][0][k]+","+pd[2][0][k]+","+pd[3][0][k]);
        }
        up.close();
        m.save(DIR + "sample_crescent_eit_us.mph");
        writeMetadata();
        System.out.println("Ultrasound grid and MPH written");
        ModelUtil.clear();
        System.out.println("done");
    }
}
