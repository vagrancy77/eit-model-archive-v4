import com.comsol.model.*;
import com.comsol.model.physics.*;
import com.comsol.model.util.*;

/** Add one 2-D pressure-acoustics simulation to the already validated crescent geometry. */
public class BuildUltrasound {
    private static final String DIR = "E:\\Codex\\eit_reproduction\\comsol_small_test\\";
    private static final String BASE = DIR + "comsol_small_test_crescent_eit.mph";
    private static final int[] OUTER = {1,2,3,4,5,6,9,10,15,16,19,20,21,22,23,24};
    private static final int GRID = 11;
    private static int[] exceptFirst() {
        int[] x = new int[OUTER.length-1];
        for (int i=1; i<OUTER.length; i++) x[i-1] = OUTER[i];
        return x;
    }
    public static void main(String[] args) throws Exception {
        ModelUtil.initStandalone(true);
        System.out.println("US init"); System.out.flush();
        Model m = ModelUtil.load("m", BASE);
        System.out.println("US loaded"); System.out.flush();
        Physics ac = m.component("comp1").physics().create("acpr", "PressureAcoustics", "geom1");
        System.out.println("acpr created"); System.out.flush();

        Material bg = m.component("comp1").material().create("matAcBg", "Common");
        bg.selection().set(new int[]{1});
        bg.propertyGroup("def").set("density", "1000[kg/m^3]");
        bg.propertyGroup("def").set("soundspeed", "1500[m/s]");
        System.out.println("background acoustic material"); System.out.flush();
        Material le = m.component("comp1").material().create("matAcLesion", "Common");
        le.selection().set(new int[]{2});
        le.propertyGroup("def").set("density", "1050[kg/m^3]");
        le.propertyGroup("def").set("soundspeed", "1560[m/s]");
        System.out.println("lesion acoustic material"); System.out.flush();

        // A 1 Pa boundary pulse on the first arc, with the remainder sound-hard.
        // Leave the automatically generated SoundHard feature active on all
        // outer boundaries; Pressure on the source arc overrides it locally.
        // (Changing this selection can be slow in COMSOL 6.3 for this geometry.)
        PhysicsFeature src = ac.feature().create("usSource", "Pressure", 1);
        src.selection().set(new int[]{OUTER[0]});
        src.set("p0", "1[Pa]");
        System.out.println("source configured"); System.out.flush();
        // A coarse but stable acoustic mesh is sufficient for this first
        // paired-data smoke test; it avoids launching a high-resolution wave
        // solve before the data format is validated.
        m.component("comp1").mesh("mesh1").autoMeshSize(8);
        System.out.println("mesh configured"); System.out.flush();

        m.study().create("stdUS");
        m.study("stdUS").create("freqUS", "Frequency");
        m.study("stdUS").feature("freqUS").set("plist", "50[kHz]");
        try {
            m.study("stdUS").feature("freqUS").set("activate", new String[]{"ec", "off", "acpr", "on"});
        } catch (Exception ex) {
            System.out.println("Study activation switch unavailable: " + ex);
        }
        System.out.println("Running pressure acoustics at 50 kHz"); System.out.flush();
        m.study("stdUS").run();
        System.out.println("Acoustic study solved"); System.out.flush();

        double[][] xy = new double[2][GRID*GRID];
        int z=0;
        for (int iy=0; iy<GRID; iy++) for (int ix=0; ix<GRID; ix++) {
            xy[0][z] = -1.0 + 2.0*ix/(GRID-1.0);
            xy[1][z] = -1.0 + 2.0*iy/(GRID-1.0);
            z++;
        }
        m.result().numerical().create("usGrid", "Interp");
        m.result().numerical("usGrid").set("expr", new String[]{"real(p)", "imag(p)", "abs(p)"});
        m.result().numerical("usGrid").setInterpolationCoordinates(xy);
        double[][][] pd = m.result().numerical("usGrid").getData();
        java.io.PrintWriter pw = new java.io.PrintWriter(DIR + "ultrasound_pressure_grid.csv");
        pw.println("x_m,y_m,p_real_Pa,p_imag_Pa,p_abs_Pa,p_phase_rad");
        for (int k=0; k<GRID*GRID; k++) {
            double phase = Math.atan2(pd[1][0][k], pd[0][0][k]);
            pw.println(xy[0][k]+","+xy[1][k]+","+pd[0][0][k]+","+pd[1][0][k]+","+pd[2][0][k]+","+phase);
        }
        pw.close();
        try {
            m.result().create("pgUS", "PlotGroup2D");
            m.result("pgUS").create("surfUS", "Surface");
            m.result("pgUS").feature("surfUS").set("expr", "abs(p)");
            m.result().export().create("imgUS", "pgUS", "Image");
            m.result().export("imgUS").set("filename", DIR + "ultrasound_pressure_50kHz.png");
            m.result().export("imgUS").set("width", "800");
            m.result().export("imgUS").set("height", "600");
            m.result().export("imgUS").run();
            System.out.println("Acoustic image exported");
        } catch (Exception ex) { System.out.println("Acoustic image export warning: " + ex); }
        m.save(DIR + "sample_crescent_eit_us.mph");
        java.io.PrintWriter meta = new java.io.PrintWriter(DIR + "sample_metadata.json");
        meta.println("{\"sample_id\":\"crescent_001\",\"eit\":{\"frequencies_hz\":[10000,50000],\"matrix\":[2,16,16],\"drive\":\"1 V terminal i, ground i+1\"},\"ultrasound\":{\"frequency_hz\":50000,\"source\":\"1 Pa on boundary arc 1\",\"grid\":[81,81]},\"geometry\":\"unit circle; ellipse difference crescent\",\"note\":\"Ideal voltage-drive EIT smoke test; acoustic lesion has rho=1050 kg/m3, c=1560 m/s versus background rho=1000 kg/m3, c=1500 m/s.\"}");
        meta.close();
        System.out.println("Saved ultrasound grid and combined MPH");
        ModelUtil.clear(); System.exit(0);
    }
}
