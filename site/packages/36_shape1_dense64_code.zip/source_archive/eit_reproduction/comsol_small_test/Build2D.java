import com.comsol.model.*;
import com.comsol.model.physics.*;
import com.comsol.model.util.*;

public class Build2D {
    private static final String OUT = "E:\\Codex\\eit_reproduction\\comsol_small_test\\";

    public static void main(String[] args) throws Exception {
        ModelUtil.initStandalone(true);
        Model m = ModelUtil.create("Model");
        m.label("build2d_test.mph");
        m.param().set("sigma_bg", "0.5[S/m]");
        m.param().set("sigma_lesion", "1.0[S/m]");
        m.param().set("freq", "10[kHz]");
        m.component().create("comp1", true);
        m.component("comp1").geom().create("geom1", 2);
        GeomSequence g = m.component("comp1").geom("geom1");
        // Circular tissue; points partition the circumference into 16 arcs.
        g.create("c1", "Circle");
        g.feature("c1").set("r", 1.0);
        for (int k = 0; k < 16; k++) {
            double a = 2.0*Math.PI*k/16.0;
            String tag = "p" + (k+1);
            g.create(tag, "Point");
            g.feature(tag).set("p", new double[]{Math.cos(a), Math.sin(a)});
        }
        // Smooth crescent: a larger ellipse minus an offset smaller ellipse.
        g.create("e1", "Ellipse");
        g.feature("e1").set("semiaxes", new double[]{0.30, 0.20});
        g.feature("e1").set("pos", new double[]{-0.10, 0.05});
        g.create("e2", "Ellipse");
        g.feature("e2").set("semiaxes", new double[]{0.24, 0.145});
        g.feature("e2").set("pos", new double[]{0.03, 0.05});
        g.create("lesion", "Difference");
        g.feature("lesion").selection("input").set("e1");
        g.feature("lesion").selection("input2").set("e2");
        // Retain the interface between lesion and tissue as an interior edge.
        g.create("uni1", "Union");
        g.feature("uni1").selection("input").set(new String[]{"c1", "lesion"});
        g.feature("uni1").set("intbnd", true);
        g.run();
        System.out.println("geom dim=" + g.getSDim() + " bnd=" + g.getNBoundaries() + " dom=" + g.getNDomains());
        // Boundary/domain adjacency is inspected in a separate lightweight loader
        // after the solved MPH is written; querying it before physics creation can
        // destabilize some COMSOL 6.3 geometry kernels.
        System.out.println("creating physics");
        m.component("comp1").physics().create("ec", "ConductiveMedia", "geom1");
        System.out.println("physics created");
        m.component("comp1").material().create("mat1", "Common");
        m.component("comp1").material("mat1").selection().set(new int[]{1});
        m.component("comp1").material("mat1").propertyGroup("def").set("electricconductivity", new String[]{"sigma_bg", "0", "0", "0", "sigma_bg", "0", "0", "0", "sigma_bg"});
        m.component("comp1").material("mat1").propertyGroup("def").set("relpermittivity", new String[]{"1", "0", "0", "0", "1", "0", "0", "0", "1"});
        m.component("comp1").material().create("mat2", "Common");
        m.component("comp1").material("mat2").selection().set(new int[]{2});
        m.component("comp1").material("mat2").propertyGroup("def").set("electricconductivity", new String[]{"sigma_lesion", "0", "0", "0", "sigma_lesion", "0", "0", "0", "sigma_lesion"});
        m.component("comp1").material("mat2").propertyGroup("def").set("relpermittivity", new String[]{"1", "0", "0", "0", "1", "0", "0", "0", "1"});
        Physics ec = m.component("comp1").physics("ec");
        ec.feature().create("pot1", "ElectricPotential", 1);
        ec.feature("pot1").set("V0", "1[V]");
        ec.feature("pot1").selection().set(new int[]{1});
        ec.feature().create("gnd1", "Ground", 1);
        ec.feature("gnd1").selection().set(new int[]{9});
        System.out.println("materials configured");
        m.component("comp1").mesh().create("mesh1");
        System.out.println("mesh feature created");
        m.component("comp1").mesh("mesh1").autoMeshSize(4);
        m.study().create("std1");
        m.study("std1").create("freq", "Frequency");
        m.study("std1").feature("freq").set("plist", "10[kHz] 50[kHz]");
        System.out.println("running study");
        m.study("std1").run();
        System.out.println("solved");
        try {
            System.out.println("creating interpolation feature");
            // Evaluate just inside the boundary to avoid an ambiguous boundary projection.
            m.result().numerical().create("int1", "Interp");
            m.result().numerical("int1").set("expr", new String[]{"V"});
            // COMSOL expects coord[spaceDimension][numberOfPoints].
            double[][] xy = new double[2][16];
            for (int k=0; k<16; k++) {
                double a = 2.0*Math.PI*(k+0.5)/16.0;
                xy[0][k] = 0.995*Math.cos(a); xy[1][k] = 0.995*Math.sin(a);
            }
            m.result().numerical("int1").setInterpolationCoordinates(xy);
            System.out.println("interpolation coordinates set");
            double[][][] dat = m.result().numerical("int1").getData();
            System.out.println("interp dimensions=" + dat.length + "," + dat[0].length + "," + dat[0][0].length);
            java.io.PrintWriter pw = new java.io.PrintWriter(OUT + "comsol_small_test_electrode_voltage.csv");
            pw.println("electrode,V_10kHz,V_50kHz");
            for (int k=0; k<16; k++) {
                double v10 = (dat.length>0 && dat[0].length>0 && dat[0][0].length>k) ? dat[0][0][k] : Double.NaN;
                double v50 = (dat.length>0 && dat[0].length>1 && dat[0][1].length>k) ? dat[0][1][k] : Double.NaN;
                pw.println((k+1)+","+v10+","+v50);
                System.out.println("E"+(k+1)+" V10="+v10+" V50="+v50);
            }
            pw.close();
        } catch (Exception ex) {
            System.out.println("interpolation failed: " + ex);
            ex.printStackTrace();
        }
        try {
            // Minimal plot groups for visual verification.
            m.result().create("pgV10", "PlotGroup2D");
            m.result("pgV10").create("surf", "Surface");
            m.result("pgV10").feature("surf").set("expr", "V");
            m.result("pgV10").set("looplevel", new String[]{"1"});
            m.result().export().create("imgV10", "pgV10", "Image");
            m.result().export("imgV10").set("filename", OUT + "comsol_geometry_potential_10kHz.png");
            m.result().export("imgV10").set("width", "1200");
            m.result().export("imgV10").set("height", "900");
            m.result().export("imgV10").run();
            m.result().create("pgV50", "PlotGroup2D");
            m.result("pgV50").create("surf", "Surface");
            m.result("pgV50").feature("surf").set("expr", "V");
            m.result("pgV50").set("looplevel", new String[]{"2"});
            m.result().export().create("imgV50", "pgV50", "Image");
            m.result().export("imgV50").set("filename", OUT + "comsol_geometry_potential_50kHz.png");
            m.result().export("imgV50").set("width", "1200");
            m.result().export("imgV50").set("height", "900");
            m.result().export("imgV50").run();
            System.out.println("images exported");
        } catch (Exception ex) {
            System.out.println("image export failed: " + ex);
            ex.printStackTrace();
        }
        m.save(OUT + "comsol_small_test_crescent_eit.mph");
        System.out.println("model saved");
        ModelUtil.clear();
        System.out.println("done");
        System.exit(0);
    }
}
