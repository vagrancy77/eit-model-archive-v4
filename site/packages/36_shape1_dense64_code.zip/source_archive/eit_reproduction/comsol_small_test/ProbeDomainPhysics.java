import com.comsol.model.*; import com.comsol.model.physics.*; import com.comsol.model.util.*;
public class ProbeDomainPhysics { public static void main(String[] a)throws Exception{
 ModelUtil.initStandalone(true); Model m=ModelUtil.load("m",a.length>0?a[0]:"E:\\Codex\\eit_reproduction\\comsol_small_test\\comsol_small_test_crescent_eit.mph"); Physics ec=m.component("comp1").physics("ec");
 String[] t={"ElectricPotential","Ground","Terminal","FloatingPotential","CurrentSource"}; for(String x:t){try{PhysicsFeature f=ec.feature().create("d"+x,x,2); System.out.println(x+" OK");}catch(Exception e){System.out.println(x+" FAIL "+e);}}
}}
