"""Package a COMSOL Untitled.mph export as one EIT training sample.

The electrode CSV is the only file treated as an inverse-problem input.  The
finite-element potential field is retained separately for QA and is never
included in the default ``eit_voltage`` tensor.
"""
from __future__ import annotations

import csv
import hashlib
import json
import shutil
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent / "comsol_untitled_dataset"
SOURCE_GLOBAL_CSV = Path(r"C:\Users\luandingyu\Desktop\癌症\COMSOL\Untitled.csv")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read_electrode_csv(path: Path):
    rows = []
    with path.open("r", encoding="utf-8", errors="replace", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            re = float(row["voltage_real_V"])
            im = float(row["voltage_imag_V"])
            rows.append((float(row["frequency_hz"]), int(row["electrode_id"]), re, im))
    freqs = np.array(sorted({r[0] for r in rows}), dtype=np.float64)
    n_e = max(r[1] for r in rows)
    voltage = np.full((len(freqs), n_e), np.nan + 1j * np.nan, dtype=np.complex128)
    for f, e, re, im in rows:
        voltage[np.where(freqs == f)[0][0], e - 1] = re + 1j * im
    if not np.isfinite(voltage.real).all() or not np.isfinite(voltage.imag).all():
        raise ValueError("Electrode voltage export has missing entries")
    return freqs, voltage


def grid_from_field(path: Path, freqs: np.ndarray, axis: np.ndarray):
    n = len(axis)
    real = np.full((len(freqs), n, n), np.nan, dtype=np.float32)
    imag = np.full_like(real, np.nan)
    index = {round(float(x), 12): i for i, x in enumerate(axis)}
    with path.open("r", encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            f_hz = float(row["frequency_hz"])
            s = int(np.argmin(np.abs(freqs - f_hz)))
            x = float(row["x_m"]); y = float(row["y_m"])
            i = index[round(x, 12)]; j = index[round(y, 12)]
            real[s, j, i] = float(row["potential_real_V"])
            imag[s, j, i] = float(row["potential_imag_V"])
    return real, imag


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    meta = json.loads((OUT / "comsol_model_metadata.json").read_text(encoding="utf-8"))
    freqs, voltage = read_electrode_csv(OUT / meta["voltage_file"])
    with (OUT / meta["voltage_file"]).open("r", encoding="utf-8", newline="") as f:
        first_rows = list(csv.DictReader(f))
    electrode_xy = np.zeros((voltage.shape[1], 2), dtype=np.float32)
    for row in first_rows:
        e = int(row["electrode_id"]) - 1
        electrode_xy[e] = [float(row["x_m"]), float(row["y_m"])]
    adjacent_diff = np.roll(voltage, -1, axis=1) - voltage
    n = int(meta["grid_size"]); radius = float(meta["domain_radius_m"])
    axis = np.linspace(-radius, radius, n, dtype=np.float64)
    xx, yy = np.meshgrid(axis, axis, indexing="xy")
    valid = xx * xx + yy * yy <= radius * radius
    lesion_cfg = meta["geometry"]["lesion"]
    cx, cy = lesion_cfg["ellipse_center_m"]
    ax, by = lesion_cfg["ellipse_semiaxes_m"]
    cutx, cuty = lesion_cfg["cutout_center_m"]
    cutr = float(lesion_cfg["cutout_radius_m"])
    ellipse = ((xx - cx) / ax) ** 2 + ((yy - cy) / by) ** 2 <= 1.0
    cutout = (xx - cutx) ** 2 + (yy - cuty) ** 2 <= cutr * cutr
    lesion = valid & ellipse & ~cutout
    sig = meta["conductivity_S_per_m"]
    cond = np.empty((len(freqs), n, n), dtype=np.float32)
    for k, f in enumerate(freqs):
        lesion_sigma = float(sig["lesion_10kHz"] if f < 30000 else sig["lesion_50kHz"])
        cond[k] = np.where(lesion, lesion_sigma, float(sig["background"])).astype(np.float32)
        cond[k, ~valid] = np.nan

    field_real, field_imag = grid_from_field(OUT / meta["potential_field_file"], freqs, axis)
    field_real[:, ~valid] = np.nan; field_imag[:, ~valid] = np.nan

    # Preserve the original COMSOL global table, but mark it as auxiliary.
    if SOURCE_GLOBAL_CSV.exists():
        shutil.copy2(SOURCE_GLOBAL_CSV, OUT / "Untitled_global_table_original.csv")

    np.save(OUT / "lesion_mask.npy", lesion)
    np.save(OUT / "conductivity_S_per_m.npy", cond)
    np.savez_compressed(
        OUT / "sample_pair.npz",
        eit_voltage=voltage.astype(np.complex64),
        eit_voltage_real=voltage.real.astype(np.float32),
        eit_voltage_imag=voltage.imag.astype(np.float32),
        eit_voltage_abs=np.abs(voltage).astype(np.float32),
        eit_voltage_phase=np.angle(voltage).astype(np.float32),
        eit_adjacent_difference=adjacent_diff.astype(np.complex64),
        eit_adjacent_difference_real=adjacent_diff.real.astype(np.float32),
        eit_adjacent_difference_imag=adjacent_diff.imag.astype(np.float32),
        frequencies_hz=freqs.astype(np.float32),
        x=axis.astype(np.float32), y=axis.astype(np.float32),
        electrode_xy=electrode_xy,
        valid_mask=valid, lesion_mask=lesion,
        conductivity_S_per_m=cond,
        potential_real_V=field_real, potential_imag_V=field_imag,
        electrode_boundary_ids=np.asarray(meta["electrode_boundary_ids"], dtype=np.int32),
    )

    # A compact QA image: labels, electrode amplitudes, and internal field.
    f50 = int(np.argmin(np.abs(freqs - 50000)))
    fig, axp = plt.subplots(2, 3, figsize=(13, 8), constrained_layout=True)
    extent = [-radius, radius, -radius, radius]
    axp[0, 0].imshow(lesion, origin="lower", extent=extent, cmap="gray_r", vmin=0, vmax=1)
    axp[0, 0].set_title("Ground-truth lesion mask")
    im = axp[0, 1].imshow(cond[f50], origin="lower", extent=extent, cmap="viridis")
    axp[0, 1].set_title(f"Conductivity ({freqs[f50]/1000:g} kHz)"); fig.colorbar(im, ax=axp[0, 1], label="S/m")
    im = axp[0, 2].imshow(field_real[f50], origin="lower", extent=extent, cmap="turbo")
    axp[0, 2].contour(xx, yy, lesion, levels=[0.5], colors="white", linewidths=0.8)
    axp[0, 2].set_title("Internal FEM potential (QA only)"); fig.colorbar(im, ax=axp[0, 2], label="V")
    im = axp[1, 0].imshow(np.abs(voltage), aspect="auto", cmap="magma")
    axp[1, 0].set_title("|electrode voltage|"); axp[1, 0].set_xlabel("electrode"); axp[1, 0].set_ylabel("frequency")
    axp[1, 1].plot(freqs / 1000, np.abs(voltage[:, 0]), "o-"); axp[1, 1].set_title("E1 voltage vs frequency"); axp[1, 1].set_xlabel("kHz"); axp[1, 1].set_ylabel("V")
    axp[1, 2].axis("off")
    fig.suptitle("COMSOL Untitled.mph: EIT case package", fontsize=14)
    fig.savefig(OUT / "dataset_preview.png", dpi=180)
    plt.close(fig)

    files = ["sample_pair.npz", "lesion_mask.npy", "conductivity_S_per_m.npy", "dataset_preview.png", meta["voltage_file"], meta["potential_field_file"]]
    manifest = {
        "sample_id": "untitled_crescent_001",
        "source": meta["source_mph"],
        "input_tensor": {"file": "sample_pair.npz", "name": "eit_voltage", "shape": list(voltage.shape), "axis_order": ["frequency", "electrode"], "complex": True, "also_provided": "eit_adjacent_difference"},
        "label_tensors": {"lesion_mask": [n, n], "conductivity": list(cond.shape), "axis_order": ["frequency", "y", "x"]},
        "frequencies_hz": freqs.astype(int).tolist(),
        "valid_domain_fraction": float(valid.mean()),
        "lesion_fraction_in_domain": float(lesion.sum() / valid.sum()),
        "protocol": meta["drive_protocol"],
        "files": {p: {"bytes": (OUT / p).stat().st_size, "sha256": sha256(OUT / p)} for p in files},
        "important_limitation": "This mph contains one current-drive case only. It is a valid single-case export, not yet a 1000-case dataset and not a full adjacent-drive EIT matrix. Generate more cases by varying geometry/material parameters before training.",
        "leakage_warning": "potential_field_nodes.csv and potential_real_V/potential_imag_V are internal FEM fields. Do not use them as inverse-model input; use eit_voltage only.",
    }
    (OUT / "dataset_manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    (OUT / "README.md").write_text(
        "# COMSOL Untitled EIT sample\n\n"
        "This package was re-solved from the supplied `Untitled.mph`. `sample_pair.npz` contains the measured-style complex electrode voltage vector for the 16-electrode current-drive case and frequency-dependent conductivity/mask labels.\n\n"
        "Use `eit_voltage` as the neural-network input. The FEM potential field is retained only for visualization/QA. The model has one drive pattern (E1=1 mA, E2=ground, other terminals zero current), so this is a validated single-case export and not yet a complete multi-pattern training set.\n",
        encoding="utf-8",
    )
    print(json.dumps({"output": str(OUT), "voltage_shape": list(voltage.shape), "conductivity_shape": list(cond.shape), "lesion_pixels": int(lesion.sum()), "preview": str(OUT / "dataset_preview.png")}, indent=2))


if __name__ == "__main__":
    main()
