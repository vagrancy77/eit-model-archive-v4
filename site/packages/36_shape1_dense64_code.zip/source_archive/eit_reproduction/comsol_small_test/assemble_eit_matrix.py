"""Combine the sixteen independent COMSOL EIT pattern files into one sample."""
from pathlib import Path
import csv
import json
import numpy as np

root = Path(__file__).resolve().parent
rows = []
mat = np.zeros((2, 16, 16), dtype=np.float64)
for d in range(16):
    path = root / f"eit_pattern_{d+1}.csv"
    with path.open(newline="") as f:
        rr = list(csv.DictReader(f))
    if len(rr) != 16:
        raise RuntimeError(f"{path} has {len(rr)} rows, expected 16")
    for q, r in enumerate(rr):
        mat[0, d, q] = float(r["V_10kHz"])
        mat[1, d, q] = float(r["V_50kHz"])
        rows.append(r)

with (root / "eit_voltage_matrix.csv").open("w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["drive_electrode", "ground_electrode", "measurement_electrode", "V_10kHz", "V_50kHz"])
    w.writeheader(); w.writerows(rows)
np.savez_compressed(root / "eit_voltage_matrix.npz", voltage=mat, frequencies_hz=np.array([10000., 50000.]))

meta = {
    "shape": list(mat.shape),
    "axis_order": ["frequency", "drive_electrode", "measurement_electrode"],
    "drive_protocol": "1 V ideal voltage terminal on electrode i; ground on adjacent electrode i+1",
    "electrode_boundary_ids": [1,2,3,4,5,6,9,10,15,16,19,20,21,22,23,24],
    "frequencies_hz": [10000, 50000],
    "max_10kHz_50kHz_difference_V": float(np.max(np.abs(mat[0]-mat[1]))),
    "note": "Voltage-drive EIT matrix on the crescent test geometry; not contact-impedance CEM."
}
(root / "eit_matrix_metadata.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
print("saved", root / "eit_voltage_matrix.npz", "shape", mat.shape)
print("max frequency difference", meta["max_10kHz_50kHz_difference_V"])
