$ErrorActionPreference = 'Stop'

$comsol = 'E:\COMSOL\COMSOL63\Multiphysics'
$java = "$comsol\java\win64\jre\bin\java.exe"
$javac = "$comsol\java\win64\jre\bin\javac.exe"
$compile = 'E:\Codex\compile_direct'
$source = 'E:\Codex\eit_reproduction\comsol_small_test\Build2D.java'

New-Item -ItemType Directory -Path $compile -Force | Out-Null
& $javac -cp "$comsol\plugins\*" -d $compile $source
if ($LASTEXITCODE -ne 0) { throw "COMSOL Java compilation failed ($LASTEXITCODE)" }

$env:PATH = "$comsol\bin\win64;" + $env:PATH
& $java -cp "$compile;$comsol\plugins\*" Build2D
if ($LASTEXITCODE -ne 0) { throw "COMSOL model run failed ($LASTEXITCODE)" }

$pythonCommand = Get-Command python -ErrorAction SilentlyContinue
$pythonExe = if ($null -eq $pythonCommand) {
    'C:\Users\luandingyu\AppData\Local\Programs\Python\Python313\python.exe'
} else {
    $pythonCommand.Source
}
& $pythonExe 'E:\Codex\eit_reproduction\comsol_small_test\make_preview.py'
if ($LASTEXITCODE -ne 0) { throw "Preview generation failed ($LASTEXITCODE)" }

Write-Host 'COMSOL small test completed.'
