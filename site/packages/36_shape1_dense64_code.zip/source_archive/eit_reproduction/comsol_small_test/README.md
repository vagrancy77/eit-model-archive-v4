# COMSOL 2D 月牙形 EIT + 超声单组样本

这个目录保存一组已经求解完成、空间配对的 COMSOL 6.3 数据：同一个二维月牙
病灶同时生成 EIT 电压和超声声压场。它是后续批量数据集的格式样例，当前只做
这一组，便于先检查数据是否符合预期。

## 模型设置

- 几何：半径 `1 m` 的二维圆形组织。
- 病灶：两个椭圆的差集 `e1 - e2`，形成平滑月牙形；外椭圆半轴
  `(0.30, 0.20) m`、中心 `(-0.10, 0.05) m`，切除椭圆半轴
  `(0.24, 0.145) m`、中心 `(0.03, 0.05) m`。
- 材料：背景电导率 `0.5 S/m`，病灶电导率 `1.0 S/m`；相对介电常数均设为
  `1`，因此这是一个准静态、频率无色散的 sanity check。
- EIT 频率：同一几何上求解 `10 kHz` 和 `50 kHz`。
- 超声频率：`50 kHz` Pressure Acoustics（当前用于验证 AC/DC 与声学模块的
  联通，不等同于临床 MHz B-mode 超声）。
- 电流边界：一个 `Electric Potential`（`1 V`）和一个 `Ground`，其余外边界
  为默认绝缘。
- 电极几何准备：16 个圆周点把外圆边界切分成 16 个独立弧段；当前在每个弧段
  中心稍内侧 `r=0.995` 处插值 `V`，作为 16 个电极位置的电压代理并输出到 CSV。

## EIT 协议和限制

当前样本采用 16 个独立模式：第 `i` 个弧段施加 `1 V` 理想电压，第 `i+1` 个弧段
接地，其余边界绝缘，并在 16 个电极中心内侧采样电势。因此当前它严格来说是
**ideal voltage-drive EIT**，还不是含接触阻抗和浮动电极电位的临床 Complete
Electrode Model (CEM)。

这组样本适合先验证“EIT 张量 + 超声张量 + 同坐标真值”的数据接口，不能据此
宣称已经完成临床采集协议。后续批量训练前建议将 EIT 改为 current-drive CEM。

## 超声数据格式

`ultrasound_pressure_mesh.csv` 是 COMSOL 导出的原始非规则网格节点，共约
`132,618` 个节点，列为 `x, y, real(p), imag(p), abs(p)`。

`ultrasound_pressure_grid.npz` 是便于 PyTorch 读取的规则 `128 x 128` 网格，包含：

- `pressure_real`、`pressure_imag`、`pressure_abs`、`pressure_phase`；
- `valid_mask`（圆形组织域）；
- `lesion_mask`（与 EIT 几何完全配准的月牙真值）；
- `x`、`y` 坐标和 `frequency_hz`。

规则网格由 8 邻近节点的反距离加权得到；原始 COMSOL 网格文件始终保留，便于
以后改用有限元单元插值。

## 这组数据可以回答什么

1. 圆形组织和内含月牙病灶能否稳定网格化；
2. EIT 在 10/50 kHz 下能否自动导出 `[frequency, drive, measurement] = [2,16,16]`
   电压矩阵；
3. 同一病灶能否在超声声压网格和 EIT 数据中保持坐标配对；
4. 后续 PyTorch 数据加载器是否能同时读取 EIT、超声和病灶真值。

## 输出文件

- `sample_crescent_eit_us.mph`：包含 EIT 几何和 50 kHz Pressure Acoustics 的组合
  COMSOL 模型。
- `eit_voltage_matrix.npz/csv`：EIT 电压矩阵和长表。
- `eit_pattern_1.csv` ... `eit_pattern_16.csv`：各独立激励模式。
- `ultrasound_pressure_mesh.csv`：COMSOL 原始声学网格节点。
- `ultrasound_pressure_grid.npz/csv`：规则超声张量和可读长表。
- `lesion_mask_grid.npy`：规则网格上的月牙真值掩膜。
- `conductivity_grid_S_per_m.npy`：与掩膜同坐标的电导率真值（背景 `0.5`、病灶
  `1.0 S/m`）。
- `sample_pair_eit_us.npz`：把 EIT、超声、坐标、有效域、掩膜和电导率真值放在一
  个文件中的便捷版本，后续 PyTorch `Dataset` 可直接读取。
- `sample_manifest.json`：完整字段、尺寸、物理参数和文件校验信息。
- `sample_eit_us_complete_preview.png`：包含真值轮廓、超声场和两组 EIT 矩阵的 QA 图。
- `package_single_sample.py`：从原始导出重新打包规则网格、真值和 manifest。

旧版 `comsol_small_test_preview.png` 仍保留，用于只看原始 EIT 矩阵和声学网格。

当前 CSV 的两列几乎相同是预期结果：在本测试中电导率和介电常数没有频率依赖，
并且使用的是线性导电介质。因此这验证了频率扫描链路，但不能证明组织的真实
频散。若要研究 10/50 kHz 的差异，应给病灶和背景加入频率相关的复电导率或
相对介电常数。

## 复现命令（Windows PowerShell）

```powershell
$comsol = 'E:\COMSOL\COMSOL63\Multiphysics'
$java = "$comsol\java\win64\jre\bin\java.exe"
$javac = "$comsol\java\win64\jre\bin\javac.exe"
$env:PATH = "$comsol\bin\win64;" + $env:PATH

& $javac -cp "$comsol\plugins\*" -d 'E:\Codex\compile_direct' `
    'E:\Codex\eit_reproduction\comsol_small_test\Build2D.java'
& $java -cp 'E:\Codex\compile_direct;E:\COMSOL\COMSOL63\Multiphysics\plugins\*' Build2D
```

需要 COMSOL 6.3 的 AC/DC Module 和 Acoustics Module 许可证。当前机器已检查到
两者均可用，组合模型已经保存为 `sample_crescent_eit_us.mph`。
