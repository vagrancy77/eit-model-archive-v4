import com.comsol.model.*;
import com.comsol.model.physics.*;
import com.comsol.model.util.*;
public class ProbeGround {
  public static void main(String[] a) throws Exception {
    ModelUtil.initStandalone(true);
    Model m=ModelUtil.load("m", a.length>0?a[0]:"E:\\Codex\\eit_reproduction\\comsol_small_test\\comsol_small_test_crescent_eit.mph");
    GeomSequence g=m.component("comp1").geom("geom1");
    System.out.println("bnd="+g.getNBoundaries()+" dom="+g.getNDomains());
    Physics ec=m.component("comp1").physics("ec");
    try { PhysicsFeature f=ec.feature().create("gp0","Ground",0); f.selection().set(new int[]{1}); System.out.println("ground0 OK"); }
    catch(Exception e){System.out.println("ground0 FAIL "+e);}
    try { PhysicsFeature f=ec.feature().create("gp2","Ground",2); f.selection().set(new int[]{1}); System.out.println("ground2 OK"); }
    catch(Exception e){System.out.println("ground2 FAIL "+e);}
    ModelUtil.clear();
  }
}
