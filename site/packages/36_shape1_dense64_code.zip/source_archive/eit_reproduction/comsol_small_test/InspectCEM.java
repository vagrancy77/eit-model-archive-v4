import com.comsol.model.*;
import com.comsol.model.physics.*;
import com.comsol.model.util.*;

public class InspectCEM {
  public static void main(String[] args) throws Exception {
    ModelUtil.initStandalone(true);
    String path = args.length > 0 ? args[0] : "E:\\COMSOL\\COMSOL63\\Multiphysics\\applications\\ACDC_Module\\Introductory_Electric_Currents\\contact_impedance_comparison.mph";
    Model m = ModelUtil.load("m", path);
    Physics ec = m.component("comp1").physics("ec");
    for (String tag : ec.feature().tags()) {
      PhysicsFeature f = ec.feature(tag);
      System.out.println("TAG=" + tag + " TYPE=" + f.getType());
      try { System.out.println("  bnd=" + java.util.Arrays.toString(f.selection().entities(1))); } catch(Exception e) { }
      for (String p : new String[]{"TerminalName","TerminalType","V0","I0","ds","spec_type","rhos","Csr"}) {
        try { System.out.println("  " + p + "=" + f.getString(p)); } catch(Exception e) { }
        try { System.out.println("  " + p + "(d)=" + f.getDouble(p)); } catch(Exception e) { }
      }
    }
    ModelUtil.clear();
  }
}
