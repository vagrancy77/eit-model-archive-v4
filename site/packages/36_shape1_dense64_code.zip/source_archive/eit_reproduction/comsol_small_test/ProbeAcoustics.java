import com.comsol.model.*;
import com.comsol.model.physics.*;
import com.comsol.model.util.*;

public class ProbeAcoustics {
  public static void main(String[] args) throws Exception {
    ModelUtil.initStandalone(true);
    String path = args.length > 0 ? args[0] : "E:\\Codex\\eit_reproduction\\comsol_small_test\\comsol_small_test_crescent_eit.mph";
    Model m = ModelUtil.load("m", path);
    Physics acpr = null;
    try { acpr = m.component("comp1").physics().create("acpr", "PressureAcoustics", "geom1"); System.out.println("acpr OK"); }
    catch(Exception e) { System.out.println("acpr FAIL " + e); }
    if (acpr != null) {
      String[] types = {"Pressure", "SoundHardBoundary", "PlaneWaveRadiation", "RadiationCondition", "NormalAcceleration", "MonopolePointSource"};
      for (String type : types) {
        try { PhysicsFeature f = acpr.feature().create("probe_"+type.toLowerCase(), type, 1); System.out.println(type+" OK props="+java.util.Arrays.toString(f.properties())); }
        catch(Exception e) { System.out.println(type+" FAIL "+e); }
      }
    }
    System.out.println("done");
  }
}
