"""Create compact QA figures for the COMSOL crescent test model.

The conductivity panel is the analytic material map used by Build2D.java;
the voltage panels are the PNG exports produced by COMSOL itself.
"""
from pathlib import Path
import csv
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "comsol_small_test_preview.png"

def crescent_map(n=401):
    x = np.linspace(-1, 1, n)
    y = np.linspace(-1, 1, n)
    X, Y = np.meshgrid(x, y)
    tissue = X * X + Y * Y <= 1.0
    outer = ((X + 0.10) / 0.30) ** 2 + ((Y - 0.05) / 0.20) ** 2 <= 1
    cut = ((X - 0.03) / 0.24) ** 2 + ((Y - 0.05) / 0.145) ** 2 <= 1
    lesion = tissue & outer & ~cut
    sigma = np.full_like(X, np.nan, dtype=float)
    sigma[tissue] = 0.5
    sigma[lesion] = 1.0
    return X, Y, sigma, lesion

def add_electrodes(ax):
    for k in range(16):
        a = 2 * np.pi * (k + 0.5) / 16
        x, y = np.cos(a), np.sin(a)
        ax.plot(x, y, "o", ms=4.5, color="#d62728", mec="white", mew=0.5, zorder=4)
        ax.text(1.09*x, 1.09*y, f"{k+1}", fontsize=6.5, ha="center", va="center", color="#8c1d1d")

X, Y, sigma, lesion = crescent_map()
fig, axes = plt.subplots(2, 2, figsize=(11, 8.5), constrained_layout=True)

ax = axes[0, 0]
im = ax.imshow(sigma, extent=(-1, 1, -1, 1), origin="lower", cmap="viridis", vmin=0.5, vmax=1.0)
ax.contour(X, Y, lesion.astype(float), levels=[0.5], colors="black", linewidths=1.0)
add_electrodes(ax)
ax.set_title("Conductivity map (S/m) + 16 electrode centers")
ax.set_aspect("equal"); ax.set_xlabel("x"); ax.set_ylabel("y")
fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

def show_comsol(ax, path, title):
    img = Image.open(path)
    ax.imshow(img)
    # COMSOL image has a square model centered in the frame; use axes-relative
    # coordinates so markers remain aligned if the export resolution changes.
    for k in range(16):
        a = 2 * np.pi * (k + 0.5) / 16
        # The COMSOL export includes a small margin around the model.  The
        # circle outline is x=127..672 and y=27..572 in the 800x600 export.
        u, v = 399.5/800 + 272.5/800*np.cos(a), 299.5/600 - 272.5/600*np.sin(a)
        ax.plot(u, v, "o", ms=3.2, color="#d62728", transform=ax.transAxes,
                mec="white", mew=0.4, zorder=4)
    ax.set_title(title); ax.set_axis_off()

show_comsol(axes[0, 1], ROOT / "comsol_geometry_potential_10kHz.png", "COMSOL potential, 10 kHz")
show_comsol(axes[1, 0], ROOT / "comsol_geometry_potential_50kHz.png", "COMSOL potential, 50 kHz")

ax = axes[1, 1]
csv_path = ROOT / "comsol_small_test_electrode_voltage.csv"
e, v10, v50 = [], [], []
with csv_path.open(newline="") as f:
    for row in csv.DictReader(f):
        e.append(int(row["electrode"]))
        v10.append(float(row["V_10kHz"]))
        v50.append(float(row["V_50kHz"]))
ax.plot(e, v10, "o-", lw=1.6, ms=4, label="10 kHz")
ax.plot(e, v50, "s--", lw=1.2, ms=3.5, label="50 kHz")
ax.set_xlabel("Electrode index"); ax.set_ylabel("Interpolated V (V)")
ax.set_title("Boundary potential sampled at 16 electrode centers")
ax.set_xticks(range(1, 17)); ax.grid(alpha=0.25); ax.legend(frameon=False)

fig.suptitle("COMSOL 2D crescent EIT feasibility test", fontsize=15)
fig.savefig(OUT, dpi=180)
print(OUT)
