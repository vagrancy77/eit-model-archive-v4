import com.comsol.model.*;
import com.comsol.model.util.*;
import java.lang.reflect.*;

public class ReflectComsol {
 public static void main(String[] a)throws Exception{
  ModelUtil.initStandalone(true); String p=a.length>0?a[0]:"C:\\Users\\luandingyu\\Desktop\\Untitled.mph"; Model m=ModelUtil.load("x",p);
  Object pg=m.component("comp1").material("mat1").propertyGroup("def");
  System.out.println("CLASS="+pg.getClass());
  for(Method z:pg.getClass().getMethods()){if(z.getName().matches("get.*|set.*|properties|tags"))System.out.println(z);}
  System.out.println("PROPS="+java.util.Arrays.toString(m.component("comp1").material("mat1").propertyGroup("def").properties()));
  for(String k:m.component("comp1").material("mat1").propertyGroup("def").properties()){
   for(String meth:new String[]{"getString","getStringArray","getDouble","getDoubleArray","getValue"}) try{Method z=pg.getClass().getMethod(meth,String.class); Object o=z.invoke(pg,k);System.out.println(meth+"("+k+")="+(o!=null?java.util.Arrays.deepToString(new Object[]{o}):"null"));}catch(Exception e){}
  }
  ModelUtil.clear();
 }
}
