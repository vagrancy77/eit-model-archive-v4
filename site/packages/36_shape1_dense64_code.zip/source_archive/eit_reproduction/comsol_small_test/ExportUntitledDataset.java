import com.comsol.model.*;
import com.comsol.model.util.*;
import java.io.*;
import java.util.*;

/** Re-solve Untitled.mph and export an EIT-ready, case-level sample. */
public class ExportUntitledDataset {
  static void mkdir(String p) { new File(p).mkdirs(); }
  static String csv(double x) { return Double.isNaN(x) ? "" : Double.toString(x); }
  public static void main(String[] args) throws Exception {
    ModelUtil.initStandalone(true);
    String in = args.length > 0 ? args[0] : "C:\\Users\\luandingyu\\Desktop\\癌症\\COMSOL\\Untitled.mph";
    String out = args.length > 1 ? args[1] : "E:\\Codex\\eit_reproduction\\comsol_untitled_dataset";
    mkdir(out);
    Model m = ModelUtil.load("export", in);
    try { m.study("std1").run(); } catch (Exception e) { System.out.println("solve_warning=" + e); }

    // The geometry uses R as the outer radius. Query it from the model rather than hard-coding it.
    double R = Double.parseDouble(m.param().get("R").replace("[m]", ""));
    double r0 = Double.parseDouble(m.param().get("r0").replace("[m]", ""));
    double rC = Double.parseDouble(m.param().get("rC").replace("[m]", ""));
    double aL = Double.parseDouble(m.param().get("aL").replace("[m]", ""));
    double bL = Double.parseDouble(m.param().get("bL").replace("[m]", ""));
    double xL = Double.parseDouble(m.param().get("xL").replace("[m]", ""));
    double xC = Double.parseDouble(m.param().get("xC").replace("[m]", ""));
    double yL = Double.parseDouble(m.param().get("yL").replace("[m]", ""));
    double sigB = Double.parseDouble(m.param().get("sig_b").replace("[S/m]", ""));
    double sig10 = Double.parseDouble(m.param().get("sig_l10").replace("[S/m]", ""));
    double sig50 = Double.parseDouble(m.param().get("sig_l50").replace("[S/m]", ""));
    double epsr = Double.parseDouble(m.param().get("eps_r"));
    // COMSOL range(start, step, stop) here means 10 kHz and 50 kHz.
    double[] freqs = new double[]{10000.0, 50000.0};
    int[] boundaryIds = new int[]{20,22,26,32,34,36,38,37,35,33,31,25,21,19,17,18};

    double[][] xy = new double[2][16];
    for (int k=0; k<16; k++) {
      double ang = 2.0*Math.PI*(k+0.5)/16.0;
      // Sample just inside the electrode arc so interpolation remains defined.
      xy[0][k] = 0.999999*R*Math.cos(ang); xy[1][k] = 0.999999*R*Math.sin(ang);
    }
    NumericalFeature n = m.result().numerical().create("eitExport", "Interp");
    n.set("expr", new String[]{"V"}); n.setInterpolationCoordinates(xy);
    double[][][] vr = n.getData(); double[][][] vi = n.getImagData();
    int nsol = Math.min(freqs.length, vr.length > 0 ? vr[0].length : 0);
    PrintWriter ev = new PrintWriter(new OutputStreamWriter(new FileOutputStream(out+"\\electrode_voltage_complex.csv"), "UTF-8"));
    ev.println("frequency_hz,electrode_id,angle_deg,boundary_id,x_m,y_m,voltage_real_V,voltage_imag_V,voltage_abs_V,voltage_phase_rad");
    for (int s=0; s<nsol; s++) for (int k=0; k<16; k++) {
      double re=vr[0][s][k], im=vi[0][s][k], ang=360.0*(k+0.5)/16.0;
      ev.println(freqs[s]+","+(k+1)+","+ang+","+boundaryIds[k]+","+xy[0][k]+","+xy[1][k]+","+re+","+im+","+Math.hypot(re,im)+","+Math.atan2(im,re));
    }
    ev.close();

    // Optional field export for QA only; it is explicitly not a measurement input.
    int N=128, count=0; for(int j=0;j<N;j++){double y=-R+2*R*j/(N-1.0);for(int i=0;i<N;i++){double x=-R+2*R*i/(N-1.0);if(x*x+y*y<=R*R)count++;}}
    double[][] gxy=new double[2][count]; int q=0; for(int j=0;j<N;j++){double y=-R+2*R*j/(N-1.0);for(int i=0;i<N;i++){double x=-R+2*R*i/(N-1.0);if(x*x+y*y<=R*R){gxy[0][q]=x;gxy[1][q]=y;q++;}}}
    NumericalFeature nf=m.result().numerical().create("fieldExport","Interp");nf.set("expr",new String[]{"V"});nf.setInterpolationCoordinates(gxy);double[][][] fr=nf.getData(), fi=nf.getImagData();
    PrintWriter fp=new PrintWriter(new OutputStreamWriter(new FileOutputStream(out+"\\potential_field_nodes.csv"),"UTF-8"));fp.println("frequency_hz,x_m,y_m,potential_real_V,potential_imag_V");q=0;for(int j=0;j<N;j++){double y=-R+2*R*j/(N-1.0);for(int i=0;i<N;i++){double x=-R+2*R*i/(N-1.0);if(x*x+y*y<=R*R){for(int s=0;s<nsol;s++)fp.println(freqs[s]+","+x+","+y+","+fr[0][s][q]+","+fi[0][s][q]);q++;}}}fp.close();

    PrintWriter meta=new PrintWriter(new OutputStreamWriter(new FileOutputStream(out+"\\comsol_model_metadata.json"),"UTF-8"));
    meta.println("{"); meta.println("  \"source_mph\": \""+in.replace("\\","\\\\")+"\","); meta.println("  \"generator\": \"COMSOL Multiphysics 6.3.0.290\",");
    meta.println("  \"dimension\": 2, \"domain_radius_m\": "+R+","); meta.println("  \"grid_size\": "+N+",");
    meta.println("  \"frequencies_hz\": [10000, 50000],"); meta.println("  \"electrodes\": 16,");
    meta.println("  \"electrode_boundary_ids\": "+Arrays.toString(boundaryIds).replace(" ","")+",");
    meta.println("  \"drive_protocol\": {\"type\": \"current_terminal_CEM\", \"drive_electrode\": 1, \"ground_electrode\": 2, \"current_A\": 0.001, \"other_terminal_currents_A\": 0.0},");
    meta.println("  \"geometry\": {\"background_circle_radius_m\": "+R+", \"electrode_inner_radius_m\": "+r0+", \"lesion\": {\"type\": \"ellipse_minus_circle\", \"ellipse_center_m\": ["+xL+","+yL+"], \"ellipse_semiaxes_m\": ["+aL+","+bL+"], \"cutout_center_m\": ["+xC+","+yL+"], \"cutout_radius_m\": "+rC+"}},");
    meta.println("  \"conductivity_S_per_m\": {\"background\": "+sigB+", \"lesion_10kHz\": "+sig10+", \"lesion_50kHz\": "+sig50+"},");
    meta.println("  \"relative_permittivity\": "+epsr+","); meta.println("  \"voltage_file\": \"electrode_voltage_complex.csv\","); meta.println("  \"voltage_sampling\": \"V at 0.999999*R near each electrode arc midpoint (terminal-voltage proxy)\","); meta.println("  \"potential_field_file\": \"potential_field_nodes.csv\",");
    meta.println("  \"input_warning\": \"Use electrode_voltage_complex.csv for EIT input. potential_field_nodes.csv is internal FEM field for visualization/QA only and must not be fed to a reconstruction network.\""); meta.println("}"); meta.close();
    System.out.println("exported frequencies="+nsol+" electrodes=16 field_nodes="+count+" out="+out);
    ModelUtil.clear(); System.exit(0);
  }
}
