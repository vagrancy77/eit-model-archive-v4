"""Make a compact visual check of the paired EIT + ultrasound sample."""
from pathlib import Path
import csv
import numpy as np
import matplotlib.pyplot as plt

root = Path(__file__).resolve().parent
eit = np.load(root / "eit_voltage_matrix.npz")["voltage"]
rows = []
with (root / "ultrasound_pressure_mesh.csv").open(errors="ignore") as f:
    for line in f:
        if line.startswith("%") or not line.strip(): continue
        if line.lower().startswith("x") or line.lower().startswith("x,"): continue
        try:
            vals = [float(x) for x in line.strip().split(",")]
            if len(vals) >= 5: rows.append(vals)
        except ValueError: pass
arr = np.asarray(rows)
if arr.size == 0: raise RuntimeError("No numeric acoustic rows found")
x,y,pr,pi,pabs = arr[:,0],arr[:,1],arr[:,2],arr[:,3],arr[:,4]
fig, ax = plt.subplots(2, 2, figsize=(11,8.5), constrained_layout=True)
im=ax[0,0].imshow(eit[0],origin="lower",aspect="auto",cmap="viridis"); ax[0,0].set_title("EIT voltage matrix, 10 kHz"); ax[0,0].set_xlabel("measurement electrode"); ax[0,0].set_ylabel("drive pattern"); fig.colorbar(im,ax=ax[0,0],fraction=.046)
im=ax[0,1].imshow(eit[1],origin="lower",aspect="auto",cmap="viridis"); ax[0,1].set_title("EIT voltage matrix, 50 kHz"); ax[0,1].set_xlabel("measurement electrode"); ax[0,1].set_ylabel("drive pattern"); fig.colorbar(im,ax=ax[0,1],fraction=.046)
sc=ax[1,0].scatter(x,y,c=pabs,s=5,cmap="magma"); ax[1,0].set_title("Ultrasound |p|, 50 kHz (COMSOL mesh samples)"); ax[1,0].set_aspect("equal"); ax[1,0].set_xlabel("x (m)"); ax[1,0].set_ylabel("y (m)"); fig.colorbar(sc,ax=ax[1,0],fraction=.046,label="Pa")
ax[1,1].plot(np.arange(1,17),eit[0,0],"o-",label="10 kHz"); ax[1,1].plot(np.arange(1,17),eit[1,0],"s--",label="50 kHz"); ax[1,1].set_title("Pattern 1 boundary voltages"); ax[1,1].set_xlabel("measurement electrode"); ax[1,1].set_ylabel("V"); ax[1,1].grid(alpha=.25); ax[1,1].legend(frameon=False)
fig.suptitle("One paired COMSOL sample: EIT + ultrasound",fontsize=15)
out=root/"sample_eit_us_preview.png"; fig.savefig(out,dpi=180); print(out, "acoustic rows", len(arr), "pabs range", float(np.nanmin(pabs)), float(np.nanmax(pabs)))
