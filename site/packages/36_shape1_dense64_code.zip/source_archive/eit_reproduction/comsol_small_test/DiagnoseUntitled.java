import com.comsol.model.*;
import com.comsol.model.util.*;

/** Solve a copy of Untitled.mph and export diagnostic potential/terminal data. */
public class DiagnoseUntitled {
  static void eval(Model m, String tag, String expr) {
    try {
      m.result().numerical().create(tag, "EvalGlobal");
      m.result().numerical(tag).set("expr", new String[]{expr});
      double[][][] d=m.result().numerical(tag).getData();
      System.out.println("EVAL "+expr+" dims="+d.length+"x"+(d.length>0?d[0].length:0)+"x"+(d.length>0&&d[0].length>0?d[0][0].length:0));
      for(int i=0;i<d.length;i++) for(int j=0;j<d[i].length;j++) System.out.println("  "+java.util.Arrays.toString(d[i][j]));
    } catch(Exception e) { System.out.println("EVAL_FAIL "+expr+" :: "+e); }
  }
  public static void main(String[] args)throws Exception {
    ModelUtil.initStandalone(true);
    String in=args.length>0?args[0]:"C:\\Users\\luandingyu\\Desktop\\Untitled.mph";
    String out=args.length>1?args[1]:"E:\\Codex\\eit_reproduction\\comsol_small_test\\Untitled_diagnostic.mph";
    Model m=ModelUtil.load("d",in);
    System.out.println("Loaded "+in);
    System.out.println("Study features="+java.util.Arrays.toString(m.study("std1").feature().tags()));
    try {m.study("std1").run(); System.out.println("Solved");} catch(Exception e){System.out.println("SOLVE_FAIL "+e);}
    for(String e:new String[]{"ec.V0","ec.I0","ec.I","V","ec.sigma","ec.normE","ec.normJ"}) eval(m,"g"+Math.abs(e.hashCode()),e);
    // A 2-D surface potential plot for every frequency in the frequency sweep.
    try {
      m.result().create("diagPG", "PlotGroup2D");
      m.result("diagPG").create("surf", "Surface");
      m.result("diagPG").feature("surf").set("expr", "V");
      m.result("diagPG").set("looplevel", new String[]{"1"});
      m.result().export().create("diagImg1", "diagPG", "Image");
      m.result().export("diagImg1").set("filename", "E:\\Codex\\eit_reproduction\\comsol_small_test\\Untitled_potential_solution1.png");
      m.result().export("diagImg1").set("width", "1400"); m.result().export("diagImg1").set("height", "1000");
      m.result().export("diagImg1").run();
      m.result("diagPG").set("looplevel", new String[]{"2"});
      m.result().export().create("diagImg2", "diagPG", "Image");
      m.result().export("diagImg2").set("filename", "E:\\Codex\\eit_reproduction\\comsol_small_test\\Untitled_potential_solution2.png");
      m.result().export("diagImg2").set("width", "1400"); m.result().export("diagImg2").set("height", "1000");
      m.result().export("diagImg2").run();
      System.out.println("Exported potential images");
    } catch(Exception e){System.out.println("PLOT_FAIL "+e);e.printStackTrace();}
    try {m.save(out);System.out.println("Saved "+out);} catch(Exception e){System.out.println("SAVE_FAIL "+e);}
    ModelUtil.clear(); System.exit(0);
  }
}
