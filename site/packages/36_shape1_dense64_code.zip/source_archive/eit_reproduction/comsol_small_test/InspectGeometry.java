import com.comsol.model.*;
import com.comsol.model.util.*;
public class InspectGeometry {
 static void val(Object o,String k){
  for(String meth:new String[]{"getString","getDouble","getInt","getBoolean"}) try{Object x=o.getClass().getMethod(meth,String.class).invoke(o,k);System.out.println("    "+k+" "+meth+"="+x);return;}catch(Exception e){}
  try{Object x=o.getClass().getMethod("getStringArray",String.class).invoke(o,k);System.out.println("    "+k+" arr="+java.util.Arrays.toString((String[])x));return;}catch(Exception e){}
  try{Object x=o.getClass().getMethod("getDoubleArray",String.class).invoke(o,k);System.out.println("    "+k+" darr="+java.util.Arrays.toString((double[])x));return;}catch(Exception e){}
 }
 public static void main(String[] a)throws Exception{
  ModelUtil.initStandalone(true);Model m=ModelUtil.load("g",a.length>0?a[0]:"C:\\Users\\luandingyu\\Desktop\\Untitled.mph");
  Object g=m.component("comp1").geom("geom1");
  Object fc=g.getClass().getMethod("feature").invoke(g);
  String[] ft=(String[])fc.getClass().getMethod("tags").invoke(fc);
  for(String tag:ft){Object f=fc.getClass().getMethod("get",String.class).invoke(fc,tag); if(f==null)f=fc.getClass().getMethod(tag).invoke(fc); System.out.println("FEATURE "+tag+" type="+f.getClass().getMethod("getType").invoke(f)+" props="+java.util.Arrays.toString((String[])f.getClass().getMethod("properties").invoke(f)));for(String k:(String[])f.getClass().getMethod("properties").invoke(f))val(f,k);}
  Object mc=m.component("comp1").material(); String[] mt=(String[])mc.getClass().getMethod("tags").invoke(mc);
  for(String tag:mt){Object x=mc.getClass().getMethod("get",String.class).invoke(mc,tag);if(x==null)x=mc.getClass().getMethod(tag).invoke(mc);System.out.println("MAT "+tag+" props="+java.util.Arrays.toString((String[])x.getClass().getMethod("properties").invoke(x)));Object pgc=x.getClass().getMethod("propertyGroup").invoke(x);String[] pgt=(String[])pgc.getClass().getMethod("tags").invoke(pgc);for(String pg:pgt){Object q=pgc.getClass().getMethod("get",String.class).invoke(pgc,pg);if(q==null)q=pgc.getClass().getMethod(pg).invoke(pgc);System.out.println(" GROUP "+pg+" props="+java.util.Arrays.toString((String[])q.getClass().getMethod("properties").invoke(q)));for(String k:(String[])q.getClass().getMethod("properties").invoke(q))val(q,k);}}
  ModelUtil.clear();
 }
}
