import com.comsol.model.*; import com.comsol.model.physics.*; import com.comsol.model.util.*;
public class RunEITPattern {
  static final String DIR="E:\\Codex\\eit_reproduction\\comsol_small_test\\";
  static final int[] OUTER={1,2,3,4,5,6,9,10,15,16,19,20,21,22,23,24};
  public static void main(String[] a)throws Exception{
    int d=Integer.parseInt(a.length>0?a[0]:"0");
    ModelUtil.initStandalone(true); Model m=ModelUtil.load("m",DIR+"comsol_small_test_crescent_eit.mph");
    Physics ec=m.component("comp1").physics("ec");
    ec.feature("pot1").selection().set(new int[]{}); ec.feature("gnd1").selection().set(new int[]{});
    PhysicsFeature term=ec.feature().create("term0","Terminal",1); term.selection().set(new int[]{OUTER[d]}); term.set("TerminalName","drive"); term.set("TerminalType","Voltage"); term.set("V0","1[V]");
    PhysicsFeature g=ec.feature().create("gnd0","Ground",1); g.selection().set(new int[]{OUTER[(d+1)%16]});
    m.study("std1").run();
    m.result().numerical().create("ip","Interp");m.result().numerical("ip").set("expr",new String[]{"V"});double[][]xy=new double[2][16];for(int k=0;k<16;k++){double aa=2*Math.PI*(k+.5)/16;xy[0][k]=.995*Math.cos(aa);xy[1][k]=.995*Math.sin(aa);}m.result().numerical("ip").setInterpolationCoordinates(xy);double[][][]v=m.result().numerical("ip").getData();
    java.io.PrintWriter pw=new java.io.PrintWriter(DIR+"eit_pattern_"+(d+1)+".csv");pw.println("drive_electrode,ground_electrode,measurement_electrode,V_10kHz,V_50kHz");for(int k=0;k<16;k++)pw.println((d+1)+","+(((d+1)%16)+1)+","+(k+1)+","+v[0][0][k]+","+v[0][1][k]);pw.close();System.out.println("pattern "+(d+1)+" done");
    ModelUtil.clear();
    System.exit(0);
  }
}
