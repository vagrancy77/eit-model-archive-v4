import com.comsol.model.*;
import com.comsol.model.util.*;
import java.lang.reflect.*;
public class InspectTables {
  static Object call(Object o,String name,Class<?>[] ts,Object[] vs){try{return o.getClass().getMethod(name,ts).invoke(o,vs);}catch(Exception e){return null;}}
  static void out(String s){System.out.println(s);}
  public static void main(String[] a)throws Exception{
    ModelUtil.initStandalone(true); String path=a.length>0?a[0]:"C:\\Users\\luandingyu\\Desktop\\Untitled.mph";
    Model m=ModelUtil.load("t",path); Object coll=m.result().table();
    out("table collection class="+coll.getClass()); Object tags=call(coll,"tags",new Class<?>[]{},new Object[]{}); out("tables="+java.util.Arrays.deepToString(new Object[]{tags}));
    if(tags instanceof String[]) for(String tag:(String[])tags){Object t=call(coll,"get",new Class<?>[]{String.class},new Object[]{tag}); if(t==null)t=call(coll,tag,new Class<?>[]{},new Object[]{}); out("TABLE "+tag+" obj="+t+" class="+(t==null?null:t.getClass())); if(t==null)continue;
      Object props=call(t,"properties",new Class<?>[]{},new Object[]{}); out(" props="+java.util.Arrays.deepToString(new Object[]{props}));
      for(String k:new String[]{"filename","comments","table","header","data","unit","descr"}){Object x=call(t,"getString",new Class<?>[]{String.class},new Object[]{k});if(x!=null)out(" "+k+"="+x);}
      for(String k:new String[]{"headers","rows","cols","datacol","format","param","probetag"}){Object x=call(t,"getStringArray",new Class<?>[]{String.class},new Object[]{k});if(x!=null)out(" "+k+" array="+java.util.Arrays.toString((String[])x)); Object y=call(t,"getInt",new Class<?>[]{String.class},new Object[]{k});if(y!=null)out(" "+k+" int="+y);}
      try{Object x=t.getClass().getMethod("getTableData",boolean.class).invoke(t,true);String[][] rows=(String[][])x;out(" rows="+rows.length+" cols="+(rows.length>0?rows[0].length:0));for(int i=0;i<Math.min(rows.length,5);i++)out(" row="+java.util.Arrays.toString(rows[i]));}catch(Exception e){out(" getTableData failed "+e);}
      for(Method mm:t.getClass().getMethods()) if(mm.getName().toLowerCase().contains("table")||mm.getName().toLowerCase().contains("data")) out(" method="+mm);
    }
    ModelUtil.clear();
  }
}
