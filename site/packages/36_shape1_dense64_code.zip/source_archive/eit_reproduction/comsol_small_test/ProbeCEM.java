import com.comsol.model.*;
import com.comsol.model.physics.*;
import com.comsol.model.util.*;

public class ProbeCEM {
  public static void main(String[] args) throws Exception {
    ModelUtil.initStandalone(true);
    Model m = ModelUtil.load("m", args.length > 0 ? args[0] : "E:\\Codex\\eit_reproduction\\comsol_small_test\\comsol_small_test_crescent_eit.mph");
    Physics ec = m.component("comp1").physics("ec");
    String[] types = {"Terminal", "FloatingPotential", "ContactImpedance", "ElectricPotential", "Ground"};
    for (String type : types) {
      String tag = "probe_" + type.toLowerCase();
      try {
        PhysicsFeature f = ec.feature().create(tag, type, 1);
        System.out.println(type + " OK props=" + java.util.Arrays.toString(f.properties()));
      } catch (Exception ex) {
        System.out.println(type + " FAIL " + ex);
      }
    }
    ModelUtil.clear();
  }
}
