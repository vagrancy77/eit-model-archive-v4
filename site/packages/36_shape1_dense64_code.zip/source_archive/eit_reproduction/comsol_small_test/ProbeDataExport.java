import com.comsol.model.*; import com.comsol.model.util.*;
public class ProbeDataExport { public static void main(String[] a)throws Exception{
 ModelUtil.initStandalone(true); Model m=ModelUtil.load("m",a.length>0?a[0]:"E:\\Codex\\eit_reproduction\\comsol_small_test\\sample_crescent_eit_us.mph");
 try { ExportFeature e=m.result().export().create("dataProbe","Data"); System.out.println("OK props="+java.util.Arrays.toString(e.properties())); } catch(Exception ex){System.out.println("FAIL "+ex);}
}}
