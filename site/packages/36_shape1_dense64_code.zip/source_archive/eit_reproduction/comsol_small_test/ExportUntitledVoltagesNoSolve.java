import com.comsol.model.*;
import com.comsol.model.util.*;

public class ExportUntitledVoltagesNoSolve {
  public static void main(String[] args)throws Exception{
    ModelUtil.initStandalone(true);
    String in=args.length>0?args[0]:"C:\\Users\\luandingyu\\Desktop\\Untitled.mph";
    String out=args.length>1?args[1]:"E:\\Codex\\eit_reproduction\\comsol_small_test\\Untitled_sampled_V.csv";
    Model m=ModelUtil.load("nv",in);
    double[][] xy=new double[2][16];
    for(int k=0;k<16;k++){double a=2*Math.PI*(k+0.5)/16.;xy[0][k]=.995*Math.cos(a);xy[1][k]=.995*Math.sin(a);}
    m.result().numerical().create("ipNoSolve","Interp");
    m.result().numerical("ipNoSolve").set("expr",new String[]{"V"});
    m.result().numerical("ipNoSolve").setInterpolationCoordinates(xy);
    double[][][] d=m.result().numerical("ipNoSolve").getData();
    System.out.println("dims="+d.length+"x"+(d.length>0?d[0].length:0)+"x"+(d.length>0&&d[0].length>0?d[0][0].length:0));
    java.io.PrintWriter pw=new java.io.PrintWriter(out);pw.println("electrode,angle_deg,V_sol1,V_sol2,V_sol3");
    for(int k=0;k<16;k++){
      double v1=d[0][0][k],v2=d[0].length>1?d[0][1][k]:Double.NaN,v3=d[0].length>2?d[0][2][k]:Double.NaN;
      pw.println((k+1)+","+(360.*(k+.5)/16.)+","+v1+","+v2+","+v3);
      System.out.println("E"+(k+1)+" "+v1+" "+v2+" "+v3);
    }
    pw.close(); ModelUtil.clear(); System.exit(0);
  }
}
