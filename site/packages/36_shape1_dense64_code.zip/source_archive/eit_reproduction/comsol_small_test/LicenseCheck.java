import com.comsol.model.*;
import com.comsol.model.util.*;

public class LicenseCheck {
    public static void main(String[] args) {
        run();
    }

    public static Model run() {
        ModelUtil.initStandalone(true);
        Model model = ModelUtil.create("Model");
        boolean acdc = false;
        boolean acoustics = false;
        try { acdc = ModelUtil.checkoutLicense("ACDC"); } catch (Exception e) { System.out.println("ACDC license check exception: " + e.getMessage()); }
        try { acoustics = ModelUtil.checkoutLicense("ACOUSTICS"); } catch (Exception e) { System.out.println("ACOUSTICS license check exception: " + e.getMessage()); }
        System.out.println("LICENSE_ACDC=" + acdc);
        System.out.println("LICENSE_ACOUSTICS=" + acoustics);
        model.label("license_check.mph");
        return model;
    }
}
