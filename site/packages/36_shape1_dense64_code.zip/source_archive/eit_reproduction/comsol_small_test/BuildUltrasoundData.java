import com.comsol.model.*;
import com.comsol.model.physics.*;
import com.comsol.model.util.*;

/** Generate one acoustic field and export it directly using COMSOL Data export. */
public class BuildUltrasoundData {
  private static final String DIR="E:\\Codex\\eit_reproduction\\comsol_small_test\\";
  private static final String BASE=DIR+"comsol_small_test_crescent_eit.mph";
  private static final int[] OUTER={1,2,3,4,5,6,9,10,15,16,19,20,21,22,23,24};
  public static void main(String[] args)throws Exception{
    ModelUtil.initStandalone(true); System.out.println("US init"); System.out.flush();
    Model m=ModelUtil.load("m",BASE); System.out.println("US loaded"); System.out.flush();
    Physics ac=m.component("comp1").physics().create("acpr","PressureAcoustics","geom1");
    Material bg=m.component("comp1").material().create("matAcBg","Common"); bg.selection().set(new int[]{1}); bg.propertyGroup("def").set("density","1000[kg/m^3]"); bg.propertyGroup("def").set("soundspeed","1500[m/s]");
    Material le=m.component("comp1").material().create("matAcLesion","Common"); le.selection().set(new int[]{2}); le.propertyGroup("def").set("density","1050[kg/m^3]"); le.propertyGroup("def").set("soundspeed","1560[m/s]");
    PhysicsFeature src=ac.feature().create("usSource","Pressure",1); src.selection().set(new int[]{OUTER[0]}); src.set("p0","1[Pa]");
    m.component("comp1").mesh("mesh1").autoMeshSize(8);
    m.study().create("stdUS"); m.study("stdUS").create("freqUS","Frequency"); m.study("stdUS").feature("freqUS").set("plist","50[kHz]");
    try{m.study("stdUS").feature("freqUS").set("activate",new String[]{"ec","off","acpr","on"});}catch(Exception ignored){}
    System.out.println("Running acoustic study"); System.out.flush(); m.study("stdUS").run(); System.out.println("Acoustic solved"); System.out.flush();
    System.out.println("datasets="+java.util.Arrays.toString(m.result().dataset().tags()));
    System.out.println("creating data export"); System.out.flush(); ExportFeature ex=m.result().export().create("usData","Data"); System.out.println("data export created"); System.out.flush();
    try{ex.set("data","dset2");}catch(Exception e){System.out.println("dset2 unavailable: "+e);}
    ex.set("expr",new String[]{"real(p)","imag(p)","abs(p)"}); ex.set("exporttype","text"); ex.set("filename",DIR+"ultrasound_pressure_mesh.csv"); ex.set("includecoords",true); ex.set("showheader",true);
    System.out.println("Exporting acoustic grid"); System.out.flush(); ex.run(); System.out.println("Acoustic grid exported");
    try{m.result().create("pgUS","PlotGroup2D");m.result("pgUS").create("surfUS","Surface");m.result("pgUS").feature("surfUS").set("expr","abs(p)");m.result().export().create("imgUS","pgUS","Image");m.result().export("imgUS").set("filename",DIR+"ultrasound_pressure_50kHz.png");m.result().export("imgUS").set("width","800");m.result().export("imgUS").set("height","600");m.result().export("imgUS").run();System.out.println("Acoustic image exported");}catch(Exception e){System.out.println("image warning="+e);}
    m.save(DIR+"sample_crescent_eit_us.mph"); java.io.PrintWriter meta=new java.io.PrintWriter(DIR+"sample_metadata.json");meta.println("{\"sample_id\":\"crescent_001\",\"eit_matrix\":\"eit_voltage_matrix.npz\",\"ultrasound_frequency_hz\":50000,\"ultrasound_grid\":\"11x11 COMSOL Data export\",\"geometry\":\"unit circle with ellipse-difference crescent\",\"note\":\"EIT is ideal voltage-drive smoke data; ultrasound is 2-D pressure acoustics with lesion rho=1050 kg/m3,c=1560 m/s and background rho=1000 kg/m3,c=1500 m/s.\"}");meta.close();
    System.out.println("saved combined sample"); ModelUtil.clear(); System.exit(0);
  }
}
