import com.comsol.model.*; import com.comsol.model.util.*;
public class InspectParamsFixed { public static void main(String[] a)throws Exception{ModelUtil.initStandalone(true);Model m=ModelUtil.load("p",a.length>0?a[0]:"C:\\Users\\luandingyu\\Desktop\\Untitled.mph"); String[] k={"R","r0","rC","aL","bL","xL","xC","yL","sig_b","sig_l10","sig_l50","eps_r","freq","I0"};for(String x:k)try{System.out.println(x+"="+m.param().get(x));}catch(Exception e){System.out.println(x+"=<missing>");}ModelUtil.clear();}}

