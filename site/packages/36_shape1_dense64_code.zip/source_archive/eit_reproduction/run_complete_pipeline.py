from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the complete 2D CEM, nonlinear and neural EIT workflow."
    )
    parser.add_argument(
        "--quick",
        action="store_true",
        help="Use a small dataset and short neural training for a smoke test.",
    )
    parser.add_argument("--skip-base", action="store_true")
    parser.add_argument("--skip-nonlinear", action="store_true")
    parser.add_argument("--skip-dataset", action="store_true")
    parser.add_argument("--skip-training", action="store_true")
    return parser.parse_args()


def run_stage(project_root: Path, label: str, arguments: list[str]) -> None:
    print(f"\n=== {label} ===", flush=True)
    subprocess.run(
        [sys.executable, *arguments],
        cwd=project_root,
        check=True,
    )


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    arguments = parse_arguments()
    project_root = Path(__file__).resolve().parent
    if not arguments.skip_base:
        run_stage(project_root, "Linear CEM pipeline", ["run_basic_eit.py"])
    if not arguments.skip_nonlinear:
        nonlinear_arguments = ["run_nonlinear_eit.py"]
        if arguments.quick:
            nonlinear_arguments += ["--iterations", "5"]
        run_stage(project_root, "Nonlinear absolute EIT", nonlinear_arguments)
    if not arguments.skip_dataset:
        dataset_arguments = ["generate_eit_dataset.py"]
        if arguments.quick:
            dataset_arguments += ["--samples", "128"]
        run_stage(project_root, "Synthetic nonlinear CEM dataset", dataset_arguments)
    if not arguments.skip_training:
        training_arguments = ["train_neural_eit.py"]
        if arguments.quick:
            training_arguments += [
                "--hidden-units",
                "48",
                "--epochs",
                "50",
                "--patience",
                "10",
            ]
        run_stage(project_root, "Neural EIT training", training_arguments)
        run_stage(
            project_root,
            "Single-frame inference",
            [
                "predict_neural_eit.py",
                "outputs/voltages.csv",
                "--csv-column",
                "noisy",
            ],
        )
    run_stage(
        project_root,
        "Automated tests",
        ["-m", "unittest", "discover", "-s", "tests", "-v"],
    )
    run_stage(
        project_root,
        "Artifact validation",
        ["scripts/validate_complete_project.py"],
    )

    artifact_paths = [
        project_root / "outputs" / "simulation_data.npz",
        project_root / "outputs_fenicsx" / "fenicsx_results.npz",
        project_root / "outputs_nonlinear" / "nonlinear_results.npz",
        project_root / "datasets" / "synthetic_cem_v1.npz",
        project_root / "models" / "residual_mlp_v1.npz",
        project_root / "outputs_neural" / "neural_test_predictions.npz",
        project_root / "external" / "GN4IP" / "data" / "training_data_v0.mat",
        project_root / "external" / "GN4IP" / "data" / "test_data_v0.mat",
        project_root / "external" / "GN4IP" / "data" / "conv_unet_model.pt",
        project_root / "datasets" / "cem_gn4ip_v1.mat",
        project_root / "outputs_gn4ip" / "gn4ip_reproduction.npz",
        project_root / "outputs_gn4ip" / "local_cem" / "model_state.pt",
        project_root / "outputs_gn4ip" / "local_cem" / "results.npz",
        project_root / "datasets" / "multimodal_cem_v1.npz",
        project_root / "datasets" / "public_us_eit" / "Supplementary_Files.zip",
        project_root / "datasets" / "public_us_eit" / "public_us_eit_v1.npz",
        project_root / "outputs_pytorch_multimodal" / "model.pt",
        project_root / "outputs_pytorch_multimodal" / "summary.json",
        project_root / "outputs_public_us_eit" / "predictions.npz",
        project_root / "outputs_public_us_eit" / "summary.json",
    ]
    existing_artifacts = [path for path in artifact_paths if path.exists()]
    manifest = {
        "pipeline": "complete 2D CEM EIT",
        "python": sys.version,
        "quick_mode": arguments.quick,
        "artifacts": [
            {
                "path": str(path.relative_to(project_root)),
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
            }
            for path in existing_artifacts
        ],
    }
    output_directory = project_root / "outputs_complete"
    output_directory.mkdir(parents=True, exist_ok=True)
    with (output_directory / "manifest.json").open(
        "w",
        encoding="utf-8",
    ) as handle:
        json.dump(manifest, handle, ensure_ascii=False, indent=2)
    print("\nComplete pipeline finished successfully.")
    print(f"Manifest: {(output_directory / 'manifest.json').resolve()}")


if __name__ == "__main__":
    main()
