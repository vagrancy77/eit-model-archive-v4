from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.tri as mtri
import numpy as np
import pyeit.eit.protocol as protocol
from pyeit.mesh.wrapper import PyEITMesh

from eit_basic.cem import CEMForward
from eit_basic.nonlinear import NonlinearEITConfig, solve_absolute_eit


def parse_arguments() -> argparse.Namespace:
    project_root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(
        description="Run nonlinear absolute CEM-EIT reconstruction."
    )
    parser.add_argument(
        "--input",
        type=Path,
        default=project_root / "outputs" / "simulation_data.npz",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=project_root / "outputs_nonlinear",
    )
    parser.add_argument("--iterations", type=int, default=30)
    parser.add_argument("--tv-weight", type=float, default=1e-4)
    parser.add_argument("--l2-weight", type=float, default=1e-4)
    parser.add_argument("--tv-epsilon", type=float, default=1e-3)
    parser.add_argument("--lm-damping", type=float, default=1e-2)
    parser.add_argument("--minimum-conductivity", type=float, default=0.05)
    parser.add_argument("--maximum-conductivity", type=float, default=3.0)
    parser.add_argument("--electrode-width", type=float, default=2.5 / 14.0)
    parser.add_argument("--contact-impedance", type=float, default=0.01)
    parser.add_argument("--current-amplitude", type=float, default=1.0)
    return parser.parse_args()


def safe_correlation(first: np.ndarray, second: np.ndarray) -> float:
    if np.std(first) == 0.0 or np.std(second) == 0.0:
        return float("nan")
    return float(np.corrcoef(first, second)[0, 1])


def save_figure(
    saved: np.lib.npyio.NpzFile,
    conductivity: np.ndarray,
    predicted_voltage: np.ndarray,
    history,
    output: Path,
) -> None:
    nodes = saved["inverse_nodes"][:, :2]
    elements = saved["inverse_elements"][:, :3]
    triangulation = mtri.Triangulation(nodes[:, 0], nodes[:, 1], elements)
    truth = saved["conductivity_true_inverse"]
    linear = 1.0 + saved["reconstruction_delta"]
    values = np.concatenate([truth, linear, conductivity])
    vmin, vmax = float(np.min(values)), float(np.max(values))

    figure, axes = plt.subplots(2, 3, figsize=(15, 9), constrained_layout=True)
    for axis, field, title in zip(
        axes[0],
        [truth, linear, conductivity],
        ["Ground truth", "Linear difference EIT", "Nonlinear absolute EIT"],
        strict=True,
    ):
        image = axis.tripcolor(
            triangulation,
            facecolors=field,
            shading="flat",
            cmap="viridis",
            vmin=vmin,
            vmax=vmax,
        )
        axis.set_title(title)
        axis.set_aspect("equal")
        axis.set_axis_off()
        plt.colorbar(image, ax=axis, fraction=0.046, pad=0.04)

    iterations = np.array([record.iteration for record in history])
    objectives = np.array([record.objective for record in history])
    voltage_errors = np.array(
        [record.relative_voltage_error for record in history]
    )
    axes[1, 0].semilogy(iterations, objectives, marker="o")
    axes[1, 0].set_title("Nonlinear objective")
    axes[1, 0].set_xlabel("Iteration")
    axes[1, 0].grid(alpha=0.25)

    axes[1, 1].semilogy(iterations, voltage_errors, marker="o")
    axes[1, 1].set_title("Relative voltage error")
    axes[1, 1].set_xlabel("Iteration")
    axes[1, 1].grid(alpha=0.25)

    measured = saved["voltage_noisy"]
    axes[1, 2].plot(measured, label="Measured", linewidth=1.2)
    axes[1, 2].plot(
        predicted_voltage,
        "--",
        label="Nonlinear prediction",
        linewidth=1.0,
    )
    axes[1, 2].set_title("Absolute boundary voltages")
    axes[1, 2].set_xlabel("Measurement index")
    axes[1, 2].grid(alpha=0.25)
    axes[1, 2].legend()
    figure.savefig(output, dpi=180)
    plt.close(figure)


def main() -> None:
    arguments = parse_arguments()
    saved = np.load(arguments.input)
    inverse_mesh = PyEITMesh(
        node=saved["inverse_nodes"],
        element=saved["inverse_elements"],
        perm=np.ones(saved["inverse_elements"].shape[0]),
        el_pos=saved["inverse_electrode_nodes"],
    )
    protocol_object = protocol.create(
        n_el=saved["inverse_electrode_nodes"].size,
        dist_exc=1,
        step_meas=1,
        parser_meas="std",
    )
    np.testing.assert_array_equal(
        protocol_object.ex_mat,
        saved["excitation_matrix"],
    )
    np.testing.assert_array_equal(
        protocol_object.meas_mat,
        saved["measurement_matrix"],
    )
    solver = CEMForward(
        inverse_mesh,
        protocol_object,
        electrode_width=arguments.electrode_width,
        contact_impedance=arguments.contact_impedance,
        current_amplitude=arguments.current_amplitude,
    )
    settings = NonlinearEITConfig(
        max_iterations=arguments.iterations,
        tv_weight=arguments.tv_weight,
        l2_weight=arguments.l2_weight,
        tv_epsilon=arguments.tv_epsilon,
        lm_damping=arguments.lm_damping,
        min_conductivity=arguments.minimum_conductivity,
        max_conductivity=arguments.maximum_conductivity,
    )

    print("Running log-conductivity Gauss-Newton + TV reconstruction...")

    def report(record, _conductivity) -> None:
        print(
            f"  iter={record.iteration:02d} "
            f"objective={record.objective:.6e} "
            f"voltage_error={record.relative_voltage_error:.4e} "
            f"step={record.step_length:.3f} "
            f"sigma=[{record.min_conductivity:.3f}, "
            f"{record.max_conductivity:.3f}]",
            flush=True,
        )

    result = solve_absolute_eit(
        solver,
        measured_voltage=saved["voltage_noisy"],
        initial_conductivity=np.ones(inverse_mesh.n_elems),
        nodes=inverse_mesh.node,
        elements=inverse_mesh.element,
        config=settings,
        callback=report,
    )

    arguments.output_dir.mkdir(parents=True, exist_ok=True)
    history_columns = {
        field: np.array([getattr(record, field) for record in result.history])
        for field in (
            "iteration",
            "objective",
            "data_objective",
            "tv_objective",
            "l2_objective",
            "relative_voltage_error",
            "relative_step_norm",
            "step_length",
            "damping",
            "min_conductivity",
            "max_conductivity",
        )
    }
    np.savez_compressed(
        arguments.output_dir / "nonlinear_results.npz",
        conductivity=result.conductivity,
        conductivity_delta=result.conductivity - 1.0,
        predicted_voltage=result.predicted_voltage,
        truth_conductivity=saved["conductivity_true_inverse"],
        linear_reconstruction=saved["reconstruction_delta"],
        **history_columns,
    )
    with (arguments.output_dir / "history.csv").open(
        "w",
        newline="",
        encoding="utf-8",
    ) as handle:
        writer = csv.writer(handle)
        writer.writerow(history_columns.keys())
        writer.writerows(zip(*history_columns.values(), strict=True))

    truth = saved["conductivity_true_inverse"]
    linear_conductivity = 1.0 + saved["reconstruction_delta"]
    summary = {
        "stage": "nonlinear absolute CEM EIT",
        "algorithm": "log-conductivity Gauss-Newton + TV-IRLS + LM line search",
        "converged": result.converged,
        "stop_reason": result.stop_reason,
        "iterations_completed": len(result.history),
        "strictly_positive": bool(np.all(result.conductivity > 0.0)),
        "conductivity_range": [
            float(np.min(result.conductivity)),
            float(np.max(result.conductivity)),
        ],
        "relative_voltage_error": float(
            np.linalg.norm(result.predicted_voltage - saved["voltage_noisy"])
            / np.linalg.norm(saved["voltage_noisy"])
        ),
        "linear_truth_correlation": safe_correlation(
            truth,
            linear_conductivity,
        ),
        "nonlinear_truth_correlation": safe_correlation(
            truth,
            result.conductivity,
        ),
        "config": settings.__dict__,
    }
    with (arguments.output_dir / "summary.json").open(
        "w",
        encoding="utf-8",
    ) as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    save_figure(
        saved,
        result.conductivity,
        result.predicted_voltage,
        result.history,
        arguments.output_dir / "nonlinear_reconstruction.png",
    )

    print("Nonlinear absolute EIT completed.")
    print(f"  Stop reason: {result.stop_reason}")
    print(
        "  Conductivity range: "
        f"[{np.min(result.conductivity):.4f}, "
        f"{np.max(result.conductivity):.4f}]"
    )
    print(
        "  Linear/nonlinear truth correlation: "
        f"{summary['linear_truth_correlation']:.4f} / "
        f"{summary['nonlinear_truth_correlation']:.4f}"
    )
    print(f"  Outputs: {arguments.output_dir.resolve()}")


if __name__ == "__main__":
    main()
