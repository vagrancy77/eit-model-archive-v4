# 面向内凹边界重建的拓扑安全 EIT：最终 CPU 实验报告

## 1. 工程状态

本阶段的数据生成、模型训练、失败分支审计、冻结策略选择、独立细胞样测试、KTC 公开基准评估、bootstrap 统计和病例可视化均已完成。

- Python：`C:\Users\luandingyu\AppData\Local\Programs\Python\Python313\python.exe`
- PyTorch：`2.13.0+cpu`
- 计算设备：CPU，最终结果没有使用 CUDA
- 最终结果目录：`E:\Codex\ktc_topology_safe_final_cpu`
- 最终评估脚本：`scripts/evaluate_ktc_topology_safe_final.py`
- 论文图汇总脚本：`scripts/summarize_ktc_topology_safe_final.py`

## 2. 最终方法

最终方法不是在整幅图上选择 vanilla 或 shape-aware 网络，而是使用 vanilla 网络保护主体，只允许 shape-aware 网络提出局部向内删除：

1. shape-aware U-Net 同时预测分割、signed distance field 和电导率变化，并使用边界、凹口误填充和 Jacobian 物理一致性损失；
2. vanilla U-Net 提供稳定的普通重建及像素置信度；
3. 只有 shape 专家高置信、与 vanilla 差异足够大且 vanilla 本身不高置信的局部删除候选才进入下一步；
4. 候选必须与外部背景连通；
5. 候选按连通块逐块接受，接受后前景连通分量数和孔洞数必须与 vanilla 一致；
6. 单病例最多删除 vanilla 前景的 1%，禁止 shape 网络向外新增前景。

冻结参数为：

```text
remove_threshold       = 0.94
remove_margin          = 0.35
vanilla_confidence_cap = 0.88
max_remove_fraction    = 0.01
add_threshold          = inf
dilation               = 2
```

这些参数来自合成 validation、独立细胞样 development 和 4 个官方普通校准病例。最终评估脚本没有使用 21 个 KTC 公开病例的真值选择参数。

需要保留一个严格限定：KTC 病例在此前方法探索中已被观察过，所以它们是公开基准评估，不能再称为完全未见测试。三个细胞样测试种子是新生成的，但其形状生成器家族已参与方法开发。

## 3. 数据与评估隔离

基础合成集 `datasets/ktc_shape_nonlinear_v1.npz` 含 3000 个 nonlinear-CEM 样本，固定为：

| 划分 | 样本数 | 用途 |
|---|---:|---|
| train | 2160 | vanilla 与 shape-aware 网络训练 |
| validation | 420 | checkpoint 和候选规则开发 |
| test | 420 | 原分布评估 |
| 官方普通校准 | 4 | 普通病例安全门槛，不用于证明泛化 |
| KTC 公开基准 | 21 | 冻结策略后的公开基准评估 |

最终域外细胞样测试使用种子 `20263001`、`20263002`、`20263003`，每个种子 420 例，共 1260 例；其中内凹 566 例，普通 694 例。

## 4. 失败分支与保留理由

### 病例级二选一门控

严格 OOF 门控在合成域可以判断何时启用 shape 网络，但在 KTC 域发生明显偏移，会把部分普通病例错误切换到 shape 网络，因此已否决。

### 直接 shape-aware 输出

shape 专家在 KTC 9 个严格内凹病例上将 notch preservation 从 `0.38205` 提高到 `0.57421`，但 boundary-F1 从 `0.16491` 降到 `0.15110`，KTC-SSIM 从 `0.55848` 降到 `0.51451`。这证明 shape 分支学到了内凹信号，但不能作为全局最终输出。

### 局部融合 V1/V2/V3

- V1 的安全条件过严，最终零修改；
- V2 的内凹改动更强，但独立细胞样普通病例有 `45/237` 发生 IoU 下降超过 0.01；
- V3 加入细胞样开发集，受损降至 `9/231`，但仍不满足最终安全目标；
- 最终版本进一步限制候选强度和删除比例，在 694 个新普通病例中只剩 `2` 例下降超过 0.01。

### 细胞样微调

使用 1200 个新细胞样样本、800 个原分布样本、vanilla 教师蒸馏和 4 个官方普通病例保护，冻结编码器并微调网络末端。训练后的权重会改善部分细胞样指标，但无法同时通过原分布、普通校准和 notch 硬门槛。最终 checkpoint 选择 epoch 0，即拒绝所有微调权重，没有污染最终模型。

## 5. 最终结果

### 5.1 全新细胞样测试

| 子组/指标 | Vanilla | 最终安全融合 | 配对差 | 95% CI |
|---|---:|---:|---:|---:|
| 内凹 IoU，n=566 | 0.787625 | 0.787818 | +0.000194 | [+0.000004, +0.000391] |
| 内凹 boundary-F1 | 0.879033 | 0.879136 | +0.000103 | [-0.000331, +0.000545] |
| 内凹 notch preservation | 0.353667 | 0.355236 | +0.001569 | [+0.000603, +0.002857] |
| 内凹 concavity score | 0.469186 | 0.470523 | +0.001337 | [+0.000448, +0.002540] |
| 普通 IoU，n=694 | 0.842936 | 0.843069 | +0.000133 | [-0.000029, +0.000295] |

安全审计：

- 共修改 `146/1260` 个病例；
- `13/566` 个内凹病例的 notch preservation 真正提高；
- `2/694` 个普通病例的 IoU 下降超过 0.01；
- 前景连通分量数或孔洞数改变：`0/1260`。

### 5.2 KTC 公开基准

| 子组/指标 | Vanilla | 最终安全融合 | 配对差 | 95% CI |
|---|---:|---:|---:|---:|
| 严格内凹 IoU，n=9 | 0.534350 | 0.534798 | +0.000448 | [-0.001270, +0.001862] |
| 严格内凹 boundary-F1 | 0.164909 | 0.164870 | -0.000039 | [-0.008746, +0.006736] |
| 严格内凹 notch preservation | 0.382049 | 0.384842 | +0.002794 | [0.000000, +0.008214] |
| 严格内凹 concavity score | 0.395212 | 0.398540 | +0.003328 | [+0.000242, +0.009089] |
| 普通 IoU，n=12 | 0.562819 | 0.565872 | +0.003053 | [+0.001564, +0.004612] |

安全审计：

- 共修改 `13/21` 个病例；
- `2/9` 个严格内凹病例的 notch preservation 提高；
- 普通病例 IoU 下降超过 0.01：`0/12`；
- 前景连通分量数或孔洞数改变：`0/21`。

## 6. 结论边界

当前证据可以支持：

> 高置信度 shape 专家提出的外部连通局部修正，在 vanilla 置信度保护和严格拓扑约束下，能够小幅但稳定地提高内凹趋势指标，同时基本维持普通病例性能。

当前证据不能支持：

> 方法已经显著、普遍并且肉眼明显地恢复深内凹边界。

原因不是统计流程未闭合，而是最终安全策略通常只接受 2 到数个像素的删除。它避免了普通病例退化，却把 shape 专家的强内凹收益大部分阻断。现有结果适合作为可信的负结果和下一版方法的基线，但效应量不足以单独支撑题为“已解决内凹边界重建”的强论文主结论。

若继续追求强论文结果，下一步应把实例级凹口入口、方向、两侧 bank 和深度作为可学习变量，并在训练期同时约束 bank retention，而不是继续调后处理阈值。

## 7. 输出文件

- `E:\Codex\ktc_topology_safe_final_cpu\paper_metrics_summary.png`：论文式统计总图；
- `E:\Codex\ktc_topology_safe_final_cpu\ktc_strict_inward_all.png`：KTC 9 个严格内凹病例逐例对比；
- `E:\Codex\ktc_topology_safe_final_cpu\biological_preregistered_examples.png`：固定顺序的细胞样病例；
- `E:\Codex\ktc_topology_safe_final_cpu\biological_largest_notch_recovery.png`：最大 notch 改善病例；
- `E:\Codex\ktc_topology_safe_final_cpu\summary.json`：全部汇总和 bootstrap 结果；
- `E:\Codex\ktc_topology_safe_final_cpu\ktc_case_metrics.csv`：KTC 逐例指标；
- `E:\Codex\ktc_topology_safe_final_cpu\biological_case_metrics.csv`：1260 个细胞样病例逐例指标；
- `E:\Codex\ktc_topology_safe_final_cpu\biological_concave_notch_improved_cases.csv`：13 个真实改善病例；
- `E:\Codex\ktc_topology_safe_final_cpu\biological_ordinary_harmed_cases.csv`：2 个普通受损病例。

## 8. 可复现命令

```powershell
& 'C:\Users\luandingyu\AppData\Local\Programs\Python\Python313\python.exe' `
  'E:\Codex\eit_reproduction\scripts\evaluate_ktc_topology_safe_final.py'

& 'C:\Users\luandingyu\AppData\Local\Programs\Python\Python313\python.exe' `
  'E:\Codex\eit_reproduction\scripts\summarize_ktc_topology_safe_final.py'
```
