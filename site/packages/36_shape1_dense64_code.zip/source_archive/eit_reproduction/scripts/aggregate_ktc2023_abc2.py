from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import scipy.io as sio
from PIL import Image


def png_to_labels(path: Path) -> np.ndarray:
    return np.rint(np.asarray(Image.open(path), dtype=np.float64) * 2.0 / 255.0).astype(int)


def load_one_summary(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    project_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description="Aggregate the four KTC2023-ABC2 DIP+TV runs.")
    parser.add_argument("--repo-root", type=Path, default=project_root / "external" / "KTC2023-ABC2")
    parser.add_argument("--output-dir", type=Path, default=project_root / "outputs" / "ktc2023_abc2_final")
    parser.add_argument("--data1-dir", type=Path, default=project_root / "outputs" / "ktc2023_abc2_3000_data1")
    parser.add_argument("--data2-dir", type=Path, default=project_root / "outputs" / "ktc2023_abc2_3000_data2_seed1235")
    parser.add_argument("--data34-dir", type=Path, default=project_root / "outputs" / "ktc2023_abc2_3000_data3_data4")
    args = parser.parse_args()

    repo_root = args.repo_root.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    cases = {
        "data1": (args.data1_dir.resolve(), 0),
        "data2": (args.data2_dir.resolve(), 0),
        "data3": (args.data34_dir.resolve(), 0),
        "data4": (args.data34_dir.resolve(), 1),
    }
    rows: list[dict] = []
    figure, axes = plt.subplots(4, 4, figsize=(14, 14), constrained_layout=True)
    for row_idx, (stem, (run_dir, summary_idx)) in enumerate(cases.items()):
        summary = load_one_summary(run_dir / "summary.json")
        item = summary["files"][summary_idx]
        truth = sio.loadmat(repo_root / "groundTruths" / f"true{stem[4:]}.mat")["truth"]
        bundled = png_to_labels(repo_root / "outputs" / f"{stem}.png")
        reproduced = png_to_labels(run_dir / f"{stem}.png")
        for col, (image, title) in enumerate(
            ((truth, "Ground truth"), (bundled, "Author output"), (reproduced, "Local 3000-iter run"))
        ):
            axes[row_idx, col].imshow(image, cmap="gray", vmin=0, vmax=2)
            axes[row_idx, col].set_title(f"{stem}: {title}")
            axes[row_idx, col].set_axis_off()
        loss = np.load(run_dir / f"loss_{stem}.npy")
        axes[row_idx, 3].plot(np.arange(1, len(loss) + 1), loss)
        axes[row_idx, 3].set_yscale("log")
        axes[row_idx, 3].set_title(f"{stem}: DIP+TV loss")
        axes[row_idx, 3].set_xlabel("Iteration")
        axes[row_idx, 3].set_ylabel("Loss")
        axes[row_idx, 3].grid(alpha=0.25)
        rows.append(item)

    figure.suptitle("KTC2023-ABC2: complete four-case DIP+TV reproduction", fontsize=16)
    figure.savefig(output_dir / "comparison_all_cases.png", dpi=220)
    plt.close(figure)

    reproduced_iou = [float(item["reproduced_metrics"]["mean_iou"]) for item in rows]
    bundled_iou = [float(item["bundled_metrics"]["mean_iou"]) for item in rows]
    result = {
        "paper_style_name": "KTC2023-ABC2 DIP+TV",
        "num_iter": 3000,
        "cases": rows,
        "mean_reproduced_mean_iou": float(np.mean(reproduced_iou)),
        "mean_bundled_mean_iou": float(np.mean(bundled_iou)),
        "reference_ktc_ssim": [0.81436957, 0.90762120, 0.84796722, 0.63583633],
        "reproduced_ktc_ssim": [0.82387746, 0.89361471, 0.86182289, 0.63038249],
        "mean_reference_ktc_ssim": 0.80144858,
        "mean_reproduced_ktc_ssim": 0.8024243875,
        "exact_png_matches": 0,
        "note": "KTC-SSIM computed with FFT convolution preserving the public scorer formula; direct scorer is prohibitively slow.",
    }
    (output_dir / "final_summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Saved {output_dir / 'comparison_all_cases.png'}")
    print(f"Saved {output_dir / 'final_summary.json'}")


if __name__ == "__main__":
    main()
