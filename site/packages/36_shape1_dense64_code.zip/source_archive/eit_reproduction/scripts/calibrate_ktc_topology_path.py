"""Open predicted inward cavities through validation-calibrated minimum-cost paths.

The correction is shape agnostic.  It only acts when a reconstruction contains
an enclosed background component and an independently trained aggressive model
assigns sufficient background probability to a short route from that cavity
to the exterior.  Thus a one-pixel bridge can be removed without globally
eroding the two lesion banks.
"""
from __future__ import annotations

import argparse
import heapq
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from scipy.ndimage import binary_dilation, label as connected_components

from fuse_ktc_joint_shape_models import blend, infer_probability, load_model
from train_ktc_concavity_network import InputAdapter
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_implicit_boolean_network import standard_metrics, stress_metrics


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    p.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    p.add_argument("--conservative", type=Path, default=Path("E:/Codex/ktc_joint_shape_pretrained_seed20260820/best.pt"))
    p.add_argument("--aggressive", type=Path, default=Path("E:/Codex/ktc_joint_shape_network_seed20260820/best.pt"))
    p.add_argument("--shape-expert", type=Path, default=Path("E:/Codex/ktc_shape_expert_seed20260820/predictions.npz"))
    p.add_argument("--output-dir", type=Path, default=Path("E:/Codex/ktc_topology_corridor_seed20260820"))
    p.add_argument("--batch-size", type=int, default=32)
    return p.parse_args()


NEIGHBORS = ((-1, 0), (1, 0), (0, -1), (0, 1))


def cavity_path(foreground: np.ndarray, cavity: np.ndarray, exterior: np.ndarray, cost: np.ndarray) -> list[tuple[int, int]]:
    """Dijkstra path from a cavity to external background; returns foreground pixels."""
    height, width = foreground.shape
    distance = np.full((height, width), np.inf, dtype=np.float64)
    parent_y = np.full((height, width), -1, dtype=np.int16)
    parent_x = np.full((height, width), -1, dtype=np.int16)
    queue: list[tuple[float, int, int]] = []
    for y, x in np.argwhere(cavity):
        distance[y, x] = 0.0; heapq.heappush(queue, (0.0, int(y), int(x)))
    target = None
    while queue:
        value, y, x = heapq.heappop(queue)
        if value != distance[y, x]: continue
        if exterior[y, x]: target = (y, x); break
        for dy, dx in NEIGHBORS:
            ny, nx = y + dy, x + dx
            if not (0 <= ny < height and 0 <= nx < width): continue
            step = float(cost[ny, nx]) if foreground[ny, nx] else 0.01
            proposal = value + step
            if proposal < distance[ny, nx]:
                distance[ny, nx] = proposal; parent_y[ny, nx] = y; parent_x[ny, nx] = x
                heapq.heappush(queue, (proposal, ny, nx))
    if target is None: return []
    path = []
    y, x = target
    while parent_y[y, x] >= 0:
        if foreground[y, x]: path.append((y, x))
        y, x = int(parent_y[y, x]), int(parent_x[y, x])
        if cavity[y, x]: break
    return path


def correct_one(
    labels: np.ndarray,
    conservative: np.ndarray,
    aggressive: np.ndarray,
    max_length: int,
    min_background: float,
    min_hole: int,
    corridor_radius: int = 0,
    corridor_background: float = 1.0,
) -> tuple[np.ndarray, int]:
    prediction = labels.copy(); foreground = prediction != 0
    components, count = connected_components(~foreground, structure=np.ones((3, 3), dtype=np.uint8))
    border = np.unique(np.concatenate((components[0], components[-1], components[:, 0], components[:, -1])))
    exterior = np.isin(components, border[border != 0])
    conservative_fg = conservative[1:].sum(axis=0)
    aggressive_fg = aggressive[1:].sum(axis=0)
    cost = 0.10 + 0.45 * conservative_fg + 0.45 * aggressive_fg
    opened = 0
    for component in range(1, count + 1):
        if component in border: continue
        cavity = components == component
        if int(cavity.sum()) < min_hole: continue
        path = cavity_path(foreground, cavity, exterior, cost)
        if not path or len(path) > max_length: continue
        background_evidence = float(np.mean([aggressive[0, y, x] for y, x in path]))
        if background_evidence < min_background: continue
        path_mask = np.zeros_like(foreground)
        for y, x in path: path_mask[y, x] = True
        removal = path_mask
        if corridor_radius > 0:
            corridor = binary_dilation(
                path_mask,
                structure=np.ones((3, 3), dtype=bool),
                iterations=corridor_radius,
            )
            corridor &= foreground
            removal = path_mask | (corridor & (aggressive[0] >= corridor_background))
        prediction[removal] = 0
        foreground = prediction != 0
        exterior |= cavity
        exterior |= removal
        opened += 1
    return prediction, opened


def correct_batch(
    labels: np.ndarray,
    conservative: np.ndarray,
    aggressive: np.ndarray,
    max_length: int,
    min_background: float,
    min_hole: int,
    corridor_radius: int = 0,
    corridor_background: float = 1.0,
) -> tuple[np.ndarray, int]:
    output = np.empty_like(labels); opened = 0
    for i in range(len(labels)):
        output[i], count = correct_one(
            labels[i], conservative[i], aggressive[i], max_length,
            min_background, min_hole, corridor_radius, corridor_background,
        ); opened += count
    return output, opened


def save_grid(path: Path, truth: np.ndarray, raw: np.ndarray, corrected: np.ndarray, ids: np.ndarray, limit: int) -> None:
    count = min(limit, len(truth)); fig, axes = plt.subplots(count, 4, figsize=(10.5, 2.25 * count), squeeze=False)
    for i in range(count):
        for j, image in enumerate((truth[i], raw[i], corrected[i], (raw[i] != corrected[i]).astype(np.uint8))):
            axes[i, j].imshow(image, vmin=0, vmax=2, cmap="viridis"); axes[i, j].axis("off")
        axes[i, 0].set_ylabel(str(ids[i]), fontsize=7)
    for axis, title in zip(axes[0], ("truth", "raw", "path-corrected", "changed pixels")): axis.set_title(title)
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def save_changed_grid(
    path: Path,
    truth: np.ndarray,
    reference: np.ndarray,
    raw: np.ndarray,
    corrected: np.ndarray,
    ids: np.ndarray,
    limit: int = 24,
) -> None:
    changed = np.flatnonzero(np.any(raw != corrected, axis=(1, 2)))
    if len(changed) == 0:
        return
    changed_pixels = np.count_nonzero(raw[changed] != corrected[changed], axis=(1, 2))
    order = np.argsort(changed_pixels)[::-1][:limit]
    changed, changed_pixels = changed[order], changed_pixels[order]
    fig, axes = plt.subplots(len(changed), 5, figsize=(13, 2.7 * len(changed)), squeeze=False)
    for row, index in enumerate(changed):
        images = (
            truth[index], reference[index], raw[index], corrected[index],
            (raw[index] != corrected[index]).astype(np.uint8),
        )
        for column, image in enumerate(images):
            axes[row, column].imshow(image, vmin=0, vmax=2, cmap="viridis", interpolation="nearest")
            axes[row, column].axis("off")
        axes[row, 0].set_ylabel(f"id={ids[index]}\nchanged={changed_pixels[row]}", fontsize=8)
    for axis, title in zip(
        axes[0], ("truth", "shape expert", "raw fusion", "wide correction", "changed pixels")
    ):
        axis.set_title(title)
    fig.tight_layout(); fig.savefig(path, dpi=180); plt.close(fig)


def main() -> None:
    args = parse_args(); out = args.output_dir.resolve(); out.mkdir(parents=True, exist_ok=True)
    base = np.load(args.base_dataset.resolve(), allow_pickle=False); stress = np.load(args.stress_dataset.resolve(), allow_pickle=False); expert = np.load(args.shape_expert.resolve(), allow_pickle=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu"); adapter = InputAdapter(base["fov_mask"]).to(device)
    conservative = load_model(args.conservative, device); aggressive = load_model(args.aggressive, device)
    bv, sv = np.asarray(base["validation_indices"]), np.asarray(stress["validation_indices"])
    bc = infer_probability(conservative, adapter, base["linear_images"][bv], base["voltages"][bv], device, args.batch_size); ba = infer_probability(aggressive, adapter, base["linear_images"][bv], base["voltages"][bv], device, args.batch_size)
    sc = infer_probability(conservative, adapter, stress["linear_images"][sv], stress["voltages"][sv], device, args.batch_size); sa = infer_probability(aggressive, adapter, stress["linear_images"][sv], stress["voltages"][sv], device, args.batch_size)
    candidates = []
    for alpha in (0.0, 0.30, 0.50):
        raw_b, raw_s = blend(bc, ba, alpha), blend(sc, sa, alpha)
        base_ref = standard_metrics(base["labels"][bv], raw_b, base["indentation_masks"][bv]); stress_ref, _, _ = stress_metrics(stress["labels"][sv], raw_s, stress["cutout_masks"][sv], stress["cutout_depth_weights"][sv], stress["family_codes"][sv])
        for length in (1, 2, 3, 4, 5, 6):
            for evidence in (0.10, 0.20, 0.30, 0.40, 0.50):
                bp, bo = correct_batch(raw_b, bc, ba, length, evidence, 3); sp, so = correct_batch(raw_s, sc, sa, length, evidence, 3)
                bm = standard_metrics(base["labels"][bv], bp, base["indentation_masks"][bv]); sm, _, _ = stress_metrics(stress["labels"][sv], sp, stress["cutout_masks"][sv], stress["cutout_depth_weights"][sv], stress["family_codes"][sv])
                eligible = bm["foreground_iou"] >= base_ref["foreground_iou"] - 0.008 and sm["foreground_iou"] >= stress_ref["foreground_iou"] - 0.012 and sm["bank_retention"] >= stress_ref["bank_retention"] - 0.018
                score = 0.20 * bm["foreground_iou"] + 0.18 * sm["foreground_iou"] + 0.30 * sm["open_deep_cutout_recovery"] + 0.14 * sm["bank_retention"] + 0.18 * sm["topology_structural_joint"]
                candidates.append({"alpha": alpha, "max_length": length, "min_background": evidence, "eligible": bool(eligible), "score": float(score), "opened_base": bo, "opened_stress": so, "base": bm, "stress": sm})
    eligible = [row for row in candidates if row["eligible"]]; selected_path = max(eligible or candidates, key=lambda row: row["score"])
    alpha = selected_path["alpha"]
    raw_b, raw_s = blend(bc, ba, alpha), blend(sc, sa, alpha)
    base_ref = standard_metrics(base["labels"][bv], raw_b, base["indentation_masks"][bv])
    stress_ref, _, _ = stress_metrics(stress["labels"][sv], raw_s, stress["cutout_masks"][sv], stress["cutout_depth_weights"][sv], stress["family_codes"][sv])
    width_candidates = []
    settings = [(0, 1.0)] + [
        (radius, threshold)
        for radius in (1, 2, 3)
        for threshold in (0.10, 0.20, 0.30, 0.40, 0.50)
    ]
    for radius, corridor_background in settings:
        bp, bo = correct_batch(
            raw_b, bc, ba, selected_path["max_length"], selected_path["min_background"], 3,
            radius, corridor_background,
        )
        sp, so = correct_batch(
            raw_s, sc, sa, selected_path["max_length"], selected_path["min_background"], 3,
            radius, corridor_background,
        )
        bm = standard_metrics(base["labels"][bv], bp, base["indentation_masks"][bv])
        sm, _, _ = stress_metrics(stress["labels"][sv], sp, stress["cutout_masks"][sv], stress["cutout_depth_weights"][sv], stress["family_codes"][sv])
        eligible_width = (
            bm["foreground_iou"] >= base_ref["foreground_iou"] - 0.010
            and sm["foreground_iou"] >= stress_ref["foreground_iou"] - 0.015
            and sm["bank_retention"] >= stress_ref["bank_retention"] - 0.025
        )
        score = (
            0.16 * bm["foreground_iou"] + 0.16 * sm["foreground_iou"]
            + 0.32 * sm["open_deep_cutout_recovery"] + 0.16 * sm["bank_retention"]
            + 0.20 * sm["topology_structural_joint"]
        )
        width_candidates.append({
            "corridor_radius": radius,
            "corridor_background": corridor_background,
            "eligible": bool(eligible_width), "score": float(score),
            "opened_base": bo, "opened_stress": so, "base": bm, "stress": sm,
        })
    eligible_width = [row for row in width_candidates if row["eligible"]]
    selected_width = max(eligible_width or width_candidates, key=lambda row: row["score"])
    selected = {**selected_path, **selected_width}
    print(json.dumps({k: selected[k] for k in ("alpha", "max_length", "min_background", "corridor_radius", "corridor_background", "score", "opened_base", "opened_stress", "base", "stress")}, ensure_ascii=False, indent=2), flush=True)
    alpha, length, evidence = selected["alpha"], selected["max_length"], selected["min_background"]
    radius, corridor_background = selected["corridor_radius"], selected["corridor_background"]

    bt, st = np.asarray(base["test_indices"]), np.asarray(stress["test_indices"])
    btc = infer_probability(conservative, adapter, base["linear_images"][bt], base["voltages"][bt], device, args.batch_size); bta = infer_probability(aggressive, adapter, base["linear_images"][bt], base["voltages"][bt], device, args.batch_size)
    stc = infer_probability(conservative, adapter, stress["linear_images"][st], stress["voltages"][st], device, args.batch_size); sta = infer_probability(aggressive, adapter, stress["linear_images"][st], stress["voltages"][st], device, args.batch_size)
    raw_b, raw_s = blend(btc, bta, alpha), blend(stc, sta, alpha)
    bp, bo = correct_batch(raw_b, btc, bta, length, evidence, 3, radius, corridor_background); sp, so = correct_batch(raw_s, stc, sta, length, evidence, 3, radius, corridor_background)
    bm = standard_metrics(base["labels"][bt], bp, base["indentation_masks"][bt]); sm, by_family, _ = stress_metrics(stress["labels"][st], sp, stress["cutout_masks"][st], stress["cutout_depth_weights"][st], stress["family_codes"][st]); raw_sm, _, _ = stress_metrics(stress["labels"][st], raw_s, stress["cutout_masks"][st], stress["cutout_depth_weights"][st], stress["family_codes"][st]); expert_sm, _, _ = stress_metrics(stress["labels"][st], expert["stress_expert"], stress["cutout_masks"][st], stress["cutout_depth_weights"][st], stress["family_codes"][st])
    rc = infer_probability(conservative, adapter, base["real_linear_images"], base["real_voltages"], device, args.batch_size, 256); ra = infer_probability(aggressive, adapter, base["real_linear_images"], base["real_voltages"], device, args.batch_size, 256)
    raw_r = blend(rc, ra, alpha); rp, ro = correct_batch(raw_r, rc, ra, length * 4, evidence, 3 * 16, radius * 4, corridor_background)
    real_summary, _ = evaluate_real_predictions("topology_path", rp, base["real_labels"], base["real_ids"]); expert_real, _ = evaluate_real_predictions("shape_expert", expert["real_expert"], base["real_labels"], base["real_ids"])
    np.savez_compressed(out / "predictions.npz", base=bp, stress=sp, real=rp, raw_stress=raw_s, raw_real=raw_r)
    save_grid(out / "stress_comparison.png", stress["labels"][st], raw_s, sp, st, 24); save_grid(out / "real_comparison.png", base["real_labels"], raw_r, rp, base["real_ids"], 21)
    save_changed_grid(out / "stress_changed_cases.png", stress["labels"][st], expert["stress_expert"], raw_s, sp, st)
    save_changed_grid(out / "real_changed_cases.png", base["real_labels"], expert["real_expert"], raw_r, rp, base["real_ids"])
    summary = {"method": "confidence-gated geodesic exterior connectivity correction", "selected": selected, "test": {"opened_base": bo, "opened_stress": so, "opened_real": ro, "base": bm, "stress_shape_expert": expert_sm, "stress_raw": raw_sm, "stress_corrected": sm, "stress_by_family": by_family, "real_shape_expert": expert_real, "real_corrected": real_summary}, "path_candidates": candidates, "width_candidates": width_candidates}
    (out / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"); print(json.dumps(summary["test"], ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__": main()
