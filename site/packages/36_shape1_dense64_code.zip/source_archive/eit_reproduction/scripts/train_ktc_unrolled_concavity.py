"""Train a physics-unrolled EIT segmenter for non-convex inclusions.

Each stage performs an explicit linearized CEM data-consistency step
``x <- x - tau J.T (J x - dV)`` followed by a learned residual proximal
operator.  The network is trained on the independent synthetic and deep
concavity training splits; the 21 public KTC labels are only evaluated after
the checkpoint and synthetic test metrics are frozen.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import random
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy.ndimage import distance_transform_edt, label as connected_components
from torch.utils.data import ConcatDataset, DataLoader, Dataset

from train_ktc_concavity_network import (
    DecoderStage,
    InputAdapter,
    ResidualBlock,
    aggregate_rows,
    confusion_metrics,
    indentation_mask,
    ktc_score,
    save_focus_montage,
    save_real_montage,
    soft_dice_loss,
)
from train_ktc_implicit_boolean_network import FAMILIES


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    parser.add_argument("--output-dir", type=Path, default=root / "outputs" / "ktc_unrolled_concavity_v1")
    parser.add_argument("--stages", type=int, default=4)
    parser.add_argument("--base-channels", type=int, default=20)
    parser.add_argument("--epochs", type=int, default=55)
    parser.add_argument("--patience", type=int, default=11)
    parser.add_argument("--batch-size", type=int, default=24)
    parser.add_argument("--learning-rate", type=float, default=1.5e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--physics-weight", type=float, default=0.002)
    parser.add_argument(
        "--physics-warmup",
        type=int,
        default=8,
        help="Number of epochs used to ramp the data-consistency loss from zero.",
    )
    parser.add_argument("--sdf-weight", type=float, default=0.30)
    parser.add_argument("--boundary-weight", type=float, default=0.24)
    parser.add_argument("--indent-weight", type=float, default=0.44)
    parser.add_argument("--delta-weight", type=float, default=0.20)
    parser.add_argument("--seed", type=int, default=20260819)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--progress-every", type=int, default=1)
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


class ArchiveDataset(Dataset):
    def __init__(self, archive: np.lib.npyio.NpzFile, indices: np.ndarray, source: int) -> None:
        self.images = np.asarray(archive["linear_images"], dtype=np.float32)
        self.voltages = np.asarray(archive["voltages"], dtype=np.float32)
        self.labels = np.asarray(archive["labels"], dtype=np.int64)
        self.delta = np.asarray(archive["delta"], dtype=np.float32)
        self.sdf = np.asarray(archive["signed_distance"], dtype=np.float32)
        self.indent = np.asarray(archive["indentation_masks"], dtype=np.float32)
        self.indices = np.asarray(indices, dtype=np.int64)
        self.source = int(source)

    def __len__(self) -> int:
        return int(self.indices.size)

    def __getitem__(self, item: int) -> dict[str, torch.Tensor]:
        index = int(self.indices[item])
        return {
            "image": torch.from_numpy(self.images[index][None]),
            "voltage": torch.from_numpy(self.voltages[index]),
            "labels": torch.from_numpy(self.labels[index]),
            "delta": torch.from_numpy(self.delta[index][None]),
            "sdf": torch.from_numpy(self.sdf[index][None]),
            "indent": torch.from_numpy(self.indent[index][None]),
            "index": torch.tensor(index, dtype=torch.int64),
            "source": torch.tensor(self.source, dtype=torch.int64),
        }


class KTCLinearOperator(nn.Module):
    """Differentiable pixel-to-node CEM Jacobian and its adjoint."""

    def __init__(self, jacobian: np.ndarray, node_to_raw_pixel: np.ndarray) -> None:
        super().__init__()
        self.register_buffer("jacobian", torch.from_numpy(np.asarray(jacobian, dtype=np.float32)))
        self.register_buffer("node_to_raw_pixel", torch.from_numpy(np.asarray(node_to_raw_pixel, dtype=np.int64)))

    def forward(self, field: torch.Tensor) -> torch.Tensor:
        raw = torch.flip(field, dims=(-2,)).flatten(1)
        nodes = raw[:, self.node_to_raw_pixel]
        return 2.0 * (nodes @ self.jacobian.T)

    def adjoint(self, voltage: torch.Tensor) -> torch.Tensor:
        node_gradient = 2.0 * (voltage @ self.jacobian)
        raw = torch.zeros(
            node_gradient.shape[0], 64 * 64, device=node_gradient.device, dtype=node_gradient.dtype
        )
        indices = self.node_to_raw_pixel[None].expand(node_gradient.shape[0], -1)
        raw.scatter_add_(1, indices, node_gradient)
        return torch.flip(raw.view(-1, 1, 64, 64), dims=(-2,))

    def loss(self, field: torch.Tensor, voltage: torch.Tensor) -> torch.Tensor:
        """RMS-normalized linearized CEM data-consistency loss in FP32."""
        with torch.amp.autocast("cuda", enabled=False):
            predicted = self.forward(field.float())
            voltage_float = voltage.float()
            rms = torch.sqrt(voltage_float.square().mean(dim=1, keepdim=True) + 1e-10)
            return ((predicted.float() - voltage_float) / rms).square().mean()


class ProximalStage(nn.Module):
    """Residual U-Net used as the learned proximal map at one physics step."""

    def __init__(self, base: int) -> None:
        super().__init__()
        self.stem = ResidualBlock(8, base)
        self.enc1 = ResidualBlock(base, base * 2)
        self.enc2 = ResidualBlock(base * 2, base * 4)
        self.enc3 = ResidualBlock(base * 4, base * 8)
        self.bottleneck = nn.Sequential(ResidualBlock(base * 8, base * 12), ResidualBlock(base * 12, base * 12))
        self.dec3 = DecoderStage(base * 12, base * 8, base * 8)
        self.dec2 = DecoderStage(base * 8, base * 4, base * 4)
        self.dec1 = DecoderStage(base * 4, base * 2, base * 2)
        self.dec0 = DecoderStage(base * 2, base, base)
        self.update = nn.Conv2d(base, 4, 1)
        nn.init.zeros_(self.update.weight)
        nn.init.zeros_(self.update.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        e0 = self.stem(x)
        e1 = self.enc1(F.max_pool2d(e0, 2))
        e2 = self.enc2(F.max_pool2d(e1, 2))
        e3 = self.enc3(F.max_pool2d(e2, 2))
        y = self.bottleneck(F.max_pool2d(e3, 2))
        y = self.dec3(y, e3)
        y = self.dec2(y, e2)
        y = self.dec1(y, e1)
        y = self.dec0(y, e0)
        return 1.5 * torch.tanh(self.update(y))


class UnrolledConcavityNet(nn.Module):
    def __init__(self, operator: KTCLinearOperator, stages: int, base: int) -> None:
        super().__init__()
        self.operator = operator
        self.stages = nn.ModuleList([ProximalStage(base) for _ in range(stages)])
        self.step_logits = nn.Parameter(torch.full((stages,), -1.0))
        self.init_logits = nn.Conv2d(3, 3, 1)
        self.init_delta = nn.Conv2d(3, 1, 1)
        # A zero conductivity perturbation is the reference state of the
        # linearized CEM. Starting here keeps the first physical residual in
        # the same numerical range as the measured voltage.
        nn.init.zeros_(self.init_delta.weight)
        nn.init.zeros_(self.init_delta.bias)

    @staticmethod
    def normalize_gradient(gradient: torch.Tensor) -> torch.Tensor:
        gradient = gradient.float()
        scale = torch.quantile(gradient.abs().flatten(1), 0.985, dim=1).view(-1, 1, 1, 1).clamp_min(1e-5)
        return torch.tanh(gradient / scale)

    def forward(self, features: torch.Tensor, voltage: torch.Tensor) -> dict[str, torch.Tensor]:
        logits = self.init_logits(features)
        delta = 0.8 * torch.tanh(self.init_delta(features))
        stage_outputs: list[dict[str, torch.Tensor]] = []
        voltage_rms = torch.sqrt(voltage.square().mean(dim=1, keepdim=True) + 1e-8)
        for stage, step_logit in zip(self.stages, self.step_logits):
            predicted = self.operator(delta).float()
            residual = (predicted - voltage.float()) / voltage_rms
            gradient = self.normalize_gradient(self.operator.adjoint(residual))
            stage_input = torch.cat((features, logits.tanh(), delta, gradient), dim=1)
            update = stage(stage_input)
            step = torch.sigmoid(step_logit)
            logits = logits + step * update[:, :3]
            delta = (delta + 0.45 * step * update[:, 3:4]).clamp(-1.2, 1.2)
            stage_outputs.append({"logits": logits, "delta": delta})
        return {"logits": logits, "delta": delta, "stages": stage_outputs}


def gradients(image: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    return image[:, :, 1:, :] - image[:, :, :-1, :], image[:, :, :, 1:] - image[:, :, :, :-1]


def masked_mean(value: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    denom = mask.sum(dim=(1, 2, 3)).clamp_min(1.0)
    per_case = (value * mask).sum(dim=(1, 2, 3)) / denom
    valid = mask.sum(dim=(1, 2, 3)) > 0
    return per_case[valid].mean() if valid.any() else value.new_zeros(())


def loss_fn(
    model: UnrolledConcavityNet,
    outputs: dict[str, torch.Tensor],
    batch: dict[str, torch.Tensor],
    class_weights: torch.Tensor,
    args: argparse.Namespace,
    physics_multiplier: float = 1.0,
) -> tuple[torch.Tensor, dict[str, float]]:
    logits = outputs["logits"]
    probabilities = torch.softmax(logits, dim=1)
    foreground = probabilities[:, 1:].sum(dim=1, keepdim=True)
    target_foreground = (batch["labels"] != 0).float().unsqueeze(1)
    ce = F.cross_entropy(logits, batch["labels"], weight=class_weights)
    dice = soft_dice_loss(logits, batch["labels"])
    sdf_proxy = torch.tanh(logits[:, 1:].sum(dim=1, keepdim=True) - logits[:, 0:1])
    sdf = F.smooth_l1_loss(sdf_proxy, batch["sdf"], beta=0.08)
    delta_loss = F.smooth_l1_loss(outputs["delta"], batch["delta"], beta=0.08)
    pred_dy, pred_dx = gradients(foreground)
    true_dy, true_dx = gradients(target_foreground)
    boundary = F.l1_loss(pred_dy, true_dy) + F.l1_loss(pred_dx, true_dx)
    indentation = batch["indent"]
    rim = indentation * F.max_pool2d(target_foreground, 11, stride=1, padding=5)
    inside = target_foreground * F.max_pool2d(indentation, 11, stride=1, padding=5)
    false_fill = masked_mean(foreground, rim)
    false_cut = masked_mean(1.0 - foreground, inside)
    indent = 0.5 * (false_fill + false_cut)
    physical = model.operator.loss(outputs["delta"], batch["voltage"]) if hasattr(model.operator, "loss") else None
    if physical is None:
        predicted = model.operator(outputs["delta"])
        rms = torch.sqrt(batch["voltage"].square().mean(dim=1, keepdim=True) + 1e-8)
        physical = torch.mean(((predicted - batch["voltage"]) / rms) ** 2)
    total = ce + dice + args.sdf_weight * sdf + args.boundary_weight * boundary
    total = total + args.indent_weight * indent + args.delta_weight * delta_loss
    total = total + (args.physics_weight * physics_multiplier) * physical
    # Deep supervision stops the last stage from undoing a useful earlier boundary.
    if len(outputs["stages"]) > 1:
        for stage_output in outputs["stages"][:-1]:
            total = total + 0.08 * F.cross_entropy(stage_output["logits"], batch["labels"], weight=class_weights)
    pieces = {"total": float(total.detach()), "ce": float(ce.detach()), "dice": float(dice.detach()),
              "sdf": float(sdf.detach()), "boundary": float(boundary.detach()), "indent": float(indent.detach()),
              "delta": float(delta_loss.detach()), "physics": float(physical.detach())}
    return total, pieces


def evaluate(model: UnrolledConcavityNet, adapter: InputAdapter, loader: DataLoader, device: torch.device) -> tuple[dict[str, float], np.ndarray]:
    model.eval()
    predictions: list[np.ndarray] = []
    rows: list[dict[str, float]] = []
    with torch.no_grad():
        for batch in loader:
            image = adapter(batch["image"].to(device))
            voltage = batch["voltage"].to(device)
            pred = model(image, voltage)["logits"].argmax(dim=1).cpu().numpy().astype(np.uint8)
            truth = batch["labels"].numpy()
            indent = batch["indent"].numpy()[:, 0]
            predictions.append(pred)
            rows.extend(confusion_metrics(t, p, i) for t, p, i in zip(truth, pred, indent))
    return aggregate_rows(rows), np.concatenate(predictions)


@torch.no_grad()
def infer_loader(model: UnrolledConcavityNet, adapter: InputAdapter, loader: DataLoader, device: torch.device) -> np.ndarray:
    model.eval()
    predictions: list[np.ndarray] = []
    for batch in loader:
        image = adapter(batch["image"].to(device))
        voltage = batch["voltage"].to(device)
        predictions.append(model(image, voltage)["logits"].argmax(dim=1).cpu().numpy().astype(np.uint8))
    return np.concatenate(predictions)


def selection_score(metrics: dict[str, float]) -> float:
    return float(0.55 * metrics["foreground_iou"] + 0.20 * metrics["boundary_f1"] + 0.25 * metrics["concavity_score"])


def stress_metrics(truths: np.ndarray, predictions: np.ndarray, cutouts: np.ndarray, depths: np.ndarray, families: np.ndarray) -> tuple[dict[str, float], dict[str, dict[str, float]], list[dict[str, float]]]:
    rows: list[dict[str, float]] = []
    for truth, prediction, cutout, depth, family in zip(truths, predictions, cutouts, depths, families):
        row = confusion_metrics(truth, prediction, cutout)
        background = prediction == 0
        target = truth != 0
        cut = cutout != 0
        weight = cut * (1.0 + 3.0 * depth)
        components, count = connected_components(background, structure=np.ones((3, 3), dtype=np.uint8))
        borders = np.unique(np.concatenate((components[0], components[-1], components[:, 0], components[:, -1])))
        exterior = np.isin(components, borders[borders != 0])
        bank = target & (distance_transform_edt(~cut) <= 3.0)
        row["open_deep_cutout_recovery"] = float((exterior * weight).sum() / max(1e-6, float(weight.sum())))
        row["bank_retention"] = float((prediction != 0)[bank].mean()) if bank.any() else float("nan")
        row["topology_joint"] = float(max(row["foreground_iou"], 1e-8) * max(row["open_deep_cutout_recovery"], 1e-8) * max(row["bank_retention"], 1e-8)) ** (1.0 / 3.0)
        row["family"] = float(family)
        rows.append(row)
    numeric = [{k: v for k, v in row.items() if k != "family"} for row in rows]
    overall = aggregate_rows(numeric)
    by_family: dict[str, dict[str, float]] = {}
    for code, name in enumerate(FAMILIES):
        selected = [{k: v for k, v in row.items() if k != "family"} for row in rows if int(row["family"]) == code]
        by_family[name] = aggregate_rows(selected) if selected else {}
    return overall, by_family, rows


def save_stress_preview(path: Path, truth: np.ndarray, predictions: dict[str, np.ndarray], families: np.ndarray) -> None:
    indices = [next((i for i, code in enumerate(families) if int(code) == j), None) for j in range(len(FAMILIES))]
    indices = [i for i in indices if i is not None]
    fig, axes = plt.subplots(len(indices), 1 + len(predictions), figsize=(3.0 * (1 + len(predictions)), 2.8 * len(indices)), squeeze=False)
    for r, index in enumerate(indices):
        axes[r, 0].imshow(truth[index], vmin=0, vmax=2, cmap="viridis")
        axes[r, 0].set_title(f"{FAMILIES[int(families[index])]} truth")
        for c, (name, pred) in enumerate(predictions.items(), 1):
            axes[r, c].imshow(pred[index], vmin=0, vmax=2, cmap="viridis")
            axes[r, c].set_title(name)
        for axis in axes[r]: axis.set_axis_off()
    fig.suptitle("Physics-unrolled reconstruction on deep-concavity stress families")
    fig.tight_layout(); fig.savefig(path, dpi=160); plt.close(fig)


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    keys = ["id", "method", "foreground_iou", "foreground_dice", "class_1_iou", "class_2_iou", "boundary_f1", "notch_pixels", "notch_preservation", "concavity_score", "ktc_ssim"]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys); writer.writeheader(); writer.writerows({key: row.get(key) for key in keys} for row in rows)


def main() -> None:
    args = parse_args(); set_seed(args.seed)
    output = args.output_dir.resolve(); output.mkdir(parents=True, exist_ok=True)
    base = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    train_set = ConcatDataset([ArchiveDataset(base, base["train_indices"], 0), ArchiveDataset(stress, stress["train_indices"], 1)])
    val_set = ConcatDataset([ArchiveDataset(base, base["validation_indices"], 0), ArchiveDataset(stress, stress["validation_indices"], 1)])
    train_loader = DataLoader(train_set, batch_size=args.batch_size, shuffle=True, num_workers=args.workers, drop_last=True, pin_memory=device.type == "cuda")
    val_loader = DataLoader(val_set, batch_size=args.batch_size, shuffle=False, num_workers=args.workers)
    operator = KTCLinearOperator(base["jacobian"], base["node_to_raw_pixel"]).to(device)
    model = UnrolledConcavityNet(operator, args.stages, args.base_channels).to(device)
    adapter = InputAdapter(base["fov_mask"]).to(device)
    counts = np.bincount(np.concatenate((base["labels"][base["train_indices"]].reshape(-1), stress["labels"][stress["train_indices"]].reshape(-1))), minlength=3).astype(np.float64)
    weights = np.sqrt(counts.sum() / np.maximum(counts, 1.0)); weights /= weights.mean(); class_weights = torch.from_numpy(weights.astype(np.float32)).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    checkpoint = output / "best.pt"; best = -math.inf; stale = 0; history: list[dict[str, float]] = []
    print(f"device={device}; train={len(train_set)}; validation={len(val_set)}; stages={args.stages}", flush=True)
    for epoch in range(1, args.epochs + 1):
        model.train(); losses: list[float] = []
        physics_multiplier = min(1.0, max(0.0, (epoch - 1) / max(1, args.physics_warmup)))
        epoch_pieces: list[dict[str, float]] = []
        foreground_means: list[float] = []
        delta_rms_values: list[float] = []
        for batch in train_loader:
            batch = {key: value.to(device, non_blocking=True) for key, value in batch.items()}
            optimizer.zero_grad(set_to_none=True)
            with torch.amp.autocast("cuda", enabled=device.type == "cuda"):
                outputs = model(adapter(batch["image"]), batch["voltage"])
                loss, pieces = loss_fn(model, outputs, batch, class_weights, args, physics_multiplier)
                epoch_pieces.append(pieces)
                foreground_means.append(float((torch.softmax(outputs["logits"], dim=1)[:, 1:] .sum(dim=1)).mean().detach()))
                delta_rms_values.append(float(outputs["delta"].detach().square().mean().sqrt()))
            scaler.scale(loss).backward(); scaler.unscale_(optimizer); torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0); scaler.step(optimizer); scaler.update(); losses.append(float(loss.detach()))
        scheduler.step(); val_metrics, _ = evaluate(model, adapter, val_loader, device); score = selection_score(val_metrics)
        mean_pieces = {f"train_{key}": float(np.mean([part[key] for part in epoch_pieces])) for key in epoch_pieces[0]}
        row = {
            "epoch": float(epoch),
            "train_loss": float(np.mean(losses)),
            "physics_multiplier": float(physics_multiplier),
            "train_foreground_probability": float(np.mean(foreground_means)),
            "train_delta_rms": float(np.mean(delta_rms_values)),
            "selection_score": score,
            **mean_pieces,
            **{f"validation_{k}": v for k, v in val_metrics.items()},
        }
        history.append(row)
        if args.progress_every and (epoch == 1 or epoch % args.progress_every == 0):
            print(
                f"epoch {epoch}/{args.epochs}: loss={row['train_loss']:.4f} "
                f"IoU={val_metrics['foreground_iou']:.4f} boundary={val_metrics['boundary_f1']:.4f} "
                f"notch={val_metrics['notch_preservation']:.4f} fg={row['train_foreground_probability']:.3f} "
                f"delta_rms={row['train_delta_rms']:.4f} phys={row['train_physics']:.4f} "
                f"ramp={physics_multiplier:.2f}", flush=True
            )
        if score > best + 1e-5:
            best = score; stale = 0
            torch.save({"model": model.state_dict(), "base_channels": args.base_channels, "stages": args.stages, "selection_score": score, "args": vars(args) | {"base_dataset": str(args.base_dataset), "stress_dataset": str(args.stress_dataset)}}, checkpoint)
        else:
            stale += 1
        if stale >= args.patience: break
    model.load_state_dict(torch.load(checkpoint, map_location=device, weights_only=False)["model"]); model.eval()
    (output / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    base_test_loader = DataLoader(ArchiveDataset(base, base["test_indices"], 0), batch_size=args.batch_size, shuffle=False)
    stress_test_loader = DataLoader(ArchiveDataset(stress, stress["test_indices"], 1), batch_size=args.batch_size, shuffle=False)
    base_metrics, base_pred = evaluate(model, adapter, base_test_loader, device)
    stress_base_metrics, stress_pred = evaluate(model, adapter, stress_test_loader, device)
    stress_overall, stress_by_family, stress_rows = stress_metrics(stress["labels"][stress["test_indices"]], stress_pred, stress["cutout_masks"][stress["test_indices"]], stress["cutout_depth_weights"][stress["test_indices"]], stress["family_codes"][stress["test_indices"]])
    stress_truth = stress["labels"][stress["test_indices"]]
    save_stress_preview(output / "stress_test_comparison.png", stress_truth, {"unrolled": stress_pred}, stress["family_codes"][stress["test_indices"]])
    real_images = base["real_linear_images"]; real_voltages = base["real_voltages"]; real_truth = base["real_labels"]; real_ids = base["real_ids"]
    real_dataset = ArchiveDataset({"linear_images": real_images, "voltages": real_voltages, "labels": real_truth, "delta": np.zeros_like(real_images), "signed_distance": np.zeros_like(real_images), "indentation_masks": np.asarray([indentation_mask(x) for x in real_truth], dtype=np.float32)}, np.arange(len(real_ids)), 2)
    real_loader = DataLoader(real_dataset, batch_size=args.batch_size, shuffle=False)
    real_pred64 = infer_loader(model, adapter, real_loader, device)
    from PIL import Image
    real_pred = np.stack([np.asarray(Image.fromarray(pred).resize((256, 256), resample=Image.Resampling.NEAREST)) for pred in real_pred64])
    real_rows: list[dict[str, object]] = []; numeric: list[dict[str, float]] = []
    for case_id, truth, pred in zip(real_ids, real_truth, real_pred):
        row = {"id": str(case_id), "method": "unrolled", **confusion_metrics(truth, pred, indentation_mask(truth))}; row["ktc_ssim"] = ktc_score(truth, pred); numeric.append({k: v for k, v in row.items() if isinstance(v, (int, float))}); real_rows.append(row)
    real_summary = aggregate_rows(numeric)
    write_rows(output / "real_case_metrics.csv", real_rows)
    save_real_montage(output / "real_all_21_comparison.png", real_truth, real_ids, {"unrolled": real_pred}, real_rows)
    save_focus_montage(output / "real_most_concave_comparison.png", real_truth, real_ids, {"unrolled": real_pred}, real_rows)
    summary = {"device": str(device), "seed": args.seed, "checkpoint": str(checkpoint), "synthetic_base_test": base_metrics, "synthetic_stress_test": stress_overall, "stress_by_family": stress_by_family, "real_untouched_test": real_summary, "evaluation_truth_used_for_training_or_selection": False, "literature_basis": ["parametric level-set EIT", "B-spline/Boolean shape reconstruction", "learned primal-dual/FISTA unrolling"]}
    (output / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
