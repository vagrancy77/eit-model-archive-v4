"""Evaluate frozen v6 EIT models under measurement and inverse-map shifts.

The v4 anchor, v6 local corrector, quantile risk gate, and both routing rules
remain frozen.  Measurement perturbations are propagated through the archived
linear reconstruction operator before inference.  The two inverse-map
conditions are explicitly reported as reconstruction-operator mismatches, not
as forward-physics perturbations.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
import zlib
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import gaussian_filter

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import evaluate_topology_measurement_robustness as legacy
import train_local_topology_corrector_v6 as v6
from pytorch_eit.local_topology_corrector_v6 import (
    DualRiskQuantileGate,
    LocalTopologyCorrectorV6,
)


CONDITIONS = (
    "native",
    "snr_40db",
    "snr_30db",
    "snr_20db",
    "gain_0p9",
    "gain_1p1",
    "element_dropout_0p05",
    "element_dropout_0p10",
    "slot_drift_0p05",
    "slot_drift_0p10",
    "slot_dropout_4of76",
    "slot_dropout_8of76",
    "inverse_blur_sigma1",
    "inverse_grid_shift_1px",
)
CONDITION_LABELS = {
    "native": "native",
    "snr_40db": "40 dB",
    "snr_30db": "30 dB",
    "snr_20db": "20 dB",
    "gain_0p9": "gain .9",
    "gain_1p1": "gain 1.1",
    "element_dropout_0p05": "random 5%",
    "element_dropout_0p10": "random 10%",
    "slot_drift_0p05": "slot drift 5%",
    "slot_drift_0p10": "slot drift 10%",
    "slot_dropout_4of76": "drop 4 slots",
    "slot_dropout_8of76": "drop 8 slots",
    "inverse_blur_sigma1": "inverse blur",
    "inverse_grid_shift_1px": "grid shift 1 px",
}
METHODS = ("anchor_v4", "candidate_v6", "gated_v6")
METRICS = (
    "foreground_iou",
    "foreground_dice",
    "boundary_f1",
    "notch_preservation",
    "bank_retention",
)


@dataclass
class FrozenRun:
    seed: str
    directory: Path
    checkpoint_v4: Path
    v4_threshold: float
    corrector: LocalTopologyCorrectorV6
    risk_gate: DualRiskQuantileGate
    feature_mean: np.ndarray
    feature_std: np.ndarray
    gate_rule: dict[str, object]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", nargs="+", required=True, help="seed=v6_run_directory")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--base-dataset", type=Path, default=ROOT / "datasets" / "ktc_shape_nonlinear_v1.npz"
    )
    parser.add_argument(
        "--biological-dataset", type=Path,
        default=ROOT / "datasets" / "ktc_biological_concavity_v1.npz",
    )
    parser.add_argument(
        "--stress-dataset", type=Path,
        default=ROOT / "datasets" / "ktc_deep_concavity_stress_v1.npz",
    )
    parser.add_argument(
        "--audit", type=Path,
        default=ROOT / "outputs" / "ktc2023_full_audit" / "summary.json",
    )
    parser.add_argument("--batch-size", type=int, default=28)
    parser.add_argument("--bootstrap", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20261103)
    parser.add_argument("--device", choices=("auto", "cuda", "cpu"), default="auto")
    parser.add_argument("--max-cases", type=int, default=0, help="smoke-test cap per group")
    return parser.parse_args()


def parse_keyed(values: list[str]) -> dict[str, Path]:
    result: dict[str, Path] = {}
    for value in values:
        if "=" not in value:
            raise ValueError(f"expected seed=directory, got {value!r}")
        seed, raw = value.split("=", 1)
        if seed in result:
            raise ValueError(f"duplicate seed {seed}")
        result[seed] = Path(raw).resolve()
    return result


def choose_device(name: str) -> torch.device:
    if name == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    result = torch.device(name)
    if result.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable")
    return result


def load_groups(args: argparse.Namespace) -> dict[str, legacy.Group]:
    forwarded = argparse.Namespace(
        base_dataset=args.base_dataset,
        biological_dataset=args.biological_dataset,
        stress_dataset=args.stress_dataset,
        audit=args.audit,
        max_cases=args.max_cases,
    )
    groups = legacy.load_groups(forwarded)
    for group in groups.values():
        if group.audited_concave is None:
            group.audited_concave = group.cutout.reshape(len(group.ids), -1).any(axis=1)
        group.cutout = np.asarray(
            [v6.indentation_mask(label) for label in group.truth], dtype=np.uint8
        )
    return groups


def reconstruct_images(
    voltage: np.ndarray,
    group: legacy.Group,
    device: torch.device,
) -> np.ndarray:
    return legacy.reconstruct_images(
        voltage,
        group.reconstruction_operator,
        group.raw_pixel_to_node,
        device,
    )


def measurement_conditions(
    group: legacy.Group,
    device: torch.device,
    seed: int,
) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    voltage = np.asarray(group.voltage, dtype=np.float32)
    rng = np.random.default_rng(seed + zlib.crc32(group.name.encode("utf-8")))
    standard_noise = rng.normal(size=voltage.shape).astype(np.float32)
    rms = np.sqrt(np.mean(voltage.astype(np.float64) ** 2, axis=1, keepdims=True)).astype(np.float32)
    element_scores = rng.random(size=voltage.shape)
    conditions: dict[str, np.ndarray] = {"native": voltage.copy()}
    for snr in (40, 30, 20):
        conditions[f"snr_{snr}db"] = voltage + standard_noise * (
            rms / (10.0 ** (snr / 20.0)) + 1e-9
        )
    conditions["gain_0p9"] = 0.9 * voltage
    conditions["gain_1p1"] = 1.1 * voltage
    conditions["element_dropout_0p05"] = voltage * (element_scores >= 0.05)
    conditions["element_dropout_0p10"] = voltage * (element_scores >= 0.10)

    if voltage.shape[1] != 76 * 31:
        raise ValueError(
            f"structured KTC perturbations expect 76x31 measurements, got {voltage.shape[1]}"
        )
    shaped = voltage.reshape(len(voltage), 76, 31)
    slot_standard = rng.normal(size=(len(voltage), 76, 1)).astype(np.float32)
    for scale in (0.05, 0.10):
        gain = np.clip(1.0 + scale * slot_standard, 1.0 - 3 * scale, 1.0 + 3 * scale)
        conditions[f"slot_drift_0p{int(scale * 100):02d}"] = (shaped * gain).reshape(voltage.shape)
    slot_scores = rng.random(size=(len(voltage), 76))
    slot_order = np.argsort(slot_scores, axis=1)
    for count in (4, 8):
        mask = np.ones((len(voltage), 76, 1), dtype=np.float32)
        np.put_along_axis(mask[:, :, 0], slot_order[:, :count], 0.0, axis=1)
        conditions[f"slot_dropout_{count}of76"] = (shaped * mask).reshape(voltage.shape)

    result: dict[str, tuple[np.ndarray, np.ndarray]] = {}
    for condition, changed in conditions.items():
        changed = np.asarray(changed, dtype=np.float32)
        image = group.native_image.copy() if condition == "native" else reconstruct_images(
            changed, group, device
        )
        result[condition] = (changed, image.astype(np.float32))

    native_image = np.asarray(group.native_image, dtype=np.float32)
    blurred = gaussian_filter(native_image, sigma=(0.0, 1.0, 1.0)).astype(np.float32)
    shifted = np.roll(native_image, shift=1, axis=2)
    shifted[:, :, 0] = 0.0
    result["inverse_blur_sigma1"] = (voltage.copy(), blurred)
    result["inverse_grid_shift_1px"] = (voltage.copy(), shifted.astype(np.float32))
    if tuple(result) != CONDITIONS:
        raise RuntimeError(f"condition mismatch: {tuple(result)}")
    return result


def load_frozen_run(
    seed: str,
    directory: Path,
    fov: np.ndarray,
    device: torch.device,
) -> tuple[FrozenRun, torch.nn.Module]:
    summary_path = directory / "v6_summary.json"
    if not summary_path.is_file():
        raise FileNotFoundError(summary_path)
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    if str(summary["seed"]) != seed:
        raise ValueError(f"seed mismatch in {summary_path}: {summary['seed']} != {seed}")
    checkpoint_v4 = Path(summary["checkpoint_v4"]).resolve()
    v4_model, _ = v6.load_v4(checkpoint_v4, fov, device)

    corrector_path = directory / "local_corrector_v6_best.pt"
    corrector_state = torch.load(corrector_path, map_location=device, weights_only=False)
    corrector = LocalTopologyCorrectorV6(
        input_channels=int(corrector_state.get("input_channels", 15)),
        base_channels=int(corrector_state["base_channels"]),
        enforce_connectivity=bool(corrector_state.get("enforce_connectivity", True)),
    ).to(device)
    corrector.load_state_dict(corrector_state["model"])
    corrector.eval()

    gate_path = directory / "dual_risk_gate_v6_best.pt"
    gate_state = torch.load(gate_path, map_location=device, weights_only=False)
    feature_mean = np.asarray(gate_state["feature_mean"], dtype=np.float32)
    feature_std = np.asarray(gate_state["feature_std"], dtype=np.float32)
    risk_gate = DualRiskQuantileGate(len(feature_mean)).to(device)
    risk_gate.load_state_dict(gate_state["model"])
    risk_gate.eval()
    run = FrozenRun(
        seed=seed,
        directory=directory,
        checkpoint_v4=checkpoint_v4,
        v4_threshold=float(summary["v4_anchor_threshold"]),
        corrector=corrector,
        risk_gate=risk_gate,
        feature_mean=feature_mean,
        feature_std=feature_std,
        gate_rule=dict(summary["gate_rule"]),
    )
    return run, v4_model


@torch.no_grad()
def infer_condition(
    run: FrozenRun,
    v4_model: torch.nn.Module,
    voltage: np.ndarray,
    image: np.ndarray,
    truth_size: tuple[int, int],
    fov: torch.Tensor,
    jacobian: torch.Tensor,
    node_to_raw_pixel: torch.Tensor,
    batch_size: int,
    device: torch.device,
) -> dict[str, np.ndarray]:
    saved: dict[str, list[np.ndarray]] = {
        "anchor_v4": [],
        "candidate_v6": [],
        "gate_features": [],
        "risk": [],
        "selected": [],
        "removal": [],
    }
    for start in range(0, len(voltage), batch_size):
        stop = min(len(voltage), start + batch_size)
        x = torch.from_numpy(image[start:stop, None]).to(device)
        measured = torch.from_numpy(voltage[start:stop]).to(device)
        v4_output = v4_model(x, measured)
        v4_gate = v4_output["case_gate"][:, 0, 0, 0]
        v4_route = v4_gate >= run.v4_threshold
        anchor = torch.where(
            v4_route[:, None, None, None],
            v4_output["probabilities"],
            v4_output["base_probabilities"],
        )
        backprojection = v6.physics_backprojection(
            v4_output["delta"], measured, jacobian, node_to_raw_pixel
        )
        maps = torch.cat(
            (
                v4_output["sdf"],
                v4_output["raw_cutout_probability"],
                v4_output["connected_cutout_probability"],
                v4_output["mouth_probability"],
                v4_output["effective_cutout_probability"],
                v4_output["delta"],
                backprojection,
            ),
            dim=1,
        )
        output = run.corrector(v6.build_features(anchor, maps, x, fov), anchor, fov)
        features = v6.extract_gate_features(
            output,
            anchor,
            maps,
            x,
            v4_gate,
            v4_route.float(),
            fov,
        )
        normalized = (features - torch.from_numpy(run.feature_mean).to(device)) / torch.from_numpy(
            run.feature_std
        ).to(device)
        risk = torch.sort(run.risk_gate(normalized), dim=2).values
        risk_numpy = risk.cpu().numpy()
        selected = v6.apply_gate(risk_numpy, run.gate_rule)

        anchor_out = anchor
        candidate_out = output["candidate_probabilities"]
        if anchor.shape[-2:] != truth_size:
            anchor_out = F.interpolate(anchor, truth_size, mode="bilinear", align_corners=False)
            candidate_out = F.interpolate(
                candidate_out, truth_size, mode="bilinear", align_corners=False
            )
        saved["anchor_v4"].append(anchor_out.argmax(dim=1).cpu().numpy().astype(np.uint8))
        saved["candidate_v6"].append(
            candidate_out.argmax(dim=1).cpu().numpy().astype(np.uint8)
        )
        saved["gate_features"].append(features.cpu().numpy().astype(np.float32))
        saved["risk"].append(risk_numpy.astype(np.float32))
        saved["selected"].append(selected.astype(np.uint8))
        saved["removal"].append(output["removal"][:, 0].cpu().numpy().astype(np.float16))
    result = {key: np.concatenate(value) for key, value in saved.items()}
    result["gated_v6"] = np.where(
        result["selected"][:, None, None].astype(bool),
        result["candidate_v6"],
        result["anchor_v4"],
    ).astype(np.uint8)
    return result


def append_rows(
    rows: list[dict[str, object]],
    seed: str,
    condition: str,
    group: legacy.Group,
    output: dict[str, np.ndarray],
) -> None:
    for index, case_id in enumerate(group.ids):
        concave = (
            bool(group.audited_concave[index])
            if group.audited_concave is not None
            else bool(group.cutout[index].any())
        )
        for method in METHODS:
            rows.append(
                {
                    "seed": seed,
                    "condition": condition,
                    "group": group.name,
                    "case_id": str(case_id),
                    "subset": "concave" if concave else "ordinary",
                    "method": method,
                    "gate_selected": int(output["selected"][index]) if method == "gated_v6" else 0,
                    "predicted_benefit_q20": float(output["risk"][index, 0, 0]),
                    "predicted_iou_loss_q80": float(output["risk"][index, 1, 2]),
                    "predicted_bank_loss_q80": float(output["risk"][index, 2, 2]),
                    **v6.case_metrics(
                        group.truth[index], output[method][index], group.cutout[index]
                    ),
                }
            )


def hierarchical_bootstrap(
    difference: np.ndarray,
    repetitions: int,
    rng: np.random.Generator,
) -> dict[str, object] | None:
    finite = np.isfinite(difference).all(axis=0)
    difference = difference[:, finite]
    if difference.size == 0:
        return None
    seed_count, case_count = difference.shape
    draws = np.empty(repetitions, dtype=np.float64)
    for start in range(0, repetitions, 1000):
        stop = min(repetitions, start + 1000)
        count = stop - start
        seed_draw = rng.integers(seed_count, size=(count, seed_count))
        case_draw = rng.integers(case_count, size=(count, case_count))
        draws[start:stop] = difference[
            seed_draw[:, :, None], case_draw[:, None, :]
        ].mean(axis=(1, 2))
    return {
        "mean_difference": float(difference.mean()),
        "ci95_low": float(np.percentile(draws, 2.5)),
        "ci95_high": float(np.percentile(draws, 97.5)),
        "probability_positive": float(np.mean(draws > 0.0)),
        "per_seed_mean_difference": [float(value) for value in difference.mean(axis=1)],
        "seed_count": seed_count,
        "case_count": case_count,
    }


def summarize(
    rows: list[dict[str, object]],
    repetitions: int,
    random_seed: int,
) -> dict[str, object]:
    seeds = sorted({str(row["seed"]) for row in rows})
    lookup = {
        (
            str(row["seed"]), str(row["condition"]), str(row["group"]),
            str(row["case_id"]), str(row["method"]),
        ): row
        for row in rows
    }
    reference = [
        row for row in rows
        if row["seed"] == seeds[0] and row["condition"] == "native"
        and row["method"] == "anchor_v4"
    ]
    specs: dict[str, tuple[str, list[str]]] = {}
    for group in sorted({str(row["group"]) for row in reference}):
        group_rows = [row for row in reference if row["group"] == group]
        for subset in ("all", "concave", "ordinary"):
            ids = sorted(
                str(row["case_id"]) for row in group_rows
                if subset == "all" or row["subset"] == subset
            )
            if ids:
                specs[f"{group}_{subset}"] = (group, ids)

    rng = np.random.default_rng(random_seed)
    groups: dict[str, object] = {}
    for label, (group, ids) in specs.items():
        condition_results: dict[str, object] = {}
        native_matrices: dict[tuple[str, str], np.ndarray] = {}
        for method in METHODS:
            for metric in METRICS:
                native_matrices[(method, metric)] = np.asarray(
                    [
                        [
                            float(lookup[(seed, "native", group, case_id, method)][metric])
                            for case_id in ids
                        ]
                        for seed in seeds
                    ],
                    dtype=np.float64,
                )
        for condition in CONDITIONS:
            matrices: dict[tuple[str, str], np.ndarray] = {}
            method_statistics: dict[str, object] = {}
            for method in METHODS:
                method_statistics[method] = {}
                for metric in METRICS:
                    matrix = np.asarray(
                        [
                            [
                                float(lookup[(seed, condition, group, case_id, method)][metric])
                                for case_id in ids
                            ]
                            for seed in seeds
                        ],
                        dtype=np.float64,
                    )
                    matrices[(method, metric)] = matrix
                    if np.isfinite(matrix).any():
                        method_statistics[method][metric] = {
                            "pooled_mean": float(np.nanmean(matrix)),
                            "per_seed_means": [float(np.nanmean(value)) for value in matrix],
                        }
                selections = [
                    float(lookup[(seed, condition, group, case_id, method)]["gate_selected"])
                    for seed in seeds for case_id in ids
                ]
                method_statistics[method]["selected_fraction"] = float(np.mean(selections))
            comparisons: dict[str, object] = {}
            for method, reference_method in (
                ("candidate_v6", "anchor_v4"),
                ("gated_v6", "anchor_v4"),
                ("gated_v6", "candidate_v6"),
            ):
                name = f"{method}_minus_{reference_method}"
                comparisons[name] = {}
                for metric in METRICS:
                    value = hierarchical_bootstrap(
                        matrices[(method, metric)] - matrices[(reference_method, metric)],
                        repetitions,
                        rng,
                    )
                    if value is not None:
                        comparisons[name][metric] = value
            degradation: dict[str, object] = {}
            if condition != "native":
                for method in METHODS:
                    degradation[method] = {}
                    for metric in METRICS:
                        value = hierarchical_bootstrap(
                            matrices[(method, metric)] - native_matrices[(method, metric)],
                            repetitions,
                            rng,
                        )
                        if value is not None:
                            degradation[method][metric] = value
            condition_results[condition] = {
                "method_statistics": method_statistics,
                "comparisons": comparisons,
                "degradation_from_native": degradation,
            }
        groups[label] = {"cases_per_seed": len(ids), "conditions": condition_results}
    return {"seeds": seeds, "groups": groups, "bootstrap_repetitions": repetitions}


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def write_paper_table(path: Path, summary: dict[str, object]) -> None:
    selected_groups = (
        "biological_concave",
        "biological_ordinary",
        "stress_concave",
        "public_ktc_concave",
        "public_ktc_ordinary",
    )
    rows: list[dict[str, object]] = []
    for group_name in selected_groups:
        if group_name not in summary["groups"]:
            continue
        group = summary["groups"][group_name]
        for condition in CONDITIONS:
            condition_data = group["conditions"][condition]
            effect = condition_data["comparisons"]["gated_v6_minus_anchor_v4"]
            for method in ("anchor_v4", "gated_v6"):
                stats = condition_data["method_statistics"][method]
                rows.append(
                    {
                        "group": group_name,
                        "cases_per_seed": group["cases_per_seed"],
                        "condition": condition,
                        "method": method,
                        "foreground_iou": stats["foreground_iou"]["pooled_mean"],
                        "boundary_f1": stats["boundary_f1"]["pooled_mean"],
                        "notch_preservation": stats.get("notch_preservation", {}).get(
                            "pooled_mean", ""
                        ),
                        "selected_fraction": stats["selected_fraction"],
                        "gated_minus_anchor_iou": effect["foreground_iou"]["mean_difference"],
                        "gated_minus_anchor_notch": effect.get("notch_preservation", {}).get(
                            "mean_difference", ""
                        ),
                    }
                )
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def plot_curves(path: Path, summary: dict[str, object]) -> None:
    selected = ("biological_concave", "stress_concave", "public_ktc_concave")
    available = [value for value in selected if value in summary["groups"]]
    figure, axes = plt.subplots(len(available), 2, figsize=(16.0, 3.6 * len(available)), squeeze=False)
    colors = {"anchor_v4": "#4d4d4d", "gated_v6": "#087f5b"}
    for row_index, group_name in enumerate(available):
        group = summary["groups"][group_name]
        for column, metric in enumerate(("foreground_iou", "notch_preservation")):
            axis = axes[row_index, column]
            for method in ("anchor_v4", "gated_v6"):
                values = [
                    group["conditions"][condition]["method_statistics"][method][metric][
                        "pooled_mean"
                    ]
                    for condition in CONDITIONS
                ]
                axis.plot(values, marker="o", linewidth=1.8, color=colors[method], label=method)
            axis.set_xticks(
                range(len(CONDITIONS)),
                [CONDITION_LABELS[value] for value in CONDITIONS],
                rotation=38,
                ha="right",
                fontsize=8,
            )
            axis.set_title(f"{group_name.replace('_', ' ')}: {metric.replace('_', ' ')}")
            axis.grid(alpha=0.22)
    if available:
        axes[0, 1].legend(frameon=False)
    figure.suptitle("Frozen v6 under measurement and inverse-map mismatch")
    figure.tight_layout()
    figure.savefig(path, dpi=240)
    plt.close(figure)


def plot_heatmaps(path: Path, summary: dict[str, object]) -> None:
    selected = (
        "biological_concave",
        "biological_ordinary",
        "stress_concave",
        "public_ktc_concave",
        "public_ktc_ordinary",
    )
    groups = [value for value in selected if value in summary["groups"]]
    shifted = CONDITIONS[1:]
    degradation = np.asarray(
        [
            [
                summary["groups"][group]["conditions"][condition]["degradation_from_native"]
                ["gated_v6"]["foreground_iou"]["mean_difference"]
                for condition in shifted
            ]
            for group in groups
        ]
    )
    selection = np.asarray(
        [
            [
                summary["groups"][group]["conditions"][condition]["method_statistics"]
                ["gated_v6"]["selected_fraction"]
                for condition in CONDITIONS
            ]
            for group in groups
        ]
    )
    figure, axes = plt.subplots(2, 1, figsize=(15.5, 8.2))
    limit = max(0.005, float(np.max(np.abs(degradation))))
    first = axes[0].imshow(degradation, cmap="coolwarm", vmin=-limit, vmax=limit, aspect="auto")
    axes[0].set_xticks(
        range(len(shifted)), [CONDITION_LABELS[value] for value in shifted], rotation=35, ha="right"
    )
    axes[0].set_yticks(range(len(groups)), [value.replace("_", " ") for value in groups])
    axes[0].set_title("Gated v6 IoU degradation from native")
    figure.colorbar(first, ax=axes[0], label="IoU change")
    second = axes[1].imshow(selection, cmap="YlGn", vmin=0.0, vmax=max(0.2, float(selection.max())), aspect="auto")
    axes[1].set_xticks(
        range(len(CONDITIONS)), [CONDITION_LABELS[value] for value in CONDITIONS], rotation=35, ha="right"
    )
    axes[1].set_yticks(range(len(groups)), [value.replace("_", " ") for value in groups])
    axes[1].set_title("Frozen dual-risk gate selection fraction")
    figure.colorbar(second, ax=axes[1], label="selected fraction")
    figure.tight_layout()
    figure.savefig(path, dpi=240)
    plt.close(figure)


def plot_examples(
    path: Path,
    group: legacy.Group,
    prepared: dict[str, tuple[np.ndarray, np.ndarray]],
    examples: dict[str, dict[str, np.ndarray]],
) -> None:
    concave = np.flatnonzero(group.cutout.reshape(len(group.ids), -1).sum(axis=1) > 0)
    index = int(concave[len(concave) // 2] if len(concave) else 0)
    chosen = ("native", "snr_20db", "slot_dropout_8of76", "inverse_grid_shift_1px")
    figure, axes = plt.subplots(len(chosen), 5, figsize=(13.2, 2.75 * len(chosen)))
    for row, condition in enumerate(chosen):
        output = examples[condition]
        panels = (
            (group.truth[index], "truth"),
            (prepared[condition][1][index], "linear EIT"),
            (output["anchor_v4"][index], "v4 anchor"),
            (output["candidate_v6"][index], "v6 candidate"),
            (output["gated_v6"][index], f"gated (use={bool(output['selected'][index])})"),
        )
        for column, (image, title) in enumerate(panels):
            axes[row, column].imshow(image, cmap="viridis", interpolation="nearest")
            axes[row, column].set_title(f"{CONDITION_LABELS[condition]}: {title}", fontsize=9)
            axes[row, column].set_axis_off()
    figure.suptitle("Representative frozen-v6 distribution-shift reconstructions")
    figure.tight_layout()
    figure.savefig(path, dpi=240)
    plt.close(figure)


def write_report(path: Path, summary: dict[str, object]) -> None:
    lines = [
        "# V6 Measurement and Inverse-Map Robustness",
        "",
        "All models and routing thresholds were frozen before this evaluation. No test or public truth was used for adaptation.",
        "",
        "| Group | Condition | gated-v4 IoU (95% CI) | gated-v4 Notch (95% CI) | gated IoU degradation |",
        "|---|---|---:|---:|---:|",
    ]
    for group_name in (
        "biological_concave", "biological_ordinary", "stress_concave",
        "public_ktc_concave", "public_ktc_ordinary",
    ):
        if group_name not in summary["groups"]:
            continue
        for condition in CONDITIONS:
            data = summary["groups"][group_name]["conditions"][condition]
            effect = data["comparisons"]["gated_v6_minus_anchor_v4"]
            iou = effect["foreground_iou"]
            notch = effect.get("notch_preservation")
            notch_text = "n/a" if notch is None else (
                f"{notch['mean_difference']:+.5f} [{notch['ci95_low']:+.5f}, {notch['ci95_high']:+.5f}]"
            )
            degradation = data["degradation_from_native"].get("gated_v6", {}).get(
                "foreground_iou"
            )
            degradation_text = "native" if degradation is None else (
                f"{degradation['mean_difference']:+.5f} [{degradation['ci95_low']:+.5f}, {degradation['ci95_high']:+.5f}]"
            )
            lines.append(
                f"| {group_name} | {condition} | {iou['mean_difference']:+.5f} "
                f"[{iou['ci95_low']:+.5f}, {iou['ci95_high']:+.5f}] | {notch_text} | {degradation_text} |"
            )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    run_paths = parse_keyed(args.runs)
    device = choose_device(args.device)
    groups = load_groups(args)
    base_archive = np.load(args.base_dataset.resolve(), allow_pickle=False)
    jacobian = torch.from_numpy(np.asarray(base_archive["jacobian"], dtype=np.float32)).to(device)
    node_to_raw_pixel = torch.from_numpy(
        np.asarray(base_archive["node_to_raw_pixel"], dtype=np.int64)
    ).to(device)
    fov = torch.from_numpy(groups["base"].fov.astype(np.float32))[None, None].to(device)

    print("preparing deterministic measurement conditions", flush=True)
    prepared = {
        name: measurement_conditions(group, device, args.seed)
        for name, group in groups.items()
    }
    rows: list[dict[str, object]] = []
    examples: dict[str, dict[str, np.ndarray]] = {}
    first_seed = next(iter(run_paths))
    rules: dict[str, object] = {}
    for model_seed, directory in run_paths.items():
        run, v4_model = load_frozen_run(model_seed, directory, groups["base"].fov, device)
        rules[model_seed] = run.gate_rule
        print(f"seed={model_seed} loaded frozen v4/v6/gate", flush=True)
        for group_name, group in groups.items():
            for condition in CONDITIONS:
                voltage, image = prepared[group_name][condition]
                output = infer_condition(
                    run,
                    v4_model,
                    voltage,
                    image,
                    tuple(group.truth.shape[-2:]),
                    fov,
                    jacobian,
                    node_to_raw_pixel,
                    args.batch_size,
                    device,
                )
                append_rows(rows, model_seed, condition, group, output)
                if model_seed == first_seed and group_name == "biological" and condition in {
                    "native", "snr_20db", "slot_dropout_8of76", "inverse_grid_shift_1px"
                }:
                    examples[condition] = output
            print(f"  completed {group_name}", flush=True)
        del v4_model, run
        if device.type == "cuda":
            torch.cuda.empty_cache()

    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    write_rows(output_dir / "v6_measurement_shift_case_metrics.csv", rows)
    summary = summarize(rows, args.bootstrap, args.seed + 1)
    summary.update(
        {
            "conditions": list(CONDITIONS),
            "condition_definitions": {
                "snr": "added zero-mean Gaussian voltage noise at stated SNR",
                "gain": "scalar calibration gain applied to the full voltage vector",
                "element_dropout": "independent missing scalar measurements",
                "slot_drift": "case-specific gain drift shared across each of 76 KTC readout slots and its 31 stimulations",
                "slot_dropout": "complete readout slots removed across all 31 stimulations",
                "inverse_blur": "linear EIT image blurred after the frozen reconstruction operator; voltage unchanged",
                "inverse_grid_shift": "linear EIT image shifted one pixel after the frozen reconstruction operator; voltage unchanged",
            },
            "frozen_gate_rules": rules,
            "protocol": {
                "test_or_public_truth_used_for_adaptation": False,
                "measurement_images_recomputed_from_perturbed_voltage": True,
                "inverse_map_conditions_claimed_as_forward_physics": False,
                "paired_conditions_across_model_seeds": True,
            },
        }
    )
    (output_dir / "v6_measurement_shift_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    write_paper_table(output_dir / "v6_measurement_shift_paper_table.csv", summary)
    plot_curves(output_dir / "v6_measurement_shift_curves.png", summary)
    plot_heatmaps(output_dir / "v6_measurement_shift_heatmaps.png", summary)
    plot_examples(
        output_dir / "v6_measurement_shift_examples.png",
        groups["biological"],
        prepared["biological"],
        examples,
    )
    write_report(output_dir / "V6_MEASUREMENT_SHIFT_REPORT.md", summary)
    print(json.dumps({"output_dir": str(output_dir), "rows": len(rows)}, indent=2), flush=True)


if __name__ == "__main__":
    main()
