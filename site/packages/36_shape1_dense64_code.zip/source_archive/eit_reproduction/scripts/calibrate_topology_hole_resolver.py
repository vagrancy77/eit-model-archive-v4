"""Select the discrete hole resolver using synthetic validation data only."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
from scipy.ndimage import binary_fill_holes
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import calibrate_open_topology_projection as calibration
import train_boolean_shape_eit_v2 as data_tools
import train_topology_residual_eit_v3 as trainer
from pytorch_eit.topology_projection import resolve_closed_holes
from pytorch_eit.topology_residual_net import TopologyResidualEITNet


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--checkpoint", type=Path,
        default=Path(r"E:\Codex\topology_residual_eit_v3_full\topology_residual_v3_best.pt"),
    )
    parser.add_argument(
        "--base-dataset", type=Path, default=ROOT / "datasets" / "ktc_shape_nonlinear_v1.npz"
    )
    parser.add_argument(
        "--biological-dataset", type=Path,
        default=ROOT / "datasets" / "ktc_biological_concavity_v1.npz",
    )
    parser.add_argument(
        "--stress-dataset", type=Path,
        default=ROOT / "datasets" / "ktc_deep_concavity_stress_v1.npz",
    )
    parser.add_argument(
        "--output", type=Path,
        default=Path(r"E:\Codex\topology_residual_eit_v3_full\hole_resolver.json"),
    )
    parser.add_argument("--batch-size", type=int, default=24)
    return parser.parse_args()


def original_prediction(arrays: dict[str, np.ndarray]) -> np.ndarray:
    base = arrays["base"]
    foreground = base[:, 1:].sum(axis=1)
    corrected = np.clip(foreground * (1.0 - 0.98 * arrays["effective"]), 1e-6, 1.0 - 1e-6)
    conditional = base[:, 1:] / np.maximum(foreground[:, None], 1e-6)
    probability = np.concatenate(((1.0 - corrected)[:, None], corrected[:, None] * conditional), axis=1)
    return probability.argmax(axis=1).astype(np.uint8)


def apply_resolver(
    arrays: dict[str, np.ndarray], threshold: float, mouth_weight: float, path_width: int
) -> tuple[np.ndarray, dict[str, float]]:
    prediction = original_prediction(arrays)
    result = np.empty_like(prediction)
    totals = {"holes_seen": 0.0, "holes_opened": 0.0, "holes_filled": 0.0}
    for index in range(len(prediction)):
        result[index], audit = resolve_closed_holes(
            prediction[index], arrays["effective"][index], arrays["mouth"][index],
            float(arrays["gate"][index]), threshold, mouth_weight, path_width,
        )
        for key in totals:
            totals[key] += audit[key]
    return result, totals


def spurious_holes(truth: np.ndarray, prediction: np.ndarray, selected: np.ndarray) -> float:
    values: list[float] = []
    for index in np.flatnonzero(selected):
        truth_fg = truth[index] != 0
        pred_fg = prediction[index] != 0
        pred_holes = binary_fill_holes(pred_fg) & ~pred_fg
        true_holes = binary_fill_holes(truth_fg) & ~truth_fg
        values.append(float((pred_holes & ~true_holes).sum() / max(1, truth_fg.sum())))
    return float(np.mean(values)) if values else 0.0


def main() -> None:
    args = parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    archives = {
        "base": np.load(args.base_dataset.resolve(), allow_pickle=False),
        "biological": np.load(args.biological_dataset.resolve(), allow_pickle=False),
        "stress": np.load(args.stress_dataset.resolve(), allow_pickle=False),
    }
    prepared = {name: data_tools.prepare_arrays(archive, name) for name, archive in archives.items()}
    state = torch.load(args.checkpoint.resolve(), map_location=device, weights_only=False)
    model = TopologyResidualEITNet(
        prepared["base"].fov_mask,
        int(state["base_channels"]),
        int(state.get("propagation_steps", 14)),
        risk_aware=bool(state.get("risk_aware", False)),
    ).to(device)
    model.load_state_dict(state["model"])
    groups: dict[str, dict[str, np.ndarray]] = {}
    direct_metrics: dict[str, dict[str, dict[str, float]]] = {}
    for source, name in enumerate(("base", "biological", "stress")):
        dataset = trainer.DirectStructuralDataset(
            prepared[name], archives[name], archives[name]["validation_indices"], source
        )
        groups[name] = calibration.infer(
            model, DataLoader(dataset, batch_size=args.batch_size, shuffle=False), device
        )
        direct = groups[name]["base"].argmax(axis=1)
        direct_metrics[name] = calibration.split_metrics(
            groups[name]["truth"], direct, groups[name]["cutout"]
        )

    candidates: list[dict[str, object]] = []
    for threshold in (
        0.005, 0.010, 0.020, 0.030, 0.040, 0.050, 0.060, 0.080,
        0.12, 0.16, 0.20, 0.30, 0.48,
    ):
        for mouth_weight in (0.35, 0.55, 0.75, 1.0):
            for path_width in (1, 2):
                metrics: dict[str, dict[str, dict[str, dict[str, float]]]] = {}
                audits: dict[str, dict[str, float]] = {}
                predictions: dict[str, np.ndarray] = {}
                for name, arrays in groups.items():
                    prediction, audits[name] = apply_resolver(
                        arrays, threshold, mouth_weight, path_width
                    )
                    predictions[name] = prediction
                    metrics[name] = {
                        "final": calibration.split_metrics(
                            arrays["truth"], prediction, arrays["cutout"]
                        ),
                        "direct_base": direct_metrics[name],
                    }
                ordinary = groups["biological"]["cutout"].reshape(
                    len(groups["biological"]["cutout"]), -1
                ).sum(axis=1) == 0
                stress_all = np.ones(len(groups["stress"]["truth"]), dtype=bool)
                ordinary_holes = spurious_holes(
                    groups["biological"]["truth"], predictions["biological"], ordinary
                )
                stress_holes = spurious_holes(
                    groups["stress"]["truth"], predictions["stress"], stress_all
                )
                raw_score = trainer.selection_score(metrics)
                objective = raw_score - 1.5 * ordinary_holes - 0.35 * stress_holes
                candidates.append({
                    "confidence_threshold": threshold,
                    "mouth_weight": mouth_weight,
                    "path_width": path_width,
                    "objective": float(objective),
                    "raw_selection_score": float(raw_score),
                    "biological_ordinary_spurious_hole_fraction": ordinary_holes,
                    "stress_spurious_hole_fraction": stress_holes,
                    "metrics": metrics,
                    "resolver_audit": audits,
                })
    candidates.sort(key=lambda row: float(row["objective"]), reverse=True)
    result = {
        "selection_data": "synthetic validation only",
        "synthetic_test_or_public_truth_used": False,
        "best": candidates[0],
        "top_10": candidates[:10],
    }
    args.output.resolve().write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
