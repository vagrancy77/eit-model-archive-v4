import sys
from pathlib import Path

import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from pytorch_eit.models import RegistrationRobustMultiModalEITNet


model = RegistrationRobustMultiModalEITNet(voltage_dim=208, base_channels=8, attention_heads=4)
out = model(
    torch.rand(2, 1, 64, 64),
    torch.rand(2, 208),
    torch.rand(2, 1, 64, 64),
    torch.ones(2, 1),
)
assert out["reconstruction"].shape == (2, 1, 64, 64)
assert out["confidence_map"].shape == (2, 1, 64, 64)
assert out["registration_theta"].shape == (2, 2, 3)
print("registration robust network ok", sum(p.numel() for p in model.parameters()))
