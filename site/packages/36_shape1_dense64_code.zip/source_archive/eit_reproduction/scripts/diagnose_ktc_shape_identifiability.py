from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np
import scipy.io as sio
from scipy.optimize import minimize_scalar
from PIL import Image, ImageDraw
from scipy.spatial import ConvexHull


def parse_args() -> argparse.Namespace:
    project_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=project_root / "external" / "KTC2023-ABC2",
    )
    parser.add_argument("--case", type=int, default=4, choices=(1, 2, 3, 4))
    parser.add_argument(
        "--output",
        type=Path,
        default=project_root / "outputs" / "ktc_shape_identifiability.json",
    )
    return parser.parse_args()


def convex_hull_mask(binary: np.ndarray) -> np.ndarray:
    rows, cols = np.nonzero(binary)
    points = np.column_stack((cols, rows))
    hull = ConvexHull(points)
    canvas = Image.new("1", (binary.shape[1], binary.shape[0]), 0)
    ImageDraw.Draw(canvas).polygon(
        [tuple(point) for point in points[hull.vertices]], outline=1, fill=1
    )
    return np.asarray(canvas, dtype=bool)


def equivalent_ellipse(binary: np.ndarray) -> np.ndarray:
    rows, cols = np.nonzero(binary)
    row_center = float(rows.mean())
    col_center = float(cols.mean())
    covariance = np.cov(np.column_stack((rows, cols)), rowvar=False)
    eigenvalues, eigenvectors = np.linalg.eigh(covariance)
    yy, xx = np.mgrid[: binary.shape[0], : binary.shape[1]]
    coordinates = np.stack((yy - row_center, xx - col_center), axis=-1)
    rotated = coordinates @ eigenvectors
    # Uniform filled ellipse has coordinate variance a^2 / 4.  Rescale both
    # axes to match the target area exactly after rasterization.
    radii = 2.0 * np.sqrt(np.maximum(eigenvalues, 1e-12))
    normalized = np.square(rotated[..., 0] / radii[0]) + np.square(
        rotated[..., 1] / radii[1]
    )
    ellipse = normalized <= 1.0
    scale = np.sqrt(binary.sum() / max(1, ellipse.sum()))
    normalized = np.square(rotated[..., 0] / (radii[0] * scale)) + np.square(
        rotated[..., 1] / (radii[1] * scale)
    )
    return normalized <= 1.0


def resize_for_solver(mask: np.ndarray, size: int = 128) -> np.ndarray:
    image = Image.fromarray(np.asarray(mask, dtype=np.uint8) * 255)
    resampling = getattr(Image, "Resampling", Image).NEAREST
    resized = np.asarray(image.resize((size, size), resample=resampling)) > 127
    # solver flips its 128 image vertically before comparison with truth
    return np.flipud(resized).astype(np.float64)


def fit_shape(
    mask: np.ndarray,
    jacobian: np.ndarray,
    delta_voltage: np.ndarray,
    interpolation: np.ndarray,
) -> dict[str, float]:
    pixels = resize_for_solver(mask).reshape(-1, 1)
    voltage_basis = jacobian @ (interpolation @ pixels)
    numerator = float(np.sum(voltage_basis * delta_voltage))
    denominator = float(np.sum(np.square(voltage_basis)))
    contrast = numerator / denominator if denominator > 0 else 0.0
    residual = voltage_basis * contrast - delta_voltage
    zero_mse = float(np.mean(np.square(delta_voltage)))
    mse = float(np.mean(np.square(residual)))
    return {
        "area_pixels": float(mask.sum()),
        "optimal_contrast": contrast,
        "voltage_mse": mse,
        "relative_mse_to_zero": mse / zero_mse if zero_mse else 0.0,
        "explained_voltage_fraction": 1.0 - mse / zero_mse if zero_mse else 1.0,
    }


def fit_shape_nonlinear(
    mask: np.ndarray,
    matrices: dict[str, object],
    target_scale: float = 2.0,
) -> dict[str, float]:
    interpolation = matrices["interpolation"]
    pixels = resize_for_solver(mask).reshape(-1, 1)
    nodal_mask = interpolation @ pixels
    forward_solver = matrices["forward_solver"]
    sigma0 = np.asarray(matrices["sigma0"], dtype=np.float64)
    contact_impedance = np.asarray(
        matrices["contact_impedance"], dtype=np.float64
    )
    reference_forward = np.asarray(matrices["reference_forward"], dtype=np.float64)
    delta_voltage = np.asarray(matrices["deltaU"], dtype=np.float64) * target_scale
    zero_mse = float(np.mean(np.square(delta_voltage)))

    def objective(contrast: float) -> float:
        conductivity = sigma0 + contrast * nodal_mask
        prediction = forward_solver.SolveForward(
            conductivity.copy(), contact_impedance.copy()
        )
        residual = prediction - reference_forward - delta_voltage
        return float(np.mean(np.square(residual)))

    # The data4 inclusion is resistive.  Keep total conductivity positive.
    optimization = minimize_scalar(
        objective,
        bounds=(-float(sigma0.min()) + 1e-6, 0.0),
        method="bounded",
        options={"xatol": 1e-4, "maxiter": 30},
    )
    mse = float(optimization.fun)
    return {
        "optimal_contrast": float(optimization.x),
        "voltage_mse": mse,
        "relative_mse_to_zero": mse / zero_mse if zero_mse else 0.0,
        "explained_voltage_fraction": 1.0 - mse / zero_mse if zero_mse else 1.0,
        "optimizer_success": bool(optimization.success),
        "optimizer_evaluations": int(optimization.nfev),
    }


def main() -> None:
    args = parse_args()
    repo_root = args.repo_root.resolve()
    os.chdir(repo_root)
    sys.path.insert(0, str(repo_root))
    from utils import solver

    truth = sio.loadmat(repo_root / "groundTruths" / f"true{args.case}.mat")["truth"]
    foreground = truth != 0
    hull = convex_hull_mask(foreground)
    ellipse = equivalent_ellipse(foreground)
    matrices = solver.get_solver_matrices(
        str(repo_root / "inputs" / f"data{args.case}.mat"), 1, 0.7927
    )
    interpolation = solver.calc_dist(
        matrices["coordinates"], x_d=128, y_d=128, mode="lowpass", sigma=8e-3
    )
    matrices["interpolation"] = interpolation
    shapes = {
        "ground_truth": foreground,
        "convex_hull": hull,
        "equivalent_ellipse": ellipse,
    }
    result = {
        "case": args.case,
        "interpretation": (
            "Lower voltage_mse means the shape is more compatible with the measured "
            "voltages under the public solver's fixed linearized forward model."
        ),
        "shapes": {},
    }
    for name, shape in shapes.items():
        result["shapes"][name] = {
            "linear": fit_shape(
                shape, matrices["J"], matrices["deltaU"] * 2.0, interpolation
            ),
            "nonlinear": fit_shape_nonlinear(shape, matrices),
        }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as handle:
        json.dump(result, handle, ensure_ascii=False, indent=2)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
