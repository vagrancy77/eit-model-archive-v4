"""Quick, PyTorch-free validation for the paired public 10/50-kHz data."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description="Validate the public paired multi-frequency EIT adapter.")
    parser.add_argument("--data", type=Path, default=root / "datasets" / "public_us_eit" / "public_us_eit_multifrequency_v1.npz")
    arguments = parser.parse_args()
    data = np.load(arguments.data)
    expected = {"pair_voltages", "pair_targets_gn", "pair_baselines_tikhonov", "frequency_khz", "layers", "voltage_vpp", "pair_ids", "source_indices", "mask"}
    missing = expected.difference(data.files)
    if missing:
        raise AssertionError(f"missing fields: {sorted(missing)}")
    voltage = np.asarray(data["pair_voltages"])
    targets = np.asarray(data["pair_targets_gn"])
    baselines = np.asarray(data["pair_baselines_tikhonov"])
    frequencies = np.asarray(data["frequency_khz"])
    layers = np.asarray(data["layers"])
    amplitudes = np.asarray(data["voltage_vpp"])
    pair_ids = np.asarray(data["pair_ids"])
    source_indices = np.asarray(data["source_indices"])
    mask = np.asarray(data["mask"])
    assert voltage.shape == (6, 2, 416), voltage.shape
    assert targets.shape == (6, 2, 64, 64), targets.shape
    assert baselines.shape == targets.shape, baselines.shape
    assert np.array_equal(frequencies, np.asarray([10.0, 50.0], dtype=np.float32)), frequencies
    assert sorted(np.unique(layers).tolist()) == ["L1", "L2", "L3"], layers
    assert sorted(np.unique(amplitudes).tolist()) == [1, 5], amplitudes
    assert len(np.unique(pair_ids)) == 6, pair_ids
    assert source_indices.shape == (6, 2), source_indices.shape
    assert np.all(np.isfinite(voltage)) and np.all(np.isfinite(targets))
    assert mask.shape == (64, 64) and set(np.unique(mask)).issubset({0.0, 1.0})
    # One 10/50-kHz pair for every layer-amplitude combination proves that the
    # pairing key is complete and suitable for groupwise splitting.
    pairs = {(str(layer), int(amplitude)) for layer, amplitude in zip(layers, amplitudes, strict=True)}
    assert pairs == {(layer, amplitude) for layer in ("L1", "L2", "L3") for amplitude in (1, 5)}, pairs
    print(json.dumps({"status": "passed", "data": str(arguments.data.resolve()), "paired_samples": int(voltage.shape[0]), "frequencies_khz": frequencies.tolist(), "measurements_per_frequency": int(voltage.shape[-1])}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
