from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.io import loadmat


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def load_json(path: Path) -> dict:
    require(path.exists(), f"missing artifact: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    project_root = Path(__file__).resolve().parents[1]
    external_data = project_root / "external" / "GN4IP" / "data"
    training_path = external_data / "training_data_v0.mat"
    test_path = external_data / "test_data_v0.mat"
    weight_path = external_data / "conv_unet_model.pt"
    for path in (training_path, test_path, weight_path):
        require(path.exists(), f"missing public GN4IP artifact: {path}")

    training = loadmat(training_path)
    testing = loadmat(test_path)
    require(training["X2"].shape == (300, 4204), "invalid public training X2")
    require(training["Y"].shape == (300, 4204), "invalid public training Y")
    require(testing["X2"].shape == (10, 4204), "invalid public test X2")
    require(testing["VSIM"].shape == (10, 256), "invalid public test VSIM")
    require(int(testing["n_pixels"].item()) == 32, "invalid public grid size")

    reproduction = load_json(project_root / "outputs_gn4ip" / "summary.json")
    require(
        reproduction["author_output_reproduction"]["relative_l2_error"] < 1e-12,
        "pretrained output does not reproduce the author artifact",
    )
    metrics = reproduction["mean_metrics"]
    require(
        metrics["legacy_unet_correlation"] > metrics["three_step_lm_correlation"],
        "public Conv U-Net does not improve the public LM baseline",
    )
    require(
        metrics["legacy_unet_relative_l2"] < metrics["three_step_lm_relative_l2"],
        "public Conv U-Net does not improve public relative L2",
    )

    short_training = load_json(
        project_root / "outputs_gn4ip" / "short_training" / "summary.json"
    )
    require(
        short_training["final_training_loss"]
        < short_training["initial_training_loss"],
        "short public training loss did not decrease",
    )
    require(
        short_training["final_validation_loss"]
        < short_training["initial_validation_loss"],
        "short public validation loss did not decrease",
    )

    adapter_path = project_root / "datasets" / "cem_gn4ip_v1.mat"
    require(adapter_path.exists(), "missing local CEM to GN4IP adapter output")
    adapter = loadmat(adapter_path)
    require(adapter["X2"].shape == (1024, 560), "invalid adapted X2 shape")
    require(adapter["Y"].shape == (1024, 560), "invalid adapted Y shape")
    require(adapter["closest_elements"].shape == (1024, 1), "invalid pixel map")

    local = load_json(
        project_root / "outputs_gn4ip" / "local_cem" / "summary.json"
    )
    require(
        local["mean_network_correlation"] > local["mean_baseline_correlation"],
        "GN4IP did not improve local CEM correlation",
    )
    require(
        local["mean_network_relative_l2"] < local["mean_baseline_relative_l2"],
        "GN4IP did not improve local CEM relative L2",
    )

    print("GN4IP reproduction validation passed.")
    print(
        "  Author output relative error: "
        f"{reproduction['author_output_reproduction']['relative_l2_error']:.3e}"
    )
    print(
        "  Public correlation LM -> U-Net: "
        f"{metrics['three_step_lm_correlation']:.4f} -> "
        f"{metrics['legacy_unet_correlation']:.4f}"
    )
    print(
        "  Local CEM correlation baseline -> U-Net: "
        f"{local['mean_baseline_correlation']:.4f} -> "
        f"{local['mean_network_correlation']:.4f}"
    )


if __name__ == "__main__":
    main()
