"""Recompute KTC concavity statistics using the audited case IDs.

This script never reads images or model checkpoints. It only combines the
pre-declared non-convex IDs from the independent dataset audit with the frozen
per-case metrics produced after model selection.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


METRICS = (
    "foreground_iou",
    "foreground_dice",
    "boundary_f1",
    "notch_preservation",
    "concavity_score",
    "ktc_ssim",
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--metrics",
        type=Path,
        default=root / "outputs" / "ktc_shape_network_v1" / "real_case_metrics.csv",
    )
    parser.add_argument(
        "--audit",
        type=Path,
        default=root / "outputs" / "ktc2023_full_audit" / "summary.json",
    )
    parser.add_argument(
        "--summary",
        type=Path,
        default=root / "outputs" / "ktc_shape_network_v1" / "summary.json",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=root / "outputs" / "ktc_shape_network_v1" / "strict_17_case_statistics",
    )
    parser.add_argument("--bootstrap-repetitions", type=int, default=10_000)
    parser.add_argument("--seed", type=int, default=20260819)
    parser.add_argument("--candidate", default="shape")
    parser.add_argument("--reference", default="vanilla")
    parser.add_argument("--secondary-reference", default="ridge")
    return parser.parse_args()


def finite_mean(values: list[float]) -> float:
    array = np.asarray(values, dtype=np.float64)
    return float(np.nanmean(array))


def summarize(rows: list[dict[str, str]], ids: set[str]) -> dict[str, dict[str, float]]:
    methods = sorted({row["method"] for row in rows})
    output: dict[str, dict[str, float]] = {}
    for method in methods:
        selected = [row for row in rows if row["method"] == method and row["id"] in ids]
        output[method] = {
            "cases": float(len(selected)),
            **{metric: finite_mean([float(row[metric]) for row in selected]) for metric in METRICS},
        }
    return output


def paired_bootstrap(
    rows: list[dict[str, str]],
    ids: list[str],
    candidate: str,
    reference: str,
    repetitions: int,
    seed: int,
) -> dict[str, dict[str, float]]:
    lookup = {(row["id"], row["method"]): row for row in rows}
    rng = np.random.default_rng(seed)
    output: dict[str, dict[str, float]] = {}
    for metric in METRICS:
        differences = np.asarray(
            [float(lookup[(case_id, candidate)][metric]) - float(lookup[(case_id, reference)][metric]) for case_id in ids],
            dtype=np.float64,
        )
        differences = differences[np.isfinite(differences)]
        indices = rng.integers(0, differences.size, size=(repetitions, differences.size))
        samples = differences[indices].mean(axis=1)
        output[metric] = {
            "cases": float(differences.size),
            "mean_difference": float(differences.mean()),
            "ci95_low": float(np.percentile(samples, 2.5)),
            "ci95_high": float(np.percentile(samples, 97.5)),
            "bootstrap_probability_positive": float((samples > 0).mean()),
        }
    return output


def plot_case_differences(
    path: Path,
    rows: list[dict[str, str]],
    ids: list[str],
    candidate: str,
    reference: str,
) -> None:
    lookup = {(row["id"], row["method"]): row for row in rows}
    figure, axes = plt.subplots(2, 2, figsize=(12.5, 8.5), sharex=True)
    fields = (
        ("foreground_iou", "Foreground IoU"),
        ("boundary_f1", "Boundary F1"),
        ("notch_preservation", "Notch preservation"),
        ("concavity_score", "Joint concavity score"),
    )
    x = np.arange(len(ids))
    for axis, (metric, title) in zip(axes.flat, fields):
        values = np.asarray(
            [
                float(lookup[(case_id, candidate)][metric]) - float(lookup[(case_id, reference)][metric])
                for case_id in ids
            ]
        )
        colors = np.where(values >= 0, "#167d57", "#bb3e3e")
        axis.bar(x, values, color=colors, width=0.78)
        axis.axhline(0, color="#333333", linewidth=0.9)
        axis.set_title(f"{candidate} - {reference}: {title}")
        axis.grid(axis="y", alpha=0.2)
    for axis in axes[-1]:
        axis.set_xticks(x, ids, rotation=55, ha="right", fontsize=8)
    figure.suptitle(
        f"KTC2023 strict 17-case non-convex subgroup: {candidate} - {reference}", fontsize=14
    )
    figure.tight_layout()
    figure.savefig(path, dpi=190)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    audit = json.loads(args.audit.resolve().read_text(encoding="utf-8"))
    ids = [str(case_id) for case_id in audit["nonconvex_ids"]]
    if len(ids) != int(audit["num_nonconvex"]):
        raise RuntimeError("Audit ID count does not match num_nonconvex")
    with args.metrics.resolve().open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    available = {(row["id"], row["method"]) for row in rows}
    required_methods = (args.candidate, args.reference, args.secondary_reference)
    missing = [
        (case_id, method)
        for case_id in ids
        for method in required_methods
        if (case_id, method) not in available
    ]
    if missing:
        raise RuntimeError(f"Missing frozen metrics: {missing}")

    strict_summary = summarize(rows, set(ids))
    bootstrap = {
        f"{args.candidate}_minus_{args.secondary_reference}": paired_bootstrap(
            rows, ids, args.candidate, args.secondary_reference, args.bootstrap_repetitions, args.seed
        ),
        f"{args.candidate}_minus_{args.reference}": paired_bootstrap(
            rows, ids, args.candidate, args.reference, args.bootstrap_repetitions, args.seed + 1
        ),
    }
    result = {
        "definition": "At least one connected lesion instance has >=50 convex-hull indentation pixels and >=3% indentation fraction.",
        "case_ids_fixed_before_model_comparison": True,
        "case_count": len(ids),
        "case_ids": ids,
        "bootstrap_repetitions": args.bootstrap_repetitions,
        "subgroup_mean": strict_summary,
        "paired_bootstrap": bootstrap,
    }
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    plot_case_differences(
        output_dir / "paired_case_differences.png", rows, ids, args.candidate, args.reference
    )

    summary_path = args.summary.resolve()
    if summary_path.exists():
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
        summary["real_materially_concave_test"] = strict_summary
        summary["paired_bootstrap_materially_concave"] = bootstrap
        summary["materially_concave_definition"] = result["definition"]
        summary["materially_concave_ids"] = ids
        summary["materially_concave_statistics_source"] = str((output_dir / "summary.json").resolve())
        summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
