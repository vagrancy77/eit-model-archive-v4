"""Estimate the truth-assisted upper bound of selecting routed v4 or routed v5.

This is a post-hoc diagnostic. Test and public truth are intentionally used to
construct oracle decisions, so none of the resulting policies are deployable or
eligible for training, calibration, checkpoint selection, or claims about an
implementable gate.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import MaxNLocator
from scipy.stats import spearmanr

from aggregate_topology_action_router_multiseed import (
    METRICS,
    build_groups,
    hierarchical_bootstrap,
    lookup,
    matrix,
    parse_runs,
    read_rows,
)


TARGET_GROUPS = (
    "biological_concave",
    "stress_concave",
    "public_ktc_nonconvex",
)
ORDINARY_GROUPS = ("biological_ordinary", "public_ktc_ordinary")
DISPLAY_LABELS = {
    "biological_concave": "Biological concave",
    "stress_concave": "Stress concave",
    "public_ktc_nonconvex": "Public KTC nonconvex",
    "biological_ordinary": "Biological ordinary",
    "public_ktc_ordinary": "Public KTC ordinary",
}
POLICY_LABELS = {
    "v5_always": "Always v5",
    "iou_oracle": "IoU oracle",
    "notch_oracle": "Notch oracle",
    "safe_notch_000": "Safe Notch (0.000)",
    "safe_notch_003": "Safe Notch (0.003)",
    "safe_notch_010": "Safe Notch (0.010)",
    "pareto_oracle": "Strict Pareto oracle",
}
FRONTIER_BUDGETS: tuple[float | None, ...] = (0.0, 0.001, 0.003, 0.005, 0.01, 0.02, None)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--v4-runs", nargs="+", required=True, help="seed=router_directory")
    parser.add_argument("--v5-runs", nargs="+", required=True, help="seed=router_directory")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--bootstrap", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20261001)
    parser.add_argument(
        "--audit",
        type=Path,
        default=root / "outputs" / "ktc2023_full_audit" / "summary.json",
    )
    return parser.parse_args()


def paired_run_paths(
    v4_values: list[str], v5_values: list[str]
) -> tuple[list[str], list[Path], list[Path]]:
    v4 = dict(parse_runs(v4_values))
    v5 = dict(parse_runs(v5_values))
    if set(v4) != set(v5):
        raise ValueError(f"v4/v5 seed mismatch: {sorted(v4)} != {sorted(v5)}")
    seeds = sorted(v4)
    return seeds, [v4[seed] for seed in seeds], [v5[seed] for seed in seeds]


def bootstrap_rate(
    mask: np.ndarray, repetitions: int, rng: np.random.Generator
) -> dict[str, object]:
    result = hierarchical_bootstrap(mask.astype(np.float64), repetitions, rng)
    if result is None:
        raise ValueError("selection mask unexpectedly contains no finite values")
    return {
        "mean": result["mean_difference"],
        "ci95_low": result["ci95_low"],
        "ci95_high": result["ci95_high"],
        "per_seed": result["per_seed_mean_differences"],
        "between_seed_sd": result["between_seed_sd"],
    }


def metric_result(
    difference: np.ndarray,
    choice: np.ndarray,
    repetitions: int,
    rng: np.random.Generator,
) -> dict[str, object] | None:
    selected_difference = np.where(choice, difference, 0.0)
    return hierarchical_bootstrap(selected_difference, repetitions, rng)


def make_policy_masks(differences: dict[str, np.ndarray]) -> dict[str, np.ndarray]:
    iou = differences["foreground_iou"]
    notch = differences["notch_preservation"]
    boundary = differences["boundary_f1"]
    bank = differences["bank_retention"]
    finite = np.isfinite(iou) & np.isfinite(notch) & np.isfinite(boundary) & np.isfinite(bank)
    better_notch = finite & (notch > 0.0)
    return {
        "v5_always": finite,
        "iou_oracle": finite & (iou > 0.0),
        "notch_oracle": better_notch,
        "safe_notch_000": better_notch & (iou >= 0.0),
        "safe_notch_003": better_notch & (iou >= -0.003),
        "safe_notch_010": better_notch & (iou >= -0.010),
        "pareto_oracle": better_notch & (iou >= 0.0) & (boundary >= 0.0) & (bank >= 0.0),
    }


def summarize_policy_set(
    differences: dict[str, np.ndarray],
    policies: dict[str, np.ndarray],
    repetitions: int,
    rng: np.random.Generator,
) -> dict[str, object]:
    policy_results: dict[str, object] = {}
    for policy_name, choice in policies.items():
        metrics: dict[str, object] = {}
        for metric in METRICS:
            result = metric_result(differences[metric], choice, repetitions, rng)
            if result is not None:
                metrics[metric] = result
        selected_iou = np.where(choice, differences["foreground_iou"], 0.0)
        policy_results[policy_name] = {
            "selection_rate": bootstrap_rate(choice, repetitions, rng),
            "metrics": metrics,
            "fraction_all_cases_iou_below_minus_0_01": float(np.mean(selected_iou < -0.01)),
            "fraction_selected_iou_below_minus_0_01": float(
                np.mean(differences["foreground_iou"][choice] < -0.01)
            )
            if choice.any()
            else 0.0,
        }
    return policy_results


def cross_seed_policy_masks(
    differences: dict[str, np.ndarray], mode: str
) -> dict[str, np.ndarray]:
    seed_count = next(iter(differences.values())).shape[0]
    if mode == "all_seed_consensus_oracle":
        mean_differences = {
            metric: np.nanmean(values, axis=0, keepdims=True)
            for metric, values in differences.items()
        }
        masks = make_policy_masks(mean_differences)
        return {name: np.repeat(mask, seed_count, axis=0) for name, mask in masks.items()}
    if mode != "leave_one_seed_out_transfer":
        raise ValueError(f"unknown cross-seed policy mode: {mode}")
    result = {
        name: np.zeros_like(differences["foreground_iou"], dtype=bool)
        for name in make_policy_masks(
            {metric: values[:1] for metric, values in differences.items()}
        )
    }
    for held_out in range(seed_count):
        train_indices = [index for index in range(seed_count) if index != held_out]
        mean_differences = {
            metric: np.nanmean(values[train_indices], axis=0, keepdims=True)
            for metric, values in differences.items()
        }
        fold_masks = make_policy_masks(mean_differences)
        for name, mask in fold_masks.items():
            result[name][held_out] = mask[0]
    return result


def summarize_stability(choice: np.ndarray) -> dict[str, object]:
    count = choice.sum(axis=0)
    histogram = {str(value): int(np.sum(count == value)) for value in range(choice.shape[0] + 1)}
    total = choice.shape[1]
    return {
        "case_count": total,
        "beneficial_seed_count_histogram": histogram,
        "fraction_beneficial_at_least_1_of_4": float(np.mean(count >= 1)),
        "fraction_beneficial_at_least_3_of_4": float(np.mean(count >= 3)),
        "fraction_beneficial_4_of_4": float(np.mean(count == choice.shape[0])),
    }


def summarize_concave_group(
    v4_lookups: list[dict[tuple[str, str], dict[str, str]]],
    v5_lookups: list[dict[tuple[str, str], dict[str, str]]],
    ids: list[str],
    repetitions: int,
    rng: np.random.Generator,
) -> tuple[dict[str, object], dict[str, np.ndarray]]:
    v4 = {metric: matrix(v4_lookups, ids, "topology_routed", metric) for metric in METRICS}
    v5 = {metric: matrix(v5_lookups, ids, "topology_routed", metric) for metric in METRICS}
    differences = {metric: v5[metric] - v4[metric] for metric in METRICS}
    policies = make_policy_masks(differences)
    policy_modes = {
        "per_seed_truth_oracle": summarize_policy_set(
            differences, policies, repetitions, rng
        ),
        "all_seed_consensus_truth_oracle": summarize_policy_set(
            differences,
            cross_seed_policy_masks(differences, "all_seed_consensus_oracle"),
            repetitions,
            rng,
        ),
        "leave_one_seed_out_truth_transfer": summarize_policy_set(
            differences,
            cross_seed_policy_masks(differences, "leave_one_seed_out_transfer"),
            repetitions,
            rng,
        ),
    }

    iou = differences["foreground_iou"]
    notch = differences["notch_preservation"]
    finite = np.isfinite(iou) & np.isfinite(notch)
    correlation = spearmanr(iou[finite], notch[finite])
    quadrants = {
        "better_iou_better_notch": float(np.mean((iou[finite] > 0.0) & (notch[finite] > 0.0))),
        "worse_iou_better_notch": float(np.mean((iou[finite] <= 0.0) & (notch[finite] > 0.0))),
        "better_iou_worse_notch": float(np.mean((iou[finite] > 0.0) & (notch[finite] <= 0.0))),
        "worse_iou_worse_notch": float(np.mean((iou[finite] <= 0.0) & (notch[finite] <= 0.0))),
    }
    stability = {
        "notch_oracle": summarize_stability(policies["notch_oracle"]),
        "safe_notch_003": summarize_stability(policies["safe_notch_003"]),
        "pareto_oracle": summarize_stability(policies["pareto_oracle"]),
    }
    return (
        {
            "case_count": len(ids),
            "seed_case_count": int(finite.sum()),
            "spearman_iou_vs_notch": {
                "rho": float(correlation.statistic),
                "pvalue": float(correlation.pvalue),
            },
            "quadrants": quadrants,
            "policies": policy_modes["per_seed_truth_oracle"],
            "policy_modes": policy_modes,
            "cross_seed_stability": stability,
        },
        differences,
    )


def summarize_ordinary_group(
    v4_lookups: list[dict[tuple[str, str], dict[str, str]]],
    v5_lookups: list[dict[tuple[str, str], dict[str, str]]],
    ids: list[str],
    repetitions: int,
    rng: np.random.Generator,
) -> dict[str, object]:
    differences = {
        metric: matrix(v5_lookups, ids, "topology_routed", metric)
        - matrix(v4_lookups, ids, "topology_routed", metric)
        for metric in METRICS
    }
    finite = np.isfinite(differences["foreground_iou"])
    masks = {
        "v5_always": finite,
        "iou_oracle": finite & (differences["foreground_iou"] > 0.0),
        "v4_fallback": np.zeros_like(finite, dtype=bool),
    }
    policies: dict[str, object] = {}
    for name, choice in masks.items():
        metrics: dict[str, object] = {}
        for metric in ("foreground_iou", "foreground_dice", "boundary_f1", "bank_retention"):
            result = metric_result(differences[metric], choice, repetitions, rng)
            if result is not None:
                metrics[metric] = result
        policies[name] = {
            "selection_rate": bootstrap_rate(choice, repetitions, rng),
            "metrics": metrics,
        }
    return {"case_count": len(ids), "policies": policies}


def frontier_rows(
    group_name: str,
    differences: dict[str, np.ndarray],
    repetitions: int,
    rng: np.random.Generator,
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    iou = differences["foreground_iou"]
    notch = differences["notch_preservation"]
    finite = np.isfinite(iou) & np.isfinite(notch)
    for budget in FRONTIER_BUDGETS:
        choice = finite & (notch > 0.0)
        if budget is not None:
            choice &= iou >= -budget
        iou_result = metric_result(iou, choice, repetitions, rng)
        notch_result = metric_result(notch, choice, repetitions, rng)
        rate = bootstrap_rate(choice, repetitions, rng)
        if iou_result is None or notch_result is None:
            continue
        rows.append(
            {
                "group": group_name,
                "iou_budget": budget,
                "budget_label": "unbounded" if budget is None else f"{budget:.3f}",
                "selection_rate": rate["mean"],
                "iou_delta": iou_result["mean_difference"],
                "iou_ci95_low": iou_result["ci95_low"],
                "iou_ci95_high": iou_result["ci95_high"],
                "notch_delta": notch_result["mean_difference"],
                "notch_ci95_low": notch_result["ci95_low"],
                "notch_ci95_high": notch_result["ci95_high"],
            }
        )
    return rows


def write_policy_table(path: Path, groups: dict[str, dict[str, object]]) -> None:
    rows: list[dict[str, object]] = []
    for group_name in TARGET_GROUPS:
        for mode_name, policies in groups[group_name]["policy_modes"].items():
            for policy_name, policy in policies.items():
                row: dict[str, object] = {
                    "group": group_name,
                    "cases": groups[group_name]["case_count"],
                    "decision_mode": mode_name,
                    "policy": policy_name,
                    "selection_rate": policy["selection_rate"]["mean"],
                    "fraction_selected_iou_below_minus_0_01": policy[
                        "fraction_selected_iou_below_minus_0_01"
                    ],
                }
                for metric in ("foreground_iou", "boundary_f1", "notch_preservation", "bank_retention"):
                    value = policy["metrics"][metric]
                    prefix = {
                        "foreground_iou": "iou",
                        "boundary_f1": "boundary",
                        "notch_preservation": "notch",
                        "bank_retention": "bank",
                    }[metric]
                    row[f"{prefix}_delta"] = value["mean_difference"]
                    row[f"{prefix}_ci95_low"] = value["ci95_low"]
                    row[f"{prefix}_ci95_high"] = value["ci95_high"]
                rows.append(row)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def write_frontier_table(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def plot_frontier(path: Path, rows: list[dict[str, object]]) -> None:
    figure, axes = plt.subplots(1, 3, figsize=(13.2, 4.4), squeeze=False)
    for axis, group_name in zip(axes.flat, TARGET_GROUPS):
        selected = [row for row in rows if row["group"] == group_name]
        x = np.asarray([row["iou_delta"] for row in selected])
        y = np.asarray([row["notch_delta"] for row in selected])
        rates = np.asarray([row["selection_rate"] for row in selected])
        axis.plot(x, y, color="#5f6b73", linewidth=1.3, alpha=0.8)
        scatter = axis.scatter(x, y, c=rates, cmap="viridis", s=58, edgecolors="#222222")
        for row in selected:
            label = row["budget_label"]
            if label in {"0.000", "0.003", "0.010", "unbounded"}:
                axis.annotate(
                    label,
                    (row["iou_delta"], row["notch_delta"]),
                    xytext=(4, 5),
                    textcoords="offset points",
                    fontsize=8,
                )
        axis.axvline(0.0, color="#333333", linewidth=0.9)
        axis.axhline(0.0, color="#333333", linewidth=0.9)
        axis.set_title(DISPLAY_LABELS[group_name])
        axis.set_xlabel("Mean IoU change vs v4")
        axis.set_ylabel("Mean Notch change vs v4")
        axis.grid(alpha=0.18)
        figure.colorbar(scatter, ax=axis, fraction=0.047, pad=0.03, label="v5 selection rate")
    figure.suptitle("Truth-assisted safe-Notch oracle frontier across four seeds")
    figure.tight_layout()
    figure.savefig(path, dpi=240)
    plt.close(figure)


def plot_quadrants(path: Path, differences_by_group: dict[str, dict[str, np.ndarray]]) -> None:
    figure, axes = plt.subplots(1, 3, figsize=(13.0, 4.2), squeeze=False)
    for axis, group_name in zip(axes.flat, TARGET_GROUPS):
        differences = differences_by_group[group_name]
        x = differences["foreground_iou"].ravel()
        y = differences["notch_preservation"].ravel()
        finite = np.isfinite(x) & np.isfinite(y)
        x = x[finite]
        y = y[finite]
        axis.scatter(x, y, s=10, alpha=0.26, color="#2f6f9f", edgecolors="none")
        axis.axvline(0.0, color="#333333", linewidth=0.9)
        axis.axhline(0.0, color="#333333", linewidth=0.9)
        both = np.mean((x > 0.0) & (y > 0.0))
        tradeoff = np.mean((x <= 0.0) & (y > 0.0))
        axis.text(
            0.02,
            0.98,
            f"both improve: {both:.1%}\nNotch up / IoU down: {tradeoff:.1%}",
            transform=axis.transAxes,
            va="top",
            fontsize=9,
        )
        axis.set_title(DISPLAY_LABELS[group_name])
        axis.set_xlabel("Per-case IoU change (v5 - v4)")
        axis.set_ylabel("Per-case Notch change (v5 - v4)")
        axis.grid(alpha=0.16)
    figure.suptitle("Per-case complementarity of routed v4 and v5")
    figure.tight_layout()
    figure.savefig(path, dpi=240)
    plt.close(figure)


def plot_stability(path: Path, groups: dict[str, dict[str, object]]) -> None:
    figure, axes = plt.subplots(1, 3, figsize=(12.6, 3.9), squeeze=False)
    for axis, group_name in zip(axes.flat, TARGET_GROUPS):
        hist = groups[group_name]["cross_seed_stability"]["safe_notch_003"][
            "beneficial_seed_count_histogram"
        ]
        counts = np.asarray([hist[str(value)] for value in range(5)], dtype=float)
        fractions = counts / counts.sum()
        axis.bar(np.arange(5), fractions, color="#4f8b64")
        axis.set_xticks(np.arange(5))
        axis.set_ylim(0.0, max(0.55, fractions.max() * 1.16))
        for index, value in enumerate(fractions):
            axis.text(index, value + 0.012, f"{value:.1%}", ha="center", fontsize=8)
        axis.set_title(DISPLAY_LABELS[group_name])
        axis.set_xlabel("Seeds where safe v5 action is beneficial (of 4)")
        axis.set_ylabel("Fraction of cases")
        axis.grid(axis="y", alpha=0.18)
    figure.suptitle("Cross-seed stability of the 0.003-IoU-budget oracle action")
    figure.tight_layout()
    figure.savefig(path, dpi=240)
    plt.close(figure)


def plot_transfer(path: Path, groups: dict[str, dict[str, object]]) -> None:
    modes = (
        "per_seed_truth_oracle",
        "all_seed_consensus_truth_oracle",
        "leave_one_seed_out_truth_transfer",
    )
    mode_labels = ("Per-seed oracle", "All-seed consensus", "Leave-one-seed-out")
    colors = ("#2f6f9f", "#4f8b64", "#c26d2d")
    figure, axes = plt.subplots(1, 3, figsize=(13.0, 4.8), squeeze=False)
    for axis, group_name in zip(axes.flat, TARGET_GROUPS):
        for index, (mode, label, color) in enumerate(zip(modes, mode_labels, colors)):
            policy = groups[group_name]["policy_modes"][mode]["safe_notch_003"]
            iou = policy["metrics"]["foreground_iou"]
            notch = policy["metrics"]["notch_preservation"]
            axis.errorbar(
                iou["mean_difference"],
                notch["mean_difference"],
                xerr=[
                    [iou["mean_difference"] - iou["ci95_low"]],
                    [iou["ci95_high"] - iou["mean_difference"]],
                ],
                yerr=[
                    [notch["mean_difference"] - notch["ci95_low"]],
                    [notch["ci95_high"] - notch["mean_difference"]],
                ],
                fmt="o",
                color=color,
                markersize=7,
                capsize=3,
                label=label if group_name == TARGET_GROUPS[0] else None,
            )
            axis.annotate(
                f"{policy['selection_rate']['mean']:.0%}",
                (iou["mean_difference"], notch["mean_difference"]),
                xytext=(4, 4 + 8 * index),
                textcoords="offset points",
                fontsize=8,
            )
        axis.axvline(0.0, color="#333333", linewidth=0.9)
        axis.axhline(0.0, color="#333333", linewidth=0.9)
        axis.set_title(DISPLAY_LABELS[group_name])
        axis.set_xlabel("Mean IoU change vs v4")
        axis.set_ylabel("Mean Notch change vs v4")
        axis.xaxis.set_major_locator(MaxNLocator(nbins=4))
        axis.grid(alpha=0.18)
    figure.suptitle(
        "0.003-budget oracle: optimistic ceiling versus cross-seed transfer",
        y=0.985,
    )
    figure.legend(
        loc="upper center",
        bbox_to_anchor=(0.5, 0.925),
        ncol=3,
        frameon=False,
    )
    figure.tight_layout(rect=(0.0, 0.0, 1.0, 0.84))
    figure.savefig(path, dpi=240)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    seeds, v4_paths, v5_paths = paired_run_paths(args.v4_runs, args.v5_runs)
    v4_rows = [read_rows(path / "action_router_case_metrics.csv") for path in v4_paths]
    v5_rows = [read_rows(path / "action_router_case_metrics.csv") for path in v5_paths]
    audit = json.loads(args.audit.resolve().read_text(encoding="utf-8"))
    strict_ids = {str(value) for value in audit["nonconvex_ids"]}
    v4_groups = build_groups(v4_rows[0], strict_ids)
    v5_groups = build_groups(v5_rows[0], strict_ids)
    if v4_groups != v5_groups:
        raise ValueError("v4/v5 case groups are not identical")
    v4_lookups = [lookup(rows) for rows in v4_rows]
    v5_lookups = [lookup(rows) for rows in v5_rows]
    rng = np.random.default_rng(args.seed)

    groups: dict[str, dict[str, object]] = {}
    differences_by_group: dict[str, dict[str, np.ndarray]] = {}
    frontier: list[dict[str, object]] = []
    for group_name in TARGET_GROUPS:
        result, differences = summarize_concave_group(
            v4_lookups,
            v5_lookups,
            v4_groups[group_name],
            args.bootstrap,
            rng,
        )
        groups[group_name] = result
        differences_by_group[group_name] = differences
        frontier.extend(frontier_rows(group_name, differences, args.bootstrap, rng))
    for group_name in ORDINARY_GROUPS:
        groups[group_name] = summarize_ordinary_group(
            v4_lookups,
            v5_lookups,
            v4_groups[group_name],
            args.bootstrap,
            rng,
        )

    result = {
        "analysis": "truth-assisted oracle ceiling for choosing routed v4 or routed v5",
        "deployable": False,
        "test_and_public_truth_used_for_oracle_decisions": True,
        "prohibited_uses": [
            "training",
            "checkpoint selection",
            "resolver calibration",
            "gate threshold selection",
            "claiming performance of an implementable selector",
        ],
        "seeds": seeds,
        "v4_runs": {seed: str(path) for seed, path in zip(seeds, v4_paths)},
        "v5_runs": {seed: str(path) for seed, path in zip(seeds, v5_paths)},
        "bootstrap_repetitions": args.bootstrap,
        "bootstrap_design": "paired hierarchical resampling of matched seeds and cases",
        "groups": groups,
        "frontier": frontier,
    }
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "oracle_ceiling_summary.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    write_policy_table(output_dir / "oracle_policy_table.csv", groups)
    write_frontier_table(output_dir / "oracle_frontier_table.csv", frontier)
    plot_frontier(output_dir / "oracle_tradeoff_frontier.png", frontier)
    plot_quadrants(output_dir / "oracle_case_quadrants.png", differences_by_group)
    plot_stability(output_dir / "oracle_seed_consistency.png", groups)
    plot_transfer(output_dir / "oracle_cross_seed_transfer.png", groups)
    print(
        json.dumps(
            {
                "seeds": seeds,
                "groups": {name: groups[name]["case_count"] for name in groups},
                "bootstrap": args.bootstrap,
                "output_dir": str(output_dir),
            },
            indent=2,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
