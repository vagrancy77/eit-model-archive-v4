"""Audit instance-wise, exterior-connected bay candidates on public KTC2023.

This is a representation audit, not a deployable reconstruction claim.  A
frozen neural reconstruction supplies lesion instances and conductivity
polarity.  Each instance is independently expanded and carved by a
low-dimensional exterior-connected bay family.  Public labels are opened only
after every geometric candidate and its measurement residual have been
computed.  The case-wise oracle therefore measures whether this shape family
can represent the missing concavity; it is explicitly not an inference rule.

The construction follows the topology-to-shape strategy used in EIT shape
optimization: preserve a reliable topology/class initialization, then search a
continuous boundary family.  Unlike the earlier carve-only graph cut, these
candidates may both add outer support and remove an inward bay.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from scipy import ndimage as ndi

from train_ktc_concavity_network_v2 import evaluate_real_predictions


STRICT_INWARD_IDS = (
    "level_2/1", "level_2/3", "level_3/2", "level_5/2",
    "level_6/2", "level_6/3", "level_7/1", "level_7/2", "level_7/3",
)


@dataclass(frozen=True)
class BaySpec:
    class_id: int
    component_rank: int
    angle_degrees: float
    profile: str
    depth_fraction: float
    width_fraction: float
    expansion_fraction: float
    lateral_offset_fraction: float = 0.0
    curvature_fraction: float = 0.0
    asymmetry_fraction: float = 0.0
    branch_fraction: float = 0.0


@dataclass(frozen=True)
class PhysicsRule:
    name: str
    penalty: float
    min_gain: float
    max_component_removal: float
    min_fold_agreement: float


PHYSICS_RULES = (
    PhysicsRule("residual_only", 0.0, 0.0, 0.60, 0.00),
    PhysicsRule("mild", 0.10, 0.0003, 0.50, 0.50),
    PhysicsRule("balanced", 0.30, 0.0010, 0.42, 0.50),
    PhysicsRule("guarded", 0.80, 0.0030, 0.32, 0.75),
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz"
    )
    parser.add_argument(
        "--pool", type=Path,
        default=root / "outputs" / "ktc_cross_representation_pool_seed20260820" / "public_21.npz",
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=root / "outputs" / "ktc_instance_bay_audit_seed20260820",
    )
    parser.add_argument("--angles", type=int, default=12)
    parser.add_argument("--max-components", type=int, default=3)
    parser.add_argument("--min-component-fraction", type=float, default=0.0015)
    parser.add_argument("--physics-chunk", type=int, default=256)
    parser.add_argument("--seed", type=int, default=20260820)
    return parser.parse_args()


def nearest_resize(labels: np.ndarray, size: int) -> np.ndarray:
    """Resize integer labels with deterministic centre-aligned nearest sampling."""
    source_h, source_w = labels.shape[-2:]
    rows = np.rint((np.arange(size) + 0.5) * source_h / size - 0.5).astype(np.int64)
    columns = np.rint((np.arange(size) + 0.5) * source_w / size - 0.5).astype(np.int64)
    rows = np.clip(rows, 0, source_h - 1)
    columns = np.clip(columns, 0, source_w - 1)
    return labels[..., rows[:, None], columns[None, :]]


def foreground_iou(truth: np.ndarray, prediction: np.ndarray) -> float:
    target = truth != 0
    estimate = prediction != 0
    return float(np.logical_and(target, estimate).sum() / max(1, np.logical_or(target, estimate).sum()))


def exterior_background(foreground: np.ndarray) -> np.ndarray:
    components, _ = ndi.label(~foreground, structure=np.ones((3, 3), dtype=np.uint8))
    border_ids = np.unique(
        np.concatenate((components[0], components[-1], components[:, 0], components[:, -1]))
    )
    return np.isin(components, border_ids[border_ids != 0])


def new_hole_pixels(before: np.ndarray, after: np.ndarray) -> int:
    before_holes = ndi.binary_fill_holes(before) & ~before
    after_holes = ndi.binary_fill_holes(after) & ~after
    return int(np.logical_and(after_holes, ~before_holes).sum())


def component_records(
    labels: np.ndarray,
    max_components: int,
    min_fraction: float,
) -> list[dict[str, object]]:
    records: list[dict[str, object]] = []
    min_pixels = max(8, int(round(labels.size * min_fraction)))
    for class_id in (1, 2):
        components, count = ndi.label(labels == class_id, structure=np.ones((3, 3), dtype=np.uint8))
        for component_id in range(1, count + 1):
            mask = components == component_id
            area = int(mask.sum())
            if area < min_pixels:
                continue
            coordinates = np.argwhere(mask)
            records.append(
                {
                    "class_id": class_id,
                    "mask": mask,
                    "area": area,
                    "centroid": coordinates.mean(axis=0),
                }
            )
    records.sort(key=lambda value: int(value["area"]), reverse=True)
    return records[:max_components]


def bay_half_width(profile: str, t: np.ndarray, base_width: float) -> np.ndarray:
    if profile == "u":
        return base_width * (0.88 + 0.12 * np.sin(0.5 * np.pi * t))
    if profile == "v":
        return base_width * (1.00 - 0.78 * t)
    if profile == "keyhole":
        chamber = np.exp(-0.5 * np.square((t - 0.68) / 0.20))
        return base_width * (0.42 + 1.75 * chamber)
    raise ValueError(f"unknown bay profile: {profile}")


def apply_bay(
    labels: np.ndarray,
    component: dict[str, object],
    spec: BaySpec,
) -> tuple[np.ndarray, dict[str, float]] | None:
    component_mask = np.asarray(component["mask"], dtype=bool)
    class_id = int(component["class_id"])
    area = int(component["area"])
    centroid = np.asarray(component["centroid"], dtype=np.float64)
    foreground_before = labels != 0
    fov = np.indices(labels.shape)
    centre = (np.asarray(labels.shape, dtype=np.float64) - 1.0) / 2.0
    radius = min(labels.shape) * 0.49
    fov_mask = np.square(fov[0] - centre[0]) + np.square(fov[1] - centre[1]) <= radius * radius

    equivalent_radius = math.sqrt(area / math.pi)
    expansion_pixels = int(round(spec.expansion_fraction * equivalent_radius))
    if expansion_pixels:
        expanded = ndi.binary_dilation(
            component_mask,
            structure=ndi.generate_binary_structure(2, 2),
            iterations=expansion_pixels,
        )
        expanded &= fov_mask
        expanded &= np.logical_or(~foreground_before, component_mask)
    else:
        expanded = component_mask.copy()

    angle = math.radians(spec.angle_degrees)
    # Image rows point down.  This convention still covers the full circle and
    # keeps reported angles deterministic.
    direction = np.asarray((math.sin(angle), math.cos(angle)), dtype=np.float64)
    tangent = np.asarray((-direction[1], direction[0]), dtype=np.float64)
    coordinates = np.argwhere(expanded)
    centred = coordinates - centroid[None]
    projection = centred @ direction
    lateral_values = centred @ tangent
    front = float(projection.max())
    span = max(2.0, front - float(projection.min()))
    depth = max(2.0, spec.depth_fraction * span)
    base_width = max(1.25, spec.width_fraction * equivalent_radius)

    yy, xx = np.indices(labels.shape, dtype=np.float64)
    rel_y = yy - centroid[0]
    rel_x = xx - centroid[1]
    axial = front - (rel_y * direction[0] + rel_x * direction[1])
    lateral = rel_y * tangent[0] + rel_x * tangent[1]
    t = np.clip(axial / depth, 0.0, 1.0)
    half_width = bay_half_width(spec.profile, t, base_width)
    centreline = equivalent_radius * (
        spec.lateral_offset_fraction
        + spec.curvature_fraction * np.sin(np.pi * t)
    )
    asymmetry = float(np.clip(spec.asymmetry_fraction, -0.65, 0.65))
    left_width = half_width * (1.0 + asymmetry)
    right_width = half_width * (1.0 - asymmetry)
    lateral_delta = lateral - centreline
    inside = (lateral_delta >= -left_width) & (lateral_delta <= right_width)
    if spec.branch_fraction > 0.0:
        branch_ramp = np.clip((t - 0.28) / 0.72, 0.0, 1.0)
        branch_offset = spec.branch_fraction * equivalent_radius * branch_ramp
        branch_width = 0.72 * half_width
        left_branch = np.abs(lateral - (centreline - branch_offset)) <= branch_width
        right_branch = np.abs(lateral - (centreline + branch_offset)) <= branch_width
        inside |= left_branch | right_branch
    # Starting slightly outside the support guarantees a 4/8-connected mouth
    # after discretization; the validity test below still rejects closed holes.
    bay = (axial >= -1.75) & (axial <= depth) & inside

    candidate = labels.copy()
    candidate[expanded] = class_id
    removed = bay & (candidate == class_id)
    candidate[removed] = 0
    foreground_after = candidate != 0
    original_removed = component_mask & ~foreground_after
    added = ~foreground_before & foreground_after
    removed_fraction = float(original_removed.sum() / max(area, 1))
    added_fraction = float(added.sum() / max(area, 1))
    if original_removed.sum() < max(3, int(round(0.015 * area))):
        return None
    if removed_fraction > 0.62:
        return None
    holes = new_hole_pixels(foreground_before, foreground_after)
    if holes:
        return None
    exterior = exterior_background(foreground_after)
    open_fraction = float((exterior & original_removed).sum() / max(1, int(original_removed.sum())))
    if open_fraction < 0.995:
        return None
    remaining = component_mask & foreground_after
    if int(remaining.sum()) < max(6, int(round(0.30 * area))):
        return None
    return candidate, {
        "removed_fraction": removed_fraction,
        "added_fraction": added_fraction,
        "open_removed_fraction": open_fraction,
        "new_hole_pixels": float(holes),
        "equivalent_radius": equivalent_radius,
        "span": span,
    }


def apply_expansion(
    labels: np.ndarray,
    component: dict[str, object],
    class_id: int,
    expansion_fraction: float,
) -> tuple[np.ndarray, dict[str, float]] | None:
    mask = np.asarray(component["mask"], dtype=bool)
    area = int(component["area"])
    equivalent_radius = math.sqrt(area / math.pi)
    pixels = max(1, int(round(expansion_fraction * equivalent_radius)))
    yy, xx = np.indices(labels.shape, dtype=np.float64)
    centre = (np.asarray(labels.shape, dtype=np.float64) - 1.0) / 2.0
    fov = np.square(yy - centre[0]) + np.square(xx - centre[1]) <= (min(labels.shape) * 0.49) ** 2
    expanded = ndi.binary_dilation(
        mask, structure=ndi.generate_binary_structure(2, 2), iterations=pixels
    )
    expanded &= fov
    expanded &= np.logical_or(labels == 0, mask)
    candidate = labels.copy()
    candidate[expanded] = class_id
    added = (candidate != 0) & (labels == 0)
    if not np.any(added):
        return None
    return candidate, {
        "removed_fraction": 0.0,
        "added_fraction": float(added.sum() / max(area, 1)),
        "open_removed_fraction": 1.0,
        "new_hole_pixels": 0.0,
        "equivalent_radius": equivalent_radius,
        "span": 0.0,
    }


def generate_candidates(
    labels: np.ndarray,
    angles: int,
    max_components: int,
    min_component_fraction: float,
) -> tuple[np.ndarray, list[dict[str, object]]]:
    candidates = [labels.copy()]
    metadata: list[dict[str, object]] = [
        {
            "kind": "identity", "component_rank": -1, "class_id": 0,
            "removed_fraction": 0.0, "added_fraction": 0.0,
            "open_removed_fraction": 1.0, "new_hole_pixels": 0.0,
        }
    ]
    seen = {labels.tobytes()}
    components = component_records(labels, max_components, min_component_fraction)
    angle_values = np.linspace(0.0, 360.0, angles, endpoint=False)
    for rank, component in enumerate(components):
        class_id = int(component["class_id"])
        expansion = apply_expansion(labels, component, class_id, 0.10)
        if expansion is not None and expansion[0].tobytes() not in seen:
            seen.add(expansion[0].tobytes())
            candidates.append(expansion[0])
            metadata.append(
                {
                    "kind": "expansion", "component_rank": rank, "class_id": class_id,
                    "expansion_fraction": 0.10, **expansion[1],
                }
            )
        for angle in angle_values:
            for profile in ("u", "v", "keyhole"):
                for depth_fraction in (0.48, 0.72):
                    for expansion_fraction in (0.0, 0.08):
                        spec = BaySpec(
                            class_id=class_id,
                            component_rank=rank,
                            angle_degrees=float(angle),
                            profile=profile,
                            depth_fraction=depth_fraction,
                            width_fraction=0.32,
                            expansion_fraction=expansion_fraction,
                        )
                        result = apply_bay(labels, component, spec)
                        if result is None:
                            continue
                        candidate, diagnostics = result
                        key = candidate.tobytes()
                        if key in seen:
                            continue
                        seen.add(key)
                        candidates.append(candidate)
                        metadata.append({"kind": "bay", **asdict(spec), **diagnostics})
    return np.stack(candidates).astype(np.uint8), metadata


def generate_expanded_pure_candidates(
    labels: np.ndarray,
    angles: int = 16,
    max_components: int = 3,
    min_component_fraction: float = 0.0015,
) -> tuple[np.ndarray, list[dict[str, object]]]:
    """Generate a topology-audited bank of pure, exterior-connected bays.

    The bank is deterministic and label-free.  It broadens the original radial
    U/V/keyhole family with shallow/narrow scales, off-centre mouths, curved
    centre lines, asymmetric banks, and a connected bifurcating cut.  No
    compensating support expansion is allowed.
    """
    candidates = [labels.copy()]
    metadata: list[dict[str, object]] = [{
        "kind": "identity", "component_rank": -1, "class_id": 0,
        "removed_fraction": 0.0, "added_fraction": 0.0,
        "open_removed_fraction": 1.0, "new_hole_pixels": 0.0,
    }]
    seen = {labels.tobytes()}
    components = component_records(labels, max_components, min_component_fraction)
    angle_values = np.linspace(0.0, 360.0, angles, endpoint=False)

    def append_spec(component: dict[str, object], spec: BaySpec, rank: int) -> None:
        result = apply_bay(labels, component, spec)
        if result is None:
            return
        candidate, diagnostics = result
        key = candidate.tobytes()
        if key in seen:
            return
        seen.add(key)
        candidates.append(candidate)
        metadata.append({"kind": "bay", **asdict(spec), **diagnostics})

    for rank, component in enumerate(components):
        class_id = int(component["class_id"])
        # Dense straight bank: especially important for the shallow heart-like
        # indentations absent from the original 0.48/0.72-depth family.
        for angle in angle_values:
            for profile in ("u", "v", "keyhole"):
                for depth_fraction in (0.18, 0.32, 0.50, 0.72):
                    for width_fraction in (0.12, 0.22, 0.36):
                        append_spec(component, BaySpec(
                            class_id, rank, float(angle), profile,
                            depth_fraction, width_fraction, 0.0,
                        ), rank)

        # The deformed templates are sampled on interleaved angles so the bank
        # stays tractable while covering geometry missing from radial cuts.
        for angle in angle_values[::2]:
            deformations = (
                (0.26, 0.00, 0.00, 0.00),
                (-0.26, 0.00, 0.00, 0.00),
                (0.00, 0.32, 0.00, 0.00),
                (0.00, -0.32, 0.00, 0.00),
                (0.00, 0.00, 0.40, 0.00),
                (0.00, 0.00, -0.40, 0.00),
            )
            for offset, curvature, asymmetry, branch in deformations:
                for profile in ("u", "v"):
                    for depth_fraction in (0.38, 0.64):
                        for width_fraction in (0.16, 0.28):
                            append_spec(component, BaySpec(
                                class_id, rank, float(angle), profile,
                                depth_fraction, width_fraction, 0.0,
                                offset, curvature, asymmetry, branch,
                            ), rank)
            for profile in ("v", "keyhole"):
                for depth_fraction in (0.50, 0.72):
                    for width_fraction in (0.16, 0.26):
                        append_spec(component, BaySpec(
                            class_id, rank, float(angle), profile,
                            depth_fraction, width_fraction, 0.0,
                            branch_fraction=0.24,
                        ), rank)
    return np.stack(candidates).astype(np.uint8), metadata


def fit_voltage_cv_torch(
    labels: np.ndarray,
    voltage: np.ndarray,
    jacobian: torch.Tensor,
    node_map: torch.Tensor,
    chunk_size: int,
    folds: int = 4,
) -> np.ndarray:
    """Fit two nonnegative class amplitudes and test on held-out drives."""
    device = jacobian.device
    target = torch.from_numpy(np.asarray(voltage, dtype=np.float32)).to(device)
    if target.numel() % 31:
        raise ValueError("KTC voltage vector must contain 31 measurements per drive pattern")
    drive_ids = torch.repeat_interleave(
        torch.arange(target.numel() // 31, device=device), 31
    )
    outputs: list[np.ndarray] = []
    for start in range(0, len(labels), chunk_size):
        values = torch.from_numpy(labels[start : start + chunk_size].astype(np.int64)).to(device)
        negative = torch.flip(values == 1, dims=(1,)).flatten(1).float()[:, node_map]
        positive = torch.flip(values == 2, dims=(1,)).flatten(1).float()[:, node_map]
        basis_negative = -2.0 * (negative @ jacobian.T)
        basis_positive = 2.0 * (positive @ jacobian.T)
        fold_values: list[torch.Tensor] = []
        for fold in range(folds):
            held = drive_ids.remainder(folds) == fold
            train = ~held
            b1 = basis_negative[:, train]
            b2 = basis_positive[:, train]
            y = target[train]
            g11 = b1.square().sum(dim=1).clamp_min(1e-10)
            g22 = b2.square().sum(dim=1).clamp_min(1e-10)
            g12 = (b1 * b2).sum(dim=1)
            r1 = (b1 * y).sum(dim=1)
            r2 = (b2 * y).sum(dim=1)
            count = len(values)
            coefficient = torch.zeros((count, 4, 2), device=device)
            coefficient[:, 1, 0] = (r1 / g11).clamp_min(0.0)
            coefficient[:, 2, 1] = (r2 / g22).clamp_min(0.0)
            determinant = (g11 * g22 - g12.square()).clamp_min(1e-10)
            both_one = (r1 * g22 - r2 * g12) / determinant
            both_two = (r2 * g11 - r1 * g12) / determinant
            valid_both = (both_one >= 0.0) & (both_two >= 0.0)
            coefficient[:, 3, 0] = torch.where(valid_both, both_one, torch.zeros_like(both_one))
            coefficient[:, 3, 1] = torch.where(valid_both, both_two, torch.zeros_like(both_two))
            prediction = (
                coefficient[:, :, 0, None] * b1[:, None]
                + coefficient[:, :, 1, None] * b2[:, None]
            )
            train_error = (prediction - y[None, None]).square().mean(dim=2)
            train_error[:, 3] = torch.where(
                valid_both, train_error[:, 3], torch.full_like(train_error[:, 3], float("inf"))
            )
            best = train_error.argmin(dim=1)
            selected = coefficient[torch.arange(count, device=device), best]
            held_prediction = (
                selected[:, 0, None] * basis_negative[:, held]
                + selected[:, 1, None] * basis_positive[:, held]
            )
            denominator = target[held].square().mean().clamp_min(1e-12)
            fold_values.append((held_prediction - target[held]).square().mean(dim=1) / denominator)
        outputs.append(torch.stack(fold_values, dim=1).detach().cpu().numpy())
    return np.concatenate(outputs)


def choose_physics(
    fold_residuals: np.ndarray,
    metadata: list[dict[str, object]],
    rule: PhysicsRule,
) -> int:
    residual = fold_residuals.mean(axis=1)
    baseline = max(float(residual[0]), 1e-12)
    ratio = residual / baseline
    change = np.asarray(
        [float(row["removed_fraction"]) + float(row["added_fraction"]) for row in metadata]
    )
    removal = np.asarray([float(row["removed_fraction"]) for row in metadata])
    gain = 1.0 - ratio
    fold_gain = 1.0 - fold_residuals / np.maximum(fold_residuals[0], 1e-12)[None]
    agreement = (fold_gain >= rule.min_gain).mean(axis=1)
    objective = ratio + rule.penalty * change
    valid = (
        (gain >= rule.min_gain)
        & (removal <= rule.max_component_removal)
        & (agreement >= rule.min_fold_agreement)
    )
    valid[0] = True
    objective[~valid] = np.inf
    return int(np.argmin(objective))


def save_montage(
    path: Path,
    truths: np.ndarray,
    ids: np.ndarray,
    baselines: np.ndarray,
    selected: np.ndarray,
    oracle: np.ndarray,
    selected_names: list[str],
) -> None:
    indices = [index for index, case_id in enumerate(ids) if str(case_id) in STRICT_INWARD_IDS]
    figure, axes = plt.subplots(len(indices), 5, figsize=(13.0, 2.65 * len(indices)), squeeze=False)
    for row, index in enumerate(indices):
        panels = (
            (truths[index], "truth", "viridis", 2),
            (baselines[index], f"fusion baseline\nIoU={foreground_iou(truths[index], baselines[index]):.3f}", "viridis", 2),
            (selected[index], f"physics rule\nIoU={foreground_iou(truths[index], selected[index]):.3f}", "viridis", 2),
            (oracle[index], f"instance-bay oracle\nIoU={foreground_iou(truths[index], oracle[index]):.3f}", "viridis", 2),
            ((baselines[index] != oracle[index]), "oracle change mask", "magma", 1),
        )
        for column, (image, title, cmap, vmax) in enumerate(panels):
            axes[row, column].imshow(image, cmap=cmap, vmin=0, vmax=vmax, interpolation="nearest")
            axes[row, column].set_title(title, fontsize=8)
            axes[row, column].set_axis_off()
        axes[row, 0].set_ylabel(f"{ids[index]}\n{selected_names[index]}", fontsize=8)
    figure.suptitle("Instance-wise exterior-connected bay audit on strict inward KTC cases", fontsize=13)
    figure.tight_layout()
    figure.savefig(path, dpi=190)
    plt.close(figure)


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    args = parse_args()
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    archive = np.load(args.dataset.resolve(), allow_pickle=False)
    pool = np.load(args.pool.resolve(), allow_pickle=False)
    names = [str(value) for value in pool["candidate_names"]]
    baseline_index = names.index("fusion_primary")
    baselines = np.asarray(pool["candidates"][baseline_index], dtype=np.uint8)
    truths = np.asarray(archive["real_labels"], dtype=np.uint8)
    ids = np.asarray(archive["real_ids"])
    voltages = np.asarray(archive["real_voltages"], dtype=np.float32)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    jacobian = torch.from_numpy(np.asarray(archive["jacobian"], dtype=np.float32)).to(device)
    node_map = torch.from_numpy(np.asarray(archive["node_to_raw_pixel"], dtype=np.int64)).to(device)
    print(f"device={device}; public cases={len(ids)}; angles={args.angles}", flush=True)

    oracle_predictions: list[np.ndarray] = []
    rule_predictions: dict[str, list[np.ndarray]] = {rule.name: [] for rule in PHYSICS_RULES}
    rows: list[dict[str, object]] = []
    selected_metadata: dict[str, list[dict[str, object]]] = {rule.name: [] for rule in PHYSICS_RULES}
    all_candidate_counts: list[int] = []
    oracle_metadata: list[dict[str, object]] = []
    for case_index, (case_id, baseline, truth, voltage) in enumerate(
        zip(ids, baselines, truths, voltages)
    ):
        candidates, metadata = generate_candidates(
            baseline, args.angles, args.max_components, args.min_component_fraction
        )
        candidates64 = nearest_resize(candidates, 64).astype(np.uint8)
        fold_residuals = fit_voltage_cv_torch(
            candidates64, voltage, jacobian, node_map, args.physics_chunk
        )
        ious = np.asarray([foreground_iou(truth, candidate) for candidate in candidates])
        oracle_index = int(np.argmax(ious))
        oracle_predictions.append(candidates[oracle_index])
        oracle_metadata.append(metadata[oracle_index])
        all_candidate_counts.append(len(candidates))
        record: dict[str, object] = {
            "id": str(case_id),
            "strict_inward": str(case_id) in STRICT_INWARD_IDS,
            "candidate_count": len(candidates),
            "baseline_iou": float(ious[0]),
            "oracle_iou": float(ious[oracle_index]),
            "oracle_gain": float(ious[oracle_index] - ious[0]),
            "oracle_index": oracle_index,
            "oracle_kind": str(metadata[oracle_index]["kind"]),
            "oracle_component_rank": int(metadata[oracle_index]["component_rank"]),
            "oracle_profile": str(metadata[oracle_index].get("profile", "")),
            "oracle_angle": float(metadata[oracle_index].get("angle_degrees", math.nan)),
            "oracle_depth": float(metadata[oracle_index].get("depth_fraction", math.nan)),
            "oracle_removed_fraction": float(metadata[oracle_index]["removed_fraction"]),
            "oracle_added_fraction": float(metadata[oracle_index]["added_fraction"]),
        }
        for rule in PHYSICS_RULES:
            selected_index = choose_physics(fold_residuals, metadata, rule)
            prediction = candidates[selected_index]
            rule_predictions[rule.name].append(prediction)
            selected_metadata[rule.name].append(metadata[selected_index])
            record[f"{rule.name}_index"] = selected_index
            record[f"{rule.name}_iou"] = foreground_iou(truth, prediction)
            record[f"{rule.name}_gain"] = record[f"{rule.name}_iou"] - record["baseline_iou"]
            record[f"{rule.name}_kind"] = str(metadata[selected_index]["kind"])
        rows.append(record)
        print(
            f"{case_index + 1:02d}/{len(ids)} {case_id}: candidates={len(candidates)}, "
            f"IoU {ious[0]:.4f}->{ious[oracle_index]:.4f} oracle={metadata[oracle_index]['kind']}",
            flush=True,
        )

    oracle_array = np.stack(oracle_predictions)
    rule_arrays = {name: np.stack(values) for name, values in rule_predictions.items()}
    baseline_summary, _ = evaluate_real_predictions("fusion_primary", baselines, truths, ids)
    oracle_summary, _ = evaluate_real_predictions("instance_bay_oracle", oracle_array, truths, ids)
    rule_summaries = {
        name: evaluate_real_predictions(name, values, truths, ids)[0]
        for name, values in rule_arrays.items()
    }
    strict = np.asarray([str(case_id) in STRICT_INWARD_IDS for case_id in ids])

    def group_iou(values: np.ndarray, selected: np.ndarray) -> float:
        return float(np.mean([foreground_iou(t, p) for t, p in zip(truths[selected], values[selected])]))

    group_summary = {
        "all": {
            "baseline": group_iou(baselines, np.ones(len(ids), dtype=bool)),
            "oracle": group_iou(oracle_array, np.ones(len(ids), dtype=bool)),
            **{name: group_iou(values, np.ones(len(ids), dtype=bool)) for name, values in rule_arrays.items()},
        },
        "strict_inward": {
            "ids": [str(value) for value in ids[strict]],
            "baseline": group_iou(baselines, strict),
            "oracle": group_iou(oracle_array, strict),
            **{name: group_iou(values, strict) for name, values in rule_arrays.items()},
        },
        "ordinary": {
            "baseline": group_iou(baselines, ~strict),
            "oracle": group_iou(oracle_array, ~strict),
            **{name: group_iou(values, ~strict) for name, values in rule_arrays.items()},
        },
    }
    # The guarded rule is visualized because it is fixed before truth access;
    # oracle remains a clearly-labelled representation upper bound.
    visual_rule = "guarded"
    visual_names = [
        str(row.get("kind", "identity")) for row in selected_metadata[visual_rule]
    ]
    save_montage(
        output_dir / "strict_inward_instance_bay_audit.png",
        truths, ids, baselines, rule_arrays[visual_rule], oracle_array, visual_names,
    )
    write_csv(output_dir / "public_case_metrics.csv", rows)
    np.savez_compressed(
        output_dir / "predictions.npz",
        ids=ids,
        truths=truths,
        baseline=baselines,
        oracle=oracle_array,
        **{f"physics_{name}": values for name, values in rule_arrays.items()},
    )
    references = [
        {
            "title": "Electrical impedance tomography using level set representation and total variational regularization",
            "year": 2005,
            "doi": "10.1016/j.jcp.2004.11.022",
        },
        {
            "title": "Electrical Impedance Tomography: from topology to shape",
            "year": 2008,
            "url": "https://www.uni-graz.at/imawww/ifb/assets/pdfs/IFB_Report15_HiLa08.pdf",
        },
        {
            "title": "Hybrid topological derivative and gradient-based methods for electrical impedance tomography",
            "year": 2012,
            "doi": "10.1088/0266-5611/28/9/095010",
        },
        {
            "title": "A Parametric Level Set Method for Electrical Impedance Tomography",
            "year": 2017,
            "doi": "10.1109/TMI.2017.2756078",
        },
        {
            "title": "B-Spline Level Set Method for Shape Reconstruction in Electrical Impedance Tomography",
            "year": 2019,
            "doi": "10.1109/TMI.2019.2961938",
        },
    ]
    summary = {
        "method": "instance-wise exterior-connected parametric bay plus compensating support expansion",
        "status": "representation audit; oracle is not deployable",
        "public_truth_used_for_candidate_generation": False,
        "public_truth_used_for_oracle_audit": True,
        "device": str(device),
        "candidate_count": {
            "mean": float(np.mean(all_candidate_counts)),
            "min": int(np.min(all_candidate_counts)),
            "max": int(np.max(all_candidate_counts)),
        },
        "physics_rules": [asdict(rule) for rule in PHYSICS_RULES],
        "real_evaluation": {"baseline": baseline_summary, "oracle": oracle_summary, **rule_summaries},
        "group_foreground_iou": group_summary,
        "strict_inward_oracle_improved_cases": int(
            sum(float(row["oracle_gain"]) > 1e-9 for row in rows if bool(row["strict_inward"]))
        ),
        "strict_inward_oracle_newly_solved_ids": [
            str(row["id"])
            for row in rows
            if bool(row["strict_inward"]) and float(row["oracle_gain"]) > 1e-9
        ],
        "references": references,
        "args": {
            **vars(args),
            "dataset": str(args.dataset),
            "pool": str(args.pool),
            "output_dir": str(args.output_dir),
        },
    }
    (output_dir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary["group_foreground_iou"], indent=2), flush=True)


if __name__ == "__main__":
    main()
