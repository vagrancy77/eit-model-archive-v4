from __future__ import annotations

import json
from pathlib import Path

import numpy as np


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def load_json(path: Path) -> dict:
    require(path.exists(), f"missing artifact: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def check_finite(name: str, values: np.ndarray) -> None:
    require(np.all(np.isfinite(values)), f"{name} contains NaN or infinity")


def main() -> None:
    project_root = Path(__file__).resolve().parents[1]
    base_path = project_root / "outputs" / "simulation_data.npz"
    fenicsx_path = project_root / "outputs_fenicsx" / "fenicsx_results.npz"
    nonlinear_path = project_root / "outputs_nonlinear" / "nonlinear_results.npz"
    dataset_path = project_root / "datasets" / "synthetic_cem_v1.npz"
    model_path = project_root / "models" / "residual_mlp_v1.npz"
    neural_path = project_root / "outputs_neural" / "neural_test_predictions.npz"
    for path in (
        base_path,
        fenicsx_path,
        nonlinear_path,
        dataset_path,
        model_path,
        neural_path,
    ):
        require(path.exists(), f"missing artifact: {path}")

    base = np.load(base_path)
    require(base["voltage_clean"].shape == (208,), "base voltage shape is invalid")
    require(base["jacobian"].shape == (208, 560), "base Jacobian shape is invalid")
    check_finite("base Jacobian", base["jacobian"])

    fenicsx_summary = load_json(
        project_root / "outputs_fenicsx" / "summary.json"
    )
    comparison = fenicsx_summary["comparison_with_scipy_cem"]
    require(
        comparison["background_voltage_relative_error"] < 1e-10,
        "FEniCSX voltage does not match the reference backend",
    )
    require(
        comparison["jacobian_relative_error"] < 1e-10,
        "FEniCSX Jacobian does not match the reference backend",
    )

    nonlinear = np.load(nonlinear_path)
    nonlinear_summary = load_json(
        project_root / "outputs_nonlinear" / "summary.json"
    )
    require(
        np.all(nonlinear["conductivity"] > 0.0),
        "nonlinear reconstruction violates positivity",
    )
    require(
        nonlinear_summary["nonlinear_truth_correlation"]
        > nonlinear_summary["linear_truth_correlation"],
        "nonlinear reconstruction did not improve truth correlation",
    )
    objectives = nonlinear["objective"]
    require(
        objectives.size >= 2 and np.all(np.diff(objectives) < 0.0),
        "nonlinear objective is not strictly decreasing",
    )

    dataset = np.load(dataset_path)
    n_samples = dataset["conductivity_inverse"].shape[0]
    require(n_samples >= 128, "dataset is too small for a reproducible split")
    require(
        dataset["voltage_differences"].shape == (n_samples, 208),
        "dataset voltage shape is invalid",
    )
    require(
        dataset["linear_reconstructions"].shape == (n_samples, 560),
        "dataset reconstruction shape is invalid",
    )
    split_total = sum(
        dataset[key].size
        for key in ("train_indices", "validation_indices", "test_indices")
    )
    require(split_total == n_samples, "dataset splits do not cover every sample")
    check_finite("dataset voltages", dataset["voltages_noisy"])
    check_finite("dataset conductivities", dataset["conductivity_inverse"])

    neural_metrics = load_json(project_root / "outputs_neural" / "metrics.json")
    require(
        neural_metrics["neural_mean_correlation"]
        > neural_metrics["linear_mean_correlation"],
        "neural model did not improve mean test correlation",
    )
    require(
        neural_metrics["neural_mean_relative_l2"]
        < neural_metrics["linear_mean_relative_l2"],
        "neural model did not improve mean test relative L2",
    )
    predictions = np.load(neural_path)
    check_finite("neural predictions", predictions["neural_delta"])
    require(
        np.all(predictions["neural_conductivity"] > 0.0),
        "neural predictions violate positivity",
    )

    gn4ip_summary = load_json(project_root / "outputs_gn4ip" / "summary.json")
    require(
        gn4ip_summary["author_output_reproduction"]["relative_l2_error"] < 1e-12,
        "GN4IP pretrained prediction does not match the author output",
    )
    gn4ip_local = load_json(
        project_root / "outputs_gn4ip" / "local_cem" / "summary.json"
    )
    require(
        gn4ip_local["mean_network_correlation"]
        > gn4ip_local["mean_baseline_correlation"],
        "GN4IP Conv U-Net did not improve local CEM correlation",
    )

    multimodal_data = np.load(project_root / "datasets" / "multimodal_cem_v1.npz")
    require(multimodal_data["baseline_grid"].shape == (1024, 64, 64), "invalid multimodal CEM grid")
    require(multimodal_data["voltage_features"].shape == (1024, 208), "invalid multimodal voltage features")
    multimodal_summary = load_json(project_root / "outputs_pytorch_multimodal" / "summary.json")
    require(multimodal_summary["parameters"] > 5_000_000, "multimodal PyTorch network is too small")
    require(multimodal_summary["metrics"]["multimodal"]["correlation"] > multimodal_summary["metrics"]["eit_only"]["correlation"], "multimodal network does not improve EIT-only correlation")
    public_summary = load_json(project_root / "outputs_public_us_eit" / "summary.json")
    require(public_summary["fusion_correlation_to_public_gn"] > public_summary["eit_only_correlation_to_public_gn"], "public US-EIT fusion does not improve pseudo-GN agreement")

    print("Complete project validation passed.")
    print(f"  Base measurements/Jacobian: 208 / {base['jacobian'].shape}")
    print(
        "  FEniCSX relative errors: "
        f"voltage={comparison['background_voltage_relative_error']:.3e}, "
        f"Jacobian={comparison['jacobian_relative_error']:.3e}"
    )
    print(
        "  Nonlinear truth correlation: "
        f"{nonlinear_summary['linear_truth_correlation']:.4f} -> "
        f"{nonlinear_summary['nonlinear_truth_correlation']:.4f}"
    )
    print(
        "  Neural test mean correlation: "
        f"{neural_metrics['linear_mean_correlation']:.4f} -> "
        f"{neural_metrics['neural_mean_correlation']:.4f}"
    )
    print(
        "  GN4IP local CEM mean correlation: "
        f"{gn4ip_local['mean_baseline_correlation']:.4f} -> "
        f"{gn4ip_local['mean_network_correlation']:.4f}"
    )
    print(
        "  PyTorch multimodal synthetic correlation: "
        f"{multimodal_summary['metrics']['eit_only']['correlation']:.4f} -> "
        f"{multimodal_summary['metrics']['multimodal']['correlation']:.4f}"
    )


if __name__ == "__main__":
    main()
