"""Rank the frozen 13-candidate EIT pool by fixed-contrast physics evidence.

Conductivity contrasts are fitted once from the baseline candidate. Every
alternative candidate reuses those contrasts, so a more flexible shape cannot
win merely by refitting its amplitudes. Policy hyperparameters are selected on
synthetic validation data; public KTC labels are evaluation-only.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import scipy.ndimage as ndi
import torch
import torch.nn.functional as F

from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_cross_representation_pixel_fusion import (
    STRICT_INWARD_IDS,
    SplitArrays,
    foreground_iou_per_case,
    load_pool,
    metric_for,
    paired_bootstrap,
    prepare_split,
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    parser.add_argument(
        "--pool-dir", type=Path,
        default=root / "outputs" / "ktc_cross_representation_pool_seed20260820",
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=root / "outputs" / "ktc_cross_pool_physics_ranking_seed20260820",
    )
    parser.add_argument("--bootstrap-repetitions", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260820)
    return parser.parse_args()


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        return
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def resize_candidates(candidates: np.ndarray, size: int = 64) -> np.ndarray:
    if candidates.shape[-2:] == (size, size):
        return candidates.astype(np.uint8, copy=False)
    count, samples, height, width = candidates.shape
    tensor = torch.from_numpy(candidates.reshape(count * samples, 1, height, width).astype(np.float32))
    resized = F.interpolate(tensor, size=(size, size), mode="nearest")
    return resized[:, 0].numpy().reshape(count, samples, size, size).astype(np.uint8)


def all_class_bases(
    candidates: np.ndarray,
    jacobian: np.ndarray,
    node_to_raw_pixel: np.ndarray,
    batch_size: int = 2048,
) -> np.ndarray:
    """Project every candidate mask through J in one batched CUDA/CPU pass."""
    count, samples = candidates.shape[:2]
    labels = np.flip(candidates, axis=2).reshape(count * samples, -1).copy()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    j_transpose = torch.from_numpy(np.asarray(jacobian, dtype=np.float32).T.copy()).to(device)
    node_map = torch.from_numpy(np.asarray(node_to_raw_pixel, dtype=np.int64)).to(device)
    chunks: list[torch.Tensor] = []
    for start in range(0, len(labels), batch_size):
        batch = torch.from_numpy(labels[start:start + batch_size]).to(device)
        negative_nodes = (batch == 1).float()[:, node_map]
        positive_nodes = (batch == 2).float()[:, node_map]
        chunks.append(torch.stack((-2.0 * (negative_nodes @ j_transpose), 2.0 * (positive_nodes @ j_transpose)), dim=1).cpu())
    return torch.cat(chunks).numpy().astype(np.float64).reshape(count, samples, 2, -1)


CONTRAST_UPPER_BOUNDS = np.asarray([1.05, 1.65], dtype=np.float64)


def fit_baseline_contrasts(bases: np.ndarray, voltages: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    target = np.asarray(voltages, dtype=np.float64)
    result = np.zeros((len(target), 2), dtype=np.float64)
    for index, (matrix, y) in enumerate(zip(bases.transpose(0, 2, 1), target)):
        coefficient_candidates = [np.zeros(2, dtype=np.float64)]
        for column_index in range(2):
            column = matrix[:, column_index]
            coefficient = np.clip(
                float(np.dot(column, y) / max(np.dot(column, column), 1e-12)),
                0.0, CONTRAST_UPPER_BOUNDS[column_index],
            )
            candidate = np.zeros(2, dtype=np.float64)
            candidate[column_index] = coefficient
            coefficient_candidates.append(candidate)
        gram = matrix.T @ matrix + 1e-8 * np.eye(2)
        both = np.linalg.solve(gram, matrix.T @ y)
        coefficient_candidates.append(np.clip(both, 0.0, CONTRAST_UPPER_BOUNDS))
        # Include both upper-bound faces; with two variables this captures the
        # bounded least-squares optimum when simple clipping is insufficient.
        for fixed_index in range(2):
            free_index = 1 - fixed_index
            candidate = np.zeros(2, dtype=np.float64)
            candidate[fixed_index] = CONTRAST_UPPER_BOUNDS[fixed_index]
            residual = y - matrix[:, fixed_index] * candidate[fixed_index]
            column = matrix[:, free_index]
            candidate[free_index] = np.clip(
                float(np.dot(column, residual) / max(np.dot(column, column), 1e-12)),
                0.0, CONTRAST_UPPER_BOUNDS[free_index],
            )
            coefficient_candidates.append(candidate)
        errors = [float(np.mean(np.square(matrix @ value - y))) for value in coefficient_candidates]
        result[index] = coefficient_candidates[int(np.argmin(errors))]
    saturated = np.any(result >= CONTRAST_UPPER_BOUNDS[None] - 1e-6, axis=1)
    return result, saturated


def residual_scores(
    candidates: np.ndarray,
    voltages: np.ndarray,
    jacobian: np.ndarray,
    node_to_raw_pixel: np.ndarray,
) -> tuple[dict[str, np.ndarray], np.ndarray, np.ndarray]:
    candidates64 = resize_candidates(candidates)
    target = np.asarray(voltages, dtype=np.float64)
    bases_all = all_class_bases(candidates64, jacobian, node_to_raw_pixel)
    baseline_bases = bases_all[0]
    contrasts, saturated = fit_baseline_contrasts(baseline_bases, target)
    global_scores = np.empty(candidates64.shape[:2], dtype=np.float64)
    drive_scores = np.empty_like(global_scores)
    cosine_scores = np.empty_like(global_scores)
    if target.shape[1] % 31 != 0:
        raise ValueError("expected 31 measurements per KTC drive pattern")
    drive_count = target.shape[1] // 31
    target_drive = target.reshape(len(target), drive_count, 31)
    target_drive_energy = np.mean(np.square(target_drive), axis=2).clip(min=1e-12)
    target_energy = np.mean(np.square(target), axis=1).clip(min=1e-12)
    target_norm = np.linalg.norm(target, axis=1).clip(min=1e-12)
    for candidate_index, bases in enumerate(bases_all):
        prediction = (bases * contrasts[:, :, None]).sum(axis=1)
        error = prediction - target
        global_scores[candidate_index] = np.mean(np.square(error), axis=1) / target_energy
        drive_error = np.mean(np.square(error.reshape(len(target), drive_count, 31)), axis=2)
        drive_scores[candidate_index] = np.median(drive_error / target_drive_energy, axis=1)
        numerator = np.sum(prediction * target, axis=1)
        denominator = np.linalg.norm(prediction, axis=1).clip(min=1e-12) * target_norm
        cosine_scores[candidate_index] = 1.0 - numerator / denominator
    eps = 1e-12
    hybrid = (
        global_scores / np.maximum(global_scores[0:1], eps)
        + drive_scores / np.maximum(drive_scores[0:1], eps)
        + cosine_scores / np.maximum(cosine_scores[0:1], eps)
    ) / 3.0
    scores = {
        "global_nmse": global_scores,
        "drive_median_nmse": drive_scores,
        "cosine": cosine_scores,
        "hybrid_ratio": hybrid,
    }
    # A baseline fit at a physical bound signals that the linearized model is
    # being asked to explain domain mismatch. Refuse all automatic edits for
    # that case instead of turning model error into a shape change.
    for values in scores.values():
        values[1:, saturated] = np.inf
    return scores, contrasts, saturated


def geometry_risks(candidates: np.ndarray, fov: np.ndarray) -> dict[str, np.ndarray]:
    foreground = candidates != 0
    count, samples = foreground.shape[:2]
    changes = np.zeros((count, samples), dtype=np.float64)
    new_holes = np.zeros((count, samples), dtype=np.float64)
    component_removal = np.zeros((count, samples), dtype=np.float64)
    structure = ndi.generate_binary_structure(2, 2)
    fov_pixels = max(1, int(np.count_nonzero(fov)))
    for sample in range(samples):
        baseline = foreground[0, sample]
        baseline_holes = ndi.binary_fill_holes(baseline) & ~baseline
        components, component_count = ndi.label(baseline, structure=structure)
        for candidate_index in range(1, count):
            candidate = foreground[candidate_index, sample]
            changes[candidate_index, sample] = np.count_nonzero((candidate != baseline) & fov) / fov_pixels
            holes = ndi.binary_fill_holes(candidate) & ~candidate
            new_holes[candidate_index, sample] = np.count_nonzero(holes & ~baseline_holes)
            removed = baseline & ~candidate
            worst = 0.0
            for component_index in range(1, component_count + 1):
                component = components == component_index
                worst = max(worst, np.count_nonzero(removed & component) / max(1, np.count_nonzero(component)))
            component_removal[candidate_index, sample] = worst
    return {"change_fraction": changes, "new_hole_pixels": new_holes, "component_removal": component_removal}


def choose_candidates(
    candidates: np.ndarray,
    scores: np.ndarray,
    risks: dict[str, np.ndarray],
    gain_threshold: float,
    max_change: float,
    max_component_removal: float,
    forbid_new_holes: bool,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    baseline_score = np.maximum(scores[0], 1e-12)
    ratios = scores / baseline_score[None]
    eligible = risks["change_fraction"] <= max_change
    eligible &= risks["component_removal"] <= max_component_removal
    if forbid_new_holes:
        eligible &= risks["new_hole_pixels"] == 0
    eligible[0] = True
    masked = np.where(eligible, ratios, np.inf)
    choice = masked.argmin(axis=0)
    best_ratio = masked[choice, np.arange(masked.shape[1])]
    choice[best_ratio > 1.0 - gain_threshold] = 0
    prediction = candidates[choice, np.arange(len(choice))]
    return prediction, choice, 1.0 - best_ratio


def calibrate_policy(
    base: SplitArrays,
    stress: SplitArrays,
    base_scores: dict[str, np.ndarray],
    stress_scores: dict[str, np.ndarray],
    base_risks: dict[str, np.ndarray],
    stress_risks: dict[str, np.ndarray],
) -> tuple[dict[str, object], list[dict[str, object]]]:
    base_reference = metric_for(base, base.candidates[0])
    stress_reference = metric_for(stress, stress.candidates[0])
    rows: list[dict[str, object]] = []
    for score_name in base_scores:
        print(f"calibrating score={score_name}", flush=True)
        for threshold in (0.0, 0.0025, 0.01, 0.025, 0.05, 1.0):
            for max_change in (0.025, 0.075, 1.0):
                for max_removal in (0.30, 1.0):
                    # An inward bay must remain connected to exterior
                    # background; sealed new holes are never admissible.
                    for forbid_holes in (True,):
                        base_prediction, base_choice, _ = choose_candidates(
                            base.candidates, base_scores[score_name], base_risks, threshold,
                            max_change, max_removal, forbid_holes,
                        )
                        stress_prediction, stress_choice, _ = choose_candidates(
                            stress.candidates, stress_scores[score_name], stress_risks, threshold,
                            max_change, max_removal, forbid_holes,
                        )
                        base_metric = metric_for(base, base_prediction)
                        stress_metric = metric_for(stress, stress_prediction)
                        eligible = (
                            base_metric["foreground_iou"] >= base_reference["foreground_iou"] - 0.002
                            and base_metric["boundary_f1"] >= base_reference["boundary_f1"] - 0.004
                            and stress_metric["foreground_iou"] >= stress_reference["foreground_iou"] - 0.004
                            and stress_metric["bank_retention"] >= stress_reference["bank_retention"] - 0.012
                        )
                        objective = (
                            3.0 * (stress_metric["open_deep_cutout_recovery"] - stress_reference["open_deep_cutout_recovery"])
                            + 2.0 * (stress_metric["topology_structural_joint"] - stress_reference["topology_structural_joint"])
                            + (stress_metric["foreground_iou"] - stress_reference["foreground_iou"])
                            + 0.5 * (base_metric["foreground_iou"] - base_reference["foreground_iou"])
                        )
                        rows.append({
                            "score": score_name, "gain_threshold": threshold,
                            "max_change_fraction": max_change,
                            "max_component_removal": max_removal,
                            "forbid_new_holes": forbid_holes, "eligible": bool(eligible),
                            "objective": float(objective),
                            "base_iou": base_metric["foreground_iou"],
                            "base_boundary_f1": base_metric["boundary_f1"],
                            "stress_iou": stress_metric["foreground_iou"],
                            "stress_open_deep": stress_metric["open_deep_cutout_recovery"],
                            "stress_bank": stress_metric["bank_retention"],
                            "stress_topology_joint": stress_metric["topology_structural_joint"],
                            "base_changed": int(np.count_nonzero(base_choice)),
                            "stress_changed": int(np.count_nonzero(stress_choice)),
                        })
    eligible_rows = [row for row in rows if row["eligible"]]
    selected = max(
        eligible_rows,
        key=lambda row: (
            float(row["objective"]), float(row["stress_iou"]), float(row["base_iou"]),
            -int(row["stress_changed"]),
        ),
    )
    return selected, rows


def apply_policy(
    candidates: np.ndarray,
    scores: dict[str, np.ndarray],
    risks: dict[str, np.ndarray],
    policy: dict[str, object],
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    return choose_candidates(
        candidates, scores[str(policy["score"])], risks,
        float(policy["gain_threshold"]), float(policy["max_change_fraction"]),
        float(policy["max_component_removal"]), bool(policy["forbid_new_holes"]),
    )


def save_montage(
    path: Path,
    truths: np.ndarray,
    baseline: np.ndarray,
    prediction: np.ndarray,
    oracle: np.ndarray,
    choices: np.ndarray,
    ids: np.ndarray,
    selected: np.ndarray,
) -> None:
    figure, axes = plt.subplots(len(selected), 5, figsize=(12.0, 2.3 * len(selected)), squeeze=False)
    before = foreground_iou_per_case(truths, baseline)
    after = foreground_iou_per_case(truths, prediction)
    best = foreground_iou_per_case(truths, oracle)
    for row, index in enumerate(selected):
        removed = (baseline[index] != 0) & (prediction[index] == 0)
        panels = (
            (truths[index], f"{ids[index]} truth", "viridis", 2),
            (baseline[index], f"baseline IoU {before[index]:.3f}", "viridis", 2),
            (prediction[index], f"physics choice {choices[index]}\nIoU {after[index]:.3f}", "viridis", 2),
            (oracle[index], f"pool oracle\nIoU {best[index]:.3f}", "viridis", 2),
            (removed, "removed foreground", "magma", 1),
        )
        for column, (image, title, cmap, high) in enumerate(panels):
            axes[row, column].imshow(image, cmap=cmap, vmin=0, vmax=high, interpolation="nearest")
            axes[row, column].set_title(title, fontsize=8)
            axes[row, column].set_axis_off()
    figure.suptitle("KTC2023 strict inward cases: fixed-contrast physics candidate ranking", y=0.995)
    figure.subplots_adjust(top=0.97, hspace=0.28, wspace=0.08)
    figure.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(figure)


def casewise_oracle(truths: np.ndarray, candidates: np.ndarray) -> np.ndarray:
    scores = np.stack([foreground_iou_per_case(truths, candidate) for candidate in candidates])
    choice = scores.argmax(axis=0)
    return candidates[choice, np.arange(len(choice))]


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    base_archive = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress_archive = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    pool_dir = args.pool_dir.resolve()
    names, base_validation = prepare_split("base_validation", "base", base_archive, pool_dir)
    _, base_test = prepare_split("base_test", "base", base_archive, pool_dir)
    _, stress_validation = prepare_split("stress_validation", "stress", stress_archive, pool_dir)
    _, stress_test = prepare_split("stress_test", "stress", stress_archive, pool_dir)
    public_names, public_indices, public_candidates = load_pool(pool_dir / "public_21.npz")
    if names != public_names:
        raise ValueError("candidate ordering mismatch")
    ids = np.asarray(base_archive["real_ids"])
    if not np.array_equal(public_indices, np.arange(len(ids))):
        raise ValueError("public pool ordering does not match real_ids")

    def evidence(split: SplitArrays, archive: np.lib.npyio.NpzFile) -> tuple[dict[str, np.ndarray], dict[str, np.ndarray]]:
        scores, _, _ = residual_scores(
            split.candidates, split.voltages, archive["jacobian"], archive["node_to_raw_pixel"]
        )
        return scores, geometry_risks(resize_candidates(split.candidates), np.asarray(archive["fov_mask"], bool))

    print("computing validation physics evidence", flush=True)
    base_validation_scores, base_validation_risks = evidence(base_validation, base_archive)
    stress_validation_scores, stress_validation_risks = evidence(stress_validation, stress_archive)
    policy, calibration = calibrate_policy(
        base_validation, stress_validation, base_validation_scores, stress_validation_scores,
        base_validation_risks, stress_validation_risks,
    )
    write_csv(output_dir / "validation_policy_grid.csv", calibration)
    print(f"selected policy: {policy}", flush=True)

    split_results: dict[str, object] = {}
    for offset, (split, archive) in enumerate(((base_test, base_archive), (stress_test, stress_archive))):
        scores, risks = evidence(split, archive)
        prediction, choice, gain = apply_policy(split.candidates, scores, risks, policy)
        differences = foreground_iou_per_case(split.truths, prediction) - foreground_iou_per_case(
            split.truths, split.candidates[0]
        )
        split_results[split.name] = {
            "baseline": metric_for(split, split.candidates[0]),
            "physics_ranking": metric_for(split, prediction),
            "oracle": metric_for(split, casewise_oracle(split.truths, split.candidates)),
            "bootstrap_iou": paired_bootstrap(
                split.truths, split.candidates[0], prediction,
                args.bootstrap_repetitions, args.seed + offset,
            ),
            "changed_cases": int(np.count_nonzero(choice)),
            "improved_cases": int(np.count_nonzero(differences > 1e-6)),
            "harmed_cases": int(np.count_nonzero(differences < -1e-6)),
            "mean_selected_physics_gain": float(gain[choice != 0].mean()) if np.any(choice) else 0.0,
        }

    print("computing public physics evidence without labels", flush=True)
    public_scores, public_contrasts, public_saturated = residual_scores(
        public_candidates, np.asarray(base_archive["real_voltages"]),
        base_archive["jacobian"], base_archive["node_to_raw_pixel"],
    )
    public_risks = geometry_risks(
        resize_candidates(public_candidates), np.asarray(base_archive["fov_mask"], bool)
    )
    public_prediction, public_choice, public_gain = apply_policy(
        public_candidates, public_scores, public_risks, policy
    )
    # Public labels are first accessed here, after policy and predictions are fixed.
    public_truths = np.asarray(base_archive["real_labels"], dtype=np.uint8)
    public_oracle = casewise_oracle(public_truths, public_candidates)
    strict = np.asarray([str(case_id) in STRICT_INWARD_IDS for case_id in ids])
    ordinary = ~strict

    def public_metrics(selected: np.ndarray, seed: int) -> dict[str, object]:
        baseline_summary, _ = evaluate_real_predictions(
            "baseline", public_candidates[0, selected], public_truths[selected], ids[selected]
        )
        proposed_summary, _ = evaluate_real_predictions(
            "physics_ranking", public_prediction[selected], public_truths[selected], ids[selected]
        )
        oracle_summary, _ = evaluate_real_predictions(
            "oracle", public_oracle[selected], public_truths[selected], ids[selected]
        )
        return {
            "baseline": baseline_summary, "physics_ranking": proposed_summary, "oracle": oracle_summary,
            "bootstrap_iou": paired_bootstrap(
                public_truths[selected], public_candidates[0, selected], public_prediction[selected],
                args.bootstrap_repetitions, seed,
            ),
        }

    differences = foreground_iou_per_case(public_truths, public_prediction) - foreground_iou_per_case(
        public_truths, public_candidates[0]
    )
    rows: list[dict[str, object]] = []
    for index, case_id in enumerate(ids):
        rows.append({
            "id": str(case_id), "strict_inward": bool(strict[index]),
            "choice": int(public_choice[index]),
            "candidate": names[int(public_choice[index])],
            "physics_gain": float(public_gain[index]),
            "low_contrast": float(public_contrasts[index, 0]),
            "high_contrast": float(public_contrasts[index, 1]),
            "contrast_saturated": bool(public_saturated[index]),
            "baseline_iou": float(foreground_iou_per_case(public_truths[index:index + 1], public_candidates[0, index:index + 1])[0]),
            "physics_iou": float(foreground_iou_per_case(public_truths[index:index + 1], public_prediction[index:index + 1])[0]),
            "delta_iou": float(differences[index]),
        })
    write_csv(output_dir / "public_case_metrics.csv", rows)
    np.savez_compressed(
        output_dir / "results.npz", public_prediction=public_prediction,
        public_choice=public_choice, public_gain=public_gain,
        public_contrasts=public_contrasts, public_ids=ids,
    )
    save_montage(
        output_dir / "public_strict_inward_physics_ranking.png", public_truths,
        public_candidates[0], public_prediction, public_oracle, public_choice, ids,
        np.flatnonzero(strict),
    )
    summary = {
        "method": "fixed-baseline-contrast linear EIT candidate ranking",
        "candidate_names": names,
        "selected_policy": policy,
        "synthetic_test": split_results,
        "public_21": public_metrics(np.ones(len(ids), dtype=bool), args.seed + 10),
        "public_strict_inward": public_metrics(strict, args.seed + 11),
        "public_ordinary": public_metrics(ordinary, args.seed + 12),
        "public_changes": {
            "changed": int(np.count_nonzero(public_choice)),
            "improved": int(np.count_nonzero(differences > 1e-6)),
            "harmed": int(np.count_nonzero(differences < -1e-6)),
            "material_improvements": int(np.count_nonzero(differences >= 0.01)),
            "material_harms": int(np.count_nonzero(differences <= -0.01)),
        },
        "data_policy": "synthetic validation selects policy; public labels are final-audit only",
        "public_truth_used_for_candidate_generation_or_selection": False,
        "seed": args.seed,
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
