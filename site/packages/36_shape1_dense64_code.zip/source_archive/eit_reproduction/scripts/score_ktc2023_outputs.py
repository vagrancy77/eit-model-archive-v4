from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import scipy.io as sio
import scipy.signal as sps
from PIL import Image


def png_to_labels(path: Path) -> np.ndarray:
    image = np.asarray(Image.open(path), dtype=np.float64)
    return np.rint(image * 2.0 / 255.0).astype(np.int64)


def _ssim_fft(truth: np.ndarray, reco: np.ndarray) -> float:
    """FFT implementation of the repository's SSIM formula.

    The public implementation uses a 321x321 Gaussian kernel with direct
    convolution, which is mathematically fine but prohibitively slow. FFT
    convolution preserves the same kernel, boundary correction, constants,
    and therefore the paper's score up to floating-point roundoff.
    """
    c1 = 1e-4
    c2 = 9e-4
    r = 80
    ws = int(np.ceil(2 * r))
    wr = np.arange(-ws, ws + 1)
    x, y = np.meshgrid(wr, wr)
    ker = (1 / np.sqrt(2 * np.pi)) * np.exp(-0.5 * ((x * x + y * y) / (r * r)))
    correction = sps.fftconvolve(np.ones(truth.shape), ker, mode="same")

    def conv(image: np.ndarray) -> np.ndarray:
        return sps.fftconvolve(image, ker, mode="same") / correction

    gt = conv(truth)
    gr = conv(reco)
    mu_t2 = gt * gt
    mu_r2 = gr * gr
    mu_t_mu_r = gt * gr
    sigma_t2 = conv(truth * truth) - mu_t2
    sigma_r2 = conv(reco * reco) - mu_r2
    sigma_tr = conv(truth * reco) - mu_t_mu_r
    num = (2 * mu_t_mu_r + c1) * (2 * sigma_tr + c2)
    den = (mu_t2 + mu_r2 + c1) * (sigma_t2 + sigma_r2 + c2)
    return float(np.mean(num / den))


def ktc_score_fft(groundtruth: np.ndarray, reconstruction: np.ndarray) -> float:
    truth_c = (np.abs(groundtruth - 2) < 0.1).astype(np.float64)
    reco_c = (np.abs(reconstruction - 2) < 0.1).astype(np.float64)
    truth_d = (np.abs(groundtruth - 1) < 0.1).astype(np.float64)
    reco_d = (np.abs(reconstruction - 1) < 0.1).astype(np.float64)
    return 0.5 * (_ssim_fft(truth_c, reco_c) + _ssim_fft(truth_d, reco_d))


def main() -> None:
    parser = argparse.ArgumentParser(description="Compute the original KTC scoringFunction.")
    parser.add_argument("--repo-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--original",
        action="store_true",
        help="Use the repository's direct-convolution scorer (very slow).",
    )
    args = parser.parse_args()
    import sys

    repo_root = args.repo_root.resolve()
    sys.path.insert(0, str(repo_root))
    from utils import KTCScoring

    for path in sorted(args.output_dir.glob("data*.png")):
        stem = path.stem
        truth = sio.loadmat(repo_root / "groundTruths" / f"true{stem[4:]}.mat")["truth"]
        reconstruction = png_to_labels(path)
        score = (
            KTCScoring.scoringFunction(truth, reconstruction)
            if args.original
            else ktc_score_fft(truth, reconstruction)
        )
        print(f"{stem}: {score:.8f}")


if __name__ == "__main__":
    main()
