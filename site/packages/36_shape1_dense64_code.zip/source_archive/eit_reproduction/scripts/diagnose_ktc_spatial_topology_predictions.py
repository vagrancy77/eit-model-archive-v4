"""Diagnose outer-level rankings of the spatial topology bay model."""
from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np
import torch
import matplotlib.pyplot as plt

import train_ktc_spatial_topology_bay_oof as core


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--pool", type=Path, default=root / "outputs" / "ktc_cross_representation_pool_seed20260820" / "public_21.npz")
    parser.add_argument("--cache-dir", type=Path, default=Path(r"E:\Codex\ktc_expanded_pure_bay_candidate_cache_seed20260820"))
    parser.add_argument("--target-dir", type=Path, default=Path(r"E:\Codex\ktc_expanded_pure_bay_training_targets_seed20260820"))
    parser.add_argument("--pretrained", type=Path, default=Path(r"E:\Codex\ktc_synthetic_pure_bay_physics_ranker_seed20260820\synthetic_bay_risk_ranker.pt"))
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--front-size", type=int, default=1536)
    parser.add_argument("--patch-size", type=int, default=20)
    return parser.parse_args()


def descending_rank(values: np.ndarray, valid: np.ndarray, index: int) -> int:
    order = np.argsort(np.where(valid, values, -np.inf))[::-1]
    positions = np.flatnonzero(order == index)
    return int(positions[0] + 1) if len(positions) else -1


def main() -> None:
    args = parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    pretrained = torch.load(args.pretrained.resolve(), map_location="cpu", weights_only=False)
    cases, truths, _ = core.load_public_cases(args)
    archive = np.load(args.dataset.resolve(), allow_pickle=False)
    linear_images = np.asarray(archive["real_linear_images"], dtype=np.float32)
    fronts = {case.case_id: core.candidate_front(case, args.front_size) for case in cases}
    patches = core.build_spatial_inputs(args, cases, fronts, device)
    rows = []
    visual = {}
    for level in sorted({case.level for case in cases}):
        payload = torch.load(
            args.model_dir.resolve() / f"exclude_{level}.pt",
            map_location=device, weights_only=False,
        )
        models = []
        channels = next(iter(patches.values())).shape[1]
        for member, state in enumerate(payload["models"]):
            model = core.SpatialTopologyRanker(
                pretrained["models"][member % len(pretrained["models"])], channels
            ).to(device)
            model.load_state_dict(state)
            model.eval()
            models.append(model)
        for case in cases:
            if case.level != level:
                continue
            front = fronts[case.case_id]
            evidence = core.predict_case(
                case, front, patches[case.case_id], models, pretrained,
                payload["target_mean"], payload["target_scale"], device,
            )
            valid = case.valid.copy() & np.isfinite(evidence.score)
            valid[0] = False
            combined = evidence.score + 0.80 * evidence.regression[:, 0]
            combined += 0.25 * evidence.regression[:, 1] + 0.70 * evidence.regression[:, 2]
            combined += 0.10 * evidence.regression[:, 4]
            predicted = int(np.argmax(np.where(valid, combined, -np.inf)))
            material = valid & core.material_mask(case.targets)
            utility = core.target_utility(case.targets, case.removed)
            oracle = int(np.argmax(np.where(material, utility, -np.inf))) if material.any() else 0
            best_iou = int(np.argmax(np.where(valid, case.targets[:, 0], -np.inf)))
            row = {
                "id": case.case_id,
                "strict_inward": case.case_id in core.STRICT_INWARD_IDS,
                "front_count": int(valid.sum()),
                "material_count": int(material.sum()),
                "case_probability": evidence.case_probability,
                "predicted_index": predicted,
                "predicted_score": float(evidence.score[predicted]),
                "predicted_iou_delta": float(case.targets[predicted, 0]),
                "predicted_boundary_delta": float(case.targets[predicted, 1]),
                "predicted_bay_f1_delta": float(case.targets[predicted, 2]),
                "predicted_joint_probability": float(evidence.probability[predicted, 5]),
                "oracle_index": oracle,
                "oracle_score": float(evidence.score[oracle]),
                "oracle_score_rank": descending_rank(evidence.score, valid, oracle) if oracle else -1,
                "oracle_regression_iou_rank": descending_rank(evidence.regression[:, 0], valid, oracle) if oracle else -1,
                "oracle_probability_iou_rank": descending_rank(evidence.probability[:, 0], valid, oracle) if oracle else -1,
                "oracle_combined_rank": descending_rank(combined, valid, oracle) if oracle else -1,
                "oracle_iou_delta": float(case.targets[oracle, 0]),
                "oracle_boundary_delta": float(case.targets[oracle, 1]),
                "oracle_bay_f1_delta": float(case.targets[oracle, 2]),
                "oracle_bay_depth_delta": float(case.targets[oracle, 4]),
                "oracle_safe_probability": float(evidence.probability[oracle, 0]),
                "oracle_bay_probability": float(evidence.probability[oracle, 3]),
                "oracle_joint_probability": float(evidence.probability[oracle, 5]),
                "best_iou_delta": float(case.targets[best_iou, 0]),
                "best_iou_rank": descending_rank(combined, valid, best_iou),
            }
            evidence_columns = {
                "cv_mean": 76, "cv_min": 78, "cv_positive_folds": 80,
                "fixed_global": 81, "fixed_drive": 82, "fixed_cosine": 83,
                "fixed_hybrid": 84, "pool_agreement_mean": 114,
                "pool_agreement_max": 115, "background_vote": 117,
                "foreground_vote": 118, "removed_fraction": 130,
            }
            for name, column in evidence_columns.items():
                row[f"oracle_rank_{name}"] = (
                    descending_rank(case.features[:, column], valid, oracle) if oracle else -1
                )
            rows.append(row)
            visual[case.case_id] = (predicted, oracle)
            print(
                f"{case.case_id}: pred dIoU={row['predicted_iou_delta']:+.4f} "
                f"dBay={row['predicted_bay_f1_delta']:+.4f}; oracle rank="
                f"{row['oracle_score_rank']}/{row['oracle_combined_rank']} "
                f"dIoU={row['oracle_iou_delta']:+.4f} dBay={row['oracle_bay_f1_delta']:+.4f} "
                f"P={row['oracle_safe_probability']:.3f}/{row['oracle_joint_probability']:.3f}",
                flush=True,
            )
    args.output.resolve().parent.mkdir(parents=True, exist_ok=True)
    with args.output.resolve().open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    selected_ids = ["level_2/1", "level_3/3", "level_5/2", "level_6/2", "level_7/2", "level_7/3"]
    figure, axes = plt.subplots(len(selected_ids), 7, figsize=(15, 2.35 * len(selected_ids)))
    for row_index, case_id in enumerate(selected_ids):
        case_index = next(index for index, case in enumerate(cases) if case.case_id == case_id)
        case = cases[case_index]
        predicted, oracle = visual[case_id]
        panels = (
            (truths[case_index], "truth"), (linear_images[case_index], "linear EIT"),
            (case.candidates[0], "baseline"), (case.candidates[predicted], "model top"),
            (case.candidates[oracle], "safe oracle"),
            ((case.candidates[0] != 0) & (case.candidates[predicted] == 0), "model removal"),
            ((case.candidates[0] != 0) & (case.candidates[oracle] == 0), "oracle removal"),
        )
        for column, (image, title) in enumerate(panels):
            axes[row_index, column].imshow(image, cmap="viridis", interpolation="nearest")
            axes[row_index, column].axis("off")
            axes[row_index, column].set_title(f"{case_id} {title}", fontsize=8)
    figure.tight_layout()
    figure.savefig(args.output.resolve().with_suffix(".png"), dpi=180)
    plt.close(figure)


if __name__ == "__main__":
    main()
