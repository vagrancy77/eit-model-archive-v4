"""Train a from-scratch direct-plus-topology-residual EIT network.

Public KTC labels are excluded from optimization and checkpoint selection.
The final checkpoint is selected on three disjoint synthetic validation sets.
"""
from __future__ import annotations

import argparse
import json
import math
import random
import sys
import time
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import binary_dilation, binary_erosion
from torch.utils.data import ConcatDataset, DataLoader, Dataset

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import train_boolean_shape_eit_v2 as data_tools
from pytorch_eit.topology_residual_net import PhysicsOperator, TopologyResidualEITNet


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=ROOT / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--biological-dataset", type=Path, default=ROOT / "datasets" / "ktc_biological_concavity_v1.npz")
    parser.add_argument("--stress-dataset", type=Path, default=ROOT / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "outputs" / "topology_residual_eit_v3")
    parser.add_argument("--epochs", type=int, default=80)
    parser.add_argument("--patience", type=int, default=16)
    parser.add_argument("--batch-size", type=int, default=18)
    parser.add_argument("--base-channels", type=int, default=28)
    parser.add_argument("--learning-rate", type=float, default=1.6e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--stress-repeat", type=int, default=2)
    parser.add_argument("--ordinary-repeat", type=int, default=1)
    parser.add_argument("--architecture", choices=("v3", "v4"), default="v3")
    parser.add_argument("--seed", type=int, default=20260911)
    parser.add_argument("--device", choices=("auto", "cuda", "cpu"), default="auto")
    parser.add_argument("--physics-weight", type=float, default=1.5e-4)
    parser.add_argument("--topology-start", type=int, default=4)
    parser.add_argument("--topology-ramp", type=int, default=10)
    parser.add_argument(
        "--area-budget-weight", type=float, default=0.0,
        help="penalize excessive or insufficient foreground removal relative to the target cutout",
    )
    parser.add_argument(
        "--boundary-protection-weight", type=float, default=0.0,
        help="protect true foreground outside a dilated target cutout from topology edits",
    )
    parser.add_argument("--protection-kernel", type=int, default=7)
    parser.add_argument(
        "--domain-randomization", action="store_true",
        help="randomize voltage noise, gain and dropout during training",
    )
    parser.add_argument("--domain-snr-min", type=float, default=20.0)
    parser.add_argument("--domain-snr-max", type=float, default=60.0)
    parser.add_argument("--domain-gain", type=float, default=0.10)
    parser.add_argument("--domain-dropout", type=float, default=0.05)
    parser.add_argument("--max-train-batches", type=int, default=0)
    parser.add_argument("--progress-every", type=int, default=4)
    parser.add_argument("--diagnose-gradients", action="store_true")
    parser.add_argument("--resume-checkpoint", type=Path, default=None)
    parser.add_argument("--disable-amp", action="store_true")
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = True


def to_device(batch: dict[str, torch.Tensor], device: torch.device) -> dict[str, torch.Tensor]:
    return {key: value.to(device, non_blocking=True) for key, value in batch.items()}


def randomize_measurements(
    batch: dict[str, torch.Tensor], args: argparse.Namespace,
) -> None:
    """Apply measurement-domain perturbations while keeping the conductivity target fixed."""
    if not args.domain_randomization:
        return
    voltage = batch["voltage"]
    batch_size = voltage.shape[0]
    gain = 1.0 + torch.empty(
        (batch_size, 1), device=voltage.device, dtype=voltage.dtype
    ).uniform_(-args.domain_gain, args.domain_gain)
    voltage = voltage * gain
    snr = torch.empty(
        (batch_size, 1), device=voltage.device, dtype=voltage.dtype
    ).uniform_(args.domain_snr_min, args.domain_snr_max)
    rms = torch.sqrt(voltage.square().flatten(1).mean(dim=1, keepdim=True) + 1e-10)
    noise_scale = torch.pow(voltage.new_tensor(10.0), -snr / 20.0)
    voltage = voltage + torch.randn_like(voltage) * rms.reshape(batch_size, *([1] * (voltage.ndim - 1))) * noise_scale.reshape(
        batch_size, *([1] * (voltage.ndim - 1))
    )
    if args.domain_dropout > 0.0:
        keep = torch.rand_like(voltage) >= args.domain_dropout
        voltage = voltage * keep
    batch["voltage"] = voltage


class DirectStructuralDataset(data_tools.StructuralDataset):
    """Add the true foreground signed-distance target to the shared archive view."""

    def __init__(
        self,
        arrays: data_tools.StructuralArrays,
        archive: np.lib.npyio.NpzFile,
        indices: np.ndarray,
        source: int,
    ) -> None:
        super().__init__(arrays, indices, source)
        self.foreground_sdf = np.asarray(archive["signed_distance"], dtype=np.float32)

    def __getitem__(self, item: int) -> dict[str, torch.Tensor]:
        result = super().__getitem__(item)
        index = int(result["index"])
        result["sdf"] = torch.from_numpy(self.foreground_sdf[index][None])
        return result


def gradients(image: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    return image[:, :, 1:, :] - image[:, :, :-1, :], image[:, :, :, 1:] - image[:, :, :, :-1]


def weighted_case_mean(value: torch.Tensor, weight: torch.Tensor) -> torch.Tensor:
    per_case = value.flatten(1).mean(dim=1)
    weight = weight.flatten()
    return (per_case * weight).sum() / weight.sum().clamp_min(1.0)


def balanced_case_bce(logit: torch.Tensor, target: torch.Tensor, weight: torch.Tensor) -> torch.Tensor:
    loss = F.binary_cross_entropy_with_logits(logit, target, reduction="none").flatten()
    target = target.flatten()
    weight = weight.flatten()
    positive = (target > 0.5) & (weight > 0)
    negative = (target <= 0.5) & (weight > 0)
    terms: list[torch.Tensor] = []
    if positive.any():
        terms.append((loss[positive] * weight[positive]).sum() / weight[positive].sum())
    if negative.any():
        terms.append((loss[negative] * weight[negative]).sum() / weight[negative].sum())
    return torch.stack(terms).mean() if terms else loss.new_zeros(())


def probability_bce(probability: torch.Tensor, target: torch.Tensor, domain: torch.Tensor) -> torch.Tensor:
    with torch.amp.autocast("cuda", enabled=False):
        probability = probability.float().clamp(1e-6, 1.0 - 1e-6)
        target = target.float()
        domain = domain.float()
        raw = F.binary_cross_entropy(probability, target, reduction="none")
    positive = target * domain
    negative = (1.0 - target) * domain
    dims = (1, 2, 3)
    positive_loss = (raw * positive).sum(dim=dims) / positive.sum(dim=dims).clamp_min(1.0)
    negative_loss = (raw * negative).sum(dim=dims) / negative.sum(dim=dims).clamp_min(1.0)
    has_positive = positive.sum(dim=dims) > 0
    return torch.where(has_positive, 0.5 * (positive_loss + negative_loss), negative_loss).mean()


def per_case_soft_iou(probability: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    dimensions = (1, 2, 3)
    intersection = (probability * target).sum(dim=dimensions)
    union = (probability + target - probability * target).sum(dim=dimensions)
    return intersection / union.clamp_min(1.0)


def compute_loss(
    outputs: dict[str, torch.Tensor],
    batch: dict[str, torch.Tensor],
    fov: torch.Tensor,
    physics: PhysicsOperator,
    physics_weight: float,
    topology_strength: float,
    risk_aware: bool = False,
    area_budget_weight: float = 0.0,
    boundary_protection_weight: float = 0.0,
    protection_kernel: int = 7,
) -> tuple[torch.Tensor, dict[str, float]]:
    labels = batch["labels"]
    target_foreground = (labels != 0).float().unsqueeze(1)
    class_weights = outputs["logits"].new_tensor([0.24, 1.0, 1.0])

    base_ce = F.cross_entropy(outputs["base_logits"], labels, weight=class_weights)
    base_dice = data_tools.soft_dice_loss(outputs["base_probabilities"], labels)
    final_ce = F.nll_loss(outputs["logits"], labels, weight=class_weights)
    final_dice = data_tools.soft_dice_loss(outputs["probabilities"], labels)
    sdf = F.smooth_l1_loss(outputs["sdf"], batch["sdf"], beta=0.08)

    base_dy, base_dx = gradients(outputs["base_foreground_probability"])
    final_dy, final_dx = gradients(outputs["foreground_probability"])
    true_dy, true_dx = gradients(target_foreground)
    boundary = (
        0.45 * (F.l1_loss(base_dy, true_dy) + F.l1_loss(base_dx, true_dx))
        + 0.55 * (F.l1_loss(final_dy, true_dy) + F.l1_loss(final_dx, true_dx))
    )
    conductivity = F.smooth_l1_loss(outputs["delta"] * fov, batch["delta"] * fov, beta=0.06)
    physical = physics.loss(outputs["delta"], batch["voltage"])

    total = (
        1.00 * base_ce
        + 1.00 * base_dice
        + 0.85 * final_ce
        + 0.85 * final_dice
        + 0.32 * sdf
        + 0.32 * boundary
        + 0.38 * conductivity
        + physics_weight * physical
    )

    source = batch["source"]
    structural_weight = torch.where(
        source == 0,
        source.new_full(source.shape, 0.30, dtype=torch.float32),
        torch.where(
            source == 1,
            source.new_full(source.shape, 1.00, dtype=torch.float32),
            source.new_full(source.shape, 1.35, dtype=torch.float32),
        ),
    )
    domain = fov * structural_weight[:, None, None, None]
    cutout_bce = data_tools.balanced_bce(outputs["cutout_logit"], batch["cutout"], domain)
    cutout_dice = data_tools.binary_structure_dice(
        outputs["raw_cutout_probability"], batch["cutout"], structural_weight
    )
    effective_fit = probability_bce(
        outputs["effective_cutout_probability"], batch["cutout"], domain
    )
    mouth_bce = data_tools.balanced_bce(outputs["mouth_logit"], batch["mouth"], domain)
    mouth_dice = data_tools.binary_structure_dice(
        outputs["mouth_probability"], batch["mouth"], structural_weight
    )
    has_cutout = (batch["cutout"].sum(dim=(1, 2, 3)) > 0).float().unsqueeze(1)
    case_gate = balanced_case_bce(outputs["case_gate_logit"], has_cutout, structural_weight)

    deep_weight = batch["cutout"] * (0.35 + 0.65 * batch["cutout_depth"]) * domain
    deep_cutout = (
        -torch.log(outputs["raw_cutout_probability"].clamp_min(1e-6)) * deep_weight
    ).sum() / deep_weight.sum().clamp_min(1.0)
    structural_valid = (structural_weight > 0).float()[:, None, None, None]
    topology = data_tools.cutout_cldice(
        outputs["raw_cutout_probability"] * batch["support"] * structural_valid,
        batch["cutout"] * structural_valid,
    )

    empty = (has_cutout <= 0.5).float()[:, :, None, None]
    ordinary_domain = batch["support"] * empty * structural_weight[:, None, None, None]
    ordinary_cut = (
        outputs["effective_cutout_probability"] * ordinary_domain
    ).sum() / ordinary_domain.sum().clamp_min(1.0)
    ordinary_consistency = weighted_case_mean(
        torch.abs(outputs["probabilities"] - outputs["base_probabilities"]),
        (has_cutout <= 0.5).float() * structural_weight[:, None],
    )
    bank_loss = (
        (1.0 - outputs["foreground_probability"]) * target_foreground
    ).sum() / target_foreground.sum().clamp_min(1.0)
    notch_fill = (
        outputs["foreground_probability"] * batch["cutout"] * domain
    ).sum() / (batch["cutout"] * domain).sum().clamp_min(1.0)

    # The topology branch removes foreground pixels.  Match the amount of
    # removal to the target cutout and protect the true lesion boundary away
    # from a small cutout neighbourhood.  Both terms are disabled by default
    # so the historical v3/v4 checkpoints remain exactly reproducible.
    edit = (
        outputs["base_foreground_probability"] - outputs["foreground_probability"]
    ).clamp_min(0.0)
    target_edit = outputs["base_foreground_probability"].detach() * batch["cutout"]
    edit_area = (edit * domain).sum(dim=(1, 2, 3))
    target_edit_area = (target_edit * domain).sum(dim=(1, 2, 3))
    area_normalizer = target_edit_area + 0.02 * domain.sum(dim=(1, 2, 3)) + 1.0
    area_budget = torch.abs(edit_area - target_edit_area) / area_normalizer

    kernel = max(3, int(protection_kernel))
    if kernel % 2 == 0:
        kernel += 1
    cutout_neighbourhood = F.max_pool2d(
        batch["cutout"], kernel_size=kernel, stride=1, padding=kernel // 2
    ).clamp(0.0, 1.0)
    protected_boundary = (
        batch["support"]
        * target_foreground
        * (1.0 - cutout_neighbourhood)
        * structural_weight[:, None, None, None]
    )
    boundary_protection = (
        torch.abs(outputs["foreground_probability"] - outputs["base_foreground_probability"])
        * protected_boundary
    ).sum() / protected_boundary.sum().clamp_min(1.0)

    action_gate = outputs["action_gate"].flatten()
    action_gate_loss = action_gate.new_zeros(())
    ordinary_gate = action_gate.new_zeros(())
    ordinary_tail = action_gate.new_zeros(())
    if risk_aware:
        proposal_foreground = outputs["proposal_probabilities"][:, 1:].sum(dim=1, keepdim=True)
        proposal_cutout = outputs["proposal_cutout_probability"]
        base_iou = per_case_soft_iou(outputs["base_foreground_probability"], target_foreground)
        proposal_iou = per_case_soft_iou(proposal_foreground, target_foreground)
        dimensions = (1, 2, 3)
        cutout_pixels = batch["cutout"].sum(dim=dimensions)
        cutout_overlap = (proposal_cutout * batch["cutout"]).sum(dim=dimensions)
        cutout_dice_case = 2.0 * cutout_overlap / (
            proposal_cutout.sum(dim=dimensions) + cutout_pixels
        ).clamp_min(1.0)
        notch_gain = (
            (outputs["base_foreground_probability"] - proposal_foreground) * batch["cutout"]
        ).sum(dim=dimensions) / cutout_pixels.clamp_min(1.0)
        proposal_quality = (
            torch.sigmoid(8.0 * (cutout_dice_case - 0.12))
            * torch.sigmoid(18.0 * (notch_gain - 0.01))
            * torch.sigmoid(20.0 * (proposal_iou - base_iou + 0.015))
        )
        action_target = torch.nan_to_num(
            has_cutout.flatten() * proposal_quality.detach(), nan=0.0, posinf=1.0, neginf=0.0
        ).clamp(0.0, 1.0)
        action_gate_loss = F.binary_cross_entropy_with_logits(
            outputs["action_gate_logit"].flatten(), action_target
        )
        ordinary_case = has_cutout.flatten() <= 0.5
        if ordinary_case.any():
            final_difference = torch.abs(
                outputs["probabilities"] - outputs["base_probabilities"]
            ).flatten(1).mean(dim=1)
            ordinary_values = final_difference[ordinary_case]
            tail_count = max(1, int(math.ceil(0.25 * len(ordinary_values))))
            ordinary_tail = torch.topk(ordinary_values, tail_count).values.mean()
            ordinary_gate = (
                outputs["class_gate"].flatten()[ordinary_case].square().mean()
                + action_gate[ordinary_case].square().mean()
            )

    topology_total = (
        0.48 * cutout_bce
        + 0.32 * cutout_dice
        + 0.22 * effective_fit
        + 0.24 * mouth_bce
        + 0.12 * mouth_dice
        + 0.20 * case_gate
        + 0.13 * deep_cutout
        + 0.08 * topology
        + 1.10 * ordinary_cut
        + 0.80 * ordinary_consistency
        + 0.24 * bank_loss
        + 0.22 * notch_fill
        + area_budget_weight * area_budget.mean()
        + boundary_protection_weight * boundary_protection
    )
    if risk_aware:
        topology_total = topology_total + (
            0.75 * action_gate_loss
            + 2.20 * ordinary_gate
            + 2.40 * ordinary_tail
            + 0.45 * case_gate
        )
    total = total + topology_strength * topology_total
    pieces = {
        "total": float(total.detach()),
        "base_ce": float(base_ce.detach()),
        "base_dice": float(base_dice.detach()),
        "final_ce": float(final_ce.detach()),
        "final_dice": float(final_dice.detach()),
        "sdf": float(sdf.detach()),
        "boundary": float(boundary.detach()),
        "conductivity": float(conductivity.detach()),
        "physics": float(physical.detach()),
        "cutout_bce": float(cutout_bce.detach()),
        "cutout_dice": float(cutout_dice.detach()),
        "effective_fit": float(effective_fit.detach()),
        "mouth": float(mouth_bce.detach()),
        "case_gate": float(case_gate.detach()),
        "deep_cutout": float(deep_cutout.detach()),
        "topology": float(topology.detach()),
        "ordinary_cut": float(ordinary_cut.detach()),
        "ordinary_consistency": float(ordinary_consistency.detach()),
        "bank": float(bank_loss.detach()),
        "notch_fill": float(notch_fill.detach()),
        "area_budget": float(area_budget.mean().detach()),
        "boundary_protection": float(boundary_protection.detach()),
        "topology_strength": float(topology_strength),
        "action_gate": float(action_gate_loss.detach()),
        "ordinary_gate": float(ordinary_gate.detach()),
        "ordinary_tail": float(ordinary_tail.detach()),
    }
    return total, pieces


def case_metrics(truth: np.ndarray, prediction: np.ndarray, cutout: np.ndarray) -> dict[str, float]:
    truth_fg = truth != 0
    pred_fg = prediction != 0
    intersection = np.logical_and(truth_fg, pred_fg).sum()
    union = np.logical_or(truth_fg, pred_fg).sum()
    truth_edge = np.logical_xor(truth_fg, binary_erosion(truth_fg))
    pred_edge = np.logical_xor(pred_fg, binary_erosion(pred_fg))
    tolerance = np.ones((3, 3), dtype=bool)
    precision = (pred_edge & binary_dilation(truth_edge, structure=tolerance)).sum() / max(1, pred_edge.sum())
    recall = (truth_edge & binary_dilation(pred_edge, structure=tolerance)).sum() / max(1, truth_edge.sum())
    return {
        "foreground_iou": float(intersection / max(1, union)),
        "foreground_dice": float(2 * intersection / max(1, truth_fg.sum() + pred_fg.sum())),
        "boundary_f1": float(2 * precision * recall / max(1e-9, precision + recall)),
        "notch_preservation": float((~pred_fg[cutout != 0]).mean()) if (cutout != 0).any() else float("nan"),
        "bank_retention": float(pred_fg[truth_fg].mean()) if truth_fg.any() else float("nan"),
        "has_cutout": float((cutout != 0).any()),
    }


def aggregate(rows: list[dict[str, float]]) -> dict[str, float]:
    result: dict[str, float] = {"cases": float(len(rows))}
    for key in sorted({key for row in rows for key in row}):
        values = np.asarray([row.get(key, np.nan) for row in rows], dtype=float)
        result[key] = float(values[np.isfinite(values)].mean()) if np.isfinite(values).any() else float("nan")
    return result


@torch.no_grad()
def evaluate_loader(
    model: TopologyResidualEITNet,
    loader: DataLoader,
    device: torch.device,
) -> tuple[dict[str, dict[str, dict[str, float]]], dict[str, np.ndarray]]:
    model.eval()
    final_rows: list[dict[str, float]] = []
    base_rows: list[dict[str, float]] = []
    saved: dict[str, list[np.ndarray]] = {
        key: [] for key in (
            "index", "image", "truth", "support", "cutout", "base_prediction",
            "raw_cutout", "mouth", "effective_cutout", "prediction", "delta", "case_gate",
            "class_gate", "action_gate",
        )
    }
    for batch in loader:
        outputs = model(batch["image"].to(device), batch["voltage"].to(device))
        prediction = outputs["probabilities"].argmax(dim=1).cpu().numpy()
        base_prediction = outputs["base_probabilities"].argmax(dim=1).cpu().numpy()
        truths = batch["labels"].numpy()
        cutouts = batch["cutout"][:, 0].numpy()
        for offset in range(len(prediction)):
            final_rows.append(case_metrics(truths[offset], prediction[offset], cutouts[offset]))
            base_rows.append(case_metrics(truths[offset], base_prediction[offset], cutouts[offset]))
        saved["index"].append(batch["index"].numpy())
        saved["image"].append(batch["image"][:, 0].numpy())
        saved["truth"].append(truths)
        saved["support"].append(batch["support"][:, 0].numpy())
        saved["cutout"].append(cutouts)
        saved["base_prediction"].append(base_prediction)
        saved["raw_cutout"].append(outputs["raw_cutout_probability"][:, 0].cpu().numpy())
        saved["mouth"].append(outputs["mouth_probability"][:, 0].cpu().numpy())
        saved["effective_cutout"].append(outputs["effective_cutout_probability"][:, 0].cpu().numpy())
        saved["prediction"].append(prediction)
        saved["delta"].append(outputs["delta"][:, 0].cpu().numpy())
        saved["case_gate"].append(outputs["case_gate"][:, 0, 0, 0].cpu().numpy())
        saved["class_gate"].append(outputs["class_gate"][:, 0, 0, 0].cpu().numpy())
        saved["action_gate"].append(outputs["action_gate"][:, 0, 0, 0].cpu().numpy())

    def split(rows: list[dict[str, float]]) -> dict[str, dict[str, float]]:
        concave = [row for row in rows if row["has_cutout"] > 0.5]
        ordinary = [row for row in rows if row["has_cutout"] <= 0.5]
        return {
            "all": aggregate(rows),
            "concave": aggregate(concave) if concave else {"cases": 0.0},
            "ordinary": aggregate(ordinary) if ordinary else {"cases": 0.0},
        }

    final_split = split(final_rows)
    base_split = split(base_rows)
    for name, selected in (
        ("concave", np.asarray([row["has_cutout"] > 0.5 for row in final_rows])),
        ("ordinary", np.asarray([row["has_cutout"] <= 0.5 for row in final_rows])),
    ):
        if selected.any():
            differences = np.asarray([
                final_rows[index]["foreground_iou"] - base_rows[index]["foreground_iou"]
                for index in np.flatnonzero(selected)
            ])
            final_split[name]["mean_iou_delta_vs_direct"] = float(differences.mean())
            final_split[name]["worst_iou_delta_vs_direct"] = float(differences.min())
            final_split[name]["fraction_iou_regressed_over_0_01"] = float(
                (differences < -0.01).mean()
            )
    arrays = {key: np.concatenate(value, axis=0) for key, value in saved.items()}
    return {"final": final_split, "direct_base": base_split}, arrays


def selection_score(
    metrics: dict[str, dict[str, dict[str, dict[str, float]]]],
    strict_safety: bool = False,
) -> float:
    base = metrics["base"]["final"]
    biological = metrics["biological"]["final"]
    stress = metrics["stress"]["final"]
    direct_bio = metrics["biological"]["direct_base"]
    direct_stress = metrics["stress"]["direct_base"]
    score = (
        0.14 * base["all"]["foreground_iou"]
        + 0.16 * biological["ordinary"].get("foreground_iou", 0.0)
        + 0.15 * biological["concave"].get("foreground_iou", 0.0)
        + 0.18 * biological["concave"].get("notch_preservation", 0.0)
        + 0.15 * stress["all"]["foreground_iou"]
        + 0.22 * stress["concave"].get("notch_preservation", 0.0)
    )
    ordinary_regression = direct_bio["ordinary"].get("foreground_iou", 0.0) - biological["ordinary"].get("foreground_iou", 0.0)
    biological_regression = direct_bio["all"]["foreground_iou"] - biological["all"]["foreground_iou"]
    stress_regression = direct_stress["all"]["foreground_iou"] - stress["all"]["foreground_iou"]
    penalty = (
        4.0 * max(0.0, ordinary_regression - 0.003)
        + 2.0 * max(0.0, biological_regression - 0.006)
        + 1.2 * max(0.0, stress_regression - 0.015)
    )
    if strict_safety:
        base_ordinary = base["ordinary"]
        bio_ordinary = biological["ordinary"]
        penalty += (
            8.0 * max(0.0, ordinary_regression - 0.001)
            + 1.2 * bio_ordinary.get("fraction_iou_regressed_over_0_01", 0.0)
            + 0.8 * max(0.0, -bio_ordinary.get("worst_iou_delta_vs_direct", 0.0) - 0.08)
            + 0.8 * base_ordinary.get("fraction_iou_regressed_over_0_01", 0.0)
        )
    return float(score - penalty)


def save_montage(path: Path, groups: dict[str, dict[str, np.ndarray]], title: str) -> None:
    selected: list[tuple[str, int]] = []
    for name, arrays in groups.items():
        pixels = arrays["cutout"].reshape(len(arrays["cutout"]), -1).sum(axis=1)
        selected.extend((name, int(index)) for index in np.argsort(pixels)[-2:][::-1])
        ordinary = np.flatnonzero(pixels == 0)
        selected.extend((name, int(index)) for index in ordinary[:1])
    columns = (
        "linear EIT", "truth", "direct base", "cutout target", "raw cutout",
        "mouth", "effective residual", "final output", "conductivity",
    )
    figure, axes = plt.subplots(len(selected), len(columns), figsize=(17.0, 2.15 * len(selected)), squeeze=False)
    for row, (name, index) in enumerate(selected):
        arrays = groups[name]
        linear = arrays["image"][index]
        scale = max(float(np.percentile(np.abs(linear), 99)), 1e-6)
        panels = (
            (linear, "coolwarm", -scale, scale),
            (arrays["truth"][index], "viridis", 0, 2),
            (arrays["base_prediction"][index], "viridis", 0, 2),
            (arrays["cutout"][index], "magma", 0, 1),
            (arrays["raw_cutout"][index], "magma", 0, 1),
            (arrays["mouth"][index], "plasma", 0, 1),
            (arrays["effective_cutout"][index], "magma", 0, 1),
            (arrays["prediction"][index], "viridis", 0, 2),
            (arrays["delta"][index], "coolwarm", -1.1, 1.1),
        )
        for column, (image, cmap, vmin, vmax) in enumerate(panels):
            axes[row, column].imshow(image, cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest")
            axes[row, column].set_axis_off()
            if row == 0:
                axes[row, column].set_title(columns[column], fontsize=9)
        axes[row, 0].set_ylabel(f"{name}\n#{int(arrays['index'][index])}", fontsize=8)
    figure.suptitle(title)
    figure.tight_layout(rect=(0, 0, 1, 0.975))
    figure.savefig(path, dpi=170)
    plt.close(figure)


def save_history(path: Path, history: list[dict[str, object]]) -> None:
    epochs = [int(row["epoch"]) for row in history]
    figure, axes = plt.subplots(1, 3, figsize=(13.0, 3.8))
    axes[0].plot(epochs, [float(row["train_loss"]) for row in history])
    axes[0].set_title("training loss")
    axes[1].plot(epochs, [float(row["score"]) for row in history])
    axes[1].set_title("validation score")
    for name in ("base", "biological", "stress"):
        axes[2].plot(
            epochs,
            [float(row["validation"][name]["final"]["all"]["foreground_iou"]) for row in history],
            label=name,
        )
    axes[2].set_title("final IoU")
    axes[2].legend(fontsize=8)
    for axis in axes:
        axis.grid(alpha=0.25)
        axis.set_xlabel("epoch")
    figure.tight_layout()
    figure.savefig(path, dpi=170)
    plt.close(figure)


def make_loader(dataset: Dataset, args: argparse.Namespace, shuffle: bool) -> DataLoader:
    return DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=shuffle,
        num_workers=args.workers,
        pin_memory=torch.cuda.is_available(),
        persistent_workers=args.workers > 0,
    )


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    archives = {
        "base": np.load(args.base_dataset.resolve(), allow_pickle=True),
        "biological": np.load(args.biological_dataset.resolve(), allow_pickle=True),
        "stress": np.load(args.stress_dataset.resolve(), allow_pickle=True),
    }
    arrays = {name: data_tools.prepare_arrays(archive, name) for name, archive in archives.items()}
    if args.device == "auto":
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable")

    train_parts: list[Dataset] = [
        DirectStructuralDataset(arrays["base"], archives["base"], archives["base"]["train_indices"], 0),
        DirectStructuralDataset(
            arrays["biological"], archives["biological"], archives["biological"]["train_indices"], 1
        ),
    ]
    for name, source in (("base", 0), ("biological", 1)):
        indices = np.asarray(archives[name]["train_indices"], dtype=np.int64)
        ordinary = indices[
            arrays[name].cutout[indices].reshape(len(indices), -1).sum(axis=1) == 0
        ]
        for _ in range(max(1, args.ordinary_repeat) - 1):
            train_parts.append(DirectStructuralDataset(arrays[name], archives[name], ordinary, source))
    for _ in range(max(1, args.stress_repeat)):
        train_parts.append(
            DirectStructuralDataset(arrays["stress"], archives["stress"], archives["stress"]["train_indices"], 2)
        )
    train_loader = make_loader(ConcatDataset(train_parts), args, shuffle=True)
    validation_loaders = {
        name: make_loader(
            DirectStructuralDataset(arrays[name], archives[name], archives[name]["validation_indices"], source),
            args,
            shuffle=False,
        )
        for source, name in enumerate(("base", "biological", "stress"))
    }
    test_loaders = {
        name: make_loader(
            DirectStructuralDataset(arrays[name], archives[name], archives[name]["test_indices"], source),
            args,
            shuffle=False,
        )
        for source, name in enumerate(("base", "biological", "stress"))
    }

    risk_aware = args.architecture == "v4"
    amp_enabled = device.type == "cuda" and not args.disable_amp
    model = TopologyResidualEITNet(
        arrays["base"].fov_mask, base=args.base_channels, risk_aware=risk_aware
    ).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=max(1, args.epochs), eta_min=1e-5
    )
    scaler = torch.amp.GradScaler(
        "cuda", enabled=amp_enabled, init_scale=1024.0, growth_interval=1000
    )
    physics = PhysicsOperator(
        torch.from_numpy(np.asarray(archives["base"]["jacobian"], dtype=np.float32)).to(device),
        torch.from_numpy(np.asarray(archives["base"]["node_to_raw_pixel"], dtype=np.int64)).to(device),
    )
    fov = torch.from_numpy(arrays["base"].fov_mask.astype(np.float32))[None, None].to(device)
    parameter_count = sum(parameter.numel() for parameter in model.parameters())
    print(
        f"device={device}; gpu={torch.cuda.get_device_name(0) if device.type == 'cuda' else 'none'}; "
        f"parameters={parameter_count:,}; train={len(train_loader.dataset)}",
        flush=True,
    )

    checkpoint = output_dir / f"topology_residual_{args.architecture}_best.pt"
    history_path = output_dir / "training_history.json"
    history: list[dict[str, object]] = []
    best_score = -math.inf
    stale = 0
    start_epoch = 1
    if args.resume_checkpoint is not None:
        resume = torch.load(args.resume_checkpoint.resolve(), map_location=device, weights_only=False)
        model.load_state_dict(resume["model"])
        start_epoch = int(resume["epoch"]) + 1
        best_score = float(resume.get("validation_score", -math.inf))
        if "optimizer" in resume:
            optimizer.load_state_dict(resume["optimizer"])
        if "scheduler" in resume:
            scheduler.load_state_dict(resume["scheduler"])
        if "scaler" in resume:
            scaler.load_state_dict(resume["scaler"])
        if history_path.exists():
            history = json.loads(history_path.read_text(encoding="utf-8"))
        print(
            f"resuming self-trained checkpoint epoch={start_epoch - 1}; best={best_score:.4f}; "
            f"lr={optimizer.param_groups[0]['lr']:.3g}",
            flush=True,
        )
    for epoch in range(start_epoch, args.epochs + 1):
        started = time.perf_counter()
        topology_strength = min(1.0, max(0.0, (epoch - args.topology_start) / max(1, args.topology_ramp)))
        model.train()
        totals: dict[str, float] = {}
        batches = 0
        skipped_batches = 0
        for batch_index, batch in enumerate(train_loader, start=1):
            if args.max_train_batches and batch_index > args.max_train_batches:
                break
            batch = to_device(batch, device)
            randomize_measurements(batch, args)
            optimizer.zero_grad(set_to_none=True)
            with torch.amp.autocast(device.type, enabled=amp_enabled):
                outputs = model(batch["image"], batch["voltage"])
                if not all(
                    torch.isfinite(value).all()
                    for value in outputs.values()
                    if torch.is_tensor(value)
                ):
                    skipped_batches += 1
                    optimizer.zero_grad(set_to_none=True)
                    continue
                loss, pieces = compute_loss(
                    outputs, batch, fov, physics, args.physics_weight, topology_strength,
                    risk_aware=risk_aware,
                    area_budget_weight=args.area_budget_weight,
                    boundary_protection_weight=args.boundary_protection_weight,
                    protection_kernel=args.protection_kernel,
                )
            if not torch.isfinite(loss):
                skipped_batches += 1
                optimizer.zero_grad(set_to_none=True)
                continue
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            invalid = [
                name for name, parameter in model.named_parameters()
                if parameter.grad is not None and not torch.isfinite(parameter.grad).all()
            ]
            if invalid:
                skipped_batches += 1
                optimizer.zero_grad(set_to_none=True)
                print(json.dumps({"loss": float(loss.detach()), "pieces": pieces, "invalid": invalid}, indent=2), flush=True)
                if args.diagnose_gradients:
                    return
                if amp_enabled:
                    scaler.update(new_scale=max(1.0, float(scaler.get_scale()) / 2.0))
                continue
            torch.nn.utils.clip_grad_norm_(model.parameters(), 4.0)
            scaler.step(optimizer)
            scaler.update()
            batches += 1
            for key, value in pieces.items():
                totals[key] = totals.get(key, 0.0) + value
        scheduler.step()
        averages = {key: value / max(1, batches) for key, value in totals.items()}
        validation: dict[str, dict[str, dict[str, dict[str, float]]]] = {}
        visuals: dict[str, dict[str, np.ndarray]] = {}
        for name, loader in validation_loaders.items():
            validation[name], visuals[name] = evaluate_loader(model, loader, device)
        score = selection_score(validation, strict_safety=risk_aware)
        row: dict[str, object] = {
            "epoch": epoch,
            "train_loss": averages.get("total", float("nan")),
            "train_pieces": averages,
            "learning_rate": optimizer.param_groups[0]["lr"],
            "topology_strength": topology_strength,
            "skipped_batches": skipped_batches,
            "score": score,
            "elapsed_seconds": time.perf_counter() - started,
            "validation": validation,
        }
        history.append(row)
        improved = score > best_score + 1e-5
        if improved:
            best_score = score
            stale = 0
            torch.save(
                {
                    "model": model.state_dict(),
                    "epoch": epoch,
                    "validation_score": score,
                    "validation": validation,
                    "base_channels": args.base_channels,
                    "propagation_steps": model.propagation_steps,
                    "risk_aware": risk_aware,
                    "optimizer": optimizer.state_dict(),
                    "scheduler": scheduler.state_dict(),
                    "scaler": scaler.state_dict(),
                    "args": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
                },
                checkpoint,
            )
        else:
            stale += 1
        bio = validation["biological"]
        stress = validation["stress"]
        print(
            f"epoch={epoch:03d} loss={averages.get('total', float('nan')):.4f} score={score:.4f} "
            f"bio_iou={bio['final']['all']['foreground_iou']:.4f} "
            f"bio_ordinary={bio['final']['ordinary'].get('foreground_iou', float('nan')):.4f} "
            f"bio_notch={bio['final']['concave'].get('notch_preservation', float('nan')):.4f} "
            f"stress_iou={stress['final']['all']['foreground_iou']:.4f} "
            f"stress_notch={stress['final']['concave'].get('notch_preservation', float('nan')):.4f} "
            f"gate={float(visuals['biological']['case_gate'].mean()):.3f} best={improved} "
            f"skipped={skipped_batches} time={row['elapsed_seconds']:.1f}s",
            flush=True,
        )
        history_path.write_text(json.dumps(history, indent=2), encoding="utf-8")
        save_history(output_dir / "training_history.png", history)
        if improved or epoch == 1 or epoch % max(1, args.progress_every) == 0:
            save_montage(
                output_dir / f"validation_epoch_{epoch:03d}.png",
                visuals,
                f"Topology-residual EIT {args.architecture} validation, epoch {epoch}",
            )
        if stale >= args.patience:
            print(f"early stopping at epoch {epoch}; best score={best_score:.4f}", flush=True)
            break

    state = torch.load(checkpoint, map_location=device, weights_only=False)
    model.load_state_dict(state["model"])
    test_metrics: dict[str, dict[str, dict[str, dict[str, float]]]] = {}
    test_arrays: dict[str, dict[str, np.ndarray]] = {}
    for name, loader in test_loaders.items():
        test_metrics[name], test_arrays[name] = evaluate_loader(model, loader, device)
    save_montage(
        output_dir / "independent_test_comparison.png",
        test_arrays,
        f"Topology-residual EIT {args.architecture} independent tests (best epoch {state['epoch']})",
    )
    np.savez_compressed(
        output_dir / "test_predictions.npz",
        **{f"{name}_{key}": value for name, group in test_arrays.items() for key, value in group.items()},
    )
    summary = {
        "method": (
            "from-scratch risk-aware topology-action EIT network"
            if risk_aware else
            "from-scratch direct reconstruction with exterior-connected topology residual"
        ),
        "device": str(device),
        "gpu": torch.cuda.get_device_name(0) if device.type == "cuda" else None,
        "parameters": parameter_count,
        "random_initialization": True,
        "loaded_pretrained_weights": False,
        "best_epoch": int(state["epoch"]),
        "best_validation_score": float(state["validation_score"]),
        "validation": state["validation"],
        "independent_test": test_metrics,
        "public_ktc_truth_used_for_training_or_selection": False,
        "args": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
