"""Train a synthetic-only risk-gated within-case ranker for concave EIT edits.

The model separates two questions that a plain multi-target regressor conflates:
whether an exterior-connected edit is safe, and whether it is useful.  A
case-wise ranking loss then makes every proposed edit compete against the
identity fallback.  Public KTC cases are never used for training or policy
selection.
"""
from __future__ import annotations

import argparse
import json
import random
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from train_ktc_synthetic_bay_verifier import (
    HEAD_NAMES,
    STRESS_FAMILIES,
    BayVerifier,
    CachedCase,
    bootstrap_means,
    load_split,
    normalization,
    set_seed,
)


CLASS_NAMES = (
    "safe_iou",
    "safe_boundary",
    "safe_bank",
    "open_gain",
    "topology_safe",
    "joint_good",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--stress-cache", type=Path,
        default=Path(r"E:\Codex\ktc_synthetic_instance_bay_cache_stress_seed20260820"),
    )
    parser.add_argument(
        "--base-cache", type=Path,
        default=Path(r"E:\Codex\ktc_synthetic_instance_bay_cache_base_seed20260820"),
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=Path(r"E:\Codex\ktc_synthetic_bay_risk_ranker_seed20260820"),
    )
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--ensemble-size", type=int, default=3)
    parser.add_argument("--case-batch-size", type=int, default=20)
    parser.add_argument("--candidates-per-case", type=int, default=112)
    parser.add_argument("--learning-rate", type=float, default=7e-4)
    parser.add_argument("--weight-decay", type=float, default=2e-4)
    parser.add_argument("--seed", type=int, default=20260820)
    parser.add_argument(
        "--include-physics", action="store_true",
        help="Use all 150 feature columns, including CV and fixed-residual physics evidence.",
    )
    parser.add_argument(
        "--candidate-mode", choices=("compensated", "pure"), default="compensated",
        help="Train on expansion-compensated bays or zero-expansion exterior bays.",
    )
    parser.add_argument(
        "--validation-only", action="store_true",
        help="Stop after fitting and validation policy selection without opening test labels.",
    )
    return parser.parse_args()


def load_cases(
    root: Path, split: str, source: str, include_physics: bool,
    candidate_mode: str = "compensated",
) -> list[CachedCase]:
    if not include_physics:
        return load_split(root, split, source)
    cases: list[CachedCase] = []
    for path in sorted((root.resolve() / split).glob("sample_*.npz")):
        archive = np.load(path, allow_pickle=False)
        target_names = [str(value) for value in archive["target_names"]]
        targets_all = np.asarray(archive["target_delta"], dtype=np.float32)
        targets = targets_all[:, [target_names.index(name) for name in HEAD_NAMES]]
        features = np.asarray(archive["features"], dtype=np.float32)
        kind = np.asarray(archive["meta_kind"], dtype=np.int64)
        removed = np.asarray(archive["meta_removed"], dtype=np.float32)
        added = np.asarray(archive["meta_added"], dtype=np.float32)
        valid = (
            (kind == 2) & (removed >= 0.005) & (features[:, 3] >= 0.015)
            & (np.asarray(archive["meta_open"], dtype=np.float32) >= 0.995)
            & (np.asarray(archive["meta_new_holes"], dtype=np.float32) == 0)
        )
        if candidate_mode == "compensated":
            valid &= added >= 0.005
        elif candidate_mode == "pure":
            valid &= added <= 1e-8
        else:
            raise ValueError(f"unknown candidate mode: {candidate_mode}")
        valid[0] = True
        if features.shape[1] != 150 or not np.isfinite(features).all():
            raise ValueError(f"invalid physical feature matrix in {path}: {features.shape}")
        cases.append(CachedCase(
            source, split, f"{source}/{split}/{path.stem}", features, targets, valid,
            int(np.asarray(archive["global_index"]).item()),
            int(np.asarray(archive["family"]).item()),
        ))
    if not cases:
        raise FileNotFoundError(f"no cache files under {root / split}")
    return cases


def class_targets(targets: np.ndarray) -> np.ndarray:
    safe_iou = targets[:, 0] >= -0.005
    safe_boundary = targets[:, 1] >= -0.020
    safe_bank = targets[:, 3] >= -0.020
    open_gain = targets[:, 2] >= 0.020
    topology_safe = targets[:, 4] >= 0.0
    joint_good = safe_iou & safe_boundary & safe_bank & open_gain & topology_safe
    return np.column_stack((
        safe_iou, safe_boundary, safe_bank, open_gain, topology_safe, joint_good
    )).astype(np.float32)


def risk_adjusted_utility(targets: torch.Tensor) -> torch.Tensor:
    utility = (
        targets[:, 0] + 0.25 * targets[:, 1] + 0.75 * targets[:, 2]
        + 0.25 * targets[:, 3] + 0.50 * targets[:, 4]
    )
    risk = (
        4.0 * F.relu(-0.005 - targets[:, 0])
        + F.relu(-0.020 - targets[:, 1])
        + 2.0 * F.relu(-0.020 - targets[:, 3])
    )
    return utility - risk


class RiskRankVerifier(nn.Module):
    def __init__(self, feature_count: int) -> None:
        super().__init__()
        self.trunk = nn.Sequential(
            nn.Linear(feature_count, 256), nn.LayerNorm(256), nn.SiLU(), nn.Dropout(0.10),
            nn.Linear(256, 192), nn.LayerNorm(192), nn.SiLU(), nn.Dropout(0.08),
            nn.Linear(192, 128), nn.LayerNorm(128), nn.SiLU(),
            nn.Linear(128, 96), nn.SiLU(),
        )
        self.regression = nn.Linear(96, len(HEAD_NAMES))
        self.classification = nn.Linear(96, len(CLASS_NAMES))
        self.rank = nn.Linear(96, 1)

    def forward(self, features: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        latent = self.trunk(features)
        return self.regression(latent), self.classification(latent), self.rank(latent).squeeze(1)


def sample_case(case: CachedCase, rng: np.random.Generator, count: int) -> np.ndarray:
    admissible = np.flatnonzero(case.valid)
    targets = case.targets
    classes = class_targets(targets)
    joint = admissible[classes[admissible, 5] > 0.5]
    useful = admissible[
        (classes[admissible, 0] > 0.5)
        & (classes[admissible, 2] > 0.5)
        & (classes[admissible, 3] > 0.5)
    ]
    harmful = admissible[
        (targets[admissible, 0] < -0.010) | (targets[admissible, 3] < -0.030)
    ]

    def take(values: np.ndarray, limit: int) -> np.ndarray:
        if len(values) <= limit:
            return values
        return rng.choice(values, size=limit, replace=False)

    reserved = np.unique(np.concatenate((
        np.asarray([0]), take(joint, count // 4), take(useful, count // 4),
        take(harmful, count // 4),
    )))
    remaining = np.setdiff1d(admissible, reserved, assume_unique=False)
    selected = np.unique(np.concatenate((
        reserved, take(remaining, max(0, count - len(reserved))),
    )))
    if len(selected) > count:
        keep = selected[selected != 0]
        selected = np.sort(np.concatenate((np.asarray([0]), take(keep, count - 1))))
    return selected


def positive_weights(cases: list[CachedCase]) -> np.ndarray:
    rows = np.concatenate([class_targets(case.targets[case.valid]) for case in cases])
    positives = rows.sum(axis=0)
    negatives = len(rows) - positives
    return np.clip(negatives / np.maximum(positives, 1.0), 1.0, 60.0).astype(np.float32)


def train_model(
    seed: int,
    cases: list[CachedCase],
    norm: tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray],
    args: argparse.Namespace,
    device: torch.device,
) -> tuple[RiskRankVerifier, list[dict[str, float]]]:
    set_seed(seed)
    fm, fs, tm, ts = (torch.from_numpy(value).to(device) for value in norm)
    pos_weight = torch.from_numpy(positive_weights(cases)).to(device)
    model = RiskRankVerifier(len(norm[0])).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    rng = np.random.default_rng(seed)
    history: list[dict[str, float]] = []
    for epoch in range(args.epochs):
        model.train()
        order = rng.permutation(len(cases))
        epoch_losses: list[float] = []
        for start in range(0, len(order), args.case_batch_size):
            selected_cases = [cases[int(index)] for index in order[start:start + args.case_batch_size]]
            selected_indices = [sample_case(case, rng, args.candidates_per_case) for case in selected_cases]
            feature_rows = np.concatenate([
                case.features[index] for case, index in zip(selected_cases, selected_indices)
            ])
            target_rows = np.concatenate([
                case.targets[index] for case, index in zip(selected_cases, selected_indices)
            ])
            features = torch.from_numpy(feature_rows).to(device)
            targets = torch.from_numpy(target_rows).to(device)
            regression, logits, rank = model((features - fm) / fs)
            normalized_targets = (targets - tm) / ts
            regression_loss = F.smooth_l1_loss(regression, normalized_targets, beta=0.35)
            binary_targets = torch.from_numpy(class_targets(target_rows)).to(device)
            classification_loss = F.binary_cross_entropy_with_logits(
                logits, binary_targets, pos_weight=pos_weight
            )
            rank_losses: list[torch.Tensor] = []
            identity_losses: list[torch.Tensor] = []
            offset = 0
            for indices in selected_indices:
                stop = offset + len(indices)
                utility = risk_adjusted_utility(targets[offset:stop])
                target_distribution = torch.softmax(utility / 0.08, dim=0)
                rank_losses.append(-torch.sum(target_distribution * F.log_softmax(rank[offset:stop], dim=0)))
                identity_position = int(np.flatnonzero(indices == 0)[0])
                identity_losses.append(
                    regression[offset + identity_position].square().mean()
                    + rank[offset + identity_position].square()
                )
                offset = stop
            rank_loss = torch.stack(rank_losses).mean()
            identity_loss = torch.stack(identity_losses).mean()
            loss = regression_loss + 0.55 * classification_loss + 0.18 * rank_loss + 0.08 * identity_loss
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            epoch_losses.append(float(loss.detach()))
        record = {"epoch": epoch + 1, "loss": float(np.mean(epoch_losses))}
        history.append(record)
        if epoch == 0 or (epoch + 1) % 10 == 0:
            print(f"seed={seed} epoch={epoch + 1}/{args.epochs} loss={record['loss']:.5f}", flush=True)
    model.eval()
    return model, history


@dataclass(frozen=True)
class Policy:
    safe_iou: float
    safe_boundary: float
    safe_bank: float
    open_gain: float
    joint_good: float
    min_reg_iou: float
    rank_margin: float
    uncertainty: float
    max_change: float
    max_removal: float


POLICIES = tuple(
    Policy(pi, pbnd, pbank, popen, pjoint, riou, rank, unc, change, removal)
    for pi in (0.50, 0.68, 0.82)
    for pbnd in (0.35, 0.55)
    for pbank in (0.50, 0.70, 0.85)
    for popen in (0.45, 0.62)
    for pjoint in (0.03, 0.10, 0.25)
    for riou in (-0.080, -0.040, -0.010)
    for rank in (-0.05, 0.00, 0.05)
    for unc in (0.0, 0.5)
    for change in (0.36, 0.62)
    for removal in (0.18, 0.36)
) + (Policy(1, 1, 1, 1, 1, 1, 1, 1, 0.36, 0.18),)


@torch.no_grad()
def predict_cases(
    models: list[RiskRankVerifier],
    cases: list[CachedCase],
    norm: tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray],
    device: torch.device,
) -> dict[str, tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]]:
    fm, fs, tm, ts = (torch.from_numpy(value).to(device) for value in norm)
    output = {}
    for case in cases:
        features = (torch.from_numpy(case.features).to(device) - fm) / fs
        regressions, probabilities, ranks = [], [], []
        for model in models:
            regression, logits, rank = model(features)
            regressions.append((regression * ts + tm).cpu().numpy())
            probabilities.append(torch.sigmoid(logits).cpu().numpy())
            ranks.append((rank - rank[:1]).cpu().numpy())
        regression_matrix = np.stack(regressions)
        regression_matrix -= regression_matrix[:, :1]
        probability_matrix = np.stack(probabilities)
        rank_matrix = np.stack(ranks)
        output[case.case_id] = (
            regression_matrix.mean(0), regression_matrix.std(0),
            probability_matrix.mean(0), probability_matrix.std(0),
            rank_matrix.mean(0) - rank_matrix.std(0),
        )
    return output


def choose(case: CachedCase, evidence: tuple[np.ndarray, ...], policy: Policy) -> int:
    regression, regression_std, probability, probability_std, rank_lower = evidence
    probability_lower = probability - policy.uncertainty * probability_std
    iou_lower = regression[:, 0] - policy.uncertainty * regression_std[:, 0]
    metadata_offset = 130 if case.features.shape[1] == 150 else 117
    removed = case.features[:, metadata_offset]
    added = case.features[:, metadata_offset + 1]
    valid = case.valid.copy()
    valid &= (removed + added) <= policy.max_change
    valid &= removed <= policy.max_removal
    valid &= probability_lower[:, 0] >= policy.safe_iou
    valid &= probability_lower[:, 1] >= policy.safe_boundary
    valid &= probability_lower[:, 2] >= policy.safe_bank
    valid &= probability_lower[:, 3] >= policy.open_gain
    valid &= probability_lower[:, 5] >= policy.joint_good
    valid &= iou_lower >= policy.min_reg_iou
    valid &= rank_lower >= policy.rank_margin
    valid[0] = True
    score = (
        rank_lower + 0.40 * iou_lower + 0.18 * regression[:, 2]
        + 0.10 * regression[:, 3] + 0.10 * regression[:, 4]
    )
    score[0] = 0.0
    score = np.where(valid, score, -np.inf)
    return int(np.argmax(score))


def result(cases: list[CachedCase], predictions: dict[str, tuple[np.ndarray, ...]], policy: Policy):
    choices = np.asarray([choose(case, predictions[case.case_id], policy) for case in cases])
    values = np.stack([case.targets[index] for case, index in zip(cases, choices)])
    return choices, values, {
        "changed": int(np.count_nonzero(choices)),
        **{f"mean_{name}": float(values[:, i].mean()) for i, name in enumerate(HEAD_NAMES)},
        "minimum_iou": float(values[:, 0].min()),
        "harmed_iou_005": int(np.count_nonzero(values[:, 0] < -0.005)),
        "harmed_iou_010": int(np.count_nonzero(values[:, 0] < -0.010)),
        "harmed_bank_010": int(np.count_nonzero(values[:, 3] < -0.010)),
        "improved_open_010": int(np.count_nonzero(values[:, 2] > 0.010)),
    }


def all_policy_results(cases, predictions, chunk_size: int = 2048):
    """Evaluate the full policy grid with the exact ``choose`` semantics.

    The former Python policy-by-policy loop repeated every candidate filter
    more than 12 million times on validation.  Candidate decisions are
    independent across policies, so evaluate a bounded policy block as one
    NumPy matrix while retaining identity fallback for every row.
    """
    count = len(POLICIES)
    policy_values = {
        field: np.asarray([getattr(policy, field) for policy in POLICIES], dtype=np.float32)
        for field in Policy.__dataclass_fields__
    }
    target_sum = np.zeros((count, len(HEAD_NAMES)), dtype=np.float64)
    minimum_iou = np.full(count, np.inf, dtype=np.float64)
    harmed_iou_005 = np.zeros(count, dtype=np.int64)
    harmed_iou_010 = np.zeros(count, dtype=np.int64)
    harmed_bank_010 = np.zeros(count, dtype=np.int64)
    improved_open_010 = np.zeros(count, dtype=np.int64)
    changed = np.zeros(count, dtype=np.int64)
    changed_iou_sum = np.zeros(count, dtype=np.float64)

    for case in cases:
        regression, regression_std, probability, probability_std, rank_lower = predictions[case.case_id]
        metadata_offset = 130 if case.features.shape[1] == 150 else 117
        removed = case.features[:, metadata_offset]
        added = case.features[:, metadata_offset + 1]
        for start in range(0, count, chunk_size):
            stop = min(start + chunk_size, count)
            row = slice(start, stop)
            uncertainty = policy_values["uncertainty"][row, None]
            valid = np.broadcast_to(case.valid, (stop - start, len(case.valid))).copy()
            valid &= (removed[None] + added[None]) <= policy_values["max_change"][row, None]
            valid &= removed[None] <= policy_values["max_removal"][row, None]
            probability_lower = probability[None] - uncertainty[..., None] * probability_std[None]
            valid &= probability_lower[:, :, 0] >= policy_values["safe_iou"][row, None]
            valid &= probability_lower[:, :, 1] >= policy_values["safe_boundary"][row, None]
            valid &= probability_lower[:, :, 2] >= policy_values["safe_bank"][row, None]
            valid &= probability_lower[:, :, 3] >= policy_values["open_gain"][row, None]
            valid &= probability_lower[:, :, 5] >= policy_values["joint_good"][row, None]
            iou_lower = regression[None, :, 0] - uncertainty * regression_std[None, :, 0]
            valid &= iou_lower >= policy_values["min_reg_iou"][row, None]
            valid &= rank_lower[None] >= policy_values["rank_margin"][row, None]
            valid[:, 0] = True
            score = (
                rank_lower[None] + 0.40 * iou_lower + 0.18 * regression[None, :, 2]
                + 0.10 * regression[None, :, 3] + 0.10 * regression[None, :, 4]
            )
            score[:, 0] = 0.0
            choices = np.argmax(np.where(valid, score, -np.inf), axis=1)
            values = case.targets[choices]
            target_sum[row] += values
            minimum_iou[row] = np.minimum(minimum_iou[row], values[:, 0])
            harmed_iou_005[row] += values[:, 0] < -0.005
            harmed_iou_010[row] += values[:, 0] < -0.010
            harmed_bank_010[row] += values[:, 3] < -0.010
            improved_open_010[row] += values[:, 2] > 0.010
            edited = choices != 0
            changed[row] += edited
            changed_iou_sum[row] += values[:, 0] * edited

    means = target_sum / max(len(cases), 1)
    return {
        "changed": changed,
        **{f"mean_{name}": means[:, index] for index, name in enumerate(HEAD_NAMES)},
        "minimum_iou": minimum_iou,
        "harmed_iou_005": harmed_iou_005,
        "harmed_iou_010": harmed_iou_010,
        "harmed_bank_010": harmed_bank_010,
        "improved_open_010": improved_open_010,
        "mean_changed_iou": np.divide(
            changed_iou_sum, changed, out=np.zeros_like(changed_iou_sum), where=changed != 0
        ),
    }


def select_policy(base_cases, stress_cases, predictions):
    base_all = all_policy_results(base_cases, predictions)
    stress_all = all_policy_results(stress_cases, predictions)
    rows, best = [], None
    for index, policy in enumerate(POLICIES):
        base = {key: values[index].item() for key, values in base_all.items()}
        stress = {key: values[index].item() for key, values in stress_all.items()}
        eligible = (
            base["mean_foreground_iou"] >= 0.0
            and base["minimum_iou"] >= -0.005
            and base["harmed_iou_010"] == 0
            and stress["mean_foreground_iou"] >= -0.001
            and stress["mean_bank_retention"] >= -0.003
            and stress["harmed_iou_010"] <= max(1, int(round(0.005 * len(stress_cases))))
        )
        objective = (
            2.5 * stress["mean_open_deep_cutout_recovery"]
            + 1.5 * stress["mean_topology_structural_joint"]
            + stress["mean_foreground_iou"]
            + 0.5 * stress["mean_boundary_f1"]
            + 0.5 * base["mean_foreground_iou"]
        )
        rows.append({
            **asdict(policy), "eligible": bool(eligible), "objective": float(objective),
            **{f"base_{k}": v for k, v in base.items()},
            **{f"stress_{k}": v for k, v in stress.items()},
        })
        key = (
            int(eligible), float(objective), float(stress["mean_foreground_iou"]),
            float(base["mean_foreground_iou"]), -float(stress["changed"] + base["changed"]),
        )
        if best is None or key > best[0]:
            best = (key, policy)
    return best[1], rows


def summarize(cases, predictions, policy, seed):
    choices, values, summary = result(cases, predictions, policy)
    summary["case_count"] = len(cases)
    summary["bootstrap_95_ci"] = bootstrap_means(values, seed)
    summary["per_case"] = [
        {
            "case_id": case.case_id, "global_index": case.global_index,
            "family_code": case.family,
            "family": STRESS_FAMILIES[case.family] if case.family >= 0 else "base",
            "candidate_index": int(index), "changed": bool(index),
            **{name: float(value) for name, value in zip(HEAD_NAMES, target)},
        }
        for case, index, target in zip(cases, choices, values)
    ]
    if any(case.family >= 0 for case in cases):
        summary["per_family"] = {}
        for family, name in enumerate(STRESS_FAMILIES):
            mask = np.asarray([case.family == family for case in cases])
            family_values = values[mask]
            summary["per_family"][name] = {
                "case_count": int(mask.sum()), "changed": int(np.count_nonzero(choices[mask])),
                **{f"mean_{head}": float(family_values[:, i].mean()) for i, head in enumerate(HEAD_NAMES)},
                "minimum_iou": float(family_values[:, 0].min()),
                "bootstrap_95_ci": bootstrap_means(family_values, seed + family + 100),
            }
    return summary


def main() -> None:
    args = parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    train_cases = (
        load_cases(args.base_cache, "base_train", "base", args.include_physics, args.candidate_mode)
        + load_cases(args.stress_cache, "stress_train", "stress", args.include_physics, args.candidate_mode)
    )
    base_validation = load_cases(
        args.base_cache, "base_validation", "base", args.include_physics, args.candidate_mode
    )
    stress_validation = load_cases(
        args.stress_cache, "stress_validation", "stress", args.include_physics, args.candidate_mode
    )
    norm = normalization(train_cases)
    models, histories = [], {}
    for member in range(args.ensemble_size):
        seed = args.seed + member
        model, history = train_model(seed, train_cases, norm, args, device)
        models.append(model)
        histories[str(seed)] = history
    validation_predictions = predict_cases(models, base_validation + stress_validation, norm, device)
    policy, calibration = select_policy(base_validation, stress_validation, validation_predictions)

    checkpoint = {
        "models": [model.state_dict() for model in models],
        "feature_mean": norm[0], "feature_scale": norm[1],
        "target_mean": norm[2], "target_scale": norm[3],
        "head_names": HEAD_NAMES, "class_names": CLASS_NAMES,
        "include_physics": args.include_physics,
        "policy": asdict(policy),
        "args": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
    }
    torch.save(checkpoint, output / "synthetic_bay_risk_ranker.pt")
    (output / "history.json").write_text(json.dumps(histories, indent=2), encoding="utf-8")
    (output / "calibration.json").write_text(json.dumps(calibration, indent=2), encoding="utf-8")
    if args.validation_only:
        validation_summary = {
            "method": "synthetic-only risk-gated within-case bay ranker ensemble",
            "status": "validation-only; test labels were not opened",
            "public_cases_used_for_training_or_policy_selection": False,
            "feature_mode": "physics_and_topology_150" if args.include_physics else "topology_only_137",
            "candidate_mode": args.candidate_mode,
            "training_cases": len(train_cases),
            "validation_cases": {"base": len(base_validation), "stress": len(stress_validation)},
            "selected_policy": asdict(policy),
            "device": str(device),
        }
        (output / "summary.json").write_text(
            json.dumps(validation_summary, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        print(json.dumps(validation_summary, ensure_ascii=False, indent=2), flush=True)
        return

    # The test labels remain unopened until all weights and policy thresholds are frozen.
    base_test = load_cases(
        args.base_cache, "base_test", "base", args.include_physics, args.candidate_mode
    )
    stress_test = load_cases(
        args.stress_cache, "stress_test", "stress", args.include_physics, args.candidate_mode
    )
    test_predictions = predict_cases(models, base_test + stress_test, norm, device)
    test_summary = {
        "base": summarize(base_test, test_predictions, policy, args.seed + 5000),
        "stress": summarize(stress_test, test_predictions, policy, args.seed + 6000),
    }
    summary = {
        "method": "synthetic-only risk-gated within-case bay ranker ensemble",
        "public_cases_used_for_training_or_policy_selection": False,
        "feature_mode": "physics_and_topology_150" if args.include_physics else "topology_only_137",
        "candidate_mode": args.candidate_mode,
        "training_cases": len(train_cases),
        "validation_cases": {"base": len(base_validation), "stress": len(stress_validation)},
        "test_cases": {"base": len(base_test), "stress": len(stress_test)},
        "selected_policy": asdict(policy), "test": test_summary, "device": str(device),
    }
    (output / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({
        "selected_policy": asdict(policy),
        "base_test": {k: v for k, v in test_summary["base"].items() if k not in ("per_case",)},
        "stress_test": {k: v for k, v in test_summary["stress"].items() if k not in ("per_case", "per_family")},
    }, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
