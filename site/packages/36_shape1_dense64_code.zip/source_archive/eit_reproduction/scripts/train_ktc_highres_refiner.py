"""Train a 128-pixel coarse-to-fine refiner for inward EIT boundaries.

The 64-pixel EIT reconstruction network is frozen. Its continuous logits and
the normalized linear reconstruction are upsampled, while this network learns
only a gated high-resolution residual and signed-distance correction. Model
selection uses the synthetic validation split; KTC evaluation truths are not
read until the checkpoint and synthetic test results are fixed.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import scipy.io as sio
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
from PIL import Image

from train_ktc_concavity_network import (
    DecoderStage,
    InputAdapter,
    ResidualBlock,
    aggregate_rows,
    confusion_metrics,
    save_focus_montage,
    save_real_montage,
    save_training_curves,
    soft_dice_loss,
    write_rows,
)
from train_ktc_concavity_network_v2 import (
    ConcavityNetV2,
    ModelSpec,
    evaluate_real_predictions,
    gradients,
    normalized_masked_mean,
    selection_score,
    set_seed,
)
from train_ktc_topology_refiner import balanced_binary_loss, binary_band


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--geometry", type=Path, default=root / "datasets" / "ktc_shape_geometry_128_v1.npz")
    parser.add_argument("--coarse-checkpoint", nargs="+", type=Path, required=True)
    parser.add_argument(
        "--coarse-weights",
        nargs="+",
        type=float,
        help="Fixed log-probability fusion weights; defaults to equal weights.",
    )
    parser.add_argument("--output-dir", type=Path, default=root / "outputs" / "ktc_highres_refiner")
    parser.add_argument("--official-repo", type=Path, default=root / "external" / "KTC2023-ABC2")
    parser.add_argument("--epochs", type=int, default=48)
    parser.add_argument("--patience", type=int, default=11)
    parser.add_argument("--batch-size", type=int, default=12)
    parser.add_argument("--base-channels", type=int, default=20)
    parser.add_argument("--learning-rate", type=float, default=1.2e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--seed", type=int, default=20260819)
    parser.add_argument("--calibration-weight", type=float, default=0.08)
    parser.add_argument("--boundary-weight", type=float, default=0.45)
    parser.add_argument("--boundary-ce-weight", type=float, default=0.30)
    parser.add_argument("--sdf-weight", type=float, default=0.40)
    parser.add_argument("--sdf-gradient-weight", type=float, default=0.15)
    parser.add_argument("--indent-weight", type=float, default=0.42)
    parser.add_argument("--aux-boundary-weight", type=float, default=0.12)
    parser.add_argument("--aux-notch-weight", type=float, default=0.10)
    parser.add_argument("--gate-weight", type=float, default=0.08)
    parser.add_argument("--identity-weight", type=float, default=0.22)
    parser.add_argument("--residual-weight", type=float, default=0.025)
    parser.add_argument("--iou-tolerance", type=float, default=0.004)
    parser.add_argument("--boundary-tolerance", type=float, default=0.008)
    return parser.parse_args()


class HighResolutionDataset(Dataset):
    def __init__(
        self,
        archive: np.lib.npyio.NpzFile,
        geometry: np.lib.npyio.NpzFile,
        indices: np.ndarray,
    ) -> None:
        self.linear = archive["linear_images"]
        self.voltage = archive["voltages"]
        self.labels = geometry["labels"]
        self.sdf = geometry["signed_distance"]
        self.indent = geometry["indentation_masks"]
        self.indices = np.asarray(indices, dtype=np.int64)

    def __len__(self) -> int:
        return int(self.indices.size)

    def __getitem__(self, item: int) -> dict[str, torch.Tensor]:
        index = int(self.indices[item])
        return {
            "image": torch.from_numpy(np.asarray(self.linear[index], dtype=np.float32)[None]),
            "input_voltage": torch.from_numpy(np.asarray(self.voltage[index], dtype=np.float32)),
            "labels": torch.from_numpy(np.asarray(self.labels[index], dtype=np.int64)),
            "sdf": torch.from_numpy(np.asarray(self.sdf[index], dtype=np.float32)[None]),
            "indent": torch.from_numpy(np.asarray(self.indent[index], dtype=np.float32)[None]),
            "index": torch.tensor(index, dtype=torch.int64),
        }


class HighResolutionCalibrationDataset(Dataset):
    def __init__(self, archive: np.lib.npyio.NpzFile, geometry: np.lib.npyio.NpzFile) -> None:
        self.linear = archive["calibration_linear_images"]
        self.voltage = archive["calibration_voltages"]
        self.labels = geometry["calibration_labels_high"]
        self.sdf = geometry["calibration_signed_distance_high"]
        self.indent = geometry["calibration_indentation_masks_high"]

    def __len__(self) -> int:
        return int(len(self.labels))

    def __getitem__(self, index: int) -> dict[str, torch.Tensor]:
        return {
            "image": torch.from_numpy(np.asarray(self.linear[index], dtype=np.float32)[None]),
            "input_voltage": torch.from_numpy(np.asarray(self.voltage[index], dtype=np.float32)),
            "labels": torch.from_numpy(np.asarray(self.labels[index], dtype=np.int64)),
            "sdf": torch.from_numpy(np.asarray(self.sdf[index], dtype=np.float32)[None]),
            "indent": torch.from_numpy(np.asarray(self.indent[index], dtype=np.float32)[None]),
            "index": torch.tensor(index, dtype=torch.int64),
        }


class FrozenCoarseEnsemble(nn.Module):
    """Expose one or more frozen coarse models as a single log-probability model."""

    def __init__(self, models: list[ConcavityNetV2], weights: list[float]) -> None:
        super().__init__()
        if len(models) != len(weights) or not models:
            raise ValueError("coarse models and weights must have the same non-zero length")
        weight = torch.tensor(weights, dtype=torch.float32)
        if (weight < 0).any() or float(weight.sum()) <= 0:
            raise ValueError("coarse weights must be non-negative with a positive sum")
        self.models = nn.ModuleList(models)
        self.register_buffer("weights", weight / weight.sum())
        self.requires_grad_(False)
        self.eval()

    def train(self, mode: bool = True) -> "FrozenCoarseEnsemble":
        # The refiner training loop must never enable dropout in frozen models.
        super().train(False)
        return self

    def forward(self, image: torch.Tensor, voltage: torch.Tensor) -> dict[str, torch.Tensor]:
        log_probabilities = [
            F.log_softmax(model(image, voltage)["logits"], dim=1) for model in self.models
        ]
        fused = sum(weight * value for weight, value in zip(self.weights, log_probabilities))
        return {"logits": fused}


def load_coarse_ensemble(
    paths: list[Path],
    weights: list[float] | None,
    device: torch.device,
) -> tuple[FrozenCoarseEnsemble, list[dict[str, object]], list[float]]:
    states: list[dict[str, object]] = []
    models: list[ConcavityNetV2] = []
    for path in paths:
        state = torch.load(path.resolve(), map_location=device, weights_only=False)
        spec = ModelSpec(**state["spec"])
        model = ConcavityNetV2(int(state["base_channels"]), spec).to(device)
        model.load_state_dict(state["model"])
        model.eval()
        model.requires_grad_(False)
        states.append(state)
        models.append(model)
    selected_weights = list(weights) if weights is not None else [1.0 / len(models)] * len(models)
    if len(selected_weights) != len(models):
        raise ValueError("--coarse-weights must contain one value per --coarse-checkpoint")
    total = float(sum(selected_weights))
    selected_weights = [float(value / total) for value in selected_weights]
    return FrozenCoarseEnsemble(models, selected_weights).to(device), states, selected_weights


class HighResolutionRefiner(nn.Module):
    """Predict a local class-logit correction and a continuous level set."""

    def __init__(self, base: int) -> None:
        super().__init__()
        self.stem = ResidualBlock(8, base)
        self.enc1 = ResidualBlock(base, base * 2)
        self.enc2 = ResidualBlock(base * 2, base * 4)
        self.enc3 = ResidualBlock(base * 4, base * 8)
        self.bottleneck = nn.Sequential(
            ResidualBlock(base * 8, base * 12),
            nn.Dropout2d(0.10),
            ResidualBlock(base * 12, base * 12),
        )
        self.dec3 = DecoderStage(base * 12, base * 8, base * 8)
        self.dec2 = DecoderStage(base * 8, base * 4, base * 4)
        self.dec1 = DecoderStage(base * 4, base * 2, base * 2)
        self.dec0 = DecoderStage(base * 2, base, base)
        self.residual_head = nn.Conv2d(base, 3, 1)
        self.gate_head = nn.Conv2d(base, 1, 1)
        self.sdf_head = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))
        self.boundary_head = nn.Conv2d(base, 1, 1)
        self.notch_head = nn.Conv2d(base, 1, 1)
        self.geometry_gain = nn.Parameter(torch.tensor(0.0))
        nn.init.zeros_(self.residual_head.weight)
        nn.init.zeros_(self.residual_head.bias)
        nn.init.zeros_(self.gate_head.weight)
        nn.init.constant_(self.gate_head.bias, -2.0)
        nn.init.zeros_(self.sdf_head[-1].weight)
        nn.init.zeros_(self.sdf_head[-1].bias)

    def forward(self, image: torch.Tensor, coarse_probability: torch.Tensor) -> dict[str, torch.Tensor]:
        entropy = -(coarse_probability * torch.log(coarse_probability.clamp_min(1e-7))).sum(dim=1, keepdim=True)
        entropy = entropy / math.log(coarse_probability.shape[1])
        coarse_foreground = coarse_probability[:, 1:].sum(dim=1, keepdim=True)
        dy, dx = gradients(coarse_foreground)
        edge = torch.zeros_like(coarse_foreground)
        edge[:, :, 1:, :] += dy.abs()
        edge[:, :, :, 1:] += dx.abs()
        x = torch.cat((image, coarse_probability, entropy, edge.clamp(0.0, 1.0)), dim=1)
        e0 = self.stem(x)
        e1 = self.enc1(F.max_pool2d(e0, 2))
        e2 = self.enc2(F.max_pool2d(e1, 2))
        e3 = self.enc3(F.max_pool2d(e2, 2))
        x = self.bottleneck(F.max_pool2d(e3, 2))
        x = self.dec3(x, e3)
        x = self.dec2(x, e2)
        x = self.dec1(x, e1)
        features = self.dec0(x, e0)

        residual = 1.75 * torch.tanh(self.residual_head(features))
        gate_logits = self.gate_head(features)
        gate = torch.sigmoid(gate_logits)
        sdf = torch.tanh(self.sdf_head(features))
        geometry = torch.cat((-sdf, 0.5 * sdf, 0.5 * sdf), dim=1)
        correction = residual + self.geometry_gain.clamp(0.0, 2.0) * geometry
        logits = torch.log(coarse_probability.clamp_min(1e-7)) + gate * correction
        return {
            "logits": logits,
            "residual": residual,
            "gate": gate,
            "gate_logits": gate_logits,
            "sdf": sdf,
            "boundary_logits": self.boundary_head(features),
            "notch_logits": self.notch_head(features),
        }


def make_context(
    coarse: nn.Module,
    adapter: InputAdapter,
    image64: torch.Tensor,
    voltage: torch.Tensor,
    target_size: tuple[int, int],
) -> tuple[torch.Tensor, torch.Tensor]:
    adapted64 = adapter(image64)
    coarse_logits64 = coarse(adapted64, voltage)["logits"]
    image_high = F.interpolate(adapted64, size=target_size, mode="bilinear", align_corners=False)
    coarse_logits_high = F.interpolate(coarse_logits64, size=target_size, mode="bilinear", align_corners=False)
    return image_high, torch.softmax(coarse_logits_high, dim=1)


def highres_loss(
    outputs: dict[str, torch.Tensor],
    batch: dict[str, torch.Tensor],
    reference_probability: torch.Tensor,
    class_weights: torch.Tensor,
    args: argparse.Namespace,
    ramp: float,
) -> tuple[torch.Tensor, dict[str, float]]:
    labels = batch["labels"]
    logits = outputs["logits"]
    probability = torch.softmax(logits, dim=1)
    foreground = probability[:, 1:].sum(dim=1, keepdim=True)
    target_foreground = (labels != 0).float().unsqueeze(1)

    ce_map = F.cross_entropy(logits, labels, weight=class_weights, reduction="none").unsqueeze(1)
    ce = ce_map.mean()
    dice = soft_dice_loss(logits, labels)
    target_boundary = binary_band(target_foreground)
    boundary_neighborhood = F.max_pool2d(target_boundary, 9, stride=1, padding=4)
    boundary_ce = normalized_masked_mean(ce_map, boundary_neighborhood)

    pred_dy, pred_dx = gradients(foreground)
    true_dy, true_dx = gradients(target_foreground)
    boundary = F.l1_loss(pred_dy, true_dy) + F.l1_loss(pred_dx, true_dx)
    sdf = F.smooth_l1_loss(outputs["sdf"], batch["sdf"], beta=0.05)
    sdf_dy, sdf_dx = gradients(outputs["sdf"])
    true_sdf_dy, true_sdf_dx = gradients(batch["sdf"])
    sdf_gradient = F.smooth_l1_loss(sdf_dy, true_sdf_dy, beta=0.03) + F.smooth_l1_loss(sdf_dx, true_sdf_dx, beta=0.03)

    indentation = batch["indent"]
    notch_rim = indentation * F.max_pool2d(target_foreground, 21, stride=1, padding=10)
    concave_inside = target_foreground * F.max_pool2d(indentation, 21, stride=1, padding=10)
    false_fill = normalized_masked_mean(foreground, notch_rim)
    false_cut = normalized_masked_mean(1.0 - foreground, concave_inside)
    indent = 0.5 * (false_fill + false_cut)

    auxiliary_boundary = balanced_binary_loss(outputs["boundary_logits"], target_boundary)
    auxiliary_notch = balanced_binary_loss(outputs["notch_logits"], indentation)
    reference_prediction = reference_probability.argmax(dim=1, keepdim=True)
    correction_target = (reference_prediction != labels.unsqueeze(1)).float()
    correction_target = F.max_pool2d(correction_target, 9, stride=1, padding=4)
    gate = balanced_binary_loss(outputs["gate_logits"], correction_target)

    confidence = reference_probability.max(dim=1, keepdim=True).values
    stable = ((reference_prediction == labels.unsqueeze(1)) & (confidence > 0.82) & (correction_target == 0)).float()
    probability_change = (probability - reference_probability).abs().sum(dim=1, keepdim=True)
    identity = normalized_masked_mean(probability_change, stable)
    residual = (outputs["gate"] * outputs["residual"].abs().mean(dim=1, keepdim=True)).mean()

    total = ce + dice + ramp * (
        args.boundary_weight * boundary
        + args.boundary_ce_weight * boundary_ce
        + args.sdf_weight * sdf
        + args.sdf_gradient_weight * sdf_gradient
        + args.indent_weight * indent
        + args.aux_boundary_weight * auxiliary_boundary
        + args.aux_notch_weight * auxiliary_notch
        + args.gate_weight * gate
        + args.identity_weight * identity
        + args.residual_weight * residual
    )
    pieces = {
        "ce": ce, "dice": dice, "boundary": boundary, "boundary_ce": boundary_ce,
        "sdf": sdf, "sdf_gradient": sdf_gradient, "indent": indent, "gate": gate,
        "identity": identity, "residual": residual, "total": total,
    }
    return total, {key: float(value.detach()) for key, value in pieces.items()}


@torch.no_grad()
def evaluate_loader(
    coarse: nn.Module,
    refiner: HighResolutionRefiner,
    adapter: InputAdapter,
    loader: DataLoader,
    device: torch.device,
) -> tuple[dict[str, float], dict[str, float], dict[int, np.ndarray], dict[int, np.ndarray]]:
    coarse.eval()
    refiner.eval()
    coarse_rows: list[dict[str, float]] = []
    refined_rows: list[dict[str, float]] = []
    coarse_predictions: dict[int, np.ndarray] = {}
    refined_predictions: dict[int, np.ndarray] = {}
    for batch in loader:
        labels = batch["labels"]
        target_size = tuple(labels.shape[-2:])
        image_high, reference_probability = make_context(
            coarse,
            adapter,
            batch["image"].to(device),
            batch["input_voltage"].to(device),
            target_size,
        )
        refined_logits = refiner(image_high, reference_probability)["logits"]
        coarse_prediction = reference_probability.argmax(dim=1).cpu().numpy()
        refined_prediction = refined_logits.argmax(dim=1).cpu().numpy()
        truths = labels.numpy()
        indentations = batch["indent"].numpy()[:, 0]
        for offset, index in enumerate(batch["index"].numpy()):
            coarse_predictions[int(index)] = coarse_prediction[offset]
            refined_predictions[int(index)] = refined_prediction[offset]
            coarse_rows.append(confusion_metrics(truths[offset], coarse_prediction[offset], indentations[offset]))
            refined_rows.append(confusion_metrics(truths[offset], refined_prediction[offset], indentations[offset]))
    return aggregate_rows(coarse_rows), aggregate_rows(refined_rows), coarse_predictions, refined_predictions


def train_model(
    archive: np.lib.npyio.NpzFile,
    geometry: np.lib.npyio.NpzFile,
    coarse: nn.Module,
    adapter: InputAdapter,
    args: argparse.Namespace,
    output_dir: Path,
    device: torch.device,
) -> tuple[HighResolutionRefiner, list[dict[str, float]], dict[str, float], dict[str, float]]:
    train_loader = DataLoader(
        HighResolutionDataset(archive, geometry, geometry["train_indices"]),
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.workers,
        pin_memory=device.type == "cuda",
        drop_last=True,
    )
    validation_loader = DataLoader(
        HighResolutionDataset(archive, geometry, geometry["validation_indices"]),
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.workers,
        pin_memory=device.type == "cuda",
    )
    calibration_loader = DataLoader(
        HighResolutionCalibrationDataset(archive, geometry), batch_size=4, shuffle=True, num_workers=0
    )
    calibration_iterator = iter(calibration_loader)
    model = HighResolutionRefiner(args.base_channels).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(1, args.epochs))
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    train_labels = geometry["labels"][geometry["train_indices"]]
    counts = np.bincount(train_labels.reshape(-1), minlength=3).astype(np.float64)
    class_weights_np = np.sqrt(counts.sum() / np.maximum(counts, 1.0))
    class_weights_np /= class_weights_np.mean()
    class_weights = torch.from_numpy(class_weights_np.astype(np.float32)).to(device)
    checkpoint = output_dir / "highres_refiner_best.pt"
    history: list[dict[str, float]] = []
    best_score = -math.inf
    stale = 0
    selected_reference: dict[str, float] = {}
    selected_metrics: dict[str, float] = {}

    for epoch in range(1, args.epochs + 1):
        model.train()
        losses: list[float] = []
        ramp = min(1.0, max(0.0, (epoch - 2) / 8.0))
        for batch in train_loader:
            batch = {key: value.to(device, non_blocking=True) for key, value in batch.items()}
            optimizer.zero_grad(set_to_none=True)
            with torch.no_grad():
                image_high, reference_probability = make_context(
                    coarse, adapter, batch["image"], batch["input_voltage"], tuple(batch["labels"].shape[-2:])
                )
            with torch.amp.autocast("cuda", enabled=device.type == "cuda"):
                outputs = model(image_high, reference_probability)
                loss, _ = highres_loss(outputs, batch, reference_probability, class_weights, args, ramp)
                try:
                    calibration_batch = next(calibration_iterator)
                except StopIteration:
                    calibration_iterator = iter(calibration_loader)
                    calibration_batch = next(calibration_iterator)
                calibration_batch = {key: value.to(device, non_blocking=True) for key, value in calibration_batch.items()}
                with torch.no_grad():
                    calibration_image, calibration_reference = make_context(
                        coarse,
                        adapter,
                        calibration_batch["image"],
                        calibration_batch["input_voltage"],
                        tuple(calibration_batch["labels"].shape[-2:]),
                    )
                calibration_outputs = model(calibration_image, calibration_reference)
                calibration_loss, _ = highres_loss(
                    calibration_outputs, calibration_batch, calibration_reference, class_weights, args, ramp
                )
                loss = loss + args.calibration_weight * calibration_loss
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            scaler.step(optimizer)
            scaler.update()
            losses.append(float(loss.detach()))
        scheduler.step()

        reference, refined, _, _ = evaluate_loader(coarse, model, adapter, validation_loader, device)
        eligible = (
            refined["foreground_iou"] >= reference["foreground_iou"] - args.iou_tolerance
            and refined["boundary_f1"] >= reference["boundary_f1"] - args.boundary_tolerance
        )
        score = selection_score(refined) if eligible else -math.inf
        row = {
            "epoch": float(epoch),
            "train_loss": float(np.mean(losses)),
            "learning_rate": float(optimizer.param_groups[0]["lr"]),
            "eligible": float(eligible),
            "selection_score": float(score),
            **{f"validation_{key}": value for key, value in refined.items()},
        }
        history.append(row)
        print(
            f"highres epoch {epoch}/{args.epochs}: loss={row['train_loss']:.4f}, "
            f"IoU={refined['foreground_iou']:.4f}, boundary={refined['boundary_f1']:.4f}, "
            f"notch={refined['notch_preservation']:.4f}, joint={refined['concavity_score']:.4f}, "
            f"eligible={eligible}",
            flush=True,
        )
        if eligible and score > best_score + 1e-5:
            best_score = score
            stale = 0
            selected_reference = reference
            selected_metrics = refined
            torch.save(
                {
                    "model": model.state_dict(),
                    "base_channels": args.base_channels,
                    "epoch": epoch,
                    "selection_score": score,
                    "coarse_checkpoints": [str(path.resolve()) for path in args.coarse_checkpoint],
                    "coarse_weights": args.coarse_weights,
                    "class_weights": class_weights_np.tolist(),
                    "target_resolution": int(geometry["labels"].shape[-1]),
                },
                checkpoint,
            )
        else:
            stale += 1
        if stale >= args.patience and checkpoint.exists():
            print(f"highres: early stopping after {epoch} epochs", flush=True)
            break

    if not checkpoint.exists():
        raise RuntimeError("No high-resolution checkpoint satisfied the validation region/boundary constraints")
    state = torch.load(checkpoint, map_location=device, weights_only=False)
    model.load_state_dict(state["model"])
    (output_dir / "training_history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    return model, history, selected_reference, selected_metrics


@torch.no_grad()
def infer_real(
    coarse: nn.Module,
    refiner: HighResolutionRefiner,
    adapter: InputAdapter,
    images: np.ndarray,
    voltages: np.ndarray,
    target_resolution: int,
    device: torch.device,
    batch_size: int,
) -> tuple[np.ndarray, np.ndarray]:
    coarse_predictions: list[np.ndarray] = []
    refined_predictions: list[np.ndarray] = []
    for start in range(0, len(images), batch_size):
        image = torch.from_numpy(images[start:start + batch_size, None].astype(np.float32)).to(device)
        voltage = torch.from_numpy(voltages[start:start + batch_size].astype(np.float32)).to(device)
        adapted64 = adapter(image)
        coarse_logits64 = coarse(adapted64, voltage)["logits"]
        image_high = F.interpolate(adapted64, size=(target_resolution, target_resolution), mode="bilinear", align_corners=False)
        probability_high = torch.softmax(
            F.interpolate(coarse_logits64, size=(target_resolution, target_resolution), mode="bilinear", align_corners=False),
            dim=1,
        )
        refined_logits = refiner(image_high, probability_high)["logits"]
        coarse_logits256 = F.interpolate(coarse_logits64, size=(256, 256), mode="bilinear", align_corners=False)
        refined_logits256 = F.interpolate(refined_logits, size=(256, 256), mode="bilinear", align_corners=False)
        coarse_predictions.append(coarse_logits256.argmax(dim=1).cpu().numpy())
        refined_predictions.append(refined_logits256.argmax(dim=1).cpu().numpy())
    return np.concatenate(coarse_predictions), np.concatenate(refined_predictions)


def save_synthetic_examples(
    path: Path,
    truths: np.ndarray,
    indentations: np.ndarray,
    indices: np.ndarray,
    coarse_predictions: dict[int, np.ndarray],
    refined_predictions: dict[int, np.ndarray],
) -> None:
    ranked = sorted((int(index) for index in indices), key=lambda index: int(indentations[index].sum()), reverse=True)[:8]
    figure, axes = plt.subplots(len(ranked), 3, figsize=(7.2, 2.25 * len(ranked)), squeeze=False)
    for row, index in enumerate(ranked):
        images = (truths[index], coarse_predictions[index], refined_predictions[index])
        titles = (f"truth {index}", "coarse 64->128", "high-resolution refiner")
        for column, (image, title) in enumerate(zip(images, titles)):
            axes[row, column].imshow(image, vmin=0, vmax=2, cmap="viridis", interpolation="nearest")
            axes[row, column].set_title(title, fontsize=9)
            axes[row, column].set_axis_off()
    figure.suptitle("Most concave untouched synthetic test cases", fontsize=13)
    figure.tight_layout()
    figure.savefig(path, dpi=170)
    plt.close(figure)


def load_official_four_case_truths(repo: Path) -> tuple[np.ndarray, np.ndarray]:
    truths = [
        sio.loadmat(repo / "groundTruths" / f"true{sample}.mat")["truth"].astype(np.uint8)
        for sample in range(1, 5)
    ]
    return np.stack(truths), np.asarray([f"data{sample}" for sample in range(1, 5)])


def load_dip_four_case_predictions(root: Path) -> np.ndarray:
    paths = (
        root / "outputs" / "ktc2023_abc2_3000_data1" / "data1.png",
        root / "outputs" / "ktc2023_abc2_3000_data2" / "data2.png",
        root / "outputs" / "ktc2023_abc2_3000_data3_data4" / "data3.png",
        root / "outputs" / "ktc2023_abc2_3000_data3_data4" / "data4.png",
    )
    predictions = []
    for path in paths:
        grayscale = np.asarray(Image.open(path).convert("L"), dtype=np.uint8)
        labels = np.zeros_like(grayscale, dtype=np.uint8)
        labels[(grayscale >= 64) & (grayscale < 192)] = 1
        labels[grayscale >= 192] = 2
        predictions.append(labels)
    return np.stack(predictions)


def save_official_four_case_comparison(
    path: Path,
    truths: np.ndarray,
    ids: np.ndarray,
    predictions: dict[str, np.ndarray],
    rows: list[dict[str, object]],
) -> None:
    lookup = {(str(row["id"]), str(row["method"])): row for row in rows}
    methods = list(predictions)
    figure, axes = plt.subplots(len(ids), len(methods) + 1, figsize=(3.1 * (len(methods) + 1), 11.2), squeeze=False)
    for row, (truth, case_id) in enumerate(zip(truths, ids)):
        axes[row, 0].imshow(truth, vmin=0, vmax=2, cmap="gray", interpolation="nearest")
        axes[row, 0].set_title(f"{case_id}: truth")
        for column, method in enumerate(methods, start=1):
            metric = lookup[(str(case_id), method)]
            axes[row, column].imshow(predictions[method][row], vmin=0, vmax=2, cmap="gray", interpolation="nearest")
            axes[row, column].set_title(
                f"{method}\nIoU={float(metric['foreground_iou']):.3f}, "
                f"B-F1={float(metric['boundary_f1']):.3f}"
            )
        for axis in axes[row]:
            axis.set_axis_off()
    figure.suptitle("Original four KTC2023-ABC2 cases: DIP+TV versus external-connected support/cutout model", fontsize=14)
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    archive = np.load(args.dataset.resolve(), allow_pickle=False)
    geometry = np.load(args.geometry.resolve(), allow_pickle=False)
    for split in ("train_indices", "validation_indices", "test_indices"):
        if not np.array_equal(archive[split], geometry[split]):
            raise RuntimeError(f"high-resolution geometry has a different {split}")
    if archive["labels"].shape[0] != geometry["labels"].shape[0]:
        raise RuntimeError("base archive and high-resolution geometry have different sample counts")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    coarse, coarse_states, coarse_weights = load_coarse_ensemble(
        args.coarse_checkpoint, args.coarse_weights, device
    )
    adapter = InputAdapter(archive["fov_mask"]).to(device)
    target_resolution = int(geometry["labels"].shape[-1])
    print(
        f"device={device}; seed={args.seed}; frozen coarse={args.coarse_checkpoint}; "
        f"weights={coarse_weights}; "
        f"target={target_resolution}x{target_resolution}",
        flush=True,
    )
    model, history, validation_reference, validation_selected = train_model(
        archive, geometry, coarse, adapter, args, output_dir, device
    )

    test_loader = DataLoader(
        HighResolutionDataset(archive, geometry, geometry["test_indices"]),
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.workers,
    )
    test_reference, test_refined, coarse_test, refined_test = evaluate_loader(
        coarse, model, adapter, test_loader, device
    )
    print(f"synthetic untouched test coarse: {test_reference}", flush=True)
    print(f"synthetic untouched test highres: {test_refined}", flush=True)
    save_synthetic_examples(
        output_dir / "synthetic_most_concave_test.png",
        geometry["labels"],
        geometry["indentation_masks"],
        geometry["test_indices"],
        coarse_test,
        refined_test,
    )

    # Evaluation truth is first touched after validation selection and the
    # independent synthetic test evaluation have completed.
    real_coarse, real_refined = infer_real(
        coarse,
        model,
        adapter,
        archive["real_linear_images"],
        archive["real_voltages"],
        target_resolution,
        device,
        args.batch_size,
    )
    real_truths = archive["real_labels"]
    real_ids = archive["real_ids"]
    real_predictions = {"coarse_boundary": real_coarse, "highres_refiner": real_refined}
    real_summary: dict[str, dict[str, float]] = {}
    real_rows: list[dict[str, object]] = []
    for name, predictions in real_predictions.items():
        real_summary[name], rows = evaluate_real_predictions(name, predictions, real_truths, real_ids)
        real_rows.extend(rows)
        print(f"real evaluation {name}: {real_summary[name]}", flush=True)
    write_rows(output_dir / "real_case_metrics.csv", real_rows)
    save_real_montage(output_dir / "real_all_21_comparison.png", real_truths, real_ids, real_predictions, real_rows)
    save_focus_montage(output_dir / "real_most_concave_comparison.png", real_truths, real_ids, real_predictions, real_rows)
    save_training_curves(output_dir / "training_curves.png", {"highres_refiner": history})
    np.savez_compressed(
        output_dir / "real_predictions.npz",
        ids=real_ids,
        truth=real_truths,
        coarse_boundary=real_coarse,
        highres_refiner=real_refined,
    )

    # The four official examples are calibration/training examples, not an
    # independent test. They are reported separately because data4 is the
    # motivating inward-corner failure of DIP+TV.
    official_truths, official_ids = load_official_four_case_truths(args.official_repo.resolve())
    official_coarse, official_refined = infer_real(
        coarse,
        model,
        adapter,
        archive["calibration_linear_images"],
        archive["calibration_voltages"],
        target_resolution,
        device,
        args.batch_size,
    )
    official_predictions = {
        "DIP+TV": load_dip_four_case_predictions(Path(__file__).resolve().parents[1]),
        "coarse_fusion": official_coarse,
        "highres_refiner": official_refined,
    }
    official_summary: dict[str, dict[str, float]] = {}
    official_rows: list[dict[str, object]] = []
    for name, predictions in official_predictions.items():
        official_summary[name], rows = evaluate_real_predictions(
            name, predictions, official_truths, official_ids
        )
        official_rows.extend(rows)
        print(f"official four calibration cases {name}: {official_summary[name]}", flush=True)
    write_rows(output_dir / "official_four_case_metrics.csv", official_rows)
    save_official_four_case_comparison(
        output_dir / "official_four_case_comparison.png",
        official_truths,
        official_ids,
        official_predictions,
        official_rows,
    )
    np.savez_compressed(
        output_dir / "official_four_case_predictions.npz",
        ids=official_ids,
        truth=official_truths,
        **official_predictions,
    )

    result = {
        "dataset": str(args.dataset.resolve()),
        "geometry": str(args.geometry.resolve()),
        "coarse_checkpoints": [str(path.resolve()) for path in args.coarse_checkpoint],
        "coarse_weights": coarse_weights,
        "coarse_epochs": [int(state.get("epoch", -1)) for state in coarse_states],
        "output_dir": str(output_dir),
        "device": str(device),
        "seed": args.seed,
        "target_resolution": target_resolution,
        "validation_reference": validation_reference,
        "validation_selected": validation_selected,
        "synthetic_untouched_test": {"coarse_boundary": test_reference, "highres_refiner": test_refined},
        "real_evaluation": real_summary,
        "official_four_calibration_cases": official_summary,
        "official_four_are_training_calibration_not_independent_test": True,
        "evaluation_truth_used_for_training_or_selection": False,
        "selection_rule": "validation-only 0.55 IoU + 0.20 boundary F1 + 0.25 joint concavity with IoU/boundary floors",
        "args": vars(args) | {
            "dataset": str(args.dataset),
            "geometry": str(args.geometry),
            "coarse_checkpoint": [str(path) for path in args.coarse_checkpoint],
            "output_dir": str(args.output_dir),
            "official_repo": str(args.official_repo),
        },
    }
    (output_dir / "summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
