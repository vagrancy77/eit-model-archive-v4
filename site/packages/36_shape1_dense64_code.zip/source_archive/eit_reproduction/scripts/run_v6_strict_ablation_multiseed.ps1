$ErrorActionPreference = "Stop"

$python = "E:\Anaconda\envs\myenv\python.exe"
$root = "E:\Codex"
$trainScript = Join-Path $root "eit_reproduction\scripts\train_local_topology_corrector_v6.py"

$runs = @(
    @{
        Seed = 20260911
        Checkpoint = "topology_risk_eit_v4_full\topology_residual_v4_best.pt"
        Router = "topology_risk_eit_v4_router_seed_20260911\action_router_summary.json"
    },
    @{
        Seed = 20260912
        Checkpoint = "topology_risk_eit_v4_seed_20260912\topology_residual_v4_best.pt"
        Router = "topology_risk_eit_v4_router_seed_20260912\action_router_summary.json"
    },
    @{
        Seed = 20260913
        Checkpoint = "topology_risk_eit_v4_seed_20260913\topology_residual_v4_best.pt"
        Router = "topology_risk_eit_v4_router_seed_20260913\action_router_summary.json"
    },
    @{
        Seed = 20260914
        Checkpoint = "topology_risk_eit_v4_seed_20260914\topology_residual_v4_best.pt"
        Router = "topology_risk_eit_v4_router_seed_20260914\action_router_summary.json"
    }
)

$variants = @("no_physics", "no_topology_supervision", "no_connectivity")
Set-Location $root
foreach ($variant in $variants) {
    foreach ($run in $runs) {
        $output = Join-Path $root ("topology_local_eit_v6_corrected_ablation_" + $variant + "_seed_" + $run.Seed)
        $summary = Join-Path $output "v6_summary.json"
        if (Test-Path -LiteralPath $summary) {
            Write-Host ("Skipping completed " + $variant + " seed " + $run.Seed)
            continue
        }
        $cache = Join-Path $root ("topology_local_eit_v6_seed_" + $run.Seed + "\v4_cache")
        Write-Host ("Starting " + $variant + " seed " + $run.Seed + " -> " + $output)
        & $python $trainScript `
            --checkpoint (Join-Path $root $run.Checkpoint) `
            --anchor-router (Join-Path $root $run.Router) `
            --output-dir $output `
            --cache-dir $cache `
            --seed $run.Seed `
            --variant $variant `
            --device cuda `
            --epochs 54 `
            --patience 12 `
            --batch-size 28 `
            --base-channels 24 `
            --gate-epochs 260 `
            --gate-patience 36 `
            --progress-every 2
        if ($LASTEXITCODE -ne 0) {
            throw "$variant seed $($run.Seed) failed with exit code $LASTEXITCODE"
        }
    }
}

$aggregate = Join-Path $root "eit_reproduction\scripts\aggregate_v6_strict_ablation.py"
$outputFinal = Join-Path $root "topology_local_eit_v6_corrected_strict_ablation_final"
& $python $aggregate `
    --full-runs `
        (Join-Path $root "topology_local_eit_v6_corrected_seed_20260911") `
        (Join-Path $root "topology_local_eit_v6_corrected_seed_20260912") `
        (Join-Path $root "topology_local_eit_v6_corrected_seed_20260913") `
        (Join-Path $root "topology_local_eit_v6_corrected_seed_20260914") `
    --no-physics-runs `
        (Join-Path $root "topology_local_eit_v6_corrected_ablation_no_physics_seed_20260911") `
        (Join-Path $root "topology_local_eit_v6_corrected_ablation_no_physics_seed_20260912") `
        (Join-Path $root "topology_local_eit_v6_corrected_ablation_no_physics_seed_20260913") `
        (Join-Path $root "topology_local_eit_v6_corrected_ablation_no_physics_seed_20260914") `
    --no-topology-runs `
        (Join-Path $root "topology_local_eit_v6_corrected_ablation_no_topology_supervision_seed_20260911") `
        (Join-Path $root "topology_local_eit_v6_corrected_ablation_no_topology_supervision_seed_20260912") `
        (Join-Path $root "topology_local_eit_v6_corrected_ablation_no_topology_supervision_seed_20260913") `
        (Join-Path $root "topology_local_eit_v6_corrected_ablation_no_topology_supervision_seed_20260914") `
    --no-connectivity-runs `
        (Join-Path $root "topology_local_eit_v6_corrected_ablation_no_connectivity_seed_20260911") `
        (Join-Path $root "topology_local_eit_v6_corrected_ablation_no_connectivity_seed_20260912") `
        (Join-Path $root "topology_local_eit_v6_corrected_ablation_no_connectivity_seed_20260913") `
        (Join-Path $root "topology_local_eit_v6_corrected_ablation_no_connectivity_seed_20260914") `
    --output-dir $outputFinal `
    --bootstrap 10000 `
    --seed 20261031
if ($LASTEXITCODE -ne 0) {
    throw "strict v6 ablation aggregation failed with exit code $LASTEXITCODE"
}

Write-Host "strict v6 ablation workflow completed: $outputFinal"
