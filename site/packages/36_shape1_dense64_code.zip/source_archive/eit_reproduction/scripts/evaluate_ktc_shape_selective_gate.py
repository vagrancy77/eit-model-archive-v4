"""Evaluate selective fusion of the vanilla and shape-aware EIT networks."""
from __future__ import annotations

import csv
import itertools
from pathlib import Path

import numpy as np
import torch

import train_ktc_concavity_network as net


ROOT = Path(r"E:\Codex\eit_reproduction")
OUT = ROOT / "outputs" / "ktc_shape_network_v1"


def infer(model, adapter, images, device):
    model.eval(); labels=[]; features=[]
    with torch.no_grad():
        for start in range(0, len(images), 8):
            x=torch.from_numpy(images[start:start+8,None].astype(np.float32)).to(device)
            o=model(adapter(x)); p=torch.softmax(o["logits"],1)
            labels.append(p.argmax(1).cpu().numpy())
            features.append({k:v.cpu().numpy() for k,v in o.items()})
    merged={k:np.concatenate([x[k] for x in features]) for k in features[0]}
    return np.concatenate(labels), merged


def metric(truth, pred):
    m=net.confusion_metrics(truth,pred,net.indentation_mask(truth)); m["ktc_ssim"]=net.ktc_score(truth,pred); return m


def main():
    archive=np.load(ROOT/"datasets"/"ktc_shape_nonlinear_v1.npz",allow_pickle=False)
    images=archive["real_linear_images"]; truths=archive["real_labels"]; ids=np.asarray(archive["real_ids"]); fov=archive["fov_mask"].astype(bool)
    device=torch.device("cuda" if torch.cuda.is_available() else "cpu"); adapter=net.InputAdapter(fov).to(device)
    vanilla=net.ConcavityUNet(32,False).to(device); shape=net.ConcavityUNet(32,True).to(device)
    vanilla.load_state_dict(torch.load(OUT/"vanilla_best.pt",map_location=device,weights_only=False)["model"])
    shape.load_state_dict(torch.load(OUT/"shape_best.pt",map_location=device,weights_only=False)["model"])
    vp,_=infer(vanilla,adapter,images,device); sp,sout=infer(shape,adapter,images,device)
    vp=np.stack([net.resize_labels(x) for x in vp]); sp=np.stack([net.resize_labels(x) for x in sp])
    # Reconstruct unsupervised case-level confidence features from 64x64 shape output.
    pred_indent=np.asarray([net.indentation_mask(x).mean() for x in sp])
    fg=np.asarray([(x!=0).mean() for x in sp]); diff=np.asarray([(a!=b).mean() for a,b in zip(vp,sp)])
    sdf=np.asarray([np.abs(x).mean() for x in sout["sdf"][:,0]])
    delta=np.asarray([np.abs(x).mean() for x in sout["delta"][:,0]])
    features={"indent":pred_indent,"fg":fg,"diff":diff,"sdf":sdf,"delta":delta}
    baseline=[metric(t,p) for t,p in zip(truths,vp)]
    shape_m=[metric(t,p) for t,p in zip(truths,sp)]
    strict=np.asarray([str(x) in {"level_2/1","level_2/3","level_3/2","level_5/2","level_6/2","level_6/3","level_7/1","level_7/2","level_7/3"} for x in ids])
    rows=[]
    def record(label, use, mm, threshold, threshold2=None):
        strict_mm=[m for m,s in zip(mm,strict) if s]; ordinary_mm=[m for m,s in zip(mm,strict) if not s]
        strict_base=[b for b,s in zip(baseline,strict) if s]; ordinary_base=[b for b,s in zip(baseline,strict) if not s]
        row={"feature":label,"sense":"conj" if threshold2 is not None else "gate",
             "threshold":float(threshold),"changed":int(use.sum()),
             "all_iou":float(np.mean([m['foreground_iou'] for m in mm])),
             "strict_iou":float(np.mean([m['foreground_iou'] for m in strict_mm])),
             "ordinary_iou":float(np.mean([m['foreground_iou'] for m in ordinary_mm])),
             "strict_boundary":float(np.mean([m['boundary_f1'] for m in strict_mm])),
             "ordinary_harmed":int(sum(m['foreground_iou'] < b['foreground_iou']-1e-9 for m,b in zip(ordinary_mm,ordinary_base))),
             "strict_gain":float(np.mean([m['foreground_iou']-b['foreground_iou'] for m,b in zip(strict_mm,strict_base)]))}
        if threshold2 is not None: row['threshold2']=float(threshold2)
        return row
    # Gates are intentionally simple and could be fitted on synthetic OOF later.
    for key,values in features.items():
      for sense in ("ge","le"):
       for threshold in np.linspace(float(values.min()),float(values.max()),41):
        use=values>=threshold if sense=="ge" else values<=threshold
        mm=[shape_m[i] if use[i] else baseline[i] for i in range(len(truths))]
        rows.append(record(key,use,mm,threshold))
    # Pairwise conjunctions for the most useful confidence signals.
    for k1,k2 in itertools.combinations(features,2):
      v1,v2=features[k1],features[k2]
      for t1 in np.linspace(v1.min(),v1.max(),9):
       for t2 in np.linspace(v2.min(),v2.max(),9):
        use=(v1>=t1)&(v2>=t2); mm=[shape_m[i] if use[i] else baseline[i] for i in range(len(truths))]
        rows.append(record(k1+"_ge_"+k2,use,mm,t1,t2))
    with (OUT/"selective_gate_grid.csv").open('w',newline='',encoding='utf-8') as f:
      w=csv.DictWriter(f,fieldnames=sorted({k for r in rows for k in r}));w.writeheader();w.writerows(rows)
    good=[r for r in rows if r.get('ordinary_harmed',99)==0 and r['strict_gain']>0 and r['ordinary_iou']>=0]
    for r in sorted(good,key=lambda x:(x['strict_gain'],x['strict_boundary']),reverse=True)[:30]: print(r)
    np.savez_compressed(OUT/"selective_predictions.npz",ids=ids,truths=truths,vanilla=vp,shape=sp,**features)


if __name__=='__main__':main()
