"""Combine legacy and biological KTC simulations without mixing test splits.

Only the training and validation partitions are pooled.  The original-shape
and held-out biological test indices remain named separately so every reported
result can be traced to an untouched distribution.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


SAMPLE_KEYS = (
    "labels",
    "delta",
    "indentation_masks",
    "signed_distance",
    "voltages",
    "clean_voltages",
    "linear_images",
)
STATIC_KEYS = (
    "fov_mask",
    "jacobian",
    "reconstruction_operator",
    "node_to_raw_pixel",
    "raw_pixel_to_node",
    "node_coordinates",
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--legacy",
        type=Path,
        default=root / "datasets" / "ktc_shape_nonlinear_v1.npz",
    )
    parser.add_argument(
        "--biological",
        type=Path,
        default=root / "datasets" / "ktc_biological_concavity_v1.npz",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=root / "datasets" / "ktc_joint_concavity_v1.npz",
    )
    return parser.parse_args()


def require_keys(archive: np.lib.npyio.NpzFile, keys: tuple[str, ...], label: str) -> None:
    missing = sorted(set(keys) - set(archive.files))
    if missing:
        raise KeyError(f"{label} archive is missing required arrays: {missing}")


def assert_compatible(
    legacy: np.lib.npyio.NpzFile,
    biological: np.lib.npyio.NpzFile,
) -> None:
    require_keys(legacy, SAMPLE_KEYS + STATIC_KEYS, "legacy")
    require_keys(biological, SAMPLE_KEYS + STATIC_KEYS, "biological")
    for key in STATIC_KEYS:
        left = np.asarray(legacy[key])
        right = np.asarray(biological[key])
        if left.shape != right.shape:
            raise ValueError(f"incompatible {key} shapes: {left.shape} versus {right.shape}")
        if not np.allclose(left, right, rtol=2e-5, atol=2e-6):
            maximum = float(np.max(np.abs(left.astype(np.float64) - right.astype(np.float64))))
            raise ValueError(f"incompatible {key} values (maximum absolute difference {maximum:g})")


def shifted(indices: np.ndarray, offset: int) -> np.ndarray:
    return np.asarray(indices, dtype=np.int64) + int(offset)


def main() -> None:
    args = parse_args()
    legacy_path = args.legacy.resolve()
    biological_path = args.biological.resolve()
    output = args.output.resolve()
    with np.load(legacy_path, allow_pickle=False) as legacy, np.load(
        biological_path, allow_pickle=False
    ) as biological:
        assert_compatible(legacy, biological)
        legacy_count = int(legacy["labels"].shape[0])
        biological_count = int(biological["labels"].shape[0])
        sample_arrays = {
            key: np.concatenate((np.asarray(legacy[key]), np.asarray(biological[key])), axis=0)
            for key in SAMPLE_KEYS
        }
        legacy_train = np.asarray(legacy["train_indices"], dtype=np.int64)
        legacy_validation = np.asarray(legacy["validation_indices"], dtype=np.int64)
        legacy_test = np.asarray(legacy["test_indices"], dtype=np.int64)
        biological_train = shifted(biological["train_indices"], legacy_count)
        biological_validation = shifted(biological["validation_indices"], legacy_count)
        biological_test = shifted(biological["test_indices"], legacy_count)
        train_indices = np.concatenate((legacy_train, biological_train))
        validation_indices = np.concatenate((legacy_validation, biological_validation))
        test_indices = np.concatenate((legacy_test, biological_test))

        sample_source = np.concatenate(
            (
                np.zeros(legacy_count, dtype=np.uint8),
                np.ones(biological_count, dtype=np.uint8),
            )
        )
        family_codes = np.concatenate(
            (
                np.full(legacy_count, -1, dtype=np.int16),
                np.asarray(biological["family_codes"], dtype=np.int16),
            )
        )
        indentation_pixels = sample_arrays["indentation_masks"].reshape(
            legacy_count + biological_count, -1
        ).sum(axis=1).astype(np.int32)
        sample_ids = np.asarray(
            [f"legacy/{index:04d}" for index in range(legacy_count)]
            + [f"biological/{index:04d}" for index in range(biological_count)]
        )

        copied = {
            key: np.asarray(legacy[key])
            for key in legacy.files
            if key.startswith("real_") or key.startswith("calibration_")
        }
        output.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(
            output,
            **sample_arrays,
            **{key: np.asarray(legacy[key]) for key in STATIC_KEYS},
            train_indices=train_indices,
            validation_indices=validation_indices,
            test_indices=test_indices,
            legacy_train_indices=legacy_train,
            legacy_validation_indices=legacy_validation,
            legacy_test_indices=legacy_test,
            biological_train_indices=biological_train,
            biological_validation_indices=biological_validation,
            biological_test_indices=biological_test,
            sample_source=sample_source,
            family_codes=family_codes,
            indentation_pixels=indentation_pixels,
            sample_ids=sample_ids,
            **copied,
        )

    summary = {
        "output": str(output),
        "legacy_dataset": str(legacy_path),
        "biological_dataset": str(biological_path),
        "samples": legacy_count + biological_count,
        "source_codes": {"legacy": 0, "biological": 1},
        "splits": {
            "train": int(train_indices.size),
            "validation": int(validation_indices.size),
            "combined_test": int(test_indices.size),
            "legacy_test": int(legacy_test.size),
            "biological_held_out_test": int(biological_test.size),
        },
        "test_partitions_used_for_training_or_selection": False,
        "ktc_evaluation_truth_used_for_training_or_selection": False,
    }
    output.with_suffix(".json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
