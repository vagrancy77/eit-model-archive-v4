"""Compare every retained non-convex EIT method on identical frozen tests.

This script does not tune a threshold or train a model.  It only aligns saved
predictions with the fixed synthetic stress split and the 21 public KTC2023
cases, then creates per-family images and paired bootstrap intervals.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from prepare_ktc_shape_dataset import instance_indentation_mask
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_implicit_boolean_network import FAMILIES, stress_metrics


METHOD_FILES = {
    "shape_expert": (Path("E:/Codex/ktc_shape_expert_seed20260820/predictions.npz"), "stress_expert", "real_expert"),
    "raw_fusion": (Path("E:/Codex/ktc_joint_shape_fusion_seed20260820/predictions.npz"), "stress", "real"),
    "boolean_external": (Path("E:/Codex/ktc_external_connected_support_seed20260820/predictions.npz"), "stress_external", "real_external"),
    "geodesic_corridor": (Path("E:/Codex/ktc_topology_corridor_seed20260820/predictions.npz"), "stress", "real"),
}

METRICS = (
    "foreground_iou",
    "open_deep_cutout_recovery",
    "bank_retention",
    "topology_structural_joint",
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--output-dir", type=Path, default=Path("E:/Codex/ktc_nonconvex_unified_seed20260820"))
    parser.add_argument("--bootstrap-samples", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260820)
    return parser.parse_args()


def load_predictions() -> tuple[dict[str, np.ndarray], dict[str, np.ndarray]]:
    stress_predictions: dict[str, np.ndarray] = {}
    real_predictions: dict[str, np.ndarray] = {}
    for name, (path, stress_key, real_key) in METHOD_FILES.items():
        archive = np.load(path.resolve(), allow_pickle=False)
        stress_predictions[name] = np.asarray(archive[stress_key])
        real_predictions[name] = np.asarray(archive[real_key])
    return stress_predictions, real_predictions


def save_rows(path: Path, rows: list[dict[str, object]]) -> None:
    keys = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def save_stress_family_grid(
    path: Path,
    truth: np.ndarray,
    cutout: np.ndarray,
    depth: np.ndarray,
    families: np.ndarray,
    predictions: dict[str, np.ndarray],
) -> None:
    indices = []
    for code in range(len(FAMILIES)):
        candidates = np.flatnonzero(families == code)
        score = (cutout[candidates] * (1.0 + 3.0 * depth[candidates])).sum(axis=(1, 2))
        indices.append(int(candidates[int(np.argmax(score))]))
    columns = ["truth", *predictions]
    figure, axes = plt.subplots(len(indices), len(columns), figsize=(2.65 * len(columns), 2.35 * len(indices)), squeeze=False)
    for row, index in enumerate(indices):
        images = [truth[index], *(prediction[index] for prediction in predictions.values())]
        for column, image in enumerate(images):
            axes[row, column].imshow(image, cmap="viridis", vmin=0, vmax=2, interpolation="nearest")
            axes[row, column].set_axis_off()
        axes[row, 0].set_ylabel(FAMILIES[int(families[index])], fontsize=9)
    for axis, title in zip(axes[0], columns):
        axis.set_title(title.replace("_", "\n"), fontsize=10)
    figure.suptitle("Independent nonlinear-CEM test: one deep inward target per family", fontsize=14)
    figure.tight_layout()
    figure.savefig(path, dpi=190)
    plt.close(figure)


def save_real_focus_grid(
    path: Path,
    truth: np.ndarray,
    ids: np.ndarray,
    predictions: dict[str, np.ndarray],
    limit: int = 10,
) -> None:
    indentation = np.stack([instance_indentation_mask(labels) for labels in truth])
    order = np.argsort(indentation.sum(axis=(1, 2)))[::-1][:limit]
    columns = ["truth", *predictions]
    figure, axes = plt.subplots(len(order), len(columns), figsize=(2.65 * len(columns), 2.45 * len(order)), squeeze=False)
    for row, index in enumerate(order):
        images = [truth[index], *(prediction[index] for prediction in predictions.values())]
        for column, image in enumerate(images):
            axes[row, column].imshow(image, cmap="viridis", vmin=0, vmax=2, interpolation="nearest")
            axes[row, column].set_axis_off()
        axes[row, 0].set_ylabel(f"{ids[index]}\nindent={int(indentation[index].sum())}", fontsize=8)
    for axis, title in zip(axes[0], columns):
        axis.set_title(title.replace("_", "\n"), fontsize=10)
    figure.suptitle("Most non-convex cases in the full public KTC2023 set", fontsize=14)
    figure.tight_layout()
    figure.savefig(path, dpi=190)
    plt.close(figure)


def paired_bootstrap(
    rows_by_method: dict[str, list[dict[str, float]]],
    reference: str,
    samples: int,
    seed: int,
) -> list[dict[str, object]]:
    rng = np.random.default_rng(seed)
    n = len(rows_by_method[reference])
    draws = rng.integers(0, n, size=(samples, n))
    output: list[dict[str, object]] = []
    for method, rows in rows_by_method.items():
        if method == reference:
            continue
        for metric in METRICS:
            before = np.asarray([float(row[metric]) for row in rows_by_method[reference]])
            after = np.asarray([float(row[metric]) for row in rows])
            difference = after - before
            boot = difference[draws].mean(axis=1)
            output.append({
                "reference": reference,
                "method": method,
                "metric": metric,
                "reference_mean": float(before.mean()),
                "method_mean": float(after.mean()),
                "mean_difference": float(difference.mean()),
                "ci95_low": float(np.quantile(boot, 0.025)),
                "ci95_high": float(np.quantile(boot, 0.975)),
                "improved_fraction": float((difference > 0).mean()),
                "n": n,
            })
    return output


def main() -> None:
    args = parse_args()
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    stress = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    base = np.load(args.base_dataset.resolve(), allow_pickle=False)
    indices = np.asarray(stress["test_indices"], dtype=np.int64)
    truth = np.asarray(stress["labels"])[indices]
    cutout = np.asarray(stress["cutout_masks"])[indices]
    depth = np.asarray(stress["cutout_depth_weights"])[indices]
    families = np.asarray(stress["family_codes"])[indices]
    stress_predictions, real_predictions = load_predictions()

    stress_summary: dict[str, dict[str, float]] = {}
    family_summary: dict[str, dict[str, dict[str, float]]] = {}
    stress_rows: dict[str, list[dict[str, float]]] = {}
    for name, prediction in stress_predictions.items():
        summary, by_family, rows = stress_metrics(truth, prediction, cutout, depth, families)
        stress_summary[name] = summary
        family_summary[name] = by_family
        stress_rows[name] = rows

    real_summary: dict[str, dict[str, float]] = {}
    real_rows: list[dict[str, object]] = []
    for name, prediction in real_predictions.items():
        summary, rows = evaluate_real_predictions(name, prediction, base["real_labels"], base["real_ids"])
        real_summary[name] = summary
        real_rows.extend(rows)

    bootstrap = paired_bootstrap(stress_rows, "raw_fusion", args.bootstrap_samples, args.seed)
    save_rows(out / "stress_paired_bootstrap.csv", bootstrap)
    save_rows(out / "real_case_metrics.csv", real_rows)
    save_stress_family_grid(out / "stress_family_comparison.png", truth, cutout, depth, families, stress_predictions)
    save_real_focus_grid(out / "real_most_nonconvex_comparison.png", base["real_labels"], base["real_ids"], real_predictions)
    result = {
        "policy": "read-only comparison; all predictions and test indices were frozen before this script",
        "stress_test_samples": int(len(indices)),
        "public_ktc_cases": int(len(base["real_ids"])),
        "stress": stress_summary,
        "stress_by_family": family_summary,
        "real": real_summary,
        "bootstrap_reference": "raw_fusion",
        "bootstrap_samples": args.bootstrap_samples,
        "bootstrap": bootstrap,
    }
    (out / "summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"stress": stress_summary, "real": real_summary}, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
