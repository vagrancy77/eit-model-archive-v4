"""Apply predeclared success criteria and write the final experiment report."""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--aggregate", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--candidate-architecture", required=True)
    parser.add_argument("--pilot-summary", type=Path, required=True)
    parser.add_argument("--dataset-summary", type=Path, default=root / "datasets" / "ktc_joint_concavity_v1.json")
    return parser.parse_args()


def statistic(
    groups: dict[str, object], group: str, metric: str, comparison: str = "protected_minus_vanilla"
) -> dict[str, float]:
    return groups[group]["paired_hierarchical_bootstrap"][comparison][metric]


def main() -> None:
    args = parse_args()
    aggregate = json.loads(args.aggregate.resolve().read_text(encoding="utf-8"))
    pilot = json.loads(args.pilot_summary.resolve().read_text(encoding="utf-8"))
    dataset = json.loads(args.dataset_summary.resolve().read_text(encoding="utf-8"))
    groups = aggregate["groups"]

    biological_joint = statistic(groups, "biological_held_out_test", "concavity_score")
    stress_joint = statistic(groups, "deep_concavity_stress_test", "concavity_score")
    legacy_ordinary_iou = statistic(groups, "legacy_test_ordinary", "foreground_iou")
    ktc_nonconvex_joint = statistic(groups, "ktc2023_audited_nonconvex", "concavity_score")
    ktc_all_iou = statistic(groups, "ktc2023_all", "foreground_iou")
    ktc_ordinary_iou = statistic(groups, "ktc2023_audited_ordinary", "foreground_iou")
    per_seed_biological = biological_joint["per_seed_mean_differences"]

    criteria = {
        "unseen_biological_concavity": {
            "passed": biological_joint["mean_difference"] > 0.0
            and biological_joint["bootstrap_probability_positive"] >= 0.95,
            "rule": "mean concavity-score gain > 0 and bootstrap P(gain) >= 0.95",
            "observed": biological_joint,
        },
        "deep_concavity_stress": {
            "passed": stress_joint["mean_difference"] > 0.0
            and stress_joint["bootstrap_probability_positive"] >= 0.90,
            "rule": "mean concavity-score gain > 0 and bootstrap P(gain) >= 0.90",
            "observed": stress_joint,
        },
        "ordinary_shape_protection": {
            "passed": legacy_ordinary_iou["mean_difference"] >= -0.005
            and legacy_ordinary_iou["ci95_low"] >= -0.015,
            "rule": "legacy ordinary IoU mean loss <= 0.005 and 95% lower bound >= -0.015",
            "observed": legacy_ordinary_iou,
        },
        "multi_seed_direction": {
            "passed": sum(value > 0.0 for value in per_seed_biological)
            >= max(2, len(per_seed_biological) - 1),
            "rule": "unseen-biological concavity gain is positive in at least two of three seeds",
            "observed": per_seed_biological,
        },
        "ktc_non_degradation_and_concavity": {
            "passed": ktc_nonconvex_joint["mean_difference"] >= 0.0
            and ktc_all_iou["mean_difference"] >= -0.005
            and ktc_ordinary_iou["mean_difference"] >= -0.010,
            "rule": "KTC nonconvex joint score nonnegative; all-case IoU loss <= 0.005; ordinary IoU loss <= 0.010",
            "observed": {
                "audited_nonconvex_concavity_score": ktc_nonconvex_joint,
                "all_case_foreground_iou": ktc_all_iou,
                "audited_ordinary_foreground_iou": ktc_ordinary_iou,
            },
        },
    }
    passed = sum(bool(value["passed"]) for value in criteria.values())
    if passed == len(criteria):
        verdict = "SUCCESS"
    elif (
        criteria["unseen_biological_concavity"]["passed"]
        and criteria["ordinary_shape_protection"]["passed"]
        and criteria["ktc_non_degradation_and_concavity"]["passed"]
    ):
        verdict = "PARTIAL_SUCCESS"
    else:
        verdict = "NOT_CONFIRMED"

    result = {
        "verdict": verdict,
        "passed_criteria": passed,
        "total_criteria": len(criteria),
        "candidate_architecture": args.candidate_architecture,
        "seeds": aggregate["seeds"],
        "criteria": criteria,
        "selection": {
            "pilot_selected_model": pilot["selection"]["selected_model"],
            "pilot_used_test_truth": bool(
                pilot["synthetic_test_labels_used_for_training_or_selection"]
                or pilot["ktc_evaluation_labels_accessed"]
            ),
            "final_test_truth_used_for_model_or_gate_selection": aggregate[
                "test_truth_used_for_model_or_gate_selection"
            ],
        },
        "dataset": dataset,
    }
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "assessment.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    def format_stat(value: dict[str, float]) -> str:
        return (
            f"{value['mean_difference']:+.4f} "
            f"[95% CI {value['ci95_low']:+.4f}, {value['ci95_high']:+.4f}], "
            f"P(>0)={value['bootstrap_probability_positive']:.3f}"
        )

    lines = [
        "# Physics- and topology-aware deep EIT: final simulation report",
        "",
        f"**Verdict: {verdict} ({passed}/{len(criteria)} predeclared criteria passed).**",
        "",
        "## Frozen design",
        "",
        f"- Candidate architecture: `{args.candidate_architecture}` (selected on pooled synthetic validation only).",
        f"- Random seeds: {', '.join(aggregate['seeds'])}.",
        f"- Training samples: {dataset['splits']['train']}; validation samples: {dataset['splits']['validation']}.",
        f"- Independent tests: {dataset['splits']['legacy_test']} legacy shapes, "
        f"{dataset['splits']['biological_held_out_test']} unseen biological-family shapes, "
        "160 deep-concavity stress cases, and 21 KTC2023 evaluation cases.",
        "- Public KTC evaluation truth was not used for checkpoint, architecture, or gate selection.",
        "",
        "## Primary results (protected minus vanilla)",
        "",
        f"- Unseen biological concavity score: {format_stat(biological_joint)}",
        f"- Deep-concavity stress score: {format_stat(stress_joint)}",
        f"- Legacy ordinary-shape IoU: {format_stat(legacy_ordinary_iou)}",
        f"- KTC audited-nonconvex concavity score: {format_stat(ktc_nonconvex_joint)}",
        f"- KTC all-case IoU: {format_stat(ktc_all_iou)}",
        f"- KTC audited-ordinary IoU: {format_stat(ktc_ordinary_iou)}",
        "",
        "## Predeclared checks",
        "",
    ]
    for name, value in criteria.items():
        lines.append(f"- {'PASS' if value['passed'] else 'FAIL'} `{name}`: {value['rule']}")
    lines.extend(
        (
            "",
            "## Reproducibility artifacts",
            "",
            "The aggregate directory contains `summary.json`, `assessment.json`, and "
            "`multiseed_key_results.png`. Each seed directory contains frozen gate settings, "
            "per-case CSV files, checkpoints, prediction archives, and KTC comparison montages.",
            "",
        )
    )
    (output_dir / "FINAL_REPORT.md").write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
