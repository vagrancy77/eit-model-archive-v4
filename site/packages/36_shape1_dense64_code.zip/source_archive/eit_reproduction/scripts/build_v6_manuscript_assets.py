"""Build manuscript figures and tables from frozen corrected-v6 results.

This script never trains a model and never selects a rule from test truth. It
only formats already-frozen summaries and creates explanatory schematics.
"""
from __future__ import annotations

import csv
import json
import shutil
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch


ROOT = Path(r"E:\Codex")
OUT = ROOT / "topology_local_eit_v6_corrected_paper_final" / "manuscript_assets"
MAIN = ROOT / "topology_local_eit_v6_corrected_multiseed_final"
ABLATION = ROOT / "topology_local_eit_v6_corrected_strict_ablation_final"
MEASUREMENT = ROOT / "topology_local_eit_v6_corrected_measurement_shift_final"
PHYSICAL = ROOT / "topology_local_eit_v6_corrected_physical_mismatch_final"
CASE_FIGURE = ROOT / "topology_local_eit_v6_corrected_paper_final" / "v6_success_safety_failure_cases.png"


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def write_md(path: Path, title: str, columns: list[str], rows: list[dict[str, Any]]) -> None:
    lines = [f"# {title}", "", "| " + " | ".join(columns) + " |", "|" + "|".join("---" for _ in columns) + "|"]
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(column, "")) for column in columns) + " |")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def ci(value: dict[str, Any], digits: int = 5) -> str:
    return (
        f"{float(value['mean_difference']):+.{digits}f} "
        f"[{float(value['ci95_low']):+.{digits}f}, {float(value['ci95_high']):+.{digits}f}]"
    )


def effect(summary: dict[str, Any], label: str, comparison: str, metric: str) -> dict[str, Any]:
    for row in summary["effects"]:
        row_comparison = row.get("comparison", row.get("candidate"))
        aliases = {comparison}
        if comparison.endswith("_minus_anchor_v4"):
            aliases.add(comparison.removesuffix("_minus_anchor_v4"))
        if row["label"] == label and row_comparison in aliases and row["metric"] == metric:
            return row
    raise KeyError((label, comparison, metric))


def draw_box(ax, x: float, y: float, w: float, h: float, text: str, color: str, fontsize: int = 10) -> None:
    patch = FancyBboxPatch(
        (x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.02",
        facecolor=color, edgecolor="#263238", linewidth=1.2,
    )
    ax.add_patch(patch)
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fontsize, wrap=True)


def arrow(ax, x1: float, y1: float, x2: float, y2: float, color: str = "#455a64") -> None:
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=14, linewidth=1.5, color=color))


def framework_figure(path: Path) -> None:
    fig, ax = plt.subplots(figsize=(15, 6.5), dpi=220)
    ax.set_xlim(0, 15)
    ax.set_ylim(0, 6.5)
    ax.axis("off")
    ax.set_title("Figure 1. Physics- and topology-aware local EIT correction", fontsize=16, pad=14)
    draw_box(ax, 0.35, 2.45, 1.55, 1.0, "Voltage\nmeasurements", "#e3f2fd")
    draw_box(ax, 2.35, 2.45, 1.55, 1.0, "Frozen v4\nanchor", "#bbdefb")
    arrow(ax, 1.9, 2.95, 2.35, 2.95)
    draw_box(ax, 4.35, 4.55, 2.15, 0.85, "Anchor probabilities", "#e8eaf6")
    draw_box(ax, 4.35, 3.25, 2.15, 0.85, "Physics\nbackprojection", "#e8eaf6")
    draw_box(ax, 4.35, 1.95, 2.15, 0.85, "Connectivity and\nlocal topology maps", "#e8eaf6")
    arrow(ax, 3.9, 2.95, 4.35, 4.95)
    arrow(ax, 3.9, 2.95, 4.35, 3.65)
    arrow(ax, 3.9, 2.95, 4.35, 2.35)
    draw_box(ax, 7.0, 2.35, 2.0, 1.2, "Topology corrector\n15-channel residual CNN", "#c8e6c9")
    arrow(ax, 6.5, 4.95, 7.0, 3.15)
    arrow(ax, 6.5, 3.65, 7.0, 3.0)
    arrow(ax, 6.5, 2.35, 7.0, 2.75)
    draw_box(ax, 9.5, 2.35, 1.8, 1.2, "Candidate\nlocal removal", "#fff3e0")
    arrow(ax, 9.0, 2.95, 9.5, 2.95)
    draw_box(ax, 11.8, 4.25, 2.45, 0.9, "Benefit quantile\nq20", "#fce4ec")
    draw_box(ax, 11.8, 3.0, 2.45, 0.9, "IoU-loss risk\nq80", "#fce4ec")
    draw_box(ax, 11.8, 1.75, 2.45, 0.9, "Bank-loss risk\nq80", "#fce4ec")
    arrow(ax, 11.3, 2.95, 11.8, 4.65)
    arrow(ax, 11.3, 2.95, 11.8, 3.4)
    arrow(ax, 11.3, 2.95, 11.8, 2.15)
    draw_box(ax, 11.8, 0.35, 2.45, 0.9, "Final gated output\n(candidate or v4)", "#c5cae9")
    arrow(ax, 13.0, 1.75, 13.0, 1.25)
    ax.text(7.95, 1.75, "topology supervision during training", ha="center", fontsize=9, color="#455a64")
    ax.text(13.05, 5.65, "Validation-only thresholds", ha="center", fontsize=9, color="#ad1457")
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def network_figure(path: Path) -> None:
    fig, ax = plt.subplots(figsize=(14, 7), dpi=220)
    ax.set_xlim(0, 14)
    ax.set_ylim(0, 7)
    ax.axis("off")
    ax.set_title("Figure 2. Local topology corrector and dual-risk gate", fontsize=16, pad=14)
    draw_box(ax, 0.35, 3.0, 1.7, 1.05, "15 x 64 x 64\ninput maps", "#e3f2fd")
    draw_box(ax, 2.45, 3.0, 1.5, 1.05, "Residual\nstem", "#c8e6c9")
    draw_box(ax, 4.45, 4.45, 1.7, 1.05, "Dilated\ncontext", "#c8e6c9")
    draw_box(ax, 4.45, 2.95, 1.7, 1.05, "Refinement\nblocks x2", "#c8e6c9")
    draw_box(ax, 4.45, 1.45, 1.7, 1.05, "Residual skip\nfeatures", "#c8e6c9")
    arrow(ax, 2.05, 3.52, 2.45, 3.52)
    arrow(ax, 3.95, 3.52, 4.45, 3.52)
    arrow(ax, 3.95, 3.52, 4.45, 4.95)
    arrow(ax, 3.95, 3.52, 4.45, 1.95)
    for idx, (y, label, color) in enumerate(((4.8, "Removal map", "#fff3e0"), (3.35, "Mouth / local\nconfidence", "#fff3e0"), (1.9, "Corrected mask\nproposal", "#fff3e0"))):
        draw_box(ax, 7.0, y, 1.85, 0.9, label, color)
        arrow(ax, 6.15, 3.52, 7.0, y + 0.45)
    draw_box(ax, 9.45, 3.4, 1.85, 1.0, "Connectivity\nprojection", "#dcedc8")
    arrow(ax, 8.85, 2.35, 9.45, 3.9)
    draw_box(ax, 11.8, 4.55, 1.75, 0.8, "MLP 96\n+ dropout", "#fce4ec")
    draw_box(ax, 11.8, 3.25, 1.75, 0.8, "Benefit q20", "#fce4ec")
    draw_box(ax, 11.8, 1.95, 1.75, 0.8, "IoU / bank\nrisk q80", "#fce4ec")
    arrow(ax, 11.3, 3.9, 11.8, 4.95)
    arrow(ax, 11.3, 3.9, 11.8, 3.65)
    arrow(ax, 11.3, 3.9, 11.8, 2.35)
    draw_box(ax, 11.8, 0.55, 1.75, 0.8, "Gate decision", "#c5cae9")
    arrow(ax, 12.65, 1.95, 12.65, 1.35)
    ax.text(6.95, 6.35, "All convolutional heads operate on shared spatial features; the gate is case-level.", ha="center", fontsize=10, color="#37474f")
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def protocol_figure(path: Path) -> None:
    fig, ax = plt.subplots(figsize=(15, 7), dpi=220)
    ax.set_xlim(0, 15)
    ax.set_ylim(0, 7)
    ax.axis("off")
    ax.set_title("Figure 3. Training, calibration, and inference protocol", fontsize=16, pad=14)
    ax.text(0.6, 6.3, "Training and validation", fontsize=13, weight="bold", color="#1565c0")
    ax.text(0.6, 2.9, "Frozen test evaluation", fontsize=13, weight="bold", color="#2e7d32")
    train = [(0.6, 5.0, "Synthetic train\n(base + biological + stress)"), (3.55, 5.0, "Cache frozen v4\nanchor and physics maps"), (6.5, 5.0, "Train topology\ncorrector"), (9.45, 5.0, "Train quantile\nrisk gate")]
    for x, y, text in train:
        draw_box(ax, x, y, 2.35, 0.95, text, "#e3f2fd" if x < 6 else "#e8f5e9")
    for x in (2.95, 5.9, 8.85):
        arrow(ax, x, 5.48, x + 0.6, 5.48)
    draw_box(ax, 12.4, 5.0, 2.0, 0.95, "Calibrate gate\non validation only", "#fff3e0")
    arrow(ax, 11.8, 5.48, 12.4, 5.48)
    test = [(0.6, 1.55, "Independent synthetic\ntest truth"), (3.55, 1.55, "Public KTC\n21 real samples"), (6.5, 1.55, "Measurement shifts\n(dropout / noise / drift)"), (9.45, 1.55, "Exact nonlinear CEM\nphysical mismatch"), (12.4, 1.55, "Report paired\nbootstrap effects")]
    for x, y, text in test:
        draw_box(ax, x, y, 2.35, 0.95, text, "#e8f5e9")
    for x in (2.95, 5.9, 8.85, 11.8):
        arrow(ax, x, 2.03, x + 0.6, 2.03)
    ax.plot([1.75, 1.75], [4.95, 2.55], linestyle="--", color="#90a4ae")
    ax.text(1.95, 3.7, "No test truth used\nfor training or routing", fontsize=9, color="#546e7a")
    ax.text(7.5, 0.55, "All primary intervals: 10,000 paired hierarchical bootstrap repetitions.", ha="center", fontsize=10, color="#37474f")
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def build_tables() -> None:
    main = load(MAIN / "v6_multiseed_summary.json")
    ablation = load(ABLATION / "v6_ablation_summary.json")
    measurement = load(MEASUREMENT / "v6_measurement_shift_summary.json")
    physical = load(PHYSICAL / "v6_physical_mismatch_summary.json")

    dataset_rows = [
        {"Dataset": "Synthetic base", "Train": "2,160", "Validation": "420", "Test": "420", "Test composition": "Concave / ordinary", "Role": "Training, validation, internal test"},
        {"Dataset": "Biological concavity", "Train": "1,600", "Validation": "400", "Test": "400", "Test composition": "300 concave + 100 ordinary per seed", "Role": "Main independent synthetic test"},
        {"Dataset": "Deep concavity stress", "Train": "520", "Validation": "120", "Test": "160", "Test composition": "160 stress concave", "Role": "Unseen-shape stress test"},
        {"Dataset": "Public KTC real samples", "Train": "0", "Validation": "0", "Test": "21", "Test composition": "17 nonconvex + 4 ordinary", "Role": "Public domain-out test only"},
    ]
    columns = ["Dataset", "Train", "Validation", "Test", "Test composition", "Role"]
    write_csv(OUT / "table1_dataset_splits.csv", dataset_rows)
    write_md(OUT / "table1_dataset_splits.md", "Table 1. Dataset splits and evaluation roles", columns, dataset_rows)

    main_rows = []
    for label in ("Biological concave", "Stress concave", "Public KTC nonconvex", "Biological ordinary"):
        iou = effect(main, label, "gated_v6_minus_anchor_v4", "foreground_iou")
        notch = effect(main, label, "gated_v6_minus_anchor_v4", "notch_preservation")
        rate = main["rates"][label]["severe_iou_loss"]
        main_rows.append({
            "Subset": label,
            "Cases/seed": iou["cases_per_seed"],
            "Delta IoU (95% CI)": ci(iou),
            "Delta Notch (95% CI)": ci(notch),
            "Severe IoU loss rate": f"{rate['rate']:.4f} [{rate['ci95_low']:.4f}, {rate['ci95_high']:.4f}]",
        })
    columns = ["Subset", "Cases/seed", "Delta IoU (95% CI)", "Delta Notch (95% CI)", "Severe IoU loss rate"]
    write_csv(OUT / "table2_primary_effects.csv", main_rows)
    write_md(OUT / "table2_primary_effects.md", "Table 2. Primary paired effects of gated v6 versus v4", columns, main_rows)

    safety = {}
    with (ROOT / "topology_local_eit_v6_corrected_paper_final" / "v6_safety_by_variant.csv").open(encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            safety[row["variant"]] = row
    variant_names = ["no_physics", "no_topology_supervision", "no_connectivity", "full_ungated", "benefit_only_gate", "full_dual_risk_gate"]
    variant_labels = {
        "no_physics": "No physics backprojection",
        "no_topology_supervision": "No topology supervision",
        "no_connectivity": "No connectivity projection",
        "full_ungated": "Full model, ungated",
        "benefit_only_gate": "Benefit-only gate",
        "full_dual_risk_gate": "Full dual-risk gate",
    }
    ablation_rows = []
    for variant in variant_names:
        comp = f"{variant}_minus_anchor_v4"
        iou = effect(ablation, "Biological concave", comp, "foreground_iou")
        notch = effect(ablation, "Biological concave", comp, "notch_preservation")
        s = safety[variant]
        ablation_rows.append({
            "Variant": variant_labels[variant],
            "Biological concave Delta IoU": ci(iou),
            "Biological concave Delta Notch": ci(notch),
            "Ordinary mean Delta IoU": f"{float(s['mean_delta_iou']):+.5f}",
            "Ordinary severe-loss rate": f"{float(s['severe_loss_rate']):.4f}",
            "Worst ordinary Delta IoU": f"{float(s['worst_delta_iou']):+.5f}",
        })
    columns = ["Variant", "Biological concave Delta IoU", "Biological concave Delta Notch", "Ordinary mean Delta IoU", "Ordinary severe-loss rate", "Worst ordinary Delta IoU"]
    write_csv(OUT / "table3_strict_ablation.csv", ablation_rows)
    write_md(OUT / "table3_strict_ablation.md", "Table 3. Strict component ablation", columns, ablation_rows)

    measurement_rows = []
    g = measurement["groups"]["biological_concave"]
    for condition in measurement["conditions"]:
        item = g["conditions"][condition]
        comp = item["comparisons"]["gated_v6_minus_anchor_v4"]
        degradation = item.get("degradation_from_native", {}).get("gated_v6", {}).get("foreground_iou")
        measurement_rows.append({
            "Condition": condition,
            "Delta IoU (95% CI)": ci(comp["foreground_iou"]),
            "Delta Notch (95% CI)": ci(comp["notch_preservation"]),
            "Absolute gated IoU degradation": "native" if degradation is None else ci(degradation),
        })
    columns = ["Condition", "Delta IoU (95% CI)", "Delta Notch (95% CI)", "Absolute gated IoU degradation"]
    write_csv(OUT / "table4_measurement_shifts.csv", measurement_rows)
    write_md(OUT / "table4_measurement_shifts.md", "Table 4. Measurement-shift robustness on biological concave cases", columns, measurement_rows)

    physical_rows = []
    g = physical["groups"]["concave"]
    for condition in physical["conditions"]:
        item = g["conditions"][condition]
        comp = item["comparisons"]["gated_v6_minus_anchor_v4"]
        degradation = item.get("degradation_from_nominal", {}).get("gated_v6", {}).get("foreground_iou")
        physical_rows.append({
            "Condition": condition,
            "Delta IoU (95% CI)": ci(comp["foreground_iou"]),
            "Delta Notch (95% CI)": ci(comp["notch_preservation"]),
            "Absolute gated IoU degradation": "nominal" if degradation is None else ci(degradation),
        })
    columns = ["Condition", "Delta IoU (95% CI)", "Delta Notch (95% CI)", "Absolute gated IoU degradation"]
    write_csv(OUT / "table5_exact_cem_mismatch.csv", physical_rows)
    write_md(OUT / "table5_exact_cem_mismatch.md", "Table 5. Exact nonlinear CEM mismatch robustness", columns, physical_rows)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    framework_figure(OUT / "fig1_method_framework.png")
    network_figure(OUT / "fig2_network_structure.png")
    protocol_figure(OUT / "fig3_training_inference_protocol.png")
    shutil.copy2(CASE_FIGURE, OUT / "fig4_case_comparison.png")
    build_tables()
    manifest = {
        "source": "frozen corrected-v6 summaries",
        "figures": [f"fig{i}" for i in range(1, 5)],
        "tables": [f"table{i}" for i in range(1, 6)],
        "bootstrap_repetitions": 10000,
        "test_truth_used_for_training_or_rule_selection": False,
    }
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps({"output_dir": str(OUT), "figures": 4, "tables": 5}, indent=2))


if __name__ == "__main__":
    main()
