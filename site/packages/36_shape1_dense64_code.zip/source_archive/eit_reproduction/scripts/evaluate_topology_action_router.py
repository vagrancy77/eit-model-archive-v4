"""Calibrate a case-level topology router on synthetic validation data only."""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import calibrate_open_topology_projection as calibration
import calibrate_topology_hole_resolver as hole_calibration
import train_boolean_shape_eit_v2 as data_tools
import train_topology_residual_eit_v3 as trainer
from pytorch_eit.topology_residual_net import TopologyResidualEITNet


THRESHOLDS = (
    0.0, 0.0005, 0.001, 0.002, 0.003, 0.005, 0.0075, 0.01,
    0.015, 0.02, 0.03, 0.04, 0.05, 0.075, 0.10, 0.15, 0.20,
    0.30, 0.50, 0.75, 1.0,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--test-predictions", type=Path, required=True)
    parser.add_argument("--public-predictions", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--base-dataset", type=Path, default=ROOT / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument(
        "--biological-dataset", type=Path,
        default=ROOT / "datasets" / "ktc_biological_concavity_v1.npz",
    )
    parser.add_argument(
        "--stress-dataset", type=Path,
        default=ROOT / "datasets" / "ktc_deep_concavity_stress_v1.npz",
    )
    parser.add_argument(
        "--audit", type=Path,
        default=ROOT / "outputs" / "ktc2023_full_audit" / "summary.json",
    )
    parser.add_argument("--batch-size", type=int, default=24)
    parser.add_argument(
        "--risk-quantile", type=float, default=0.05,
        help="lower-tail quantile used to calibrate ordinary-case routing risk",
    )
    parser.add_argument(
        "--risk-floor", type=float, default=-0.01,
        help="minimum allowed lower-tail IoU delta on validation ordinary cases",
    )
    return parser.parse_args()


def routed(direct: np.ndarray, topology: np.ndarray, gate: np.ndarray, threshold: float) -> np.ndarray:
    enabled = gate >= threshold
    return np.where(enabled[:, None, None], topology, direct)


def metric_rows(
    truth: np.ndarray, prediction: np.ndarray, cutout: np.ndarray
) -> list[dict[str, float]]:
    return [trainer.case_metrics(t, p, c) for t, p, c in zip(truth, prediction, cutout)]


def split_rows(rows: list[dict[str, float]]) -> dict[str, dict[str, float]]:
    concave = [row for row in rows if row["has_cutout"] > 0.5]
    ordinary = [row for row in rows if row["has_cutout"] <= 0.5]
    return {
        "all": trainer.aggregate(rows),
        "concave": trainer.aggregate(concave) if concave else {"cases": 0.0},
        "ordinary": trainer.aggregate(ordinary) if ordinary else {"cases": 0.0},
    }


def ordinary_tail(
    direct_rows: list[dict[str, float]], candidate_rows: list[dict[str, float]],
    quantile: float = 0.05,
) -> dict[str, float]:
    differences = np.asarray([
        candidate["foreground_iou"] - direct["foreground_iou"]
        for direct, candidate in zip(direct_rows, candidate_rows)
        if direct["has_cutout"] <= 0.5
    ], dtype=np.float64)
    if not differences.size:
        return {
            "cases": 0.0, "mean": 0.0, "minimum": 0.0,
            "fraction_below_minus_0_01": 0.0,
            "lower_quantile": 0.0, "lower_tail_mean": 0.0,
        }
    quantile = float(np.clip(quantile, 0.0, 0.5))
    lower_count = max(1, int(np.ceil(quantile * differences.size)))
    sorted_differences = np.sort(differences)
    return {
        "cases": float(differences.size),
        "mean": float(differences.mean()),
        "minimum": float(differences.min()),
        "fraction_below_minus_0_01": float(np.mean(differences < -0.01)),
        "lower_quantile": float(np.quantile(differences, quantile)),
        "lower_tail_mean": float(sorted_differences[:lower_count].mean()),
    }


def delta(metrics: dict[str, dict[str, float]], direct: dict[str, dict[str, float]], subset: str, key: str) -> float:
    return float(metrics[subset].get(key, 0.0) - direct[subset].get(key, 0.0))


def candidate_score(
    groups: dict[str, dict[str, np.ndarray]], threshold: float,
    risk_quantile: float = 0.05, risk_floor: float = -0.01,
) -> dict[str, object]:
    summaries: dict[str, object] = {}
    tails: dict[str, dict[str, float]] = {}
    enabled: dict[str, float] = {}
    for name, arrays in groups.items():
        direct = arrays["base"].argmax(axis=1).astype(np.uint8)
        topology = hole_calibration.original_prediction(arrays)
        prediction = routed(direct, topology, arrays["gate"], threshold)
        direct_rows = metric_rows(arrays["truth"], direct, arrays["cutout"])
        candidate_rows = metric_rows(arrays["truth"], prediction, arrays["cutout"])
        direct_summary = split_rows(direct_rows)
        candidate_summary = split_rows(candidate_rows)
        summaries[name] = {"routed": candidate_summary, "direct_base": direct_summary}
        tails[name] = ordinary_tail(direct_rows, candidate_rows, risk_quantile)
        enabled[name] = float(np.mean(arrays["gate"] >= threshold))

    base = summaries["base"]
    biological = summaries["biological"]
    stress = summaries["stress"]
    benefit = (
        0.10 * delta(base["routed"], base["direct_base"], "concave", "notch_preservation")
        + 0.25 * delta(biological["routed"], biological["direct_base"], "concave", "notch_preservation")
        + 0.40 * delta(stress["routed"], stress["direct_base"], "concave", "notch_preservation")
        + 0.05 * delta(biological["routed"], biological["direct_base"], "concave", "boundary_f1")
        + 0.10 * delta(stress["routed"], stress["direct_base"], "concave", "boundary_f1")
        + 0.05 * delta(biological["routed"], biological["direct_base"], "concave", "foreground_iou")
        + 0.05 * delta(stress["routed"], stress["direct_base"], "concave", "foreground_iou")
    )
    bio_tail = tails["biological"]
    base_tail = tails["base"]
    feasible = (
        bio_tail["mean"] >= -0.0005
        and bio_tail["minimum"] >= -0.015
        and bio_tail["fraction_below_minus_0_01"] <= 0.02
        and base_tail["minimum"] >= -0.01
        and bio_tail["lower_tail_mean"] >= risk_floor
        and base_tail["lower_tail_mean"] >= risk_floor
    )
    safety_penalty = (
        2.0 * max(0.0, -0.0005 - bio_tail["mean"])
        + 0.5 * max(0.0, -0.015 - bio_tail["minimum"])
        + 0.5 * max(0.0, bio_tail["fraction_below_minus_0_01"] - 0.02)
        + 0.25 * max(0.0, -0.01 - base_tail["minimum"])
        + 1.5 * max(0.0, risk_floor - bio_tail["lower_tail_mean"])
        + 0.75 * max(0.0, risk_floor - base_tail["lower_tail_mean"])
    )
    return {
        "threshold": threshold,
        "feasible": feasible,
        "objective": float(benefit - safety_penalty),
        "benefit_before_safety_penalty": float(benefit),
        "safety_penalty": float(safety_penalty),
        "enabled_fraction": enabled,
        "ordinary_tail": tails,
        "metrics": summaries,
    }


def select_threshold(
    groups: dict[str, dict[str, np.ndarray]], risk_quantile: float, risk_floor: float,
) -> tuple[dict[str, object], list[dict[str, object]]]:
    candidates = [
        candidate_score(groups, threshold, risk_quantile, risk_floor)
        for threshold in THRESHOLDS
    ]
    feasible = [candidate for candidate in candidates if bool(candidate["feasible"])]
    pool = feasible if feasible else candidates
    pool.sort(key=lambda row: (float(row["objective"]), -float(row["threshold"])), reverse=True)
    return pool[0], sorted(candidates, key=lambda row: float(row["objective"]), reverse=True)


def archive_group(archive: np.lib.npyio.NpzFile, prefix: str) -> dict[str, np.ndarray]:
    return {
        "truth": np.asarray(archive[f"{prefix}_truth"]),
        "cutout": np.asarray(archive[f"{prefix}_cutout"]),
        "direct": np.asarray(archive[f"{prefix}_base_prediction"]),
        "topology": np.asarray(archive[f"{prefix}_prediction"]),
        "gate": np.asarray(archive[f"{prefix}_case_gate"]),
        "image": np.asarray(archive[f"{prefix}_image"]),
        "ids": np.asarray([f"{prefix}/{value}" for value in archive[f"{prefix}_index"]]),
    }


def evaluate_group(arrays: dict[str, np.ndarray], threshold: float) -> tuple[dict[str, object], np.ndarray, list[dict[str, float]]]:
    route = routed(arrays["direct"], arrays["topology"], arrays["gate"], threshold)
    direct_rows = metric_rows(arrays["truth"], arrays["direct"], arrays["cutout"])
    topology_rows = metric_rows(arrays["truth"], arrays["topology"], arrays["cutout"])
    routed_rows = metric_rows(arrays["truth"], route, arrays["cutout"])
    result = {
        "direct_base": split_rows(direct_rows),
        "topology_residual": split_rows(topology_rows),
        "topology_routed": split_rows(routed_rows),
        "ordinary_tail_topology_residual": ordinary_tail(direct_rows, topology_rows),
        "ordinary_tail_topology_routed": ordinary_tail(direct_rows, routed_rows),
        "enabled_fraction": float(np.mean(arrays["gate"] >= threshold)),
    }
    return result, route, routed_rows


def save_case_rows(
    path: Path,
    group_name: str,
    arrays: dict[str, np.ndarray],
    routed_prediction: np.ndarray,
) -> None:
    rows: list[dict[str, object]] = []
    for method, predictions in (
        ("direct_base", arrays["direct"]),
        ("topology_residual", arrays["topology"]),
        ("topology_routed", routed_prediction),
    ):
        for case_id, truth, prediction, cutout, gate in zip(
            arrays["ids"], arrays["truth"], predictions, arrays["cutout"], arrays["gate"]
        ):
            row: dict[str, object] = {
                "id": str(case_id), "group": group_name, "method": method, "case_gate": float(gate)
            }
            row.update(trainer.case_metrics(truth, prediction, cutout))
            rows.append(row)
    write_header = not path.exists()
    with path.open("a", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        if write_header:
            writer.writeheader()
        writer.writerows(rows)


def save_montage(
    path: Path, arrays: dict[str, np.ndarray], routed_prediction: np.ndarray, title: str
) -> None:
    direct_rows = metric_rows(arrays["truth"], arrays["direct"], arrays["cutout"])
    routed_rows = metric_rows(arrays["truth"], routed_prediction, arrays["cutout"])
    differences = np.asarray([
        candidate["foreground_iou"] - direct["foreground_iou"]
        for direct, candidate in zip(direct_rows, routed_rows)
    ])
    notch = arrays["cutout"].reshape(len(arrays["cutout"]), -1).sum(axis=1) > 0
    chosen: list[int] = []
    for selected in (notch, ~notch):
        indices = np.flatnonzero(selected)
        if indices.size:
            chosen.extend(indices[np.argsort(differences[indices])[[0, -1]]].tolist())
    chosen = list(dict.fromkeys(chosen))
    figure, axes = plt.subplots(len(chosen), 5, figsize=(10.8, 2.15 * len(chosen)), squeeze=False)
    for row_index, index in enumerate(chosen):
        panels = (
            (arrays["image"][index], "coolwarm", None, None, "linear EIT"),
            (arrays["truth"][index], "viridis", 0, 2, "truth"),
            (arrays["direct"][index], "viridis", 0, 2, "direct"),
            (arrays["topology"][index], "viridis", 0, 2, "raw topology"),
            (routed_prediction[index], "viridis", 0, 2, "routed"),
        )
        for column, (image, cmap, vmin, vmax, name) in enumerate(panels):
            axes[row_index, column].imshow(image, cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest")
            axes[row_index, column].set_axis_off()
            if row_index == 0:
                axes[row_index, column].set_title(name)
        axes[row_index, 0].set_ylabel(
            f"gate={arrays['gate'][index]:.3f}\nIoU delta={differences[index]:+.3f}", rotation=0,
            ha="right", va="center",
        )
    figure.suptitle(title)
    figure.tight_layout()
    figure.savefig(path, dpi=220)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    archives = {
        "base": np.load(args.base_dataset.resolve(), allow_pickle=False),
        "biological": np.load(args.biological_dataset.resolve(), allow_pickle=False),
        "stress": np.load(args.stress_dataset.resolve(), allow_pickle=False),
    }
    prepared = {name: data_tools.prepare_arrays(archive, name) for name, archive in archives.items()}
    state = torch.load(args.checkpoint.resolve(), map_location=device, weights_only=False)
    model = TopologyResidualEITNet(
        prepared["base"].fov_mask,
        int(state["base_channels"]),
        int(state.get("propagation_steps", 14)),
        risk_aware=bool(state.get("risk_aware", False)),
    ).to(device)
    model.load_state_dict(state["model"])

    validation: dict[str, dict[str, np.ndarray]] = {}
    for source, name in enumerate(("base", "biological", "stress")):
        dataset = trainer.DirectStructuralDataset(
            prepared[name], archives[name], archives[name]["validation_indices"], source
        )
        validation[name] = calibration.infer(
            model, DataLoader(dataset, batch_size=args.batch_size, shuffle=False), device
        )
    best, candidates = select_threshold(validation, args.risk_quantile, args.risk_floor)
    threshold = float(best["threshold"])

    test_archive = np.load(args.test_predictions.resolve(), allow_pickle=False)
    evaluations: dict[str, object] = {}
    case_path = output_dir / "action_router_case_metrics.csv"
    if case_path.exists():
        case_path.unlink()
    test_groups: dict[str, dict[str, np.ndarray]] = {}
    for name in ("base", "biological", "stress"):
        arrays = archive_group(test_archive, name)
        test_groups[name] = arrays
        evaluations[name], route, _ = evaluate_group(arrays, threshold)
        save_case_rows(case_path, name, arrays, route)
    save_montage(
        output_dir / "biological_action_router_cases.png", test_groups["biological"],
        routed(test_groups["biological"]["direct"], test_groups["biological"]["topology"], test_groups["biological"]["gate"], threshold),
        f"Biological independent test, validation-routed topology (threshold={threshold:g})",
    )

    public_archive = np.load(args.public_predictions.resolve(), allow_pickle=False)
    public = {
        "truth": np.asarray(public_archive["truth"]),
        "cutout": np.asarray(public_archive["notch"]),
        "direct": np.asarray(public_archive["direct_base"]),
        "topology": np.asarray(public_archive["topology_residual"]),
        "gate": np.asarray(public_archive["case_gate"]),
        "image": np.zeros_like(public_archive["truth"], dtype=np.float32),
        "ids": np.asarray(public_archive["ids"]),
    }
    public_evaluation, public_route, _ = evaluate_group(public, threshold)
    save_case_rows(case_path, "public_ktc", public, public_route)
    audit = json.loads(args.audit.resolve().read_text(encoding="utf-8"))
    strict_ids = {str(value) for value in audit["nonconvex_ids"]}
    strict = np.asarray([str(case_id) in strict_ids for case_id in public["ids"]])
    public_evaluation["audited_nonconvex"] = evaluate_group(
        {key: value[strict] for key, value in public.items()}, threshold
    )[0]
    public_evaluation["audited_ordinary"] = evaluate_group(
        {key: value[~strict] for key, value in public.items()}, threshold
    )[0]
    evaluations["public_ktc"] = public_evaluation

    result = {
        "selection_data": "synthetic validation only",
        "synthetic_test_or_public_truth_used_for_threshold_selection": False,
        "checkpoint": str(args.checkpoint.resolve()),
        "threshold": threshold,
        "risk_quantile": args.risk_quantile,
        "risk_floor": args.risk_floor,
        "best_validation_candidate": best,
        "validation_candidates": candidates,
        "independent_and_public_evaluation": evaluations,
    }
    (output_dir / "action_router_summary.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps({
        "threshold": threshold,
        "validation_objective": best["objective"],
        "validation_ordinary_tail": best["ordinary_tail"],
        "evaluation": evaluations,
    }, indent=2), flush=True)


if __name__ == "__main__":
    main()
