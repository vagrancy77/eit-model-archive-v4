"""Low-capacity level-held-out ranker for the frozen KTC candidate pool.

The model predicts each complete candidate's IoU improvement from explicit
geometry, local EIT, and fixed-contrast physics descriptors. Seven outer folds
hold out one complete public KTC level; a second level selects ridge and
acceptance hyperparameters. Outer labels never influence that fold.
"""
from __future__ import annotations

import argparse
import csv
import json
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from evaluate_ktc_cross_pool_physics_ranking import (
    geometry_risks,
    residual_scores,
    resize_candidates,
)
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_cross_representation_pixel_fusion import (
    STRICT_INWARD_IDS,
    SplitArrays,
    foreground_iou_per_case,
    load_pool,
    metric_for,
    paired_bootstrap,
    prepare_split,
)
from train_ktc_cross_representation_ranker import candidate_descriptors


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    parser.add_argument(
        "--pool-dir", type=Path,
        default=root / "outputs" / "ktc_cross_representation_pool_seed20260820",
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=root / "outputs" / "ktc_public_level_cv_ridge_ranker_seed20260820",
    )
    parser.add_argument("--base-train-samples", type=int, default=600)
    parser.add_argument("--stress-train-samples", type=int, default=300)
    parser.add_argument("--bootstrap-repetitions", type=int, default=10000)
    parser.add_argument("--fold-limit", type=int, default=0)
    parser.add_argument("--seed", type=int, default=20260820)
    return parser.parse_args()


@dataclass
class FeatureSet:
    features: np.ndarray
    risks: dict[str, np.ndarray]


@dataclass
class RidgeModel:
    mean: np.ndarray
    scale: np.ndarray
    coefficients: np.ndarray

    def predict(self, features: np.ndarray) -> np.ndarray:
        standardized = (features - self.mean) / self.scale
        design = np.concatenate((np.ones((*standardized.shape[:-1], 1)), standardized), axis=-1)
        return design @ self.coefficients


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        return
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def subset_split(split: SplitArrays, selected: np.ndarray, name: str) -> SplitArrays:
    return SplitArrays(
        name=name, source=split.source, indices=split.indices[selected],
        images=split.images[selected], voltages=split.voltages[selected], truths=split.truths[selected],
        candidates=split.candidates[:, selected], cutouts=split.cutouts[selected],
        depths=split.depths[selected], families=split.families[selected],
    )


def candidate_targets(truths: np.ndarray, candidates: np.ndarray) -> np.ndarray:
    values = np.stack([foreground_iou_per_case(truths, candidate) for candidate in candidates], axis=1)
    return values - values[:, :1]


def build_features(
    images: np.ndarray,
    voltages: np.ndarray,
    candidates: np.ndarray,
    archive: np.lib.npyio.NpzFile,
) -> FeatureSet:
    candidates64 = resize_candidates(candidates)
    fov = np.asarray(archive["fov_mask"], dtype=bool)
    descriptors = candidate_descriptors(np.asarray(images, dtype=np.float32), candidates64, fov)
    baseline = np.repeat(descriptors[:, :1], descriptors.shape[1], axis=1)
    descriptor_delta = descriptors - baseline
    physics, _, saturated = residual_scores(
        candidates64, voltages, archive["jacobian"], archive["node_to_raw_pixel"]
    )
    physics_features: list[np.ndarray] = []
    for values in physics.values():
        reference = np.maximum(np.abs(values[0]), 1e-12)
        gain = 1.0 - values / reference[None]
        physics_features.append(np.clip(np.nan_to_num(gain.T, nan=-2.0, neginf=-2.0, posinf=1.0), -2.0, 1.0)[..., None])
    risks = geometry_risks(candidates64, fov)
    risk_features = np.stack((
        risks["change_fraction"].T,
        np.clip(risks["new_hole_pixels"].T / 64.0, 0.0, 4.0),
        risks["component_removal"].T,
    ), axis=2)
    candidate_count = candidates.shape[0]
    identities = np.broadcast_to(np.eye(candidate_count, dtype=np.float32)[None], (*descriptors.shape[:2], candidate_count))
    saturation = np.broadcast_to(saturated[:, None, None].astype(np.float32), (*descriptors.shape[:2], 1))
    features = np.concatenate((
        descriptors, descriptor_delta, baseline,
        *physics_features, risk_features, saturation, identities,
    ), axis=2).astype(np.float64)
    return FeatureSet(features=features, risks=risks)


def fit_ridge(
    groups: list[tuple[np.ndarray, np.ndarray, float]],
    regularization: float,
) -> RidgeModel:
    flat_features = np.concatenate([features.reshape(-1, features.shape[-1]) for features, _, _ in groups])
    flat_targets = np.concatenate([targets.reshape(-1) for _, targets, _ in groups])
    weights = np.concatenate([
        np.full(features.shape[0] * features.shape[1], group_weight / (features.shape[0] * features.shape[1]))
        for features, _, group_weight in groups
    ])
    weight_sum = max(float(weights.sum()), 1e-12)
    mean = np.sum(flat_features * weights[:, None], axis=0) / weight_sum
    variance = np.sum(np.square(flat_features - mean) * weights[:, None], axis=0) / weight_sum
    scale = np.sqrt(variance).clip(min=1e-5)
    standardized = (flat_features - mean) / scale
    design = np.concatenate((np.ones((len(standardized), 1)), standardized), axis=1)
    root_weight = np.sqrt(weights * len(weights) / weight_sum)
    weighted_design = design * root_weight[:, None]
    weighted_target = flat_targets * root_weight
    penalty = np.eye(design.shape[1]) * regularization
    penalty[0, 0] = 0.0
    coefficients = np.linalg.solve(
        weighted_design.T @ weighted_design + penalty,
        weighted_design.T @ weighted_target,
    )
    return RidgeModel(mean=mean, scale=scale, coefficients=coefficients)


def select_candidates(
    candidates: np.ndarray,
    scores: np.ndarray,
    risks: dict[str, np.ndarray],
    threshold: float,
    max_change: float,
    max_removal: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    relative = scores - scores[:, :1]
    eligible = risks["change_fraction"].T <= max_change
    eligible &= risks["component_removal"].T <= max_removal
    eligible &= risks["new_hole_pixels"].T == 0
    eligible[:, 0] = True
    masked = np.where(eligible, relative, -np.inf)
    choice = masked.argmax(axis=1)
    gain = masked[np.arange(len(choice)), choice]
    choice[gain < threshold] = 0
    return candidates[choice, np.arange(len(choice))], choice, gain


def calibrate_fold(
    public_train_features: np.ndarray,
    public_train_targets: np.ndarray,
    public_validation_candidates: np.ndarray,
    public_validation_truths: np.ndarray,
    public_validation_features: FeatureSet,
    synthetic_train: list[tuple[np.ndarray, np.ndarray]],
    base_validation: SplitArrays,
    stress_validation: SplitArrays,
    base_validation_features: FeatureSet,
    stress_validation_features: FeatureSet,
) -> tuple[RidgeModel, dict[str, object], list[dict[str, object]]]:
    base_reference = metric_for(base_validation, base_validation.candidates[0])
    stress_reference = metric_for(stress_validation, stress_validation.candidates[0])
    rows: list[dict[str, object]] = []
    best: tuple[tuple[float, ...], RidgeModel, dict[str, object]] | None = None
    for public_weight in (0.65, 0.85, 0.95):
        remaining = 1.0 - public_weight
        for regularization in (0.10, 1.0, 10.0):
            model = fit_ridge([
                (public_train_features, public_train_targets, public_weight),
                (synthetic_train[0][0], synthetic_train[0][1], remaining * 0.45),
                (synthetic_train[1][0], synthetic_train[1][1], remaining * 0.55),
            ], regularization)
            public_scores = model.predict(public_validation_features.features)
            base_scores = model.predict(base_validation_features.features)
            stress_scores = model.predict(stress_validation_features.features)
            for threshold in (0.0, 0.005, 0.02, 1.0):
                for max_change in (0.075, 1.0):
                    for max_removal in (0.30, 1.0):
                        public_prediction, public_choice, _ = select_candidates(
                            public_validation_candidates, public_scores,
                            public_validation_features.risks, threshold, max_change, max_removal,
                        )
                        base_prediction, base_choice, _ = select_candidates(
                            base_validation.candidates, base_scores, base_validation_features.risks,
                            threshold, max_change, max_removal,
                        )
                        stress_prediction, stress_choice, _ = select_candidates(
                            stress_validation.candidates, stress_scores, stress_validation_features.risks,
                            threshold, max_change, max_removal,
                        )
                        public_iou = float(foreground_iou_per_case(public_validation_truths, public_prediction).mean())
                        base_metric = metric_for(base_validation, base_prediction)
                        stress_metric = metric_for(stress_validation, stress_prediction)
                        eligible = (
                            base_metric["foreground_iou"] >= base_reference["foreground_iou"] - 0.004
                            and base_metric["boundary_f1"] >= base_reference["boundary_f1"] - 0.006
                            and stress_metric["foreground_iou"] >= stress_reference["foreground_iou"] - 0.007
                            and stress_metric["bank_retention"] >= stress_reference["bank_retention"] - 0.018
                        )
                        row: dict[str, object] = {
                            "public_weight": public_weight, "regularization": regularization,
                            "score_threshold": threshold, "max_change_fraction": max_change,
                            "max_component_removal": max_removal, "eligible": bool(eligible),
                            "public_validation_iou": public_iou,
                            "base_validation_iou": base_metric["foreground_iou"],
                            "stress_validation_iou": stress_metric["foreground_iou"],
                            "stress_open_deep": stress_metric["open_deep_cutout_recovery"],
                            "stress_bank": stress_metric["bank_retention"],
                            "public_changed": int(np.count_nonzero(public_choice)),
                            "base_changed": int(np.count_nonzero(base_choice)),
                            "stress_changed": int(np.count_nonzero(stress_choice)),
                        }
                        rows.append(row)
                        key = (
                            1.0 if eligible else 0.0, public_iou,
                            stress_metric["open_deep_cutout_recovery"],
                            stress_metric["foreground_iou"], base_metric["foreground_iou"],
                            -float(np.count_nonzero(public_choice)),
                        )
                        if best is None or key > best[0]:
                            best = (key, model, row)
    assert best is not None
    return best[1], best[2], rows


def save_montage(
    path: Path,
    truths: np.ndarray,
    baseline: np.ndarray,
    prediction: np.ndarray,
    oracle: np.ndarray,
    choices: np.ndarray,
    ids: np.ndarray,
    selected: np.ndarray,
) -> None:
    before = foreground_iou_per_case(truths, baseline)
    after = foreground_iou_per_case(truths, prediction)
    best = foreground_iou_per_case(truths, oracle)
    figure, axes = plt.subplots(len(selected), 5, figsize=(12.0, 2.3 * len(selected)), squeeze=False)
    for row, index in enumerate(selected):
        removed = (baseline[index] != 0) & (prediction[index] == 0)
        panels = (
            (truths[index], f"{ids[index]} truth", "viridis", 2),
            (baseline[index], f"baseline IoU {before[index]:.3f}", "viridis", 2),
            (prediction[index], f"ridge choice {choices[index]}\nIoU {after[index]:.3f}", "viridis", 2),
            (oracle[index], f"pool oracle\nIoU {best[index]:.3f}", "viridis", 2),
            (removed, "removed foreground", "magma", 1),
        )
        for column, (image, title, cmap, high) in enumerate(panels):
            axes[row, column].imshow(image, cmap=cmap, vmin=0, vmax=high, interpolation="nearest")
            axes[row, column].set_title(title, fontsize=8)
            axes[row, column].set_axis_off()
    figure.suptitle("KTC2023 strict inward: complete-level-held-out low-capacity ranking", y=0.995)
    figure.subplots_adjust(top=0.97, hspace=0.28, wspace=0.08)
    figure.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(figure)


def casewise_oracle(truths: np.ndarray, candidates: np.ndarray) -> np.ndarray:
    scores = np.stack([foreground_iou_per_case(truths, candidate) for candidate in candidates])
    choice = scores.argmax(axis=0)
    return candidates[choice, np.arange(len(choice))]


def public_group_metrics(
    name: str,
    selected: np.ndarray,
    truths: np.ndarray,
    baseline: np.ndarray,
    prediction: np.ndarray,
    oracle: np.ndarray,
    ids: np.ndarray,
    repetitions: int,
    seed: int,
) -> dict[str, object]:
    result: dict[str, object] = {}
    for method, values in (("baseline", baseline), ("ridge_ranker", prediction), ("oracle", oracle)):
        result[method], _ = evaluate_real_predictions(name + "_" + method, values[selected], truths[selected], ids[selected])
    result["bootstrap_iou"] = paired_bootstrap(
        truths[selected], baseline[selected], prediction[selected], repetitions, seed,
    )
    return result


def main() -> None:
    args = parse_args()
    rng = np.random.default_rng(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    base = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    pool_dir = args.pool_dir.resolve()
    names, base_train = prepare_split("base_train", "base", base, pool_dir)
    _, stress_train = prepare_split("stress_train", "stress", stress, pool_dir)
    _, base_validation = prepare_split("base_validation", "base", base, pool_dir)
    _, stress_validation = prepare_split("stress_validation", "stress", stress, pool_dir)
    _, base_test = prepare_split("base_test", "base", base, pool_dir)
    _, stress_test = prepare_split("stress_test", "stress", stress, pool_dir)
    public_names, public_indices, public_candidates = load_pool(pool_dir / "public_21.npz")
    if names != public_names or not np.array_equal(public_indices, np.arange(len(public_indices))):
        raise ValueError("candidate ordering mismatch")

    base_selected = np.sort(rng.choice(len(base_train.indices), min(args.base_train_samples, len(base_train.indices)), replace=False))
    stress_selected = np.sort(rng.choice(len(stress_train.indices), min(args.stress_train_samples, len(stress_train.indices)), replace=False))
    base_train = subset_split(base_train, base_selected, "base_train_subset")
    stress_train = subset_split(stress_train, stress_selected, "stress_train_subset")
    print("building synthetic low-dimensional features", flush=True)
    base_train_features = build_features(base_train.images, base_train.voltages, base_train.candidates, base)
    stress_train_features = build_features(stress_train.images, stress_train.voltages, stress_train.candidates, stress)
    base_validation_features = build_features(base_validation.images, base_validation.voltages, base_validation.candidates, base)
    stress_validation_features = build_features(stress_validation.images, stress_validation.voltages, stress_validation.candidates, stress)
    synthetic_train = [
        (base_train_features.features, candidate_targets(base_train.truths, base_train.candidates)),
        (stress_train_features.features, candidate_targets(stress_train.truths, stress_train.candidates)),
    ]

    ids = np.asarray(base["real_ids"])
    levels = np.asarray([str(case_id).split("/")[0] for case_id in ids])
    unique_levels = sorted(set(levels))
    print("building public features without labels", flush=True)
    public_features = build_features(
        np.asarray(base["real_linear_images"]), np.asarray(base["real_voltages"]), public_candidates, base
    )
    prediction = np.zeros_like(public_candidates[0])
    choices = np.zeros(len(ids), dtype=np.int64)
    predicted = np.zeros(len(ids), dtype=bool)
    policies: list[dict[str, object]] = []
    fold_count = len(unique_levels) if args.fold_limit <= 0 else min(args.fold_limit, len(unique_levels))
    for fold, outer_level in enumerate(unique_levels[:fold_count]):
        inner_level = unique_levels[(fold + 1) % len(unique_levels)]
        outer = np.flatnonzero(levels == outer_level)
        inner = np.flatnonzero(levels == inner_level)
        train = np.flatnonzero((levels != outer_level) & (levels != inner_level))
        print(f"fold {fold}: train={levels[train].tolist()}, inner={inner_level}, outer={outer_level}", flush=True)
        train_truths = np.asarray(base["real_labels"])[train]
        inner_truths = np.asarray(base["real_labels"])[inner]
        model, policy, grid = calibrate_fold(
            public_features.features[train], candidate_targets(train_truths, public_candidates[:, train]),
            public_candidates[:, inner], inner_truths,
            FeatureSet(public_features.features[inner], {key: values[:, inner] for key, values in public_features.risks.items()}),
            synthetic_train, base_validation, stress_validation,
            base_validation_features, stress_validation_features,
        )
        policy = {"fold": fold, "outer_level": outer_level, "inner_level": inner_level, **policy}
        policies.append(policy)
        write_csv(output_dir / f"fold_{fold}_calibration.csv", grid)
        np.savez_compressed(
            output_dir / f"fold_{fold}_ridge.npz", mean=model.mean, scale=model.scale,
            coefficients=model.coefficients,
        )
        outer_feature_set = FeatureSet(
            public_features.features[outer], {key: values[:, outer] for key, values in public_features.risks.items()}
        )
        fold_prediction, fold_choice, _ = select_candidates(
            public_candidates[:, outer], model.predict(outer_feature_set.features), outer_feature_set.risks,
            float(policy["score_threshold"]), float(policy["max_change_fraction"]),
            float(policy["max_component_removal"]),
        )
        prediction[outer] = fold_prediction
        choices[outer] = fold_choice
        predicted[outer] = True
        print(f"fold {fold} policy={policy}; outer choices={fold_choice.tolist()}", flush=True)
    if not predicted.all():
        prediction[~predicted] = public_candidates[0, ~predicted]
    (output_dir / "fold_policies.json").write_text(json.dumps(policies, indent=2), encoding="utf-8")

    # Outer predictions are frozen before full public truth is evaluated.
    truths = np.asarray(base["real_labels"], dtype=np.uint8)
    baseline = public_candidates[0]
    oracle = casewise_oracle(truths, public_candidates)
    strict = np.asarray([str(case_id) in STRICT_INWARD_IDS for case_id in ids])
    all_mask = predicted if args.fold_limit > 0 else np.ones(len(ids), dtype=bool)
    strict_mask = strict & all_mask
    ordinary_mask = ~strict & all_mask
    differences = foreground_iou_per_case(truths[all_mask], prediction[all_mask]) - foreground_iou_per_case(
        truths[all_mask], baseline[all_mask]
    )
    rows: list[dict[str, object]] = []
    all_before = foreground_iou_per_case(truths, baseline)
    all_after = foreground_iou_per_case(truths, prediction)
    for index in np.flatnonzero(all_mask):
        rows.append({
            "id": str(ids[index]), "strict_inward": bool(strict[index]),
            "choice": int(choices[index]), "candidate": names[int(choices[index])],
            "baseline_iou": float(all_before[index]), "ridge_iou": float(all_after[index]),
            "delta_iou": float(all_after[index] - all_before[index]),
        })
    write_csv(output_dir / "public_case_metrics.csv", rows)
    if strict_mask.any():
        save_montage(
            output_dir / "public_strict_inward_level_cv_ridge.png", truths, baseline,
            prediction, oracle, choices, ids, np.flatnonzero(strict_mask),
        )
    np.savez_compressed(
        output_dir / "predictions.npz", prediction=prediction, choices=choices,
        predicted_mask=predicted, ids=ids,
    )
    summary = {
        "method": "nested complete-level-held-out weighted ridge candidate ranking",
        "outer_folds_completed": fold_count,
        "public_21": public_group_metrics(
            "all", all_mask, truths, baseline, prediction, oracle, ids,
            args.bootstrap_repetitions, args.seed + 10,
        ),
        "public_strict_inward": public_group_metrics(
            "strict", strict_mask, truths, baseline, prediction, oracle, ids,
            args.bootstrap_repetitions, args.seed + 11,
        ) if strict_mask.any() else {},
        "public_ordinary": public_group_metrics(
            "ordinary", ordinary_mask, truths, baseline, prediction, oracle, ids,
            args.bootstrap_repetitions, args.seed + 12,
        ) if ordinary_mask.any() else {},
        "public_changes": {
            "changed": int(np.count_nonzero(choices[all_mask])),
            "improved": int(np.count_nonzero(differences > 1e-6)),
            "harmed": int(np.count_nonzero(differences < -1e-6)),
            "material_improvements": int(np.count_nonzero(differences >= 0.01)),
            "material_harms": int(np.count_nonzero(differences <= -0.01)),
        },
        "fold_policies": policies,
        "leakage_policy": "outer level labels excluded from regression, hyperparameter selection, and acceptance calibration",
        "outer_truth_used_for_training_or_selection": False,
        "seed": args.seed,
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
