"""Final frozen evaluation of topology-safe inward-boundary EIT fusion."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

import finalize_ktc_topology_pixel_fusion as fusion
import finalize_ktc_topology_selective as core
import train_ktc_concavity_network as net
from audit_ktc_instance_bay_topology import case_metrics as bay_metrics


POLICY = {
    "remove_threshold": 0.94,
    "remove_margin": 0.35,
    "vanilla_confidence_cap": 0.88,
    "max_remove_fraction": 0.01,
    "add_threshold": float("inf"),
    "add_margin": 0.10,
    "dilation": 2,
}


def parse_args():
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--checkpoint-dir", type=Path, default=root / "outputs" / "ktc_shape_network_v1")
    parser.add_argument("--output-dir", type=Path, default=Path(r"E:\Codex\ktc_topology_safe_final_cpu"))
    parser.add_argument("--samples-per-seed", type=int, default=420)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--bootstrap", type=int, default=10000)
    return parser.parse_args()


def write_csv(path: Path, rows: list[dict]):
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def evaluate(truths, vanilla, shape, final, group):
    methods = {"vanilla": vanilla, "shape_aware": shape, "topology_safe": final}
    rows = {name: core.per_case_metrics(truths, prediction) for name, prediction in methods.items()}
    summary = {
        name: {
            "all": core.aggregate(values),
            "concave": core.aggregate(values, group),
            "ordinary": core.aggregate(values, ~group),
        }
        for name, values in rows.items()
    }
    base, end = rows["vanilla"], rows["topology_safe"]
    summary["ordinary_harmed_iou_gt_0.01"] = int(sum(
        end[index]["foreground_iou"] < base[index]["foreground_iou"] - 0.01
        for index in np.flatnonzero(~group)
    ))
    summary["concave_improved_notch"] = int(sum(
        end[index]["notch_preservation"] > base[index]["notch_preservation"] + 1e-12
        for index in np.flatnonzero(group)
        if np.isfinite(end[index]["notch_preservation"])
    ))
    summary["changed_cases"] = int(np.sum(np.any(final != vanilla, axis=(1, 2))))
    summary["topology_violations"] = int(sum(
        fusion.topology(end_prediction) != fusion.topology(base_prediction)
        for base_prediction, end_prediction in zip(vanilla, final)
    ))
    return summary, rows


def plot_cases(path, title, ids, truths, images, vanilla, shape, final, indices):
    figure, axes = plt.subplots(len(indices), 6, figsize=(15.2, 2.45 * len(indices)), squeeze=False)
    for row_index, index in enumerate(indices):
        scale = max(float(np.quantile(np.abs(images[index]), 0.99)), 1e-6)
        panels = (truths[index], images[index], vanilla[index], shape[index], final[index])
        names = ("Ground truth", "Linear EIT", "Vanilla U-Net", "Shape-aware U-Net", "Final topology-safe")
        for column, (panel, name) in enumerate(zip(panels, names)):
            if column == 1:
                axes[row_index, column].imshow(panel, cmap="coolwarm", vmin=-scale, vmax=scale)
            else:
                axes[row_index, column].imshow(panel, cmap="viridis", vmin=0, vmax=2)
            if row_index == 0:
                axes[row_index, column].set_title(name, fontsize=10)
            axes[row_index, column].set_axis_off()
        edit = np.zeros((*truths[index].shape, 3), dtype=float)
        edit[:] = (0.06, 0.06, 0.06)
        edit[(vanilla[index] != 0) & (final[index] == 0)] = (1.0, 0.16, 0.60)
        axes[row_index, 5].imshow(edit)
        axes[row_index, 5].set_axis_off()
        if row_index == 0:
            axes[row_index, 5].set_title("Accepted inward edits", fontsize=10)
        base = net.confusion_metrics(truths[index], vanilla[index], net.indentation_mask(truths[index]))
        end = net.confusion_metrics(truths[index], final[index], net.indentation_mask(truths[index]))
        axes[row_index, 0].set_ylabel(
            f"{ids[index]}\nIoU {base['foreground_iou']:.3f} to {end['foreground_iou']:.3f}\n"
            f"Notch {base['notch_preservation']:.3f} to {end['notch_preservation']:.3f}",
            fontsize=8,
        )
    figure.suptitle(title, fontsize=15, y=0.998)
    figure.tight_layout(rect=(0, 0, 1, 0.985))
    figure.savefig(path, dpi=190, bbox_inches="tight")
    plt.close(figure)


def main():
    args = parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    archive = np.load(args.dataset.resolve(), allow_pickle=False)
    device = torch.device("cpu")
    torch.set_num_threads(max(1, min(12, torch.get_num_threads())))
    adapter = net.InputAdapter(archive["fov_mask"]).to(device)
    vanilla_model = net.ConcavityUNet(32, False).to(device)
    shape_model = net.ConcavityUNet(32, True).to(device)
    vanilla_model.load_state_dict(torch.load(args.checkpoint_dir / "vanilla_best.pt", map_location=device, weights_only=False)["model"])
    shape_model.load_state_dict(torch.load(args.checkpoint_dir / "shape_best.pt", map_location=device, weights_only=False)["model"])

    seeds = (20263001, 20263002, 20263003)
    ood_parts = []
    for seed in seeds:
        print(f"biological test seed {seed}", flush=True)
        truths, _, indent, group, _, images = core.generate_biological_ood(
            archive, args.samples_per_seed, seed
        )
        vout = core.infer(vanilla_model, adapter, images, device, args.batch_size)
        sout = core.infer(shape_model, adapter, images, device, args.batch_size)
        vanilla = core.hard_predictions(vout)
        shape = core.hard_predictions(sout)
        final = fusion.fuse_batch(vout, sout, POLICY)
        ood_parts.append((truths, indent, group, images, vanilla, shape, final, seed))

    ood_truths = np.concatenate([part[0] for part in ood_parts])
    ood_indent = np.concatenate([part[1] for part in ood_parts])
    ood_group = np.concatenate([part[2] for part in ood_parts])
    ood_images = np.concatenate([part[3] for part in ood_parts])
    ood_vanilla = np.concatenate([part[4] for part in ood_parts])
    ood_shape = np.concatenate([part[5] for part in ood_parts])
    ood_final = np.concatenate([part[6] for part in ood_parts])
    ood_summary, ood_rows = evaluate(ood_truths, ood_vanilla, ood_shape, ood_final, ood_group)
    ood_bootstrap = {
        "concave": core.bootstrap(ood_rows["vanilla"], ood_rows["topology_safe"], ood_group, args.bootstrap, 20264001),
        "ordinary": core.bootstrap(ood_rows["vanilla"], ood_rows["topology_safe"], ~ood_group, args.bootstrap, 20264002),
    }

    print("KTC public benchmark", flush=True)
    real_vout = core.infer(vanilla_model, adapter, archive["real_linear_images"], device, args.batch_size)
    real_sout = core.infer(shape_model, adapter, archive["real_linear_images"], device, args.batch_size)
    real_vanilla = core.resize_predictions(core.hard_predictions(real_vout))
    real_shape = core.resize_predictions(core.hard_predictions(real_sout))
    real_final = core.resize_predictions(fusion.fuse_batch(real_vout, real_sout, POLICY))
    real_ids = np.asarray(archive["real_ids"])
    strict = np.asarray([str(value) in core.STRICT_IDS for value in real_ids])
    real_summary, real_rows = evaluate(
        archive["real_labels"], real_vanilla, real_shape, real_final, strict
    )
    real_bootstrap = {
        "strict_inward": core.bootstrap(real_rows["vanilla"], real_rows["topology_safe"], strict, args.bootstrap, 20264003),
        "ordinary": core.bootstrap(real_rows["vanilla"], real_rows["topology_safe"], ~strict, args.bootstrap, 20264004),
    }

    rows = []
    for index, case_id in enumerate(real_ids):
        for method in ("vanilla", "shape_aware", "topology_safe"):
            prediction = {"vanilla": real_vanilla, "shape_aware": real_shape, "topology_safe": real_final}[method][index]
            rows.append({
                "id": str(case_id), "method": method, "strict_inward": bool(strict[index]),
                **real_rows[method][index],
                **{f"bay_{key}": value for key, value in bay_metrics(archive["real_labels"][index], prediction).items()},
            })
    write_csv(output / "ktc_case_metrics.csv", rows)

    ood_case_rows = []
    for index in range(len(ood_truths)):
        seed_index = index // args.samples_per_seed
        for method in ("vanilla", "shape_aware", "topology_safe"):
            ood_case_rows.append({
                "seed": seeds[seed_index], "index": index % args.samples_per_seed,
                "method": method, "concave": bool(ood_group[index]), **ood_rows[method][index],
            })
    write_csv(output / "biological_case_metrics.csv", ood_case_rows)

    strict_indices = np.flatnonzero(strict)
    plot_cases(
        output / "ktc_strict_inward_all.png",
        "KTC public strict inward-boundary cases: frozen topology-safe fusion",
        real_ids, archive["real_labels"], archive["real_linear_images"],
        real_vanilla, real_shape, real_final, strict_indices,
    )
    first_concave = np.flatnonzero(ood_group)[:6]
    first_ordinary = np.flatnonzero(~ood_group)[:3]
    ood_ids = np.asarray([f"seed {seeds[i // args.samples_per_seed]} / {i % args.samples_per_seed}" for i in range(len(ood_truths))])
    plot_cases(
        output / "biological_preregistered_examples.png",
        "Unseen cell-like EIT cases: fixed-order representative examples",
        ood_ids, ood_truths, ood_images, ood_vanilla, ood_shape, ood_final,
        np.r_[first_concave, first_ordinary],
    )
    notch_gain = np.asarray([
        ood_rows["topology_safe"][i]["notch_preservation"] - ood_rows["vanilla"][i]["notch_preservation"]
        if ood_group[i] else -np.inf for i in range(len(ood_truths))
    ])
    visible = np.argsort(notch_gain)[-8:][::-1]
    plot_cases(
        output / "biological_largest_notch_recovery.png",
        "Unseen cell-like EIT: largest recovered inward-boundary examples",
        ood_ids, ood_truths, ood_images, ood_vanilla, ood_shape, ood_final, visible,
    )

    np.savez_compressed(
        output / "final_predictions.npz",
        seeds=np.asarray(seeds), ood_truths=ood_truths, ood_group=ood_group,
        ood_vanilla=ood_vanilla, ood_shape=ood_shape, ood_final=ood_final,
        real_ids=real_ids, real_truths=archive["real_labels"],
        real_vanilla=real_vanilla, real_shape=real_shape, real_final=real_final,
    )
    result = {
        "method": "vanilla-protected, reliability-gated, topology-safe local inward fusion",
        "policy": POLICY,
        "selection": {
            "selected_from_synthetic_validation_and_independent_cell_like_development": True,
            "official_training_cases_used_only_as_ordinary_safety_calibration": True,
            "KTC_public_benchmark_truth_used_for_policy_selection": False,
            "fine_tuning_attempt_accepted": False,
        },
        "biological_test_seeds": list(seeds),
        "biological_ood": ood_summary,
        "biological_ood_bootstrap": ood_bootstrap,
        "ktc_public_benchmark": real_summary,
        "ktc_public_bootstrap": real_bootstrap,
    }
    (output / "summary.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
