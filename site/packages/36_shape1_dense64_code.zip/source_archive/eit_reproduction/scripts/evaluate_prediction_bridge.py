"""Evaluate an external-background bridge between two saved EIT predictions.

The aggressive Boolean prediction is used only as a connectivity cue.  Pixels
that are already background in the balanced prediction are untouched; only the
new background corridor of an exterior-connected component is written back.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import binary_dilation, label as connected_components

from prepare_ktc_deep_concavity_stress import FAMILIES
from train_ktc_implicit_boolean_network import prepare_structural_arrays, standard_metrics, stress_metrics


STRUCTURE = np.ones((3, 3), dtype=np.uint8)


def bridge_prediction(
    balanced: np.ndarray,
    aggressive: np.ndarray,
    dilation_radius: int,
    min_core_pixels: int,
) -> tuple[np.ndarray, np.ndarray]:
    result = balanced.copy()
    bridges = np.zeros(balanced.shape, dtype=bool)
    for index, (body, raw) in enumerate(zip(balanced, aggressive)):
        body_foreground = body != 0
        raw_background = raw == 0
        components, count = connected_components(raw_background, structure=STRUCTURE)
        border_labels = np.unique(
            np.concatenate((components[0], components[-1], components[:, 0], components[:, -1]))
        )
        exterior = np.isin(components, border_labels[border_labels != 0])
        # A narrow dilation of the body is a conservative support proxy. It
        # prevents a large raw false-positive background island from eating an
        # entire bank while still allowing a one-to-several-pixel mouth.
        support = binary_dilation(body_foreground, structure=STRUCTURE, iterations=dilation_radius)
        body_holes = (~body_foreground) & support
        for component_id in np.unique(components[exterior & body_holes]):
            if component_id == 0:
                continue
            component = components == component_id
            core = component & body_holes
            if int(core.sum()) < min_core_pixels:
                continue
            bridge = component & support & body_foreground
            result[index][bridge] = 0
            bridges[index] |= bridge
    return result, bridges


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--predictions", type=Path,
        default=root / "outputs" / "ktc_openmouth_boolean_balanced_seed20260819" / "predictions.npz",
    )
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument(
        "--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz"
    )
    parser.add_argument(
        "--output-dir", type=Path, default=root / "outputs" / "ktc_prediction_bridge_seed20260819"
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    prediction_archive = np.load(args.predictions.resolve(), allow_pickle=False)
    base_archive = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress_archive = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    base = prepare_structural_arrays(base_archive, "base")
    stress = prepare_structural_arrays(stress_archive, "stress")
    base_indices = np.asarray(prediction_archive["base_test_indices"], dtype=np.int64)
    stress_indices = np.asarray(prediction_archive["stress_test_indices"], dtype=np.int64)
    rows = []
    best = None
    for radius in (1, 2, 3, 4, 5):
        for min_core in (2, 4, 8, 12):
            base_pred, base_bridge = bridge_prediction(
                prediction_archive["base_calibrated"], prediction_archive["base_v1"], radius, min_core
            )
            stress_pred, stress_bridge = bridge_prediction(
                prediction_archive["stress_calibrated"], prediction_archive["stress_v1"], radius, min_core
            )
            base_metric = standard_metrics(base.labels[base_indices], base_pred, base.indentation[base_indices])
            stress_metric, family_metric, _ = stress_metrics(
                stress.labels[stress_indices], stress_pred,
                stress.cutout[stress_indices], stress.cutout_depth[stress_indices], stress.family_codes[stress_indices]
            )
            deep_c = family_metric["deep_c"]
            eligible = (
                base_metric["foreground_iou"] >= 0.58
                and stress_metric["foreground_iou"] >= 0.585
                and stress_metric["bank_retention"] >= 0.70
            )
            row = {
                "dilation_radius": radius,
                "min_core_pixels": min_core,
                "eligible": eligible,
                "base_iou": base_metric["foreground_iou"],
                "stress_iou": stress_metric["foreground_iou"],
                "stress_open_deep_cutout": stress_metric["open_deep_cutout_recovery"],
                "stress_bank_retention": stress_metric["bank_retention"],
                "stress_topology_joint": stress_metric["topology_structural_joint"],
                "deep_c_open_deep_cutout": deep_c["open_deep_cutout_recovery"],
                "deep_c_bank_retention": deep_c["bank_retention"],
                "bridge_fraction": float(stress_bridge.mean()),
            }
            rows.append(row)
            if eligible and (best is None or (row["stress_topology_joint"], row["deep_c_open_deep_cutout"]) > (best["stress_topology_joint"], best["deep_c_open_deep_cutout"])):
                best = row
    if best is None:
        best = max(rows, key=lambda row: (row["stress_topology_joint"], row["deep_c_open_deep_cutout"]))
    base_pred, base_bridge = bridge_prediction(
        prediction_archive["base_calibrated"], prediction_archive["base_v1"], best["dilation_radius"], best["min_core_pixels"]
    )
    stress_pred, stress_bridge = bridge_prediction(
        prediction_archive["stress_calibrated"], prediction_archive["stress_v1"], best["dilation_radius"], best["min_core_pixels"]
    )
    base_metric = standard_metrics(base.labels[base_indices], base_pred, base.indentation[base_indices])
    stress_metric, family_metric, _ = stress_metrics(
        stress.labels[stress_indices], stress_pred,
        stress.cutout[stress_indices], stress.cutout_depth[stress_indices], stress.family_codes[stress_indices]
    )
    np.savez_compressed(
        args.output_dir / "predictions.npz", base_bridge=base_pred, stress_bridge=stress_pred,
        base_bridge_mask=base_bridge, stress_bridge_mask=stress_bridge,
    )
    (args.output_dir / "grid.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
    (args.output_dir / "summary.json").write_text(json.dumps({"selected": best, "base": base_metric, "stress": stress_metric, "stress_by_family": family_metric}, indent=2), encoding="utf-8")
    print(json.dumps({"selected": best, "base": base_metric, "stress": stress_metric, "deep_c": family_metric["deep_c"]}, indent=2))


if __name__ == "__main__":
    main()
