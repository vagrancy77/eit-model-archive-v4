"""Nested pairwise physics/topology ranker for exterior-connected concave bays.

The public label cache is used only inside complete-level training folds and
inside the corresponding inner calibration folds. Candidate generation,
candidate-front compression, and all inference features are label-free.
Strict-concavity IDs are opened only after every outer-fold prediction is
frozen.
"""
from __future__ import annotations

import argparse
import copy
import csv
import itertools
import json
import random
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from audit_ktc_instance_bay_topology import case_metrics, edit_metrics, paired_bootstrap
from train_ktc_instance_bay_nested_ranker import (
    STRICT_INWARD_IDS,
    boundary_f1_per_case,
    foreground_iou_per_case,
    save_montage,
    topology_checks,
)
from train_ktc_setaware_pure_bay_oof import (
    CLASS_NAMES,
    TARGET_NAMES,
    PublicCase,
    class_targets,
    load_public_cases,
)
from train_ktc_synthetic_bay_risk_ranker import RiskRankVerifier


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument(
        "--cache-dir", type=Path,
        default=Path(r"E:\Codex\ktc_expanded_pure_bay_candidate_cache_seed20260820"),
    )
    parser.add_argument(
        "--target-dir", type=Path,
        default=Path(r"E:\Codex\ktc_expanded_pure_bay_training_targets_seed20260820"),
    )
    parser.add_argument(
        "--pretrained", type=Path,
        default=Path(r"E:\Codex\ktc_synthetic_pure_bay_physics_ranker_seed20260820")
        / "synthetic_bay_risk_ranker.pt",
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=Path(r"E:\Codex\ktc_pairwise_topology_bay_oof_seed20260820"),
    )
    parser.add_argument("--epochs", type=int, default=80)
    parser.add_argument("--ensemble-size", type=int, default=3)
    parser.add_argument("--case-batch-size", type=int, default=4)
    parser.add_argument("--front-size", type=int, default=1536)
    parser.add_argument("--positives-per-case", type=int, default=24)
    parser.add_argument("--hard-negatives-per-case", type=int, default=72)
    parser.add_argument("--random-negatives-per-case", type=int, default=72)
    parser.add_argument("--learning-rate", type=float, default=2e-4)
    parser.add_argument("--weight-decay", type=float, default=2e-4)
    parser.add_argument("--bootstrap-repetitions", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260820)
    parser.add_argument("--front-audit-only", action="store_true")
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def robust_standardize(values: np.ndarray) -> np.ndarray:
    median = np.median(values, axis=0)
    scale = np.median(np.abs(values - median), axis=0) * 1.4826
    scale = np.where(scale > 1e-5, scale, np.std(values, axis=0))
    scale = np.maximum(scale, 1e-5)
    return np.clip((values - median) / scale, -8.0, 8.0)


def physics_priority(features: np.ndarray) -> np.ndarray:
    """A weak label-free priority used only to seed a diverse candidate front."""
    axes = np.column_stack((
        features[:, 76], features[:, 78], features[:, 80],
        features[:, 81:85].mean(1),
        features[:, 98:111].mean(1),
        features[:, 114], features[:, 115],
        features[:, 117], -features[:, 118],
        features[:, 19], features[:, 20], features[:, 21],
    ))
    z = robust_standardize(axes)
    weights = np.asarray((
        0.80, 0.45, 0.35, 0.45, 0.35, 0.30, 0.20,
        0.65, 0.30, 0.20, 0.15, 0.35,
    ))
    return np.asarray(z @ weights, dtype=np.float32)


def family_keys(features: np.ndarray) -> np.ndarray:
    class_id = np.argmax(features[:, 138:141], axis=1)
    component = np.argmax(features[:, 141:145], axis=1)
    profile = np.argmax(features[:, 145:149], axis=1)
    angle = np.arctan2(features[:, 125], features[:, 126])
    angle_bin = np.mod(np.rint(angle / (2 * np.pi / 16)).astype(np.int64), 16)
    return np.column_stack((class_id, component, profile, angle_bin))


def candidate_front(case: PublicCase, max_size: int) -> np.ndarray:
    """Build a label-free physics-seeded, geometry-stratified candidate front."""
    valid = np.flatnonzero(case.valid)
    if len(valid) <= max_size:
        return valid
    features = case.features[valid]
    priority = physics_priority(features)
    keys = family_keys(features)
    removed = case.removed[valid]
    depth = features[:, 127]
    width = features[:, 128]

    selected: set[int] = {0}
    # Preserve extremes of each independent evidence channel.
    evidence_columns = (76, 78, 80, 81, 82, 83, 84, 114, 115, 117, 19, 20, 21)
    for column in evidence_columns:
        values = features[:, column]
        selected.update(np.argsort(values)[-8:].tolist())
    selected.update(np.argsort(priority)[-32:].tolist())

    # Preserve representatives from every component/profile/angle family.
    for key in np.unique(keys, axis=0):
        group = np.flatnonzero(np.all(keys == key, axis=1))
        if not len(group):
            continue
        selected.add(int(group[np.argmax(priority[group])]))
        selected.add(int(group[np.argmin(removed[group])]))
        for values in (depth, width):
            order = group[np.argsort(values[group])]
            selected.add(int(order[len(order) // 2]))

    geometry_columns = np.r_[0:24, 72:85, 117:135]
    geometry = robust_standardize(features[:, geometry_columns]).astype(np.float32)
    selected_list = sorted(selected)
    if len(selected_list) > max_size:
        core = sorted({0, *np.argsort(priority)[-48:].tolist()})
        pool = np.asarray([value for value in selected_list if value not in set(core)], dtype=np.int64)
        selected_list = core
    else:
        pool = np.asarray([value for value in range(len(valid)) if value not in selected], dtype=np.int64)

    # Greedy farthest-point filling avoids hundreds of near-duplicate bays.
    chosen = np.asarray(selected_list, dtype=np.int64)
    if len(chosen):
        minimum_distance = np.full(len(valid), np.inf, dtype=np.float32)
        for start in range(0, len(chosen), 64):
            block = geometry[chosen[start:start + 64]]
            distances = np.square(geometry[:, None] - block[None]).mean(2)
            minimum_distance = np.minimum(minimum_distance, distances.min(1))
    else:
        minimum_distance = np.full(len(valid), np.inf, dtype=np.float32)
    available = np.ones(len(valid), dtype=bool)
    available[chosen] = False
    if len(pool):
        allowed = np.zeros(len(valid), dtype=bool)
        allowed[pool] = True
        available &= allowed
    while len(selected_list) < max_size and np.any(available):
        # A small priority term resolves geometric ties with physical evidence.
        normalized_priority = (priority - priority.min()) / max(float(np.ptp(priority)), 1e-6)
        next_index = int(np.argmax(np.where(
            available, minimum_distance + 0.03 * normalized_priority, -np.inf
        )))
        selected_list.append(next_index)
        available[next_index] = False
        distance = np.square(geometry - geometry[next_index]).mean(1)
        minimum_distance = np.minimum(minimum_distance, distance)
    return valid[np.asarray(sorted(set(selected_list)), dtype=np.int64)]


def material_mask(targets: np.ndarray) -> np.ndarray:
    finite_bay = np.isfinite(targets[:, 2])
    finite_depth = np.isfinite(targets[:, 4])
    return (
        (targets[:, 0] >= 0.002) & (targets[:, 1] >= -0.005)
        & finite_bay & (targets[:, 2] >= 0.030)
        & (~finite_depth | (targets[:, 4] >= -0.020))
    )


def target_utility(targets: np.ndarray, removed: np.ndarray) -> np.ndarray:
    bay = np.nan_to_num(targets[:, 2])
    depth = np.nan_to_num(targets[:, 4])
    value = targets[:, 0] + 0.25 * targets[:, 1] + 0.80 * bay + 0.12 * depth
    value -= (
        7.0 * np.maximum(-targets[:, 0], 0.0)
        + 2.0 * np.maximum(-0.005 - targets[:, 1], 0.0)
        + 3.0 * np.maximum(-bay, 0.0)
        + np.maximum(-0.020 - depth, 0.0)
    )
    value -= 0.015 * removed
    return np.asarray(value, dtype=np.float32)


def training_scores(case: PublicCase, indices: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    targets = case.targets[indices]
    material = material_mask(targets)
    values = target_utility(targets, case.removed[indices])
    if not np.any(material):
        values = np.minimum(values, -0.01 - 0.05 * case.removed[indices])
        values[indices == 0] = 0.0
    else:
        values[~material] -= 0.025
        values[indices == 0] = 0.0
    return values, material


class PairwiseTopologyRanker(nn.Module):
    def __init__(self, pretrained_state: dict[str, torch.Tensor]) -> None:
        super().__init__()
        source = RiskRankVerifier(150)
        source.load_state_dict(pretrained_state)
        self.encoder = copy.deepcopy(source.trunk)
        self.context_norm = nn.LayerNorm(96 * 4)
        self.candidate = nn.Sequential(
            nn.Linear(96 * 6, 256), nn.LayerNorm(256), nn.SiLU(), nn.Dropout(0.08),
            nn.Linear(256, 160), nn.LayerNorm(160), nn.SiLU(),
            nn.Linear(160, 96), nn.SiLU(),
        )
        self.score = nn.Linear(96, 1)
        self.regression = nn.Linear(96, len(TARGET_NAMES))
        self.classification = nn.Linear(96, len(CLASS_NAMES))
        self.case_head = nn.Sequential(
            nn.Linear(96 * 4, 128), nn.SiLU(), nn.Dropout(0.08), nn.Linear(128, 1)
        )

    def forward(self, features: torch.Tensor):
        latent = self.encoder(features)
        base = latent[:1]
        context = self.context_norm(torch.cat((
            base.squeeze(0), latent.mean(0), latent.max(0).values, latent.min(0).values,
        )))
        joined = torch.cat((
            latent, latent - base, context.expand(len(latent), -1),
        ), dim=1)
        candidate = self.candidate(joined)
        return (
            self.score(candidate).squeeze(1),
            self.regression(candidate),
            self.classification(candidate),
            self.case_head(context).squeeze(0),
        )


def target_normalization(cases: list[PublicCase], fronts: dict[str, np.ndarray]):
    rows = np.concatenate([case.targets[fronts[case.case_id]] for case in cases])
    mean = np.asarray([np.nanmean(rows[:, i]) for i in range(rows.shape[1])], dtype=np.float32)
    scale = np.asarray([np.nanstd(rows[:, i]) for i in range(rows.shape[1])], dtype=np.float32)
    return mean, np.maximum(scale, 1e-4)


def positive_weights(cases: list[PublicCase], fronts: dict[str, np.ndarray]) -> tuple[np.ndarray, float]:
    rows = np.concatenate([
        class_targets(case.targets[fronts[case.case_id]]) for case in cases
    ])
    positive = rows.sum(0)
    weights = np.clip((len(rows) - positive) / np.maximum(positive, 1), 1, 40).astype(np.float32)
    action = sum(np.any(material_mask(case.targets[fronts[case.case_id]])) for case in cases)
    action_weight = float(np.clip((len(cases) - action) / max(action, 1), 1, 12))
    return weights, action_weight


def balanced_positions(
    scores: torch.Tensor, values: np.ndarray, material: np.ndarray,
    args: argparse.Namespace, rng: np.random.Generator,
) -> np.ndarray:
    count = len(values)
    positives = np.flatnonzero(material)
    if len(positives):
        positives = positives[np.argsort(values[positives])[-args.positives_per_case:]]
    else:
        positives = np.asarray([0], dtype=np.int64)
    excluded = np.zeros(count, dtype=bool)
    excluded[positives] = True
    negative = np.flatnonzero(~excluded)
    predicted = scores.detach().cpu().numpy()
    hard_predicted = negative[np.argsort(predicted[negative])[-args.hard_negatives_per_case:]]
    hard_target = negative[np.argsort(values[negative])[-args.hard_negatives_per_case // 2:]]
    random_count = min(args.random_negatives_per_case, len(negative))
    random_negative = rng.choice(negative, random_count, replace=False) if random_count else np.empty(0, int)
    return np.unique(np.concatenate(([0], positives, hard_predicted, hard_target, random_negative)))


def pairwise_loss(
    scores: torch.Tensor, values: np.ndarray, material: np.ndarray,
    positions: np.ndarray, rng: np.random.Generator,
) -> torch.Tensor:
    positives = np.flatnonzero(material)
    if len(positives):
        positives = positives[np.argsort(values[positives])[-24:]]
    else:
        positives = np.asarray([0], dtype=np.int64)
    negative = positions[~np.isin(positions, positives)]
    if not len(negative):
        return scores.sum() * 0.0
    left = np.repeat(positives, len(negative))
    right = np.tile(negative, len(positives))
    gap = values[left] - values[right]
    keep = gap >= 0.005
    left, right, gap = left[keep], right[keep], gap[keep]
    if not len(left):
        return scores.sum() * 0.0
    if len(left) > 768:
        choice = rng.choice(len(left), 768, replace=False)
        left, right, gap = left[choice], right[choice], gap[choice]
    left_t = torch.as_tensor(left, dtype=torch.long, device=scores.device)
    right_t = torch.as_tensor(right, dtype=torch.long, device=scores.device)
    margin = torch.as_tensor(np.clip(gap, 0.01, 0.20), dtype=torch.float32, device=scores.device)
    weights = 1.0 + 2.0 * torch.clamp(margin / 0.10, max=1.0)
    return (weights * F.softplus(-(scores[left_t] - scores[right_t] - margin) / 0.12)).mean()


def train_one(
    cases: list[PublicCase], fronts: dict[str, np.ndarray], pretrained_state: dict[str, torch.Tensor],
    feature_mean: np.ndarray, feature_scale: np.ndarray,
    target_mean: np.ndarray, target_scale: np.ndarray,
    args: argparse.Namespace, seed: int, device: torch.device,
):
    set_seed(seed)
    model = PairwiseTopologyRanker(pretrained_state).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    fm = torch.from_numpy(feature_mean).to(device)
    fs = torch.from_numpy(feature_scale).to(device)
    tm = torch.from_numpy(target_mean).to(device)
    ts = torch.from_numpy(target_scale).to(device)
    pos_weight_np, action_pos_weight = positive_weights(cases, fronts)
    pos_weight = torch.from_numpy(pos_weight_np).to(device)
    action_weight = torch.tensor(action_pos_weight, dtype=torch.float32, device=device)
    rng = np.random.default_rng(seed)
    history = []
    for epoch in range(args.epochs):
        model.train()
        order = rng.permutation(len(cases))
        epoch_losses = []
        for start in range(0, len(order), args.case_batch_size):
            case_losses = []
            for case_number in order[start:start + args.case_batch_size]:
                case = cases[int(case_number)]
                indices = fronts[case.case_id]
                features = torch.from_numpy(case.features[indices]).to(device)
                features = torch.clamp((features - fm) / fs, -12.0, 12.0)
                scores, regression, logits, case_logit = model(features)
                values, material = training_scores(case, indices)
                positions = balanced_positions(scores, values, material, args, rng)
                targets = torch.from_numpy(case.targets[indices][positions]).to(device)
                normalized = (torch.nan_to_num(targets) - tm) / ts
                finite = torch.isfinite(targets)
                regression_loss = F.smooth_l1_loss(
                    regression[positions][finite], normalized[finite], beta=0.35
                )
                classes_np = class_targets(case.targets[indices][positions])
                classes = torch.from_numpy(classes_np).to(device)
                classification_loss = F.binary_cross_entropy_with_logits(
                    logits[positions], classes, pos_weight=pos_weight
                )
                pair_loss = pairwise_loss(scores, values, material, positions, rng)
                value_t = torch.from_numpy(values[positions]).to(device)
                distribution = torch.softmax(value_t / 0.055, dim=0)
                list_loss = -torch.sum(distribution * F.log_softmax(scores[positions], dim=0))
                action_target = torch.tensor(
                    float(np.any(material)), dtype=torch.float32, device=device
                )
                action_loss = F.binary_cross_entropy_with_logits(
                    case_logit.view(()), action_target,
                    pos_weight=action_weight if action_target > 0 else None,
                )
                identity_loss = scores[0].square() + F.smooth_l1_loss(
                    regression[0], -tm / ts, beta=0.35
                )
                case_losses.append(
                    pair_loss + 0.25 * list_loss + 0.35 * regression_loss
                    + 0.30 * classification_loss + 0.35 * action_loss + 0.04 * identity_loss
                )
            loss = torch.stack(case_losses).mean()
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            epoch_losses.append(float(loss.detach()))
        history.append({"epoch": epoch + 1, "loss": float(np.mean(epoch_losses))})
    model.eval()
    return model, history


def train_or_load_ensemble(
    name: str, training: list[PublicCase], fronts: dict[str, np.ndarray],
    pretrained: dict[str, object], args: argparse.Namespace, device: torch.device,
):
    model_dir = args.output_dir.resolve() / "model_cache"
    model_dir.mkdir(parents=True, exist_ok=True)
    path = model_dir / f"{name}.pt"
    history_path = model_dir / f"{name}_history.json"
    if path.exists() and not args.force:
        payload = torch.load(path, map_location=device, weights_only=False)
        models = []
        for member, state in enumerate(payload["models"]):
            model = PairwiseTopologyRanker(
                pretrained["models"][member % len(pretrained["models"])]
            ).to(device)
            model.load_state_dict(state)
            model.eval()
            models.append(model)
        return models, payload["target_mean"], payload["target_scale"]
    target_mean, target_scale = target_normalization(training, fronts)
    models, histories = [], {}
    for member in range(args.ensemble_size):
        seed = args.seed + member
        model, history = train_one(
            training, fronts, pretrained["models"][member % len(pretrained["models"])],
            np.asarray(pretrained["feature_mean"], dtype=np.float32),
            np.asarray(pretrained["feature_scale"], dtype=np.float32),
            target_mean, target_scale, args, seed, device,
        )
        models.append(model)
        histories[str(seed)] = history
    torch.save({
        "models": [model.state_dict() for model in models],
        "target_mean": target_mean, "target_scale": target_scale,
        "training_case_ids": [case.case_id for case in training],
        "front_size": args.front_size,
    }, path)
    history_path.write_text(json.dumps(histories, indent=2), encoding="utf-8")
    return models, target_mean, target_scale


@dataclass
class Evidence:
    score: np.ndarray
    score_std: np.ndarray
    regression: np.ndarray
    regression_std: np.ndarray
    probability: np.ndarray
    probability_std: np.ndarray
    case_probability: float
    case_probability_std: float


@torch.no_grad()
def predict_case(
    case: PublicCase, front: np.ndarray, models: list[PairwiseTopologyRanker],
    pretrained: dict[str, object], target_mean: np.ndarray, target_scale: np.ndarray,
    device: torch.device,
) -> Evidence:
    fm = torch.from_numpy(np.asarray(pretrained["feature_mean"], dtype=np.float32)).to(device)
    fs = torch.from_numpy(np.asarray(pretrained["feature_scale"], dtype=np.float32)).to(device)
    features = torch.from_numpy(case.features[front]).to(device)
    features = torch.clamp((features - fm) / fs, -12.0, 12.0)
    scores, regressions, probabilities, case_probabilities = [], [], [], []
    for model in models:
        score, regression, logits, case_logit = model(features)
        scores.append((score - score[:1]).cpu().numpy())
        regressions.append(regression.cpu().numpy() * target_scale + target_mean)
        probabilities.append(torch.sigmoid(logits).cpu().numpy())
        case_probabilities.append(float(torch.sigmoid(case_logit)))
    count = len(case.features)
    score_mean = np.full(count, -np.inf, dtype=np.float32)
    score_std = np.full(count, np.inf, dtype=np.float32)
    regression_mean = np.full((count, len(TARGET_NAMES)), -np.inf, dtype=np.float32)
    regression_std = np.full((count, len(TARGET_NAMES)), np.inf, dtype=np.float32)
    probability_mean = np.zeros((count, len(CLASS_NAMES)), dtype=np.float32)
    probability_std = np.full((count, len(CLASS_NAMES)), np.inf, dtype=np.float32)
    score_matrix = np.stack(scores)
    regression_matrix = np.stack(regressions)
    probability_matrix = np.stack(probabilities)
    score_mean[front], score_std[front] = score_matrix.mean(0), score_matrix.std(0)
    regression_mean[front] = regression_matrix.mean(0)
    regression_std[front] = regression_matrix.std(0)
    probability_mean[front] = probability_matrix.mean(0)
    probability_std[front] = probability_matrix.std(0)
    score_mean[0] = score_std[0] = 0.0
    regression_mean[0] = regression_std[0] = 0.0
    return Evidence(
        score_mean, score_std, regression_mean, regression_std,
        probability_mean, probability_std,
        float(np.mean(case_probabilities)), float(np.std(case_probabilities)),
    )


@dataclass(frozen=True)
class Policy:
    case_probability: float
    safe_probability: float
    joint_probability: float
    score_margin: float
    uncertainty: float
    max_removal: float


POLICIES = tuple(
    Policy(case, safe, joint, margin, uncertainty, removal)
    for case in (0.50, 0.65, 0.80, 0.90)
    for safe in (0.55, 0.65, 0.75, 0.85)
    for joint in (0.30, 0.45, 0.60, 0.75)
    for margin in (0.00, 0.04, 0.08)
    for uncertainty in (0.0, 0.5, 1.0)
    for removal in (0.08, 0.15, 0.25)
) + (Policy(1.0, 1.0, 1.0, 1.0, 1.0, 0.08),)
IDENTITY_POLICY = POLICIES[-1]


def choose(case: PublicCase, evidence: Evidence, policy: Policy) -> int:
    case_lower = evidence.case_probability - policy.uncertainty * evidence.case_probability_std
    if case_lower < policy.case_probability:
        return 0
    if policy.uncertainty > 0:
        probability = evidence.probability - policy.uncertainty * evidence.probability_std
        regression = evidence.regression - policy.uncertainty * evidence.regression_std
        score = evidence.score - policy.uncertainty * evidence.score_std
    else:
        probability = evidence.probability
        regression = evidence.regression
        score = evidence.score
    valid = case.valid.copy()
    valid &= np.isfinite(score)
    valid &= case.removed <= policy.max_removal
    valid &= probability[:, 0] >= policy.safe_probability
    valid &= probability[:, 1] >= 0.50
    valid &= probability[:, 2] >= policy.safe_probability
    valid &= probability[:, 3] >= 0.50
    valid &= probability[:, 4] >= 0.50
    valid &= probability[:, 5] >= policy.joint_probability
    valid &= regression[:, 0] >= -0.001
    valid &= regression[:, 1] >= -0.005
    valid &= regression[:, 2] >= 0.0
    valid &= score >= policy.score_margin
    valid[0] = True
    combined = (
        score + 0.80 * regression[:, 0] + 0.25 * regression[:, 1]
        + 0.70 * regression[:, 2] + 0.10 * regression[:, 4]
    )
    combined[0] = 0.0
    return int(np.argmax(np.where(valid, combined, -np.inf)))


def policy_result(cases: list[PublicCase], evidence: dict[str, Evidence], policy: Policy):
    choices = np.asarray([choose(case, evidence[case.case_id], policy) for case in cases])
    values = np.stack([case.targets[index] for case, index in zip(cases, choices)])
    changed = choices != 0
    finite_bay = np.isfinite(values[:, 2])
    joint = changed & (values[:, 0] > 0.0) & finite_bay & (values[:, 2] >= 0.005)
    eligible = (
        not np.any(values[:, 0] < -1e-9)
        and not np.any(values[:, 1] < -0.005)
        and not np.any(values[changed & finite_bay, 2] < -1e-9)
        and not np.any(values[changed & np.isfinite(values[:, 4]), 4] < -0.020)
    )
    utility = target_utility(values, np.asarray([
        case.removed[index] for case, index in zip(cases, choices)
    ]))
    return choices, values, {
        "eligible": bool(eligible), "changed": int(changed.sum()),
        "joint_improved": int(joint.sum()),
        "false_actions": int(np.count_nonzero(changed & ~joint)),
        "harmed_iou": int(np.count_nonzero(values[:, 0] < 0)),
        "harmed_bay": int(np.count_nonzero(changed & finite_bay & (values[:, 2] < 0))),
        "mean_iou": float(values[:, 0].mean()),
        "mean_bay": float(np.nanmean(values[:, 2])),
        "mean_utility": float(utility.mean()),
        "minimum_iou": float(values[:, 0].min()),
    }


def select_policy(cases: list[PublicCase], evidence: dict[str, Evidence]):
    rows, best = [], None
    for policy in POLICIES:
        _, _, result = policy_result(cases, evidence, policy)
        rows.append({**asdict(policy), **result})
        key = (
            int(result["eligible"]), int(result["joint_improved"]),
            -int(result["false_actions"]), float(result["mean_utility"]),
            float(result["mean_iou"]), -int(result["changed"]),
        )
        if best is None or key > best[0]:
            best = (key, policy, result)
    # Deployment is allowed only after inner OOF has demonstrated at least one
    # genuinely useful, zero-harm action. Otherwise the calibrated action is
    # identity, irrespective of a permissive policy's nominal thresholds.
    if not best[2]["eligible"] or best[2]["joint_improved"] < 1:
        _, _, identity_result = policy_result(cases, evidence, IDENTITY_POLICY)
        return IDENTITY_POLICY, identity_result, rows
    return best[1], best[2], rows


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        return
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def front_audit(cases: list[PublicCase], fronts: dict[str, np.ndarray]):
    rows = []
    for case in cases:
        full = np.flatnonzero(case.valid)
        front = fronts[case.case_id]
        full_values, full_material = training_scores(case, full)
        front_values, front_material = training_scores(case, front)
        rows.append({
            "id": case.case_id, "valid_candidates": int(len(full)),
            "front_candidates": int(len(front)),
            "full_material_candidates": int(full_material.sum()),
            "front_material_candidates": int(front_material.sum()),
            "full_best_utility": float(full_values.max()),
            "front_best_utility": float(front_values.max()),
            "utility_retained": bool(front_values.max() >= full_values.max() - 0.010),
            "full_best_iou": float(np.max(case.targets[full, 0])),
            "front_best_iou": float(np.max(case.targets[front, 0])),
            "full_best_bay_f1": float(np.nanmax(case.targets[full, 2]))
            if np.isfinite(case.targets[full, 2]).any() else float("nan"),
            "front_best_bay_f1": float(np.nanmax(case.targets[front, 2]))
            if np.isfinite(case.targets[front, 2]).any() else float("nan"),
        })
    return rows


def group_summary(mask, truths, baselines, predictions, repetitions, seed):
    indices = np.flatnonzero(mask)
    before_iou = foreground_iou_per_case(truths[indices], baselines[indices])
    after_iou = foreground_iou_per_case(truths[indices], predictions[indices])
    before_boundary = boundary_f1_per_case(truths[indices], baselines[indices])
    after_boundary = boundary_f1_per_case(truths[indices], predictions[indices])
    before_geometry = [case_metrics(truths[i], baselines[i]) for i in indices]
    after_geometry = [case_metrics(truths[i], predictions[i]) for i in indices]
    result = {
        "case_count": int(len(indices)),
        "changed_cases": int(np.count_nonzero(np.any(
            predictions[indices] != baselines[indices], axis=(1, 2)
        ))),
        "improved_iou_cases": int(np.count_nonzero(after_iou > before_iou + 1e-9)),
        "harmed_iou_cases": int(np.count_nonzero(after_iou < before_iou - 1e-9)),
        "baseline_iou": float(before_iou.mean()), "final_iou": float(after_iou.mean()),
        "delta_iou": paired_bootstrap(after_iou - before_iou, repetitions, seed),
        "baseline_boundary_f1": float(before_boundary.mean()),
        "final_boundary_f1": float(after_boundary.mean()),
        "delta_boundary_f1": paired_bootstrap(
            after_boundary - before_boundary, repetitions, seed + 1
        ),
    }
    for offset, metric in enumerate((
        "bay_f1", "bay_precision", "bay_depth_score", "bay_direction_score"
    )):
        before = np.asarray([float(row[metric]) for row in before_geometry])
        after = np.asarray([float(row[metric]) for row in after_geometry])
        result[f"baseline_{metric}"] = float(np.nanmean(before))
        result[f"final_{metric}"] = float(np.nanmean(after))
        result[f"delta_{metric}"] = paired_bootstrap(
            after - before, repetitions, seed + 2 + offset
        )
    return result


def main() -> None:
    args = parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    pretrained = torch.load(args.pretrained.resolve(), map_location="cpu", weights_only=False)
    cases, truths, ids = load_public_cases(args)
    fronts = {case.case_id: candidate_front(case, args.front_size) for case in cases}
    audit_rows = front_audit(cases, fronts)
    write_csv(output / "candidate_front_audit.csv", audit_rows)
    audit_summary = {
        "cases": len(cases),
        "mean_compression_ratio": float(np.mean([
            row["front_candidates"] / row["valid_candidates"] for row in audit_rows
        ])),
        "utility_retained_cases": int(sum(row["utility_retained"] for row in audit_rows)),
        "material_cases_retained": int(sum(
            row["full_material_candidates"] == 0 or row["front_material_candidates"] > 0
            for row in audit_rows
        )),
        "front_rule_used_labels": False,
    }
    (output / "candidate_front_summary.json").write_text(
        json.dumps(audit_summary, indent=2), encoding="utf-8"
    )
    print(json.dumps(audit_summary, indent=2), flush=True)
    if args.front_audit_only:
        return

    levels = sorted({case.level for case in cases})
    pair_evidence: dict[tuple[str, str], dict[str, Evidence]] = {}
    for fold, (left, right) in enumerate(itertools.combinations(levels, 2), 1):
        training = [case for case in cases if case.level not in (left, right)]
        models, target_mean, target_scale = train_or_load_ensemble(
            f"exclude_{left}_{right}", training, fronts, pretrained, args, device
        )
        held = [case for case in cases if case.level in (left, right)]
        pair_evidence[(left, right)] = {
            case.case_id: predict_case(
                case, fronts[case.case_id], models, pretrained,
                target_mean, target_scale, device,
            ) for case in held
        }
        print(f"pair {fold:02d}/21 {left}+{right}: train={len(training)}", flush=True)

    baselines = np.stack([case.candidates[0] for case in cases])
    predictions = baselines.copy()
    choices = np.zeros(len(cases), dtype=np.int64)
    policies, calibration_rows = [], []
    for fold, outer in enumerate(levels, 1):
        inner_cases = [case for case in cases if case.level != outer]
        inner_evidence: dict[str, Evidence] = {}
        for inner in levels:
            if inner == outer:
                continue
            pair = tuple(sorted((outer, inner)))
            for case in cases:
                if case.level == inner:
                    inner_evidence[case.case_id] = pair_evidence[pair][case.case_id]
        policy, inner_result, calibration = select_policy(inner_cases, inner_evidence)
        calibration_rows.extend({"outer_level": outer, **row} for row in calibration)
        training = [case for case in cases if case.level != outer]
        models, target_mean, target_scale = train_or_load_ensemble(
            f"exclude_{outer}", training, fronts, pretrained, args, device
        )
        outer_choices = []
        for index, case in enumerate(cases):
            if case.level != outer:
                continue
            evidence = predict_case(
                case, fronts[case.case_id], models, pretrained,
                target_mean, target_scale, device,
            )
            choice = choose(case, evidence, policy)
            choices[index] = choice
            predictions[index] = case.candidates[choice]
            outer_choices.append(int(choice))
        record = {
            "outer_level": outer, **asdict(policy),
            **{f"inner_oof_{key}": value for key, value in inner_result.items()},
            "outer_choices": outer_choices,
        }
        policies.append(record)
        print(f"outer {fold}/7: {record}", flush=True)

    before_iou = foreground_iou_per_case(truths, baselines)
    after_iou = foreground_iou_per_case(truths, predictions)
    before_boundary = boundary_f1_per_case(truths, baselines)
    after_boundary = boundary_f1_per_case(truths, predictions)
    case_rows = []
    for index, case in enumerate(cases):
        before_geometry = case_metrics(truths[index], baselines[index])
        after_geometry = case_metrics(truths[index], predictions[index])
        row = {
            "id": case.case_id, "strict_inward": case.case_id in STRICT_INWARD_IDS,
            "choice": int(choices[index]), "baseline_iou": float(before_iou[index]),
            "final_iou": float(after_iou[index]),
            "delta_iou": float(after_iou[index] - before_iou[index]),
            "baseline_boundary_f1": float(before_boundary[index]),
            "final_boundary_f1": float(after_boundary[index]),
            "delta_boundary_f1": float(after_boundary[index] - before_boundary[index]),
            **topology_checks(baselines[index], predictions[index]),
            **edit_metrics(truths[index], baselines[index], predictions[index]),
        }
        for metric in ("bay_f1", "bay_precision", "bay_depth_score", "bay_direction_score"):
            row[f"baseline_{metric}"] = before_geometry[metric]
            row[f"final_{metric}"] = after_geometry[metric]
            row[f"delta_{metric}"] = float(after_geometry[metric] - before_geometry[metric])
        case_rows.append(row)
    strict = np.asarray([case.case_id in STRICT_INWARD_IDS for case in cases])
    groups = {
        "all": group_summary(
            np.ones(len(cases), bool), truths, baselines, predictions,
            args.bootstrap_repetitions, args.seed,
        ),
        "strict_inward": group_summary(
            strict, truths, baselines, predictions,
            args.bootstrap_repetitions, args.seed + 20,
        ),
        "ordinary": group_summary(
            ~strict, truths, baselines, predictions,
            args.bootstrap_repetitions, args.seed + 40,
        ),
    }
    write_csv(output / "public_case_metrics.csv", case_rows)
    write_csv(output / "nested_calibration.csv", calibration_rows)
    (output / "fold_policies.json").write_text(json.dumps(policies, indent=2), encoding="utf-8")
    np.savez_compressed(
        output / "predictions.npz", ids=ids, truths=truths,
        baseline=baselines, prediction=predictions, choices=choices,
    )
    save_montage(
        output / "strict_inward_pairwise_topology.png", truths, baselines,
        predictions, baselines, ids, np.flatnonzero(strict),
    )
    summary = {
        "method": "case-balanced pairwise physics/topology exterior-bay ranker",
        "status": "complete-level nested outer-OOF evaluation",
        "outer_truth_used_for_training_or_policy_selection": False,
        "strict_inward_ids_used_for_training_or_policy_selection": False,
        "front_audit": audit_summary,
        "candidate_constraints": {
            "added_pixels": 0,
            "removed_background_exterior_connected": True,
            "new_holes_forbidden": True,
            "foreground_and_class_component_counts_preserved": True,
            "identity_fallback": True,
        },
        "groups": groups, "fold_policies": policies,
        "args": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
    }
    (output / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=True), encoding="utf-8"
    )
    print(json.dumps(groups, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
