"""Aggregate four matched v6 seeds with paired hierarchical bootstrap statistics."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


GROUP_ORDER = (
    ("base", "concave", "Base concave"),
    ("biological", "concave", "Biological concave"),
    ("biological", "ordinary", "Biological ordinary"),
    ("stress", "concave", "Stress concave"),
    ("public_ktc", "concave", "Public KTC nonconvex"),
    ("public_ktc", "ordinary", "Public KTC ordinary"),
)
METRICS = (
    "foreground_iou",
    "foreground_dice",
    "boundary_f1",
    "notch_preservation",
    "bank_retention",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", nargs="+", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--bootstrap", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20261021)
    return parser.parse_args()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def paired_differences(
    rows: list[dict[str, str]],
    group: str,
    subset: str,
    metric: str,
    candidate: str,
) -> dict[int, np.ndarray]:
    by_key: dict[tuple[int, str], dict[str, float]] = {}
    for row in rows:
        if row["group"] != group or row["subset"] != subset:
            continue
        seed = int(row["seed"])
        key = (seed, row["case_id"])
        try:
            value = float(row[metric])
        except ValueError:
            value = float("nan")
        by_key.setdefault(key, {})[row["method"]] = value
    by_seed: dict[int, list[float]] = {}
    for (seed, _), methods in by_key.items():
        if candidate not in methods or "anchor_v4" not in methods:
            continue
        difference = methods[candidate] - methods["anchor_v4"]
        if np.isfinite(difference):
            by_seed.setdefault(seed, []).append(float(difference))
    return {seed: np.asarray(values, dtype=float) for seed, values in by_seed.items()}


def paired_joint_differences(
    rows: list[dict[str, str]],
    group: str,
    subset: str,
    metrics: tuple[str, ...],
    candidate: str,
) -> dict[int, np.ndarray]:
    """Return case-aligned metric differences, dropping a case jointly if any is undefined."""
    by_key: dict[tuple[int, str], dict[str, dict[str, float]]] = {}
    for row in rows:
        if row["group"] != group or row["subset"] != subset:
            continue
        seed = int(row["seed"])
        key = (seed, row["case_id"])
        method_values = by_key.setdefault(key, {}).setdefault(row["method"], {})
        for metric in metrics:
            try:
                method_values[metric] = float(row[metric])
            except ValueError:
                method_values[metric] = float("nan")

    by_seed: dict[int, list[list[float]]] = {}
    for (seed, _), methods in by_key.items():
        if candidate not in methods or "anchor_v4" not in methods:
            continue
        differences = [
            methods[candidate].get(metric, float("nan"))
            - methods["anchor_v4"].get(metric, float("nan"))
            for metric in metrics
        ]
        if np.all(np.isfinite(differences)):
            by_seed.setdefault(seed, []).append([float(value) for value in differences])
    return {
        seed: np.asarray(values, dtype=float).reshape(-1, len(metrics))
        for seed, values in by_seed.items()
    }


def hierarchical_bootstrap(
    by_seed: dict[int, np.ndarray],
    repetitions: int,
    rng: np.random.Generator,
) -> dict[str, float]:
    values = [by_seed[key] for key in sorted(by_seed)]
    if not values:
        return {
            "mean_difference": float("nan"),
            "ci95_low": float("nan"),
            "ci95_high": float("nan"),
            "probability_positive": float("nan"),
            "seeds": 0,
            "cases_per_seed": 0,
        }
    within_columns: list[np.ndarray] = []
    for value in values:
        sampled = rng.integers(0, len(value), size=(repetitions, len(value)))
        within_columns.append(value[sampled].mean(axis=1))
    within = np.column_stack(within_columns)
    choices = rng.integers(0, len(values), size=(repetitions, len(values)))
    bootstrap = np.take_along_axis(within, choices, axis=1).mean(axis=1)
    observed = float(np.mean([value.mean() for value in values]))
    return {
        "mean_difference": observed,
        "ci95_low": float(np.percentile(bootstrap, 2.5)),
        "ci95_high": float(np.percentile(bootstrap, 97.5)),
        "probability_positive": float(np.mean(bootstrap > 0.0)),
        "seeds": len(values),
        "cases_per_seed": int(round(np.mean([len(value) for value in values]))),
    }


def hierarchical_rate(
    iou_by_seed: dict[int, np.ndarray],
    notch_by_seed: dict[int, np.ndarray] | None,
    repetitions: int,
    rng: np.random.Generator,
) -> dict[str, float]:
    rates: dict[int, np.ndarray] = {}
    for seed, iou in iou_by_seed.items():
        if notch_by_seed is None:
            rates[seed] = (iou < -0.01).astype(float)
        else:
            notch = notch_by_seed[seed]
            if len(iou) != len(notch):
                raise ValueError(
                    f"Unaligned IoU/Notch arrays for seed {seed}: {len(iou)} != {len(notch)}"
                )
            rates[seed] = ((notch > 0.02) & (iou >= -0.02)).astype(float)
    result = hierarchical_bootstrap(rates, repetitions, rng)
    return {
        "rate": result["mean_difference"],
        "ci95_low": result["ci95_low"],
        "ci95_high": result["ci95_high"],
    }


def write_effects(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def plot_effects(path: Path, effects: list[dict[str, object]]) -> None:
    figure, axes = plt.subplots(1, 3, figsize=(15.2, 5.4))
    panels = (
        ("foreground_iou", "IoU difference"),
        ("notch_preservation", "Notch preservation difference"),
        ("bank_retention", "Bank retention difference"),
    )
    method_colors = {"candidate_v6": "#cc4c4c", "gated_v6": "#2b7a77"}
    method_offsets = {"candidate_v6": -0.10, "gated_v6": 0.10}
    labels = [label for _, _, label in GROUP_ORDER]
    for axis, (metric, title) in zip(axes, panels):
        for method in ("candidate_v6", "gated_v6"):
            selected = [
                row
                for group, subset, _ in GROUP_ORDER
                for row in effects
                if row["group"] == group
                and row["subset"] == subset
                and row["metric"] == metric
                and row["candidate"] == method
            ]
            y = np.arange(len(selected)) + method_offsets[method]
            mean = np.asarray([row["mean_difference"] for row in selected], dtype=float)
            low = np.asarray([row["ci95_low"] for row in selected], dtype=float)
            high = np.asarray([row["ci95_high"] for row in selected], dtype=float)
            axis.errorbar(
                mean,
                y,
                xerr=np.vstack((mean - low, high - mean)),
                fmt="o",
                color=method_colors[method],
                capsize=3,
                label="ungated candidate" if method == "candidate_v6" else "dual-risk gated",
            )
        axis.axvline(0.0, color="black", linewidth=1, linestyle="--")
        axis.set_yticks(np.arange(len(labels)), labels if axis is axes[0] else [])
        axis.invert_yaxis()
        axis.set_title(title)
        axis.grid(axis="x", alpha=0.25)
    axes[0].legend(fontsize=8, loc="lower right")
    figure.suptitle("v6 paired hierarchical bootstrap effects (95% CI)", fontsize=14)
    figure.tight_layout(rect=(0, 0, 1, 0.96))
    figure.savefig(path, dpi=220)
    plt.close(figure)


def plot_seed_effects(
    path: Path,
    all_rows: list[dict[str, str]],
) -> None:
    figure, axes = plt.subplots(1, 3, figsize=(14.0, 4.2))
    groups = (
        ("biological", "Biological concave"),
        ("stress", "Stress concave"),
        ("public_ktc", "Public KTC nonconvex"),
    )
    for axis, (group, label) in zip(axes, groups):
        iou = paired_differences(all_rows, group, "concave", "foreground_iou", "gated_v6")
        notch = paired_differences(all_rows, group, "concave", "notch_preservation", "gated_v6")
        for seed in sorted(iou):
            axis.scatter(iou[seed].mean(), notch[seed].mean(), s=55, label=str(seed))
            axis.annotate(str(seed)[-2:], (iou[seed].mean(), notch[seed].mean()), xytext=(4, 3), textcoords="offset points")
        axis.axvline(0, color="black", linestyle="--", linewidth=1)
        axis.axhline(0, color="black", linestyle="--", linewidth=1)
        axis.set_title(label)
        axis.set_xlabel("mean IoU difference")
        axis.set_ylabel("mean Notch difference")
        axis.grid(alpha=0.25)
    figure.suptitle("Matched-seed stability of gated v6")
    figure.tight_layout(rect=(0, 0, 1, 0.95))
    figure.savefig(path, dpi=210)
    plt.close(figure)


def plot_reliability(path: Path, rows: list[dict[str, str]]) -> dict[str, float]:
    unique: dict[tuple[int, str, str], dict[str, str]] = {}
    for row in rows:
        key = (int(row["seed"]), row["group"], row["case_id"])
        if row["method"] == "anchor_v4":
            unique[key] = row
    values = list(unique.values())
    panels = (
        ("predicted_benefit_q20", "actual_notch_gain_candidate", "Benefit q20", "lower"),
        ("predicted_iou_loss_q80", "actual_iou_loss_candidate", "IoU-loss q80", "upper"),
        ("predicted_bank_loss_q80", "actual_bank_loss_candidate", "Bank-loss q80", "upper"),
    )
    figure, axes = plt.subplots(1, 3, figsize=(13.2, 3.9))
    coverage: dict[str, float] = {}
    for axis, (predicted_key, actual_key, title, direction) in zip(axes, panels):
        predicted = np.asarray([float(row[predicted_key]) for row in values])
        actual = np.asarray([float(row[actual_key]) for row in values])
        edges = np.unique(np.quantile(predicted, np.linspace(0.0, 1.0, 11)))
        means_x: list[float] = []
        means_y: list[float] = []
        sizes: list[int] = []
        for lower, upper in zip(edges[:-1], edges[1:]):
            mask = (predicted >= lower) & (predicted <= upper if upper == edges[-1] else predicted < upper)
            if mask.any():
                means_x.append(float(predicted[mask].mean()))
                means_y.append(float(actual[mask].mean()))
                sizes.append(int(mask.sum()))
        axis.scatter(means_x, means_y, s=np.asarray(sizes) * 0.08 + 12, alpha=0.8)
        low = min(means_x + means_y)
        high = max(means_x + means_y)
        axis.plot([low, high], [low, high], "k--", linewidth=1)
        value = float(np.mean(actual >= predicted)) if direction == "lower" else float(np.mean(actual <= predicted))
        coverage[predicted_key] = value
        axis.set_title(f"{title}\ncoverage={value:.3f}")
        axis.set_xlabel("predicted")
        axis.set_ylabel("observed bin mean")
        axis.grid(alpha=0.25)
    figure.tight_layout()
    figure.savefig(path, dpi=210)
    plt.close(figure)
    return coverage


def select_reference_run(run_summaries: list[tuple[Path, dict[str, object]]]) -> Path:
    values = []
    for path, summary in run_summaries:
        effect = summary["evaluation"]["public_ktc"]["concave"]["concavity_direction"][
            "mean_notch_delta"
        ]
        values.append((float(effect), path))
    values.sort(key=lambda item: item[0])
    return values[len(values) // 2][1]


def visible_notch_gain(
    anchor: np.ndarray, gated: np.ndarray, notch: np.ndarray
) -> np.ndarray:
    anchor_foreground = anchor != 0
    gated_foreground = gated != 0
    flat_notch = notch.reshape(len(notch), -1).astype(bool)
    gain = np.zeros(len(notch), dtype=float)
    for index in range(len(notch)):
        mask = flat_notch[index]
        if mask.any():
            a = anchor_foreground[index].reshape(-1)[mask]
            g = gated_foreground[index].reshape(-1)[mask]
            gain[index] = float((~g).mean() - (~a).mean())
    return gain


def save_final_montage(path: Path, run: Path) -> None:
    archive = np.load(run / "v6_predictions.npz", allow_pickle=False)
    chosen: list[tuple[str, int]] = []
    for prefix, take in (("public", 4), ("biological", 4)):
        gain = visible_notch_gain(
            archive[f"{prefix}_anchor"], archive[f"{prefix}_gated"], archive[f"{prefix}_cutout"]
        )
        indices = np.argsort(gain)[::-1][:take]
        chosen.extend((prefix, int(index)) for index in indices)
    columns = ("linear EIT", "truth", "v4 anchor", "v6 removal", "v6 candidate", "v6 gated")
    figure, axes = plt.subplots(len(chosen), len(columns), figsize=(13.5, 2.05 * len(chosen)), squeeze=False)
    for row, (prefix, index) in enumerate(chosen):
        truth = archive[f"{prefix}_truth"][index]
        linear = archive[f"{prefix}_image"][index]
        if linear.shape != truth.shape:
            from scipy.ndimage import zoom

            linear = zoom(linear, (truth.shape[0] / linear.shape[0], truth.shape[1] / linear.shape[1]), order=1)
        scale = max(float(np.percentile(np.abs(linear), 99)), 1e-6)
        panels = (
            (linear, "coolwarm", -scale, scale),
            (truth, "viridis", 0, 2),
            (archive[f"{prefix}_anchor"][index], "viridis", 0, 2),
            (archive[f"{prefix}_removal"][index], "magma", 0, 1),
            (archive[f"{prefix}_candidate"][index], "viridis", 0, 2),
            (archive[f"{prefix}_gated"][index], "viridis", 0, 2),
        )
        for column, (image, cmap, vmin, vmax) in enumerate(panels):
            axes[row, column].imshow(image, cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest")
            axes[row, column].set_axis_off()
            if row == 0:
                axes[row, column].set_title(columns[column], fontsize=9)
        identifier = archive[f"{prefix}_ids"][index]
        gain = visible_notch_gain(
            archive[f"{prefix}_anchor"][index : index + 1],
            archive[f"{prefix}_gated"][index : index + 1],
            archive[f"{prefix}_cutout"][index : index + 1],
        )[0]
        axes[row, 0].set_ylabel(f"{prefix}/{identifier}\nNotch gain={gain:+.3f}", fontsize=8)
    figure.suptitle("v6 representative independent-test reconstructions", fontsize=14)
    figure.tight_layout(rect=(0, 0, 1, 0.98))
    figure.savefig(path, dpi=220)
    plt.close(figure)


def effect_lookup(
    effects: list[dict[str, object]], group: str, subset: str, metric: str
) -> dict[str, object]:
    return next(
        row
        for row in effects
        if row["group"] == group
        and row["subset"] == subset
        and row["metric"] == metric
        and row["candidate"] == "gated_v6"
    )


def write_report(
    path: Path,
    effects: list[dict[str, object]],
    diagnostics: dict[str, object],
    runs: list[Path],
) -> None:
    lines = [
        "# Local Topology EIT v6 Final Multiseed Report",
        "",
        "## Protocol integrity",
        "",
        "- Four matched v4 anchor seeds were frozen.",
        "- The local corrector and quantile risk head used synthetic training cases only.",
        "- Checkpoint and decision-rule selection used synthetic validation cases only.",
        "- Synthetic tests and public KTC truths were evaluated only after the rule was frozen.",
        f"- Paired hierarchical bootstrap repetitions: {diagnostics['bootstrap_repetitions']}.",
        "",
        "## Gated v6 effects versus frozen v4",
        "",
        "| Group | IoU difference (95% CI) | Notch difference (95% CI) | Bank difference (95% CI) |",
        "|---|---:|---:|---:|",
    ]
    for group, subset, label in GROUP_ORDER:
        iou = effect_lookup(effects, group, subset, "foreground_iou")
        notch = effect_lookup(effects, group, subset, "notch_preservation")
        bank = effect_lookup(effects, group, subset, "bank_retention")
        def formatted(value: dict[str, object]) -> str:
            return (
                f"{float(value['mean_difference']):+.5f} "
                f"[{float(value['ci95_low']):+.5f}, {float(value['ci95_high']):+.5f}]"
            )
        lines.append(f"| {label} | {formatted(iou)} | {formatted(notch)} | {formatted(bank)} |")
    lines.extend(
        (
            "",
            "## Safety and direction audits",
            "",
            "| Group | IoU loss > 0.01 | Correct inward trend |",
            "|---|---:|---:|",
        )
    )
    for key, value in diagnostics["rates"].items():
        lines.append(
            f"| {key} | {value['severe_iou_loss']['rate']:.4f} "
            f"[{value['severe_iou_loss']['ci95_low']:.4f}, {value['severe_iou_loss']['ci95_high']:.4f}] | "
            f"{value.get('correct_inward_trend', {}).get('rate', float('nan')):.4f} |"
        )
    lines.extend(
        (
            "",
            "## Files",
            "",
            "- `v6_hierarchical_bootstrap_effects.csv`: all paired effect estimates.",
            "- `v6_multiseed_effects.png`: effect-size forest plot.",
            "- `v6_seed_stability.png`: seed-level IoU/Notch stability.",
            "- `v6_gate_reliability.png`: benefit/risk quantile reliability.",
            "- `v6_final_case_comparison.png`: representative independent reconstructions.",
            "- `v6_multiseed_summary.json`: machine-readable complete summary.",
            "",
            "## Run directories",
            "",
        )
    )
    lines.extend(f"- `{run.resolve()}`" for run in runs)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    runs = [path.resolve() for path in args.runs]
    all_rows: list[dict[str, str]] = []
    summaries: list[tuple[Path, dict[str, object]]] = []
    for run in runs:
        all_rows.extend(read_csv(run / "v6_case_metrics.csv"))
        summaries.append((run, json.loads((run / "v6_summary.json").read_text(encoding="utf-8"))))
    rng = np.random.default_rng(args.seed)
    effects: list[dict[str, object]] = []
    rates: dict[str, object] = {}
    for group, subset, label in GROUP_ORDER:
        for candidate in ("candidate_v6", "gated_v6"):
            for metric in METRICS:
                by_seed = paired_differences(all_rows, group, subset, metric, candidate)
                result = hierarchical_bootstrap(by_seed, args.bootstrap, rng)
                effects.append(
                    {
                        "group": group,
                        "subset": subset,
                        "label": label,
                        "candidate": candidate,
                        "metric": metric,
                        **result,
                    }
                )
        iou = paired_differences(all_rows, group, subset, "foreground_iou", "gated_v6")
        notch = paired_differences(
            all_rows, group, subset, "notch_preservation", "gated_v6"
        )
        group_rates: dict[str, object] = {
            "severe_iou_loss": hierarchical_rate(iou, None, args.bootstrap, rng)
        }
        if subset == "concave" and notch:
            joint = paired_joint_differences(
                all_rows,
                group,
                subset,
                ("foreground_iou", "notch_preservation"),
                "gated_v6",
            )
            group_rates["correct_inward_trend"] = hierarchical_rate(
                {seed: values[:, 0] for seed, values in joint.items()},
                {seed: values[:, 1] for seed, values in joint.items()},
                args.bootstrap,
                rng,
            )
        rates[label] = group_rates
    write_effects(output_dir / "v6_hierarchical_bootstrap_effects.csv", effects)
    plot_effects(output_dir / "v6_multiseed_effects.png", effects)
    plot_seed_effects(output_dir / "v6_seed_stability.png", all_rows)
    coverage = plot_reliability(output_dir / "v6_gate_reliability.png", all_rows)
    reference = select_reference_run(summaries)
    save_final_montage(output_dir / "v6_final_case_comparison.png", reference)

    criteria = {
        "biological_notch_positive_ci": effect_lookup(
            effects, "biological", "concave", "notch_preservation"
        )["ci95_low"]
        > 0.0,
        "stress_notch_positive_ci": effect_lookup(
            effects, "stress", "concave", "notch_preservation"
        )["ci95_low"]
        > 0.0,
        "public_notch_positive_ci": effect_lookup(
            effects, "public_ktc", "concave", "notch_preservation"
        )["ci95_low"]
        > 0.0,
        "biological_concave_iou_noninferior_minus_0_003": effect_lookup(
            effects, "biological", "concave", "foreground_iou"
        )["ci95_low"]
        >= -0.003,
        "biological_ordinary_iou_noninferior_minus_0_003": effect_lookup(
            effects, "biological", "ordinary", "foreground_iou"
        )["ci95_low"]
        >= -0.003,
    }
    summary = {
        "method": "v6 frozen-v4 local topology corrector with dual quantile risk gate",
        "runs": [str(run) for run in runs],
        "bootstrap_repetitions": args.bootstrap,
        "effects": effects,
        "rates": rates,
        "risk_quantile_empirical_coverage": coverage,
        "success_criteria": criteria,
        "all_primary_criteria_met": bool(all(criteria.values())),
        "reference_run_for_montage": str(reference),
    }
    (output_dir / "v6_multiseed_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    write_report(output_dir / "V6_FINAL_REPORT.md", effects, summary, runs)
    print(json.dumps({"criteria": criteria, "rates": rates}, indent=2), flush=True)


if __name__ == "__main__":
    main()
