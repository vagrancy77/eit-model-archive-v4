"""Train and evaluate the v6 local topology corrector.

Protocol
--------
1. Freeze a validation-routed v4 reconstruction model.
2. Cache truth-blind v4 maps and a Jacobian residual backprojection.
3. Train a local exterior-connected removal corrector on synthetic train data.
4. Train a dual benefit/risk quantile gate on train cases only.
5. Calibrate its decision rule on synthetic validation cases only.
6. Evaluate once on independent synthetic tests and public KTC cases.

Public KTC truths and all synthetic test truths are excluded from training,
checkpoint selection, risk-head fitting, and gate calibration.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import random
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import (
    ConcatDataset,
    DataLoader,
    Dataset,
    Subset,
    TensorDataset,
    WeightedRandomSampler,
)

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import train_boolean_shape_eit_v2 as data_tools
import train_topology_residual_eit_v3 as v4_tools
from evaluate_topology_residual_eit_v3 import case_metrics, indentation_mask
from pytorch_eit.local_topology_corrector_v6 import (
    DualRiskQuantileGate,
    LocalTopologyCorrectorV6,
    quantile_loss,
)
from pytorch_eit.topology_residual_net import TopologyResidualEITNet


DATASET_NAMES = ("base", "biological", "stress")
SPLIT_NAMES = ("train", "validation", "test")
VARIANTS = ("full", "no_physics", "no_topology_supervision", "no_connectivity")
MAP_NAMES = (
    "v4_sdf",
    "v4_raw_cutout",
    "v4_connected_cutout",
    "v4_mouth",
    "v4_effective_cutout",
    "v4_delta",
    "physics_backprojection",
)
METRIC_NAMES = (
    "foreground_iou",
    "foreground_dice",
    "boundary_f1",
    "notch_preservation",
    "bank_retention",
    "false_negative_fraction",
    "spurious_hole_fraction",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--anchor-router", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--variant", choices=VARIANTS, default="full")
    parser.add_argument(
        "--cache-dir",
        type=Path,
        default=None,
        help="reuse a frozen v4 cache from another run; the cache is read-only",
    )
    parser.add_argument(
        "--base-dataset", type=Path, default=ROOT / "datasets" / "ktc_shape_nonlinear_v1.npz"
    )
    parser.add_argument(
        "--biological-dataset",
        type=Path,
        default=ROOT / "datasets" / "ktc_biological_concavity_v1.npz",
    )
    parser.add_argument(
        "--stress-dataset",
        type=Path,
        default=ROOT / "datasets" / "ktc_deep_concavity_stress_v1.npz",
    )
    parser.add_argument(
        "--audit", type=Path, default=ROOT / "outputs" / "ktc2023_full_audit" / "summary.json"
    )
    parser.add_argument("--epochs", type=int, default=54)
    parser.add_argument("--patience", type=int, default=12)
    parser.add_argument("--batch-size", type=int, default=28)
    parser.add_argument("--base-channels", type=int, default=24)
    parser.add_argument("--learning-rate", type=float, default=1.2e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--stress-repeat", type=int, default=2)
    parser.add_argument("--ordinary-repeat", type=int, default=2)
    parser.add_argument("--gate-epochs", type=int, default=260)
    parser.add_argument("--gate-patience", type=int, default=36)
    parser.add_argument("--gate-learning-rate", type=float, default=1.5e-3)
    parser.add_argument("--gate-batch-size", type=int, default=256)
    parser.add_argument("--device", choices=("auto", "cuda", "cpu"), default="auto")
    parser.add_argument("--disable-amp", action="store_true")
    parser.add_argument("--rebuild-cache", action="store_true")
    parser.add_argument("--cache-only", action="store_true")
    parser.add_argument("--force-train", action="store_true")
    parser.add_argument("--max-train-cases", type=int, default=0)
    parser.add_argument("--max-validation-cases", type=int, default=0)
    parser.add_argument("--max-test-cases", type=int, default=0)
    parser.add_argument("--progress-every", type=int, default=2)
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = True


def choose_device(name: str) -> torch.device:
    if name == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    device = torch.device(name)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable")
    return device


def limit_indices(indices: np.ndarray, maximum: int) -> np.ndarray:
    values = np.asarray(indices, dtype=np.int64)
    return values[:maximum] if maximum > 0 else values


def split_limit(args: argparse.Namespace, split: str) -> int:
    return {
        "train": args.max_train_cases,
        "validation": args.max_validation_cases,
        "test": args.max_test_cases,
    }[split]


def load_archives(args: argparse.Namespace) -> dict[str, np.lib.npyio.NpzFile]:
    return {
        "base": np.load(args.base_dataset.resolve(), allow_pickle=False),
        "biological": np.load(args.biological_dataset.resolve(), allow_pickle=False),
        "stress": np.load(args.stress_dataset.resolve(), allow_pickle=False),
    }


def load_v4(
    checkpoint: Path,
    fov: np.ndarray,
    device: torch.device,
) -> tuple[TopologyResidualEITNet, dict[str, object]]:
    state = torch.load(checkpoint.resolve(), map_location=device, weights_only=False)
    model = TopologyResidualEITNet(
        fov,
        base=int(state["base_channels"]),
        propagation_steps=int(state.get("propagation_steps", 14)),
        risk_aware=bool(state.get("risk_aware", False)),
    ).to(device)
    model.load_state_dict(state["model"])
    model.eval()
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    return model, state


@torch.no_grad()
def physics_backprojection(
    delta: torch.Tensor,
    voltage: torch.Tensor,
    jacobian: torch.Tensor,
    node_to_raw_pixel: torch.Tensor,
) -> torch.Tensor:
    with torch.amp.autocast("cuda", enabled=False):
        display = delta[:, 0].float()
        raw = torch.flip(display, dims=(1,)).flatten(1)
        nodes = raw[:, node_to_raw_pixel]
        predicted = 2.0 * (nodes @ jacobian.float().T)
        measured = voltage.float()
        rms = torch.sqrt(measured.square().mean(dim=1, keepdim=True) + 1e-10)
        residual = (measured - predicted) / rms
        back_nodes = residual @ jacobian.float()
        scale = torch.quantile(back_nodes.abs(), 0.985, dim=1, keepdim=True).clamp_min(1e-6)
        back_nodes = torch.clamp(back_nodes / scale, -4.0, 4.0) / 4.0
        raw_grid = torch.zeros(
            (len(delta), 64 * 64), device=delta.device, dtype=torch.float32
        )
        raw_grid[:, node_to_raw_pixel] = back_nodes
        return torch.flip(raw_grid.reshape(-1, 64, 64), dims=(1,))[:, None]


def write_cache(
    path: Path,
    model: TopologyResidualEITNet,
    loader: DataLoader,
    device: torch.device,
    threshold: float,
    jacobian: torch.Tensor,
    node_to_raw_pixel: torch.Tensor,
) -> None:
    collected: dict[str, list[np.ndarray]] = {
        "indices": [],
        "anchor_probabilities": [],
        "v4_maps": [],
        "v4_gate": [],
        "v4_route_enabled": [],
    }
    for batch_number, batch in enumerate(loader, start=1):
        image = batch["image"].to(device, non_blocking=True)
        voltage = batch["voltage"].to(device, non_blocking=True)
        output = model(image, voltage)
        gate = output["case_gate"][:, 0, 0, 0]
        enabled = gate >= threshold
        anchor = torch.where(
            enabled[:, None, None, None], output["probabilities"], output["base_probabilities"]
        )
        backprojection = physics_backprojection(
            output["delta"], voltage, jacobian, node_to_raw_pixel
        )
        maps = torch.cat(
            (
                output["sdf"],
                output["raw_cutout_probability"],
                output["connected_cutout_probability"],
                output["mouth_probability"],
                output["effective_cutout_probability"],
                output["delta"],
                backprojection,
            ),
            dim=1,
        )
        collected["indices"].append(batch["index"].numpy())
        collected["anchor_probabilities"].append(anchor.cpu().numpy().astype(np.float16))
        collected["v4_maps"].append(maps.cpu().numpy().astype(np.float16))
        collected["v4_gate"].append(gate.cpu().numpy().astype(np.float32))
        collected["v4_route_enabled"].append(enabled.cpu().numpy().astype(np.uint8))
        if batch_number % 20 == 0:
            print(f"  cached {batch_number * loader.batch_size} cases -> {path.name}", flush=True)
    arrays = {key: np.concatenate(values, axis=0) for key, values in collected.items()}
    np.savez_compressed(path, **arrays)


def ensure_caches(
    args: argparse.Namespace,
    output_dir: Path,
    archives: dict[str, np.lib.npyio.NpzFile],
    prepared: dict[str, data_tools.StructuralArrays],
    model: TopologyResidualEITNet,
    device: torch.device,
    threshold: float,
) -> dict[str, Path]:
    cache_dir = (
        args.cache_dir.resolve() if args.cache_dir is not None else output_dir / "v4_cache"
    )
    cache_dir.mkdir(parents=True, exist_ok=True)
    jacobian = torch.from_numpy(np.asarray(archives["base"]["jacobian"], dtype=np.float32)).to(device)
    mapping = torch.from_numpy(
        np.asarray(archives["base"]["node_to_raw_pixel"], dtype=np.int64)
    ).to(device)
    paths: dict[str, Path] = {}
    for source, name in enumerate(DATASET_NAMES):
        for split in SPLIT_NAMES:
            path = cache_dir / f"{name}_{split}.npz"
            paths[f"{name}_{split}"] = path
            if path.exists() and not args.rebuild_cache:
                continue
            indices = limit_indices(
                np.asarray(archives[name][f"{split}_indices"]), split_limit(args, split)
            )
            dataset = v4_tools.DirectStructuralDataset(prepared[name], archives[name], indices, source)
            loader = DataLoader(
                dataset,
                batch_size=args.batch_size,
                shuffle=False,
                num_workers=args.workers,
                pin_memory=device.type == "cuda",
            )
            print(f"caching frozen v4: {name}/{split} ({len(dataset)} cases)", flush=True)
            write_cache(path, model, loader, device, threshold, jacobian, mapping)

    public_path = cache_dir / "public_ktc.npz"
    paths["public"] = public_path
    if not public_path.exists() or args.rebuild_cache:
        archive = archives["base"]
        images = np.asarray(archive["real_linear_images"], dtype=np.float32)
        voltages = np.asarray(archive["real_voltages"], dtype=np.float32)
        public_dataset = PublicInputDataset(images, voltages)
        loader = DataLoader(
            public_dataset,
            batch_size=args.batch_size,
            shuffle=False,
            num_workers=0,
            pin_memory=device.type == "cuda",
        )
        print(f"caching frozen v4: public KTC ({len(public_dataset)} cases)", flush=True)
        write_cache(public_path, model, loader, device, threshold, jacobian, mapping)

    metadata = {
        "checkpoint": str(args.checkpoint.resolve()),
        "anchor_router": str(args.anchor_router.resolve()),
        "anchor_threshold": threshold,
        "seed": args.seed,
        "map_names": MAP_NAMES,
        "selection_data": "v4 threshold was calibrated on synthetic validation only",
    }
    if args.cache_dir is None:
        (cache_dir / "cache_metadata.json").write_text(
            json.dumps(metadata, indent=2), encoding="utf-8"
        )
    return paths


class PublicInputDataset(Dataset):
    def __init__(self, images: np.ndarray, voltages: np.ndarray) -> None:
        self.images = images
        self.voltages = voltages

    def __len__(self) -> int:
        return len(self.images)

    def __getitem__(self, item: int) -> dict[str, torch.Tensor]:
        return {
            "image": torch.from_numpy(self.images[item][None]),
            "voltage": torch.from_numpy(self.voltages[item]),
            "index": torch.tensor(item, dtype=torch.int64),
        }


class CachedCorrectorDataset(Dataset):
    def __init__(
        self,
        arrays: data_tools.StructuralArrays,
        cache_path: Path,
        source: int,
        augment: bool,
        selected_positions: np.ndarray | None = None,
        use_physics: bool = True,
    ) -> None:
        cache = np.load(cache_path, allow_pickle=False)
        self.arrays = arrays
        self.indices = np.asarray(cache["indices"], dtype=np.int64)
        self.anchor = np.asarray(cache["anchor_probabilities"], dtype=np.float16)
        self.maps = np.asarray(cache["v4_maps"], dtype=np.float16)
        self.use_physics = use_physics
        self.v4_gate = np.asarray(cache["v4_gate"], dtype=np.float32)
        self.v4_route = np.asarray(cache["v4_route_enabled"], dtype=np.uint8)
        self.source = source
        self.augment = augment
        self.positions = (
            np.arange(len(self.indices), dtype=np.int64)
            if selected_positions is None
            else np.asarray(selected_positions, dtype=np.int64)
        )

    def __len__(self) -> int:
        return len(self.positions)

    def __getitem__(self, item: int) -> dict[str, torch.Tensor]:
        position = int(self.positions[item])
        index = int(self.indices[position])
        a = self.arrays
        maps = torch.from_numpy(self.maps[position].astype(np.float32))
        if not self.use_physics:
            maps[6].zero_()
        spatial = torch.cat(
            (
                torch.from_numpy(self.anchor[position].astype(np.float32)),
                maps,
                torch.from_numpy(a.images[index][None]),
                torch.from_numpy(a.labels[index].astype(np.float32)[None]),
                torch.from_numpy(a.support[index].astype(np.float32)[None]),
                torch.from_numpy(a.cutout[index].astype(np.float32)[None]),
                torch.from_numpy(a.cutout_depth[index][None]),
                torch.from_numpy(a.mouth[index].astype(np.float32)[None]),
            ),
            dim=0,
        )
        if self.augment:
            rotation = int(torch.randint(0, 4, ()).item())
            spatial = torch.rot90(spatial, rotation, dims=(-2, -1))
            if bool(torch.rand(()) < 0.5):
                spatial = torch.flip(spatial, dims=(-1,))
            if bool(torch.rand(()) < 0.5):
                spatial = torch.flip(spatial, dims=(-2,))
        return {
            "anchor": spatial[0:3],
            "maps": spatial[3:10],
            "image": spatial[10:11],
            "labels": spatial[11,].long(),
            "support": spatial[12:13],
            "cutout": spatial[13:14],
            "cutout_depth": spatial[14:15],
            "mouth": spatial[15:16],
            "index": torch.tensor(index, dtype=torch.int64),
            "source": torch.tensor(self.source, dtype=torch.int64),
            "v4_gate": torch.tensor(float(self.v4_gate[position]), dtype=torch.float32),
            "v4_route": torch.tensor(float(self.v4_route[position]), dtype=torch.float32),
        }


def normalized_image_features(image: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    flattened = image.flatten(2)
    median = flattened.median(dim=2, keepdim=True).values[:, :, :, None]
    centered = image - median
    scale = torch.quantile(centered.abs().flatten(2), 0.985, dim=2, keepdim=True)[:, :, :, None]
    normalized = torch.clamp(centered / scale.clamp_min(1e-6), -4.0, 4.0) / 4.0
    smooth = F.avg_pool2d(normalized, 5, stride=1, padding=2)
    dx = F.pad(normalized[:, :, :, 1:] - normalized[:, :, :, :-1], (0, 1, 0, 0))
    dy = F.pad(normalized[:, :, 1:, :] - normalized[:, :, :-1, :], (0, 0, 0, 1))
    edge = torch.sqrt(dx.square() + dy.square() + 1e-8)
    edge_scale = torch.quantile(edge.flatten(2), 0.985, dim=2, keepdim=True)[:, :, :, None]
    edge = torch.clamp(edge / edge_scale.clamp_min(1e-6), 0.0, 1.0)
    return normalized, smooth, edge


def build_features(
    anchor: torch.Tensor,
    maps: torch.Tensor,
    image: torch.Tensor,
    fov: torch.Tensor,
) -> torch.Tensor:
    entropy = -(anchor * torch.log(anchor.clamp_min(1e-7))).sum(dim=1, keepdim=True)
    normalized, smooth, edge = normalized_image_features(image)
    # 3 anchor + entropy + 5 proposal/geometry maps + delta + 3 image +
    # physics backprojection + fov = 15 channels.
    return torch.cat(
        (
            anchor,
            entropy,
            maps[:, 0:5],
            maps[:, 5:6],
            normalized,
            smooth,
            edge,
            maps[:, 6:7],
            fov.expand(len(anchor), -1, -1, -1),
        ),
        dim=1,
    )


def balanced_probability_bce(
    probability: torch.Tensor, target: torch.Tensor, domain: torch.Tensor
) -> torch.Tensor:
    with torch.amp.autocast("cuda", enabled=False):
        probability = probability.float().clamp(1e-6, 1.0 - 1e-6)
        target = target.float()
        domain = domain.float()
        raw = F.binary_cross_entropy(probability, target, reduction="none")
    positive = target * domain
    negative = (1.0 - target) * domain
    dims = (1, 2, 3)
    positive_loss = (raw * positive).sum(dim=dims) / positive.sum(dim=dims).clamp_min(1.0)
    negative_loss = (raw * negative).sum(dim=dims) / negative.sum(dim=dims).clamp_min(1.0)
    has_positive = positive.sum(dim=dims) > 0
    return torch.where(has_positive, 0.5 * (positive_loss + negative_loss), negative_loss).mean()


def binary_dice_loss(probability: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    dims = (1, 2, 3)
    intersection = (probability * target).sum(dim=dims)
    denominator = probability.sum(dim=dims) + target.sum(dim=dims)
    positive = target.sum(dim=dims) > 0
    positive_loss = 1.0 - (2.0 * intersection + 1.0) / (denominator + 1.0)
    empty_loss = probability.mean(dim=dims)
    return torch.where(positive, positive_loss, empty_loss).mean()


def gradients(image: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    return image[:, :, 1:, :] - image[:, :, :-1, :], image[:, :, :, 1:] - image[:, :, :, :-1]


def corrector_loss(
    output: dict[str, torch.Tensor],
    batch: dict[str, torch.Tensor],
    fov: torch.Tensor,
    topology_supervision: bool = True,
) -> tuple[torch.Tensor, dict[str, float]]:
    target_foreground = (batch["labels"] != 0).float().unsqueeze(1)
    cutout = batch["cutout"]
    mouth = batch["mouth"]
    source = batch["source"]
    source_weight = torch.where(
        source == 0,
        source.new_full(source.shape, 0.55, dtype=torch.float32),
        torch.where(
            source == 1,
            source.new_full(source.shape, 1.0, dtype=torch.float32),
            source.new_full(source.shape, 1.30, dtype=torch.float32),
        ),
    )[:, None, None, None]
    domain = fov * source_weight
    has_cutout = (cutout.sum(dim=(1, 2, 3)) > 0).float()[:, None, None, None]

    raw_bce = balanced_probability_bce(output["raw_removal"], cutout, domain)
    raw_dice = binary_dice_loss(output["raw_removal"], cutout)
    effective_bce = balanced_probability_bce(output["removal"], cutout, domain)
    effective_dice = binary_dice_loss(output["removal"], cutout)
    mouth_bce = balanced_probability_bce(output["mouth"], mouth, domain)
    mouth_dice = binary_dice_loss(output["mouth"], mouth)

    candidate = output["candidate_foreground"]
    anchor = output["anchor_foreground"].detach()
    final_bce = balanced_probability_bce(candidate, target_foreground, fov)
    final_dice = binary_dice_loss(candidate, target_foreground)
    removed = (anchor - candidate).clamp_min(0.0)
    bank_loss = (removed * target_foreground).sum() / target_foreground.sum().clamp_min(1.0)
    notch_fill = (candidate * cutout * domain).sum() / (cutout * domain).sum().clamp_min(1.0)
    outside_edit = (removed * (1.0 - cutout) * fov).sum() / (anchor * fov).sum().clamp_min(1.0)
    ordinary_edit = (removed * (1.0 - has_cutout) * fov).sum() / (
        anchor * (1.0 - has_cutout) * fov
    ).sum().clamp_min(1.0)

    predicted_area = (removed * fov).sum(dim=(1, 2, 3))
    target_area = (anchor * cutout * fov).sum(dim=(1, 2, 3))
    area_scale = target_area + 0.02 * fov.sum() + 1.0
    area_budget = (torch.abs(predicted_area - target_area) / area_scale).mean()
    target_dy, target_dx = gradients(target_foreground)
    candidate_dy, candidate_dx = gradients(candidate)
    boundary = 0.5 * (
        F.l1_loss(candidate_dy, target_dy) + F.l1_loss(candidate_dx, target_dx)
    )
    deep_weight = cutout * (0.35 + 0.65 * batch["cutout_depth"]) * domain
    deep_fill = (candidate * deep_weight).sum() / deep_weight.sum().clamp_min(1.0)

    if topology_supervision:
        total = (
            0.58 * raw_bce
            + 0.42 * raw_dice
            + 0.62 * effective_bce
            + 0.46 * effective_dice
            + 0.22 * mouth_bce
            + 0.12 * mouth_dice
            + 0.42 * final_bce
            + 0.34 * final_dice
            + 1.45 * bank_loss
            + 0.82 * notch_fill
            + 0.34 * deep_fill
            + 1.10 * outside_edit
            + 2.10 * ordinary_edit
            + 0.28 * area_budget
            + 0.28 * boundary
        )
    else:
        # Generic local segmentation correction: no cutout, mouth, depth, or
        # exterior-connectivity target contributes to optimization.
        total = (
            0.95 * final_bce
            + 0.80 * final_dice
            + 1.45 * bank_loss
            + 0.55 * boundary
        )
    pieces = {
        "total": float(total.detach()),
        "raw_bce": float(raw_bce.detach()),
        "raw_dice": float(raw_dice.detach()),
        "effective_bce": float(effective_bce.detach()),
        "effective_dice": float(effective_dice.detach()),
        "mouth": float(mouth_bce.detach()),
        "final_bce": float(final_bce.detach()),
        "final_dice": float(final_dice.detach()),
        "bank": float(bank_loss.detach()),
        "notch_fill": float(notch_fill.detach()),
        "deep_fill": float(deep_fill.detach()),
        "outside_edit": float(outside_edit.detach()),
        "ordinary_edit": float(ordinary_edit.detach()),
        "area_budget": float(area_budget.detach()),
        "boundary": float(boundary.detach()),
    }
    return total, pieces


def make_corrector_loader(
    datasets: list[Dataset] | Dataset,
    batch_size: int,
    workers: int,
    shuffle: bool,
    device: torch.device,
) -> DataLoader:
    dataset = ConcatDataset(datasets) if isinstance(datasets, list) else datasets
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=workers,
        pin_memory=device.type == "cuda",
        persistent_workers=workers > 0,
    )


def metric_pair(
    truth: np.ndarray,
    cutout: np.ndarray,
    anchor: np.ndarray,
    candidate: np.ndarray,
) -> tuple[dict[str, float], dict[str, float]]:
    notch = np.asarray(cutout, dtype=bool)
    return case_metrics(truth, anchor, notch), case_metrics(truth, candidate, notch)


def aggregate_metric_pairs(
    pairs: list[tuple[dict[str, float], dict[str, float]]],
) -> dict[str, object]:
    result: dict[str, object] = {"cases": len(pairs)}
    for metric in METRIC_NAMES:
        anchor = np.asarray([pair[0][metric] for pair in pairs], dtype=float)
        candidate = np.asarray([pair[1][metric] for pair in pairs], dtype=float)
        finite = np.isfinite(anchor) & np.isfinite(candidate)
        if finite.any():
            difference = candidate[finite] - anchor[finite]
            result[metric] = {
                "anchor": float(anchor[finite].mean()),
                "candidate": float(candidate[finite].mean()),
                "difference": float(difference.mean()),
            }
    return result


@torch.no_grad()
def validation_score(
    model: LocalTopologyCorrectorV6,
    loaders: dict[str, DataLoader],
    device: torch.device,
    fov: torch.Tensor,
) -> tuple[float, dict[str, object]]:
    model.eval()
    report: dict[str, object] = {}
    oracle_notch: list[float] = []
    oracle_iou: list[float] = []
    raw_notch: list[float] = []
    raw_iou: list[float] = []
    ordinary_iou: list[float] = []
    for name, loader in loaders.items():
        pairs: list[tuple[dict[str, float], dict[str, float]]] = []
        subsets: list[bool] = []
        for batch in loader:
            anchor = batch["anchor"].to(device, non_blocking=True)
            maps = batch["maps"].to(device, non_blocking=True)
            image = batch["image"].to(device, non_blocking=True)
            output = model(build_features(anchor, maps, image, fov), anchor, fov)
            anchor_prediction = anchor.argmax(dim=1).cpu().numpy()
            candidate_prediction = output["candidate_probabilities"].argmax(dim=1).cpu().numpy()
            truth = batch["labels"].numpy()
            supervision_cutout = batch["cutout"][:, 0].numpy()
            for truth_value, cutout_value, anchor_value, candidate_value in zip(
                truth, supervision_cutout, anchor_prediction, candidate_prediction
            ):
                geometry_notch = indentation_mask(truth_value).astype(bool)
                pair = metric_pair(
                    truth_value, geometry_notch, anchor_value, candidate_value
                )
                pairs.append(pair)
                subsets.append(bool(cutout_value.any()))
        report[name] = aggregate_metric_pairs(pairs)
        for pair, concave in zip(pairs, subsets):
            iou_delta = pair[1]["foreground_iou"] - pair[0]["foreground_iou"]
            if concave:
                notch_delta = pair[1]["notch_preservation"] - pair[0]["notch_preservation"]
                raw_iou.append(iou_delta)
                if np.isfinite(notch_delta):
                    raw_notch.append(notch_delta)
                    if notch_delta > 0.0 and iou_delta >= -0.01:
                        oracle_notch.append(notch_delta)
                        oracle_iou.append(iou_delta)
                    else:
                        oracle_notch.append(0.0)
                        oracle_iou.append(0.0)
            else:
                ordinary_iou.append(iou_delta)
    score = (
        0.60 * float(np.mean(oracle_notch) if oracle_notch else 0.0)
        + 0.18 * float(np.mean(oracle_iou) if oracle_iou else 0.0)
        + 0.13 * float(np.mean(raw_notch) if raw_notch else 0.0)
        + 0.09 * float(np.mean(raw_iou) if raw_iou else 0.0)
        - 2.0 * max(0.0, -float(np.mean(ordinary_iou) if ordinary_iou else 0.0) - 0.002)
        - 0.25 * float(np.mean(np.asarray(ordinary_iou) < -0.01) if ordinary_iou else 0.0)
    )
    report["selection"] = {
        "score": score,
        "oracle_safe_notch_delta": float(np.mean(oracle_notch) if oracle_notch else 0.0),
        "oracle_safe_iou_delta": float(np.mean(oracle_iou) if oracle_iou else 0.0),
        "raw_concave_notch_delta": float(np.mean(raw_notch) if raw_notch else 0.0),
        "raw_concave_iou_delta": float(np.mean(raw_iou) if raw_iou else 0.0),
        "ordinary_iou_delta": float(np.mean(ordinary_iou) if ordinary_iou else 0.0),
        "ordinary_severe_loss_fraction": float(
            np.mean(np.asarray(ordinary_iou) < -0.01) if ordinary_iou else 0.0
        ),
    }
    return score, report


def train_corrector(
    args: argparse.Namespace,
    output_dir: Path,
    train_loader: DataLoader,
    validation_loaders: dict[str, DataLoader],
    fov: torch.Tensor,
    device: torch.device,
) -> tuple[LocalTopologyCorrectorV6, list[dict[str, object]]]:
    checkpoint_path = output_dir / "local_corrector_v6_best.pt"
    model = LocalTopologyCorrectorV6(
        input_channels=15,
        base_channels=args.base_channels,
        enforce_connectivity=args.variant != "no_connectivity",
    ).to(device)
    if checkpoint_path.exists() and not args.force_train:
        state = torch.load(checkpoint_path, map_location=device, weights_only=False)
        model.load_state_dict(state["model"])
        history_path = output_dir / "corrector_history.json"
        history = json.loads(history_path.read_text(encoding="utf-8")) if history_path.exists() else []
        print(f"reusing trained corrector {checkpoint_path}", flush=True)
        return model, history

    optimizer = torch.optim.AdamW(
        model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=max(1, args.epochs), eta_min=1e-5
    )
    amp_enabled = device.type == "cuda" and not args.disable_amp
    scaler = torch.amp.GradScaler("cuda", enabled=amp_enabled)
    best_score = -float("inf")
    best_epoch = -1
    history: list[dict[str, object]] = []
    for epoch in range(1, args.epochs + 1):
        started = time.time()
        model.train()
        loss_sum = 0.0
        pieces_sum: dict[str, float] = {}
        for batch in train_loader:
            anchor = batch["anchor"].to(device, non_blocking=True)
            maps = batch["maps"].to(device, non_blocking=True)
            image = batch["image"].to(device, non_blocking=True)
            moved = {
                key: value.to(device, non_blocking=True)
                for key, value in batch.items()
                if key not in {"anchor", "maps", "image", "index", "v4_gate", "v4_route"}
            }
            optimizer.zero_grad(set_to_none=True)
            with torch.amp.autocast("cuda", enabled=amp_enabled):
                output = model(build_features(anchor, maps, image, fov), anchor, fov)
                loss, pieces = corrector_loss(
                    output,
                    moved,
                    fov,
                    topology_supervision=args.variant != "no_topology_supervision",
                )
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            scaler.step(optimizer)
            scaler.update()
            loss_sum += float(loss.detach())
            for key, value in pieces.items():
                pieces_sum[key] = pieces_sum.get(key, 0.0) + value
        scheduler.step()
        score, validation = validation_score(model, validation_loaders, device, fov)
        batches = max(1, len(train_loader))
        row: dict[str, object] = {
            "epoch": epoch,
            "train_loss": loss_sum / batches,
            "train_pieces": {key: value / batches for key, value in pieces_sum.items()},
            "validation_score": score,
            "validation": validation,
            "learning_rate": float(optimizer.param_groups[0]["lr"]),
            "seconds": time.time() - started,
        }
        history.append(row)
        improved = score > best_score + 1e-6
        if improved:
            best_score = score
            best_epoch = epoch
            torch.save(
                {
                    "model": model.state_dict(),
                    "epoch": epoch,
                    "validation_score": score,
                    "validation": validation,
                    "base_channels": args.base_channels,
                    "input_channels": 15,
                    "seed": args.seed,
                    "variant": args.variant,
                    "enforce_connectivity": args.variant != "no_connectivity",
                    "args": vars(args),
                },
                checkpoint_path,
            )
        if epoch == 1 or epoch % args.progress_every == 0 or improved:
            selected = validation["selection"]
            print(
                f"epoch={epoch:03d} loss={row['train_loss']:.4f} score={score:+.5f} "
                f"oracle_notch={selected['oracle_safe_notch_delta']:+.4f} "
                f"ordinary_iou={selected['ordinary_iou_delta']:+.4f} "
                f"best={best_epoch:03d} time={row['seconds']:.1f}s",
                flush=True,
            )
        (output_dir / "corrector_history.json").write_text(
            json.dumps(history, indent=2), encoding="utf-8"
        )
        if epoch - best_epoch >= args.patience:
            print(f"corrector early stopping at epoch {epoch}; best epoch {best_epoch}", flush=True)
            break
    state = torch.load(checkpoint_path, map_location=device, weights_only=False)
    model.load_state_dict(state["model"])
    return model, history


def map_statistics(value: torch.Tensor, fov: torch.Tensor) -> list[torch.Tensor]:
    domain = fov.bool().expand(len(value), -1, -1, -1)
    flattened = value.masked_select(domain).reshape(len(value), -1)
    return [
        flattened.mean(dim=1),
        flattened.std(dim=1),
        torch.quantile(flattened, 0.90, dim=1),
        flattened.amax(dim=1),
    ]


def gate_feature_names() -> list[str]:
    maps = (
        "removal",
        "raw_removal",
        "mouth",
        "local_confidence",
        "anchor_entropy",
        "abs_backprojection",
        "v4_raw_cutout",
        "v4_connected_cutout",
        "v4_effective_cutout",
        "anchor_foreground",
        "abs_sdf",
        "abs_linear_eit",
    )
    names = [f"{name}_{stat}" for name in maps for stat in ("mean", "std", "q90", "max")]
    names.extend(
        (
            "v4_case_gate",
            "v4_route_enabled",
            "removed_anchor_fraction",
            "removal_entropy_overlap",
            "removal_physics_overlap",
            "removal_v4_cutout_overlap",
            "removal_mouth_overlap",
            "candidate_foreground_fraction",
        )
    )
    return names


def extract_gate_features(
    output: dict[str, torch.Tensor],
    anchor: torch.Tensor,
    maps: torch.Tensor,
    image: torch.Tensor,
    v4_gate: torch.Tensor,
    v4_route: torch.Tensor,
    fov: torch.Tensor,
) -> torch.Tensor:
    normalized, _, _ = normalized_image_features(image)
    anchor_foreground = output["anchor_foreground"]
    entropy = -(anchor * torch.log(anchor.clamp_min(1e-7))).sum(dim=1, keepdim=True)
    values = (
        output["removal"],
        output["raw_removal"],
        output["mouth"],
        output["local_confidence"],
        entropy,
        maps[:, 6:7].abs(),
        maps[:, 1:2],
        maps[:, 2:3],
        maps[:, 4:5],
        anchor_foreground,
        maps[:, 0:1].abs(),
        normalized.abs(),
    )
    features: list[torch.Tensor] = []
    for value in values:
        features.extend(map_statistics(value, fov))
    dimensions = (1, 2, 3)
    removal = output["removal"]
    removal_mass = removal.sum(dim=dimensions).clamp_min(1e-6)
    removed = (anchor_foreground - output["candidate_foreground"]).clamp_min(0.0)
    features.extend(
        (
            v4_gate.flatten(),
            v4_route.flatten(),
            removed.sum(dim=dimensions) / anchor_foreground.sum(dim=dimensions).clamp_min(1.0),
            (removal * entropy).sum(dim=dimensions) / removal_mass,
            (removal * maps[:, 6:7].abs()).sum(dim=dimensions) / removal_mass,
            (removal * maps[:, 1:2]).sum(dim=dimensions) / removal_mass,
            (removal * output["mouth"]).sum(dim=dimensions) / removal_mass,
            output["candidate_foreground"].mean(dim=dimensions),
        )
    )
    result = torch.stack(features, dim=1)
    expected = len(gate_feature_names())
    if result.shape[1] != expected:
        raise RuntimeError(f"gate feature mismatch: got {result.shape[1]}, expected {expected}")
    return result


@dataclass
class SplitInference:
    group: str
    ids: np.ndarray
    truth: np.ndarray
    concave: np.ndarray
    cutout: np.ndarray
    image: np.ndarray
    anchor_prediction: np.ndarray
    candidate_prediction: np.ndarray
    removal: np.ndarray
    mouth: np.ndarray
    local_confidence: np.ndarray
    gate_features: np.ndarray
    v4_gate: np.ndarray
    v4_route: np.ndarray
    anchor_metrics: list[dict[str, float]]
    candidate_metrics: list[dict[str, float]]


@torch.no_grad()
def infer_synthetic_split(
    group: str,
    model: LocalTopologyCorrectorV6,
    loader: DataLoader,
    device: torch.device,
    fov: torch.Tensor,
) -> SplitInference:
    model.eval()
    saved: dict[str, list[np.ndarray]] = {
        key: []
        for key in (
            "ids",
            "truth",
            "cutout",
            "image",
            "anchor_prediction",
            "candidate_prediction",
            "removal",
            "mouth",
            "local_confidence",
            "gate_features",
            "v4_gate",
            "v4_route",
        )
    }
    for batch in loader:
        anchor = batch["anchor"].to(device, non_blocking=True)
        maps = batch["maps"].to(device, non_blocking=True)
        image = batch["image"].to(device, non_blocking=True)
        output = model(build_features(anchor, maps, image, fov), anchor, fov)
        features = extract_gate_features(
            output,
            anchor,
            maps,
            image,
            batch["v4_gate"].to(device),
            batch["v4_route"].to(device),
            fov,
        )
        saved["ids"].append(batch["index"].numpy())
        saved["truth"].append(batch["labels"].numpy().astype(np.uint8))
        saved["cutout"].append(batch["cutout"][:, 0].numpy().astype(np.uint8))
        saved["image"].append(batch["image"][:, 0].numpy().astype(np.float32))
        saved["anchor_prediction"].append(anchor.argmax(dim=1).cpu().numpy().astype(np.uint8))
        saved["candidate_prediction"].append(
            output["candidate_probabilities"].argmax(dim=1).cpu().numpy().astype(np.uint8)
        )
        saved["removal"].append(output["removal"][:, 0].cpu().numpy().astype(np.float16))
        saved["mouth"].append(output["mouth"][:, 0].cpu().numpy().astype(np.float16))
        saved["local_confidence"].append(
            output["local_confidence"][:, 0].cpu().numpy().astype(np.float16)
        )
        saved["gate_features"].append(features.cpu().numpy().astype(np.float32))
        saved["v4_gate"].append(batch["v4_gate"].numpy())
        saved["v4_route"].append(batch["v4_route"].numpy())
    arrays = {key: np.concatenate(values, axis=0) for key, values in saved.items()}
    arrays["concave"] = arrays["cutout"].reshape(len(arrays["ids"]), -1).any(axis=1)
    arrays["cutout"] = np.asarray(
        [indentation_mask(truth) for truth in arrays["truth"]], dtype=np.uint8
    )
    anchor_metrics: list[dict[str, float]] = []
    candidate_metrics: list[dict[str, float]] = []
    for truth, cutout, anchor_prediction, candidate_prediction in zip(
        arrays["truth"], arrays["cutout"], arrays["anchor_prediction"], arrays["candidate_prediction"]
    ):
        anchor_row, candidate_row = metric_pair(
            truth, cutout, anchor_prediction, candidate_prediction
        )
        anchor_metrics.append(anchor_row)
        candidate_metrics.append(candidate_row)
    return SplitInference(
        group=group,
        anchor_metrics=anchor_metrics,
        candidate_metrics=candidate_metrics,
        **arrays,
    )


@torch.no_grad()
def infer_public_split(
    model: LocalTopologyCorrectorV6,
    cache_path: Path,
    archive: np.lib.npyio.NpzFile,
    batch_size: int,
    device: torch.device,
    fov: torch.Tensor,
    use_physics: bool = True,
) -> SplitInference:
    cache = np.load(cache_path, allow_pickle=False)
    anchor_all = np.asarray(cache["anchor_probabilities"], dtype=np.float16)
    maps_all = np.asarray(cache["v4_maps"], dtype=np.float16)
    gate_all = np.asarray(cache["v4_gate"], dtype=np.float32)
    route_all = np.asarray(cache["v4_route_enabled"], dtype=np.float32)
    images = np.asarray(archive["real_linear_images"], dtype=np.float32)
    labels = np.asarray(archive["real_labels"], dtype=np.uint8)
    ids = np.asarray(archive["real_ids"])
    notches = np.asarray([indentation_mask(label) for label in labels], dtype=np.uint8)
    saved: dict[str, list[np.ndarray]] = {
        key: []
        for key in (
            "anchor_prediction",
            "candidate_prediction",
            "removal",
            "mouth",
            "local_confidence",
            "gate_features",
        )
    }
    model.eval()
    for start in range(0, len(images), batch_size):
        stop = min(len(images), start + batch_size)
        anchor = torch.from_numpy(anchor_all[start:stop].astype(np.float32)).to(device)
        maps = torch.from_numpy(maps_all[start:stop].astype(np.float32)).to(device)
        if not use_physics:
            maps[:, 6].zero_()
        image = torch.from_numpy(images[start:stop, None]).to(device)
        output = model(build_features(anchor, maps, image, fov), anchor, fov)
        features = extract_gate_features(
            output,
            anchor,
            maps,
            image,
            torch.from_numpy(gate_all[start:stop]).to(device),
            torch.from_numpy(route_all[start:stop]).to(device),
            fov,
        )
        anchor_up = F.interpolate(anchor, (256, 256), mode="bilinear", align_corners=False)
        candidate_up = F.interpolate(
            output["candidate_probabilities"], (256, 256), mode="bilinear", align_corners=False
        )
        for name, value in (
            ("removal", output["removal"]),
            ("mouth", output["mouth"]),
            ("local_confidence", output["local_confidence"]),
        ):
            saved[name].append(
                F.interpolate(value, (256, 256), mode="bilinear", align_corners=False)[:, 0]
                .cpu()
                .numpy()
                .astype(np.float16)
            )
        saved["anchor_prediction"].append(anchor_up.argmax(dim=1).cpu().numpy().astype(np.uint8))
        saved["candidate_prediction"].append(
            candidate_up.argmax(dim=1).cpu().numpy().astype(np.uint8)
        )
        saved["gate_features"].append(features.cpu().numpy().astype(np.float32))
    values = {key: np.concatenate(chunks, axis=0) for key, chunks in saved.items()}
    anchor_metrics: list[dict[str, float]] = []
    candidate_metrics: list[dict[str, float]] = []
    for truth, notch, anchor_prediction, candidate_prediction in zip(
        labels, notches, values["anchor_prediction"], values["candidate_prediction"]
    ):
        anchor_row, candidate_row = metric_pair(
            truth, notch, anchor_prediction, candidate_prediction
        )
        anchor_metrics.append(anchor_row)
        candidate_metrics.append(candidate_row)
    return SplitInference(
        group="public_ktc",
        ids=ids,
        truth=labels,
        concave=notches.reshape(len(ids), -1).any(axis=1),
        cutout=notches,
        image=images,
        anchor_prediction=values["anchor_prediction"],
        candidate_prediction=values["candidate_prediction"],
        removal=values["removal"],
        mouth=values["mouth"],
        local_confidence=values["local_confidence"],
        gate_features=values["gate_features"],
        v4_gate=gate_all,
        v4_route=route_all,
        anchor_metrics=anchor_metrics,
        candidate_metrics=candidate_metrics,
    )


def gate_targets(result: SplitInference) -> np.ndarray:
    targets = np.zeros((len(result.ids), 3), dtype=np.float32)
    for index, (anchor, candidate) in enumerate(
        zip(result.anchor_metrics, result.candidate_metrics)
    ):
        notch_gain = candidate["notch_preservation"] - anchor["notch_preservation"]
        targets[index, 0] = float(notch_gain) if np.isfinite(notch_gain) else 0.0
        targets[index, 1] = float(anchor["foreground_iou"] - candidate["foreground_iou"])
        targets[index, 2] = float(anchor["bank_retention"] - candidate["bank_retention"])
    return targets


def train_risk_gate(
    args: argparse.Namespace,
    output_dir: Path,
    training: dict[str, SplitInference],
    device: torch.device,
) -> tuple[DualRiskQuantileGate, np.ndarray, np.ndarray, list[dict[str, float]]]:
    checkpoint_path = output_dir / "dual_risk_gate_v6_best.pt"
    features = np.concatenate([training[name].gate_features for name in DATASET_NAMES], axis=0)
    targets = np.concatenate([gate_targets(training[name]) for name in DATASET_NAMES], axis=0)
    groups = np.concatenate(
        [np.full(len(training[name].ids), index, dtype=np.int64) for index, name in enumerate(DATASET_NAMES)]
    )
    has_cutout = np.concatenate([training[name].concave for name in DATASET_NAMES])
    mean = features.mean(axis=0).astype(np.float32)
    std = features.std(axis=0).astype(np.float32)
    std[std < 1e-5] = 1.0
    normalized = ((features - mean) / std).astype(np.float32)

    rng = np.random.default_rng(args.seed + 119)
    order = rng.permutation(len(normalized))
    internal_count = max(64, int(round(0.16 * len(order))))
    internal = order[:internal_count]
    fit = order[internal_count:]
    model = DualRiskQuantileGate(normalized.shape[1]).to(device)
    if checkpoint_path.exists() and not args.force_train:
        state = torch.load(checkpoint_path, map_location=device, weights_only=False)
        model.load_state_dict(state["model"])
        mean = np.asarray(state["feature_mean"], dtype=np.float32)
        std = np.asarray(state["feature_std"], dtype=np.float32)
        history_path = output_dir / "risk_gate_history.json"
        history = json.loads(history_path.read_text(encoding="utf-8")) if history_path.exists() else []
        print(f"reusing trained risk gate {checkpoint_path}", flush=True)
        return model, mean, std, history

    x = torch.from_numpy(normalized)
    y = torch.from_numpy(targets)
    weights = np.where(groups == 0, 0.65, np.where(groups == 1, 1.0, 1.35)).astype(np.float64)
    weights *= np.where(has_cutout, 1.0, 1.35)
    sampler = WeightedRandomSampler(weights[fit], num_samples=len(fit), replacement=True)
    fit_dataset = TensorDataset(x[fit], y[fit])
    fit_loader = DataLoader(
        fit_dataset,
        batch_size=args.gate_batch_size,
        sampler=sampler,
        num_workers=0,
    )
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=args.gate_learning_rate, weight_decay=2e-4
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=max(1, args.gate_epochs), eta_min=2e-5
    )
    x_internal = x[internal].to(device)
    y_internal = y[internal].to(device)
    best = float("inf")
    best_epoch = -1
    history: list[dict[str, float]] = []
    for epoch in range(1, args.gate_epochs + 1):
        model.train()
        total = 0.0
        for batch_x, batch_y in fit_loader:
            batch_x = batch_x.to(device)
            batch_y = batch_y.to(device)
            optimizer.zero_grad(set_to_none=True)
            loss = quantile_loss(model(batch_x), batch_y)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 4.0)
            optimizer.step()
            total += float(loss.detach())
        scheduler.step()
        model.eval()
        with torch.no_grad():
            internal_loss = float(quantile_loss(model(x_internal), y_internal).detach())
        row = {
            "epoch": float(epoch),
            "train_loss": total / max(1, len(fit_loader)),
            "internal_validation_loss": internal_loss,
            "learning_rate": float(optimizer.param_groups[0]["lr"]),
        }
        history.append(row)
        if internal_loss < best - 1e-6:
            best = internal_loss
            best_epoch = epoch
            torch.save(
                {
                    "model": model.state_dict(),
                    "epoch": epoch,
                    "internal_validation_loss": internal_loss,
                    "feature_mean": mean,
                    "feature_std": std,
                    "feature_names": gate_feature_names(),
                    "seed": args.seed,
                    "training_only": True,
                },
                checkpoint_path,
            )
        if epoch == 1 or epoch % 25 == 0:
            print(
                f"gate epoch={epoch:03d} train={row['train_loss']:.5f} "
                f"internal={internal_loss:.5f} best={best_epoch:03d}",
                flush=True,
            )
        if epoch - best_epoch >= args.gate_patience:
            break
    (output_dir / "risk_gate_history.json").write_text(
        json.dumps(history, indent=2), encoding="utf-8"
    )
    state = torch.load(checkpoint_path, map_location=device, weights_only=False)
    model.load_state_dict(state["model"])
    return model, mean, std, history


@torch.no_grad()
def risk_predictions(
    model: DualRiskQuantileGate,
    features: np.ndarray,
    mean: np.ndarray,
    std: np.ndarray,
    device: torch.device,
) -> np.ndarray:
    normalized = torch.from_numpy(((features - mean) / std).astype(np.float32)).to(device)
    predictions: list[np.ndarray] = []
    model.eval()
    for start in range(0, len(normalized), 1024):
        value = model(normalized[start : start + 1024]).cpu().numpy()
        predictions.append(np.sort(value, axis=2))
    return np.concatenate(predictions, axis=0)


def routed_metrics(
    result: SplitInference,
    selected: np.ndarray,
) -> tuple[list[dict[str, float]], np.ndarray]:
    gated_prediction = np.where(
        selected[:, None, None], result.candidate_prediction, result.anchor_prediction
    )
    # Routing is case-level, so its metrics are exactly one of the two already
    # computed rows.  Reusing them makes validation grid search deterministic
    # and avoids hundreds of thousands of redundant morphology operations.
    metrics = [
        result.candidate_metrics[index] if selected[index] else result.anchor_metrics[index]
        for index in range(len(result.ids))
    ]
    return metrics, gated_prediction


def subset_mask(result: SplitInference, subset: str, strict_public_ids: set[str]) -> np.ndarray:
    if result.group == "public_ktc":
        nonconvex = np.asarray([str(value) in strict_public_ids for value in result.ids])
        return nonconvex if subset == "concave" else ~nonconvex
    return result.concave if subset == "concave" else ~result.concave


def mean_delta(
    candidate: list[dict[str, float]],
    anchor: list[dict[str, float]],
    selected: np.ndarray,
    metric: str,
) -> float:
    values = np.asarray(
        [candidate[index][metric] - anchor[index][metric] for index in np.flatnonzero(selected)],
        dtype=float,
    )
    values = values[np.isfinite(values)]
    return float(values.mean()) if values.size else 0.0


def calibrate_gate(
    validation: dict[str, SplitInference],
    predictions: dict[str, np.ndarray],
) -> tuple[dict[str, object], list[dict[str, object]]]:
    benefit_thresholds = (-0.02, -0.01, -0.005, 0.0, 0.005, 0.01, 0.02, 0.03, 0.05)
    iou_tolerances = (0.0, 0.003, 0.006, 0.01, 0.015, 0.02, 0.03, 0.05)
    bank_tolerances = (0.0, 0.005, 0.01, 0.02, 0.03, 0.05)
    rows: list[dict[str, object]] = []
    for benefit_threshold in benefit_thresholds:
        for iou_tolerance in iou_tolerances:
            for bank_tolerance in bank_tolerances:
                selections: dict[str, np.ndarray] = {}
                for name in DATASET_NAMES:
                    prediction = predictions[name]
                    selections[name] = (
                        (prediction[:, 0, 0] > benefit_threshold)
                        & (prediction[:, 1, 2] <= iou_tolerance)
                        & (prediction[:, 2, 2] <= bank_tolerance)
                    )
                statistics: dict[str, float] = {}
                for name in DATASET_NAMES:
                    result = validation[name]
                    concave = result.concave
                    ordinary = ~concave
                    gated, _ = routed_metrics(result, selections[name])
                    for subset_name, subset in (("concave", concave), ("ordinary", ordinary)):
                        statistics[f"{name}_{subset_name}_iou"] = mean_delta(
                            gated, result.anchor_metrics, subset, "foreground_iou"
                        )
                        statistics[f"{name}_{subset_name}_notch"] = mean_delta(
                            gated, result.anchor_metrics, subset, "notch_preservation"
                        )
                        statistics[f"{name}_{subset_name}_selected"] = float(
                            selections[name][subset].mean() if subset.any() else 0.0
                        )
                        severe = np.asarray(
                            [
                                gated[index]["foreground_iou"]
                                - result.anchor_metrics[index]["foreground_iou"]
                                for index in np.flatnonzero(subset)
                            ],
                            dtype=float,
                        )
                        statistics[f"{name}_{subset_name}_severe"] = float(
                            np.mean(severe < -0.01) if severe.size else 0.0
                        )
                ordinary_iou = np.mean(
                    [
                        statistics["base_ordinary_iou"],
                        statistics["biological_ordinary_iou"],
                    ]
                )
                ordinary_severe = max(
                    statistics["base_ordinary_severe"],
                    statistics["biological_ordinary_severe"],
                )
                feasible = (
                    ordinary_iou >= -0.001
                    and ordinary_severe <= 0.02
                    and statistics["base_concave_iou"] >= -0.005
                    and statistics["biological_concave_iou"] >= -0.003
                    and statistics["stress_concave_iou"] >= -0.006
                )
                objective = (
                    0.10 * statistics["base_concave_notch"]
                    + 0.42 * statistics["biological_concave_notch"]
                    + 0.48 * statistics["stress_concave_notch"]
                    + 0.06 * statistics["base_concave_iou"]
                    + 0.10 * statistics["biological_concave_iou"]
                    + 0.10 * statistics["stress_concave_iou"]
                    + 0.08 * ordinary_iou
                    - 0.25 * ordinary_severe
                )
                penalty = (
                    4.0 * max(0.0, -ordinary_iou - 0.001)
                    + 0.5 * max(0.0, ordinary_severe - 0.02)
                    + 2.0 * max(0.0, -statistics["biological_concave_iou"] - 0.003)
                    + 1.5 * max(0.0, -statistics["stress_concave_iou"] - 0.006)
                )
                rows.append(
                    {
                        "minimum_predicted_benefit_q20": benefit_threshold,
                        "maximum_predicted_iou_loss_q80": iou_tolerance,
                        "maximum_predicted_bank_loss_q80": bank_tolerance,
                        "feasible": feasible,
                        "objective": float(objective - penalty),
                        **statistics,
                    }
                )
    # An exact fallback is always available and prevents unsafe forced edits.
    rows.append(
        {
            "minimum_predicted_benefit_q20": float("inf"),
            "maximum_predicted_iou_loss_q80": 0.0,
            "maximum_predicted_bank_loss_q80": 0.0,
            "feasible": True,
            "objective": 0.0,
            "exact_fallback": True,
        }
    )
    feasible_rows = [row for row in rows if bool(row["feasible"])]
    best = max(feasible_rows, key=lambda row: float(row["objective"]))
    return best, sorted(rows, key=lambda row: float(row["objective"]), reverse=True)


def apply_gate(prediction: np.ndarray, rule: dict[str, object]) -> np.ndarray:
    threshold = float(rule["minimum_predicted_benefit_q20"])
    if not np.isfinite(threshold):
        return np.zeros(len(prediction), dtype=bool)
    return (
        (prediction[:, 0, 0] > threshold)
        & (prediction[:, 1, 2] <= float(rule["maximum_predicted_iou_loss_q80"]))
        & (prediction[:, 2, 2] <= float(rule["maximum_predicted_bank_loss_q80"]))
    )


def method_summary(
    result: SplitInference,
    gated_metrics: list[dict[str, float]],
    selected: np.ndarray,
    strict_public_ids: set[str],
) -> dict[str, object]:
    summary: dict[str, object] = {}
    for subset_name in ("all", "concave", "ordinary"):
        mask = (
            np.ones(len(result.ids), dtype=bool)
            if subset_name == "all"
            else subset_mask(result, subset_name, strict_public_ids)
        )
        subset: dict[str, object] = {
            "cases": int(mask.sum()),
            "selected_fraction": float(selected[mask].mean() if mask.any() else 0.0),
        }
        for method_name, rows in (
            ("anchor_v4", result.anchor_metrics),
            ("candidate_v6", result.candidate_metrics),
            ("gated_v6", gated_metrics),
        ):
            metrics: dict[str, float] = {}
            for metric in METRIC_NAMES:
                values = np.asarray([rows[index][metric] for index in np.flatnonzero(mask)], dtype=float)
                metrics[metric] = float(np.nanmean(values)) if np.isfinite(values).any() else float("nan")
            subset[method_name] = metrics
        iou_delta = np.asarray(
            [
                gated_metrics[index]["foreground_iou"]
                - result.anchor_metrics[index]["foreground_iou"]
                for index in np.flatnonzero(mask)
            ],
            dtype=float,
        )
        subset["safety"] = {
            "mean_iou_delta": float(iou_delta.mean()) if iou_delta.size else 0.0,
            "worst_iou_delta": float(iou_delta.min()) if iou_delta.size else 0.0,
            "fraction_iou_loss_over_0_01": float(np.mean(iou_delta < -0.01)) if iou_delta.size else 0.0,
        }
        if subset_name != "ordinary" and mask.any():
            notch_delta = np.asarray(
                [
                    gated_metrics[index]["notch_preservation"]
                    - result.anchor_metrics[index]["notch_preservation"]
                    for index in np.flatnonzero(mask)
                ],
                dtype=float,
            )
            bank_delta = np.asarray(
                [
                    gated_metrics[index]["bank_retention"]
                    - result.anchor_metrics[index]["bank_retention"]
                    for index in np.flatnonzero(mask)
                ],
                dtype=float,
            )
            subset["concavity_direction"] = {
                "mean_notch_delta": float(np.nanmean(notch_delta)),
                "fraction_notch_improved_over_0_02": float(np.nanmean(notch_delta > 0.02)),
                "fraction_correct_trend_with_iou_loss_under_0_02": float(
                    np.nanmean((notch_delta > 0.02) & (iou_delta >= -0.02))
                ),
                "absolute_visible_concavity_rate": float(
                    np.nanmean(
                        np.asarray(
                            [gated_metrics[index]["notch_preservation"] for index in np.flatnonzero(mask)]
                        )
                        >= 0.10
                    )
                ),
                "mean_bank_delta": float(np.nanmean(bank_delta)),
            }
        summary[subset_name] = subset
    return summary


def write_case_rows(
    path: Path,
    results: dict[str, SplitInference],
    gated: dict[str, list[dict[str, float]]],
    selected: dict[str, np.ndarray],
    risk: dict[str, np.ndarray],
    strict_public_ids: set[str],
) -> None:
    rows: list[dict[str, object]] = []
    for group, result in results.items():
        concave = subset_mask(result, "concave", strict_public_ids)
        targets = gate_targets(result)
        for index, case_id in enumerate(result.ids):
            subset = "concave" if concave[index] else "ordinary"
            for method, metrics in (
                ("anchor_v4", result.anchor_metrics[index]),
                ("candidate_v6", result.candidate_metrics[index]),
                ("gated_v6", gated[group][index]),
            ):
                rows.append(
                    {
                        "seed": result.group and int(path.parent.name.rsplit("_", 1)[-1])
                        if path.parent.name.rsplit("_", 1)[-1].isdigit()
                        else "",
                        "group": group,
                        "case_id": str(case_id),
                        "subset": subset,
                        "method": method,
                        "gate_selected": int(selected[group][index]),
                        "predicted_benefit_q20": float(risk[group][index, 0, 0]),
                        "predicted_benefit_q50": float(risk[group][index, 0, 1]),
                        "predicted_iou_loss_q80": float(risk[group][index, 1, 2]),
                        "predicted_bank_loss_q80": float(risk[group][index, 2, 2]),
                        "actual_notch_gain_candidate": float(targets[index, 0]),
                        "actual_iou_loss_candidate": float(targets[index, 1]),
                        "actual_bank_loss_candidate": float(targets[index, 2]),
                        **metrics,
                    }
                )
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def save_calibration_grid(path: Path, rows: list[dict[str, object]]) -> None:
    keys: list[str] = []
    for row in rows:
        for key in row:
            if key not in keys:
                keys.append(key)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def save_training_plot(
    path: Path,
    corrector_history: list[dict[str, object]],
    gate_history: list[dict[str, float]],
) -> None:
    figure, axes = plt.subplots(1, 3, figsize=(13.5, 3.8))
    if corrector_history:
        epochs = [row["epoch"] for row in corrector_history]
        axes[0].plot(epochs, [row["train_loss"] for row in corrector_history])
        axes[1].plot(epochs, [row["validation_score"] for row in corrector_history])
    if gate_history:
        epochs = [row["epoch"] for row in gate_history]
        axes[2].plot(epochs, [row["train_loss"] for row in gate_history], label="train")
        axes[2].plot(
            epochs,
            [row["internal_validation_loss"] for row in gate_history],
            label="train-held-out",
        )
        axes[2].legend(fontsize=8)
    axes[0].set_title("Local corrector loss")
    axes[1].set_title("Synthetic validation score")
    axes[2].set_title("Dual-risk quantile loss")
    for axis in axes:
        axis.grid(alpha=0.25)
        axis.set_xlabel("epoch")
    figure.tight_layout()
    figure.savefig(path, dpi=190)
    plt.close(figure)


def save_reliability_plot(
    path: Path,
    validation: dict[str, SplitInference],
    risk: dict[str, np.ndarray],
) -> None:
    targets = np.concatenate([gate_targets(validation[name]) for name in DATASET_NAMES], axis=0)
    predictions = np.concatenate([risk[name] for name in DATASET_NAMES], axis=0)
    panels = (
        (0, 0, "Notch benefit: q20", "benefit"),
        (1, 2, "IoU loss: q80", "risk"),
        (2, 2, "Bank loss: q80", "risk"),
    )
    figure, axes = plt.subplots(1, 3, figsize=(13.0, 3.8))
    for axis, (target_index, quantile_index, title, kind) in zip(axes, panels):
        predicted = predictions[:, target_index, quantile_index]
        observed = targets[:, target_index]
        edges = np.quantile(predicted, np.linspace(0.0, 1.0, 9))
        edges = np.unique(edges)
        x_values: list[float] = []
        y_values: list[float] = []
        counts: list[int] = []
        for lower, upper in zip(edges[:-1], edges[1:]):
            selected = (predicted >= lower) & (
                predicted <= upper if upper == edges[-1] else predicted < upper
            )
            if selected.any():
                x_values.append(float(predicted[selected].mean()))
                y_values.append(float(observed[selected].mean()))
                counts.append(int(selected.sum()))
        axis.scatter(x_values, y_values, s=np.asarray(counts) * 0.35 + 12, alpha=0.8)
        lower = min(x_values + y_values) if x_values else -0.01
        upper = max(x_values + y_values) if x_values else 0.01
        axis.plot([lower, upper], [lower, upper], "k--", linewidth=1)
        coverage = float(np.mean(observed >= predicted)) if kind == "benefit" else float(
            np.mean(observed <= predicted)
        )
        axis.set_title(f"{title}\nempirical coverage={coverage:.3f}")
        axis.set_xlabel("predicted quantile")
        axis.set_ylabel("observed bin mean")
        axis.grid(alpha=0.25)
    figure.tight_layout()
    figure.savefig(path, dpi=200)
    plt.close(figure)


def choose_montage_cases(
    results: dict[str, SplitInference],
    gated: dict[str, list[dict[str, float]]],
    strict_public_ids: set[str],
    ordinary: bool,
    count: int = 8,
) -> list[tuple[str, int]]:
    candidates: list[tuple[float, str, int]] = []
    for group, result in results.items():
        mask = subset_mask(result, "ordinary" if ordinary else "concave", strict_public_ids)
        for index in np.flatnonzero(mask):
            if ordinary:
                value = abs(
                    gated[group][index]["foreground_iou"]
                    - result.anchor_metrics[index]["foreground_iou"]
                )
            else:
                value = (
                    gated[group][index]["notch_preservation"]
                    - result.anchor_metrics[index]["notch_preservation"]
                )
            candidates.append((float(value), group, int(index)))
    candidates.sort(reverse=not ordinary)
    if not candidates:
        return []
    if ordinary:
        candidates.sort(reverse=True)
    selected = candidates[: max(1, count // 2)]
    if not ordinary:
        selected.extend(candidates[-max(1, count // 2) :])
    return [(group, index) for _, group, index in selected[:count]]


def save_montage(
    path: Path,
    results: dict[str, SplitInference],
    gated_predictions: dict[str, np.ndarray],
    gated_metrics: dict[str, list[dict[str, float]]],
    selected_flags: dict[str, np.ndarray],
    risk: dict[str, np.ndarray],
    strict_public_ids: set[str],
    ordinary: bool,
) -> None:
    chosen = choose_montage_cases(results, gated_metrics, strict_public_ids, ordinary)
    if not chosen:
        return
    columns = ("linear EIT", "truth", "v4 anchor", "v6 removal", "v6 candidate", "v6 gated")
    figure, axes = plt.subplots(len(chosen), len(columns), figsize=(13.6, 2.05 * len(chosen)), squeeze=False)
    for row, (group, index) in enumerate(chosen):
        result = results[group]
        linear = result.image[index]
        if linear.shape != result.truth[index].shape:
            linear = torch.from_numpy(linear[None, None]).float()
            linear = F.interpolate(linear, result.truth[index].shape, mode="bilinear", align_corners=False)[0, 0].numpy()
        scale = max(float(np.percentile(np.abs(linear), 99)), 1e-6)
        panels = (
            (linear, "coolwarm", -scale, scale),
            (result.truth[index], "viridis", 0, 2),
            (result.anchor_prediction[index], "viridis", 0, 2),
            (result.removal[index], "magma", 0, 1),
            (result.candidate_prediction[index], "viridis", 0, 2),
            (gated_predictions[group][index], "viridis", 0, 2),
        )
        for column, (image, cmap, vmin, vmax) in enumerate(panels):
            axes[row, column].imshow(image, cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest")
            axes[row, column].set_axis_off()
            if row == 0:
                axes[row, column].set_title(columns[column], fontsize=9)
        delta_iou = gated_metrics[group][index]["foreground_iou"] - result.anchor_metrics[index]["foreground_iou"]
        delta_notch = gated_metrics[group][index]["notch_preservation"] - result.anchor_metrics[index]["notch_preservation"]
        axes[row, 0].set_ylabel(
            f"{group}/{result.ids[index]}\nselected={int(selected_flags[group][index])} "
            f"dIoU={delta_iou:+.3f} dN={delta_notch:+.3f}\n"
            f"qB={risk[group][index,0,0]:+.3f} qR={risk[group][index,1,2]:+.3f}",
            fontsize=7,
        )
    figure.suptitle(
        "Ordinary-case safety audit" if ordinary else "Independent concave-case v6 comparison",
        fontsize=13,
    )
    figure.tight_layout(rect=(0, 0, 1, 0.98))
    figure.savefig(path, dpi=210)
    plt.close(figure)


def save_predictions(
    path: Path,
    results: dict[str, SplitInference],
    gated_predictions: dict[str, np.ndarray],
    selected: dict[str, np.ndarray],
    risk: dict[str, np.ndarray],
) -> None:
    arrays: dict[str, np.ndarray] = {}
    for group, result in results.items():
        prefix = group.replace("_ktc", "")
        arrays[f"{prefix}_ids"] = result.ids
        arrays[f"{prefix}_truth"] = result.truth
        arrays[f"{prefix}_concave"] = result.concave
        arrays[f"{prefix}_cutout"] = result.cutout
        arrays[f"{prefix}_image"] = result.image
        arrays[f"{prefix}_anchor"] = result.anchor_prediction
        arrays[f"{prefix}_candidate"] = result.candidate_prediction
        arrays[f"{prefix}_gated"] = gated_predictions[group]
        arrays[f"{prefix}_removal"] = result.removal
        arrays[f"{prefix}_selected"] = selected[group]
        arrays[f"{prefix}_risk_quantiles"] = risk[group]
    np.savez_compressed(path, **arrays)


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    device = choose_device(args.device)
    archives = load_archives(args)
    prepared = {name: data_tools.prepare_arrays(archives[name], name) for name in DATASET_NAMES}
    router = json.loads(args.anchor_router.resolve().read_text(encoding="utf-8"))
    threshold = float(router["threshold"])
    model_v4, state_v4 = load_v4(args.checkpoint, prepared["base"].fov_mask, device)
    print(
        f"v6 seed={args.seed} variant={args.variant} device={device} "
        f"v4_epoch={state_v4.get('epoch')} "
        f"anchor_threshold={threshold:g}",
        flush=True,
    )
    cache_paths = ensure_caches(
        args, output_dir, archives, prepared, model_v4, device, threshold
    )
    del model_v4
    if device.type == "cuda":
        torch.cuda.empty_cache()
    if args.cache_only:
        return

    fov = torch.from_numpy(prepared["base"].fov_mask.astype(np.float32))[None, None].to(device)
    train_parts: list[Dataset] = []
    use_physics = args.variant != "no_physics"
    for source, name in enumerate(DATASET_NAMES):
        base_dataset = CachedCorrectorDataset(
            prepared[name], cache_paths[f"{name}_train"], source, augment=True,
            use_physics=use_physics,
        )
        train_parts.append(base_dataset)
        if name == "stress":
            for _ in range(max(1, args.stress_repeat) - 1):
                train_parts.append(base_dataset)
        ordinary_positions = np.flatnonzero(
            prepared[name]
            .cutout[base_dataset.indices]
            .reshape(len(base_dataset.indices), -1)
            .sum(axis=1)
            == 0
        )
        for _ in range(max(1, args.ordinary_repeat) - 1):
            if ordinary_positions.size:
                train_parts.append(Subset(base_dataset, ordinary_positions.tolist()))
    train_loader = make_corrector_loader(
        train_parts, args.batch_size, args.workers, True, device
    )
    validation_datasets = {
        name: CachedCorrectorDataset(
            prepared[name], cache_paths[f"{name}_validation"], source, augment=False,
            use_physics=use_physics,
        )
        for source, name in enumerate(DATASET_NAMES)
    }
    validation_loaders = {
        name: make_corrector_loader(dataset, args.batch_size, args.workers, False, device)
        for name, dataset in validation_datasets.items()
    }
    corrector, corrector_history = train_corrector(
        args, output_dir, train_loader, validation_loaders, fov, device
    )
    del train_loader, train_parts

    print("inferring unique train and validation cases for dual-risk gate", flush=True)
    training_results: dict[str, SplitInference] = {}
    validation_results: dict[str, SplitInference] = {}
    for source, name in enumerate(DATASET_NAMES):
        train_dataset = CachedCorrectorDataset(
            prepared[name], cache_paths[f"{name}_train"], source, augment=False,
            use_physics=use_physics,
        )
        training_results[name] = infer_synthetic_split(
            name,
            corrector,
            make_corrector_loader(train_dataset, args.batch_size, args.workers, False, device),
            device,
            fov,
        )
        validation_results[name] = infer_synthetic_split(
            name, corrector, validation_loaders[name], device, fov
        )
    gate, feature_mean, feature_std, gate_history = train_risk_gate(
        args, output_dir, training_results, device
    )
    validation_risk = {
        name: risk_predictions(
            gate,
            validation_results[name].gate_features,
            feature_mean,
            feature_std,
            device,
        )
        for name in DATASET_NAMES
    }
    rule, grid = calibrate_gate(validation_results, validation_risk)
    save_calibration_grid(output_dir / "validation_gate_grid.csv", grid)
    print(f"validation-calibrated gate: {rule}", flush=True)

    print("running one-time independent synthetic and public evaluation", flush=True)
    test_results: dict[str, SplitInference] = {}
    for source, name in enumerate(DATASET_NAMES):
        test_dataset = CachedCorrectorDataset(
            prepared[name], cache_paths[f"{name}_test"], source, augment=False,
            use_physics=use_physics,
        )
        test_results[name] = infer_synthetic_split(
            name,
            corrector,
            make_corrector_loader(test_dataset, args.batch_size, args.workers, False, device),
            device,
            fov,
        )
    test_results["public_ktc"] = infer_public_split(
        corrector,
        cache_paths["public"],
        archives["base"],
        args.batch_size,
        device,
        fov,
        use_physics=use_physics,
    )
    test_risk = {
        name: risk_predictions(
            gate, result.gate_features, feature_mean, feature_std, device
        )
        for name, result in test_results.items()
    }
    selected = {name: apply_gate(test_risk[name], rule) for name in test_results}
    gated_metrics: dict[str, list[dict[str, float]]] = {}
    gated_predictions: dict[str, np.ndarray] = {}
    for name, result in test_results.items():
        gated_metrics[name], gated_predictions[name] = routed_metrics(result, selected[name])

    audit = json.loads(args.audit.resolve().read_text(encoding="utf-8"))
    strict_public_ids = {str(value) for value in audit["nonconvex_ids"]}
    evaluation = {
        name: method_summary(
            result, gated_metrics[name], selected[name], strict_public_ids
        )
        for name, result in test_results.items()
    }
    write_case_rows(
        output_dir / "v6_case_metrics.csv",
        test_results,
        gated_metrics,
        selected,
        test_risk,
        strict_public_ids,
    )
    save_predictions(
        output_dir / "v6_predictions.npz",
        test_results,
        gated_predictions,
        selected,
        test_risk,
    )
    save_training_plot(
        output_dir / "v6_training_curves.png", corrector_history, gate_history
    )
    save_reliability_plot(
        output_dir / "v6_gate_reliability.png", validation_results, validation_risk
    )
    save_montage(
        output_dir / "v6_concave_comparison.png",
        test_results,
        gated_predictions,
        gated_metrics,
        selected,
        test_risk,
        strict_public_ids,
        ordinary=False,
    )
    save_montage(
        output_dir / "v6_ordinary_safety.png",
        test_results,
        gated_predictions,
        gated_metrics,
        selected,
        test_risk,
        strict_public_ids,
        ordinary=True,
    )

    summary = {
        "method": "v6 frozen-v4 local topology corrector with dual quantile risk gate",
        "ablation_variant": args.variant,
        "seed": args.seed,
        "device": str(device),
        "checkpoint_v4": str(args.checkpoint.resolve()),
        "checkpoint_v4_epoch": int(state_v4.get("epoch", -1)),
        "v4_anchor_threshold": threshold,
        "corrector_checkpoint": str((output_dir / "local_corrector_v6_best.pt").resolve()),
        "risk_gate_checkpoint": str((output_dir / "dual_risk_gate_v6_best.pt").resolve()),
        "gate_rule": rule,
        "gate_feature_names": gate_feature_names(),
        "data_protocol": {
            "corrector_training": "synthetic train only",
            "corrector_checkpoint_selection": "synthetic validation only",
            "risk_gate_training": "synthetic train only with an internal train holdout",
            "risk_gate_rule_calibration": "synthetic validation only",
            "synthetic_test_or_public_truth_used_for_selection": False,
            "physics_backprojection_input": use_physics,
            "topology_supervision": args.variant != "no_topology_supervision",
            "exterior_connectivity_operator": args.variant != "no_connectivity",
        },
        "evaluation": evaluation,
    }
    (output_dir / "v6_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps({"seed": args.seed, "rule": rule, "evaluation": evaluation}, indent=2), flush=True)


if __name__ == "__main__":
    main()
