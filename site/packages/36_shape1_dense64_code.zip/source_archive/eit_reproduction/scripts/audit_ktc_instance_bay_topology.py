"""Audit whether deployed KTC edits recover the *true* exterior-connected bay.

The historical ``notch_preservation`` metric measures only how much of every
truth convex-hull defect remains background.  It has no precision term, does
not match lesion instances, and cannot distinguish a correctly located bay
from an arbitrary cut elsewhere.  This script performs an evaluation-only,
class-aware instance match and reports defect overlap, depth and direction in
addition to region, boundary and topology checks.

Public truth is used only here, after reconstruction.  Nothing written by this
script is an inference feature or a candidate-selection input.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage as ndi
from scipy.optimize import linear_sum_assignment
from scipy.spatial import ConvexHull, QhullError


STRUCTURE = np.ones((3, 3), dtype=np.uint8)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--predictions", type=Path,
        default=Path(r"E:\Codex\ktc_instance_bay_action_gate_v3_seed20260820\predictions.npz"),
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=Path(r"E:\Codex\ktc_instance_bay_topology_audit_v3_seed20260820"),
    )
    parser.add_argument("--bootstrap-repetitions", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260820)
    return parser.parse_args()


def convex_hull_mask(binary: np.ndarray) -> np.ndarray:
    rows, columns = np.nonzero(binary)
    if rows.size < 3:
        return binary.copy()
    points = np.column_stack((columns, rows))
    try:
        hull = ConvexHull(points)
    except QhullError:
        return binary.copy()
    canvas = Image.new("1", (binary.shape[1], binary.shape[0]), 0)
    polygon = [tuple(point) for point in points[hull.vertices]]
    ImageDraw.Draw(canvas).polygon(polygon, outline=1, fill=1)
    return np.asarray(canvas, dtype=bool)


def instances(labels: np.ndarray, minimum_area: int = 8) -> list[dict[str, object]]:
    output: list[dict[str, object]] = []
    for class_id in (1, 2):
        components, count = ndi.label(labels == class_id, structure=STRUCTURE)
        for component_id in range(1, count + 1):
            mask = components == component_id
            area = int(mask.sum())
            if area < minimum_area:
                continue
            hull = convex_hull_mask(mask)
            # A different lesion inside this hull is anatomy, not background bay.
            defect = hull & ~(labels != 0)
            output.append({
                "class_id": class_id,
                "mask": mask,
                "hull": hull,
                "defect": defect,
                "area": area,
                "defect_pixels": int(defect.sum()),
                "defect_fraction": float(defect.sum() / max(1, hull.sum())),
                "centroid": np.asarray(ndi.center_of_mass(mask), dtype=np.float64),
            })
    return output


def match_instances(
    truth_labels: np.ndarray,
    prediction_labels: np.ndarray,
) -> list[tuple[dict[str, object], dict[str, object] | None]]:
    truth_instances = instances(truth_labels)
    prediction_instances = instances(prediction_labels)
    matches: list[tuple[dict[str, object], dict[str, object] | None]] = []
    for class_id in (1, 2):
        left = [row for row in truth_instances if row["class_id"] == class_id]
        right = [row for row in prediction_instances if row["class_id"] == class_id]
        if not left:
            continue
        if not right:
            matches.extend((row, None) for row in left)
            continue
        score = np.zeros((len(left), len(right)), dtype=np.float64)
        for i, truth in enumerate(left):
            for j, prediction in enumerate(right):
                intersection = np.logical_and(truth["mask"], prediction["mask"]).sum()
                union = np.logical_or(truth["mask"], prediction["mask"]).sum()
                overlap = intersection / max(1, union)
                distance = np.linalg.norm(truth["centroid"] - prediction["centroid"])
                score[i, j] = overlap + 1e-4 / (1.0 + distance)
        left_indices, right_indices = linear_sum_assignment(-score)
        assigned = {int(i): int(j) for i, j in zip(left_indices, right_indices)}
        matches.extend((row, right[assigned[i]] if i in assigned else None) for i, row in enumerate(left))
    return matches


def safe_f1(intersection: int, left_size: int, right_size: int) -> float:
    precision = intersection / max(1, right_size)
    recall = intersection / max(1, left_size)
    return float(2.0 * precision * recall / max(1e-12, precision + recall))


def defect_depth_and_direction(instance: dict[str, object]) -> tuple[float, np.ndarray]:
    defect = np.asarray(instance["defect"], dtype=bool)
    if not defect.any():
        return 0.0, np.zeros(2, dtype=np.float64)
    distance = ndi.distance_transform_edt(~np.asarray(instance["mask"], dtype=bool))
    depth = float(distance[defect].max())
    deep = defect & (distance >= max(1.0, 0.85 * depth))
    deepest_centroid = np.asarray(ndi.center_of_mass(deep), dtype=np.float64)
    direction = deepest_centroid - np.asarray(instance["centroid"], dtype=np.float64)
    norm = np.linalg.norm(direction)
    if norm > 1e-12:
        direction /= norm
    return depth, direction


def topology(labels: np.ndarray) -> dict[str, int]:
    foreground = labels != 0
    _, foreground_components = ndi.label(foreground, structure=STRUCTURE)
    filled = ndi.binary_fill_holes(foreground)
    _, holes = ndi.label(filled & ~foreground, structure=STRUCTURE)
    output = {
        "foreground_components": int(foreground_components),
        "holes": int(holes),
        "euler_characteristic": int(foreground_components - holes),
    }
    for class_id in (1, 2):
        _, count = ndi.label(labels == class_id, structure=STRUCTURE)
        output[f"class_{class_id}_components"] = int(count)
    return output


def boundary_f1(truth: np.ndarray, prediction: np.ndarray, tolerance: int = 2) -> float:
    truth_fg = truth != 0
    prediction_fg = prediction != 0
    truth_edge = ndi.binary_dilation(truth_fg, structure=STRUCTURE) ^ ndi.binary_erosion(
        truth_fg, structure=STRUCTURE
    )
    prediction_edge = ndi.binary_dilation(
        prediction_fg, structure=STRUCTURE
    ) ^ ndi.binary_erosion(prediction_fg, structure=STRUCTURE)
    truth_near = ndi.binary_dilation(truth_edge, iterations=tolerance)
    prediction_near = ndi.binary_dilation(prediction_edge, iterations=tolerance)
    precision = np.logical_and(prediction_edge, truth_near).sum() / max(1, prediction_edge.sum())
    recall = np.logical_and(truth_edge, prediction_near).sum() / max(1, truth_edge.sum())
    return float(2.0 * precision * recall / max(1e-12, precision + recall))


def case_metrics(truth: np.ndarray, prediction: np.ndarray) -> dict[str, float | int]:
    matched = match_instances(truth, prediction)
    materially_concave = [
        pair for pair in matched
        if pair[0]["defect_pixels"] >= 50 and pair[0]["defect_fraction"] >= 0.03
    ]
    defect_rows: list[dict[str, float]] = []
    for truth_instance, prediction_instance in materially_concave:
        truth_defect = np.asarray(truth_instance["defect"], dtype=bool)
        if prediction_instance is None:
            prediction_defect = np.zeros_like(truth_defect)
            prediction_depth = 0.0
            prediction_direction = np.zeros(2, dtype=np.float64)
        else:
            prediction_defect = np.asarray(prediction_instance["defect"], dtype=bool)
            prediction_depth, prediction_direction = defect_depth_and_direction(prediction_instance)
        truth_depth, truth_direction = defect_depth_and_direction(truth_instance)
        intersection = int(np.logical_and(truth_defect, prediction_defect).sum())
        union = int(np.logical_or(truth_defect, prediction_defect).sum())
        direction_cosine = float(np.clip(np.dot(truth_direction, prediction_direction), -1.0, 1.0))
        direction_score = 0.5 * (direction_cosine + 1.0) if prediction_defect.any() else 0.0
        depth_score = (
            min(truth_depth, prediction_depth) / max(truth_depth, prediction_depth, 1e-12)
            if prediction_defect.any() else 0.0
        )
        defect_rows.append({
            "pixels": float(truth_defect.sum()),
            "iou": float(intersection / max(1, union)),
            "f1": safe_f1(intersection, int(truth_defect.sum()), int(prediction_defect.sum())),
            "recall": float(intersection / max(1, truth_defect.sum())),
            "precision": float(intersection / max(1, prediction_defect.sum())),
            "depth_score": float(depth_score),
            "direction_score": float(direction_score),
            "truth_depth": float(truth_depth),
            "prediction_depth": float(prediction_depth),
        })
    weights = np.asarray([row["pixels"] for row in defect_rows], dtype=np.float64)
    if weights.size:
        weights /= weights.sum()
    result: dict[str, float | int] = {
        "materially_concave_instances": len(defect_rows),
        "boundary_f1": boundary_f1(truth, prediction),
    }
    for key in (
        "iou", "f1", "recall", "precision", "depth_score", "direction_score",
        "truth_depth", "prediction_depth",
    ):
        result[f"bay_{key}"] = (
            float(np.sum(weights * np.asarray([row[key] for row in defect_rows])))
            if defect_rows else float("nan")
        )
    result.update(topology(prediction))
    return result


def edit_metrics(
    truth: np.ndarray,
    baseline: np.ndarray,
    prediction: np.ndarray,
) -> dict[str, float | int]:
    baseline_fg = baseline != 0
    prediction_fg = prediction != 0
    added = ~baseline_fg & prediction_fg
    removed = baseline_fg & ~prediction_fg
    truth_defects = np.zeros_like(added)
    for row in instances(truth):
        if row["defect_pixels"] >= 50 and row["defect_fraction"] >= 0.03:
            truth_defects |= np.asarray(row["defect"], dtype=bool)
    added_class_correct = added & (prediction == truth) & (truth != 0)
    removed_background_correct = removed & (truth == 0)
    removed_true_bay = removed & truth_defects
    return {
        "added_pixels": int(added.sum()),
        "removed_pixels": int(removed.sum()),
        "added_class_precision": float(added_class_correct.sum() / max(1, added.sum())),
        "removed_background_precision": float(removed_background_correct.sum() / max(1, removed.sum())),
        "removed_true_bay_precision": float(removed_true_bay.sum() / max(1, removed.sum())),
        "removed_true_bay_pixels": int(removed_true_bay.sum()),
    }


def paired_bootstrap(
    differences: np.ndarray,
    repetitions: int,
    seed: int,
) -> dict[str, float]:
    finite = np.asarray(differences, dtype=np.float64)
    finite = finite[np.isfinite(finite)]
    if not len(finite):
        return {"mean_difference": float("nan"), "ci95_low": float("nan"), "ci95_high": float("nan")}
    rng = np.random.default_rng(seed)
    sampled = finite[rng.integers(0, len(finite), size=(repetitions, len(finite)))].mean(axis=1)
    return {
        "mean_difference": float(finite.mean()),
        "ci95_low": float(np.quantile(sampled, 0.025)),
        "ci95_high": float(np.quantile(sampled, 0.975)),
        "probability_positive": float(np.mean(sampled > 0.0)),
    }


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def defect_union(labels: np.ndarray) -> np.ndarray:
    result = np.zeros_like(labels, dtype=bool)
    for row in instances(labels):
        if row["defect_pixels"] >= 50 and row["defect_fraction"] >= 0.03:
            result |= np.asarray(row["defect"], dtype=bool)
    return result


def crop_box(*masks: np.ndarray, padding: int = 14) -> tuple[slice, slice]:
    union = np.logical_or.reduce([np.asarray(mask, dtype=bool) for mask in masks])
    rows, columns = np.nonzero(union)
    if not len(rows):
        return slice(0, union.shape[0]), slice(0, union.shape[1])
    r0, r1 = max(0, int(rows.min()) - padding), min(union.shape[0], int(rows.max()) + padding + 1)
    c0, c1 = max(0, int(columns.min()) - padding), min(union.shape[1], int(columns.max()) + padding + 1)
    return slice(r0, r1), slice(c0, c1)


def save_modified_figure(
    path: Path,
    ids: np.ndarray,
    truths: np.ndarray,
    baselines: np.ndarray,
    predictions: np.ndarray,
    selected: np.ndarray,
) -> None:
    figure, axes = plt.subplots(len(selected), 6, figsize=(15.0, 2.55 * len(selected)), squeeze=False)
    for row_index, case_index in enumerate(selected):
        truth, baseline, prediction = truths[case_index], baselines[case_index], predictions[case_index]
        truth_defect = defect_union(truth)
        prediction_defect = defect_union(prediction)
        added = (baseline == 0) & (prediction != 0)
        removed = (baseline != 0) & (prediction == 0)
        crop = crop_box(truth != 0, baseline != 0, prediction != 0)
        panels = (truth, baseline, prediction)
        titles = ("Truth", "Baseline", "Final")
        for column, (panel, title) in enumerate(zip(panels, titles)):
            axes[row_index, column].imshow(panel[crop], cmap="viridis", vmin=0, vmax=2, interpolation="nearest")
            axes[row_index, column].set_title(title if row_index else title, fontsize=10)
        edit = np.zeros((*truth.shape, 3), dtype=np.float32)
        edit[..., :] = 0.05
        edit[added] = (0.10, 0.85, 0.25)
        edit[removed] = (0.95, 0.20, 0.65)
        axes[row_index, 3].imshow(edit[crop], interpolation="nearest")
        axes[row_index, 3].set_title("Edits: +green / -magenta", fontsize=9)
        for column, (base, defect, title) in enumerate((
            (truth, truth_defect, "Truth bay"),
            (prediction, prediction_defect, "Recovered bay"),
        ), start=4):
            canvas = np.zeros((*truth.shape, 3), dtype=np.float32)
            canvas[base != 0] = (0.38, 0.38, 0.38)
            canvas[defect] = (0.05, 0.85, 0.95)
            axes[row_index, column].imshow(canvas[crop], interpolation="nearest")
            axes[row_index, column].set_title(title, fontsize=10)
        axes[row_index, 0].set_ylabel(str(ids[case_index]), fontsize=10)
        for axis in axes[row_index]:
            axis.set_axis_off()
    figure.suptitle(
        "KTC2023 modified cases: class-aware exterior-bay audit",
        fontsize=15, y=0.995,
    )
    figure.subplots_adjust(left=0.04, right=0.995, bottom=0.02, top=0.94, wspace=0.08, hspace=0.22)
    figure.savefig(path, dpi=190, bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    archive = np.load(args.predictions.resolve(), allow_pickle=False)
    ids = np.asarray(archive["ids"])
    truths = np.asarray(archive["truths"], dtype=np.uint8)
    baselines = np.asarray(archive["baseline"], dtype=np.uint8)
    predictions = np.asarray(archive["prediction"], dtype=np.uint8)
    choices = np.asarray(archive["choices"], dtype=np.int64)
    rows: list[dict[str, object]] = []
    for index, case_id in enumerate(ids):
        before = case_metrics(truths[index], baselines[index])
        after = case_metrics(truths[index], predictions[index])
        truth_topology = topology(truths[index])
        row: dict[str, object] = {
            "id": str(case_id),
            "modified": bool(choices[index] != 0),
            "choice": int(choices[index]),
            **edit_metrics(truths[index], baselines[index], predictions[index]),
        }
        for key, value in before.items():
            row[f"baseline_{key}"] = value
        for key, value in after.items():
            row[f"final_{key}"] = value
            if isinstance(value, (float, np.floating)) and key not in ("bay_truth_depth",):
                row[f"delta_{key}"] = float(value - float(before[key]))
        for key, value in truth_topology.items():
            row[f"truth_{key}"] = value
            row[f"baseline_{key}_error"] = abs(int(before[key]) - value)
            row[f"final_{key}_error"] = abs(int(after[key]) - value)
        rows.append(row)
    write_csv(output_dir / "instance_bay_metrics.csv", rows)
    modified = np.flatnonzero(choices != 0)
    save_modified_figure(
        output_dir / "modified_cases_exterior_bay_audit.png",
        ids, truths, baselines, predictions, modified,
    )
    metric_names = (
        "boundary_f1", "bay_iou", "bay_f1", "bay_recall", "bay_precision",
        "bay_depth_score", "bay_direction_score",
    )
    summary: dict[str, object] = {
        "status": "evaluation-only audit; public truth was not used for inference",
        "predictions": str(args.predictions.resolve()),
        "case_count": len(rows),
        "modified_case_count": int(len(modified)),
        "metric_definition": {
            "matching": "Hungarian same-class lesion-instance matching",
            "bay": "component convex-hull defect after excluding every foreground lesion",
            "material_bay": "at least 50 pixels and 3% of the component hull",
            "bay_f1": "precision-recall F1 between matched truth and prediction defect regions",
            "depth_score": "min/max ratio of deepest defect distance to lesion",
            "direction_score": "rescaled cosine between centroid-to-deepest-defect directions",
        },
        "metrics": {},
    }
    for name in metric_names:
        before = np.asarray([float(row[f"baseline_{name}"]) for row in rows])
        after = np.asarray([float(row[f"final_{name}"]) for row in rows])
        summary["metrics"][name] = {
            "all": paired_bootstrap(after - before, args.bootstrap_repetitions, args.seed),
            "modified": paired_bootstrap(
                (after - before)[modified], args.bootstrap_repetitions, args.seed + 1
            ),
        }
    summary["modified_cases"] = [rows[index] for index in modified]
    (output_dir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=True), encoding="utf-8"
    )
    print(json.dumps({"metrics": summary["metrics"], "modified": [str(ids[i]) for i in modified]}, indent=2))


if __name__ == "__main__":
    main()
