"""Train a bank-preserving competitive Boolean network for inward-bay EIT.

This experiment is intentionally independent of the DeepEIT reproduction.
It represents an inclusion as an outer support minus a directly predicted
inward-background field.  A competing lesion-bank field suppresses cutout
probability on the two sides of an indentation, while a sample-level gate
keeps the correction dormant when the measurements do not support a material
concavity.

The public KTC2023 truths are used only after training, checkpoint selection,
and threshold calibration have been frozen on synthetic validation data.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import random
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy.ndimage import distance_transform_edt
from torch.utils.data import ConcatDataset, DataLoader

from prepare_ktc_deep_concavity_stress import FAMILIES
from train_ktc_concavity_network import (
    DecoderStage,
    InputAdapter,
    PhysicsOperator,
    ResidualBlock,
    aggregate_rows,
    confusion_metrics,
    indentation_mask,
    save_real_montage,
    soft_dice_loss,
    write_rows,
)
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_highres_refiner import FrozenCoarseEnsemble, load_coarse_ensemble
from train_ktc_implicit_boolean_network import (
    ImplicitFieldHead,
    StructuralArrays,
    StructuralDataset,
    VoltageEncoder,
    balanced_bce,
    coarse_probability,
    cutout_topology_loss,
    gradients,
    masked_mean,
    prepare_structural_arrays,
    standard_metrics,
    stress_metrics,
)


CORE_FAMILY_CODES = (0, 1, 2, 3, 4, 6)
PUBLIC_INWARD_BAY_IDS = (
    "level_2/1",
    "level_2/3",
    "level_3/2",
    "level_5/2",
    "level_6/2",
    "level_6/3",
    "level_7/1",
    "level_7/2",
    "level_7/3",
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument(
        "--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz"
    )
    parser.add_argument(
        "--coarse-checkpoint",
        nargs="+",
        type=Path,
        default=[
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "boundary_best.pt",
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "indent_best.pt",
            root / "outputs" / "ktc_concavity_voltage_seed20260819" / "voltage_best.pt",
        ],
    )
    parser.add_argument("--coarse-weights", nargs="+", type=float, default=[0.30, 0.40, 0.30])
    parser.add_argument(
        "--initial-checkpoint",
        type=Path,
        default=root / "outputs" / "ktc_implicit_boolean_seed20260829" / "implicit_boolean_best.pt",
    )
    parser.add_argument(
        "--output-dir", type=Path, default=root / "outputs" / "ktc_competitive_boolean_v2"
    )
    parser.add_argument("--epochs", type=int, default=44)
    parser.add_argument("--patience", type=int, default=10)
    parser.add_argument("--batch-size", type=int, default=24)
    parser.add_argument("--base-channels", type=int, default=24)
    parser.add_argument("--learning-rate", type=float, default=3e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--seed", type=int, default=20260820)
    parser.add_argument("--stress-repeat", type=int, default=3)
    parser.add_argument("--base-iou-tolerance", type=float, default=0.008)
    parser.add_argument("--base-boundary-tolerance", type=float, default=0.015)
    parser.add_argument("--minimum-core-bank", type=float, default=0.74)
    parser.add_argument("--support-weight", type=float, default=0.30)
    parser.add_argument("--cutout-weight", type=float, default=0.42)
    parser.add_argument("--competition-weight", type=float, default=0.52)
    parser.add_argument("--bank-weight", type=float, default=0.48)
    parser.add_argument("--deep-cutout-weight", type=float, default=0.46)
    parser.add_argument("--boundary-weight", type=float, default=0.24)
    parser.add_argument("--topology-weight", type=float, default=0.10)
    parser.add_argument("--gate-weight", type=float, default=0.12)
    parser.add_argument("--anchor-weight", type=float, default=0.10)
    parser.add_argument("--conductivity-weight", type=float, default=0.10)
    parser.add_argument("--physics-weight", type=float, default=1e-4)
    parser.add_argument("--progress-every", type=int, default=1)
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


class CompetitiveBooleanNet(nn.Module):
    """Residual support plus mutually competing bank/cutout implicit fields."""

    def __init__(self, base: int) -> None:
        super().__init__()
        self.base = base
        self.stem = ResidualBlock(6, base)
        self.enc1 = ResidualBlock(base, base * 2)
        self.enc2 = ResidualBlock(base * 2, base * 4)
        self.enc3 = ResidualBlock(base * 4, base * 8)
        self.bottleneck = nn.Sequential(
            ResidualBlock(base * 8, base * 16),
            nn.Dropout2d(0.10),
            ResidualBlock(base * 16, base * 16),
        )
        self.voltage = VoltageEncoder(base)
        self.voltage_gate = nn.Parameter(torch.tensor(-1.5))
        self.dec3 = DecoderStage(base * 16, base * 8, base * 8)
        self.dec2 = DecoderStage(base * 8, base * 4, base * 4)
        self.dec1 = DecoderStage(base * 4, base * 2, base * 2)
        self.dec0 = DecoderStage(base * 2, base, base)
        self.support_field = ImplicitFieldHead(base)
        self.cutout_field = ImplicitFieldHead(base)
        self.bank_field = ImplicitFieldHead(base)
        self.polarity = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 2, 1))
        self.concavity_gate = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(base * 16, base * 2),
            nn.SiLU(),
            nn.Linear(base * 2, 1),
        )
        self.amplitudes = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(base * 16, 2))
        self.contrast_residual = nn.Conv2d(base, 1, 1)
        nn.init.zeros_(self.polarity[-1].weight)
        nn.init.zeros_(self.polarity[-1].bias)
        nn.init.zeros_(self.contrast_residual.weight)
        nn.init.zeros_(self.contrast_residual.bias)
        nn.init.zeros_(self.concavity_gate[-1].weight)
        nn.init.constant_(self.concavity_gate[-1].bias, -0.7)

    def forward(
        self,
        adapted_image: torch.Tensor,
        voltage: torch.Tensor,
        coarse_probability: torch.Tensor,
    ) -> dict[str, torch.Tensor]:
        e0 = self.stem(torch.cat((adapted_image, coarse_probability), dim=1))
        e1 = self.enc1(F.max_pool2d(e0, 2))
        e2 = self.enc2(F.max_pool2d(e1, 2))
        e3 = self.enc3(F.max_pool2d(e2, 2))
        bottleneck = self.bottleneck(F.max_pool2d(e3, 2))
        bottleneck = bottleneck + torch.sigmoid(self.voltage_gate) * self.voltage(voltage)
        d3 = self.dec3(bottleneck, e3)
        d2 = self.dec2(d3, e2)
        d1 = self.dec1(d2, e1)
        fine = self.dec0(d1, e0)

        coarse_foreground = coarse_probability[:, 1:].sum(dim=1, keepdim=True).clamp(0.015, 0.985)
        coarse_logit = torch.logit(coarse_foreground)
        support_residual = self.support_field(bottleneck, d2, fine)
        # Keeping the full coarse logit is important: the earlier Boolean
        # decoder divided it by three and unnecessarily rebuilt ordinary
        # lesions from scratch.
        support_logit = coarse_logit + 0.42 * support_residual
        support_probability = torch.sigmoid(support_logit)

        cutout_logit = (-1.15 + self.cutout_field(bottleneck, d2, fine)) / 0.40
        bank_logit = (-0.25 + self.bank_field(bottleneck, d2, fine)) / 0.40
        cutout_proposal = torch.sigmoid(cutout_logit)
        competition = torch.softmax(torch.cat((bank_logit, cutout_logit), dim=1), dim=1)
        bank_probability = competition[:, 0:1]
        competitive_cutout = cutout_proposal * competition[:, 1:2]
        gate_logit = self.concavity_gate(bottleneck)
        gate_probability = torch.sigmoid(gate_logit)[:, :, None, None]
        effective_cutout = (gate_probability * competitive_cutout).clamp(0.0, 1.0)
        foreground_probability = (support_probability * (1.0 - effective_cutout)).clamp(1e-6, 1.0 - 1e-6)

        coarse_polarity = coarse_probability[:, 1:].clamp_min(1e-6)
        coarse_polarity = coarse_polarity / coarse_polarity.sum(dim=1, keepdim=True)
        polarity = torch.softmax(torch.log(coarse_polarity) + self.polarity(fine), dim=1)
        probabilities = torch.cat(
            (
                1.0 - foreground_probability,
                foreground_probability * polarity[:, 0:1],
                foreground_probability * polarity[:, 1:2],
            ),
            dim=1,
        ).clamp_min(1e-7)
        amplitude_raw = self.amplitudes(bottleneck)
        negative = 0.08 + 0.88 * torch.sigmoid(amplitude_raw[:, 0:1, None, None])
        positive = 0.08 + 1.10 * torch.sigmoid(amplitude_raw[:, 1:2, None, None])
        delta = foreground_probability * (-negative * polarity[:, 0:1] + positive * polarity[:, 1:2])
        delta = delta + foreground_probability * 0.15 * torch.tanh(self.contrast_residual(fine))
        return {
            "logits": torch.log(probabilities),
            "probabilities": probabilities,
            "coarse_foreground": coarse_foreground,
            "support_logit": support_logit,
            "support_probability": support_probability,
            "support_residual": support_residual,
            "cutout_logit": cutout_logit,
            "bank_logit": bank_logit,
            "cutout_proposal": cutout_proposal,
            "bank_probability": bank_probability,
            "competitive_cutout": competitive_cutout,
            "gate_logit": gate_logit,
            "gate_probability": gate_probability,
            "effective_cutout": effective_cutout,
            "foreground_probability": foreground_probability,
            "polarity_probability": polarity,
            "delta": delta,
        }


def core_mask(family_codes: np.ndarray) -> np.ndarray:
    return np.isin(family_codes, np.asarray(CORE_FAMILY_CODES, dtype=np.int16))


def compute_loss(
    outputs: dict[str, torch.Tensor],
    batch: dict[str, torch.Tensor],
    physics: PhysicsOperator,
    args: argparse.Namespace,
    ramp: float,
) -> tuple[torch.Tensor, dict[str, float]]:
    labels = batch["labels"]
    class_weights = outputs["logits"].new_tensor((0.35, 1.25, 1.25))
    segmentation = F.nll_loss(outputs["logits"], labels, weight=class_weights)
    segmentation = segmentation + soft_dice_loss(outputs["logits"], labels)
    support = batch["support"]
    cutout = batch["cutout"]
    target_foreground = (labels != 0).float().unsqueeze(1)
    depth_weight = 1.0 + 3.0 * batch["cutout_depth"]
    bank = target_foreground * F.max_pool2d(cutout, 7, stride=1, padding=3)
    local_domain = support * F.max_pool2d(cutout, 11, stride=1, padding=5)

    support_loss = balanced_bce(outputs["support_logit"], support, torch.ones_like(support))
    cutout_loss = balanced_bce(outputs["cutout_logit"], cutout, support, depth_weight)
    competition_logit = outputs["cutout_logit"] - outputs["bank_logit"]
    competition_loss = balanced_bce(competition_logit, cutout, local_domain, depth_weight)
    bank_loss = balanced_bce(outputs["bank_logit"], bank, local_domain)
    false_fill = masked_mean(outputs["foreground_probability"], cutout * depth_weight)
    false_cut = masked_mean(1.0 - outputs["foreground_probability"], bank)

    pred_dy, pred_dx = gradients(outputs["foreground_probability"])
    true_dy, true_dx = gradients(target_foreground)
    boundary = F.l1_loss(pred_dy, true_dy) + F.l1_loss(pred_dx, true_dx)
    topology = cutout_topology_loss(outputs["effective_cutout"], cutout, support, 8)

    support_pixels = support.sum(dim=(1, 2, 3)).clamp_min(1.0)
    cutout_fraction = cutout.sum(dim=(1, 2, 3)) / support_pixels
    continuous_gate_target = torch.clamp(cutout_fraction / 0.035, 0.0, 1.0)
    stress_source = batch["source"].to(continuous_gate_target.dtype)
    gate_target = torch.where(stress_source > 0.5, torch.ones_like(continuous_gate_target), continuous_gate_target)
    gate_loss = F.binary_cross_entropy_with_logits(outputs["gate_logit"].flatten(), gate_target)

    coarse_correct = ((outputs["coarse_foreground"] >= 0.5) == (support >= 0.5)).float()
    anchor = masked_mean(
        torch.abs(outputs["support_probability"] - outputs["coarse_foreground"]), coarse_correct
    )
    conductivity = F.smooth_l1_loss(outputs["delta"], batch["delta"], beta=0.08)
    physical = physics.loss(outputs["delta"], batch["clean_voltage"])
    total = segmentation + ramp * (
        args.support_weight * support_loss
        + args.cutout_weight * cutout_loss
        + args.competition_weight * competition_loss
        + args.bank_weight * bank_loss
        + args.deep_cutout_weight * false_fill
        + args.bank_weight * false_cut
        + args.boundary_weight * boundary
        + args.topology_weight * topology
        + args.gate_weight * gate_loss
        + args.anchor_weight * anchor
        + args.conductivity_weight * conductivity
        + args.physics_weight * physical
    )
    pieces = {
        "total": total,
        "segmentation": segmentation,
        "support": support_loss,
        "cutout": cutout_loss,
        "competition": competition_loss,
        "bank": bank_loss,
        "false_fill": false_fill,
        "false_cut": false_cut,
        "boundary": boundary,
        "topology": topology,
        "gate": gate_loss,
        "anchor": anchor,
        "conductivity": conductivity,
        "physics": physical,
    }
    return total, {key: float(value.detach()) for key, value in pieces.items()}


@torch.no_grad()
def collect_fields(
    coarse: FrozenCoarseEnsemble,
    model: CompetitiveBooleanNet,
    adapter: InputAdapter,
    loader: DataLoader,
    device: torch.device,
) -> dict[str, np.ndarray]:
    result: dict[str, list[np.ndarray]] = {
        "coarse": [], "support": [], "cutout_proposal": [], "bank": [],
        "cutout": [], "polarity": [], "gate": [],
    }
    model.eval()
    for batch in loader:
        image = adapter(batch["image"].to(device))
        voltage = batch["voltage"].to(device)
        base = coarse_probability(coarse, image, voltage)
        output = model(image, voltage, base)
        result["coarse"].append(base.cpu().numpy())
        result["support"].append(output["support_probability"].cpu().numpy())
        result["cutout_proposal"].append(output["cutout_proposal"].cpu().numpy())
        result["bank"].append(output["bank_probability"].cpu().numpy())
        result["cutout"].append(output["effective_cutout"].cpu().numpy())
        result["polarity"].append(output["polarity_probability"].cpu().numpy())
        result["gate"].append(output["gate_probability"].flatten().cpu().numpy())
    return {key: np.concatenate(value) for key, value in result.items()}


def decode_fields(fields: dict[str, np.ndarray], support_threshold: float, cutout_threshold: float) -> np.ndarray:
    support = fields["support"][:, 0] >= support_threshold
    cutout = fields["cutout"][:, 0] >= cutout_threshold
    foreground = support & ~cutout
    polarity = fields["polarity"].argmax(axis=1).astype(np.uint8) + 1
    return (foreground * polarity).astype(np.uint8)


def core_stress_metrics(
    arrays: StructuralArrays, indices: np.ndarray, predictions: np.ndarray
) -> tuple[dict[str, float], list[dict[str, float]]]:
    selected = core_mask(arrays.family_codes[indices])
    summary, _, rows = stress_metrics(
        arrays.labels[indices][selected],
        predictions[selected],
        arrays.cutout[indices][selected],
        arrays.cutout_depth[indices][selected],
        arrays.family_codes[indices][selected],
    )
    return summary, rows


def validation_score(base: dict[str, float], core: dict[str, float]) -> float:
    return float(
        0.14 * base["foreground_iou"]
        + 0.08 * base["boundary_f1"]
        + 0.16 * core["foreground_iou"]
        + 0.10 * core["boundary_f1"]
        + 0.24 * core["topology_structural_joint"]
        + 0.16 * core["open_deep_cutout_recovery"]
        + 0.12 * core["bank_retention"]
    )


def train_model(
    base_archive: np.lib.npyio.NpzFile,
    stress_archive: np.lib.npyio.NpzFile,
    base_arrays: StructuralArrays,
    stress_arrays: StructuralArrays,
    coarse: FrozenCoarseEnsemble,
    adapter: InputAdapter,
    args: argparse.Namespace,
    output_dir: Path,
    device: torch.device,
) -> tuple[CompetitiveBooleanNet, list[dict[str, float]]]:
    base_training = StructuralDataset(base_arrays, base_archive["train_indices"], 0)
    stress_train_indices = np.asarray(stress_archive["train_indices"], dtype=np.int64)
    stress_train_indices = stress_train_indices[core_mask(stress_arrays.family_codes[stress_train_indices])]
    stress_training = StructuralDataset(stress_arrays, stress_train_indices, 1)
    training = ConcatDataset((base_training, *([stress_training] * max(1, args.stress_repeat))))
    train_loader = DataLoader(
        training, batch_size=args.batch_size, shuffle=True, num_workers=args.workers,
        pin_memory=device.type == "cuda", drop_last=True,
    )
    base_validation_indices = np.asarray(base_archive["validation_indices"], dtype=np.int64)
    stress_validation_indices = np.asarray(stress_archive["validation_indices"], dtype=np.int64)
    base_validation_loader = DataLoader(
        StructuralDataset(base_arrays, base_validation_indices, 0), batch_size=args.batch_size, shuffle=False
    )
    stress_validation_loader = DataLoader(
        StructuralDataset(stress_arrays, stress_validation_indices, 1), batch_size=args.batch_size, shuffle=False
    )
    model = CompetitiveBooleanNet(args.base_channels).to(device)
    if args.initial_checkpoint is not None and args.initial_checkpoint.exists():
        initial = torch.load(args.initial_checkpoint.resolve(), map_location=device, weights_only=False)
        missing, unexpected = model.load_state_dict(initial["model"], strict=False)
        print(
            f"initialized shared Boolean backbone from {args.initial_checkpoint.resolve()}; "
            f"missing={len(missing)}, unexpected={len(unexpected)}",
            flush=True,
        )
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    physics = PhysicsOperator(
        jacobian=torch.from_numpy(np.asarray(base_archive["jacobian"], dtype=np.float32)).to(device),
        node_to_raw_pixel=torch.from_numpy(np.asarray(base_archive["node_to_raw_pixel"], dtype=np.int64)).to(device),
        voltage_scale=2.0,
    )
    with torch.no_grad():
        base_coarse_fields = collect_fields(coarse, model, adapter, base_validation_loader, device)
        stress_coarse_fields = collect_fields(coarse, model, adapter, stress_validation_loader, device)
    base_coarse_prediction = base_coarse_fields["coarse"].argmax(axis=1).astype(np.uint8)
    stress_coarse_prediction = stress_coarse_fields["coarse"].argmax(axis=1).astype(np.uint8)
    base_coarse_metric = standard_metrics(
        base_arrays.labels[base_validation_indices], base_coarse_prediction,
        base_arrays.indentation[base_validation_indices],
    )
    core_coarse_metric, _ = core_stress_metrics(stress_arrays, stress_validation_indices, stress_coarse_prediction)

    best_score = -math.inf
    stale = 0
    history: list[dict[str, float]] = []
    checkpoint = output_dir / "competitive_boolean_best.pt"
    for epoch in range(1, args.epochs + 1):
        model.train()
        pieces: dict[str, list[float]] = {}
        ramp = min(1.0, epoch / max(5.0, args.epochs * 0.15))
        for batch in train_loader:
            image = adapter(batch["image"].to(device, non_blocking=True))
            voltage = batch["voltage"].to(device, non_blocking=True)
            with torch.no_grad():
                base_probability = coarse_probability(coarse, image, voltage)
            moved = {
                key: value.to(device, non_blocking=True) if isinstance(value, torch.Tensor) else value
                for key, value in batch.items()
            }
            optimizer.zero_grad(set_to_none=True)
            with torch.amp.autocast("cuda", enabled=device.type == "cuda"):
                outputs = model(image, voltage, base_probability)
                loss, batch_pieces = compute_loss(outputs, moved, physics, args, ramp)
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            scaler.step(optimizer)
            scaler.update()
            for key, value in batch_pieces.items():
                pieces.setdefault(key, []).append(value)
        scheduler.step()

        base_fields = collect_fields(coarse, model, adapter, base_validation_loader, device)
        stress_fields = collect_fields(coarse, model, adapter, stress_validation_loader, device)
        base_prediction = decode_fields(base_fields, 0.50, 0.50)
        stress_prediction = decode_fields(stress_fields, 0.50, 0.50)
        base_metric = standard_metrics(
            base_arrays.labels[base_validation_indices], base_prediction,
            base_arrays.indentation[base_validation_indices],
        )
        core_metric, _ = core_stress_metrics(stress_arrays, stress_validation_indices, stress_prediction)
        eligible = (
            base_metric["foreground_iou"] >= base_coarse_metric["foreground_iou"] - args.base_iou_tolerance
            and base_metric["boundary_f1"] >= base_coarse_metric["boundary_f1"] - args.base_boundary_tolerance
            and core_metric["bank_retention"] >= args.minimum_core_bank
        )
        score = validation_score(base_metric, core_metric)
        if not eligible:
            score -= 0.50 * max(
                0.0, base_coarse_metric["foreground_iou"] - args.base_iou_tolerance - base_metric["foreground_iou"]
            )
            score -= 0.35 * max(0.0, args.minimum_core_bank - core_metric["bank_retention"])
        record = {
            "epoch": float(epoch), "score": score, "eligible": float(eligible),
            "base_iou": base_metric["foreground_iou"], "base_boundary": base_metric["boundary_f1"],
            "core_iou": core_metric["foreground_iou"],
            "core_open_deep": core_metric["open_deep_cutout_recovery"],
            "core_bank": core_metric["bank_retention"],
            "core_topology_joint": core_metric["topology_structural_joint"],
            "learning_rate": float(optimizer.param_groups[0]["lr"]),
            **{f"train_{key}": float(np.mean(values)) for key, values in pieces.items()},
        }
        history.append(record)
        if args.progress_every and (epoch == 1 or epoch % args.progress_every == 0):
            print(
                f"epoch {epoch:03d}: score={score:.4f}, eligible={eligible}, "
                f"base={record['base_iou']:.4f}, core={record['core_iou']:.4f}, "
                f"open={record['core_open_deep']:.4f}, bank={record['core_bank']:.4f}, "
                f"joint={record['core_topology_joint']:.4f}",
                flush=True,
            )
        if score > best_score + 1e-5:
            best_score = score
            stale = 0
            torch.save(
                {
                    "model": model.state_dict(), "base_channels": args.base_channels, "epoch": epoch,
                    "validation_score": score, "eligible": bool(eligible),
                    "base_metric": base_metric, "core_metric": core_metric,
                },
                checkpoint,
            )
        else:
            stale += 1
            if stale >= args.patience:
                print(f"early stopping at epoch {epoch}; best={best_score:.4f}", flush=True)
                break
    state = torch.load(checkpoint, map_location=device, weights_only=False)
    model.load_state_dict(state["model"])
    model.eval()
    (output_dir / "training_history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    return model, history


def calibrate_thresholds(
    base_arrays: StructuralArrays,
    stress_arrays: StructuralArrays,
    base_indices: np.ndarray,
    stress_indices: np.ndarray,
    base_fields: dict[str, np.ndarray],
    stress_fields: dict[str, np.ndarray],
    args: argparse.Namespace,
    output_dir: Path,
) -> tuple[float, float, list[dict[str, object]]]:
    base_coarse = base_fields["coarse"].argmax(axis=1).astype(np.uint8)
    base_reference = standard_metrics(
        base_arrays.labels[base_indices], base_coarse, base_arrays.indentation[base_indices]
    )
    rows: list[dict[str, object]] = []
    for support_threshold in (0.38, 0.42, 0.46, 0.50, 0.54, 0.58):
        for cutout_threshold in (0.28, 0.34, 0.40, 0.46, 0.52, 0.58, 0.64):
            base_prediction = decode_fields(base_fields, support_threshold, cutout_threshold)
            stress_prediction = decode_fields(stress_fields, support_threshold, cutout_threshold)
            base_metric = standard_metrics(
                base_arrays.labels[base_indices], base_prediction, base_arrays.indentation[base_indices]
            )
            core_metric, _ = core_stress_metrics(stress_arrays, stress_indices, stress_prediction)
            eligible = (
                base_metric["foreground_iou"] >= base_reference["foreground_iou"] - args.base_iou_tolerance
                and base_metric["boundary_f1"] >= base_reference["boundary_f1"] - args.base_boundary_tolerance
                and core_metric["bank_retention"] >= args.minimum_core_bank
            )
            rows.append(
                {
                    "support_threshold": support_threshold, "cutout_threshold": cutout_threshold,
                    "eligible": bool(eligible), "score": validation_score(base_metric, core_metric),
                    "base_iou": base_metric["foreground_iou"], "base_boundary": base_metric["boundary_f1"],
                    "core_iou": core_metric["foreground_iou"],
                    "core_open_deep": core_metric["open_deep_cutout_recovery"],
                    "core_bank": core_metric["bank_retention"],
                    "core_topology_joint": core_metric["topology_structural_joint"],
                }
            )
    eligible_rows = [row for row in rows if row["eligible"]]
    candidates = eligible_rows if eligible_rows else rows
    selected = max(
        candidates,
        key=lambda row: (
            row["core_topology_joint"], row["core_open_deep"], row["core_iou"], row["base_iou"]
        ),
    )
    with (output_dir / "validation_threshold_grid.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(f"threshold calibration: eligible={len(eligible_rows)}/{len(rows)}; selected={selected}", flush=True)
    return float(selected["support_threshold"]), float(selected["cutout_threshold"]), rows


@torch.no_grad()
def infer_real_fields(
    coarse: FrozenCoarseEnsemble,
    model: CompetitiveBooleanNet,
    adapter: InputAdapter,
    images: np.ndarray,
    voltages: np.ndarray,
    device: torch.device,
    batch_size: int,
) -> dict[str, np.ndarray]:
    collected: dict[str, list[np.ndarray]] = {
        "coarse": [], "support": [], "cutout_proposal": [], "bank": [],
        "cutout": [], "polarity": [], "gate": [],
    }
    for start in range(0, len(images), batch_size):
        image = torch.from_numpy(images[start : start + batch_size, None].astype(np.float32)).to(device)
        voltage = torch.from_numpy(voltages[start : start + batch_size].astype(np.float32)).to(device)
        adapted = adapter(image)
        base = coarse_probability(coarse, adapted, voltage)
        output = model(adapted, voltage, base)
        for key, tensor in (
            ("coarse", base), ("support", output["support_probability"]),
            ("cutout_proposal", output["cutout_proposal"]),
            ("bank", output["bank_probability"]),
            ("cutout", output["effective_cutout"]), ("polarity", output["polarity_probability"]),
        ):
            resized = F.interpolate(tensor, size=(256, 256), mode="bilinear", align_corners=False)
            collected[key].append(resized.cpu().numpy())
        collected["gate"].append(output["gate_probability"].flatten().cpu().numpy())
    return {key: np.concatenate(value) for key, value in collected.items()}


def save_field_montage(
    path: Path,
    truths: np.ndarray,
    predictions: np.ndarray,
    fields: dict[str, np.ndarray],
    indices: list[int],
    row_labels: list[str],
) -> None:
    """Expose the implicit fields so over-cutting can be diagnosed directly."""
    figure, axes = plt.subplots(len(indices), 7, figsize=(15.8, 2.35 * len(indices)), squeeze=False)
    for row, (index, row_label) in enumerate(zip(indices, row_labels)):
        coarse_foreground = fields["coarse"][index, 1:].sum(axis=0)
        items = (
            (truths[index], "truth", "viridis", 0, 2),
            (coarse_foreground, "coarse foreground", "magma", 0, 1),
            (fields["support"][index, 0], "anchored support", "magma", 0, 1),
            (fields["cutout_proposal"][index, 0], "cutout proposal", "magma", 0, 1),
            (fields["bank"][index, 0], "bank probability", "magma", 0, 1),
            (fields["cutout"][index, 0], f"effective cutout\ngate={fields['gate'][index]:.2f}", "magma", 0, 1),
            (predictions[index], "decoded result", "viridis", 0, 2),
        )
        for column, (image, title, cmap, vmin, vmax) in enumerate(items):
            axes[row, column].imshow(image, cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest")
            axes[row, column].set_axis_off()
            if row == 0:
                axes[row, column].set_title(title, fontsize=9)
        axes[row, 0].set_ylabel(row_label, fontsize=9)
    figure.suptitle("Competitive Boolean implicit fields: support, inward cutout, and protected banks")
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def save_stress_montage(
    path: Path,
    truths: np.ndarray,
    coarse: np.ndarray,
    prediction: np.ndarray,
    cutouts: np.ndarray,
    family_codes: np.ndarray,
) -> None:
    indices = [
        next((i for i, value in enumerate(family_codes) if int(value) == code), None)
        for code in CORE_FAMILY_CODES
    ]
    indices = [index for index in indices if index is not None]
    figure, axes = plt.subplots(len(indices), 5, figsize=(12.6, 2.3 * len(indices)), squeeze=False)
    for row, index in enumerate(indices):
        change = (prediction[index] != coarse[index]).astype(np.uint8)
        images = (
            (truths[index], f"{FAMILIES[int(family_codes[index])]} truth", "viridis", 0, 2),
            (coarse[index], "coarse EIT", "viridis", 0, 2),
            (prediction[index], "competitive Boolean", "viridis", 0, 2),
            (cutouts[index], "true inward background", "gray", 0, 1),
            (change, "changed pixels", "magma", 0, 1),
        )
        for column, (image, title, cmap, vmin, vmax) in enumerate(images):
            axes[row, column].imshow(image, cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest")
            axes[row, column].set_title(title)
            axes[row, column].set_axis_off()
    figure.suptitle("Independent nonlinear-CEM inward-bay families")
    figure.tight_layout()
    figure.savefig(path, dpi=190)
    plt.close(figure)


def save_public_bay_montage(
    path: Path,
    truths: np.ndarray,
    ids: np.ndarray,
    coarse: np.ndarray,
    prediction: np.ndarray,
    rows: list[dict[str, object]],
) -> None:
    selected = [i for i, case_id in enumerate(ids) if str(case_id) in PUBLIC_INWARD_BAY_IDS]
    lookup = {(str(row["id"]), str(row["method"])): row for row in rows}
    figure, axes = plt.subplots(len(selected), 4, figsize=(10.8, 2.65 * len(selected)), squeeze=False)
    for row_index, index in enumerate(selected):
        case_id = str(ids[index])
        change = (prediction[index] != coarse[index]).astype(np.uint8)
        items = (
            (truths[index], f"{case_id} truth", "viridis", 0, 2),
            (coarse[index], f"coarse\nIoU={lookup[(case_id, 'coarse_fusion')]['foreground_iou']:.3f}", "viridis", 0, 2),
            (prediction[index], f"new\nIoU={lookup[(case_id, 'competitive_boolean')]['foreground_iou']:.3f}", "viridis", 0, 2),
            (change, "changed pixels", "magma", 0, 1),
        )
        for column, (image, title, cmap, vmin, vmax) in enumerate(items):
            axes[row_index, column].imshow(image, cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest")
            axes[row_index, column].set_title(title)
            axes[row_index, column].set_axis_off()
    figure.suptitle("Public KTC2023 cases containing inward bays/notches (stars excluded as targets)")
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def paired_bootstrap(
    coarse_rows: list[dict[str, float]],
    model_rows: list[dict[str, float]],
    seed: int,
    repeats: int = 5000,
) -> dict[str, dict[str, float]]:
    rng = np.random.default_rng(seed)
    result: dict[str, dict[str, float]] = {}
    for metric in (
        "foreground_iou", "open_deep_cutout_recovery", "bank_retention", "topology_structural_joint"
    ):
        differences = np.asarray(
            [new[metric] - old[metric] for old, new in zip(coarse_rows, model_rows)], dtype=np.float64
        )
        samples = rng.choice(differences, size=(repeats, len(differences)), replace=True).mean(axis=1)
        result[metric] = {
            "mean_difference": float(differences.mean()),
            "ci95_low": float(np.quantile(samples, 0.025)),
            "ci95_high": float(np.quantile(samples, 0.975)),
            "positive_case_fraction": float(np.mean(differences > 0)),
        }
    return result


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    base_archive = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress_archive = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    base_arrays = prepare_structural_arrays(base_archive, "base nonlinear CEM")
    stress_arrays = prepare_structural_arrays(stress_archive, "deep-concavity stress")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    coarse, _, coarse_weights = load_coarse_ensemble(args.coarse_checkpoint, args.coarse_weights, device)
    adapter = InputAdapter(base_archive["fov_mask"]).to(device)
    print(
        f"device={device}; base train={len(base_archive['train_indices'])}; "
        f"stress core train={core_mask(stress_arrays.family_codes[stress_archive['train_indices']]).sum()}",
        flush=True,
    )
    model, history = train_model(
        base_archive, stress_archive, base_arrays, stress_arrays, coarse, adapter,
        args, output_dir, device,
    )

    base_validation_indices = np.asarray(base_archive["validation_indices"], dtype=np.int64)
    stress_validation_indices = np.asarray(stress_archive["validation_indices"], dtype=np.int64)
    base_validation_loader = DataLoader(
        StructuralDataset(base_arrays, base_validation_indices, 0), batch_size=args.batch_size, shuffle=False
    )
    stress_validation_loader = DataLoader(
        StructuralDataset(stress_arrays, stress_validation_indices, 1), batch_size=args.batch_size, shuffle=False
    )
    base_validation_fields = collect_fields(coarse, model, adapter, base_validation_loader, device)
    stress_validation_fields = collect_fields(coarse, model, adapter, stress_validation_loader, device)
    support_threshold, cutout_threshold, threshold_rows = calibrate_thresholds(
        base_arrays, stress_arrays, base_validation_indices, stress_validation_indices,
        base_validation_fields, stress_validation_fields, args, output_dir,
    )

    # Test truths are accessed only after the checkpoint and thresholds above
    # have both been frozen.
    base_test_indices = np.asarray(base_archive["test_indices"], dtype=np.int64)
    stress_test_indices = np.asarray(stress_archive["test_indices"], dtype=np.int64)
    base_test_loader = DataLoader(
        StructuralDataset(base_arrays, base_test_indices, 0), batch_size=args.batch_size, shuffle=False
    )
    stress_test_loader = DataLoader(
        StructuralDataset(stress_arrays, stress_test_indices, 1), batch_size=args.batch_size, shuffle=False
    )
    base_fields = collect_fields(coarse, model, adapter, base_test_loader, device)
    stress_fields = collect_fields(coarse, model, adapter, stress_test_loader, device)
    base_coarse = base_fields["coarse"].argmax(axis=1).astype(np.uint8)
    stress_coarse = stress_fields["coarse"].argmax(axis=1).astype(np.uint8)
    base_prediction = decode_fields(base_fields, support_threshold, cutout_threshold)
    stress_prediction = decode_fields(stress_fields, support_threshold, cutout_threshold)
    base_summary = {
        "coarse_fusion": standard_metrics(
            base_arrays.labels[base_test_indices], base_coarse, base_arrays.indentation[base_test_indices]
        ),
        "competitive_boolean": standard_metrics(
            base_arrays.labels[base_test_indices], base_prediction, base_arrays.indentation[base_test_indices]
        ),
    }
    stress_coarse_summary, stress_coarse_family, stress_coarse_rows = stress_metrics(
        stress_arrays.labels[stress_test_indices], stress_coarse,
        stress_arrays.cutout[stress_test_indices], stress_arrays.cutout_depth[stress_test_indices],
        stress_arrays.family_codes[stress_test_indices],
    )
    stress_model_summary, stress_model_family, stress_model_rows = stress_metrics(
        stress_arrays.labels[stress_test_indices], stress_prediction,
        stress_arrays.cutout[stress_test_indices], stress_arrays.cutout_depth[stress_test_indices],
        stress_arrays.family_codes[stress_test_indices],
    )
    core_selected = core_mask(stress_arrays.family_codes[stress_test_indices])
    stress_core_coarse, core_coarse_rows = core_stress_metrics(stress_arrays, stress_test_indices, stress_coarse)
    stress_core_model, core_model_rows = core_stress_metrics(stress_arrays, stress_test_indices, stress_prediction)
    bootstrap = paired_bootstrap(core_coarse_rows, core_model_rows, args.seed + 77)
    save_stress_montage(
        output_dir / "stress_core_family_comparison.png",
        stress_arrays.labels[stress_test_indices][core_selected], stress_coarse[core_selected],
        stress_prediction[core_selected], stress_arrays.cutout[stress_test_indices][core_selected],
        stress_arrays.family_codes[stress_test_indices][core_selected],
    )
    core_indices: list[int] = []
    core_labels: list[str] = []
    test_family_codes = stress_arrays.family_codes[stress_test_indices]
    for code in CORE_FAMILY_CODES:
        candidates = np.flatnonzero(test_family_codes == code)
        if len(candidates):
            core_indices.append(int(candidates[0]))
            core_labels.append(FAMILIES[code])
    save_field_montage(
        output_dir / "stress_core_probability_fields.png",
        stress_arrays.labels[stress_test_indices], stress_prediction, stress_fields,
        core_indices, core_labels,
    )

    real_fields = infer_real_fields(
        coarse, model, adapter, base_archive["real_linear_images"], base_archive["real_voltages"],
        device, args.batch_size,
    )
    real_coarse = real_fields["coarse"].argmax(axis=1).astype(np.uint8)
    real_prediction = decode_fields(real_fields, support_threshold, cutout_threshold)
    real_truths = base_archive["real_labels"]
    real_ids = base_archive["real_ids"]
    real_summary: dict[str, dict[str, float]] = {}
    real_rows: list[dict[str, object]] = []
    for name, prediction in (("coarse_fusion", real_coarse), ("competitive_boolean", real_prediction)):
        real_summary[name], rows = evaluate_real_predictions(name, prediction, real_truths, real_ids)
        real_rows.extend(rows)
    bay_rows = [row for row in real_rows if str(row["id"]) in PUBLIC_INWARD_BAY_IDS]
    bay_summary = {
        method: aggregate_rows(
            [
                {key: float(value) for key, value in row.items() if key not in ("id", "method")}
                for row in bay_rows if row["method"] == method
            ]
        )
        for method in ("coarse_fusion", "competitive_boolean")
    }
    write_rows(output_dir / "real_case_metrics.csv", real_rows)
    save_real_montage(
        output_dir / "real_all_21_comparison.png", real_truths, real_ids,
        {"coarse_fusion": real_coarse, "competitive_boolean": real_prediction}, real_rows,
    )
    save_public_bay_montage(
        output_dir / "real_inward_bay_subset.png", real_truths, real_ids,
        real_coarse, real_prediction, real_rows,
    )
    real_bay_indices = [
        index for index, case_id in enumerate(real_ids) if str(case_id) in PUBLIC_INWARD_BAY_IDS
    ]
    save_field_montage(
        output_dir / "real_inward_bay_probability_fields.png",
        real_truths, real_prediction, real_fields, real_bay_indices,
        [str(real_ids[index]) for index in real_bay_indices],
    )
    np.savez_compressed(
        output_dir / "predictions.npz",
        base_test_indices=base_test_indices, base_coarse=base_coarse, base_competitive_boolean=base_prediction,
        stress_test_indices=stress_test_indices, stress_coarse=stress_coarse,
        stress_competitive_boolean=stress_prediction, stress_gate=stress_fields["gate"],
        stress_support=stress_fields["support"], stress_cutout_proposal=stress_fields["cutout_proposal"],
        stress_bank=stress_fields["bank"], stress_effective_cutout=stress_fields["cutout"],
        real_coarse=real_coarse, real_competitive_boolean=real_prediction, real_gate=real_fields["gate"],
        real_support=real_fields["support"], real_cutout_proposal=real_fields["cutout_proposal"],
        real_bank=real_fields["bank"], real_effective_cutout=real_fields["cutout"],
    )
    result = {
        "method": "bank-preserving competitive Boolean support-minus-cutout network",
        "representation": "foreground = anchored_support * (1 - gate * cutout_proposal * cutout_vs_bank_competition)",
        "device": str(device), "seed": args.seed,
        "datasets": {
            "base": str(args.base_dataset.resolve()), "stress": str(args.stress_dataset.resolve()),
            "public_ktc_cases": int(len(real_truths)),
        },
        "core_inward_families": [FAMILIES[index] for index in CORE_FAMILY_CODES],
        "excluded_from_core_target": [FAMILIES[5], FAMILIES[7]],
        "selected_thresholds": {
            "support": support_threshold, "cutout": cutout_threshold,
            "eligible_candidates": int(sum(bool(row["eligible"]) for row in threshold_rows)),
        },
        "base_synthetic_untouched_test": base_summary,
        "deep_concavity_stress_untouched_test": {
            "coarse_fusion": stress_coarse_summary, "competitive_boolean": stress_model_summary,
        },
        "core_inward_bay_stress_test": {
            "coarse_fusion": stress_core_coarse, "competitive_boolean": stress_core_model,
        },
        "stress_by_family": {
            "coarse_fusion": stress_coarse_family, "competitive_boolean": stress_model_family,
        },
        "paired_bootstrap_core": bootstrap,
        "real_evaluation_all_21": real_summary,
        "real_inward_bay_subset": {
            "ids": list(PUBLIC_INWARD_BAY_IDS), "metrics": bay_summary,
        },
        "evaluation_truth_used_for_training_or_selection": False,
        "best_epoch": int(max(history, key=lambda row: row["score"])["epoch"]),
        "coarse_weights": coarse_weights,
        "args": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
    }
    (output_dir / "summary.json").write_text(json.dumps(result, indent=2, default=str), encoding="utf-8")
    print(json.dumps(result, indent=2, default=str), flush=True)


if __name__ == "__main__":
    main()
