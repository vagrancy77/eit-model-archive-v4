"""Train a frozen-coarse topology refiner for non-convex EIT targets.

The public KTC evaluation labels are read only after checkpoint selection and
synthetic test evaluation. The coarse reconstruction network is frozen; this
script learns a sparse, uncertainty-gated residual that repairs local boundary
and indentation errors without moving already confident regions.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader

from train_ktc_concavity_network import (
    DecoderStage,
    InputAdapter,
    ResidualBlock,
    aggregate_rows,
    confusion_metrics,
    indentation_mask,
    save_focus_montage,
    save_real_montage,
    save_training_curves,
    soft_dice_loss,
    write_rows,
)
from train_ktc_concavity_network_v2 import (
    CalibrationDatasetV2,
    ConcavityNetV2,
    EITDatasetV2,
    ModelSpec,
    evaluate_real_predictions,
    gradients,
    normalized_masked_mean,
    selection_score,
    set_seed,
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--coarse-checkpoint", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, default=root / "outputs" / "ktc_topology_refiner")
    parser.add_argument("--epochs", type=int, default=55)
    parser.add_argument("--patience", type=int, default=12)
    parser.add_argument("--batch-size", type=int, default=24)
    parser.add_argument("--base-channels", type=int, default=24)
    parser.add_argument("--learning-rate", type=float, default=1.5e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--seed", type=int, default=20260819)
    parser.add_argument("--calibration-weight", type=float, default=0.10)
    parser.add_argument("--boundary-weight", type=float, default=0.35)
    parser.add_argument("--sdf-weight", type=float, default=0.35)
    parser.add_argument("--indent-weight", type=float, default=0.45)
    parser.add_argument("--aux-boundary-weight", type=float, default=0.15)
    parser.add_argument("--aux-notch-weight", type=float, default=0.12)
    parser.add_argument("--gate-weight", type=float, default=0.10)
    parser.add_argument("--identity-weight", type=float, default=0.20)
    parser.add_argument("--residual-weight", type=float, default=0.02)
    parser.add_argument("--iou-tolerance", type=float, default=0.005)
    parser.add_argument("--boundary-tolerance", type=float, default=0.010)
    return parser.parse_args()


def load_coarse(path: Path, device: torch.device) -> tuple[ConcavityNetV2, dict[str, object]]:
    state = torch.load(path.resolve(), map_location=device, weights_only=False)
    spec = ModelSpec(**state["spec"])
    model = ConcavityNetV2(int(state["base_channels"]), spec).to(device)
    model.load_state_dict(state["model"])
    model.eval()
    model.requires_grad_(False)
    return model, state


def binary_band(mask: torch.Tensor, kernel_size: int = 3) -> torch.Tensor:
    padding = kernel_size // 2
    dilation = F.max_pool2d(mask, kernel_size, stride=1, padding=padding)
    erosion = 1.0 - F.max_pool2d(1.0 - mask, kernel_size, stride=1, padding=padding)
    return (dilation - erosion).clamp(0.0, 1.0)


def balanced_binary_loss(logits: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    # A sigmoid/logit round trip can saturate to exactly 0 or 1 in FP16.
    # Keep the numerically stable BCE implementation and its masked products
    # in FP32 so zero masks never multiply an infinite half-precision loss.
    with torch.amp.autocast("cuda", enabled=False):
        logits_float = logits.float()
        target_float = target.float()
        raw = F.binary_cross_entropy_with_logits(logits_float, target_float, reduction="none")
        positive = normalized_masked_mean(raw, target_float)
        negative = normalized_masked_mean(raw, 1.0 - target_float)
    return 0.5 * (positive + negative)


def distort_probabilities(probability: torch.Tensor, fov: torch.Tensor) -> torch.Tensor:
    """Mimic the closing, blur, and dilation errors common in EIT contours."""
    foreground = probability[:, 1:].sum(dim=1, keepdim=True)
    dilated = F.max_pool2d(foreground, 5, stride=1, padding=2)
    closed = 1.0 - F.max_pool2d(1.0 - dilated, 5, stride=1, padding=2)
    blurred = F.avg_pool2d(foreground, 7, stride=1, padding=3)
    mildly_dilated = F.max_pool2d(foreground, 3, stride=1, padding=1)

    styles = torch.randint(0, 4, (probability.shape[0], 1, 1, 1), device=probability.device)
    altered = foreground
    altered = torch.where(styles == 1, closed, altered)
    altered = torch.where(styles == 2, blurred, altered)
    altered = torch.where(styles == 3, mildly_dilated, altered)
    strength = torch.empty_like(styles, dtype=probability.dtype).uniform_(0.55, 0.95)
    altered = ((1.0 - strength) * foreground + strength * altered).clamp(1e-4, 1.0 - 1e-4)

    local_total = F.avg_pool2d(foreground, 5, stride=1, padding=2).clamp_min(1e-4)
    class_one = F.avg_pool2d(probability[:, 1:2], 5, stride=1, padding=2)
    class_one_ratio = (class_one / local_total).clamp(0.02, 0.98)
    result = torch.cat(
        (1.0 - altered, altered * class_one_ratio, altered * (1.0 - class_one_ratio)), dim=1
    )
    mask = fov.expand(probability.shape[0], 1, -1, -1)
    result[:, 0:1] = torch.where(mask > 0, result[:, 0:1], torch.ones_like(result[:, 0:1]))
    result[:, 1:] = torch.where(mask > 0, result[:, 1:], torch.zeros_like(result[:, 1:]))
    return result / result.sum(dim=1, keepdim=True).clamp_min(1e-6)


class TopologyRefiner(nn.Module):
    """A small residual U-Net that only edits coarse logits through a learned gate."""

    def __init__(self, base: int) -> None:
        super().__init__()
        self.stem = ResidualBlock(8, base)
        self.enc1 = ResidualBlock(base, base * 2)
        self.enc2 = ResidualBlock(base * 2, base * 4)
        self.bottleneck = nn.Sequential(
            ResidualBlock(base * 4, base * 8),
            nn.Dropout2d(0.10),
            ResidualBlock(base * 8, base * 8),
        )
        self.dec2 = DecoderStage(base * 8, base * 4, base * 4)
        self.dec1 = DecoderStage(base * 4, base * 2, base * 2)
        self.dec0 = DecoderStage(base * 2, base, base)
        self.residual_head = nn.Conv2d(base, 3, 1)
        self.gate_head = nn.Conv2d(base, 1, 1)
        self.sdf_head = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))
        self.boundary_head = nn.Conv2d(base, 1, 1)
        self.notch_head = nn.Conv2d(base, 1, 1)
        nn.init.zeros_(self.residual_head.weight)
        nn.init.zeros_(self.residual_head.bias)
        nn.init.zeros_(self.gate_head.weight)
        nn.init.constant_(self.gate_head.bias, -2.0)

    def forward(self, image: torch.Tensor, coarse_probability: torch.Tensor) -> dict[str, torch.Tensor]:
        entropy = -(coarse_probability * torch.log(coarse_probability.clamp_min(1e-7))).sum(dim=1, keepdim=True)
        entropy = entropy / math.log(coarse_probability.shape[1])
        coarse_foreground = coarse_probability[:, 1:].sum(dim=1, keepdim=True)
        dy, dx = gradients(coarse_foreground)
        edge = torch.zeros_like(coarse_foreground)
        edge[:, :, 1:, :] += dy.abs()
        edge[:, :, :, 1:] += dx.abs()
        inputs = torch.cat((image, coarse_probability, entropy, edge.clamp(0.0, 1.0)), dim=1)
        e0 = self.stem(inputs)
        e1 = self.enc1(F.max_pool2d(e0, 2))
        e2 = self.enc2(F.max_pool2d(e1, 2))
        x = self.bottleneck(F.max_pool2d(e2, 2))
        x = self.dec2(x, e2)
        x = self.dec1(x, e1)
        features = self.dec0(x, e0)
        residual = 1.5 * torch.tanh(self.residual_head(features))
        gate_logits = self.gate_head(features)
        gate = torch.sigmoid(gate_logits)
        coarse_logits = torch.log(coarse_probability.clamp_min(1e-7))
        return {
            "logits": coarse_logits + gate * residual,
            "residual": residual,
            "gate": gate,
            "gate_logits": gate_logits,
            "sdf": torch.tanh(self.sdf_head(features)),
            "boundary_logits": self.boundary_head(features),
            "notch_logits": self.notch_head(features),
        }


def refiner_loss(
    outputs: dict[str, torch.Tensor],
    batch: dict[str, torch.Tensor],
    input_probability: torch.Tensor,
    reference_probability: torch.Tensor,
    class_weights: torch.Tensor,
    args: argparse.Namespace,
    ramp: float,
) -> tuple[torch.Tensor, dict[str, float]]:
    logits = outputs["logits"]
    labels = batch["labels"]
    target_foreground = (labels != 0).float().unsqueeze(1)
    probability = torch.softmax(logits, dim=1)
    foreground = probability[:, 1:].sum(dim=1, keepdim=True)
    ce = F.cross_entropy(logits, labels, weight=class_weights)
    dice = soft_dice_loss(logits, labels)

    pred_dy, pred_dx = gradients(foreground)
    true_dy, true_dx = gradients(target_foreground)
    boundary = F.l1_loss(pred_dy, true_dy) + F.l1_loss(pred_dx, true_dx)
    sdf = F.smooth_l1_loss(outputs["sdf"], batch["sdf"], beta=0.08)

    indentation = batch["indent"]
    notch_rim = indentation * F.max_pool2d(target_foreground, 11, stride=1, padding=5)
    concave_inside = target_foreground * F.max_pool2d(indentation, 11, stride=1, padding=5)
    false_fill = normalized_masked_mean(foreground, notch_rim)
    false_cut = normalized_masked_mean(1.0 - foreground, concave_inside)
    indent = 0.5 * (false_fill + false_cut)

    target_boundary = binary_band(target_foreground)
    auxiliary_boundary = balanced_binary_loss(outputs["boundary_logits"], target_boundary)
    auxiliary_notch = balanced_binary_loss(outputs["notch_logits"], indentation)

    input_prediction = input_probability.argmax(dim=1, keepdim=True)
    correction = (input_prediction != labels.unsqueeze(1)).float()
    correction = F.max_pool2d(correction, 5, stride=1, padding=2)
    gate = balanced_binary_loss(outputs["gate_logits"], correction)

    reference_prediction = reference_probability.argmax(dim=1, keepdim=True)
    confidence = reference_probability.max(dim=1, keepdim=True).values
    stable = ((reference_prediction == labels.unsqueeze(1)) & (confidence > 0.80) & (correction == 0)).float()
    probability_change = (probability - reference_probability).abs().sum(dim=1, keepdim=True)
    identity = normalized_masked_mean(probability_change, stable)
    residual = (outputs["gate"] * outputs["residual"].abs().mean(dim=1, keepdim=True)).mean()

    total = ce + dice + ramp * (
        args.boundary_weight * boundary
        + args.sdf_weight * sdf
        + args.indent_weight * indent
        + args.aux_boundary_weight * auxiliary_boundary
        + args.aux_notch_weight * auxiliary_notch
        + args.gate_weight * gate
        + args.identity_weight * identity
        + args.residual_weight * residual
    )
    pieces = {
        "ce": ce,
        "dice": dice,
        "boundary": boundary,
        "sdf": sdf,
        "indent": indent,
        "gate": gate,
        "identity": identity,
        "residual": residual,
        "total": total,
    }
    return total, {key: float(value.detach()) for key, value in pieces.items()}


@torch.no_grad()
def predictions_for_loader(
    coarse: ConcavityNetV2,
    refiner: TopologyRefiner,
    adapter: InputAdapter,
    loader: DataLoader,
    device: torch.device,
) -> tuple[dict[str, float], dict[str, float], dict[int, np.ndarray], dict[int, np.ndarray]]:
    coarse.eval()
    refiner.eval()
    coarse_rows: list[dict[str, float]] = []
    refined_rows: list[dict[str, float]] = []
    coarse_predictions: dict[int, np.ndarray] = {}
    refined_predictions: dict[int, np.ndarray] = {}
    for batch in loader:
        image = adapter(batch["image"].to(device))
        voltage = batch["input_voltage"].to(device)
        coarse_logits = coarse(image, voltage)["logits"]
        coarse_probability = torch.softmax(coarse_logits, dim=1)
        refined_logits = refiner(image, coarse_probability)["logits"]
        coarse_prediction = coarse_logits.argmax(dim=1).cpu().numpy()
        refined_prediction = refined_logits.argmax(dim=1).cpu().numpy()
        truths = batch["labels"].numpy()
        indentations = batch["indent"].numpy()[:, 0]
        for offset, index in enumerate(batch["index"].numpy()):
            coarse_predictions[int(index)] = coarse_prediction[offset]
            refined_predictions[int(index)] = refined_prediction[offset]
            coarse_rows.append(confusion_metrics(truths[offset], coarse_prediction[offset], indentations[offset]))
            refined_rows.append(confusion_metrics(truths[offset], refined_prediction[offset], indentations[offset]))
    return (
        aggregate_rows(coarse_rows),
        aggregate_rows(refined_rows),
        coarse_predictions,
        refined_predictions,
    )


def train_refiner(
    archive: np.lib.npyio.NpzFile,
    coarse: ConcavityNetV2,
    adapter: InputAdapter,
    args: argparse.Namespace,
    output_dir: Path,
    device: torch.device,
) -> tuple[TopologyRefiner, list[dict[str, float]], dict[str, float], dict[str, float]]:
    train_loader = DataLoader(
        EITDatasetV2(archive, archive["train_indices"]),
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.workers,
        pin_memory=device.type == "cuda",
        drop_last=True,
    )
    validation_loader = DataLoader(
        EITDatasetV2(archive, archive["validation_indices"]),
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.workers,
        pin_memory=device.type == "cuda",
    )
    calibration_loader = DataLoader(CalibrationDatasetV2(archive), batch_size=4, shuffle=True, num_workers=0)
    calibration_iterator = iter(calibration_loader)
    model = TopologyRefiner(args.base_channels).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(1, args.epochs))
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    counts = np.bincount(archive["labels"][archive["train_indices"]].reshape(-1), minlength=3).astype(np.float64)
    class_weights_np = np.sqrt(counts.sum() / np.maximum(counts, 1.0))
    class_weights_np /= class_weights_np.mean()
    class_weights = torch.from_numpy(class_weights_np.astype(np.float32)).to(device)
    fov = torch.from_numpy(archive["fov_mask"].astype(np.float32))[None, None].to(device)
    checkpoint = output_dir / "refiner_best.pt"
    history: list[dict[str, float]] = []
    best_score = -math.inf
    stale = 0
    validation_reference: dict[str, float] = {}
    validation_selected: dict[str, float] = {}

    for epoch in range(1, args.epochs + 1):
        model.train()
        totals: list[float] = []
        ramp = min(1.0, max(0.0, (epoch - 2) / 8.0))
        for batch in train_loader:
            batch = {key: value.to(device, non_blocking=True) for key, value in batch.items()}
            optimizer.zero_grad(set_to_none=True)
            with torch.no_grad():
                image = adapter(batch["image"])
                reference_probability = torch.softmax(coarse(image, batch["input_voltage"])["logits"], dim=1)
                input_probability = distort_probabilities(reference_probability, fov)
            with torch.amp.autocast("cuda", enabled=device.type == "cuda"):
                outputs = model(image, input_probability)
                loss, _ = refiner_loss(
                    outputs, batch, input_probability, reference_probability, class_weights, args, ramp
                )
                try:
                    calibration_batch = next(calibration_iterator)
                except StopIteration:
                    calibration_iterator = iter(calibration_loader)
                    calibration_batch = next(calibration_iterator)
                calibration_batch = {key: value.to(device, non_blocking=True) for key, value in calibration_batch.items()}
                with torch.no_grad():
                    calibration_image = adapter(calibration_batch["image"])
                    calibration_reference = torch.softmax(
                        coarse(calibration_image, calibration_batch["input_voltage"])["logits"], dim=1
                    )
                    calibration_input = distort_probabilities(calibration_reference, fov)
                calibration_outputs = model(calibration_image, calibration_input)
                calibration_term, _ = refiner_loss(
                    calibration_outputs,
                    calibration_batch,
                    calibration_input,
                    calibration_reference,
                    class_weights,
                    args,
                    ramp,
                )
                loss = loss + args.calibration_weight * calibration_term
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            scaler.step(optimizer)
            scaler.update()
            totals.append(float(loss.detach()))
        scheduler.step()

        reference, refined, _, _ = predictions_for_loader(coarse, model, adapter, validation_loader, device)
        eligible = (
            refined["foreground_iou"] >= reference["foreground_iou"] - args.iou_tolerance
            and refined["boundary_f1"] >= reference["boundary_f1"] - args.boundary_tolerance
        )
        score = selection_score(refined) if eligible else -math.inf
        row = {
            "epoch": float(epoch),
            "train_loss": float(np.mean(totals)),
            "learning_rate": float(optimizer.param_groups[0]["lr"]),
            "eligible": float(eligible),
            "selection_score": float(score),
            **{f"validation_{key}": value for key, value in refined.items()},
        }
        history.append(row)
        print(
            f"refiner epoch {epoch}/{args.epochs}: loss={row['train_loss']:.4f}, "
            f"IoU={refined['foreground_iou']:.4f}, boundary={refined['boundary_f1']:.4f}, "
            f"notch={refined['notch_preservation']:.4f}, joint={refined['concavity_score']:.4f}, "
            f"eligible={eligible}",
            flush=True,
        )
        if eligible and score > best_score + 1e-5:
            best_score = score
            stale = 0
            validation_reference = reference
            validation_selected = refined
            torch.save(
                {
                    "model": model.state_dict(),
                    "base_channels": args.base_channels,
                    "epoch": epoch,
                    "selection_score": score,
                    "coarse_checkpoint": str(args.coarse_checkpoint.resolve()),
                    "class_weights": class_weights_np.tolist(),
                },
                checkpoint,
            )
        else:
            stale += 1
        if stale >= args.patience and checkpoint.exists():
            print(f"refiner: early stopping after {epoch} epochs", flush=True)
            break
    if not checkpoint.exists():
        raise RuntimeError("No topology-refiner checkpoint satisfied the validation region/boundary constraints")
    state = torch.load(checkpoint, map_location=device, weights_only=False)
    model.load_state_dict(state["model"])
    (output_dir / "refiner_history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    return model, history, validation_reference, validation_selected


@torch.no_grad()
def infer_real(
    coarse: ConcavityNetV2,
    refiner: TopologyRefiner,
    adapter: InputAdapter,
    images: np.ndarray,
    voltages: np.ndarray,
    device: torch.device,
    batch_size: int,
) -> tuple[np.ndarray, np.ndarray]:
    coarse_outputs: list[np.ndarray] = []
    refined_outputs: list[np.ndarray] = []
    for start in range(0, len(images), batch_size):
        image = torch.from_numpy(images[start : start + batch_size, None].astype(np.float32)).to(device)
        voltage = torch.from_numpy(voltages[start : start + batch_size].astype(np.float32)).to(device)
        adapted = adapter(image)
        coarse_logits = coarse(adapted, voltage)["logits"]
        refined_logits = refiner(adapted, torch.softmax(coarse_logits, dim=1))["logits"]
        coarse_logits = F.interpolate(coarse_logits, size=(256, 256), mode="bilinear", align_corners=False)
        refined_logits = F.interpolate(refined_logits, size=(256, 256), mode="bilinear", align_corners=False)
        coarse_outputs.append(coarse_logits.argmax(dim=1).cpu().numpy())
        refined_outputs.append(refined_logits.argmax(dim=1).cpu().numpy())
    return np.concatenate(coarse_outputs), np.concatenate(refined_outputs)


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    archive = np.load(args.dataset.resolve(), allow_pickle=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    coarse, coarse_state = load_coarse(args.coarse_checkpoint, device)
    adapter = InputAdapter(archive["fov_mask"]).to(device)
    print(f"device={device}; seed={args.seed}; frozen coarse={args.coarse_checkpoint}", flush=True)

    refiner, history, validation_reference, validation_selected = train_refiner(
        archive, coarse, adapter, args, output_dir, device
    )
    test_loader = DataLoader(
        EITDatasetV2(archive, archive["test_indices"]),
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.workers,
    )
    test_reference, test_refined, _, _ = predictions_for_loader(coarse, refiner, adapter, test_loader, device)
    print(f"synthetic untouched test boundary: {test_reference}", flush=True)
    print(f"synthetic untouched test refiner: {test_refined}", flush=True)

    # Evaluation labels are first accessed after validation selection and the
    # independent synthetic test have both completed.
    real_truths = archive["real_labels"]
    real_ids = archive["real_ids"]
    real_boundary, real_refined = infer_real(
        coarse,
        refiner,
        adapter,
        archive["real_linear_images"],
        archive["real_voltages"],
        device,
        args.batch_size,
    )
    real_predictions = {"boundary": real_boundary, "refiner": real_refined}
    real_summary: dict[str, dict[str, float]] = {}
    real_rows: list[dict[str, object]] = []
    for name, predictions in real_predictions.items():
        real_summary[name], rows = evaluate_real_predictions(name, predictions, real_truths, real_ids)
        real_rows.extend(rows)
        print(f"real test {name}: {real_summary[name]}", flush=True)
    write_rows(output_dir / "real_case_metrics.csv", real_rows)
    save_real_montage(output_dir / "real_all_21_comparison.png", real_truths, real_ids, real_predictions, real_rows)
    save_focus_montage(output_dir / "real_most_concave_comparison.png", real_truths, real_ids, real_predictions, real_rows)
    save_training_curves(output_dir / "training_curves.png", {"refiner": history})
    np.savez_compressed(
        output_dir / "real_predictions.npz",
        ids=real_ids,
        truth=real_truths,
        boundary=real_boundary,
        refiner=real_refined,
    )

    result = {
        "dataset": str(args.dataset.resolve()),
        "coarse_checkpoint": str(args.coarse_checkpoint.resolve()),
        "coarse_epoch": int(coarse_state.get("epoch", -1)),
        "output_dir": str(output_dir),
        "device": str(device),
        "seed": args.seed,
        "validation_reference": validation_reference,
        "validation_selected": validation_selected,
        "synthetic_untouched_test": {"boundary": test_reference, "refiner": test_refined},
        "real_untouched_test": real_summary,
        "selection_constraints": {
            "minimum_iou": validation_reference.get("foreground_iou", float("nan")) - args.iou_tolerance,
            "minimum_boundary_f1": validation_reference.get("boundary_f1", float("nan")) - args.boundary_tolerance,
        },
        "evaluation_truth_used_for_training_or_selection": False,
        "selection_rule": "validation-only 0.55 IoU + 0.20 boundary F1 + 0.25 joint concavity with region/boundary floors",
        "args": vars(args) | {
            "dataset": str(args.dataset),
            "coarse_checkpoint": str(args.coarse_checkpoint),
            "output_dir": str(args.output_dir),
        },
    }
    (output_dir / "summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
