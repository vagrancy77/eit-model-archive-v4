"""Measure the representation upper bound of all saved KTC predictions.

This is an evaluation-only audit.  Its oracle must never be reported as a
deployable reconstruction method; it answers whether any existing model family
can represent the public inward boundaries at all.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


STRICT_INWARD_IDS = (
    "level_2/1", "level_2/3", "level_3/2", "level_5/2",
    "level_6/2", "level_6/3", "level_7/1", "level_7/2", "level_7/3",
)
EXCLUDED_PARTS = ("cache", "us_prior", "simulation_data", "nonlinear_cem_candidate_ranking")
EXCLUDED_KEYS = ("truth", "label", "probability", "mask", "cutout", "bank", "support", "field")


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--outputs-root", type=Path, default=root / "outputs")
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--output-dir", type=Path, default=root / "outputs" / "ktc_existing_prediction_pool_audit")
    return parser.parse_args()


def is_label_array(key: str, values: np.ndarray) -> bool:
    lower = key.lower()
    if any(part in lower for part in EXCLUDED_KEYS):
        return False
    if values.shape == (21, 256, 256):
        candidate = values
    elif values.ndim == 4 and values.shape[1:] == (21, 256, 256):
        candidate = values
    else:
        return False
    if not np.issubdtype(candidate.dtype, np.integer):
        return False
    unique = np.unique(candidate)
    return bool(np.all(np.isin(unique, (0, 1, 2))))


def foreground_iou(truths: np.ndarray, predictions: np.ndarray) -> np.ndarray:
    truth = truths != 0
    prediction = predictions != 0
    intersection = np.logical_and(truth, prediction).sum(axis=(1, 2))
    union = np.logical_or(truth, prediction).sum(axis=(1, 2))
    return intersection / np.maximum(union, 1)


def collect_predictions(outputs_root: Path) -> tuple[list[str], np.ndarray]:
    names: list[str] = []
    arrays: list[np.ndarray] = []
    for path in sorted(outputs_root.rglob("*.npz")):
        relative = str(path.relative_to(outputs_root))
        if any(part in relative for part in EXCLUDED_PARTS):
            continue
        try:
            archive = np.load(path, allow_pickle=False)
            for key in archive.files:
                values = np.asarray(archive[key])
                if not is_label_array(key, values):
                    continue
                if values.ndim == 3:
                    names.append(f"{relative}::{key}")
                    arrays.append(values.astype(np.uint8))
                else:
                    for candidate_index in range(values.shape[0]):
                        names.append(f"{relative}::{key}[{candidate_index}]")
                        arrays.append(values[candidate_index].astype(np.uint8))
        except (OSError, ValueError, KeyError):
            continue
    if not arrays:
        raise RuntimeError("no public KTC label predictions found")
    return names, np.stack(arrays)


def save_oracle_montage(
    path: Path, truths: np.ndarray, ids: np.ndarray, baseline: np.ndarray,
    oracle: np.ndarray, oracle_names: list[str], only_ids: tuple[str, ...] | None = None,
) -> None:
    indices = [index for index, case_id in enumerate(ids) if only_ids is None or str(case_id) in only_ids]
    figure, axes = plt.subplots(len(indices), 4, figsize=(10.5, 2.55 * len(indices)), squeeze=False)
    for row, index in enumerate(indices):
        before = foreground_iou(truths[index:index + 1], baseline[index:index + 1])[0]
        after = foreground_iou(truths[index:index + 1], oracle[index:index + 1])[0]
        removed = np.logical_and(baseline[index] != 0, oracle[index] == 0)
        for column, (image, title, cmap, vmax) in enumerate((
            (truths[index], "truth", "viridis", 2),
            (baseline[index], f"stable baseline\nIoU={before:.3f}", "viridis", 2),
            (oracle[index], f"pool oracle IoU={after:.3f}\n{oracle_names[index][-58:]}", "viridis", 2),
            (removed, "oracle inward removal", "magma", 1),
        )):
            axes[row, column].imshow(image, cmap=cmap, vmin=0, vmax=vmax, interpolation="nearest")
            axes[row, column].set_title(title, fontsize=7)
            axes[row, column].set_axis_off()
        axes[row, 0].set_ylabel(str(ids[index]), fontsize=8)
    figure.tight_layout()
    figure.savefig(path, dpi=190)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    base = np.load(args.base_dataset.resolve(), allow_pickle=False)
    truths = np.asarray(base["real_labels"], dtype=np.uint8)
    ids = np.asarray(base["real_ids"])
    names, pool = collect_predictions(args.outputs_root.resolve())

    # Include the stable baseline explicitly and remove byte-identical methods.
    stable_archive = np.load(
        args.outputs_root.resolve() / "ktc_physics_consistent_concavity_selector_candidate_export_seed20260820" / "predictions.npz",
        allow_pickle=False,
    )
    baseline = np.asarray(stable_archive["real_path"], dtype=np.uint8)
    names.insert(0, "stable_baseline")
    pool = np.concatenate((baseline[None], pool), axis=0)
    signatures: set[bytes] = set()
    keep: list[int] = []
    for index, prediction in enumerate(pool):
        signature = prediction.tobytes()
        if signature not in signatures:
            signatures.add(signature)
            keep.append(index)
    pool = pool[keep]
    names = [names[index] for index in keep]

    iou = np.stack([foreground_iou(truths, prediction) for prediction in pool])
    oracle_choice = np.argmax(iou, axis=0)
    oracle = pool[oracle_choice, np.arange(len(ids))]
    baseline_iou = foreground_iou(truths, baseline)
    oracle_iou = foreground_iou(truths, oracle)
    strict = np.asarray([str(case_id) in STRICT_INWARD_IDS for case_id in ids])

    method_rows = []
    for method_index, name in enumerate(names):
        values = iou[method_index]
        method_rows.append({
            "method_index": method_index, "name": name,
            "public_mean_iou": float(values.mean()),
            "strict_inward_mean_iou": float(values[strict].mean()),
            "ordinary_mean_iou": float(values[~strict].mean()),
            "wins": int(np.count_nonzero(oracle_choice == method_index)),
        })
    method_rows.sort(key=lambda row: float(row["strict_inward_mean_iou"]), reverse=True)
    case_rows = []
    oracle_names = []
    for index, case_id in enumerate(ids):
        name = names[int(oracle_choice[index])]
        oracle_names.append(name)
        case_rows.append({
            "id": str(case_id), "strict_inward": bool(strict[index]),
            "baseline_iou": float(baseline_iou[index]), "oracle_iou": float(oracle_iou[index]),
            "iou_gain": float(oracle_iou[index] - baseline_iou[index]),
            "oracle_method_index": int(oracle_choice[index]), "oracle_name": name,
        })

    for filename, rows in (("methods.csv", method_rows), ("cases.csv", case_rows)):
        with (output_dir / filename).open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    summary = {
        "audit_only": True,
        "raw_prediction_count": int(len(keep)),
        "unique_representation_count": int(len(pool)),
        "baseline_public_mean_iou": float(baseline_iou.mean()),
        "pool_oracle_public_mean_iou": float(oracle_iou.mean()),
        "baseline_strict_inward_mean_iou": float(baseline_iou[strict].mean()),
        "pool_oracle_strict_inward_mean_iou": float(oracle_iou[strict].mean()),
        "baseline_ordinary_mean_iou": float(baseline_iou[~strict].mean()),
        "pool_oracle_ordinary_mean_iou": float(oracle_iou[~strict].mean()),
        "oracle_changed_cases": int(np.count_nonzero(oracle_choice)),
        "top_strict_methods": method_rows[:15],
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    np.savez_compressed(
        output_dir / "oracle.npz", ids=ids, baseline=baseline, oracle=oracle,
        oracle_choice=oracle_choice, iou=iou, names=np.asarray(names),
    )
    save_oracle_montage(output_dir / "public_pool_oracle.png", truths, ids, baseline, oracle, oracle_names)
    save_oracle_montage(
        output_dir / "strict_inward_pool_oracle.png", truths, ids, baseline, oracle,
        oracle_names, STRICT_INWARD_IDS,
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
