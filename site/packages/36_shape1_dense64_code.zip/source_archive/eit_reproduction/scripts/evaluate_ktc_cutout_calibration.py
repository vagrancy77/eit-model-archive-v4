"""Evaluate the frozen physics-gated cutout method on the four public cases."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch

from physics_gate_ktc_cutouts import (
    candidate_physics,
    choose_indices,
    gather_candidates,
    propose_candidates,
)
from train_ktc_concavity_network import InputAdapter, confusion_metrics, indentation_mask, write_rows
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_highres_refiner import (
    load_coarse_ensemble,
    load_dip_four_case_predictions,
    load_official_four_case_truths,
    save_official_four_case_comparison,
)
from train_ktc_hull_cutout_network import HullCutoutNet


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument(
        "--cutout-checkpoint",
        type=Path,
        default=root / "outputs" / "ktc_hull_cutout_formal_seed20260819" / "hull_cutout_best.pt",
    )
    parser.add_argument(
        "--coarse-checkpoint",
        nargs="+",
        type=Path,
        default=[
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "boundary_best.pt",
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "indent_best.pt",
            root / "outputs" / "ktc_concavity_voltage_seed20260819" / "voltage_best.pt",
        ],
    )
    parser.add_argument("--coarse-weights", nargs="+", type=float, default=[0.30, 0.40, 0.30])
    parser.add_argument("--official-repo", type=Path, default=root / "external" / "KTC2023-ABC2")
    parser.add_argument("--output-dir", type=Path, default=root / "outputs" / "ktc_cutout_calibration_four")
    parser.add_argument("--penalty", type=float, default=0.0)
    parser.add_argument("--min-gain", type=float, default=0.001)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    archive = np.load(args.dataset.resolve(), allow_pickle=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    coarse, _, coarse_weights = load_coarse_ensemble(
        args.coarse_checkpoint, args.coarse_weights, device
    )
    state = torch.load(args.cutout_checkpoint.resolve(), map_location=device, weights_only=False)
    model = HullCutoutNet(int(state["base_channels"])).to(device)
    model.load_state_dict(state["model"])
    model.eval()
    adapter = InputAdapter(archive["fov_mask"]).to(device)

    coarse64, candidates64, coarse256, candidates256 = propose_candidates(
        coarse,
        model,
        adapter,
        archive["calibration_linear_images"],
        archive["calibration_voltages"],
        device,
        4,
        real_resolution=True,
    )
    assert coarse256 is not None and candidates256 is not None
    residuals, changes = candidate_physics(
        coarse64, candidates64, archive["calibration_voltages"], archive
    )
    selected = choose_indices(residuals, changes, args.penalty, args.min_gain)
    gated = gather_candidates(coarse256, candidates256, selected)
    truths, ids = load_official_four_case_truths(args.official_repo.resolve())
    dip = load_dip_four_case_predictions(Path(__file__).resolve().parents[1])
    predictions = {"DIP+TV": dip, "coarse_fusion": coarse256, "physics_gated_cutout": gated}
    summaries: dict[str, dict[str, float]] = {}
    rows: list[dict[str, object]] = []
    for name, values in predictions.items():
        summaries[name], method_rows = evaluate_real_predictions(name, values, truths, ids)
        rows.extend(method_rows)
    write_rows(output_dir / "case_metrics.csv", rows)
    save_official_four_case_comparison(
        output_dir / "comparison.png", truths, ids, predictions, rows
    )
    per_case = []
    for index, (truth, case_id) in enumerate(zip(truths, ids)):
        per_case.append(
            {
                "id": str(case_id),
                "selected_candidate": int(selected[index]),
                "coarse": confusion_metrics(truth, coarse256[index], indentation_mask(truth)),
                "physics_gated_cutout": confusion_metrics(truth, gated[index], indentation_mask(truth)),
                "relative_voltage_residuals": residuals[:, index].tolist(),
            }
        )
    result = {
        "fixed_penalty": args.penalty,
        "fixed_min_gain": args.min_gain,
        "coarse_weights": coarse_weights,
        "summaries": summaries,
        "selected_candidate_indices": selected.tolist(),
        "per_case": per_case,
        "four_cases_are_public_training_calibration_cases": True,
    }
    (output_dir / "summary.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
