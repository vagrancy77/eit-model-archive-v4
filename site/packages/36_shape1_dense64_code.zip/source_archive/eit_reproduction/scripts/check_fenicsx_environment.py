"""Verify the active FEniCSX environment and basic matrix assembly."""

from __future__ import annotations

from mpi4py import MPI
import basix.ufl
import dolfinx
from dolfinx import fem
from dolfinx import mesh as dmesh
import numpy as np
import ufl


def main() -> None:
    print("step=basic-imports-ok", flush=True)
    data = np.load("outputs/simulation_data.npz")
    cells = np.asarray(data["inverse_elements"][:, :3], dtype=np.int64)
    coordinates = np.asarray(data["inverse_nodes"][:, :2], dtype=np.float64)
    print("step=saved-mesh-loaded", flush=True)

    print("step=fenicsx-imports-ok", flush=True)
    coordinate_element = basix.ufl.element(
        "Lagrange",
        "triangle",
        1,
        shape=(2,),
    )
    domain = dmesh.create_mesh(
        MPI.COMM_SELF,
        cells,
        coordinate_element,
        coordinates,
    )
    print("step=dolfinx-mesh-ok", flush=True)
    potential_space = fem.functionspace(domain, ("Lagrange", 1))
    conductivity_space = fem.functionspace(domain, ("DG", 0))
    print("step=function-spaces-ok", flush=True)
    conductivity = fem.Function(conductivity_space)
    conductivity.x.array[:] = 1.0

    trial = ufl.TrialFunction(potential_space)
    test = ufl.TestFunction(potential_space)
    bilinear_form = fem.form(
        conductivity * ufl.inner(ufl.grad(trial), ufl.grad(test)) * ufl.dx
    )
    print("step=form-compiled", flush=True)
    stiffness = fem.assemble_matrix(bilinear_form)
    print("step=matrix-assembled", flush=True)
    stiffness.scatter_reverse()
    scipy_matrix = stiffness.to_scipy()

    print(f"dolfinx={dolfinx.__version__}")
    print(f"mpi={MPI.Get_library_version().splitlines()[0]}")
    print(f"nodes={coordinates.shape[0]}, elements={cells.shape[0]}")
    print(f"potential_dofs={potential_space.dofmap.index_map.size_local}")
    print(f"conductivity_dofs={conductivity_space.dofmap.index_map.size_local}")
    print(f"stiffness_shape={scipy_matrix.shape}, nnz={scipy_matrix.nnz}")
    print(f"geometry_dofmap_shape={np.asarray(domain.geometry.dofmap).shape}")


if __name__ == "__main__":
    main()
