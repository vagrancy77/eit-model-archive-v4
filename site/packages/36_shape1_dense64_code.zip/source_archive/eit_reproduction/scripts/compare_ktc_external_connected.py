"""Paired bootstrap comparison for the final non-convex EIT candidate."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


METRICS = (
    ("foreground_iou", "Foreground IoU"),
    ("open_deep_cutout_recovery", "Open deep cutout"),
    ("bank_retention", "Bank retention"),
    ("topology_structural_joint", "Topology joint"),
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, default=root.parent / "ktc_contact_pixel_fusion_seed20260820" / "summary.json")
    parser.add_argument("--candidate", type=Path, default=root.parent / "ktc_external_connected_support_seed20260820" / "summary.json")
    parser.add_argument("--output-dir", type=Path, default=root.parent / "ktc_external_connected_support_seed20260820")
    parser.add_argument("--samples", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260820)
    return parser.parse_args()


def main() -> None:
    args = parse_args(); out = args.output_dir.resolve(); out.mkdir(parents=True, exist_ok=True)
    baseline = json.loads(args.baseline.read_text(encoding="utf-8"))
    candidate = json.loads(args.candidate.read_text(encoding="utf-8"))
    base_rows = baseline["test"]["stress"]["stable"]["rows"]
    candidate_rows = candidate["test"]["stress"]["rows"]
    if len(base_rows) != len(candidate_rows):
        raise RuntimeError("Baseline and candidate do not contain the same test sample count")
    rng = np.random.default_rng(args.seed); n = len(base_rows)
    indices = rng.integers(0, n, size=(args.samples, n))
    rows: list[dict[str, float | str]] = []
    for key, label in METRICS:
        before = np.asarray([float(row[key]) for row in base_rows])
        after = np.asarray([float(row[key]) for row in candidate_rows])
        difference = after - before
        boot = difference[indices].mean(axis=1)
        rows.append({
            "metric": key,
            "label": label,
            "baseline_mean": float(before.mean()),
            "candidate_mean": float(after.mean()),
            "mean_difference": float(difference.mean()),
            "ci95_low": float(np.quantile(boot, 0.025)),
            "ci95_high": float(np.quantile(boot, 0.975)),
            "improved_fraction": float((difference > 0).mean()),
            "n": n,
        })
    with (out / "paired_bootstrap.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    (out / "paired_bootstrap.json").write_text(json.dumps({"samples": args.samples, "seed": args.seed, "rows": rows}, indent=2), encoding="utf-8")

    means = np.asarray([float(row["mean_difference"]) for row in rows])
    low = np.asarray([float(row["ci95_low"]) for row in rows])
    high = np.asarray([float(row["ci95_high"]) for row in rows])
    figure, axis = plt.subplots(figsize=(8.2, 4.4))
    colors = ["#167D8D" if value >= 0 else "#B34A3C" for value in means]
    axis.barh([str(row["label"]) for row in rows], means, color=colors, alpha=0.9)
    axis.errorbar(means, np.arange(len(rows)), xerr=np.vstack((means - low, high - means)), fmt="none", ecolor="black", capsize=4)
    axis.axvline(0.0, color="black", linewidth=1)
    axis.set_xlabel("Paired mean difference: external-connected - stable")
    axis.set_title(f"Independent non-convex stress test (n={n}, {args.samples:,} bootstrap samples)")
    figure.tight_layout(); figure.savefig(out / "paired_bootstrap.png", dpi=200); plt.close(figure)
    print(json.dumps(rows, indent=2))


if __name__ == "__main__": main()
