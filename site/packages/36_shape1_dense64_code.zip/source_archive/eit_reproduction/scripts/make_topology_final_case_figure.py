"""Create geometry-selected final case comparisons without performance cherry-picking."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import zoom


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--test-predictions", type=Path,
        default=Path(r"E:\Codex\topology_risk_eit_v4_full\test_predictions.npz"),
    )
    parser.add_argument(
        "--public-predictions", type=Path,
        default=Path(r"E:\Codex\topology_risk_eit_v4_final\public_ktc_predictions.npz"),
    )
    parser.add_argument(
        "--router", type=Path,
        default=Path(r"E:\Codex\topology_risk_eit_v4_router_seed_20260911\action_router_summary.json"),
    )
    parser.add_argument(
        "--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz"
    )
    parser.add_argument(
        "--audit", type=Path,
        default=root / "outputs" / "ktc2023_full_audit" / "summary.json",
    )
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def route(direct: np.ndarray, topology: np.ndarray, gate: float, threshold: float) -> np.ndarray:
    return topology if gate >= threshold else direct


def main() -> None:
    args = parse_args()
    synthetic = np.load(args.test_predictions.resolve(), allow_pickle=False)
    public = np.load(args.public_predictions.resolve(), allow_pickle=False)
    dataset = np.load(args.dataset.resolve(), allow_pickle=False)
    threshold = float(json.loads(args.router.resolve().read_text(encoding="utf-8"))["threshold"])
    audit = json.loads(args.audit.resolve().read_text(encoding="utf-8"))

    rows: list[dict[str, object]] = []
    for group_name in ("biological", "stress"):
        cutout = np.asarray(synthetic[f"{group_name}_cutout"])
        area = cutout.reshape(len(cutout), -1).sum(axis=1)
        if group_name == "stress":
            eligible = np.flatnonzero(synthetic[f"{group_name}_case_gate"] >= threshold)
            order = eligible[np.argsort(area[eligible])[-2:][::-1]]
            selection_note = "largest cutout among electrically enabled cases"
        else:
            order = np.argsort(area)[-2:][::-1]
            selection_note = "largest cutout; no prediction metric used"
        for index in order:
            direct = np.asarray(synthetic[f"{group_name}_base_prediction"][index])
            topology = np.asarray(synthetic[f"{group_name}_prediction"][index])
            gate = float(synthetic[f"{group_name}_case_gate"][index])
            rows.append(
                {
                    "id": f"{group_name}/{int(synthetic[f'{group_name}_index'][index])}",
                    "linear": np.asarray(synthetic[f"{group_name}_image"][index]),
                    "truth": np.asarray(synthetic[f"{group_name}_truth"][index]),
                    "direct": direct,
                    "topology": topology,
                    "routed": route(direct, topology, gate, threshold),
                    "cutout": cutout[index],
                    "gate": gate,
                    "selection": selection_note,
                }
            )

    ranked_public = [str(value["id"]) for value in audit["most_nonconvex"]]
    # Use the most nonconvex geometry and then the next geometry for which the
    # validation-frozen route is active; this is based on gate/input only, not truth metrics.
    chosen_public: list[int] = []
    for case_id in ranked_public:
        index = int(np.flatnonzero(public["ids"] == case_id)[0])
        if not chosen_public or float(public["case_gate"][index]) >= threshold:
            chosen_public.append(index)
        if len(chosen_public) == 2:
            break
    for index in chosen_public:
        case_id = str(public["ids"][index])
        source_index = int(np.flatnonzero(dataset["real_ids"] == case_id)[0])
        direct = np.asarray(public["direct_base"][index])
        topology = np.asarray(public["topology_residual"][index])
        gate = float(public["case_gate"][index])
        rows.append(
            {
                "id": case_id,
                "linear": zoom(np.asarray(dataset["real_linear_images"][source_index]), 4.0, order=1),
                "truth": np.asarray(public["truth"][index]),
                "direct": direct,
                "topology": topology,
                "routed": route(direct, topology, gate, threshold),
                "cutout": np.asarray(public["notch"][index]),
                "gate": gate,
                "selection": "pre-audited nonconvexity rank; no model metric used",
            }
        )

    columns = ("linear EIT", "truth", "direct trunk", "raw topology", "routed output", "true inward region", "routed edit")
    figure, axes = plt.subplots(len(rows), len(columns), figsize=(15.2, 2.35 * len(rows)), squeeze=False)
    for row_index, case in enumerate(rows):
        linear = np.asarray(case["linear"])
        scale = max(float(np.percentile(np.abs(linear), 99)), 1e-6)
        direct_fg = np.asarray(case["direct"]) != 0
        routed_fg = np.asarray(case["routed"]) != 0
        edit = direct_fg.astype(np.int8) - routed_fg.astype(np.int8)
        panels = (
            (linear, "coolwarm", -scale, scale),
            (case["truth"], "viridis", 0, 2),
            (case["direct"], "viridis", 0, 2),
            (case["topology"], "viridis", 0, 2),
            (case["routed"], "viridis", 0, 2),
            (case["cutout"], "magma", 0, 1),
            (edit, "bwr", -1, 1),
        )
        for column, (image, cmap, vmin, vmax) in enumerate(panels):
            axes[row_index, column].imshow(image, cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest")
            axes[row_index, column].set_axis_off()
            if row_index == 0:
                axes[row_index, column].set_title(columns[column], fontsize=10)
        enabled = float(case["gate"]) >= threshold
        axes[row_index, 0].set_ylabel(
            f"{case['id']}\ngate={float(case['gate']):.3f}\nroute={'on' if enabled else 'off'}",
            rotation=0,
            ha="right",
            va="center",
            fontsize=8,
        )
    figure.suptitle(
        f"Geometry-selected independent/public cases, seed 20260911 (route threshold={threshold:g})\n"
        "Edit map: red = inward foreground removal, blue = addition",
        fontsize=14,
    )
    figure.tight_layout()
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(output, dpi=240)
    plt.close(figure)
    metadata = {
        "route_threshold": threshold,
        "selection_policy": "geometry and frozen input-derived gate only; no reconstruction metric used",
        "cases": [
            {
                "id": str(case["id"]),
                "gate": float(case["gate"]),
                "route_enabled": bool(float(case["gate"]) >= threshold),
                "selection": str(case["selection"]),
            }
            for case in rows
        ],
    }
    output.with_suffix(".json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(metadata, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
