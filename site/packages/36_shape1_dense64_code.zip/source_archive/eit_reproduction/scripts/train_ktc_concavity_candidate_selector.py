"""Learn when and how to carve an inward EIT boundary.

The stable reconstruction is not replaced.  It is treated as an abstaining
baseline.  Explicit path-conditioned graph-cut candidates describe possible
inward bays, while a small candidate network predicts geometric benefit and
destructive-removal risk.  Synthetic training labels supervise the selector;
synthetic validation freezes an abstention policy; synthetic test labels and
all public KTC2023 labels are used only for final evaluation.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy import ndimage as ndi
from scipy.ndimage import zoom
from torch.utils.data import DataLoader, Dataset

from evaluate_ktc_bank_guarded_wide_cutout import (
    CORE_FAMILY_CODES,
    core_metrics,
    infer_path_prediction,
    load_action_model,
    load_competitive_model,
)
from evaluate_ktc_candidate_opening_hybrid import infer_pair
from fuse_ktc_joint_shape_models import blend, load_model
from optimize_ktc_path_conditioned_concavity import (
    CANDIDATE_NAMES,
    GRAPH_SPECS,
    PUBLIC_INWARD_IDS,
    graph_cut_candidates,
    infer_split,
)
from physics_gate_ktc_cutouts import candidate_geometry_risks, candidate_physics, gather_candidates
from prepare_ktc_deep_concavity_stress import FAMILIES
from train_ktc_candidate_opening_refiner import paired_bootstrap
from train_ktc_competitive_boolean_network import infer_real_fields
from train_ktc_concavity_network import InputAdapter, aggregate_rows, confusion_metrics
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_highres_refiner import (
    load_coarse_ensemble,
    load_dip_four_case_predictions,
    load_official_four_case_truths,
)
from train_ktc_implicit_boolean_network import (
    prepare_structural_arrays,
    standard_metrics,
    stress_metrics,
)


PATCH_SIZE = 32
MAP_CHANNELS = 8
SCALAR_FEATURES = 32


@dataclass(frozen=True)
class PhysicsEvidence:
    residuals: np.ndarray
    changes: np.ndarray
    fold_residuals: np.ndarray


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    parser.add_argument(
        "--competitive-checkpoint", type=Path,
        default=root / "outputs" / "ktc_competitive_boolean_v2_seed20260820" / "competitive_boolean_best.pt",
    )
    parser.add_argument(
        "--coarse-checkpoint", nargs="+", type=Path,
        default=[
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "boundary_best.pt",
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "indent_best.pt",
            root / "outputs" / "ktc_concavity_voltage_seed20260819" / "voltage_best.pt",
        ],
    )
    parser.add_argument("--coarse-weights", nargs="+", type=float, default=[0.30, 0.40, 0.30])
    parser.add_argument("--action-checkpoint", type=Path, default=Path("E:/Codex/ktc_candidate_opening_seed20260820/best.pt"))
    parser.add_argument("--path-summary", type=Path, default=Path("E:/Codex/ktc_candidate_hybrid_seed20260820/summary.json"))
    parser.add_argument("--conservative", type=Path, default=Path("E:/Codex/ktc_joint_shape_pretrained_seed20260820/best.pt"))
    parser.add_argument("--aggressive", type=Path, default=Path("E:/Codex/ktc_joint_shape_network_seed20260820/best.pt"))
    parser.add_argument(
        "--output-dir", type=Path,
        default=root / "outputs" / "ktc_physics_consistent_concavity_selector_seed20260820",
    )
    parser.add_argument(
        "--selector-checkpoint", type=Path,
        default=root / "outputs" / "ktc_learned_concavity_selector_seed20260820" / "selector_best.pt",
    )
    parser.add_argument("--base-train-limit", type=int, default=1200)
    parser.add_argument("--batch-size", type=int, default=192)
    parser.add_argument("--inference-batch-size", type=int, default=48)
    parser.add_argument("--epochs", type=int, default=28)
    parser.add_argument("--learning-rate", type=float, default=8e-4)
    parser.add_argument("--weight-decay", type=float, default=2e-4)
    parser.add_argument("--patience", type=int, default=7)
    parser.add_argument("--bootstrap-samples", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260820)
    parser.add_argument("--no-cache", action="store_true")
    parser.add_argument("--retrain-selector", action="store_true")
    return parser.parse_args()


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    keys = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def case_iou(truths: np.ndarray, predictions: np.ndarray) -> np.ndarray:
    truth = truths != 0
    predicted = predictions != 0
    intersection = np.logical_and(truth, predicted).reshape(len(truth), -1).sum(axis=1)
    union = np.logical_or(truth, predicted).reshape(len(truth), -1).sum(axis=1)
    return intersection / np.maximum(union, 1)


def candidate_targets(
    source: str,
    archive: np.lib.npyio.NpzFile,
    indices: np.ndarray,
    baseline: np.ndarray,
    candidates: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, dict[str, np.ndarray]]:
    """Return candidate utility and destructive-risk labels without test leakage."""
    truths = archive["labels"][indices]
    base_iou = case_iou(truths, baseline)
    utility = np.zeros(candidates.shape[:2], dtype=np.float32)
    harm = np.zeros_like(utility)
    details: dict[str, np.ndarray] = {
        "iou_delta": np.zeros_like(utility),
        "bank_delta": np.zeros_like(utility),
        "open_deep_delta": np.zeros_like(utility),
        "joint_delta": np.zeros_like(utility),
    }
    if source == "stress":
        _, _, baseline_rows = stress_metrics(
            truths, baseline, archive["cutout_masks"][indices],
            archive["cutout_depth_weights"][indices], archive["family_codes"][indices],
        )
        for candidate_index, prediction in enumerate(candidates):
            _, _, rows = stress_metrics(
                truths, prediction, archive["cutout_masks"][indices],
                archive["cutout_depth_weights"][indices], archive["family_codes"][indices],
            )
            for sample_index, (before, after) in enumerate(zip(baseline_rows, rows)):
                iou_delta = float(after["foreground_iou"] - before["foreground_iou"])
                bank_delta = float(after["bank_retention"] - before["bank_retention"])
                open_delta = float(after["open_deep_cutout_recovery"] - before["open_deep_cutout_recovery"])
                joint_delta = float(after["topology_structural_joint"] - before["topology_structural_joint"])
                details["iou_delta"][candidate_index, sample_index] = iou_delta
                details["bank_delta"][candidate_index, sample_index] = bank_delta
                details["open_deep_delta"][candidate_index, sample_index] = open_delta
                details["joint_delta"][candidate_index, sample_index] = joint_delta
                utility[candidate_index, sample_index] = (
                    0.30 * iou_delta + 0.30 * open_delta + 0.20 * bank_delta + 0.20 * joint_delta
                )
                harm[candidate_index, sample_index] = float(iou_delta < -0.015 or bank_delta < -0.030)
    else:
        truth_foreground = truths != 0
        baseline_foreground = baseline != 0
        indentation = archive["indentation_masks"][indices] != 0
        base_notch = np.logical_and(baseline == 0, indentation).reshape(len(indices), -1).sum(axis=1)
        notch_area = np.maximum(indentation.reshape(len(indices), -1).sum(axis=1), 1)
        base_notch = base_notch / notch_area
        for candidate_index, prediction in enumerate(candidates):
            iou_delta = case_iou(truths, prediction) - base_iou
            candidate_notch = np.logical_and(prediction == 0, indentation).reshape(len(indices), -1).sum(axis=1)
            notch_delta = candidate_notch / notch_area - base_notch
            removed = baseline_foreground & (prediction == 0)
            wrong = np.logical_and(removed, truth_foreground).reshape(len(indices), -1).sum(axis=1)
            truth_area = np.maximum(truth_foreground.reshape(len(indices), -1).sum(axis=1), 1)
            wrong_fraction = wrong / truth_area
            values = 0.75 * iou_delta + 0.25 * notch_delta - 0.35 * wrong_fraction
            utility[candidate_index] = values.astype(np.float32)
            harm[candidate_index] = np.logical_or(iou_delta < -0.010, wrong_fraction > 0.025)
            details["iou_delta"][candidate_index] = iou_delta.astype(np.float32)
    return utility, harm, details


def normalized_linear(images: np.ndarray) -> np.ndarray:
    output = images.astype(np.float32).copy()
    flat = output.reshape(len(output), -1)
    mean = flat.mean(axis=1)[:, None, None]
    scale = flat.std(axis=1)[:, None, None]
    return np.clip((output - mean) / np.maximum(scale, 1e-5), -4.0, 4.0) / 4.0


def exterior_background(foreground: np.ndarray) -> np.ndarray:
    components, _ = ndi.label(~foreground, structure=np.ones((3, 3), dtype=np.uint8))
    border = np.unique(np.concatenate((components[0], components[-1], components[:, 0], components[:, -1])))
    return np.isin(components, border[border != 0])


def scalar_features(
    baseline: np.ndarray,
    candidates: np.ndarray,
    fields: dict[str, np.ndarray],
    images: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    count, samples = candidates.shape[:2]
    features = np.zeros((count, samples, SCALAR_FEATURES), dtype=np.float32)
    centers = np.zeros((count, samples, 2), dtype=np.int16)
    component_removal, new_holes = candidate_geometry_risks(baseline, candidates)
    linear = normalized_linear(images)
    height, width = baseline.shape[1:]
    yy, xx = np.indices((height, width))
    for candidate_index in range(count):
        spec = GRAPH_SPECS[candidate_index % len(GRAPH_SPECS)]
        family = candidate_index // len(GRAPH_SPECS)
        for sample_index in range(samples):
            base_foreground = baseline[sample_index] != 0
            candidate_foreground = candidates[candidate_index, sample_index] != 0
            removed = base_foreground & ~candidate_foreground
            coordinates = np.argwhere(removed)
            if len(coordinates):
                cy, cx = np.rint(coordinates.mean(axis=0)).astype(int)
            else:
                base_coordinates = np.argwhere(base_foreground)
                cy, cx = (
                    np.rint(base_coordinates.mean(axis=0)).astype(int)
                    if len(base_coordinates) else np.asarray((height // 2, width // 2))
                )
            centers[candidate_index, sample_index] = (cy, cx)
            cut = fields["cutout_proposal"][sample_index, 0][removed]
            bank = fields["bank"][sample_index, 0][removed]
            image_values = linear[sample_index][removed]
            depth_map = ndi.distance_transform_edt(base_foreground)
            depth = depth_map[removed]
            removed_components = ndi.label(removed, structure=np.ones((3, 3), dtype=np.uint8))[1]
            outside = exterior_background(candidate_foreground)
            exterior_removed = float((outside & removed).sum()) / max(1, int(removed.sum()))

            def stats(values: np.ndarray) -> tuple[float, float, float, float]:
                if not len(values):
                    return 0.0, 0.0, 0.0, 0.0
                return (
                    float(values.mean()), float(np.quantile(values, 0.50)),
                    float(np.quantile(values, 0.90)), float(values.max()),
                )

            cut_stats = stats(cut)
            bank_stats = stats(bank)
            image_stats = stats(np.abs(image_values))
            depth_stats = stats(depth / max(height, width))
            features[candidate_index, sample_index] = np.asarray((
                float(removed.sum()) / max(1, int(base_foreground.sum())),
                float(component_removal[candidate_index + 1, sample_index]),
                float(new_holes[candidate_index + 1, sample_index]) / 20.0,
                *cut_stats,
                *bank_stats,
                image_stats[0], image_stats[1], image_stats[2],
                float(image_values.mean()) if len(image_values) else 0.0,
                float(image_values.std()) if len(image_values) else 0.0,
                depth_stats[0], depth_stats[3],
                float(removed_components) / 4.0,
                exterior_removed,
                float(base_foreground.mean()), float(candidate_foreground.mean()),
                float(cy) / max(1, height - 1), float(cx) / max(1, width - 1),
                float(family == 0), float(family == 1), float(family == 2),
                float(spec.radius) / 6.0, float(spec.cutout_bias),
                float(spec.bank_weight) / 1.25, float(spec.smoothness) / 0.36,
                float(spec.hard_bank),
            ), dtype=np.float32)
    return features, centers, component_removal[1:].astype(np.float32), new_holes[1:].astype(np.float32)


def crop(array: np.ndarray, center: tuple[int, int], size: int = PATCH_SIZE) -> np.ndarray:
    radius = size // 2
    padded = np.pad(array, ((radius, radius), (radius, radius)), mode="constant")
    cy, cx = center
    return padded[cy:cy + size, cx:cx + size]


class CandidateDataset(Dataset):
    def __init__(
        self,
        baseline: np.ndarray,
        candidates: np.ndarray,
        fields: dict[str, np.ndarray],
        images: np.ndarray,
        scalar: np.ndarray,
        centers: np.ndarray,
        utility: np.ndarray | None = None,
        harm: np.ndarray | None = None,
        source_weight: float = 1.0,
    ) -> None:
        self.baseline = baseline
        self.candidates = candidates
        self.cutout = fields["cutout_proposal"][:, 0].astype(np.float32)
        self.bank = fields["bank"][:, 0].astype(np.float32)
        self.support = fields["support"][:, 0].astype(np.float32)
        self.linear = normalized_linear(images)
        self.scalar = scalar
        self.centers = centers
        self.utility = utility
        self.harm = harm
        self.source_weight = source_weight
        self.samples = len(baseline)
        self.distance = np.stack([
            ndi.distance_transform_edt(item != 0) / max(item.shape) for item in baseline
        ]).astype(np.float32)

    def __len__(self) -> int:
        return self.candidates.shape[0] * self.samples

    def __getitem__(self, index: int):
        candidate_index, sample_index = divmod(index, self.samples)
        baseline = self.baseline[sample_index] != 0
        candidate = self.candidates[candidate_index, sample_index] != 0
        removed = baseline & ~candidate
        center = tuple(int(value) for value in self.centers[candidate_index, sample_index])
        channels = (
            self.linear[sample_index], baseline.astype(np.float32), candidate.astype(np.float32),
            removed.astype(np.float32), self.cutout[sample_index], self.bank[sample_index],
            self.distance[sample_index], self.support[sample_index],
        )
        patch = np.stack([crop(channel, center) for channel in channels]).astype(np.float32)
        scalar = self.scalar[candidate_index, sample_index]
        if self.utility is None:
            return patch, scalar, candidate_index, sample_index
        return (
            patch, scalar,
            np.float32(self.utility[candidate_index, sample_index]),
            np.float32(self.harm[candidate_index, sample_index]),
            np.float32(self.source_weight),
        )


class ResidualUnit(nn.Module):
    def __init__(self, channels: int) -> None:
        super().__init__()
        self.layers = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1, bias=False),
            nn.GroupNorm(4, channels), nn.SiLU(),
            nn.Conv2d(channels, channels, 3, padding=1, bias=False),
            nn.GroupNorm(4, channels),
        )

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        return F.silu(inputs + self.layers(inputs))


class ConcavityCandidateSelector(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.image = nn.Sequential(
            nn.Conv2d(MAP_CHANNELS, 24, 5, padding=2, bias=False),
            nn.GroupNorm(4, 24), nn.SiLU(), ResidualUnit(24),
            nn.Conv2d(24, 48, 3, stride=2, padding=1, bias=False),
            nn.GroupNorm(6, 48), nn.SiLU(), ResidualUnit(48),
            nn.Conv2d(48, 80, 3, stride=2, padding=1, bias=False),
            nn.GroupNorm(8, 80), nn.SiLU(), ResidualUnit(80),
            nn.AdaptiveAvgPool2d(1), nn.Flatten(),
        )
        self.head = nn.Sequential(
            nn.Linear(80 + SCALAR_FEATURES, 128), nn.SiLU(), nn.Dropout(0.12),
            nn.Linear(128, 64), nn.SiLU(),
        )
        self.utility = nn.Linear(64, 1)
        self.harm = nn.Linear(64, 1)

    def forward(self, patch: torch.Tensor, scalar: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        hidden = self.head(torch.cat((self.image(patch), scalar), dim=1))
        return self.utility(hidden).squeeze(1), self.harm(hidden).squeeze(1)


@torch.no_grad()
def predict_candidates(
    model: ConcavityCandidateSelector,
    dataset: CandidateDataset,
    scalar_mean: np.ndarray,
    scalar_scale: np.ndarray,
    utility_mean: float,
    utility_scale: float,
    device: torch.device,
    batch_size: int,
) -> tuple[np.ndarray, np.ndarray]:
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False, num_workers=0, pin_memory=device.type == "cuda")
    predicted_utility: list[np.ndarray] = []
    predicted_harm: list[np.ndarray] = []
    mean = torch.from_numpy(scalar_mean.astype(np.float32)).to(device)
    scale = torch.from_numpy(scalar_scale.astype(np.float32)).to(device)
    model.eval()
    for batch in loader:
        patch, scalar = batch[:2]
        utility, harm = model(patch.to(device), (scalar.to(device) - mean) / scale)
        predicted_utility.append((utility_mean + utility_scale * utility.cpu().numpy()).astype(np.float32))
        predicted_harm.append(torch.sigmoid(harm).cpu().numpy().astype(np.float32))
    shape = dataset.candidates.shape[:2]
    return np.concatenate(predicted_utility).reshape(shape), np.concatenate(predicted_harm).reshape(shape)


def select_candidates(
    predicted_utility: np.ndarray,
    predicted_harm: np.ndarray,
    component_removal: np.ndarray,
    new_holes: np.ndarray,
    policy: dict[str, float],
    physics: PhysicsEvidence,
) -> np.ndarray:
    if bool(policy.get("safe_fallback", False)):
        return np.zeros(predicted_utility.shape[1], dtype=np.int64)
    score = predicted_utility - float(policy["risk_weight"]) * predicted_harm
    baseline_residual = physics.residuals[0].clip(1e-12)
    physics_gain = 1.0 - physics.residuals[1:] / baseline_residual[None]
    net_physics_gain = physics_gain - float(policy["physics_change_penalty"]) * physics.changes[1:]
    fold_baseline = physics.fold_residuals[0].clip(1e-12)
    fold_gain = 1.0 - physics.fold_residuals[1:] / fold_baseline[None]
    fold_agreement = (
        fold_gain >= float(policy["min_physics_gain"])
    ).mean(axis=2)
    valid = (
        (predicted_harm <= float(policy["max_harm_probability"]))
        & (component_removal <= float(policy["max_component_removal"]))
        & (new_holes <= 0.0)
        & (score >= float(policy["score_threshold"]))
        & (physics.changes[1:] > 0.0)
        & (net_physics_gain >= float(policy["min_physics_gain"]))
        & (fold_agreement >= float(policy["min_fold_agreement"]))
    )
    score = np.where(valid, score, -np.inf)
    best = np.argmax(score, axis=0)
    best_score = score[best, np.arange(score.shape[1])]
    return np.where(np.isfinite(best_score), best + 1, 0).astype(np.int64)


def metric_cube(
    source: str,
    archive: np.lib.npyio.NpzFile,
    indices: np.ndarray,
    baseline: np.ndarray,
    candidates: np.ndarray,
) -> dict[str, np.ndarray]:
    all_predictions = np.concatenate((baseline[None], candidates), axis=0)
    rows_by_candidate: list[list[dict[str, float]]] = []
    if source == "base":
        for prediction in all_predictions:
            rows_by_candidate.append([
                confusion_metrics(truth, estimate, indentation)
                for truth, estimate, indentation in zip(
                    archive["labels"][indices], prediction, archive["indentation_masks"][indices]
                )
            ])
    else:
        for prediction in all_predictions:
            _, _, rows = stress_metrics(
                archive["labels"][indices], prediction, archive["cutout_masks"][indices],
                archive["cutout_depth_weights"][indices], archive["family_codes"][indices],
            )
            rows_by_candidate.append(rows)
    keys = sorted({key for rows in rows_by_candidate for row in rows for key in row if key != "family"})
    return {
        key: np.asarray([[row.get(key, np.nan) for row in rows] for rows in rows_by_candidate], dtype=np.float64)
        for key in keys
    }


def select_metric_summary(
    cube: dict[str, np.ndarray],
    selected: np.ndarray,
    mask: np.ndarray | None = None,
) -> dict[str, float]:
    positions = np.arange(len(selected))
    if mask is not None:
        positions = positions[mask]
    return {
        key: float(np.nanmean(values[selected[positions], positions]))
        for key, values in cube.items()
    }


def evaluate_policy(
    policy: dict[str, float],
    base_metric_cube: dict[str, np.ndarray],
    stress_metric_cube: dict[str, np.ndarray],
    core_mask: np.ndarray,
    base_predictions: tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray],
    stress_predictions: tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray],
    base_physics: PhysicsEvidence,
    stress_physics: PhysicsEvidence,
) -> dict[str, object]:
    base_utility, base_harm, base_removal, base_holes = base_predictions
    stress_utility, stress_harm, stress_removal, stress_holes = stress_predictions
    base_selected = select_candidates(
        base_utility, base_harm, base_removal, base_holes, policy, base_physics,
    )
    stress_selected = select_candidates(
        stress_utility, stress_harm, stress_removal, stress_holes, policy, stress_physics,
    )
    base_metric = select_metric_summary(base_metric_cube, base_selected)
    stress_metric = select_metric_summary(stress_metric_cube, stress_selected, core_mask)
    return {
        **policy,
        "base": base_metric,
        "stress_core": stress_metric,
        "base_changed_cases": int(np.count_nonzero(base_physics.changes[base_selected, np.arange(len(base_selected))])),
        "stress_changed_cases": int(np.count_nonzero(stress_physics.changes[stress_selected, np.arange(len(stress_selected))])),
        "_base_selected": base_selected,
        "_stress_selected": stress_selected,
    }


def tune_policy(
    base: np.lib.npyio.NpzFile,
    stress: np.lib.npyio.NpzFile,
    base_indices: np.ndarray,
    stress_indices: np.ndarray,
    base_path: np.ndarray,
    stress_path: np.ndarray,
    base_candidates: np.ndarray,
    stress_candidates: np.ndarray,
    base_predictions: tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray],
    stress_predictions: tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray],
    base_physics: PhysicsEvidence,
    stress_physics: PhysicsEvidence,
) -> tuple[dict[str, object], list[dict[str, object]]]:
    base_reference = standard_metrics(base["labels"][base_indices], base_path, base["indentation_masks"][base_indices])
    stress_reference, _ = core_metrics(stress, stress_indices, stress_path)
    print("precomputing validation candidate metric cubes", flush=True)
    base_metric_cube = metric_cube("base", base, base_indices, base_path, base_candidates)
    stress_metric_cube = metric_cube("stress", stress, stress_indices, stress_path, stress_candidates)
    core_mask = np.isin(stress["family_codes"][stress_indices], np.asarray(CORE_FAMILY_CODES))
    utility_values = np.concatenate((base_predictions[0].ravel(), stress_predictions[0].ravel()))
    finite = utility_values[np.isfinite(utility_values)]
    thresholds = np.unique(np.concatenate((
        np.asarray((-0.02, -0.01, -0.005, 0.0, 0.003, 0.006, 0.01, 0.02)),
        np.quantile(finite, (0.55, 0.65, 0.75, 0.82, 0.88, 0.93, 0.97)),
    )))
    rows: list[dict[str, object]] = []
    for threshold in thresholds:
        for risk_weight in (0.0, 0.025, 0.05):
            for max_harm in (0.15, 0.25, 0.40):
                for max_removal in (0.08, 0.10, 0.12):
                    for min_gain in (0.00003, 0.0001, 0.0003, 0.001):
                        for fold_agreement in (0.50, 0.75, 1.00):
                            for change_penalty in (0.0, 0.03, 0.10):
                                row = evaluate_policy(
                                    {
                                        "score_threshold": float(threshold),
                                        "risk_weight": risk_weight,
                                        "max_harm_probability": max_harm,
                                        "max_component_removal": max_removal,
                                        "min_physics_gain": min_gain,
                                        "min_fold_agreement": fold_agreement,
                                        "physics_change_penalty": change_penalty,
                                    },
                                    base_metric_cube, stress_metric_cube, core_mask,
                                    base_predictions, stress_predictions,
                                    base_physics, stress_physics,
                                )
                                row["eligible"] = bool(
                                    row["base"]["foreground_iou"] >= base_reference["foreground_iou"] - 0.001
                                    and row["stress_core"]["foreground_iou"] >= stress_reference["foreground_iou"] - 0.003
                                    and row["stress_core"]["bank_retention"] >= stress_reference["bank_retention"] - 0.003
                                    and row["stress_core"]["open_deep_cutout_recovery"]
                                    >= stress_reference["open_deep_cutout_recovery"] + 0.005
                                    and row["stress_core"]["topology_structural_joint"]
                                    >= stress_reference["topology_structural_joint"] + 0.001
                                )
                                row["score"] = float(
                                    0.08 * row["base"]["foreground_iou"]
                                    + 0.12 * row["stress_core"]["foreground_iou"]
                                    + 0.34 * row["stress_core"]["open_deep_cutout_recovery"]
                                    + 0.18 * row["stress_core"]["bank_retention"]
                                    + 0.28 * row["stress_core"]["topology_structural_joint"]
                                )
                                rows.append(row)
    identity = {
        "score_threshold": float("inf"), "risk_weight": 0.0,
        "max_harm_probability": 0.0, "max_component_removal": 0.0,
        "min_physics_gain": float("inf"), "min_fold_agreement": 1.0,
        "physics_change_penalty": 0.0,
        "eligible": True, "safe_fallback": True,
        "base": base_reference, "stress_core": stress_reference,
        "base_changed_cases": 0, "stress_changed_cases": 0,
        "score": float(
            0.08 * base_reference["foreground_iou"] + 0.12 * stress_reference["foreground_iou"]
            + 0.34 * stress_reference["open_deep_cutout_recovery"]
            + 0.18 * stress_reference["bank_retention"]
            + 0.28 * stress_reference["topology_structural_joint"]
        ),
    }
    eligible = [row for row in rows if row["eligible"]]
    selected = max([identity, *eligible], key=lambda row: float(row["score"]))
    selected["safe_fallback"] = bool(selected is identity)
    return selected, rows


def cache_path(output_dir: Path, name: str) -> Path:
    return output_dir / "cache" / f"{name}.npz"


def array_signature(*arrays: np.ndarray) -> str:
    digest = hashlib.sha256()
    for array in arrays:
        contiguous = np.ascontiguousarray(array)
        digest.update(str(contiguous.shape).encode("ascii"))
        digest.update(str(contiguous.dtype).encode("ascii"))
        digest.update(contiguous.view(np.uint8))
    return digest.hexdigest()


def physics_cached(
    name: str,
    output_dir: Path,
    archive: np.lib.npyio.NpzFile,
    baseline: np.ndarray,
    candidates: np.ndarray,
    voltages: np.ndarray,
    no_cache: bool,
) -> PhysicsEvidence:
    path = output_dir / "cache" / f"physics_{name}.npz"
    signature = array_signature(baseline, candidates, voltages)
    if path.exists() and not no_cache:
        cached = np.load(path, allow_pickle=False)
        if str(cached["signature"].item()) == signature:
            print(f"loading cached {name} four-fold physics", flush=True)
            return PhysicsEvidence(cached["residuals"], cached["changes"], cached["fold_residuals"])
    print(f"computing {name} four-fold held-out voltage residuals", flush=True)
    residuals, changes, folds = candidate_physics(
        baseline, candidates, voltages, archive, return_folds=True,
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        path, signature=np.asarray(signature), residuals=residuals,
        changes=changes, fold_residuals=folds,
    )
    return PhysicsEvidence(residuals, changes, folds)


def infer_cached(
    name: str,
    output_dir: Path,
    archive: np.lib.npyio.NpzFile,
    arrays: object,
    indices: np.ndarray,
    models: dict[str, object],
    source: int,
    no_cache: bool,
) -> tuple[np.ndarray, np.ndarray, dict[str, np.ndarray], np.ndarray]:
    path = cache_path(output_dir, name)
    if path.exists() and not no_cache:
        cached = np.load(path, allow_pickle=False)
        if np.array_equal(cached["indices"], indices):
            print(f"loading cached {name} candidates", flush=True)
            fields = {key: cached[key] for key in ("cutout_proposal", "bank", "support")}
            return cached["raw"], cached["path"], fields, cached["candidates"]
    print(f"inferring {name} ({len(indices)} cases)", flush=True)
    raw, baseline, fields, _ = infer_split(
        archive, arrays, indices, models["conservative"], models["aggressive"],
        models["action"], models["feature_mean"], models["feature_scale"],
        models["coarse"], models["competitive"], models["adapter"], models["device"],
        models["batch_size"], models["path_parameters"], source,
    )
    candidates, _ = graph_cut_candidates(raw, baseline, fields)
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez(
        path, indices=indices, raw=raw, path=baseline, candidates=candidates,
        cutout_proposal=fields["cutout_proposal"], bank=fields["bank"], support=fields["support"],
    )
    return raw, baseline, fields, candidates


def build_candidate_data(
    source: str,
    archive: np.lib.npyio.NpzFile,
    indices: np.ndarray,
    baseline: np.ndarray,
    candidates: np.ndarray,
    fields: dict[str, np.ndarray],
    with_targets: bool,
) -> tuple[CandidateDataset, tuple[np.ndarray, np.ndarray] | None, np.ndarray, np.ndarray]:
    scalar, centers, removal, holes = scalar_features(
        baseline, candidates, fields, archive["linear_images"][indices],
    )
    targets = candidate_targets(source, archive, indices, baseline, candidates)[:2] if with_targets else None
    dataset = CandidateDataset(
        baseline, candidates, fields, archive["linear_images"][indices], scalar, centers,
        None if targets is None else targets[0], None if targets is None else targets[1],
        1.45 if source == "stress" else 1.0,
    )
    return dataset, targets, removal, holes


def concatenate_datasets(first: CandidateDataset, second: CandidateDataset) -> torch.utils.data.ConcatDataset:
    return torch.utils.data.ConcatDataset((first, second))


def train_selector(
    train_sets: tuple[CandidateDataset, CandidateDataset],
    validation_sets: tuple[CandidateDataset, CandidateDataset],
    args: argparse.Namespace,
    device: torch.device,
) -> tuple[ConcavityCandidateSelector, dict[str, object], list[dict[str, float]]]:
    checkpoint = args.output_dir.resolve() / "selector_best.pt"
    reusable = checkpoint if checkpoint.exists() else args.selector_checkpoint.resolve()
    if reusable.exists() and not args.retrain_selector:
        state = torch.load(reusable, map_location=device, weights_only=False)
        model = ConcavityCandidateSelector().to(device)
        model.load_state_dict(state["model"])
        print(f"reusing selector checkpoint {reusable} from epoch {state['epoch']}", flush=True)
        if not checkpoint.exists():
            torch.save(state, checkpoint)
        return model, state, []
    scalar_values = np.concatenate((train_sets[0].scalar.reshape(-1, SCALAR_FEATURES), train_sets[1].scalar.reshape(-1, SCALAR_FEATURES)))
    scalar_mean = scalar_values.mean(axis=0).astype(np.float32)
    scalar_scale = scalar_values.std(axis=0).astype(np.float32)
    scalar_scale[scalar_scale < 1e-5] = 1.0
    utility_values = np.concatenate((train_sets[0].utility.ravel(), train_sets[1].utility.ravel()))
    utility_mean = float(utility_values.mean())
    utility_scale = max(float(utility_values.std()), 1e-3)
    mean_tensor = torch.from_numpy(scalar_mean).to(device)
    scale_tensor = torch.from_numpy(scalar_scale).to(device)
    model = ConcavityCandidateSelector().to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    train_loader = DataLoader(
        concatenate_datasets(*train_sets), batch_size=args.batch_size, shuffle=True,
        num_workers=0, pin_memory=device.type == "cuda",
    )
    validation_loader = DataLoader(
        concatenate_datasets(*validation_sets), batch_size=args.batch_size * 2, shuffle=False,
        num_workers=0, pin_memory=device.type == "cuda",
    )
    history: list[dict[str, float]] = []
    best_loss = math.inf
    stale = 0
    for epoch in range(1, args.epochs + 1):
        model.train()
        losses: list[float] = []
        for patch, scalar, utility, harm, weight in train_loader:
            patch, scalar = patch.to(device), scalar.to(device)
            utility, harm, weight = utility.to(device), harm.to(device), weight.to(device)
            optimizer.zero_grad(set_to_none=True)
            predicted_utility, predicted_harm = model(patch, (scalar - mean_tensor) / scale_tensor)
            target = (utility - utility_mean) / utility_scale
            regression = F.smooth_l1_loss(predicted_utility, target, beta=0.35, reduction="none")
            risk = F.binary_cross_entropy_with_logits(predicted_harm, harm, reduction="none")
            loss = (weight * (regression + 0.55 * risk)).mean()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            losses.append(float(loss.detach()))
        scheduler.step()
        model.eval()
        validation_losses: list[float] = []
        with torch.no_grad():
            for patch, scalar, utility, harm, weight in validation_loader:
                patch, scalar = patch.to(device), scalar.to(device)
                utility, harm, weight = utility.to(device), harm.to(device), weight.to(device)
                predicted_utility, predicted_harm = model(patch, (scalar - mean_tensor) / scale_tensor)
                target = (utility - utility_mean) / utility_scale
                regression = F.smooth_l1_loss(predicted_utility, target, beta=0.35, reduction="none")
                risk = F.binary_cross_entropy_with_logits(predicted_harm, harm, reduction="none")
                validation_losses.extend((weight * (regression + 0.55 * risk)).cpu().numpy().tolist())
        row = {
            "epoch": float(epoch), "train_loss": float(np.mean(losses)),
            "validation_loss": float(np.mean(validation_losses)),
        }
        history.append(row)
        print(
            f"epoch {epoch:02d}: train={row['train_loss']:.4f} validation={row['validation_loss']:.4f}",
            flush=True,
        )
        if row["validation_loss"] < best_loss - 1e-4:
            best_loss = row["validation_loss"]
            stale = 0
            torch.save({
                "model": model.state_dict(), "scalar_mean": scalar_mean, "scalar_scale": scalar_scale,
                "utility_mean": utility_mean, "utility_scale": utility_scale,
                "epoch": epoch, "seed": args.seed,
            }, checkpoint)
        else:
            stale += 1
        if epoch >= 10 and stale >= args.patience:
            break
    state = torch.load(checkpoint, map_location=device, weights_only=False)
    model.load_state_dict(state["model"])
    return model, state, history


def score_dataset(
    model: ConcavityCandidateSelector,
    dataset: CandidateDataset,
    state: dict[str, object],
    device: torch.device,
    batch_size: int,
) -> tuple[np.ndarray, np.ndarray]:
    return predict_candidates(
        model, dataset, np.asarray(state["scalar_mean"]), np.asarray(state["scalar_scale"]),
        float(state["utility_mean"]), float(state["utility_scale"]), device, batch_size,
    )


def save_improvement_montage(
    path: Path,
    stress: np.lib.npyio.NpzFile,
    indices: np.ndarray,
    raw: np.ndarray,
    baseline: np.ndarray,
    result: np.ndarray,
    selected: np.ndarray,
) -> None:
    _, _, before_rows = stress_metrics(
        stress["labels"][indices], baseline, stress["cutout_masks"][indices],
        stress["cutout_depth_weights"][indices], stress["family_codes"][indices],
    )
    _, _, after_rows = stress_metrics(
        stress["labels"][indices], result, stress["cutout_masks"][indices],
        stress["cutout_depth_weights"][indices], stress["family_codes"][indices],
    )
    score = np.asarray([
        after["topology_structural_joint"] - before["topology_structural_joint"]
        for before, after in zip(before_rows, after_rows)
    ])
    changed = np.flatnonzero(selected != 0)
    if len(changed):
        focus = changed[np.argsort(score[changed])[-min(8, len(changed)):][::-1]]
    else:
        focus = np.argsort(score)[-8:][::-1]
    figure, axes = plt.subplots(len(focus), 6, figsize=(14.0, 2.15 * len(focus)), squeeze=False)
    for row, index in enumerate(focus):
        items = (
            (stress["labels"][indices][index], "truth", "viridis", 0, 2),
            (stress["linear_images"][indices][index], "linear EIT", "coolwarm", None, None),
            (raw[index], "stable raw", "viridis", 0, 2),
            (baseline[index], "guarded path", "viridis", 0, 2),
            (result[index], f"learned selector\nchoice={selected[index]}", "viridis", 0, 2),
            ((baseline[index] != result[index]).astype(np.uint8), "new inward cut", "magma", 0, 1),
        )
        for column, (image, title, cmap, vmin, vmax) in enumerate(items):
            axes[row, column].imshow(image, cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest")
            axes[row, column].set_axis_off()
            if row == 0:
                axes[row, column].set_title(title, fontsize=9)
        family = FAMILIES[int(stress["family_codes"][indices][index])]
        axes[row, 0].set_ylabel(f"{family}\nindex={indices[index]}\nDelta={score[index]:+.3f}", fontsize=8)
    figure.suptitle("Largest frozen-test improvements for inward EIT boundaries", y=0.997)
    figure.tight_layout(rect=(0, 0, 1, 0.985))
    figure.savefig(path, dpi=190)
    plt.close(figure)


def save_public_montage(
    path: Path,
    truths: np.ndarray,
    ids: np.ndarray,
    raw: np.ndarray,
    baseline: np.ndarray,
    result: np.ndarray,
    selected: np.ndarray,
) -> None:
    focus = [index for index, case_id in enumerate(ids) if str(case_id) in PUBLIC_INWARD_IDS]
    figure, axes = plt.subplots(len(focus), 5, figsize=(12.2, 2.28 * len(focus)), squeeze=False)
    for row, index in enumerate(focus):
        items = (
            (truths[index], "truth", "viridis", 0, 2),
            (raw[index], "stable raw", "viridis", 0, 2),
            (baseline[index], "guarded path", "viridis", 0, 2),
            (result[index], f"learned selector\nchoice={selected[index]}", "viridis", 0, 2),
            ((baseline[index] != result[index]).astype(np.uint8), "new inward cut", "magma", 0, 1),
        )
        for column, (image, title, cmap, vmin, vmax) in enumerate(items):
            axes[row, column].imshow(image, cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest")
            axes[row, column].set_axis_off()
            if row == 0:
                axes[row, column].set_title(title, fontsize=9)
        axes[row, 0].set_ylabel(str(ids[index]), fontsize=9)
    figure.suptitle("All public KTC2023 inward-notch cases (policy frozen on synthetic validation)", y=0.997)
    figure.tight_layout(rect=(0, 0, 1, 0.985))
    figure.savefig(path, dpi=185)
    plt.close(figure)


def changed_case_count(baseline: np.ndarray, result: np.ndarray) -> int:
    return int(np.count_nonzero(np.any(baseline != result, axis=(-2, -1))))


def oracle_iou_selection(
    truths: np.ndarray,
    baseline: np.ndarray,
    candidates: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Evaluation-only upper bound; never use these choices to tune a policy."""
    all_predictions = np.concatenate((baseline[None], candidates), axis=0)
    truth_foreground = truths != 0
    predicted_foreground = all_predictions != 0
    intersection = np.logical_and(
        predicted_foreground, truth_foreground[None],
    ).reshape(len(all_predictions), len(truths), -1).sum(axis=2)
    union = np.logical_or(
        predicted_foreground, truth_foreground[None],
    ).reshape(len(all_predictions), len(truths), -1).sum(axis=2)
    iou = intersection / np.maximum(union, 1)
    selected = np.argmax(iou, axis=0).astype(np.int64)
    result = all_predictions[selected, np.arange(len(selected))]
    return selected, result, iou


def save_public_oracle_montage(
    path: Path,
    truths: np.ndarray,
    ids: np.ndarray,
    baseline: np.ndarray,
    oracle: np.ndarray,
    selected: np.ndarray,
) -> None:
    focus = [index for index, case_id in enumerate(ids) if str(case_id) in PUBLIC_INWARD_IDS]
    figure, axes = plt.subplots(len(focus), 4, figsize=(10.0, 2.3 * len(focus)), squeeze=False)
    for row, index in enumerate(focus):
        removed = np.logical_and(baseline[index] != 0, oracle[index] == 0)
        for column, (image, title, cmap, vmax) in enumerate((
            (truths[index], "truth", "viridis", 2),
            (baseline[index], "guarded path", "viridis", 2),
            (oracle[index], f"candidate oracle\nchoice={selected[index]}", "viridis", 2),
            (removed, "available inward cut", "magma", 1),
        )):
            axes[row, column].imshow(image, cmap=cmap, vmin=0, vmax=vmax, interpolation="nearest")
            axes[row, column].set_axis_off()
            if row == 0:
                axes[row, column].set_title(title, fontsize=9)
        axes[row, 0].set_ylabel(str(ids[index]), fontsize=9)
    figure.suptitle("Public inward cases: evaluation-only candidate representation upper bound", y=0.997)
    figure.tight_layout(rect=(0, 0, 1, 0.985))
    figure.savefig(path, dpi=190)
    plt.close(figure)


def save_official_four_montage(
    path: Path,
    truths: np.ndarray,
    ids: np.ndarray,
    dip: np.ndarray,
    raw: np.ndarray,
    baseline: np.ndarray,
    result: np.ndarray,
    selected: np.ndarray,
    metric_rows: list[dict[str, object]],
) -> None:
    lookup = {(str(row["id"]), str(row["method"])): row for row in metric_rows}
    figure, axes = plt.subplots(len(ids), 6, figsize=(15.4, 2.75 * len(ids)), squeeze=False)
    for row, case_id in enumerate(ids):
        method_items = (
            (truths[row], "truth", None),
            (dip[row], "original DIP+TV", "original_dip"),
            (raw[row], "stable network", "stable_raw"),
            (baseline[row], "guarded path", "guarded_path"),
            (result[row], f"physics selector\nchoice={selected[row]}", "physics_selector"),
            (np.logical_and(baseline[row] != 0, result[row] == 0), "new inward cut", None),
        )
        for column, (image, title, method) in enumerate(method_items):
            cmap = "magma" if column == 5 else "viridis"
            axes[row, column].imshow(image, cmap=cmap, vmin=0, vmax=1 if column == 5 else 2, interpolation="nearest")
            if method is not None:
                metric = lookup[(str(case_id), method)]
                title += f"\nIoU={float(metric['foreground_iou']):.3f}, SSIM={float(metric['ktc_ssim']):.3f}"
            axes[row, column].set_title(title, fontsize=8)
            axes[row, column].set_axis_off()
        axes[row, 0].set_ylabel(str(case_id), fontsize=9)
    figure.suptitle("Original four KTC2023 cases with the inward-boundary method", y=0.997)
    figure.tight_layout(rect=(0, 0, 1, 0.985))
    figure.savefig(path, dpi=190)
    plt.close(figure)


def save_data4_focus(
    path: Path,
    truth: np.ndarray,
    dip: np.ndarray,
    raw: np.ndarray,
    baseline: np.ndarray,
    result: np.ndarray,
) -> None:
    foreground = truth != 0
    yy, xx = np.nonzero(foreground)
    margin = 14
    y0, y1 = max(0, int(yy.min()) - margin), min(truth.shape[0], int(yy.max()) + margin + 1)
    x0, x1 = max(0, int(xx.min()) - margin), min(truth.shape[1], int(xx.max()) + margin + 1)
    removed = np.logical_and(baseline != 0, result == 0)
    images = (truth, dip, raw, baseline, result, removed)
    titles = ("truth", "original DIP+TV", "stable network", "guarded path", "new method", "new inward cut")
    figure, axes = plt.subplots(1, 6, figsize=(16.2, 3.1), squeeze=False)
    for column, (image, title) in enumerate(zip(images, titles)):
        axes[0, column].imshow(
            image[y0:y1, x0:x1], cmap="magma" if column == 5 else "viridis",
            vmin=0, vmax=1 if column == 5 else 2, interpolation="nearest",
        )
        axes[0, column].set_title(title, fontsize=10)
        axes[0, column].set_axis_off()
    figure.suptitle("data4: enlarged inward-notch region", y=0.98)
    figure.tight_layout(rect=(0, 0, 1, 0.93))
    figure.savefig(path, dpi=220)
    plt.close(figure)


def json_ready(value: object) -> object:
    if isinstance(value, dict):
        return {key: json_ready(item) for key, item in value.items() if not key.startswith("_")}
    if isinstance(value, (list, tuple)):
        return [json_ready(item) for item in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, float) and not math.isfinite(value):
        return "inf" if value > 0 else "-inf"
    return value


def main() -> None:
    args = parse_args()
    args.output_dir = args.output_dir.resolve()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    base = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    base_arrays = prepare_structural_arrays(base, "base nonlinear CEM")
    stress_arrays = prepare_structural_arrays(stress, "deep-concavity stress")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"device={device}", flush=True)
    adapter = InputAdapter(base["fov_mask"]).to(device)
    conservative = load_model(args.conservative, device)
    aggressive = load_model(args.aggressive, device)
    action, feature_mean, feature_scale = load_action_model(args.action_checkpoint, device)
    coarse, _, _ = load_coarse_ensemble(args.coarse_checkpoint, args.coarse_weights, device)
    competitive = load_competitive_model(args.competitive_checkpoint, device)
    models: dict[str, object] = {
        "conservative": conservative, "aggressive": aggressive, "action": action,
        "feature_mean": feature_mean, "feature_scale": feature_scale,
        "coarse": coarse, "competitive": competitive, "adapter": adapter, "device": device,
        "batch_size": args.inference_batch_size,
        "path_parameters": json.loads(args.path_summary.resolve().read_text(encoding="utf-8"))["selected"],
    }

    rng = np.random.default_rng(args.seed)
    base_train_all = np.asarray(base["train_indices"], dtype=np.int64)
    base_train = np.sort(rng.choice(base_train_all, size=min(args.base_train_limit, len(base_train_all)), replace=False))
    stress_train = np.asarray(stress["train_indices"], dtype=np.int64)
    base_validation = np.asarray(base["validation_indices"], dtype=np.int64)
    stress_validation = np.asarray(stress["validation_indices"], dtype=np.int64)

    split_inputs: dict[str, tuple[np.ndarray, np.ndarray, dict[str, np.ndarray], np.ndarray]] = {}
    for name, archive, arrays, indices, source in (
        ("base_train", base, base_arrays, base_train, 0),
        ("stress_train", stress, stress_arrays, stress_train, 1),
        ("base_validation", base, base_arrays, base_validation, 0),
        ("stress_validation", stress, stress_arrays, stress_validation, 1),
    ):
        split_inputs[name] = infer_cached(
            name, args.output_dir, archive, arrays, indices, models, source, args.no_cache,
        )

    data: dict[str, tuple[CandidateDataset, tuple[np.ndarray, np.ndarray] | None, np.ndarray, np.ndarray]] = {}
    for name, archive, indices, source in (
        ("base_train", base, base_train, "base"),
        ("stress_train", stress, stress_train, "stress"),
        ("base_validation", base, base_validation, "base"),
        ("stress_validation", stress, stress_validation, "stress"),
    ):
        _, baseline, fields, candidates = split_inputs[name]
        print(f"building {name} candidate features and targets", flush=True)
        data[name] = build_candidate_data(source, archive, indices, baseline, candidates, fields, True)

    model, state, history = train_selector(
        (data["base_train"][0], data["stress_train"][0]),
        (data["base_validation"][0], data["stress_validation"][0]),
        args, device,
    )
    validation_predictions: dict[str, tuple[np.ndarray, np.ndarray]] = {}
    for name in ("base_validation", "stress_validation"):
        validation_predictions[name] = score_dataset(
            model, data[name][0], state, device, args.batch_size * 2,
        )
    base_path = split_inputs["base_validation"][1]
    stress_path = split_inputs["stress_validation"][1]
    base_candidates = split_inputs["base_validation"][3]
    stress_candidates = split_inputs["stress_validation"][3]
    validation_physics = {
        "base_validation": physics_cached(
            "base_validation", args.output_dir, base, base_path, base_candidates,
            base["voltages"][base_validation], args.no_cache,
        ),
        "stress_validation": physics_cached(
            "stress_validation", args.output_dir, stress, stress_path, stress_candidates,
            stress["voltages"][stress_validation], args.no_cache,
        ),
    }
    policy, grid = tune_policy(
        base, stress, base_validation, stress_validation, base_path, stress_path,
        base_candidates, stress_candidates,
        (*validation_predictions["base_validation"], data["base_validation"][2], data["base_validation"][3]),
        (*validation_predictions["stress_validation"], data["stress_validation"][2], data["stress_validation"][3]),
        validation_physics["base_validation"], validation_physics["stress_validation"],
    )
    print(f"frozen validation policy: {json.dumps(json_ready(policy))}", flush=True)
    (args.output_dir / "training_history.json").write_text(json.dumps(json_ready(history), indent=2), encoding="utf-8")
    (args.output_dir / "validation_policy_grid.json").write_text(json.dumps(json_ready(grid), indent=2), encoding="utf-8")

    base_test = np.asarray(base["test_indices"], dtype=np.int64)
    stress_test = np.asarray(stress["test_indices"], dtype=np.int64)
    test_inputs: dict[str, tuple[np.ndarray, np.ndarray, dict[str, np.ndarray], np.ndarray]] = {}
    for name, archive, arrays, indices, source in (
        ("base_test", base, base_arrays, base_test, 0),
        ("stress_test", stress, stress_arrays, stress_test, 1),
    ):
        test_inputs[name] = infer_cached(name, args.output_dir, archive, arrays, indices, models, source, args.no_cache)
    test_data: dict[str, tuple[CandidateDataset, tuple[np.ndarray, np.ndarray] | None, np.ndarray, np.ndarray]] = {}
    for name, archive, indices, source in (
        ("base_test", base, base_test, "base"), ("stress_test", stress, stress_test, "stress"),
    ):
        _, baseline, fields, candidates = test_inputs[name]
        test_data[name] = build_candidate_data(source, archive, indices, baseline, candidates, fields, False)

    selected_test: dict[str, np.ndarray] = {}
    result_test: dict[str, np.ndarray] = {}
    predicted_test: dict[str, tuple[np.ndarray, np.ndarray]] = {}
    test_physics = {
        "base_test": physics_cached(
            "base_test", args.output_dir, base, test_inputs["base_test"][1], test_inputs["base_test"][3],
            base["voltages"][base_test], args.no_cache,
        ),
        "stress_test": physics_cached(
            "stress_test", args.output_dir, stress, test_inputs["stress_test"][1], test_inputs["stress_test"][3],
            stress["voltages"][stress_test], args.no_cache,
        ),
    }
    for name in ("base_test", "stress_test"):
        predicted = score_dataset(model, test_data[name][0], state, device, args.batch_size * 2)
        predicted_test[name] = predicted
        selected = select_candidates(
            predicted[0], predicted[1], test_data[name][2], test_data[name][3], policy,
            test_physics[name],
        )
        selected_test[name] = selected
        result_test[name] = gather_candidates(test_inputs[name][1], test_inputs[name][3], selected)

    base_summary = {
        name: standard_metrics(base["labels"][base_test], prediction, base["indentation_masks"][base_test])
        for name, prediction in (
            ("stable_raw", test_inputs["base_test"][0]),
            ("guarded_path", test_inputs["base_test"][1]),
            ("learned_selector", result_test["base_test"]),
        )
    }
    stress_summary: dict[str, dict[str, float]] = {}
    stress_family: dict[str, object] = {}
    core_rows: dict[str, list[dict[str, float]]] = {}
    for name, prediction in (
        ("stable_raw", test_inputs["stress_test"][0]),
        ("guarded_path", test_inputs["stress_test"][1]),
        ("learned_selector", result_test["stress_test"]),
    ):
        stress_summary[name], stress_family[name], _ = stress_metrics(
            stress["labels"][stress_test], prediction, stress["cutout_masks"][stress_test],
            stress["cutout_depth_weights"][stress_test], stress["family_codes"][stress_test],
        )
        _, core_rows[name] = core_metrics(stress, stress_test, prediction)
    core_summary = {
        name: core_metrics(stress, stress_test, prediction)[0]
        for name, prediction in (
            ("stable_raw", test_inputs["stress_test"][0]),
            ("guarded_path", test_inputs["stress_test"][1]),
            ("learned_selector", result_test["stress_test"]),
        )
    }
    bootstrap = paired_bootstrap(
        core_rows["guarded_path"], core_rows["learned_selector"], args.bootstrap_samples, args.seed,
    )

    print("inferring all 21 public KTC2023 cases", flush=True)
    real_conservative, real_aggressive = infer_pair(
        conservative, aggressive, adapter, base["real_linear_images"], base["real_voltages"],
        device, args.inference_batch_size, 256,
    )
    real_raw = blend(real_conservative, real_aggressive, 0.5)
    real_images = zoom(base["real_linear_images"], (1.0, 4.0, 4.0), order=1)
    real_path, _ = infer_path_prediction(
        action, feature_mean, feature_scale, real_images, real_raw, real_conservative, real_aggressive,
        device, float(models["path_parameters"]["threshold"]),
        float(models["path_parameters"]["width_bonus"]), bool(models["path_parameters"]["fallback_path"]), scale=4,
    )
    real_fields = infer_real_fields(
        coarse, competitive, adapter, base["real_linear_images"], base["real_voltages"],
        device, args.inference_batch_size,
    )
    from optimize_ktc_path_conditioned_concavity import GraphCutSpec
    real_specs = tuple(
        GraphCutSpec(spec.name, spec.radius * 4, spec.cutout_bias, spec.bank_weight, spec.smoothness, spec.hard_bank)
        for spec in GRAPH_SPECS
    )
    real_candidates, _ = graph_cut_candidates(real_raw, real_path, real_fields, real_specs)
    real_path64 = zoom(real_path, (1.0, 0.25, 0.25), order=0).astype(np.uint8)
    real_candidates64 = zoom(real_candidates, (1.0, 1.0, 0.25, 0.25), order=0).astype(np.uint8)
    real_fields64 = {
        key: zoom(real_fields[key], (1.0, 1.0, 0.25, 0.25), order=1).astype(np.float32)
        for key in ("cutout_proposal", "bank", "support")
    }
    real_scalar, real_centers, real_removal, real_holes = scalar_features(
        real_path64, real_candidates64, real_fields64, base["real_linear_images"],
    )
    real_dataset = CandidateDataset(
        real_path64, real_candidates64, real_fields64, base["real_linear_images"],
        real_scalar, real_centers,
    )
    real_prediction = score_dataset(model, real_dataset, state, device, args.batch_size * 2)
    real_physics = physics_cached(
        "public_21", args.output_dir, base, real_path64, real_candidates64,
        base["real_voltages"], args.no_cache,
    )
    real_selected = select_candidates(
        real_prediction[0], real_prediction[1], real_removal, real_holes, policy, real_physics,
    )
    real_result = gather_candidates(real_path, real_candidates, real_selected)
    real_oracle_selected, real_oracle_result, real_oracle_iou = oracle_iou_selection(
        base["real_labels"], real_path, real_candidates,
    )
    real_summary: dict[str, dict[str, float]] = {}
    real_rows: list[dict[str, object]] = []
    for name, prediction in (
        ("stable_raw", real_raw), ("guarded_path", real_path),
        ("learned_selector", real_result), ("candidate_oracle", real_oracle_result),
    ):
        real_summary[name], rows = evaluate_real_predictions(name, prediction, base["real_labels"], base["real_ids"])
        real_rows.extend(rows)
    inward_summary = {
        name: aggregate_rows([
            {key: float(value) for key, value in row.items() if key not in ("id", "method")}
            for row in real_rows if row["method"] == name and str(row["id"]) in PUBLIC_INWARD_IDS
        ])
        for name in ("stable_raw", "guarded_path", "learned_selector", "candidate_oracle")
    }

    print("inferring the original four public KTC2023-ABC2 cases", flush=True)
    calibration_conservative, calibration_aggressive = infer_pair(
        conservative, aggressive, adapter,
        base["calibration_linear_images"], base["calibration_voltages"],
        device, args.inference_batch_size, 256,
    )
    calibration_raw = blend(calibration_conservative, calibration_aggressive, 0.5)
    calibration_images = zoom(base["calibration_linear_images"], (1.0, 4.0, 4.0), order=1)
    calibration_path, _ = infer_path_prediction(
        action, feature_mean, feature_scale, calibration_images, calibration_raw,
        calibration_conservative, calibration_aggressive, device,
        float(models["path_parameters"]["threshold"]),
        float(models["path_parameters"]["width_bonus"]),
        bool(models["path_parameters"]["fallback_path"]), scale=4,
    )
    calibration_fields = infer_real_fields(
        coarse, competitive, adapter,
        base["calibration_linear_images"], base["calibration_voltages"],
        device, args.inference_batch_size,
    )
    calibration_candidates, _ = graph_cut_candidates(
        calibration_raw, calibration_path, calibration_fields, real_specs,
    )
    calibration_path64 = zoom(calibration_path, (1.0, 0.25, 0.25), order=0).astype(np.uint8)
    calibration_candidates64 = zoom(
        calibration_candidates, (1.0, 1.0, 0.25, 0.25), order=0,
    ).astype(np.uint8)
    calibration_fields64 = {
        key: zoom(calibration_fields[key], (1.0, 1.0, 0.25, 0.25), order=1).astype(np.float32)
        for key in ("cutout_proposal", "bank", "support")
    }
    calibration_scalar, calibration_centers, calibration_removal, calibration_holes = scalar_features(
        calibration_path64, calibration_candidates64, calibration_fields64,
        base["calibration_linear_images"],
    )
    calibration_dataset = CandidateDataset(
        calibration_path64, calibration_candidates64, calibration_fields64,
        base["calibration_linear_images"], calibration_scalar, calibration_centers,
    )
    calibration_prediction = score_dataset(
        model, calibration_dataset, state, device, args.batch_size * 2,
    )
    calibration_physics = physics_cached(
        "official_four", args.output_dir, base, calibration_path64, calibration_candidates64,
        base["calibration_voltages"], args.no_cache,
    )
    calibration_selected = select_candidates(
        calibration_prediction[0], calibration_prediction[1],
        calibration_removal, calibration_holes, policy, calibration_physics,
    )
    calibration_result = gather_candidates(
        calibration_path, calibration_candidates, calibration_selected,
    )
    official_truths, official_ids = load_official_four_case_truths(
        Path(__file__).resolve().parents[1] / "external" / "KTC2023-ABC2",
    )
    original_dip = load_dip_four_case_predictions(Path(__file__).resolve().parents[1])
    calibration_oracle_selected, calibration_oracle_result, calibration_oracle_iou = oracle_iou_selection(
        official_truths, calibration_path, calibration_candidates,
    )
    calibration_summary: dict[str, dict[str, float]] = {}
    calibration_rows: list[dict[str, object]] = []
    for name, prediction in (
        ("original_dip", original_dip),
        ("stable_raw", calibration_raw),
        ("guarded_path", calibration_path),
        ("physics_selector", calibration_result),
        ("candidate_oracle", calibration_oracle_result),
    ):
        calibration_summary[name], rows = evaluate_real_predictions(
            name, prediction, official_truths, official_ids,
        )
        calibration_rows.extend(rows)
    data4_metrics = {
        str(row["method"]): {key: value for key, value in row.items() if key not in ("id", "method")}
        for row in calibration_rows if str(row["id"]) == "data4"
    }

    save_improvement_montage(
        args.output_dir / "stress_largest_improvements.png", stress, stress_test,
        test_inputs["stress_test"][0], test_inputs["stress_test"][1], result_test["stress_test"],
        selected_test["stress_test"],
    )
    save_public_montage(
        args.output_dir / "public_inward_all_cases.png", base["real_labels"], base["real_ids"],
        real_raw, real_path, real_result, real_selected,
    )
    save_public_oracle_montage(
        args.output_dir / "public_inward_candidate_oracle.png", base["real_labels"], base["real_ids"],
        real_path, real_oracle_result, real_oracle_selected,
    )
    save_official_four_montage(
        args.output_dir / "official_four_comparison.png", official_truths, official_ids,
        original_dip, calibration_raw, calibration_path, calibration_result,
        calibration_selected, calibration_rows,
    )
    save_data4_focus(
        args.output_dir / "data4_inward_notch_focus.png", official_truths[3], original_dip[3],
        calibration_raw[3], calibration_path[3], calibration_result[3],
    )
    write_csv(args.output_dir / "paired_bootstrap_core.csv", bootstrap)
    write_csv(args.output_dir / "public_case_metrics.csv", real_rows)
    write_csv(args.output_dir / "official_four_case_metrics.csv", calibration_rows)
    stress_case_rows: list[dict[str, object]] = []
    for position, dataset_index in enumerate(stress_test):
        choice = int(selected_test["stress_test"][position])
        physics_gain = 0.0 if choice == 0 else float(
            1.0 - test_physics["stress_test"].residuals[choice, position]
            / max(test_physics["stress_test"].residuals[0, position], 1e-12)
        )
        fold_agreement = 0.0 if choice == 0 else float(np.mean(
            1.0 - test_physics["stress_test"].fold_residuals[choice, position]
            / np.maximum(test_physics["stress_test"].fold_residuals[0, position], 1e-12)
            >= float(policy["min_physics_gain"])
        ))
        stress_case_rows.append({
            "dataset_index": int(dataset_index),
            "family": FAMILIES[int(stress["family_codes"][dataset_index])],
            "candidate_choice": choice,
            "candidate_name": "identity" if choice == 0 else CANDIDATE_NAMES[choice - 1],
            "changed_pixels": int(np.count_nonzero(result_test["stress_test"][position] != test_inputs["stress_test"][1][position])),
            "predicted_utility": 0.0 if choice == 0 else float(predicted_test["stress_test"][0][choice - 1, position]),
            "predicted_harm": 0.0 if choice == 0 else float(predicted_test["stress_test"][1][choice - 1, position]),
            "held_out_voltage_gain": physics_gain,
            "fold_agreement": fold_agreement,
        })
    write_csv(args.output_dir / "stress_case_choices.csv", stress_case_rows)
    public_choice_rows: list[dict[str, object]] = []
    for position, case_id in enumerate(base["real_ids"]):
        choice = int(real_selected[position])
        public_choice_rows.append({
            "id": str(case_id),
            "candidate_choice": choice,
            "candidate_name": "identity" if choice == 0 else CANDIDATE_NAMES[choice - 1],
            "changed_pixels": int(np.count_nonzero(real_result[position] != real_path[position])),
            "held_out_voltage_gain": 0.0 if choice == 0 else float(
                1.0 - real_physics.residuals[choice, position]
                / max(real_physics.residuals[0, position], 1e-12)
            ),
        })
    write_csv(args.output_dir / "public_case_choices.csv", public_choice_rows)
    np.savez_compressed(
        args.output_dir / "predictions.npz",
        base_test_indices=base_test, base_raw=test_inputs["base_test"][0],
        base_path=test_inputs["base_test"][1], base_result=result_test["base_test"],
        base_selected=selected_test["base_test"], stress_test_indices=stress_test,
        stress_raw=test_inputs["stress_test"][0], stress_path=test_inputs["stress_test"][1],
        stress_result=result_test["stress_test"], stress_selected=selected_test["stress_test"],
        real_ids=base["real_ids"], real_raw=real_raw, real_path=real_path,
        real_candidates=real_candidates,
        real_result=real_result, real_selected=real_selected,
        real_oracle_result=real_oracle_result, real_oracle_selected=real_oracle_selected,
        real_candidate_iou=real_oracle_iou,
        official_ids=official_ids, official_truths=official_truths, official_dip=original_dip,
        official_raw=calibration_raw, official_path=calibration_path,
        official_candidates=calibration_candidates,
        official_result=calibration_result, official_selected=calibration_selected,
        official_oracle_result=calibration_oracle_result,
        official_oracle_selected=calibration_oracle_selected,
        official_candidate_iou=calibration_oracle_iou,
    )
    summary = {
        "method": "abstaining learned selector over explicit path-conditioned inward-boundary candidates",
        "candidate_names": list(CANDIDATE_NAMES),
        "graph_specs": [asdict(spec) for spec in GRAPH_SPECS],
        "training": {
            "base_cases": len(base_train), "stress_cases": len(stress_train),
            "checkpoint_epoch": int(state["epoch"]), "history": history,
        },
        "frozen_validation_policy": policy,
        "test": {
            "base": base_summary, "stress_all": stress_summary,
            "stress_core_inward_families": core_summary,
            "stress_by_family": stress_family,
            "bootstrap_guarded_to_learned": bootstrap,
            "changed_cases": {
                "base": changed_case_count(test_inputs["base_test"][1], result_test["base_test"]),
                "stress": changed_case_count(test_inputs["stress_test"][1], result_test["stress_test"]),
                "public": changed_case_count(real_path, real_result),
                "official_four": changed_case_count(calibration_path, calibration_result),
            },
        },
        "public_21": real_summary,
        "public_inward_subset": inward_summary,
        "official_four": calibration_summary,
        "data4": data4_metrics,
        "protocol": {
            "selector_training_labels": "synthetic train only",
            "policy_selection_labels": "synthetic validation only",
            "synthetic_test_labels": "final evaluation only",
            "public_KTC2023_labels": "final evaluation only",
            "official_four_labels": "final evaluation only",
            "physics_gate": "four drive-pattern folds; amplitudes fitted on three folds and residual tested on the held-out fold",
        },
    }
    (args.output_dir / "summary.json").write_text(json.dumps(json_ready(summary), indent=2), encoding="utf-8")
    report = (
        "# Physics-consistent selector for inward EIT boundaries\n\n"
        f"- Frozen policy: `{json.dumps(json_ready(policy))}`\n"
        f"- Core guarded open/deep recovery: `{core_summary['guarded_path']['open_deep_cutout_recovery']:.6f}`\n"
        f"- Core learned open/deep recovery: `{core_summary['learned_selector']['open_deep_cutout_recovery']:.6f}`\n"
        f"- Core guarded foreground IoU: `{core_summary['guarded_path']['foreground_iou']:.6f}`\n"
        f"- Core learned foreground IoU: `{core_summary['learned_selector']['foreground_iou']:.6f}`\n"
        f"- Core guarded bank retention: `{core_summary['guarded_path']['bank_retention']:.6f}`\n"
        f"- Core learned bank retention: `{core_summary['learned_selector']['bank_retention']:.6f}`\n"
        f"- Changed test cases (actual pixel changes): base `{changed_case_count(test_inputs['base_test'][1], result_test['base_test'])}`, "
        f"stress `{changed_case_count(test_inputs['stress_test'][1], result_test['stress_test'])}`, "
        f"public `{changed_case_count(real_path, real_result)}`, official four `{changed_case_count(calibration_path, calibration_result)}`.\n"
        f"- Public-21 guarded/new IoU: `{real_summary['guarded_path']['foreground_iou']:.6f}` / `{real_summary['learned_selector']['foreground_iou']:.6f}`.\n"
        f"- data4 original DIP/guarded/new IoU: `{data4_metrics['original_dip']['foreground_iou']:.6f}` / "
        f"`{data4_metrics['guarded_path']['foreground_iou']:.6f}` / `{data4_metrics['physics_selector']['foreground_iou']:.6f}`.\n\n"
        "The selector abstains whenever no candidate passes the validation-frozen utility, risk, component-removal, topology, and four-fold held-out voltage gates.\n"
    )
    (args.output_dir / "REPORT.md").write_text(report, encoding="utf-8")
    print(json.dumps(json_ready(summary["test"]["stress_core_inward_families"]), indent=2), flush=True)


if __name__ == "__main__":
    main()
