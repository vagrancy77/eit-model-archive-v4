"""Audit frozen case gates and pixel cutout confidence maps across seeds."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import zoom

import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import train_topology_residual_eit_v3 as trainer


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", nargs="+", required=True, help="seed=training_directory")
    parser.add_argument("--public-runs", nargs="+", required=True, help="seed=final_evaluation_directory")
    parser.add_argument("--routers", nargs="+", required=True, help="seed=router_directory")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--base-dataset", type=Path, default=ROOT / "datasets" / "ktc_shape_nonlinear_v1.npz"
    )
    parser.add_argument("--bins", type=int, default=12)
    parser.add_argument("--seed", type=int, default=20260919)
    return parser.parse_args()


def parse_keyed(values: list[str]) -> dict[str, Path]:
    result: dict[str, Path] = {}
    for value in values:
        if "=" not in value:
            raise ValueError(f"expected seed=path, got {value!r}")
        key, raw_path = value.split("=", 1)
        result[key] = Path(raw_path).resolve()
    return result


def binary_metrics(target: np.ndarray, score: np.ndarray, bins: int) -> dict[str, object]:
    target = np.asarray(target, dtype=np.uint8).reshape(-1)
    score = np.asarray(score, dtype=np.float64).reshape(-1)
    finite = np.isfinite(score)
    target = target[finite]
    score = np.clip(score[finite], 0.0, 1.0)
    positive = int(target.sum())
    negative = int(len(target) - positive)
    brier = float(np.mean((score - target) ** 2))

    if positive and negative:
        order = np.argsort(score, kind="stable")[::-1]
        sorted_target = target[order]
        tp = np.cumsum(sorted_target)
        fp = np.cumsum(1 - sorted_target)
        tpr = np.concatenate(([0.0], tp / positive, [1.0]))
        fpr = np.concatenate(([0.0], fp / negative, [1.0]))
        auroc = float(np.trapezoid(tpr, fpr))
        precision = tp / np.maximum(1, tp + fp)
        average_precision = float(precision[sorted_target == 1].sum() / positive)
    else:
        auroc = float("nan")
        average_precision = float("nan")

    edges = np.linspace(0.0, 1.0, bins + 1)
    bin_index = np.minimum(np.searchsorted(edges, score, side="right") - 1, bins - 1)
    bin_index = np.maximum(bin_index, 0)
    calibration: list[dict[str, float]] = []
    ece = 0.0
    for index in range(bins):
        selected = bin_index == index
        if selected.any():
            confidence = float(score[selected].mean())
            frequency = float(target[selected].mean())
            fraction = float(selected.mean())
        else:
            confidence = float((edges[index] + edges[index + 1]) / 2.0)
            frequency = float("nan")
            fraction = 0.0
        if np.isfinite(frequency):
            ece += fraction * abs(confidence - frequency)
        calibration.append(
            {
                "low": float(edges[index]),
                "high": float(edges[index + 1]),
                "count": int(selected.sum()),
                "mean_confidence": confidence,
                "empirical_frequency": frequency,
            }
        )
    return {
        "samples": len(target),
        "positives": positive,
        "positive_fraction": float(target.mean()),
        "brier": brier,
        "auroc": auroc,
        "average_precision": average_precision,
        "expected_calibration_error": float(ece),
        "calibration_bins": calibration,
    }


def safe_useful_targets(
    truth: np.ndarray,
    cutout: np.ndarray,
    direct: np.ndarray,
    topology: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    targets = np.zeros(len(truth), dtype=np.uint8)
    iou_delta = np.empty(len(truth), dtype=np.float64)
    notch_delta = np.full(len(truth), np.nan, dtype=np.float64)
    for index in range(len(truth)):
        base = trainer.case_metrics(truth[index], direct[index], cutout[index])
        candidate = trainer.case_metrics(truth[index], topology[index], cutout[index])
        iou_delta[index] = candidate["foreground_iou"] - base["foreground_iou"]
        if np.isfinite(base["notch_preservation"]):
            notch_delta[index] = candidate["notch_preservation"] - base["notch_preservation"]
            targets[index] = bool(notch_delta[index] > 0.0 and iou_delta[index] >= -0.01)
    return targets, iou_delta, notch_delta


def synthetic_groups(archive: np.lib.npyio.NpzFile) -> dict[str, dict[str, np.ndarray]]:
    groups: dict[str, dict[str, np.ndarray]] = {}
    for name in ("base", "biological", "stress"):
        groups[name] = {
            "truth": np.asarray(archive[f"{name}_truth"]),
            "cutout": np.asarray(archive[f"{name}_cutout"]),
            "direct": np.asarray(archive[f"{name}_base_prediction"]),
            "topology": np.asarray(archive[f"{name}_prediction"]),
            "confidence": np.asarray(archive[f"{name}_effective_cutout"]),
            "gate": np.asarray(archive[f"{name}_case_gate"]),
        }
    return groups


def public_group(archive: np.lib.npyio.NpzFile) -> dict[str, np.ndarray]:
    return {
        "truth": np.asarray(archive["truth"]),
        "cutout": np.asarray(archive["notch"]),
        "direct": np.asarray(archive["direct_base"]),
        "topology": np.asarray(archive["topology_residual"]),
        "confidence": np.asarray(archive["effective_cutout"]),
        "gate": np.asarray(archive["case_gate"]),
    }


def evaluate_group(
    arrays: dict[str, np.ndarray],
    fov: np.ndarray,
    threshold: float,
    bins: int,
) -> tuple[dict[str, object], list[dict[str, object]], dict[str, np.ndarray]]:
    targets, iou_delta, notch_delta = safe_useful_targets(
        arrays["truth"], arrays["cutout"], arrays["direct"], arrays["topology"]
    )
    gate_metrics = binary_metrics(targets, arrays["gate"], bins)
    enabled = arrays["gate"] >= threshold
    true_positive = int(np.sum(enabled & (targets != 0)))
    gate_metrics["router_threshold"] = threshold
    gate_metrics["router_enabled_fraction"] = float(enabled.mean())
    gate_metrics["router_precision_for_safe_useful"] = float(true_positive / max(1, enabled.sum()))
    gate_metrics["router_recall_for_safe_useful"] = float(true_positive / max(1, targets.sum()))
    gate_metrics["mean_iou_delta_when_enabled"] = float(iou_delta[enabled].mean()) if enabled.any() else 0.0
    valid_notch = enabled & np.isfinite(notch_delta)
    gate_metrics["mean_notch_delta_when_enabled"] = (
        float(notch_delta[valid_notch].mean()) if valid_notch.any() else 0.0
    )

    if arrays["confidence"].shape[-2:] != fov.shape:
        scale = tuple(a / b for a, b in zip(arrays["confidence"].shape[-2:], fov.shape))
        domain = zoom(fov.astype(np.uint8), scale, order=0) != 0
    else:
        domain = fov != 0
    selected_probability = arrays["confidence"][:, domain]
    selected_target = (arrays["cutout"][:, domain] != 0).astype(np.uint8)
    pixel_metrics = binary_metrics(selected_target, selected_probability, bins)

    case_rows = [
        {
            "case": index,
            "gate": float(arrays["gate"][index]),
            "safe_useful": int(targets[index]),
            "router_enabled": int(enabled[index]),
            "iou_delta": float(iou_delta[index]),
            "notch_delta": float(notch_delta[index]),
        }
        for index in range(len(targets))
    ]
    return (
        {"case_gate": gate_metrics, "pixel_confidence": pixel_metrics},
        case_rows,
        {
            "gate_target": targets,
            "gate_score": arrays["gate"],
            "pixel_target": selected_target.reshape(-1),
            "pixel_score": selected_probability.reshape(-1),
        },
    )


def pooled_seed_summary(seed_results: list[dict[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for component in ("case_gate", "pixel_confidence"):
        result[component] = {}
        keys = (
            "brier", "auroc", "average_precision", "expected_calibration_error",
            "positive_fraction",
        )
        for key in keys:
            values = np.asarray([entry[component][key] for entry in seed_results], dtype=float)
            result[component][key] = {
                "mean": float(np.nanmean(values)),
                "sd": float(np.nanstd(values, ddof=1)),
                "per_seed": [float(value) for value in values],
            }
    return result


def plot_reliability(path: Path, pooled: dict[str, dict[str, np.ndarray]], bins: int) -> None:
    selected = ("biological", "stress", "public_ktc")
    figure, axes = plt.subplots(2, 3, figsize=(14.0, 8.2), squeeze=False)
    for column, group in enumerate(selected):
        for row, (target_key, score_key, title) in enumerate(
            (
                ("gate_target", "gate_score", "case gate: safe and useful edit"),
                ("pixel_target", "pixel_score", "pixel cutout confidence"),
            )
        ):
            metric = binary_metrics(pooled[group][target_key], pooled[group][score_key], bins)
            calibration = metric["calibration_bins"]
            x = np.asarray([value["mean_confidence"] for value in calibration])
            y = np.asarray([value["empirical_frequency"] for value in calibration])
            valid = np.isfinite(y)
            axis = axes[row, column]
            axis.plot((0, 1), (0, 1), "--", color="#777777", linewidth=1)
            axis.plot(x[valid], y[valid], marker="o", color="#1b8a5a", linewidth=2)
            axis.set_xlim(0, 1)
            axis.set_ylim(0, 1)
            axis.grid(alpha=0.2)
            axis.set_title(
                f"{group}: {title}\nAUROC={metric['auroc']:.3f}, ECE={metric['expected_calibration_error']:.3f}"
            )
            axis.set_xlabel("predicted confidence")
            axis.set_ylabel("empirical frequency")
    figure.suptitle("Four-seed confidence reliability on frozen independent/public tests")
    figure.tight_layout()
    figure.savefig(path, dpi=240)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    runs = parse_keyed(args.runs)
    public_runs = parse_keyed(args.public_runs)
    routers = parse_keyed(args.routers)
    if not (runs.keys() == public_runs.keys() == routers.keys()):
        raise ValueError("all seed labels must match")
    base = np.load(args.base_dataset.resolve(), allow_pickle=False)
    fov = np.asarray(base["fov_mask"], dtype=np.uint8)
    details: dict[str, dict[str, object]] = {}
    case_rows: list[dict[str, object]] = []
    pooled: dict[str, dict[str, list[np.ndarray]]] = {}
    for seed in runs:
        threshold = float(
            json.loads(
                (routers[seed] / "action_router_summary.json").read_text(encoding="utf-8")
            )["threshold"]
        )
        test = np.load(runs[seed] / "test_predictions.npz", allow_pickle=False)
        public = np.load(public_runs[seed] / "public_ktc_predictions.npz", allow_pickle=False)
        groups = synthetic_groups(test)
        groups["public_ktc"] = public_group(public)
        details[seed] = {}
        for group_name, arrays in groups.items():
            result, rows, values = evaluate_group(arrays, fov, threshold, args.bins)
            details[seed][group_name] = result
            for row in rows:
                case_rows.append({"seed": seed, "group": group_name, **row})
            if group_name not in pooled:
                pooled[group_name] = {key: [] for key in values}
            for key, value in values.items():
                pooled[group_name][key].append(value)
    pooled_arrays = {
        group: {key: np.concatenate(values) for key, values in components.items()}
        for group, components in pooled.items()
    }
    aggregate = {
        group: pooled_seed_summary([details[seed][group] for seed in runs])
        for group in pooled_arrays
    }
    result = {
        "seeds": list(runs),
        "definition": {
            "safe_useful_case_action": "true notch improvement and IoU change >= -0.01",
            "pixel_target": "ground-truth inward cutout mask within the EIT field of view",
            "analysis_sets": "frozen independent synthetic tests and public KTC; no parameter selection",
        },
        "per_seed": details,
        "aggregate_mean_sd": aggregate,
    }
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "confidence_reliability_summary.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    with (output_dir / "confidence_reliability_cases.csv").open(
        "w", encoding="utf-8", newline=""
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=list(case_rows[0]))
        writer.writeheader()
        writer.writerows(case_rows)
    plot_reliability(output_dir / "confidence_reliability_diagram.png", pooled_arrays, args.bins)
    print(json.dumps({"output_dir": str(output_dir), "groups": list(aggregate)}, indent=2), flush=True)


if __name__ == "__main__":
    main()
