"""Aggregate frozen multi-seed KTC concavity experiments.

The script performs a paired hierarchical bootstrap over both random seeds and
the pre-audited non-convex KTC cases. It never trains or selects a model.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import ListedColormap


METRICS = (
    "foreground_iou",
    "foreground_dice",
    "boundary_f1",
    "notch_preservation",
    "concavity_score",
    "ktc_ssim",
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--runs",
        nargs="+",
        required=True,
        help="Entries formatted as seed=output_directory.",
    )
    parser.add_argument(
        "--audit",
        type=Path,
        default=root / "outputs" / "ktc2023_full_audit" / "summary.json",
    )
    parser.add_argument("--candidate", default="fusion")
    parser.add_argument("--reference", default="boundary")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--bootstrap-repetitions", type=int, default=10_000)
    parser.add_argument("--seed", type=int, default=20260819)
    parser.add_argument("--prediction-run", type=Path)
    return parser.parse_args()


def parse_runs(values: list[str]) -> list[tuple[str, Path]]:
    runs: list[tuple[str, Path]] = []
    for value in values:
        if "=" not in value:
            raise ValueError(f"Run must be seed=directory, got {value!r}")
        seed, raw_path = value.split("=", 1)
        runs.append((seed, Path(raw_path).resolve()))
    if len({seed for seed, _ in runs}) != len(runs):
        raise ValueError("Run seed labels must be unique")
    return runs


def load_rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def difference_matrix(
    rows_by_seed: list[list[dict[str, str]]],
    case_ids: list[str],
    candidate: str,
    reference: str,
    metric: str,
) -> np.ndarray:
    matrix = np.empty((len(rows_by_seed), len(case_ids)), dtype=np.float64)
    for seed_index, rows in enumerate(rows_by_seed):
        lookup = {(row["id"], row["method"]): row for row in rows}
        for case_index, case_id in enumerate(case_ids):
            matrix[seed_index, case_index] = (
                float(lookup[(case_id, candidate)][metric])
                - float(lookup[(case_id, reference)][metric])
            )
    return matrix


def method_matrix(
    rows_by_seed: list[list[dict[str, str]]],
    case_ids: list[str],
    method: str,
    metric: str,
) -> np.ndarray:
    matrix = np.empty((len(rows_by_seed), len(case_ids)), dtype=np.float64)
    for seed_index, rows in enumerate(rows_by_seed):
        lookup = {(row["id"], row["method"]): row for row in rows}
        for case_index, case_id in enumerate(case_ids):
            matrix[seed_index, case_index] = float(lookup[(case_id, method)][metric])
    return matrix


def hierarchical_bootstrap(
    differences: np.ndarray,
    repetitions: int,
    rng: np.random.Generator,
) -> dict[str, float]:
    seed_count, case_count = differences.shape
    seed_draws = rng.integers(0, seed_count, size=(repetitions, seed_count))
    case_draws = rng.integers(0, case_count, size=(repetitions, case_count))
    samples = differences[seed_draws[:, :, None], case_draws[:, None, :]].mean(axis=(1, 2))
    return {
        "mean_difference": float(differences.mean()),
        "ci95_low": float(np.percentile(samples, 2.5)),
        "ci95_high": float(np.percentile(samples, 97.5)),
        "bootstrap_probability_positive": float((samples > 0).mean()),
    }


def plot_metric_deltas(path: Path, statistics: dict[str, dict[str, float]]) -> None:
    fields = (
        ("foreground_iou", "IoU"),
        ("boundary_f1", "Boundary F1"),
        ("notch_preservation", "Notch"),
        ("concavity_score", "Joint"),
        ("ktc_ssim", "KTC-SSIM"),
    )
    means = np.asarray([statistics[key]["mean_difference"] for key, _ in fields])
    lows = np.asarray([statistics[key]["ci95_low"] for key, _ in fields])
    highs = np.asarray([statistics[key]["ci95_high"] for key, _ in fields])
    x = np.arange(len(fields))
    colors = np.where(means >= 0, "#167d57", "#b53a3a")
    figure, axis = plt.subplots(figsize=(9.2, 4.8))
    axis.bar(x, means, color=colors, width=0.66)
    axis.errorbar(x, means, yerr=(means - lows, highs - means), fmt="none", ecolor="#202020", capsize=5)
    axis.axhline(0.0, color="#222222", linewidth=1.0)
    axis.set_xticks(x, [label for _, label in fields])
    axis.set_ylabel("Fusion - boundary")
    axis.set_title("Strict non-convex KTC subgroup: hierarchical bootstrap across seeds and cases")
    axis.grid(axis="y", alpha=0.22)
    for index, value in enumerate(means):
        axis.text(index, value, f" {value:+.3f}", ha="center", va="bottom" if value >= 0 else "top", fontsize=9)
    figure.tight_layout()
    figure.savefig(path, dpi=210)
    plt.close(figure)


def plot_case_deltas(
    path: Path,
    matrices: dict[str, np.ndarray],
    case_ids: list[str],
) -> None:
    fields = (
        ("foreground_iou", "Foreground IoU"),
        ("boundary_f1", "Boundary F1"),
        ("notch_preservation", "Notch preservation"),
        ("concavity_score", "Joint concavity score"),
    )
    figure, axes = plt.subplots(2, 2, figsize=(13.2, 8.3), sharex=True)
    x = np.arange(len(case_ids))
    for axis, (metric, title) in zip(axes.flat, fields):
        values = matrices[metric].mean(axis=0)
        errors = matrices[metric].std(axis=0, ddof=1) if matrices[metric].shape[0] > 1 else np.zeros_like(values)
        colors = np.where(values >= 0, "#167d57", "#b53a3a")
        axis.bar(x, values, color=colors, width=0.76)
        axis.errorbar(x, values, yerr=errors, fmt="none", ecolor="#333333", alpha=0.65, linewidth=0.9)
        axis.axhline(0.0, color="#222222", linewidth=0.9)
        axis.set_title(title)
        axis.grid(axis="y", alpha=0.2)
    for axis in axes[-1]:
        axis.set_xticks(x, [case_id.replace("level_", "L") for case_id in case_ids], rotation=55, ha="right")
    figure.suptitle("Per-case fusion - boundary differences (mean and SD across seeds)", fontsize=14)
    figure.tight_layout()
    figure.savefig(path, dpi=200)
    plt.close(figure)


def plot_qualitative(path: Path, prediction_path: Path, metrics_path: Path) -> None:
    archive = np.load(prediction_path, allow_pickle=False)
    ids = [str(value) for value in archive["ids"]]
    requested = ("level_2/2", "level_5/2", "level_6/2", "level_7/3")
    selected = [ids.index(case_id) for case_id in requested if case_id in ids]
    if not selected:
        return
    rows = load_rows(metrics_path)
    lookup = {(row["id"], row["method"]): row for row in rows}
    methods = ("truth", "boundary", "voltage", "fusion")
    palette = ListedColormap(("#211547", "#20aaa6", "#f0c541"))
    figure, axes = plt.subplots(len(selected), len(methods), figsize=(10.2, 2.5 * len(selected)), squeeze=False)
    for row_index, case_index in enumerate(selected):
        case_id = ids[case_index]
        for column, method in enumerate(methods):
            axes[row_index, column].imshow(archive[method][case_index], vmin=0, vmax=2, cmap=palette, interpolation="nearest")
            if method == "truth":
                title = f"{case_id.replace('level_', 'L')} truth"
            else:
                metric = lookup[(case_id, method)]
                title = f"{method}\nIoU {float(metric['foreground_iou']):.3f} | notch {float(metric['notch_preservation']):.3f}"
            axes[row_index, column].set_title(title, fontsize=10)
            axes[row_index, column].set_axis_off()
    figure.suptitle("Representative public KTC non-convex cases", fontsize=14)
    figure.tight_layout()
    figure.savefig(path, dpi=220)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    runs = parse_runs(args.runs)
    audit = json.loads(args.audit.resolve().read_text(encoding="utf-8"))
    case_ids = [str(value) for value in audit["nonconvex_ids"]]
    rows_by_seed = [load_rows(path / "real_case_metrics.csv") for _, path in runs]
    available = [
        {(row["id"], row["method"]) for row in rows}
        for rows in rows_by_seed
    ]
    required = {(case_id, method) for case_id in case_ids for method in (args.candidate, args.reference)}
    for (seed, _), pairs in zip(runs, available):
        missing = sorted(required - pairs)
        if missing:
            raise RuntimeError(f"Run {seed} is missing {missing}")

    rng = np.random.default_rng(args.seed)
    difference_matrices = {
        metric: difference_matrix(rows_by_seed, case_ids, args.candidate, args.reference, metric)
        for metric in METRICS
    }
    statistics = {
        metric: hierarchical_bootstrap(matrix, args.bootstrap_repetitions, rng)
        for metric, matrix in difference_matrices.items()
    }
    per_seed = {}
    for seed_index, (seed, _) in enumerate(runs):
        per_seed[seed] = {
            metric: float(matrix[seed_index].mean()) for metric, matrix in difference_matrices.items()
        }
    subgroup_means = {}
    for method in (args.reference, args.candidate):
        subgroup_means[method] = {
            metric: float(method_matrix(rows_by_seed, case_ids, method, metric).mean()) for metric in METRICS
        }

    result = {
        "candidate": args.candidate,
        "reference": args.reference,
        "seeds": [seed for seed, _ in runs],
        "runs": {seed: str(path) for seed, path in runs},
        "strict_case_count": len(case_ids),
        "strict_case_ids": case_ids,
        "bootstrap_repetitions": args.bootstrap_repetitions,
        "bootstrap_design": "paired hierarchical resampling of random seeds and fixed audited KTC cases",
        "subgroup_means_across_seeds_and_cases": subgroup_means,
        "per_seed_mean_differences": per_seed,
        "hierarchical_bootstrap": statistics,
    }
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    plot_metric_deltas(output_dir / "multiseed_metric_deltas.png", statistics)
    plot_case_deltas(output_dir / "multiseed_case_deltas.png", difference_matrices, case_ids)
    if args.prediction_run is not None:
        prediction_run = args.prediction_run.resolve()
        plot_qualitative(
            output_dir / "representative_nonconvex_cases.png",
            prediction_run / "real_predictions.npz",
            prediction_run / "real_case_metrics.csv",
        )
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
