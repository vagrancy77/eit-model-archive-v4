"""Hull-minus-cutout network for arbitrary non-convex EIT inclusions.

Every connected inclusion can be represented as a simple support region minus
one or more background cutouts.  A frozen EIT ensemble supplies stable class
and location evidence; this network has separate decoders for the outer
support and the inward cutouts.  Cutout strength is selected on synthetic
validation data before either synthetic test or KTC evaluation truths are
read.
"""
from __future__ import annotations

import argparse
import json
import math
import random
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset

from train_ktc_concavity_network import (
    DecoderStage,
    InputAdapter,
    ResidualBlock,
    aggregate_rows,
    confusion_metrics,
    indentation_mask,
    save_focus_montage,
    save_real_montage,
    soft_dice_loss,
    write_rows,
)
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_highres_refiner import FrozenCoarseEnsemble, load_coarse_ensemble


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument(
        "--coarse-checkpoint",
        nargs="+",
        type=Path,
        default=[
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "boundary_best.pt",
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "indent_best.pt",
            root / "outputs" / "ktc_concavity_voltage_seed20260819" / "voltage_best.pt",
        ],
    )
    parser.add_argument("--coarse-weights", nargs="+", type=float, default=[0.30, 0.40, 0.30])
    parser.add_argument("--output-dir", type=Path, default=root / "outputs" / "ktc_hull_cutout")
    parser.add_argument("--epochs", type=int, default=72)
    parser.add_argument("--patience", type=int, default=14)
    parser.add_argument("--batch-size", type=int, default=20)
    parser.add_argument("--base-channels", type=int, default=24)
    parser.add_argument("--learning-rate", type=float, default=1.5e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--seed", type=int, default=20260819)
    parser.add_argument("--support-weight", type=float, default=0.45)
    parser.add_argument("--cutout-weight", type=float, default=0.65)
    parser.add_argument("--boundary-weight", type=float, default=0.30)
    parser.add_argument("--bank-weight", type=float, default=0.22)
    parser.add_argument("--sparse-weight", type=float, default=0.04)
    parser.add_argument("--calibration-weight", type=float, default=0.05)
    parser.add_argument("--iou-tolerance", type=float, default=0.012)
    parser.add_argument("--boundary-tolerance", type=float, default=0.005)
    parser.add_argument("--progress-every", type=int, default=1)
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


class HullCutoutDataset(Dataset):
    def __init__(self, archive: np.lib.npyio.NpzFile, indices: np.ndarray) -> None:
        self.images = archive["linear_images"]
        self.voltages = archive["voltages"]
        self.labels = archive["labels"]
        self.indentations = archive["indentation_masks"]
        self.indices = np.asarray(indices, dtype=np.int64)

    def __len__(self) -> int:
        return int(self.indices.size)

    def __getitem__(self, item: int) -> dict[str, torch.Tensor]:
        index = int(self.indices[item])
        labels = np.asarray(self.labels[index], dtype=np.int64)
        cutout = np.asarray(self.indentations[index], dtype=np.float32)
        support = np.logical_or(labels != 0, cutout != 0).astype(np.float32)
        return {
            "image": torch.from_numpy(np.asarray(self.images[index], dtype=np.float32)[None]),
            "voltage": torch.from_numpy(np.asarray(self.voltages[index], dtype=np.float32)),
            "labels": torch.from_numpy(labels),
            "support": torch.from_numpy(support[None]),
            "cutout": torch.from_numpy(cutout[None]),
            "indent": torch.from_numpy(cutout[None]),
            "index": torch.tensor(index, dtype=torch.int64),
        }


class CalibrationDataset(Dataset):
    def __init__(self, archive: np.lib.npyio.NpzFile) -> None:
        self.images = archive["calibration_linear_images"]
        self.voltages = archive["calibration_voltages"]
        self.labels = archive["calibration_labels"]
        self.indentations = archive["calibration_indentation_masks"]

    def __len__(self) -> int:
        return int(len(self.labels))

    def __getitem__(self, index: int) -> dict[str, torch.Tensor]:
        labels = np.asarray(self.labels[index], dtype=np.int64)
        cutout = np.asarray(self.indentations[index], dtype=np.float32)
        support = np.logical_or(labels != 0, cutout != 0).astype(np.float32)
        return {
            "image": torch.from_numpy(np.asarray(self.images[index], dtype=np.float32)[None]),
            "voltage": torch.from_numpy(np.asarray(self.voltages[index], dtype=np.float32)),
            "labels": torch.from_numpy(labels),
            "support": torch.from_numpy(support[None]),
            "cutout": torch.from_numpy(cutout[None]),
            "indent": torch.from_numpy(cutout[None]),
        }


class VoltageEncoder(nn.Module):
    def __init__(self, base: int) -> None:
        super().__init__()
        self.features = nn.Sequential(
            ResidualBlock(1, base),
            nn.Conv2d(base, base * 2, 3, stride=2, padding=1, bias=False),
            ResidualBlock(base * 2, base * 2),
            nn.Conv2d(base * 2, base * 4, 3, stride=2, padding=1, bias=False),
            ResidualBlock(base * 4, base * 4),
            nn.Conv2d(base * 4, base * 8, 3, stride=2, padding=1, bias=False),
            ResidualBlock(base * 8, base * 8),
        )
        self.projection = nn.Conv2d(base * 8, base * 16, 1)

    def forward(self, voltage: torch.Tensor) -> torch.Tensor:
        centered = voltage - voltage.median(dim=1, keepdim=True).values
        scale = torch.quantile(centered.abs(), 0.985, dim=1, keepdim=True).clamp_min(1e-6)
        table = torch.clamp(centered / scale, -4.0, 4.0).reshape(-1, 1, 76, 31) / 4.0
        return self.projection(F.adaptive_avg_pool2d(self.features(table), (4, 4)))


class DilatedContext(nn.Module):
    def __init__(self, channels: int) -> None:
        super().__init__()
        branch = max(8, channels // 4)
        self.branches = nn.ModuleList(
            nn.Sequential(
                nn.Conv2d(channels, branch, 3, padding=dilation, dilation=dilation, bias=False),
                nn.GroupNorm(min(8, branch), branch),
                nn.SiLU(),
            )
            for dilation in (1, 2, 3, 4)
        )
        self.merge = ResidualBlock(branch * 4, channels)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.merge(torch.cat([branch(x) for branch in self.branches], dim=1))


class HullCutoutNet(nn.Module):
    """Two structural decoders: outer support and background cutouts."""

    def __init__(self, base: int) -> None:
        super().__init__()
        self.base = base
        self.stem = ResidualBlock(6, base)
        self.enc1 = ResidualBlock(base, base * 2)
        self.enc2 = ResidualBlock(base * 2, base * 4)
        self.enc3 = ResidualBlock(base * 4, base * 8)
        self.bottleneck = nn.Sequential(
            ResidualBlock(base * 8, base * 16),
            nn.Dropout2d(0.10),
            ResidualBlock(base * 16, base * 16),
        )
        self.voltage = VoltageEncoder(base)
        self.voltage_gate = nn.Parameter(torch.tensor(-2.0))
        self.support3 = DecoderStage(base * 16, base * 8, base * 8)
        self.support2 = DecoderStage(base * 8, base * 4, base * 4)
        self.support1 = DecoderStage(base * 4, base * 2, base * 2)
        self.support0 = DecoderStage(base * 2, base, base)
        self.cut_context = DilatedContext(base * 16)
        self.cut3 = DecoderStage(base * 16, base * 8, base * 8)
        self.cut2 = DecoderStage(base * 8, base * 4, base * 4)
        self.cut1 = DecoderStage(base * 4, base * 2, base * 2)
        self.cut0 = DecoderStage(base * 2, base, base)
        self.support_residual = nn.Conv2d(base, 1, 1)
        self.cutout_head = nn.Sequential(ResidualBlock(base * 2, base), nn.Conv2d(base, 1, 1))
        self.polarity_residual = nn.Conv2d(base * 2, 2, 1)
        nn.init.zeros_(self.support_residual.weight)
        nn.init.zeros_(self.support_residual.bias)
        nn.init.zeros_(self.polarity_residual.weight)
        nn.init.zeros_(self.polarity_residual.bias)
        nn.init.zeros_(self.cutout_head[-1].weight)
        nn.init.constant_(self.cutout_head[-1].bias, -3.0)

    def forward(
        self,
        adapted_image: torch.Tensor,
        voltage: torch.Tensor,
        coarse_probability: torch.Tensor,
        cutout_bias: float = 0.0,
    ) -> dict[str, torch.Tensor]:
        e0 = self.stem(torch.cat((adapted_image, coarse_probability), dim=1))
        e1 = self.enc1(F.max_pool2d(e0, 2))
        e2 = self.enc2(F.max_pool2d(e1, 2))
        e3 = self.enc3(F.max_pool2d(e2, 2))
        bottleneck = self.bottleneck(F.max_pool2d(e3, 2))
        bottleneck = bottleneck + torch.sigmoid(self.voltage_gate) * self.voltage(voltage)

        support = self.support3(bottleneck, e3)
        support = self.support2(support, e2)
        support = self.support1(support, e1)
        support = self.support0(support, e0)

        cutout = self.cut3(self.cut_context(bottleneck), e3)
        cutout = self.cut2(cutout, e2)
        cutout = self.cut1(cutout, e1)
        cutout = self.cut0(cutout, e0)
        joint = torch.cat((support, cutout), dim=1)

        coarse_foreground = coarse_probability[:, 1:].sum(dim=1, keepdim=True).clamp(1e-5, 1.0 - 1e-5)
        coarse_support_logit = torch.logit(coarse_foreground)
        support_logit = coarse_support_logit + 2.5 * torch.tanh(self.support_residual(support))
        cutout_logit = self.cutout_head(joint) + float(cutout_bias)
        support_probability = torch.sigmoid(support_logit)
        cutout_probability = torch.sigmoid(cutout_logit)
        foreground_probability = (support_probability * (1.0 - cutout_probability)).clamp(1e-6, 1.0 - 1e-6)

        coarse_polarity = coarse_probability[:, 1:].clamp_min(1e-6)
        coarse_polarity = coarse_polarity / coarse_polarity.sum(dim=1, keepdim=True)
        polarity = torch.softmax(torch.log(coarse_polarity) + self.polarity_residual(joint), dim=1)
        probabilities = torch.cat(
            (
                1.0 - foreground_probability,
                foreground_probability * polarity[:, 0:1],
                foreground_probability * polarity[:, 1:2],
            ),
            dim=1,
        ).clamp_min(1e-7)
        return {
            "logits": torch.log(probabilities),
            "probabilities": probabilities,
            "support_logit": support_logit,
            "cutout_logit": cutout_logit,
            "support_probability": support_probability,
            "cutout_probability": cutout_probability,
            "foreground_probability": foreground_probability,
        }


def balanced_binary_loss(
    logits: torch.Tensor,
    target: torch.Tensor,
    mask: torch.Tensor | None = None,
    positive_share: float = 0.5,
) -> torch.Tensor:
    logits = logits.float()
    target = target.float()
    if mask is None:
        mask = torch.ones_like(target)
    else:
        mask = mask.float()
    positive = mask * target
    negative = mask * (1.0 - target)
    raw = F.binary_cross_entropy_with_logits(logits, target, reduction="none")
    positive_loss = (raw * positive).sum(dim=(1, 2, 3)) / positive.sum(dim=(1, 2, 3)).clamp_min(1.0)
    negative_loss = (raw * negative).sum(dim=(1, 2, 3)) / negative.sum(dim=(1, 2, 3)).clamp_min(1.0)
    has_positive = positive.sum(dim=(1, 2, 3)) > 0
    balanced = torch.where(
        has_positive,
        positive_share * positive_loss + (1.0 - positive_share) * negative_loss,
        negative_loss,
    )
    return balanced.mean()


def gradients(image: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    return image[:, :, 1:, :] - image[:, :, :-1, :], image[:, :, :, 1:] - image[:, :, :, :-1]


def masked_mean(value: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    per_case = (value * mask).sum(dim=(1, 2, 3)) / mask.sum(dim=(1, 2, 3)).clamp_min(1.0)
    valid = mask.sum(dim=(1, 2, 3)) > 0
    return per_case[valid].mean() if valid.any() else value.new_zeros(())


def structural_loss(
    outputs: dict[str, torch.Tensor],
    batch: dict[str, torch.Tensor],
    args: argparse.Namespace,
    ramp: float,
) -> tuple[torch.Tensor, dict[str, float]]:
    labels = batch["labels"]
    target_foreground = (labels != 0).float().unsqueeze(1)
    support = batch["support"]
    cutout = batch["cutout"]
    logits = outputs["logits"]
    class_weights = logits.new_tensor((0.35, 1.25, 1.25))
    segmentation = F.nll_loss(logits, labels, weight=class_weights) + soft_dice_loss(logits, labels)
    support_loss = balanced_binary_loss(outputs["support_logit"], support)
    cutout_domain = F.max_pool2d(support, 9, stride=1, padding=4)
    # False cutouts erase true lesion banks, so specificity receives slightly
    # more mass than sensitivity. The separate bank term still prevents the
    # trivial all-background cutout solution.
    cutout_loss = balanced_binary_loss(
        outputs["cutout_logit"], cutout, cutout_domain, positive_share=0.38
    )

    foreground = outputs["foreground_probability"]
    pred_dy, pred_dx = gradients(foreground)
    true_dy, true_dx = gradients(target_foreground)
    boundary = F.l1_loss(pred_dy, true_dy) + F.l1_loss(pred_dx, true_dx)
    notch_rim = cutout * F.max_pool2d(target_foreground, 11, stride=1, padding=5)
    lesion_banks = target_foreground * F.max_pool2d(cutout, 11, stride=1, padding=5)
    false_fill = masked_mean(foreground, notch_rim)
    false_cut = masked_mean(1.0 - foreground, lesion_banks)
    bank = 0.5 * (false_fill + false_cut)
    outside_support = 1.0 - support
    sparse = masked_mean(outputs["cutout_probability"], outside_support)
    total = segmentation + ramp * (
        args.support_weight * support_loss
        + args.cutout_weight * cutout_loss
        + args.boundary_weight * boundary
        + args.bank_weight * bank
        + args.sparse_weight * sparse
    )
    pieces = {
        "total": total,
        "segmentation": segmentation,
        "support": support_loss,
        "cutout": cutout_loss,
        "boundary": boundary,
        "bank": bank,
        "false_fill": false_fill,
        "false_cut": false_cut,
        "sparse": sparse,
    }
    return total, {key: float(value.detach()) for key, value in pieces.items()}


@torch.no_grad()
def coarse_probability(
    coarse: FrozenCoarseEnsemble,
    adapted: torch.Tensor,
    voltage: torch.Tensor,
) -> torch.Tensor:
    return torch.softmax(coarse(adapted, voltage)["logits"], dim=1)


@torch.no_grad()
def evaluate_loader(
    coarse: FrozenCoarseEnsemble,
    model: HullCutoutNet,
    adapter: InputAdapter,
    loader: DataLoader,
    device: torch.device,
    cutout_bias: float,
) -> tuple[dict[str, float], dict[str, float], dict[int, np.ndarray], dict[int, np.ndarray]]:
    coarse.eval()
    model.eval()
    coarse_rows: list[dict[str, float]] = []
    model_rows: list[dict[str, float]] = []
    coarse_predictions: dict[int, np.ndarray] = {}
    model_predictions: dict[int, np.ndarray] = {}
    for batch in loader:
        adapted = adapter(batch["image"].to(device))
        voltage = batch["voltage"].to(device)
        base_probability = coarse_probability(coarse, adapted, voltage)
        output = model(adapted, voltage, base_probability, cutout_bias=cutout_bias)
        base = base_probability.argmax(dim=1).cpu().numpy()
        prediction = output["logits"].argmax(dim=1).cpu().numpy()
        truths = batch["labels"].numpy()
        indentations = batch["indent"].numpy()[:, 0]
        indices = batch["index"].numpy()
        for offset, index in enumerate(indices):
            coarse_predictions[int(index)] = base[offset]
            model_predictions[int(index)] = prediction[offset]
            coarse_rows.append(confusion_metrics(truths[offset], base[offset], indentations[offset]))
            model_rows.append(confusion_metrics(truths[offset], prediction[offset], indentations[offset]))
    return aggregate_rows(coarse_rows), aggregate_rows(model_rows), coarse_predictions, model_predictions


def selection_score(metrics: dict[str, float]) -> float:
    return float(
        0.45 * metrics["foreground_iou"]
        + 0.25 * metrics["boundary_f1"]
        + 0.30 * metrics["concavity_score"]
    )


def train_model(
    archive: np.lib.npyio.NpzFile,
    coarse: FrozenCoarseEnsemble,
    adapter: InputAdapter,
    args: argparse.Namespace,
    output_dir: Path,
    device: torch.device,
) -> tuple[HullCutoutNet, list[dict[str, float]]]:
    train_loader = DataLoader(
        HullCutoutDataset(archive, archive["train_indices"]),
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.workers,
        pin_memory=device.type == "cuda",
        drop_last=True,
    )
    validation_loader = DataLoader(
        HullCutoutDataset(archive, archive["validation_indices"]),
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.workers,
    )
    calibration_loader = DataLoader(CalibrationDataset(archive), batch_size=4, shuffle=True, num_workers=0)
    calibration_iterator = iter(calibration_loader)
    model = HullCutoutNet(args.base_channels).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay
    )
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    checkpoint = output_dir / "hull_cutout_best.pt"
    history: list[dict[str, float]] = []
    best_score = -math.inf
    stale = 0
    for epoch in range(1, args.epochs + 1):
        model.train()
        losses: list[float] = []
        ramp = min(1.0, epoch / 10.0)
        for batch in train_loader:
            optimizer.zero_grad(set_to_none=True)
            adapted = adapter(batch["image"].to(device))
            voltage = batch["voltage"].to(device)
            labels = batch["labels"].to(device)
            prepared = {
                "labels": labels,
                "support": batch["support"].to(device),
                "cutout": batch["cutout"].to(device),
            }
            with torch.no_grad():
                base_probability = coarse_probability(coarse, adapted, voltage)
            with torch.amp.autocast("cuda", enabled=device.type == "cuda"):
                output = model(adapted, voltage, base_probability)
                loss, _ = structural_loss(output, prepared, args, ramp)
                if args.calibration_weight > 0:
                    try:
                        calibration = next(calibration_iterator)
                    except StopIteration:
                        calibration_iterator = iter(calibration_loader)
                        calibration = next(calibration_iterator)
                    cal_adapted = adapter(calibration["image"].to(device))
                    cal_voltage = calibration["voltage"].to(device)
                    with torch.no_grad():
                        cal_base = coarse_probability(coarse, cal_adapted, cal_voltage)
                    cal_prepared = {
                        "labels": calibration["labels"].to(device),
                        "support": calibration["support"].to(device),
                        "cutout": calibration["cutout"].to(device),
                    }
                    cal_output = model(cal_adapted, cal_voltage, cal_base)
                    cal_loss, _ = structural_loss(cal_output, cal_prepared, args, ramp)
                    loss = loss + args.calibration_weight * cal_loss
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            scaler.step(optimizer)
            scaler.update()
            losses.append(float(loss.detach()))

        coarse_metrics, validation, _, _ = evaluate_loader(
            coarse, model, adapter, validation_loader, device, cutout_bias=0.0
        )
        score = selection_score(validation)
        row = {
            "epoch": epoch,
            "train_loss": float(np.mean(losses)),
            "score": score,
            **{f"validation_{key}": value for key, value in validation.items()},
        }
        history.append(row)
        if epoch % args.progress_every == 0:
            print(
                f"epoch {epoch}/{args.epochs}: loss={row['train_loss']:.4f}, "
                f"IoU={validation['foreground_iou']:.4f}, boundary={validation['boundary_f1']:.4f}, "
                f"notch={validation['notch_preservation']:.4f}, joint={validation['concavity_score']:.4f}; "
                f"coarse IoU={coarse_metrics['foreground_iou']:.4f}",
                flush=True,
            )
        checkpoint_eligible = (
            validation["foreground_iou"] >= coarse_metrics["foreground_iou"] - 0.020
            and validation["boundary_f1"] >= coarse_metrics["boundary_f1"] - 0.015
        )
        if checkpoint_eligible and score > best_score + 1e-5:
            best_score = score
            stale = 0
            torch.save(
                {
                    "model": model.state_dict(),
                    "base_channels": args.base_channels,
                    "epoch": epoch,
                    "validation": validation,
                    "coarse_validation": coarse_metrics,
                    "args": vars(args) | {
                        "dataset": str(args.dataset),
                        "output_dir": str(args.output_dir),
                        "coarse_checkpoint": [str(path) for path in args.coarse_checkpoint],
                    },
                },
                checkpoint,
            )
        else:
            stale += 1
        if stale >= args.patience and checkpoint.exists():
            print(f"early stopping after {epoch} epochs", flush=True)
            break
    state = torch.load(checkpoint, map_location=device, weights_only=False)
    model.load_state_dict(state["model"])
    (output_dir / "training_history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    return model, history


@torch.no_grad()
def infer_real(
    coarse: FrozenCoarseEnsemble,
    model: HullCutoutNet,
    adapter: InputAdapter,
    images: np.ndarray,
    voltages: np.ndarray,
    device: torch.device,
    batch_size: int,
    cutout_bias: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    coarse_predictions: list[np.ndarray] = []
    model_predictions: list[np.ndarray] = []
    support_maps: list[np.ndarray] = []
    cutout_maps: list[np.ndarray] = []
    for start in range(0, len(images), batch_size):
        image = torch.from_numpy(images[start:start + batch_size, None].astype(np.float32)).to(device)
        voltage = torch.from_numpy(voltages[start:start + batch_size].astype(np.float32)).to(device)
        adapted = adapter(image)
        base_probability = coarse_probability(coarse, adapted, voltage)
        output = model(adapted, voltage, base_probability, cutout_bias=cutout_bias)
        coarse_logits = F.interpolate(torch.log(base_probability.clamp_min(1e-7)), (256, 256), mode="bilinear", align_corners=False)
        model_logits = F.interpolate(output["logits"], (256, 256), mode="bilinear", align_corners=False)
        support = F.interpolate(output["support_probability"], (256, 256), mode="bilinear", align_corners=False)
        cutout = F.interpolate(output["cutout_probability"], (256, 256), mode="bilinear", align_corners=False)
        coarse_predictions.append(coarse_logits.argmax(dim=1).cpu().numpy())
        model_predictions.append(model_logits.argmax(dim=1).cpu().numpy())
        support_maps.append(support[:, 0].cpu().numpy())
        cutout_maps.append(cutout[:, 0].cpu().numpy())
    return (
        np.concatenate(coarse_predictions),
        np.concatenate(model_predictions),
        np.concatenate(support_maps),
        np.concatenate(cutout_maps),
    )


def save_synthetic_comparison(
    path: Path,
    archive: np.lib.npyio.NpzFile,
    coarse_predictions: dict[int, np.ndarray],
    model_predictions: dict[int, np.ndarray],
) -> None:
    indices = np.asarray(archive["test_indices"], dtype=np.int64)
    indentation = archive["indentation_masks"]
    ranked = sorted(indices.tolist(), key=lambda index: int(indentation[index].sum()), reverse=True)[:8]
    figure, axes = plt.subplots(len(ranked), 3, figsize=(7.5, 2.35 * len(ranked)), squeeze=False)
    for row, index in enumerate(ranked):
        for column, (image, title) in enumerate(
            (
                (archive["labels"][index], f"truth {index}"),
                (coarse_predictions[index], "coarse fusion"),
                (model_predictions[index], "hull - cutout"),
            )
        ):
            axes[row, column].imshow(image, vmin=0, vmax=2, cmap="gray", interpolation="nearest")
            axes[row, column].set_title(title)
            axes[row, column].set_axis_off()
    figure.suptitle("Untouched synthetic test: deepest inward boundaries", fontsize=14)
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def save_structural_maps(
    path: Path,
    truths: np.ndarray,
    ids: np.ndarray,
    coarse: np.ndarray,
    prediction: np.ndarray,
    support: np.ndarray,
    cutout: np.ndarray,
) -> None:
    ranked = sorted(range(len(ids)), key=lambda index: int(indentation_mask(truths[index]).sum()), reverse=True)[:8]
    figure, axes = plt.subplots(len(ranked), 5, figsize=(12.5, 2.45 * len(ranked)), squeeze=False)
    for row, index in enumerate(ranked):
        items = (
            (truths[index], f"{ids[index]} truth", "gray", 0.0, 2.0),
            (coarse[index], "coarse", "gray", 0.0, 2.0),
            (support[index], "support p", "magma", 0.0, 1.0),
            (cutout[index], "cutout p", "magma", 0.0, 1.0),
            (prediction[index], "hull - cutout", "gray", 0.0, 2.0),
        )
        for column, (image, title, cmap, low, high) in enumerate(items):
            axes[row, column].imshow(image, cmap=cmap, vmin=low, vmax=high, interpolation="nearest")
            axes[row, column].set_title(title, fontsize=9)
            axes[row, column].set_axis_off()
    figure.suptitle("Most non-convex KTC cases: explicit support and cutout maps", fontsize=14)
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    archive = np.load(args.dataset.resolve(), allow_pickle=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    coarse, coarse_states, coarse_weights = load_coarse_ensemble(
        args.coarse_checkpoint, args.coarse_weights, device
    )
    adapter = InputAdapter(archive["fov_mask"]).to(device)
    print(
        f"device={device}; seed={args.seed}; hull-minus-cutout; coarse_weights={coarse_weights}",
        flush=True,
    )
    model, history = train_model(archive, coarse, adapter, args, output_dir, device)

    validation_loader = DataLoader(
        HullCutoutDataset(archive, archive["validation_indices"]),
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=0,
    )
    candidates: list[dict[str, object]] = []
    baseline_metrics: dict[str, float] | None = None
    for bias in (-1.50, -1.25, -1.00, -0.75, -0.50, -0.25, 0.0, 0.35, 0.75):
        coarse_metrics, metrics, _, _ = evaluate_loader(
            coarse, model, adapter, validation_loader, device, cutout_bias=bias
        )
        baseline_metrics = coarse_metrics
        eligible = (
            metrics["foreground_iou"] >= coarse_metrics["foreground_iou"] - args.iou_tolerance
            and metrics["boundary_f1"] >= coarse_metrics["boundary_f1"] - args.boundary_tolerance
            and metrics["concavity_score"] > coarse_metrics["concavity_score"]
        )
        candidates.append(
            {
                "cutout_bias": bias,
                "metrics": metrics,
                "eligible": eligible,
                "score": selection_score(metrics) if eligible else None,
            }
        )
        print(f"validation bias={bias:+.2f}: {metrics}; eligible={eligible}", flush=True)
    assert baseline_metrics is not None
    baseline_record = {
        "cutout_bias": None,
        "method": "coarse_identity",
        "metrics": baseline_metrics,
        "eligible": True,
        "score": selection_score(baseline_metrics),
    }
    eligible_candidates = [candidate for candidate in candidates if candidate["eligible"]]
    selected = max([baseline_record, *eligible_candidates], key=lambda item: float(item["score"]))
    selected_bias = selected["cutout_bias"]
    validation_selection = {
        "coarse": baseline_metrics,
        "candidates": candidates,
        "selected": selected,
        "evaluation_truth_accessed": False,
    }
    (output_dir / "validation_selection.json").write_text(
        json.dumps(validation_selection, indent=2), encoding="utf-8"
    )

    test_loader = DataLoader(
        HullCutoutDataset(archive, archive["test_indices"]),
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=0,
    )
    if selected_bias is None:
        test_coarse, test_model, coarse_test_predictions, model_test_predictions = evaluate_loader(
            coarse, model, adapter, test_loader, device, cutout_bias=0.0
        )
        test_model = test_coarse
        model_test_predictions = coarse_test_predictions
    else:
        test_coarse, test_model, coarse_test_predictions, model_test_predictions = evaluate_loader(
            coarse, model, adapter, test_loader, device, cutout_bias=float(selected_bias)
        )
    print(f"untouched synthetic test coarse: {test_coarse}", flush=True)
    print(f"untouched synthetic test selected: {test_model}", flush=True)
    save_synthetic_comparison(
        output_dir / "synthetic_test_most_concave.png", archive, coarse_test_predictions, model_test_predictions
    )

    # KTC evaluation labels are first accessed after model, bias, and fallback
    # decisions are frozen and the independent synthetic test has been scored.
    real_coarse, real_model_raw, support, cutout = infer_real(
        coarse,
        model,
        adapter,
        archive["real_linear_images"],
        archive["real_voltages"],
        device,
        args.batch_size,
        0.0 if selected_bias is None else float(selected_bias),
    )
    real_model = real_coarse if selected_bias is None else real_model_raw
    real_truths = archive["real_labels"]
    real_ids = archive["real_ids"]
    real_predictions = {"coarse_fusion": real_coarse, "hull_cutout": real_model}
    real_summary: dict[str, dict[str, float]] = {}
    real_rows: list[dict[str, object]] = []
    for name, predictions in real_predictions.items():
        real_summary[name], rows = evaluate_real_predictions(name, predictions, real_truths, real_ids)
        real_rows.extend(rows)
        print(f"real 21 {name}: {real_summary[name]}", flush=True)
    write_rows(output_dir / "real_case_metrics.csv", real_rows)
    save_real_montage(
        output_dir / "real_all_21_comparison.png", real_truths, real_ids, real_predictions, real_rows
    )
    save_focus_montage(
        output_dir / "real_most_concave_comparison.png", real_truths, real_ids, real_predictions, real_rows
    )
    save_structural_maps(
        output_dir / "real_structural_maps.png",
        real_truths,
        real_ids,
        real_coarse,
        real_model,
        support,
        cutout,
    )
    np.savez_compressed(
        output_dir / "predictions_and_maps.npz",
        real_coarse=real_coarse,
        real_hull_cutout=real_model,
        support_probability=support,
        cutout_probability=cutout,
    )
    summary = {
        "method": "explicit per-instance hull support minus learned background cutout",
        "dataset": str(args.dataset.resolve()),
        "device": str(device),
        "seed": args.seed,
        "coarse_checkpoints": [str(path.resolve()) for path in args.coarse_checkpoint],
        "coarse_weights": coarse_weights,
        "coarse_epochs": [state.get("epoch") for state in coarse_states],
        "validation_selection": validation_selection,
        "synthetic_untouched_test": {"coarse_fusion": test_coarse, "hull_cutout": test_model},
        "real_evaluation": real_summary,
        "evaluation_truth_used_for_training_or_selection": False,
        "selected_cutout_bias": selected_bias,
        "fallback_to_coarse": selected_bias is None,
        "args": vars(args) | {
            "dataset": str(args.dataset),
            "output_dir": str(args.output_dir),
            "coarse_checkpoint": [str(path) for path in args.coarse_checkpoint],
        },
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
