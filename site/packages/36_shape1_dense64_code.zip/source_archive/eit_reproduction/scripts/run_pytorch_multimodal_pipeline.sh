#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_ROOT"

python train_pytorch_multimodal_eit.py --epochs "${EIT_EPOCHS:-20}" --batch-size "${EIT_BATCH_SIZE:-32}" --output-dir outputs_pytorch_multimodal
python infer_public_us_eit.py
python scripts/validate_pytorch_multimodal.py
python -m unittest discover -s tests -p 'test_pytorch_multimodal.py' -v

