"""Summarize matched-seed topology-risk EIT ablations after frozen routing."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


MODELS = ("full_v4", "no_risk", "no_physics", "no_explicit_topology")
METHODS = ("direct_base", "topology_residual", "topology_routed")
METRICS = ("foreground_iou", "foreground_dice", "boundary_f1", "notch_preservation", "bank_retention")


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", nargs="+", required=True, help="model=router_directory")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--bootstrap", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260918)
    parser.add_argument(
        "--audit", type=Path,
        default=root / "outputs" / "ktc2023_full_audit" / "summary.json",
    )
    return parser.parse_args()


def parse_runs(values: list[str]) -> dict[str, Path]:
    result: dict[str, Path] = {}
    for value in values:
        if "=" not in value:
            raise ValueError(f"expected model=directory, got {value!r}")
        name, raw_path = value.split("=", 1)
        path = Path(raw_path).resolve()
        for filename in ("action_router_summary.json", "action_router_case_metrics.csv"):
            if not (path / filename).is_file():
                raise FileNotFoundError(path / filename)
        result[name] = path
    missing = set(MODELS) - result.keys()
    if missing:
        raise ValueError(f"missing ablations: {sorted(missing)}")
    return result


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def truthy(value: str) -> bool:
    normalized = value.strip().lower()
    if normalized in {"true", "yes"}:
        return True
    if normalized in {"false", "no", ""}:
        return False
    return float(normalized) > 0.5


def build_groups(rows: list[dict[str, str]], strict_ids: set[str]) -> dict[str, list[str]]:
    reference = [row for row in rows if row["method"] == "direct_base"]
    groups: dict[str, list[str]] = {}
    for partition in ("base", "biological", "stress"):
        selected = [row for row in reference if row["group"] == partition]
        groups[f"{partition}_concave"] = sorted(
            row["id"] for row in selected if truthy(row["has_cutout"])
        )
        groups[f"{partition}_ordinary"] = sorted(
            row["id"] for row in selected if not truthy(row["has_cutout"])
        )
    public = sorted(row["id"] for row in reference if row["group"] == "public_ktc")
    groups["public_ktc_nonconvex"] = sorted(set(public) & strict_ids)
    groups["public_ktc_ordinary"] = sorted(set(public) - strict_ids)
    return {name: ids for name, ids in groups.items() if ids}


def lookup(rows: list[dict[str, str]]) -> dict[tuple[str, str], dict[str, str]]:
    selected = [row for row in rows if row["method"] in METHODS]
    result = {(row["id"], row["method"]): row for row in selected}
    if len(result) != len(selected):
        raise ValueError("duplicate case/method rows")
    return result


def values(
    table: dict[tuple[str, str], dict[str, str]], ids: list[str], method: str, metric: str
) -> np.ndarray:
    result = np.full(len(ids), np.nan)
    for index, case_id in enumerate(ids):
        raw = table[(case_id, method)].get(metric, "")
        if raw not in (None, "", "nan", "NaN"):
            result[index] = float(raw)
    return result


def paired_bootstrap(
    difference: np.ndarray, repetitions: int, rng: np.random.Generator
) -> dict[str, float] | None:
    difference = difference[np.isfinite(difference)]
    if not difference.size:
        return None
    draws = difference[rng.integers(difference.size, size=(repetitions, difference.size))].mean(axis=1)
    return {
        "cases": int(difference.size),
        "mean_difference": float(difference.mean()),
        "ci95_low": float(np.percentile(draws, 2.5)),
        "ci95_high": float(np.percentile(draws, 97.5)),
        "probability_positive": float(np.mean(draws > 0)),
    }


def tail(difference: np.ndarray) -> dict[str, float]:
    difference = difference[np.isfinite(difference)]
    return {
        "mean": float(difference.mean()),
        "minimum": float(difference.min()),
        "fraction_below_minus_0_01": float(np.mean(difference < -0.01)),
    }


def summarize(
    tables: dict[str, dict[tuple[str, str], dict[str, str]]],
    groups: dict[str, list[str]],
    repetitions: int,
    seed: int,
) -> dict[str, object]:
    rng = np.random.default_rng(seed)
    result: dict[str, object] = {}
    for group_name, ids in groups.items():
        statistics: dict[str, object] = {}
        arrays: dict[tuple[str, str, str], np.ndarray] = {}
        for model in MODELS:
            statistics[model] = {}
            for method in METHODS:
                statistics[model][method] = {}
                for metric in METRICS:
                    current = values(tables[model], ids, method, metric)
                    arrays[(model, method, metric)] = current
                    if np.isfinite(current).any():
                        statistics[model][method][metric] = float(np.nanmean(current))

        effects: dict[str, object] = {}
        for model in MODELS:
            effects[model] = {
                "routed_minus_direct": {
                    metric: value
                    for metric in METRICS
                    if (
                        value := paired_bootstrap(
                            arrays[(model, "topology_routed", metric)]
                            - arrays[(model, "direct_base", metric)],
                            repetitions,
                            rng,
                        )
                    ) is not None
                }
            }
            if model != "full_v4":
                effects[model]["routed_minus_full_v4_routed"] = {
                    metric: value
                    for metric in METRICS
                    if (
                        value := paired_bootstrap(
                            arrays[(model, "topology_routed", metric)]
                            - arrays[("full_v4", "topology_routed", metric)],
                            repetitions,
                            rng,
                        )
                    ) is not None
                }
        tails = {
            model: tail(
                arrays[(model, "topology_routed", "foreground_iou")]
                - arrays[(model, "direct_base", "foreground_iou")]
            )
            for model in MODELS
        }
        result[group_name] = {
            "case_count": len(ids),
            "statistics": statistics,
            "effects": effects,
            "routed_iou_tail_vs_own_direct": tails,
        }
    return result


def write_table(path: Path, groups: dict[str, object]) -> None:
    selected = (
        "biological_concave", "biological_ordinary", "stress_concave",
        "public_ktc_nonconvex", "public_ktc_ordinary",
    )
    rows: list[dict[str, object]] = []
    for group_name in selected:
        group = groups[group_name]
        for model in MODELS:
            stats = group["statistics"][model]["topology_routed"]
            effect = group["effects"][model]["routed_minus_direct"]
            rows.append(
                {
                    "group": group_name,
                    "cases": group["case_count"],
                    "model": model,
                    "routed_iou": stats["foreground_iou"],
                    "routed_boundary_f1": stats["boundary_f1"],
                    "routed_notch": stats.get("notch_preservation", ""),
                    "notch_delta_vs_own_direct": effect.get("notch_preservation", {}).get("mean_difference", ""),
                    "iou_delta_vs_own_direct": effect["foreground_iou"]["mean_difference"],
                    "fraction_iou_below_own_direct_by_0p01": group["routed_iou_tail_vs_own_direct"][model]["fraction_below_minus_0_01"],
                }
            )
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def plot_ablation(path: Path, groups: dict[str, object]) -> None:
    selected = ("biological_concave", "stress_concave", "public_ktc_nonconvex")
    colors = ("#1b8a5a", "#d69b2d", "#3577ad", "#a64b63")
    figure, axes = plt.subplots(3, 2, figsize=(13.0, 10.0), squeeze=False)
    for row_index, group_name in enumerate(selected):
        group = groups[group_name]
        for column, metric in enumerate(("foreground_iou", "notch_preservation")):
            axis = axes[row_index, column]
            direct = np.asarray([
                group["statistics"][model]["direct_base"][metric] for model in MODELS
            ])
            routed = np.asarray([
                group["statistics"][model]["topology_routed"][metric] for model in MODELS
            ])
            positions = np.arange(len(MODELS))
            axis.bar(positions - 0.18, direct, 0.36, color="#777777", label="direct")
            axis.bar(positions + 0.18, routed, 0.36, color=colors, label="routed")
            axis.set_xticks(positions, [value.replace("_", "\n") for value in MODELS])
            axis.set_title(f"{group_name.replace('_', ' ')}: {metric.replace('_', ' ')}")
            axis.grid(axis="y", alpha=0.2)
    axes[0, 1].legend(frameon=False)
    figure.suptitle("Matched-seed ablation of risk, physics, and explicit topology supervision")
    figure.tight_layout()
    figure.savefig(path, dpi=240)
    plt.close(figure)


def plot_ordinary_tail(path: Path, groups: dict[str, object]) -> None:
    selected = ("biological_ordinary", "public_ktc_ordinary")
    figure, axes = plt.subplots(1, 2, figsize=(12.5, 4.6), squeeze=False)
    for axis, group_name in zip(axes[0], selected):
        tail_values = groups[group_name]["routed_iou_tail_vs_own_direct"]
        mean = [tail_values[model]["mean"] for model in MODELS]
        minimum = [tail_values[model]["minimum"] for model in MODELS]
        fraction = [tail_values[model]["fraction_below_minus_0_01"] for model in MODELS]
        positions = np.arange(len(MODELS))
        width = 0.25
        axis.bar(positions - width, mean, width, label="mean IoU delta", color="#3577ad")
        axis.bar(positions, minimum, width, label="worst IoU delta", color="#a64b63")
        axis.bar(positions + width, fraction, width, label="fraction < -0.01", color="#d69b2d")
        axis.axhline(0, color="#222222", linewidth=0.9)
        axis.set_xticks(positions, [value.replace("_", "\n") for value in MODELS])
        axis.set_title(group_name.replace("_", " "))
        axis.grid(axis="y", alpha=0.2)
    axes[0, 1].legend(frameon=False)
    figure.suptitle("Ordinary-case safety of matched-seed ablations")
    figure.tight_layout()
    figure.savefig(path, dpi=240)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    runs = parse_runs(args.runs)
    rows = {
        model: read_rows(path / "action_router_case_metrics.csv")
        for model, path in runs.items()
    }
    summaries = {
        model: json.loads((path / "action_router_summary.json").read_text(encoding="utf-8"))
        for model, path in runs.items()
    }
    audit = json.loads(args.audit.resolve().read_text(encoding="utf-8"))
    strict_ids = {str(value) for value in audit["nonconvex_ids"]}
    groups_spec = build_groups(rows["full_v4"], strict_ids)
    tables = {model: lookup(model_rows) for model, model_rows in rows.items()}
    groups = summarize(tables, groups_spec, args.bootstrap, args.seed)
    result = {
        "models": list(MODELS),
        "runs": {model: str(path) for model, path in runs.items()},
        "validation_selected_router_thresholds": {
            model: float(summary["threshold"]) for model, summary in summaries.items()
        },
        "groups": groups,
        "bootstrap_repetitions": args.bootstrap,
        "bootstrap_design": "paired resampling of fixed cases for the matched training seed",
        "public_truth_used_for_training_checkpoint_or_router_selection": False,
        "interpretation_limit": "ablations use one matched random seed; the full model main effect uses four seeds",
    }
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "ablation_summary.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    write_table(output_dir / "ablation_paper_table.csv", groups)
    plot_ablation(output_dir / "ablation_concavity_metrics.png", groups)
    plot_ordinary_tail(output_dir / "ablation_ordinary_tail.png", groups)
    print(
        json.dumps(
            {
                "thresholds": result["validation_selected_router_thresholds"],
                "output_dir": str(output_dir),
            },
            indent=2,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
