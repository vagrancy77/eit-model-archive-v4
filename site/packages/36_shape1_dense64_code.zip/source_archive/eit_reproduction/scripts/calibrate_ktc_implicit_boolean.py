"""Calibrate the frozen implicit-Boolean EIT model without touching test truth.

The V1 network has enough capacity to recover deep inward cavities, but its
default Boolean cutout is too aggressive.  This script exposes three global
structural controls, freezes them using only the ordinary and deep-concavity
validation splits, and then performs one final evaluation on both synthetic
test splits and all 21 public KTC2023 cases.
"""
from __future__ import annotations

import argparse
import csv
import json
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F

from prepare_ktc_deep_concavity_stress import FAMILIES
from train_ktc_concavity_network import (
    InputAdapter,
    save_focus_montage,
    save_real_montage,
    write_rows,
)
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_highres_refiner import load_coarse_ensemble
from train_ktc_implicit_boolean_network import (
    ImplicitBooleanNet,
    prepare_structural_arrays,
    standard_metrics,
    stress_metrics,
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument(
        "--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz"
    )
    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=root / "outputs" / "ktc_implicit_boolean_seed20260829" / "implicit_boolean_best.pt",
    )
    parser.add_argument(
        "--coarse-checkpoint",
        nargs="+",
        type=Path,
        default=[
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "boundary_best.pt",
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "indent_best.pt",
            root / "outputs" / "ktc_concavity_voltage_seed20260819" / "voltage_best.pt",
        ],
    )
    parser.add_argument("--coarse-weights", nargs="+", type=float, default=[0.30, 0.40, 0.30])
    parser.add_argument(
        "--output-dir", type=Path, default=root / "outputs" / "ktc_implicit_boolean_calibrated_seed20260829"
    )
    parser.add_argument("--batch-size", type=int, default=24)
    parser.add_argument("--base-iou-tolerance", type=float, default=0.0075)
    parser.add_argument("--base-boundary-tolerance", type=float, default=0.005)
    parser.add_argument("--stress-iou-tolerance", type=float, default=0.015)
    parser.add_argument("--min-bank-retention", type=float, default=0.82)
    parser.add_argument(
        "--selection-objective",
        choices=("structural", "topology"),
        default="structural",
        help="Topology selects by open-cutout joint score after applying the validation constraints.",
    )
    return parser.parse_args()


@dataclass
class RawFields:
    coarse_prediction: np.ndarray
    coarse_probability: np.ndarray
    coarse_field: np.ndarray
    support_residual: np.ndarray
    cutout_residual: np.ndarray
    polarity: np.ndarray


@torch.no_grad()
def collect_raw_fields(
    images: np.ndarray,
    voltages: np.ndarray,
    coarse: torch.nn.Module,
    model: ImplicitBooleanNet,
    adapter: InputAdapter,
    device: torch.device,
    batch_size: int,
) -> RawFields:
    collected: dict[str, list[np.ndarray]] = {
        "coarse_prediction": [],
        "coarse_probability": [],
        "coarse_field": [],
        "support_residual": [],
        "cutout_residual": [],
        "polarity": [],
    }
    model.eval()
    for start in range(0, len(images), batch_size):
        image = torch.from_numpy(images[start : start + batch_size, None].astype(np.float32)).to(device)
        voltage = torch.from_numpy(voltages[start : start + batch_size].astype(np.float32)).to(device)
        adapted = adapter(image)
        coarse_probability = torch.softmax(coarse(adapted, voltage)["logits"], dim=1)
        output = model(adapted, voltage, coarse_probability)
        collected["coarse_prediction"].append(coarse_probability.argmax(dim=1).cpu().numpy().astype(np.uint8))
        collected["coarse_probability"].append(coarse_probability.float().cpu().numpy())
        for key in ("coarse_field", "support_residual", "cutout_residual"):
            collected[key].append(output[key][:, 0].float().cpu().numpy())
        collected["polarity"].append(output["polarity_probability"].float().cpu().numpy())
    return RawFields(**{key: np.concatenate(value) for key, value in collected.items()})


def predict_from_fields(
    fields: RawFields,
    cutout_bias: float,
    support_scale: float,
    cutout_scale: float,
    output_size: int | None = None,
) -> np.ndarray:
    support_field = 0.55 * fields.coarse_field + support_scale * fields.support_residual
    cutout_field = cutout_bias + cutout_scale * fields.cutout_residual
    support = 1.0 / (1.0 + np.exp(-np.clip(support_field / 0.36, -30.0, 30.0)))
    cutout = 1.0 / (1.0 + np.exp(-np.clip(cutout_field / 0.36, -30.0, 30.0)))
    foreground = np.clip(support * (1.0 - cutout), 1e-6, 1.0 - 1e-6)
    probabilities = np.concatenate(
        (
            (1.0 - foreground)[:, None],
            foreground[:, None] * fields.polarity,
        ),
        axis=1,
    ).astype(np.float32)
    logits = torch.from_numpy(np.log(np.clip(probabilities, 1e-7, None)))
    if output_size is not None and logits.shape[-1] != output_size:
        logits = F.interpolate(logits, size=(output_size, output_size), mode="bilinear", align_corners=False)
    return logits.argmax(dim=1).numpy().astype(np.uint8)


def write_grid(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def save_stress_comparison(
    path: Path,
    truths: np.ndarray,
    coarse: np.ndarray,
    original: np.ndarray,
    calibrated: np.ndarray,
    cutouts: np.ndarray,
    family_codes: np.ndarray,
) -> None:
    indices = [
        next((index for index, value in enumerate(family_codes) if int(value) == code), None)
        for code in range(len(FAMILIES))
    ]
    indices = [index for index in indices if index is not None]
    figure, axes = plt.subplots(len(indices), 5, figsize=(13.0, 2.35 * len(indices)), squeeze=False)
    for row, index in enumerate(indices):
        images = (
            (truths[index], f"{FAMILIES[int(family_codes[index])]} truth"),
            (coarse[index], "coarse EIT"),
            (original[index], "V1 default"),
            (calibrated[index], "calibrated Boolean"),
            (cutouts[index], "true inward cutout"),
        )
        for column, (image, title) in enumerate(images):
            axes[row, column].imshow(image, cmap="viridis", vmin=0, vmax=2, interpolation="nearest")
            axes[row, column].set_title(title)
            axes[row, column].set_axis_off()
    figure.suptitle("Independent nonlinear-CEM deep-concavity stress test")
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def save_base_examples(
    path: Path,
    truths: np.ndarray,
    coarse: np.ndarray,
    original: np.ndarray,
    calibrated: np.ndarray,
    indentations: np.ndarray,
) -> None:
    rows = []
    for index, (truth, base, old, new, indent) in enumerate(
        zip(truths, coarse, original, calibrated, indentations)
    ):
        old_metric = standard_metrics(truth[None], old[None], indent[None])
        new_metric = standard_metrics(truth[None], new[None], indent[None])
        rows.append((new_metric["concavity_score"] - old_metric["concavity_score"], index))
    chosen = [index for _, index in sorted(rows, reverse=True)[:4]]
    chosen += [index for _, index in sorted(rows)[:4] if index not in chosen]
    figure, axes = plt.subplots(len(chosen), 4, figsize=(10.5, 2.5 * len(chosen)), squeeze=False)
    for row, index in enumerate(chosen):
        for column, (image, title) in enumerate(
            (
                (truths[index], "truth"),
                (coarse[index], "coarse EIT"),
                (original[index], "V1 default"),
                (calibrated[index], "calibrated Boolean"),
            )
        ):
            axes[row, column].imshow(image, cmap="viridis", vmin=0, vmax=2, interpolation="nearest")
            axes[row, column].set_title(title)
            axes[row, column].set_axis_off()
    figure.suptitle("Ordinary independent test: largest gains and losses after calibration")
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    base_archive = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress_archive = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    base_arrays = prepare_structural_arrays(base_archive, "base nonlinear CEM")
    stress_arrays = prepare_structural_arrays(stress_archive, "deep-concavity stress")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    coarse, _, coarse_weights = load_coarse_ensemble(args.coarse_checkpoint, args.coarse_weights, device)
    state = torch.load(args.checkpoint.resolve(), map_location=device, weights_only=False)
    model = ImplicitBooleanNet(int(state["base_channels"])).to(device)
    model.load_state_dict(state["model"], strict=False)
    model.use_external_connectivity = bool(state.get("external_connectivity", False))
    model.connectivity_steps = int(state.get("connectivity_steps", 28))
    model.eval()
    adapter = InputAdapter(base_archive["fov_mask"]).to(device)

    base_validation_indices = np.asarray(base_archive["validation_indices"], dtype=np.int64)
    stress_validation_indices = np.asarray(stress_archive["validation_indices"], dtype=np.int64)
    print(f"device={device}; collecting untouched validation fields", flush=True)
    base_validation_fields = collect_raw_fields(
        base_arrays.images[base_validation_indices], base_arrays.voltages[base_validation_indices],
        coarse, model, adapter, device, args.batch_size,
    )
    stress_validation_fields = collect_raw_fields(
        stress_arrays.images[stress_validation_indices], stress_arrays.voltages[stress_validation_indices],
        coarse, model, adapter, device, args.batch_size,
    )
    base_coarse_validation = standard_metrics(
        base_arrays.labels[base_validation_indices], base_validation_fields.coarse_prediction,
        base_arrays.indentation[base_validation_indices],
    )
    stress_coarse_validation, _, _ = stress_metrics(
        stress_arrays.labels[stress_validation_indices], stress_validation_fields.coarse_prediction,
        stress_arrays.cutout[stress_validation_indices], stress_arrays.cutout_depth[stress_validation_indices],
        stress_arrays.family_codes[stress_validation_indices],
    )

    biases = [-2.75, -2.50, -2.25, -2.00, -1.75, -1.50, -1.25]
    support_scales = [0.35, 0.50, 0.65, 0.80, 1.00]
    cutout_scales = [0.40, 0.55, 0.70, 0.85, 1.00]
    grid_rows: list[dict[str, object]] = []
    for bias in biases:
        for support_scale in support_scales:
            for cutout_scale in cutout_scales:
                base_prediction = predict_from_fields(base_validation_fields, bias, support_scale, cutout_scale)
                stress_prediction = predict_from_fields(stress_validation_fields, bias, support_scale, cutout_scale)
                base_metric = standard_metrics(
                    base_arrays.labels[base_validation_indices], base_prediction,
                    base_arrays.indentation[base_validation_indices],
                )
                stress_metric, _, _ = stress_metrics(
                    stress_arrays.labels[stress_validation_indices], stress_prediction,
                    stress_arrays.cutout[stress_validation_indices], stress_arrays.cutout_depth[stress_validation_indices],
                    stress_arrays.family_codes[stress_validation_indices],
                )
                eligible = (
                    base_metric["foreground_iou"] >= base_coarse_validation["foreground_iou"] - args.base_iou_tolerance
                    and base_metric["boundary_f1"] >= base_coarse_validation["boundary_f1"] - args.base_boundary_tolerance
                    and stress_metric["foreground_iou"] >= stress_coarse_validation["foreground_iou"] - args.stress_iou_tolerance
                    and stress_metric["bank_retention"] >= args.min_bank_retention
                )
                grid_rows.append(
                    {
                        "cutout_bias": bias,
                        "support_scale": support_scale,
                        "cutout_scale": cutout_scale,
                        "eligible": bool(eligible),
                        "base_iou": base_metric["foreground_iou"],
                        "base_boundary_f1": base_metric["boundary_f1"],
                        "stress_iou": stress_metric["foreground_iou"],
                        "stress_boundary_f1": stress_metric["boundary_f1"],
                        "stress_deep_cutout": stress_metric["deep_cutout_recovery"],
                        "stress_open_deep_cutout": stress_metric["open_deep_cutout_recovery"],
                        "stress_bank_retention": stress_metric["bank_retention"],
                        "stress_structural_joint": stress_metric["structural_joint"],
                        "stress_topology_joint": stress_metric["topology_structural_joint"],
                    }
                )
    eligible_rows = [row for row in grid_rows if row["eligible"]]
    if eligible_rows:
        joint_key = (
            "stress_topology_joint" if args.selection_objective == "topology" else "stress_structural_joint"
        )
        cutout_key = (
            "stress_open_deep_cutout" if args.selection_objective == "topology" else "stress_deep_cutout"
        )
        selected = max(
            eligible_rows,
            key=lambda row: (row[joint_key], row[cutout_key], row["base_iou"]),
        )
        selection_status = "hard_constraints_satisfied"
    else:
        selected = max(
            grid_rows,
            key=lambda row: (
                min(0.0, row["base_iou"] - (base_coarse_validation["foreground_iou"] - args.base_iou_tolerance))
                + min(0.0, row["base_boundary_f1"] - (base_coarse_validation["boundary_f1"] - args.base_boundary_tolerance))
                + min(0.0, row["stress_iou"] - (stress_coarse_validation["foreground_iou"] - args.stress_iou_tolerance))
                + min(0.0, row["stress_bank_retention"] - args.min_bank_retention),
                row["stress_structural_joint"],
            ),
        )
        selection_status = "no_candidate_satisfied_all_hard_constraints"
    write_grid(output_dir / "validation_grid.csv", grid_rows)
    print(f"eligible={len(eligible_rows)}/{len(grid_rows)}; selected={selected}", flush=True)

    # No test or public truth is accessed before this point.
    bias = float(selected["cutout_bias"])
    support_scale = float(selected["support_scale"])
    cutout_scale = float(selected["cutout_scale"])
    base_test_indices = np.asarray(base_archive["test_indices"], dtype=np.int64)
    stress_test_indices = np.asarray(stress_archive["test_indices"], dtype=np.int64)
    base_test_fields = collect_raw_fields(
        base_arrays.images[base_test_indices], base_arrays.voltages[base_test_indices],
        coarse, model, adapter, device, args.batch_size,
    )
    stress_test_fields = collect_raw_fields(
        stress_arrays.images[stress_test_indices], stress_arrays.voltages[stress_test_indices],
        coarse, model, adapter, device, args.batch_size,
    )
    base_original = predict_from_fields(base_test_fields, -1.25, 1.0, 1.0)
    base_calibrated = predict_from_fields(base_test_fields, bias, support_scale, cutout_scale)
    stress_original = predict_from_fields(stress_test_fields, -1.25, 1.0, 1.0)
    stress_calibrated = predict_from_fields(stress_test_fields, bias, support_scale, cutout_scale)
    base_test_summary = {
        "coarse_fusion": standard_metrics(
            base_arrays.labels[base_test_indices], base_test_fields.coarse_prediction,
            base_arrays.indentation[base_test_indices],
        ),
        "implicit_boolean_v1": standard_metrics(
            base_arrays.labels[base_test_indices], base_original, base_arrays.indentation[base_test_indices],
        ),
        "calibrated_boolean": standard_metrics(
            base_arrays.labels[base_test_indices], base_calibrated, base_arrays.indentation[base_test_indices],
        ),
    }
    stress_test_summary: dict[str, dict[str, float]] = {}
    stress_by_family: dict[str, dict[str, dict[str, float]]] = {}
    for name, prediction in (
        ("coarse_fusion", stress_test_fields.coarse_prediction),
        ("implicit_boolean_v1", stress_original),
        ("calibrated_boolean", stress_calibrated),
    ):
        summary, family, _ = stress_metrics(
            stress_arrays.labels[stress_test_indices], prediction,
            stress_arrays.cutout[stress_test_indices], stress_arrays.cutout_depth[stress_test_indices],
            stress_arrays.family_codes[stress_test_indices],
        )
        stress_test_summary[name] = summary
        stress_by_family[name] = family

    real_fields = collect_raw_fields(
        base_archive["real_linear_images"], base_archive["real_voltages"],
        coarse, model, adapter, device, args.batch_size,
    )
    real_original = predict_from_fields(real_fields, -1.25, 1.0, 1.0, output_size=256)
    real_calibrated = predict_from_fields(real_fields, bias, support_scale, cutout_scale, output_size=256)
    real_coarse_logits = torch.from_numpy(np.log(np.clip(real_fields.coarse_probability, 1e-7, None)))
    real_coarse = F.interpolate(
        real_coarse_logits, size=(256, 256), mode="bilinear", align_corners=False
    ).argmax(dim=1).numpy().astype(np.uint8)
    real_truths = base_archive["real_labels"]
    real_ids = base_archive["real_ids"]
    real_summary: dict[str, dict[str, float]] = {}
    real_rows: list[dict[str, object]] = []
    real_predictions = {
        "coarse_fusion": real_coarse,
        "implicit_boolean_v1": real_original,
        "calibrated_boolean": real_calibrated,
    }
    for name, prediction in real_predictions.items():
        real_summary[name], rows = evaluate_real_predictions(name, prediction, real_truths, real_ids)
        real_rows.extend(rows)
    write_rows(output_dir / "real_case_metrics.csv", real_rows)

    save_stress_comparison(
        output_dir / "stress_test_comparison.png",
        stress_arrays.labels[stress_test_indices], stress_test_fields.coarse_prediction,
        stress_original, stress_calibrated, stress_arrays.cutout[stress_test_indices],
        stress_arrays.family_codes[stress_test_indices],
    )
    save_base_examples(
        output_dir / "base_test_gains_and_losses.png",
        base_arrays.labels[base_test_indices], base_test_fields.coarse_prediction,
        base_original, base_calibrated, base_arrays.indentation[base_test_indices],
    )
    save_real_montage(
        output_dir / "real_all_21_comparison.png", real_truths, real_ids, real_predictions, real_rows
    )
    save_focus_montage(
        output_dir / "real_most_concave_comparison.png", real_truths, real_ids, real_predictions, real_rows
    )
    np.savez_compressed(
        output_dir / "predictions.npz",
        base_test_indices=base_test_indices,
        base_coarse=base_test_fields.coarse_prediction,
        base_v1=base_original,
        base_calibrated=base_calibrated,
        stress_test_indices=stress_test_indices,
        stress_coarse=stress_test_fields.coarse_prediction,
        stress_v1=stress_original,
        stress_calibrated=stress_calibrated,
        real_coarse=real_coarse,
        real_v1=real_original,
        real_calibrated=real_calibrated,
    )
    result = {
        "method": "validation-calibrated implicit Boolean support-minus-cutout network",
        "selection_status": selection_status,
        "eligible_candidates": len(eligible_rows),
        "grid_candidates": len(grid_rows),
        "selected_parameters": {
            "cutout_bias": bias,
            "support_residual_scale": support_scale,
            "cutout_residual_scale": cutout_scale,
        },
        "hard_constraints": {
            "base_iou_tolerance": args.base_iou_tolerance,
            "base_boundary_tolerance": args.base_boundary_tolerance,
            "stress_iou_tolerance": args.stress_iou_tolerance,
            "min_bank_retention": args.min_bank_retention,
        },
        "validation": {
            "coarse_base": base_coarse_validation,
            "coarse_stress": stress_coarse_validation,
            "selected": selected,
        },
        "base_synthetic_untouched_test": base_test_summary,
        "deep_concavity_stress_untouched_test": stress_test_summary,
        "stress_by_family": stress_by_family,
        "real_evaluation": real_summary,
        "evaluation_truth_used_for_training_or_selection": False,
        "checkpoint": str(args.checkpoint.resolve()),
        "coarse_checkpoints": [str(path.resolve()) for path in args.coarse_checkpoint],
        "coarse_weights": coarse_weights,
        "device": str(device),
    }
    (output_dir / "summary.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
