"""Build a KTC-geometry synthetic dataset for non-convex EIT reconstruction.

The public KTC evaluation ground truths are exported only as an untouched
real-test split. Synthetic training masks are generated independently and
projected through the KTC Jacobian. This prevents evaluation-truth leakage.
"""
from __future__ import annotations

import argparse
import json
import os
import random
import sys
from pathlib import Path

import numpy as np
import scipy.io as sio
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.path import Path as PolygonPath
from PIL import Image, ImageDraw
from scipy.ndimage import distance_transform_edt, label as connected_components
from scipy.spatial import ConvexHull, QhullError, cKDTree

os.environ.setdefault("CUDA_VISIBLE_DEVICES", "0")
import torch


SHAPE_NAMES = (
    "circle", "ellipse", "rectangle", "triangle", "capsule", "star",
    "cross", "crescent", "c_shape", "u_shape", "l_shape", "heart",
    "kidney", "lobed", "random_polygon",
)
SHAPE_TO_CODE = {name: index for index, name in enumerate(SHAPE_NAMES)}


def rotate(x: np.ndarray, y: np.ndarray, angle: float) -> tuple[np.ndarray, np.ndarray]:
    cosine, sine = np.cos(angle), np.sin(angle)
    return cosine * x + sine * y, -sine * x + cosine * y


def polygon_mask(x: np.ndarray, y: np.ndarray, vertices: np.ndarray) -> np.ndarray:
    return PolygonPath(vertices).contains_points(np.column_stack((x.ravel(), y.ravel()))).reshape(x.shape)


def draw_shape(kind: str, x: np.ndarray, y: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    size_x = float(rng.uniform(0.13, 0.34))
    size_y = float(rng.uniform(0.11, 0.31))
    radius_limit = max(0.10, 0.82 - max(size_x, size_y))
    center_radius = radius_limit * np.sqrt(float(rng.uniform()))
    center_angle = float(rng.uniform(-np.pi, np.pi))
    cx, cy = center_radius * np.cos(center_angle), center_radius * np.sin(center_angle)
    angle = float(rng.uniform(-np.pi, np.pi))
    lx, ly = rotate(x - cx, y - cy, angle)

    if kind == "circle":
        radius = min(size_x, size_y)
        return lx * lx + ly * ly <= radius * radius
    if kind == "ellipse":
        return (lx / size_x) ** 2 + (ly / size_y) ** 2 <= 1.0
    if kind == "rectangle":
        return (np.abs(lx) <= size_x) & (np.abs(ly) <= size_y)
    if kind == "triangle":
        vertices = np.asarray([[0, size_y], [-size_x, -size_y], [size_x, -size_y]])
        return polygon_mask(lx, ly, vertices)
    if kind == "capsule":
        radius = min(size_y, size_x * 0.45)
        half = max(size_x - radius, 0.0)
        return ((np.abs(lx) <= half) & (np.abs(ly) <= radius)) | ((np.abs(lx) - half).clip(0) ** 2 + ly**2 <= radius**2)
    if kind == "star":
        theta = np.arctan2(ly, lx)
        radius = np.hypot(lx / max(size_x, 1e-6), ly / max(size_y, 1e-6))
        points = int(rng.integers(4, 8))
        boundary = 0.68 + float(rng.uniform(0.20, 0.34)) * np.cos(points * theta)
        return radius <= boundary
    if kind == "cross":
        arm = float(rng.uniform(0.25, 0.43))
        return ((np.abs(lx) <= size_x * arm) & (np.abs(ly) <= size_y)) | ((np.abs(lx) <= size_x) & (np.abs(ly) <= size_y * arm))
    if kind == "crescent":
        outer = (lx / size_x) ** 2 + (ly / size_y) ** 2 <= 1.0
        shift = float(rng.uniform(0.32, 0.62)) * size_x
        inner = ((lx - shift) / (size_x * 0.82)) ** 2 + (ly / (size_y * 0.88)) ** 2 <= 1.0
        return outer & ~inner
    if kind == "c_shape":
        radius = np.hypot(lx / size_x, ly / size_y)
        theta = np.arctan2(ly, lx)
        gap = float(rng.uniform(0.42, 0.78))
        return (radius <= 1.0) & (radius >= float(rng.uniform(0.43, 0.62))) & (np.abs(theta) >= gap)
    if kind == "u_shape":
        outer = (np.abs(lx) <= size_x) & (np.abs(ly) <= size_y)
        wall = float(rng.uniform(0.28, 0.43))
        inner = (np.abs(lx) < size_x * (1.0 - wall)) & (ly > -size_y * (1.0 - wall))
        return outer & ~inner
    if kind == "l_shape":
        width = float(rng.uniform(0.25, 0.43))
        return ((lx <= -size_x * (1.0 - 2 * width)) & (np.abs(ly) <= size_y)) | ((np.abs(lx) <= size_x) & (ly <= -size_y * (1.0 - 2 * width)))
    if kind == "heart":
        hx = lx / size_x
        hy = (ly + 0.15 * size_y) / size_y
        return (hx * hx + hy * hy - 0.72) ** 3 - hx * hx * hy**3 <= 0.0
    if kind == "kidney":
        outer = (lx / size_x) ** 2 + (ly / size_y) ** 2 <= 1.0
        shift = float(rng.uniform(0.58, 0.82)) * size_x
        bite = ((lx - shift) / (size_x * 0.68)) ** 2 + (ly / (size_y * 0.55)) ** 2 <= 1.0
        return outer & ~bite
    if kind == "lobed":
        theta = np.arctan2(ly, lx)
        radius = np.hypot(lx / size_x, ly / size_y)
        lobes = int(rng.integers(3, 7))
        phase = float(rng.uniform(-np.pi, np.pi))
        boundary = 0.78 + float(rng.uniform(0.13, 0.27)) * np.cos(lobes * theta + phase)
        return radius <= boundary
    if kind == "random_polygon":
        count = int(rng.integers(7, 15))
        theta = np.linspace(0.0, 2.0 * np.pi, count, endpoint=False)
        radii = rng.uniform(0.38, 1.0, size=count)
        radii[1::2] *= rng.uniform(0.50, 0.82, size=radii[1::2].shape)
        vertices = np.column_stack((size_x * radii * np.cos(theta), size_y * radii * np.sin(theta)))
        return polygon_mask(lx, ly, vertices)
    raise ValueError(f"unknown shape {kind}")


def convex_hull_mask(binary: np.ndarray) -> np.ndarray:
    rows, cols = np.nonzero(binary)
    if rows.size < 3:
        return binary.copy()
    points = np.column_stack((cols, rows))
    try:
        hull = ConvexHull(points)
    except QhullError:
        return binary.copy()
    canvas = Image.new("1", (binary.shape[1], binary.shape[0]), 0)
    ImageDraw.Draw(canvas).polygon([tuple(point) for point in points[hull.vertices]], fill=1)
    return np.asarray(canvas, dtype=bool)


def instance_indentation_mask(labels: np.ndarray) -> np.ndarray:
    result = np.zeros_like(labels, dtype=bool)
    for class_id in (1, 2):
        components, count = connected_components(labels == class_id, structure=np.ones((3, 3), dtype=np.uint8))
        for component_id in range(1, count + 1):
            component = components == component_id
            if component.sum() < 8:
                continue
            result |= convex_hull_mask(component) & ~component
    return result


def signed_distance(labels: np.ndarray) -> np.ndarray:
    foreground = labels != 0
    distance = distance_transform_edt(foreground) - distance_transform_edt(~foreground)
    return np.clip(distance / 12.0, -1.0, 1.0).astype(np.float32)


def generate_masks(samples: int, resolution: int, seed: int) -> dict[str, np.ndarray]:
    rng = np.random.default_rng(seed)
    coordinates = np.linspace(-1.0, 1.0, resolution, dtype=np.float32)
    x, y = np.meshgrid(coordinates, coordinates)
    fov = x * x + y * y <= 0.98**2
    labels = np.zeros((samples, resolution, resolution), dtype=np.uint8)
    delta = np.zeros((samples, resolution, resolution), dtype=np.float32)
    indentations = np.zeros_like(labels, dtype=np.uint8)
    sdf = np.zeros_like(delta)
    shape_codes = np.full((samples, 4), -1, dtype=np.int16)
    shape_counts = np.zeros(samples, dtype=np.int16)
    concave_names = {"star", "cross", "crescent", "c_shape", "u_shape", "l_shape", "heart", "kidney", "lobed", "random_polygon"}

    for sample_index in range(samples):
        count = int(rng.integers(1, 5))
        shape_counts[sample_index] = count
        sample_labels = np.zeros((resolution, resolution), dtype=np.uint8)
        sample_delta = np.zeros((resolution, resolution), dtype=np.float32)
        # At least half the dataset contains a material inward boundary.
        forced_concave = sample_index % 2 == 0
        kinds = list(rng.choice(SHAPE_NAMES, size=count, replace=True))
        if forced_concave and not any(kind in concave_names for kind in kinds):
            kinds[0] = str(rng.choice(sorted(concave_names)))
        for object_index, kind in enumerate(kinds):
            mask = draw_shape(str(kind), x, y, rng) & fov
            if mask.sum() < 12:
                continue
            class_id = 1 if rng.uniform() < 0.56 else 2
            contrast = -float(rng.uniform(0.22, 0.92)) if class_id == 1 else float(rng.uniform(0.22, 1.10))
            sample_labels[mask] = class_id
            sample_delta[mask] = contrast
            shape_codes[sample_index, object_index] = SHAPE_TO_CODE[str(kind)]
        labels[sample_index] = sample_labels
        delta[sample_index] = sample_delta
        indentations[sample_index] = instance_indentation_mask(sample_labels).astype(np.uint8)
        sdf[sample_index] = signed_distance(sample_labels)
        if (sample_index + 1) % 500 == 0 or sample_index + 1 == samples:
            print(f"generated masks {sample_index + 1}/{samples}", flush=True)
    return {
        "labels": labels,
        "delta": delta,
        "indentation_masks": indentations,
        "signed_distance": sdf,
        "shape_codes": shape_codes,
        "shape_counts": shape_counts,
        "fov_mask": fov.astype(np.uint8),
    }


def parse_args() -> argparse.Namespace:
    project_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--samples", type=int, default=6000)
    parser.add_argument("--resolution", type=int, default=64)
    parser.add_argument("--seed", type=int, default=20260819)
    parser.add_argument("--ridge", type=float, default=3e-3, help="ridge scale relative to mean diagonal J^T J")
    parser.add_argument(
        "--forward-mode",
        choices=("linear", "nonlinear"),
        default="linear",
        help="Use the KTC Jacobian or the full nonlinear complete-electrode forward solver.",
    )
    parser.add_argument(
        "--voltage-scale",
        type=float,
        default=2.0,
        help="Scale applied to voltage differences; 2.0 matches the public KTC DIP solver.",
    )
    parser.add_argument("--output", type=Path, default=project_root / "datasets" / "ktc_shape_synthetic_v1.npz")
    parser.add_argument("--repo-root", type=Path, default=project_root / "external" / "KTC2023-ABC2")
    parser.add_argument("--ktc-root", type=Path, default=project_root / "datasets" / "ktc2023_full" / "v3" / "evaluation_full" / "EvaluationData_full")
    return parser.parse_args()


def save_previews(
    output: Path,
    masks: dict[str, np.ndarray],
    linear_images: np.ndarray,
    real_linear: np.ndarray,
    real_labels: np.ndarray,
    real_ids: list[str],
) -> None:
    synthetic_count = min(12, masks["labels"].shape[0])
    synthetic_indices = np.linspace(
        0, masks["labels"].shape[0] - 1, synthetic_count, dtype=int
    )
    figure, axes = plt.subplots(synthetic_count, 3, figsize=(8.3, synthetic_count * 2.25), squeeze=False)
    for row, index in enumerate(synthetic_indices):
        axes[row, 0].imshow(masks["labels"][index], vmin=0, vmax=2, cmap="viridis")
        axes[row, 0].set_title(f"synthetic {index}: labels")
        axes[row, 1].imshow(masks["delta"][index], cmap="coolwarm", vmin=-1.1, vmax=1.1)
        axes[row, 1].set_title("conductivity change")
        scale = max(float(np.percentile(np.abs(linear_images[index]), 99)), 1e-6)
        axes[row, 2].imshow(linear_images[index], cmap="coolwarm", vmin=-scale, vmax=scale)
        axes[row, 2].set_title("ridge initial image")
        for axis in axes[row]:
            axis.set_axis_off()
    figure.suptitle("Independent synthetic non-convex shapes and KTC linear initial images", fontsize=14)
    figure.tight_layout()
    figure.savefig(output.with_name(output.stem + "_synthetic_preview.png"), dpi=150)
    plt.close(figure)

    figure, axes = plt.subplots(6, 7, figsize=(15.5, 13.2), squeeze=False)
    for level in range(1, 8):
        for sample in range(1, 4):
            index = (level - 1) * 3 + (sample - 1)
            image_axis = axes[(sample - 1) * 2, level - 1]
            truth_axis = axes[(sample - 1) * 2 + 1, level - 1]
            scale = max(float(np.percentile(np.abs(real_linear[index]), 99)), 1e-6)
            image_axis.imshow(real_linear[index], cmap="coolwarm", vmin=-scale, vmax=scale)
            image_axis.set_title(f"{real_ids[index]}: ridge")
            truth_axis.imshow(real_labels[index], vmin=0, vmax=2, cmap="viridis")
            truth_axis.set_title("untouched test truth")
            image_axis.set_axis_off()
            truth_axis.set_axis_off()
    figure.suptitle("All 21 public KTC2023 v3 evaluation cases: input sanity check only", fontsize=15)
    figure.tight_layout()
    figure.savefig(output.with_name(output.stem + "_real_preview.png"), dpi=160)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    if args.samples < 32:
        raise ValueError("at least 32 samples are required")
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    # Resolve user-facing paths before entering the external solver repository,
    # whose relative reference-file imports require it to be the working directory.
    output = args.output.resolve()
    repo_root = args.repo_root.resolve()
    ktc_root = args.ktc_root.resolve()
    os.chdir(repo_root)
    sys.path.insert(0, str(repo_root))
    from utils import solver

    first_data = ktc_root / "evaluation_datasets" / "level1" / "data1.mat"
    reference = ktc_root / "evaluation_datasets" / "level1" / "ref.mat"
    print("building KTC Jacobian with the v3 evaluation reference", flush=True)
    matrices = solver.get_solver_matrices(str(first_data), 1, 0.7927, reference_data_path=str(reference))
    jacobian = np.asarray(matrices["J"], dtype=np.float32)
    node_coordinates = np.asarray(matrices["coordinates"], dtype=np.float32)
    print(f"J={jacobian.shape}, nodes={node_coordinates.shape}", flush=True)

    resolution = args.resolution
    pixel_map = solver.calc_dist(node_coordinates, x_d=resolution, y_d=resolution, mode="nearest")
    node_to_raw_pixel = np.argmax(pixel_map, axis=1).astype(np.int64)
    swapped_nodes = node_coordinates[:, [1, 0]]
    x_min, y_min = swapped_nodes.min(axis=0)
    x_max, y_max = swapped_nodes.max(axis=0)
    gx = np.arange(resolution) * ((x_max - x_min) / resolution) + x_min
    gy = np.arange(resolution) * ((y_max - y_min) / resolution) + y_min
    raw_x, raw_y = np.meshgrid(gx, gy, indexing="ij")
    raw_pixel_to_node = cKDTree(swapped_nodes).query(np.column_stack((raw_x.ravel(), raw_y.ravel())))[1].astype(np.int64)

    masks = generate_masks(args.samples, resolution, args.seed)
    raw_delta = np.flip(masks["delta"], axis=1).reshape(args.samples, -1)
    node_delta = raw_delta[:, node_to_raw_pixel]
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if args.forward_mode == "linear":
        print(f"projecting linearized synthetic voltages on {device}", flush=True)
        j_tensor = torch.from_numpy(jacobian).to(device)
        x_tensor = torch.from_numpy(node_delta).to(device)
        synthetic_voltage = torch.empty((args.samples, jacobian.shape[0]), dtype=torch.float32, device="cpu")
        batch_size = 256
        for start in range(0, args.samples, batch_size):
            stop = min(start + batch_size, args.samples)
            synthetic_voltage[start:stop] = (
                args.voltage_scale * (x_tensor[start:stop] @ j_tensor.T)
            ).cpu()
        synthetic_voltage_np = synthetic_voltage.numpy()
    else:
        print("running full nonlinear KTC complete-electrode simulations", flush=True)
        forward_solver = matrices["forward_solver"]
        sigma0 = np.asarray(matrices["sigma0"], dtype=np.float64)
        contact_impedance = np.asarray(matrices["contact_impedance"], dtype=np.float64)
        reference_forward = np.asarray(matrices["reference_forward"], dtype=np.float64).reshape(-1)
        synthetic_voltage_np = np.empty((args.samples, jacobian.shape[0]), dtype=np.float32)
        for index in range(args.samples):
            absolute_sigma = sigma0 + node_delta[index, :, None].astype(np.float64)
            # SolveForward clips in place, so every sample receives an independent array.
            simulated = np.asarray(
                forward_solver.SolveForward(absolute_sigma.copy(), contact_impedance.copy())
            ).reshape(-1)
            synthetic_voltage_np[index] = (
                args.voltage_scale * (simulated - reference_forward)
            ).astype(np.float32)
            if (index + 1) % 50 == 0 or index + 1 == args.samples:
                print(f"nonlinear forward solves {index + 1}/{args.samples}", flush=True)

    rng = np.random.default_rng(args.seed + 1)
    clean_voltage = synthetic_voltage_np.copy()
    for index in range(args.samples):
        snr = float(rng.uniform(28.0, 65.0))
        signal_rms = float(np.sqrt(np.mean(clean_voltage[index] ** 2)))
        noise_rms = signal_rms / (10.0 ** (snr / 20.0))
        synthetic_voltage_np[index] = clean_voltage[index] * float(rng.uniform(0.92, 1.08))
        synthetic_voltage_np[index] += rng.normal(0.0, noise_rms + 1e-9, size=jacobian.shape[0])

    j64 = jacobian.astype(np.float64)
    gram = j64.T @ j64
    ridge_value = float(args.ridge * np.mean(np.diag(gram)))
    reconstruction_operator = np.linalg.solve(gram + ridge_value * np.eye(gram.shape[0]), j64.T).astype(np.float32)
    print(f"ridge={ridge_value:.6e}; reconstructing synthetic and real backprojections", flush=True)
    linear_nodes = synthetic_voltage_np @ reconstruction_operator.T
    raw_linear = linear_nodes[:, raw_pixel_to_node].reshape(args.samples, resolution, resolution)
    linear_images = np.flip(raw_linear, axis=1).astype(np.float32)

    real_voltages = []
    real_labels = []
    real_ids = []
    for level in range(1, 8):
        ref = sio.loadmat(ktc_root / "evaluation_datasets" / f"level{level}" / "ref.mat")["Uelref"].reshape(-1)
        for sample in range(1, 4):
            measured = sio.loadmat(ktc_root / "evaluation_datasets" / f"level{level}" / f"data{sample}.mat")["Uel"].reshape(-1)
            real_voltages.append((2.0 * (measured - ref)).astype(np.float32))
            real_labels.append(sio.loadmat(ktc_root / "GroundTruths" / f"level_{level}" / f"{sample}_true.mat")["truth"].astype(np.uint8))
            real_ids.append(f"level_{level}/{sample}")
    real_voltages_np = np.stack(real_voltages)
    real_nodes = real_voltages_np @ reconstruction_operator.T
    real_raw = real_nodes[:, raw_pixel_to_node].reshape(len(real_ids), resolution, resolution)
    real_linear = np.flip(real_raw, axis=1).astype(np.float32)

    calibration_reference = sio.loadmat(repo_root / "utils" / "reference_files" / "ref.mat")[
        "Uelref"
    ].reshape(-1)
    calibration_voltages = []
    calibration_labels = []
    calibration_ids = []
    for sample in range(1, 5):
        measured = sio.loadmat(repo_root / "inputs" / f"data{sample}.mat")["Uel"].reshape(-1)
        calibration_voltages.append(
            (args.voltage_scale * (measured - calibration_reference)).astype(np.float32)
        )
        truth_256 = sio.loadmat(repo_root / "groundTruths" / f"true{sample}.mat")["truth"].astype(np.uint8)
        truth_64 = np.asarray(
            Image.fromarray(truth_256).resize(
                (resolution, resolution), resample=Image.Resampling.NEAREST
            )
        )
        calibration_labels.append(truth_64)
        calibration_ids.append(f"official_training/{sample}")
    calibration_voltages_np = np.stack(calibration_voltages)
    calibration_nodes = calibration_voltages_np @ reconstruction_operator.T
    calibration_raw = calibration_nodes[:, raw_pixel_to_node].reshape(
        len(calibration_ids), resolution, resolution
    )
    calibration_linear = np.flip(calibration_raw, axis=1).astype(np.float32)
    calibration_labels_np = np.stack(calibration_labels)
    calibration_sdf = np.stack([signed_distance(labels) for labels in calibration_labels_np])
    calibration_indent = np.stack(
        [instance_indentation_mask(labels).astype(np.uint8) for labels in calibration_labels_np]
    )

    order = rng.permutation(args.samples)
    train_end = int(round(args.samples * 0.72))
    val_end = int(round(args.samples * 0.86))
    train_indices = np.sort(order[:train_end])
    validation_indices = np.sort(order[train_end:val_end])
    test_indices = np.sort(order[val_end:])
    output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        output,
        **masks,
        voltages=synthetic_voltage_np.astype(np.float32),
        clean_voltages=clean_voltage.astype(np.float32),
        linear_images=linear_images,
        train_indices=train_indices,
        validation_indices=validation_indices,
        test_indices=test_indices,
        jacobian=jacobian,
        reconstruction_operator=reconstruction_operator,
        node_to_raw_pixel=node_to_raw_pixel,
        raw_pixel_to_node=raw_pixel_to_node,
        node_coordinates=node_coordinates,
        real_voltages=real_voltages_np,
        real_linear_images=real_linear,
        real_labels=np.stack(real_labels),
        real_ids=np.asarray(real_ids),
        calibration_voltages=calibration_voltages_np,
        calibration_linear_images=calibration_linear,
        calibration_labels=calibration_labels_np,
        calibration_signed_distance=calibration_sdf,
        calibration_indentation_masks=calibration_indent,
        calibration_ids=np.asarray(calibration_ids),
    )
    real_labels_np = np.stack(real_labels)
    save_previews(output, masks, linear_images, real_linear, real_labels_np, real_ids)
    summary = {
        "output": str(output),
        "samples": args.samples,
        "resolution": resolution,
        "splits": {"train": int(train_indices.size), "validation": int(validation_indices.size), "test": int(test_indices.size)},
        "real_test_samples": len(real_ids),
        "real_test_ids": real_ids,
        "real_calibration_samples": len(calibration_ids),
        "real_calibration_ids": calibration_ids,
        "shape_codes": SHAPE_TO_CODE,
        "jacobian_shape": list(jacobian.shape),
        "ridge_scale": args.ridge,
        "ridge_value": ridge_value,
        "evaluation_truth_used_for_training": False,
        "official_training_truth_used_for_calibration": True,
        "forward_mode": args.forward_mode,
        "forward_model": (
            "KTC2023 nonlinear complete-electrode model at sigma=0.7927"
            if args.forward_mode == "nonlinear"
            else "KTC2023 CEM Jacobian at sigma=0.7927"
        ),
        "voltage_scale": args.voltage_scale,
        "device": str(device),
        "seed": args.seed,
    }
    output.with_suffix(".json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
