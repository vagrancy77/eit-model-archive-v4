param(
    [string]$Python = 'E:\conda-envs\pytorch-gpu\python.exe',
    [string]$Root = 'E:\Codex',
    [int]$Seed = 20260911
)

$ErrorActionPreference = 'Stop'
$scriptRoot = Join-Path $Root 'eit_reproduction\scripts'
$train = Join-Path $scriptRoot 'train_topology_residual_eit_v3.py'
$calibrate = Join-Path $scriptRoot 'calibrate_topology_hole_resolver.py'
$evaluate = Join-Path $scriptRoot 'evaluate_topology_residual_eit_v3.py'
$route = Join-Path $scriptRoot 'evaluate_topology_action_router.py'
$configurations = @(
    @{ Name = 'matched_v3_no_risk'; Architecture = 'v3'; PhysicsWeight = 0.00015; TopologyStart = 4 },
    @{ Name = 'v4_no_physics'; Architecture = 'v4'; PhysicsWeight = 0.0; TopologyStart = 4 },
    # Keep the same v4 capacity and final segmentation objective, but disable
    # explicit cutout, mouth, clDice, and risk supervision throughout training.
    @{ Name = 'v4_no_explicit_topology'; Architecture = 'v4'; PhysicsWeight = 0.00015; TopologyStart = 80 }
)

foreach ($configuration in $configurations) {
    $name = $configuration.Name
    $architecture = $configuration.Architecture
    $physicsWeight = $configuration.PhysicsWeight
    $topologyStart = $configuration.TopologyStart
    $trainingDir = Join-Path $Root "topology_risk_eit_ablation_${name}_seed_$Seed"
    $checkpoint = Join-Path $trainingDir "topology_residual_${architecture}_best.pt"
    $predictions = Join-Path $trainingDir 'test_predictions.npz'
    $summary = Join-Path $trainingDir 'summary.json'
    $resolver = Join-Path $trainingDir 'hole_resolver.json'
    $finalDir = Join-Path $Root "topology_risk_eit_ablation_${name}_seed_${Seed}_final"
    $finalSummary = Join-Path $finalDir 'comparison_summary.json'
    $log = Join-Path $trainingDir 'training_console.log'

    if (-not (Test-Path -LiteralPath $summary)) {
        New-Item -ItemType Directory -Force -Path $trainingDir | Out-Null
        Write-Host "ablation=$name training started at $(Get-Date -Format o)"
        & $Python $train `
            --output-dir $trainingDir `
            --epochs 80 `
            --patience 18 `
            --batch-size 18 `
            --base-channels 28 `
            --learning-rate 0.0004 `
            --weight-decay 0.0001 `
            --stress-repeat 2 `
            --ordinary-repeat 4 `
            --architecture $architecture `
            --seed $Seed `
            --device cuda `
            --physics-weight $physicsWeight `
            --topology-start $topologyStart `
            --topology-ramp 10 `
            --progress-every 4 `
            --disable-amp 2>&1 | Tee-Object -FilePath $log
        if ($LASTEXITCODE -ne 0) {
            throw "ablation=$name training failed with exit code $LASTEXITCODE"
        }
    } else {
        Write-Host "ablation=$name training already complete; skipping"
    }

    foreach ($required in @($checkpoint, $predictions)) {
        if (-not (Test-Path -LiteralPath $required)) {
            throw "Missing ablation output: $required"
        }
    }
    if (-not (Test-Path -LiteralPath $resolver)) {
        & $Python $calibrate --checkpoint $checkpoint --output $resolver --batch-size 24
        if ($LASTEXITCODE -ne 0) {
            throw "ablation=$name calibration failed with exit code $LASTEXITCODE"
        }
    }
    if (-not (Test-Path -LiteralPath $finalSummary)) {
        & $Python $evaluate `
            --checkpoint $checkpoint `
            --new-predictions $predictions `
            --hole-resolver $resolver `
            --output-dir $finalDir `
            --bootstrap 5000 `
            --seed $Seed
        if ($LASTEXITCODE -ne 0) {
            throw "ablation=$name evaluation failed with exit code $LASTEXITCODE"
        }
    }

    $routeDir = Join-Path $Root "topology_risk_eit_ablation_${name}_seed_${Seed}_router"
    $routeSummary = Join-Path $routeDir 'action_router_summary.json'
    if (-not (Test-Path -LiteralPath $routeSummary)) {
        & $Python $route `
            --checkpoint $checkpoint `
            --test-predictions $predictions `
            --public-predictions (Join-Path $finalDir 'public_ktc_predictions.npz') `
            --output-dir $routeDir
        if ($LASTEXITCODE -ne 0) {
            throw "ablation=$name action-router evaluation failed with exit code $LASTEXITCODE"
        }
    }
    Write-Host "ablation=$name completed at $(Get-Date -Format o)"
}
