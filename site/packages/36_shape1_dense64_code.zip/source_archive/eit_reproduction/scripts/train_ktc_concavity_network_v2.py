"""Ablation study for non-convex EIT reconstruction on the KTC geometry.

The evaluation labels of the 21 public KTC2023 v3 phantoms are loaded only
after checkpoint selection and synthetic test evaluation. Model selection is
performed on the synthetic validation split with one rule shared by all
ablations.
"""
from __future__ import annotations

import argparse
import json
import math
import random
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset

from train_ktc_concavity_network import (
    CalibrationDataset,
    DecoderStage,
    InputAdapter,
    PhysicsOperator,
    ResidualBlock,
    aggregate_rows,
    confusion_metrics,
    indentation_mask,
    ktc_score,
    multi_otsu_labels,
    save_focus_montage,
    save_real_montage,
    save_training_curves,
    soft_dice_loss,
    write_rows,
)


@dataclass(frozen=True)
class ModelSpec:
    sdf: bool = False
    boundary: bool = False
    indentation: bool = False
    physics: bool = False
    voltage: bool = False


SPECS = {
    "vanilla": ModelSpec(),
    "sdf": ModelSpec(sdf=True),
    "boundary": ModelSpec(sdf=True, boundary=True),
    "indent": ModelSpec(sdf=True, boundary=True, indentation=True),
    "physics": ModelSpec(sdf=True, boundary=True, indentation=True, physics=True),
    "voltage": ModelSpec(sdf=True, boundary=True, indentation=True, voltage=True),
    "v2": ModelSpec(sdf=True, boundary=True, indentation=True, physics=True, voltage=True),
}


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--output-dir", type=Path, default=root / "outputs" / "ktc_concavity_v2")
    parser.add_argument("--models", default="vanilla,sdf,boundary,indent,physics,v2")
    parser.add_argument("--epochs", type=int, default=72)
    parser.add_argument("--batch-size", type=int, default=20)
    parser.add_argument("--base-channels", type=int, default=32)
    parser.add_argument("--learning-rate", type=float, default=2e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--patience", type=int, default=14)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--seed", type=int, default=20260819)
    parser.add_argument("--sdf-weight", type=float, default=0.45)
    parser.add_argument("--boundary-weight", type=float, default=0.30)
    parser.add_argument("--surface-weight", type=float, default=0.12)
    parser.add_argument("--indent-weight", type=float, default=0.30)
    parser.add_argument("--conductivity-weight", type=float, default=0.30)
    parser.add_argument("--physics-weight", type=float, default=2e-4)
    parser.add_argument("--calibration-weight", type=float, default=0.20)
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


class EITDatasetV2(Dataset):
    def __init__(self, archive: np.lib.npyio.NpzFile, indices: np.ndarray) -> None:
        self.linear = archive["linear_images"]
        self.labels = archive["labels"]
        self.delta = archive["delta"]
        self.sdf = archive["signed_distance"]
        self.indent = archive["indentation_masks"]
        self.input_voltage = archive["voltages"]
        self.clean_voltage = archive["clean_voltages"]
        self.indices = np.asarray(indices, dtype=np.int64)

    def __len__(self) -> int:
        return int(self.indices.size)

    def __getitem__(self, item: int) -> dict[str, torch.Tensor]:
        index = int(self.indices[item])
        return {
            "image": torch.from_numpy(np.asarray(self.linear[index], dtype=np.float32)[None]),
            "labels": torch.from_numpy(np.asarray(self.labels[index], dtype=np.int64)),
            "delta": torch.from_numpy(np.asarray(self.delta[index], dtype=np.float32)[None]),
            "sdf": torch.from_numpy(np.asarray(self.sdf[index], dtype=np.float32)[None]),
            "indent": torch.from_numpy(np.asarray(self.indent[index], dtype=np.float32)[None]),
            "input_voltage": torch.from_numpy(np.asarray(self.input_voltage[index], dtype=np.float32)),
            "clean_voltage": torch.from_numpy(np.asarray(self.clean_voltage[index], dtype=np.float32)),
            "index": torch.tensor(index, dtype=torch.int64),
        }


class CalibrationDatasetV2(CalibrationDataset):
    def __init__(self, archive: np.lib.npyio.NpzFile) -> None:
        super().__init__(archive, augment=False)
        self.voltage = archive["calibration_voltages"]

    def __getitem__(self, index: int) -> dict[str, torch.Tensor]:
        result = super().__getitem__(index)
        result["input_voltage"] = torch.from_numpy(np.asarray(self.voltage[index], dtype=np.float32))
        return result


class VoltageEncoder(nn.Module):
    """Encode the ordered 76 x 31 KTC voltage table into a 4 x 4 latent map."""

    def __init__(self, base: int) -> None:
        super().__init__()
        self.features = nn.Sequential(
            ResidualBlock(1, base),
            nn.Conv2d(base, base * 2, 3, stride=2, padding=1, bias=False),
            ResidualBlock(base * 2, base * 2),
            nn.Conv2d(base * 2, base * 4, 3, stride=2, padding=1, bias=False),
            ResidualBlock(base * 4, base * 4),
            nn.Conv2d(base * 4, base * 8, 3, stride=2, padding=1, bias=False),
            ResidualBlock(base * 8, base * 8),
        )
        self.projection = nn.Conv2d(base * 8, base * 16, 1)

    def forward(self, voltage: torch.Tensor) -> torch.Tensor:
        voltage = voltage - voltage.median(dim=1, keepdim=True).values
        scale = torch.quantile(voltage.abs(), 0.985, dim=1, keepdim=True).clamp_min(1e-6)
        voltage = torch.clamp(voltage / scale, -4.0, 4.0) / 4.0
        table = voltage.reshape(voltage.shape[0], 1, 76, 31)
        return self.projection(F.adaptive_avg_pool2d(self.features(table), (4, 4)))


class ConcavityNetV2(nn.Module):
    def __init__(self, base: int, spec: ModelSpec) -> None:
        super().__init__()
        self.spec = spec
        self.stem = ResidualBlock(3, base)
        self.enc1 = ResidualBlock(base, base * 2)
        self.enc2 = ResidualBlock(base * 2, base * 4)
        self.enc3 = ResidualBlock(base * 4, base * 8)
        self.bottleneck = nn.Sequential(
            ResidualBlock(base * 8, base * 16),
            nn.Dropout2d(0.12),
            ResidualBlock(base * 16, base * 16),
        )
        if spec.voltage:
            self.voltage_encoder = VoltageEncoder(base)
            self.voltage_gate = nn.Parameter(torch.tensor(-2.0))
        self.dec3 = DecoderStage(base * 16, base * 8, base * 8)
        self.dec2 = DecoderStage(base * 8, base * 4, base * 4)
        self.dec1 = DecoderStage(base * 4, base * 2, base * 2)
        self.dec0 = DecoderStage(base * 2, base, base)
        self.segmentation = nn.Conv2d(base, 3, 1)
        if spec.sdf:
            self.sdf_head = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))
        if spec.physics:
            self.delta_head = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))

    def forward(self, image: torch.Tensor, voltage: torch.Tensor) -> dict[str, torch.Tensor]:
        e0 = self.stem(image)
        e1 = self.enc1(F.max_pool2d(e0, 2))
        e2 = self.enc2(F.max_pool2d(e1, 2))
        e3 = self.enc3(F.max_pool2d(e2, 2))
        x = self.bottleneck(F.max_pool2d(e3, 2))
        if self.spec.voltage:
            x = x + torch.sigmoid(self.voltage_gate) * self.voltage_encoder(voltage)
        x = self.dec3(x, e3)
        x = self.dec2(x, e2)
        x = self.dec1(x, e1)
        features = self.dec0(x, e0)
        raw_logits = self.segmentation(features)
        output: dict[str, torch.Tensor] = {"logits": raw_logits}
        if self.spec.sdf:
            sdf = torch.tanh(self.sdf_head(features))
            # The zero level set supplies geometry while class logits retain
            # the sign of conductivity contrast.
            geometry_bias = 1.25 * sdf
            output["sdf"] = sdf
            output["logits"] = torch.cat(
                (
                    raw_logits[:, 0:1] - geometry_bias,
                    raw_logits[:, 1:2] + 0.5 * geometry_bias,
                    raw_logits[:, 2:3] + 0.5 * geometry_bias,
                ),
                dim=1,
            )
        if self.spec.physics:
            output["delta"] = 1.25 * torch.tanh(self.delta_head(features))
        return output


def gradients(image: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    return image[:, :, 1:, :] - image[:, :, :-1, :], image[:, :, :, 1:] - image[:, :, :, :-1]


def normalized_masked_mean(value: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    per_case = (value * mask).sum(dim=(1, 2, 3)) / mask.sum(dim=(1, 2, 3)).clamp_min(1.0)
    valid = mask.sum(dim=(1, 2, 3)) > 0
    return per_case[valid].mean() if valid.any() else value.new_zeros(())


def compute_loss(
    model: ConcavityNetV2,
    outputs: dict[str, torch.Tensor],
    batch: dict[str, torch.Tensor],
    class_weights: torch.Tensor,
    physics: PhysicsOperator,
    args: argparse.Namespace,
    ramp: float,
) -> tuple[torch.Tensor, dict[str, float]]:
    logits = outputs["logits"]
    ce = F.cross_entropy(logits, batch["labels"], weight=class_weights)
    dice = soft_dice_loss(logits, batch["labels"])
    total = ce + dice
    pieces: dict[str, torch.Tensor] = {"ce": ce, "dice": dice}
    if model.spec.sdf:
        sdf = F.smooth_l1_loss(outputs["sdf"], batch["sdf"], beta=0.08)
        total = total + ramp * args.sdf_weight * sdf
        pieces["sdf"] = sdf
    foreground_probability = torch.softmax(logits, dim=1)[:, 1:].sum(dim=1, keepdim=True)
    target_foreground = (batch["labels"] != 0).float().unsqueeze(1)
    if model.spec.boundary:
        pred_dy, pred_dx = gradients(foreground_probability)
        true_dy, true_dx = gradients(target_foreground)
        probability_boundary = F.l1_loss(pred_dy, true_dy) + F.l1_loss(pred_dx, true_dx)
        sdf_dy, sdf_dx = gradients(outputs["sdf"])
        target_sdf_dy, target_sdf_dx = gradients(batch["sdf"])
        sdf_boundary = F.smooth_l1_loss(sdf_dy, target_sdf_dy) + F.smooth_l1_loss(sdf_dx, target_sdf_dx)
        boundary = probability_boundary + 0.5 * sdf_boundary
        # Kervadec-style signed-distance surface term. The stored SDF is
        # positive inside, so its negative is the conventional level-set sign.
        surface = (foreground_probability * (-batch["sdf"])).mean()
        total = total + ramp * (args.boundary_weight * boundary + args.surface_weight * surface)
        pieces.update(boundary=boundary, surface=surface)
    if model.spec.indentation:
        indentation = batch["indent"]
        # Localize the background penalty to the inward boundary instead of
        # treating the entire convex-hull gap as an equally strong negative.
        notch_rim = indentation * F.max_pool2d(target_foreground, 11, stride=1, padding=5)
        concave_inside = target_foreground * F.max_pool2d(indentation, 11, stride=1, padding=5)
        false_fill = normalized_masked_mean(foreground_probability, notch_rim)
        false_cut = normalized_masked_mean(1.0 - foreground_probability, concave_inside)
        balanced_indent = 0.5 * (false_fill + false_cut)
        total = total + ramp * args.indent_weight * balanced_indent
        pieces.update(false_fill=false_fill, false_cut=false_cut, balanced_indent=balanced_indent)
    if model.spec.physics:
        conductivity = F.smooth_l1_loss(outputs["delta"], batch["delta"], beta=0.08)
        physical = physics.loss(outputs["delta"], batch["clean_voltage"])
        total = total + ramp * (args.conductivity_weight * conductivity + args.physics_weight * physical)
        pieces.update(conductivity=conductivity, physics=physical)
    pieces["total"] = total
    return total, {key: float(value.detach()) for key, value in pieces.items()}


def calibration_loss(
    model: ConcavityNetV2,
    outputs: dict[str, torch.Tensor],
    batch: dict[str, torch.Tensor],
    class_weights: torch.Tensor,
    args: argparse.Namespace,
    ramp: float,
) -> torch.Tensor:
    logits = outputs["logits"]
    total = F.cross_entropy(logits, batch["labels"], weight=class_weights) + soft_dice_loss(logits, batch["labels"])
    if model.spec.sdf:
        total = total + ramp * args.sdf_weight * F.smooth_l1_loss(outputs["sdf"], batch["sdf"], beta=0.08)
    foreground_probability = torch.softmax(logits, dim=1)[:, 1:].sum(dim=1, keepdim=True)
    target_foreground = (batch["labels"] != 0).float().unsqueeze(1)
    if model.spec.boundary:
        pred_dy, pred_dx = gradients(foreground_probability)
        true_dy, true_dx = gradients(target_foreground)
        total = total + ramp * args.boundary_weight * (F.l1_loss(pred_dy, true_dy) + F.l1_loss(pred_dx, true_dx))
    if model.spec.indentation:
        indentation = batch["indent"]
        notch_rim = indentation * F.max_pool2d(target_foreground, 11, stride=1, padding=5)
        concave_inside = target_foreground * F.max_pool2d(indentation, 11, stride=1, padding=5)
        balanced = 0.5 * (
            normalized_masked_mean(foreground_probability, notch_rim)
            + normalized_masked_mean(1.0 - foreground_probability, concave_inside)
        )
        total = total + ramp * args.indent_weight * balanced
    return total


@torch.no_grad()
def evaluate_synthetic(
    model: ConcavityNetV2,
    adapter: InputAdapter,
    loader: DataLoader,
    device: torch.device,
) -> tuple[dict[str, float], dict[int, np.ndarray]]:
    model.eval()
    rows: list[dict[str, float]] = []
    predictions: dict[int, np.ndarray] = {}
    for batch in loader:
        image = batch["image"].to(device)
        voltage = batch["input_voltage"].to(device)
        prediction = model(adapter(image), voltage)["logits"].argmax(dim=1).cpu().numpy()
        truth = batch["labels"].numpy()
        indentation = batch["indent"].numpy()[:, 0]
        for offset, index in enumerate(batch["index"].numpy()):
            predictions[int(index)] = prediction[offset]
            rows.append(confusion_metrics(truth[offset], prediction[offset], indentation[offset]))
    return aggregate_rows(rows), predictions


def selection_score(metrics: dict[str, float]) -> float:
    # The score rewards indentation recovery but still assigns 75% of its
    # mass to region and boundary accuracy, preventing the trivial shrinkage
    # solution exposed by the first experiment.
    return float(
        0.55 * metrics["foreground_iou"]
        + 0.20 * metrics["boundary_f1"]
        + 0.25 * metrics["concavity_score"]
    )


def train_one(
    name: str,
    archive: np.lib.npyio.NpzFile,
    args: argparse.Namespace,
    output_dir: Path,
    device: torch.device,
) -> tuple[ConcavityNetV2, list[dict[str, float]]]:
    spec = SPECS[name]
    train_loader = DataLoader(
        EITDatasetV2(archive, archive["train_indices"]), batch_size=args.batch_size,
        shuffle=True, num_workers=args.workers, pin_memory=device.type == "cuda", drop_last=True,
    )
    validation_loader = DataLoader(
        EITDatasetV2(archive, archive["validation_indices"]), batch_size=args.batch_size,
        shuffle=False, num_workers=args.workers, pin_memory=device.type == "cuda",
    )
    calibration_loader = DataLoader(CalibrationDatasetV2(archive), batch_size=4, shuffle=True, num_workers=0)
    calibration_iterator = iter(calibration_loader)
    adapter = InputAdapter(archive["fov_mask"]).to(device)
    model = ConcavityNetV2(args.base_channels, spec).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(1, args.epochs))
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    counts = np.bincount(archive["labels"][archive["train_indices"]].reshape(-1), minlength=3).astype(np.float64)
    class_weights_np = np.sqrt(counts.sum() / np.maximum(counts, 1.0))
    class_weights_np /= class_weights_np.mean()
    class_weights = torch.from_numpy(class_weights_np.astype(np.float32)).to(device)
    physics = PhysicsOperator(
        jacobian=torch.from_numpy(archive["jacobian"]).to(device),
        node_to_raw_pixel=torch.from_numpy(archive["node_to_raw_pixel"]).long().to(device),
        voltage_scale=2.0,
    )
    checkpoint = output_dir / f"{name}_best.pt"
    history: list[dict[str, float]] = []
    best_score = -math.inf
    stale = 0
    for epoch in range(1, args.epochs + 1):
        model.train()
        totals: list[float] = []
        ramp = min(1.0, max(0.0, (epoch - 4) / 10.0))
        for batch in train_loader:
            batch = {key: value.to(device, non_blocking=True) for key, value in batch.items()}
            optimizer.zero_grad(set_to_none=True)
            with torch.amp.autocast("cuda", enabled=device.type == "cuda"):
                outputs = model(adapter(batch["image"]), batch["input_voltage"])
                loss, _ = compute_loss(model, outputs, batch, class_weights, physics, args, ramp)
                try:
                    calibration_batch = next(calibration_iterator)
                except StopIteration:
                    calibration_iterator = iter(calibration_loader)
                    calibration_batch = next(calibration_iterator)
                calibration_batch = {key: value.to(device, non_blocking=True) for key, value in calibration_batch.items()}
                calibration_outputs = model(adapter(calibration_batch["image"]), calibration_batch["input_voltage"])
                loss = loss + args.calibration_weight * calibration_loss(
                    model, calibration_outputs, calibration_batch, class_weights, args, ramp
                )
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            scaler.step(optimizer)
            scaler.update()
            totals.append(float(loss.detach()))
        scheduler.step()
        validation, _ = evaluate_synthetic(model, adapter, validation_loader, device)
        score = selection_score(validation)
        row = {
            "epoch": float(epoch),
            "train_loss": float(np.mean(totals)),
            "learning_rate": float(optimizer.param_groups[0]["lr"]),
            "selection_score": score,
            **{f"validation_{key}": value for key, value in validation.items()},
        }
        history.append(row)
        print(
            f"{name} epoch {epoch}/{args.epochs}: loss={row['train_loss']:.4f}, "
            f"IoU={validation['foreground_iou']:.4f}, boundary={validation['boundary_f1']:.4f}, "
            f"notch={validation['notch_preservation']:.4f}, joint={validation['concavity_score']:.4f}",
            flush=True,
        )
        if score > best_score + 1e-5:
            best_score = score
            stale = 0
            torch.save(
                {
                    "model": model.state_dict(), "base_channels": args.base_channels,
                    "spec": asdict(spec), "epoch": epoch, "selection_score": score,
                    "class_weights": class_weights_np.tolist(),
                },
                checkpoint,
            )
        else:
            stale += 1
        if stale >= args.patience:
            print(f"{name}: early stopping after {epoch} epochs", flush=True)
            break
    state = torch.load(checkpoint, map_location=device, weights_only=False)
    model.load_state_dict(state["model"])
    (output_dir / f"{name}_history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    return model, history


@torch.no_grad()
def infer_real(
    model: ConcavityNetV2,
    adapter: InputAdapter,
    images: np.ndarray,
    voltages: np.ndarray,
    device: torch.device,
    batch_size: int,
) -> np.ndarray:
    model.eval()
    outputs: list[np.ndarray] = []
    for start in range(0, len(images), batch_size):
        image = torch.from_numpy(images[start : start + batch_size, None].astype(np.float32)).to(device)
        voltage = torch.from_numpy(voltages[start : start + batch_size].astype(np.float32)).to(device)
        logits = model(adapter(image), voltage)["logits"]
        # Continuous-logit upsampling avoids the block boundary imposed by
        # argmax-at-64 followed by nearest-neighbour resizing.
        logits = F.interpolate(logits, size=(256, 256), mode="bilinear", align_corners=False)
        outputs.append(logits.argmax(dim=1).cpu().numpy())
    return np.concatenate(outputs)


def evaluate_real_predictions(
    name: str,
    predictions: np.ndarray,
    truths: np.ndarray,
    ids: np.ndarray,
) -> tuple[dict[str, float], list[dict[str, object]]]:
    numeric_rows: list[dict[str, float]] = []
    rows: list[dict[str, object]] = []
    for truth, prediction, case_id in zip(truths, predictions, ids):
        metrics = confusion_metrics(truth, prediction, indentation_mask(truth))
        metrics["ktc_ssim"] = ktc_score(truth, prediction)
        numeric_rows.append(metrics)
        rows.append({"id": str(case_id), "method": name, **metrics})
    return aggregate_rows(numeric_rows), rows


def main() -> None:
    args = parse_args()
    names = [name.strip() for name in args.models.split(",") if name.strip()]
    unknown = sorted(set(names) - set(SPECS))
    if unknown:
        raise ValueError(f"Unknown models {unknown}; choose from {sorted(SPECS)}")
    set_seed(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    archive = np.load(args.dataset.resolve(), allow_pickle=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"device={device}; seed={args.seed}; models={names}", flush=True)
    trained: dict[str, ConcavityNetV2] = {}
    histories: dict[str, list[dict[str, float]]] = {}
    for name in names:
        set_seed(args.seed)
        trained[name], histories[name] = train_one(name, archive, args, output_dir, device)

    adapter = InputAdapter(archive["fov_mask"]).to(device)
    test_loader = DataLoader(
        EITDatasetV2(archive, archive["test_indices"]), batch_size=args.batch_size,
        shuffle=False, num_workers=args.workers,
    )
    synthetic_summary: dict[str, dict[str, float]] = {}
    for name, model in trained.items():
        synthetic_summary[name], _ = evaluate_synthetic(model, adapter, test_loader, device)
        print(f"synthetic test {name}: {synthetic_summary[name]}", flush=True)

    # Public evaluation truth is first accessed after checkpoint selection and
    # independent synthetic test evaluation have both finished.
    real_images = archive["real_linear_images"]
    real_voltages = archive["real_voltages"]
    real_truths = archive["real_labels"]
    real_ids = archive["real_ids"]
    fov = archive["fov_mask"].astype(bool)
    ridge_64 = np.stack([multi_otsu_labels(image, fov) for image in real_images])
    ridge = np.stack([np.repeat(np.repeat(label, 4, axis=0), 4, axis=1) for label in ridge_64])
    real_predictions: dict[str, np.ndarray] = {"ridge": ridge}
    for name, model in trained.items():
        real_predictions[name] = infer_real(model, adapter, real_images, real_voltages, device, args.batch_size)
    real_summary: dict[str, dict[str, float]] = {}
    real_rows: list[dict[str, object]] = []
    for name, predictions in real_predictions.items():
        real_summary[name], rows = evaluate_real_predictions(name, predictions, real_truths, real_ids)
        real_rows.extend(rows)
        print(f"real test {name}: {real_summary[name]}", flush=True)

    write_rows(output_dir / "real_case_metrics.csv", real_rows)
    save_real_montage(output_dir / "real_all_21_comparison.png", real_truths, real_ids, real_predictions, real_rows)
    save_focus_montage(output_dir / "real_most_concave_comparison.png", real_truths, real_ids, real_predictions, real_rows)
    save_training_curves(output_dir / "training_curves.png", histories)
    result = {
        "dataset": str(args.dataset.resolve()),
        "output_dir": str(output_dir),
        "device": str(device),
        "seed": args.seed,
        "models": names,
        "model_specs": {name: asdict(SPECS[name]) for name in names},
        "synthetic_test": synthetic_summary,
        "real_untouched_test": real_summary,
        "evaluation_truth_used_for_training_or_selection": False,
        "selection_rule": "0.55 * synthetic validation foreground IoU + 0.20 * boundary F1 + 0.25 * joint concavity score",
        "args": vars(args) | {"dataset": str(args.dataset), "output_dir": str(args.output_dir)},
    }
    (output_dir / "summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
