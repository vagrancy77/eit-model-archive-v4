"""Learn when a predicted cavity should be connected to exterior background.

The gate is trained only on synthetic training labels.  It sees geometric and
posterior features of a proposed geodesic opening, never the ground truth image
at inference time.  A threshold is selected on validation data and then frozen
for synthetic test and the 21 public KTC cases.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import numpy as np
import torch
from scipy.ndimage import binary_dilation, label as connected_components

from calibrate_ktc_topology_path import cavity_path, save_changed_grid
from fuse_ktc_joint_shape_models import blend, infer_probability, load_model
from train_ktc_concavity_network import InputAdapter
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_implicit_boolean_network import standard_metrics, stress_metrics


FEATURE_NAMES = (
    "cavity_area_fraction", "cavity_foreground_ratio", "path_length_fraction",
    "removal_area_fraction", "cavity_border_distance", "cavity_compactness",
    "conservative_path_mean", "conservative_path_min", "conservative_path_max",
    "aggressive_path_mean", "aggressive_path_min", "aggressive_path_max",
    "path_posterior_disagreement", "conservative_cavity_mean",
    "aggressive_cavity_mean", "conservative_removal_mean",
    "aggressive_removal_mean", "foreground_area_fraction",
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    p.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    p.add_argument("--conservative", type=Path, default=Path("E:/Codex/ktc_joint_shape_pretrained_seed20260820/best.pt"))
    p.add_argument("--aggressive", type=Path, default=Path("E:/Codex/ktc_joint_shape_network_seed20260820/best.pt"))
    p.add_argument("--shape-expert", type=Path, default=Path("E:/Codex/ktc_shape_expert_seed20260820/predictions.npz"))
    p.add_argument("--output-dir", type=Path, default=Path("E:/Codex/ktc_topology_gate_seed20260820"))
    p.add_argument("--batch-size", type=int, default=32)
    return p.parse_args()


def opening_candidates(
    labels: np.ndarray,
    conservative: np.ndarray,
    aggressive: np.ndarray,
    max_length: int,
    min_background: float,
    min_hole: int,
    corridor_radius: int,
    corridor_background: float,
) -> list[dict[str, np.ndarray | float]]:
    foreground = labels != 0
    components, count = connected_components(~foreground, structure=np.ones((3, 3), dtype=np.uint8))
    border = np.unique(np.concatenate((components[0], components[-1], components[:, 0], components[:, -1])))
    exterior = np.isin(components, border[border != 0])
    conservative_fg = conservative[1:].sum(axis=0)
    aggressive_fg = aggressive[1:].sum(axis=0)
    cost = 0.10 + 0.45 * conservative_fg + 0.45 * aggressive_fg
    height, width = labels.shape
    foreground_area = max(int(foreground.sum()), 1)
    records = []
    for component in range(1, count + 1):
        if component in border:
            continue
        cavity = components == component
        cavity_area = int(cavity.sum())
        if cavity_area < min_hole:
            continue
        path = cavity_path(foreground, cavity, exterior, cost)
        if not path or len(path) > max_length:
            continue
        path_y = np.asarray([y for y, _ in path], dtype=np.int64)
        path_x = np.asarray([x for _, x in path], dtype=np.int64)
        aggressive_path = aggressive[0, path_y, path_x]
        if float(aggressive_path.mean()) < min_background:
            continue
        path_mask = np.zeros_like(foreground)
        path_mask[path_y, path_x] = True
        corridor = binary_dilation(
            path_mask, structure=np.ones((3, 3), dtype=bool), iterations=corridor_radius,
        ) if corridor_radius > 0 else path_mask
        removal = path_mask | (corridor & foreground & (aggressive[0] >= corridor_background))
        removal_y, removal_x = np.nonzero(removal)
        conservative_path = conservative[0, path_y, path_x]
        cavity_y, cavity_x = np.nonzero(cavity)
        cy, cx = float(cavity_y.mean()), float(cavity_x.mean())
        border_distance = min(cy, cx, height - 1 - cy, width - 1 - cx) / max(height, width)
        cavity_boundary = binary_dilation(cavity, structure=np.ones((3, 3), dtype=bool)) & ~cavity
        perimeter = max(int(cavity_boundary.sum()), 1)
        compactness = perimeter * perimeter / (4.0 * math.pi * cavity_area)
        features = np.asarray((
            cavity_area / (height * width), cavity_area / foreground_area,
            len(path) / max(height, width), len(removal_y) / (height * width),
            border_distance, compactness,
            float(conservative_path.mean()), float(conservative_path.min()), float(conservative_path.max()),
            float(aggressive_path.mean()), float(aggressive_path.min()), float(aggressive_path.max()),
            float(np.abs(conservative_path - aggressive_path).mean()),
            float(conservative[0, cavity_y, cavity_x].mean()), float(aggressive[0, cavity_y, cavity_x].mean()),
            float(conservative[0, removal_y, removal_x].mean()), float(aggressive[0, removal_y, removal_x].mean()),
            foreground_area / (height * width),
        ), dtype=np.float32)
        records.append({"features": features, "removal": removal, "cavity": cavity})
    return records


def collect_training_examples(
    raw: np.ndarray, conservative: np.ndarray, aggressive: np.ndarray, truth: np.ndarray,
    length: int, evidence: float, min_hole: int, radius: int, corridor_background: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    features, targets, quality = [], [], []
    for labels, cons, aggr, target in zip(raw, conservative, aggressive, truth):
        records = opening_candidates(labels, cons, aggr, length, evidence, min_hole, radius, corridor_background)
        for record in records:
            removal = record["removal"]
            cavity = record["cavity"]
            removal_quality = float(np.mean(target[removal] == 0))
            cavity_quality = float(np.mean(target[cavity] == 0))
            features.append(record["features"])
            quality.append(removal_quality * cavity_quality)
            targets.append(float(removal_quality >= 0.70 and cavity_quality >= 0.60))
    if not features:
        return np.empty((0, len(FEATURE_NAMES)), np.float32), np.empty(0, np.float32), np.empty(0, np.float32)
    return np.stack(features), np.asarray(targets, np.float32), np.asarray(quality, np.float32)


def fit_gate(features: np.ndarray, targets: np.ndarray) -> dict[str, np.ndarray | float]:
    mean = features.mean(axis=0)
    scale = features.std(axis=0)
    scale[scale < 1e-6] = 1.0
    x = torch.from_numpy(((features - mean) / scale).astype(np.float32))
    y = torch.from_numpy(targets[:, None].astype(np.float32))
    torch.manual_seed(20260820)
    layer = torch.nn.Linear(features.shape[1], 1)
    positives = max(float(targets.sum()), 1.0)
    negatives = max(float(len(targets) - targets.sum()), 1.0)
    loss_fn = torch.nn.BCEWithLogitsLoss(pos_weight=torch.tensor([negatives / positives]))
    optimizer = torch.optim.AdamW(layer.parameters(), lr=0.025, weight_decay=2e-3)
    for _ in range(1200):
        optimizer.zero_grad(set_to_none=True)
        loss = loss_fn(layer(x), y)
        loss.backward()
        optimizer.step()
    return {
        "mean": mean.astype(np.float32), "scale": scale.astype(np.float32),
        "weight": layer.weight.detach().numpy()[0].astype(np.float32),
        "bias": float(layer.bias.detach().numpy()[0]),
    }


def gate_probability(features: np.ndarray, gate: dict[str, np.ndarray | float]) -> float:
    z = float(np.dot((features - gate["mean"]) / gate["scale"], gate["weight"]) + gate["bias"])
    z = float(np.clip(z, -30.0, 30.0))
    return 1.0 / (1.0 + math.exp(-z))


def apply_gate(
    raw: np.ndarray, conservative: np.ndarray, aggressive: np.ndarray,
    gate: dict[str, np.ndarray | float], threshold: float,
    length: int, evidence: float, min_hole: int, radius: int, corridor_background: float,
) -> tuple[np.ndarray, int, list[float]]:
    output = raw.copy()
    accepted = 0
    scores = []
    for index in range(len(raw)):
        records = opening_candidates(
            raw[index], conservative[index], aggressive[index], length, evidence,
            min_hole, radius, corridor_background,
        )
        for record in records:
            score = gate_probability(record["features"], gate)
            scores.append(score)
            if score >= threshold:
                output[index][record["removal"]] = 0
                accepted += 1
    return output, accepted, scores


def infer_split(model, adapter, archive, indices, device, batch_size, size=64):
    return infer_probability(
        model, adapter, archive["linear_images"][indices], archive["voltages"][indices],
        device, batch_size, size,
    )


def main() -> None:
    args = parse_args()
    out = args.output_dir.resolve(); out.mkdir(parents=True, exist_ok=True)
    base = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    expert = np.load(args.shape_expert.resolve(), allow_pickle=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    adapter = InputAdapter(base["fov_mask"]).to(device)
    conservative = load_model(args.conservative, device)
    aggressive = load_model(args.aggressive, device)
    alpha, length, evidence, radius, corridor_background = 0.5, 6, 0.1, 1, 0.1

    btr, str_ = np.asarray(base["train_indices"]), np.asarray(stress["train_indices"])
    btc = infer_split(conservative, adapter, base, btr, device, args.batch_size)
    bta = infer_split(aggressive, adapter, base, btr, device, args.batch_size)
    stc = infer_split(conservative, adapter, stress, str_, device, args.batch_size)
    sta = infer_split(aggressive, adapter, stress, str_, device, args.batch_size)
    bx, by, bq = collect_training_examples(blend(btc, bta, alpha), btc, bta, base["labels"][btr], length, evidence, 3, radius, corridor_background)
    sx, sy, sq = collect_training_examples(blend(stc, sta, alpha), stc, sta, stress["labels"][str_], length, evidence, 3, radius, corridor_background)
    x, y = np.concatenate((bx, sx)), np.concatenate((by, sy))
    gate = fit_gate(x, y)
    print(f"gate examples={len(y)} positives={int(y.sum())} base={len(by)} stress={len(sy)}", flush=True)

    bv, sv = np.asarray(base["validation_indices"]), np.asarray(stress["validation_indices"])
    bvc = infer_split(conservative, adapter, base, bv, device, args.batch_size)
    bva = infer_split(aggressive, adapter, base, bv, device, args.batch_size)
    svc = infer_split(conservative, adapter, stress, sv, device, args.batch_size)
    sva = infer_split(aggressive, adapter, stress, sv, device, args.batch_size)
    raw_bv, raw_sv = blend(bvc, bva, alpha), blend(svc, sva, alpha)
    base_ref = standard_metrics(base["labels"][bv], raw_bv, base["indentation_masks"][bv])
    stress_ref, _, _ = stress_metrics(stress["labels"][sv], raw_sv, stress["cutout_masks"][sv], stress["cutout_depth_weights"][sv], stress["family_codes"][sv])
    candidates = []
    for threshold in np.linspace(0.10, 0.90, 17):
        bp, bo, _ = apply_gate(raw_bv, bvc, bva, gate, float(threshold), length, evidence, 3, radius, corridor_background)
        sp, so, _ = apply_gate(raw_sv, svc, sva, gate, float(threshold), length, evidence, 3, radius, corridor_background)
        bm = standard_metrics(base["labels"][bv], bp, base["indentation_masks"][bv])
        sm, _, _ = stress_metrics(stress["labels"][sv], sp, stress["cutout_masks"][sv], stress["cutout_depth_weights"][sv], stress["family_codes"][sv])
        eligible = (
            bm["foreground_iou"] >= base_ref["foreground_iou"] - 0.006
            and sm["foreground_iou"] >= stress_ref["foreground_iou"] - 0.010
            and sm["bank_retention"] >= stress_ref["bank_retention"] - 0.018
        )
        score = 0.18 * bm["foreground_iou"] + 0.18 * sm["foreground_iou"] + 0.30 * sm["open_deep_cutout_recovery"] + 0.16 * sm["bank_retention"] + 0.18 * sm["topology_structural_joint"]
        candidates.append({"threshold": float(threshold), "eligible": bool(eligible), "score": float(score), "accepted_base": bo, "accepted_stress": so, "base": bm, "stress": sm})
    eligible = [row for row in candidates if row["eligible"]]
    selected = max(eligible or candidates, key=lambda row: row["score"])
    threshold = selected["threshold"]
    print(json.dumps(selected, indent=2), flush=True)

    bt, st = np.asarray(base["test_indices"]), np.asarray(stress["test_indices"])
    btc = infer_split(conservative, adapter, base, bt, device, args.batch_size)
    bta = infer_split(aggressive, adapter, base, bt, device, args.batch_size)
    stc = infer_split(conservative, adapter, stress, st, device, args.batch_size)
    sta = infer_split(aggressive, adapter, stress, st, device, args.batch_size)
    raw_b, raw_s = blend(btc, bta, alpha), blend(stc, sta, alpha)
    bp, bo, bscores = apply_gate(raw_b, btc, bta, gate, threshold, length, evidence, 3, radius, corridor_background)
    sp, so, sscores = apply_gate(raw_s, stc, sta, gate, threshold, length, evidence, 3, radius, corridor_background)
    bm = standard_metrics(base["labels"][bt], bp, base["indentation_masks"][bt])
    sm, by_family, _ = stress_metrics(stress["labels"][st], sp, stress["cutout_masks"][st], stress["cutout_depth_weights"][st], stress["family_codes"][st])
    raw_sm, _, _ = stress_metrics(stress["labels"][st], raw_s, stress["cutout_masks"][st], stress["cutout_depth_weights"][st], stress["family_codes"][st])
    expert_sm, _, _ = stress_metrics(stress["labels"][st], expert["stress_expert"], stress["cutout_masks"][st], stress["cutout_depth_weights"][st], stress["family_codes"][st])

    rc = infer_probability(conservative, adapter, base["real_linear_images"], base["real_voltages"], device, args.batch_size, 256)
    ra = infer_probability(aggressive, adapter, base["real_linear_images"], base["real_voltages"], device, args.batch_size, 256)
    raw_r = blend(rc, ra, alpha)
    rp, ro, rscores = apply_gate(raw_r, rc, ra, gate, threshold, length * 4, evidence, 3 * 16, radius * 4, corridor_background)
    real_summary, real_cases = evaluate_real_predictions("topology_gate", rp, base["real_labels"], base["real_ids"])
    expert_real, _ = evaluate_real_predictions("shape_expert", expert["real_expert"], base["real_labels"], base["real_ids"])

    save_changed_grid(out / "stress_changed_cases.png", stress["labels"][st], expert["stress_expert"], raw_s, sp, st)
    save_changed_grid(out / "real_changed_cases.png", base["real_labels"], expert["real_expert"], raw_r, rp, base["real_ids"])
    np.savez_compressed(out / "predictions.npz", base=bp, stress=sp, real=rp, raw_stress=raw_s, raw_real=raw_r)
    gate_json = {
        "feature_names": FEATURE_NAMES,
        "mean": gate["mean"].tolist(), "scale": gate["scale"].tolist(),
        "weight": gate["weight"].tolist(), "bias": gate["bias"], "threshold": threshold,
    }
    summary = {
        "method": "learned cavity-to-exterior gate with confidence-gated geodesic corridor",
        "training": {"examples": int(len(y)), "positives": int(y.sum()), "base_examples": int(len(by)), "stress_examples": int(len(sy)), "base_quality_mean": float(bq.mean()) if len(bq) else None, "stress_quality_mean": float(sq.mean()) if len(sq) else None},
        "gate": gate_json, "selected": selected, "validation_candidates": candidates,
        "test": {"accepted_base": bo, "accepted_stress": so, "accepted_real": ro, "base": bm, "stress_shape_expert": expert_sm, "stress_raw": raw_sm, "stress_gated": sm, "stress_by_family": by_family, "real_shape_expert": expert_real, "real_gated": real_summary, "real_cases": real_cases, "candidate_scores": {"base": bscores, "stress": sscores, "real": rscores}},
    }
    (out / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary["test"], ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
