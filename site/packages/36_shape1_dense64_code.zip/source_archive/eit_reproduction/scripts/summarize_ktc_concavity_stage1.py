from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import scipy.io as sio
from PIL import Image

PROJECT_ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = PROJECT_ROOT / "external" / "KTC2023-ABC2"
OUTPUT_DIR = PROJECT_ROOT / "outputs" / "ktc_concavity_stage1"
sys.path.insert(0, str(Path(__file__).resolve().parent))

from experiment_ktc_concavity import class_metrics, ktc_score, shape_metrics


def load_labels(path: Path) -> np.ndarray:
    values = np.asarray(Image.open(path), dtype=np.float64)
    return np.rint(values * 2.0 / 255.0).astype(np.int64)


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    truth = sio.loadmat(REPO_ROOT / "groundTruths" / "true4.mat")["truth"]
    candidates = {
        "Author DIP+TV, 3000": REPO_ROOT / "outputs" / "data4.png",
        "Local DIP+TV, 3000": (
            PROJECT_ROOT
            / "outputs"
            / "ktc2023_abc2_3000_data3_data4"
            / "data4.png"
        ),
        "Stage 1: best overlap": (
            PROJECT_ROOT
            / "outputs"
            / "ktc_concavity_nearest_map_750"
            / "very_shallow_dip_opening10.png"
        ),
        "Stage 1: best notch": (
            PROJECT_ROOT
            / "outputs"
            / "ktc_concavity_nearest_map_750"
            / "nearest_map_very_shallow_opening2.png"
        ),
    }
    rows = []
    images = []
    for name, path in candidates.items():
        reconstruction = load_labels(path)
        row = {
            "name": name,
            "path": str(path),
            "class_metrics": class_metrics(truth, reconstruction),
            "shape_metrics": shape_metrics(truth, reconstruction),
            "ktc_ssim": ktc_score(truth, reconstruction),
        }
        rows.append(row)
        images.append(reconstruction)

    with (OUTPUT_DIR / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump({"case": 4, "results": rows}, handle, ensure_ascii=False, indent=2)

    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    figure, axes = plt.subplots(1, 5, figsize=(16, 3.7), constrained_layout=True)
    axes[0].imshow(truth, cmap="gray", vmin=0, vmax=2)
    axes[0].set_title("Ground truth")
    axes[0].set_axis_off()
    for axis, image, row in zip(axes[1:], images, rows):
        metrics = row["class_metrics"]
        shape = row["shape_metrics"]
        axis.imshow(image, cmap="gray", vmin=0, vmax=2)
        axis.set_title(
            f"{row['name']}\n"
            f"mean IoU={metrics['mean_iou']:.3f}, KTC={row['ktc_ssim']:.3f}\n"
            f"notch={shape['indentation_preservation']:.3f}"
        )
        axis.set_axis_off()
    figure.suptitle("KTC data4: stage-1 concavity-preservation study", fontsize=15)
    figure.savefig(OUTPUT_DIR / "comparison.png", dpi=200)
    plt.close(figure)
    for row in rows:
        print(
            f"{row['name']}: mean IoU={row['class_metrics']['mean_iou']:.4f}, "
            f"KTC={row['ktc_ssim']:.4f}, "
            f"notch={row['shape_metrics']['indentation_preservation']:.4f}"
        )


if __name__ == "__main__":
    main()
