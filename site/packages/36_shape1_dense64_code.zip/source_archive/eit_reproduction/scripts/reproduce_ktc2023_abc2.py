from __future__ import annotations

import argparse
import hashlib
import json
import os
import random
import re
import sys
from pathlib import Path

import numpy as np
import scipy.io as sio
from PIL import Image

# Force CPU for better reproducibility before importing torch/solver.
os.environ.setdefault("CUDA_VISIBLE_DEVICES", "")

import torch


def parse_args() -> argparse.Namespace:
    project_root = Path(__file__).resolve().parents[1]
    default_repo = project_root / "external" / "KTC2023-ABC2"
    default_out = project_root / "outputs" / "ktc2023_abc2_reproduction"
    parser = argparse.ArgumentParser(
        description=(
            "Reproduce the public KTC2023-ABC2 DIP+TV EIT results and compare "
            "them against the bundled example outputs and ground truths."
        )
    )
    parser.add_argument("--repo-root", type=Path, default=default_repo)
    parser.add_argument("--output-dir", type=Path, default=default_out)
    parser.add_argument("--category", type=int, default=1, choices=range(1, 8))
    parser.add_argument("--seed", type=int, default=1234)
    parser.add_argument("--num-iter", type=int, default=3000)
    parser.add_argument("--max-files", type=int, default=None)
    parser.add_argument(
        "--start-index",
        type=int,
        default=0,
        help="Zero-based index in sorted inputs/*.mat from which to start.",
    )
    parser.add_argument(
        "--progress-every",
        type=int,
        default=100,
        help="Print solver progress every N iterations (0 disables logging).",
    )
    parser.add_argument(
        "--score-mode",
        choices=("none", "fast", "ktc"),
        default="fast",
        help=(
            "Metric mode. 'fast' reports pixel/IoU/Dice metrics; 'ktc' also "
            "runs the original slow KTC SSIM score; 'none' skips metrics."
        ),
    )
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    try:
        torch.use_deterministic_algorithms(True)
    except Exception:
        pass


def png_to_labels(path: Path) -> np.ndarray:
    image = np.asarray(Image.open(path), dtype=np.float64)
    return np.rint(image * 2.0 / 255.0).astype(np.int64)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def overlap_metrics(truth: np.ndarray, reconstruction: np.ndarray) -> dict[str, float]:
    """Fast, transparent metrics for the two foreground classes in KTC data."""
    truth = np.asarray(truth, dtype=np.int64)
    reconstruction = np.asarray(reconstruction, dtype=np.int64)
    result: dict[str, float] = {
        "pixel_accuracy": float(np.mean(truth == reconstruction)),
    }
    ious = []
    dices = []
    for label in (1, 2):
        t = truth == label
        r = reconstruction == label
        inter = float(np.logical_and(t, r).sum())
        union = float(np.logical_or(t, r).sum())
        denom = float(t.sum() + r.sum())
        iou = inter / union if union else 1.0
        dice = 2.0 * inter / denom if denom else 1.0
        result[f"class{label}_iou"] = iou
        result[f"class{label}_dice"] = dice
        ious.append(iou)
        dices.append(dice)
    result["mean_iou"] = float(np.mean(ious))
    result["mean_dice"] = float(np.mean(dices))
    return result


def write_comparison_figure(
    repo_root: Path,
    output_dir: Path,
    rows: list[dict[str, object]],
    output_path: Path,
) -> None:
    """Create a paper-style truth/reference/reproduction/loss figure."""
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    if not rows:
        return
    n_rows = len(rows)
    figure, axes = plt.subplots(
        n_rows,
        4,
        figsize=(13.5, 3.6 * n_rows),
        squeeze=False,
        constrained_layout=True,
    )
    for row_idx, row in enumerate(rows):
        stem = Path(str(row["input"])).stem
        truth = sio.loadmat(repo_root / "groundTruths" / str(row["truth"]))["truth"]
        bundled = png_to_labels(repo_root / "outputs" / f"{stem}.png")
        reproduced = png_to_labels(output_dir / f"{stem}.png")

        images = (truth, bundled, reproduced)
        titles = (f"{stem}: ground truth", "Author output", "Local reproduction")
        for col, (image, title) in enumerate(zip(images, titles)):
            axes[row_idx, col].imshow(image, cmap="gray", vmin=0, vmax=2)
            axes[row_idx, col].set_title(title)
            axes[row_idx, col].set_axis_off()

        loss_path = output_dir / f"loss_{stem}.npy"
        if loss_path.exists():
            loss = np.load(loss_path)
            axes[row_idx, 3].plot(np.arange(1, len(loss) + 1), loss)
            axes[row_idx, 3].set_yscale("log")
            axes[row_idx, 3].set_title("DIP+TV loss")
            axes[row_idx, 3].set_xlabel("Iteration")
            axes[row_idx, 3].set_ylabel("Loss")
            axes[row_idx, 3].grid(alpha=0.25)
        else:
            axes[row_idx, 3].set_axis_off()
    figure.suptitle("KTC2023-ABC2 DIP+TV reproduction", fontsize=15)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(output_path, dpi=220)
    plt.close(figure)


def paired_truth_name(input_name: str) -> str:
    match = re.search(r"(\d+)", input_name)
    if match is None:
        raise ValueError(f"cannot infer truth file for {input_name}")
    return f"true{match.group(1)}.mat"


def main() -> None:
    args = parse_args()
    repo_root = args.repo_root.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    # The upstream solver expects to be run from the repository root because it
    # loads reference .mat files via relative paths.
    os.chdir(repo_root)
    sys.path.insert(0, str(repo_root))

    from utils import process, solver
    KTCScoring = None
    if args.score_mode == "ktc":
        from utils import KTCScoring as _KTCScoring

        KTCScoring = _KTCScoring

    inputs_dir = repo_root / "inputs"
    truths_dir = repo_root / "groundTruths"
    bundled_outputs_dir = repo_root / "outputs"
    input_files = sorted(inputs_dir.glob("*.mat"))
    if args.start_index:
        input_files = input_files[args.start_index :]
    if args.max_files is not None:
        input_files = input_files[: args.max_files]

    summary_rows: list[dict[str, object]] = []
    reproduced_scores: list[float] = []
    bundled_scores: list[float] = []
    exact_matches = 0

    for index, input_path in enumerate(input_files):
        run_seed = args.seed + args.start_index + index
        set_seed(run_seed)
        segmented, details = solver.solve(
            str(input_path),
            args.category,
            num_iter_override=args.num_iter,
            progress_every=args.progress_every,
            return_details=True,
        )

        output_png = output_dir / f"{input_path.stem}.png"
        process.save_img(segmented, output_png)

        truth_path = truths_dir / paired_truth_name(input_path.name)
        truth = sio.loadmat(truth_path)["truth"]

        bundled_png = bundled_outputs_dir / f"{input_path.stem}.png"
        bundled_labels = png_to_labels(bundled_png)
        reproduced_metrics = overlap_metrics(truth, segmented)
        bundled_metrics = overlap_metrics(truth, bundled_labels)
        reproduced_score = None
        bundled_score = None
        if args.score_mode == "ktc":
            reproduced_score = float(KTCScoring.scoringFunction(truth, segmented))
            bundled_score = float(KTCScoring.scoringFunction(truth, bundled_labels))
            reproduced_scores.append(reproduced_score)
            bundled_scores.append(bundled_score)

        np.save(output_dir / f"loss_{input_path.stem}.npy", np.asarray(details["loss_history"], dtype=np.float64))

        exact_match = output_png.read_bytes() == bundled_png.read_bytes()
        if exact_match:
            exact_matches += 1

        row = {
            "input": input_path.name,
            "truth": truth_path.name,
            "seed": run_seed,
            "num_iter": args.num_iter,
            "reproduced_score": reproduced_score,
            "bundled_score": bundled_score,
            "score_delta": (
                reproduced_score - bundled_score
                if reproduced_score is not None and bundled_score is not None
                else None
            ),
            "reproduced_metrics": reproduced_metrics,
            "bundled_metrics": bundled_metrics,
            "final_total_loss": details["final_total_loss"],
            "png_exact_match": exact_match,
            "reproduced_sha256": sha256_file(output_png),
            "bundled_sha256": sha256_file(bundled_png),
            "reproduced_unique_labels": sorted(np.unique(segmented).astype(int).tolist()),
            "bundled_unique_labels": sorted(np.unique(bundled_labels).astype(int).tolist()),
        }
        summary_rows.append(row)
        print(
            f"{input_path.name}: mean IoU {reproduced_metrics['mean_iou']:.4f} "
            f"(author {bundled_metrics['mean_iou']:.4f}), exact_png={exact_match}"
        )

    summary = {
        "paper_style_name": "KTC2023-ABC2 DIP+TV",
        "repo_root": str(repo_root),
        "category": args.category,
        "base_seed": args.seed,
        "num_iter": args.num_iter,
        "n_files": len(summary_rows),
        "mean_reproduced_score": float(np.mean(reproduced_scores)) if reproduced_scores else None,
        "mean_bundled_score": float(np.mean(bundled_scores)) if bundled_scores else None,
        "exact_png_matches": exact_matches,
        "files": summary_rows,
    }

    summary_path = output_dir / "summary.json"
    with summary_path.open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)

    write_comparison_figure(
        repo_root,
        output_dir,
        summary_rows,
        output_dir / "comparison.png",
    )

    print(f"Saved summary to {summary_path}")
    print(f"Saved comparison figure to {output_dir / 'comparison.png'}")


if __name__ == "__main__":
    main()
