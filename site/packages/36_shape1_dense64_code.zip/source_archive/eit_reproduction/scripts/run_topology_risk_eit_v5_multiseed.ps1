param(
    [int[]]$Seeds = @(20260912, 20260913, 20260914),
    [string]$Python = 'E:\Anaconda\envs\myenv\python.exe',
    [string]$Root = 'E:\Codex',
    [int]$Bootstrap = 10000
)

$ErrorActionPreference = 'Stop'
$scripts = Join-Path $Root 'eit_reproduction\scripts'
$train = Join-Path $scripts 'train_topology_residual_eit_v3.py'
$calibrate = Join-Path $scripts 'calibrate_topology_hole_resolver.py'
$evaluate = Join-Path $scripts 'evaluate_topology_residual_eit_v3.py'
$router = Join-Path $scripts 'evaluate_topology_action_router.py'
$aggregate = Join-Path $scripts 'aggregate_topology_risk_eit_v4_multiseed.py'
$aggregateRouter = Join-Path $scripts 'aggregate_topology_action_router_multiseed.py'
$priorSynthetic = Join-Path $Root 'eit_reproduction\outputs\ktc_concavity_v3_biological\seed_20260831\evaluation\synthetic_predictions.npz'
$priorReal = Join-Path $Root 'eit_reproduction\outputs\ktc_concavity_v3_biological\seed_20260831\evaluation\real_predictions.npz'

foreach ($required in @($Python, $train, $calibrate, $evaluate, $router, $aggregate, $aggregateRouter, $priorSynthetic, $priorReal)) {
    if (-not (Test-Path -LiteralPath $required)) {
        throw "Missing required file: $required"
    }
}

$finalRuns = @('20260911=E:\Codex\topology_risk_eit_v5_final')
$routerRuns = @('20260911=E:\Codex\topology_risk_eit_v5_router_seed_20260911')

foreach ($seed in $Seeds) {
    $trainingDir = Join-Path $Root "topology_risk_eit_v5_seed_$seed"
    $checkpoint = Join-Path $trainingDir 'topology_residual_v4_best.pt'
    $predictions = Join-Path $trainingDir 'test_predictions.npz'
    $trainingSummary = Join-Path $trainingDir 'summary.json'
    $trainingLog = Join-Path $trainingDir 'training_console.log'
    $resolver = Join-Path $trainingDir 'hole_resolver.json'
    $finalDir = Join-Path $Root "topology_risk_eit_v5_seed_${seed}_final"
    $finalSummary = Join-Path $finalDir 'comparison_summary.json'
    $routerDir = Join-Path $Root "topology_risk_eit_v5_router_seed_$seed"
    $routerSummary = Join-Path $routerDir 'action_router_summary.json'

    if (-not (Test-Path -LiteralPath $trainingSummary)) {
        New-Item -ItemType Directory -Force -Path $trainingDir | Out-Null
        Write-Host "seed=$seed v5 training started at $(Get-Date -Format o)"
        & $Python $train `
            --output-dir $trainingDir `
            --epochs 26 `
            --patience 8 `
            --batch-size 32 `
            --base-channels 28 `
            --learning-rate 0.0004 `
            --weight-decay 0.0001 `
            --stress-repeat 2 `
            --ordinary-repeat 4 `
            --architecture v4 `
            --seed $seed `
            --device cuda `
            --physics-weight 0.00015 `
            --topology-start 4 `
            --topology-ramp 10 `
            --area-budget-weight 0.20 `
            --boundary-protection-weight 0.60 `
            --protection-kernel 7 `
            --domain-randomization `
            --domain-snr-min 20 `
            --domain-snr-max 60 `
            --domain-gain 0.10 `
            --domain-dropout 0.05 `
            --progress-every 4 `
            --disable-amp 2>&1 | Tee-Object -FilePath $trainingLog
        if ($LASTEXITCODE -ne 0) {
            throw "seed=$seed training failed with exit code $LASTEXITCODE"
        }
    } else {
        Write-Host "seed=$seed v5 training complete; skipping"
    }
    foreach ($required in @($checkpoint, $predictions, $trainingSummary)) {
        if (-not (Test-Path -LiteralPath $required)) {
            throw "Missing training output: $required"
        }
    }

    if (-not (Test-Path -LiteralPath $resolver)) {
        Write-Host "seed=$seed resolver calibration started at $(Get-Date -Format o)"
        & $Python $calibrate --checkpoint $checkpoint --output $resolver --batch-size 24
        if ($LASTEXITCODE -ne 0) {
            throw "seed=$seed resolver calibration failed with exit code $LASTEXITCODE"
        }
    }

    if (-not (Test-Path -LiteralPath $finalSummary)) {
        Write-Host "seed=$seed unified evaluation started at $(Get-Date -Format o)"
        & $Python $evaluate `
            --checkpoint $checkpoint `
            --new-predictions $predictions `
            --hole-resolver $resolver `
            --prior-synthetic $priorSynthetic `
            --prior-real $priorReal `
            --output-dir $finalDir `
            --bootstrap 5000 `
            --seed $seed
        if ($LASTEXITCODE -ne 0) {
            throw "seed=$seed unified evaluation failed with exit code $LASTEXITCODE"
        }
    }

    if (-not (Test-Path -LiteralPath $routerSummary)) {
        Write-Host "seed=$seed quantile-risk router started at $(Get-Date -Format o)"
        & $Python $router `
            --checkpoint $checkpoint `
            --test-predictions $predictions `
            --public-predictions (Join-Path $finalDir 'public_ktc_predictions.npz') `
            --output-dir $routerDir `
            --risk-quantile 0.05 `
            --risk-floor -0.01
        if ($LASTEXITCODE -ne 0) {
            throw "seed=$seed router evaluation failed with exit code $LASTEXITCODE"
        }
    }

    $finalRuns += "$seed=$finalDir"
    $routerRuns += "$seed=$routerDir"
}

$aggregateDir = Join-Path $Root 'topology_risk_eit_v5_multiseed_final'
Write-Host "v5 four-seed topology analysis started at $(Get-Date -Format o)"
& $Python $aggregate `
    --runs $finalRuns `
    --output-dir $aggregateDir `
    --bootstrap $Bootstrap `
    --seed 20260925
if ($LASTEXITCODE -ne 0) {
    throw "v5 topology aggregation failed with exit code $LASTEXITCODE"
}

$aggregateRouterDir = Join-Path $Root 'topology_risk_eit_v5_router_multiseed_final'
Write-Host "v5 four-seed router analysis started at $(Get-Date -Format o)"
& $Python $aggregateRouter `
    --runs $routerRuns `
    --output-dir $aggregateRouterDir `
    --bootstrap $Bootstrap `
    --seed 20260926
if ($LASTEXITCODE -ne 0) {
    throw "v5 router aggregation failed with exit code $LASTEXITCODE"
}
Write-Host "v5 multi-seed pipeline completed at $(Get-Date -Format o)"
