"""Leakage-controlled GPU training for the joint KTC concavity dataset.

This stage trains ablations and freezes one candidate using validation data
only.  It never indexes synthetic test cases or loads the separate 21-case KTC
evaluation-label array; those are handled by the final evaluator.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

import train_ktc_concavity_network_v2 as v2


class CachedArchive:
    """Lazily decompress each NPZ member once while preserving the NPZ API."""

    def __init__(self, archive: np.lib.npyio.NpzFile) -> None:
        self.archive = archive
        self.files = archive.files
        self.cache: dict[str, np.ndarray] = {}

    def __getitem__(self, key: str) -> np.ndarray:
        if key not in self.cache:
            self.cache[key] = self.archive[key]
        return self.cache[key]


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_joint_concavity_v1.npz")
    parser.add_argument("--output-dir", type=Path, default=root / "outputs" / "ktc_concavity_v3")
    parser.add_argument("--models", default="vanilla,boundary,indent,voltage,v2")
    parser.add_argument("--epochs", type=int, default=80)
    parser.add_argument("--batch-size", type=int, default=24)
    parser.add_argument("--base-channels", type=int, default=32)
    parser.add_argument("--learning-rate", type=float, default=2e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--patience", type=int, default=14)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--seed", type=int, default=20260831)
    parser.add_argument("--sdf-weight", type=float, default=0.45)
    parser.add_argument("--boundary-weight", type=float, default=0.30)
    parser.add_argument("--surface-weight", type=float, default=0.12)
    parser.add_argument("--indent-weight", type=float, default=0.30)
    parser.add_argument("--conductivity-weight", type=float, default=0.30)
    parser.add_argument("--physics-weight", type=float, default=2e-4)
    parser.add_argument("--calibration-weight", type=float, default=0.20)
    parser.add_argument("--ordinary-notch-pixels", type=int, default=12)
    parser.add_argument("--ordinary-iou-tolerance", type=float, default=0.030)
    parser.add_argument("--source-iou-tolerance", type=float, default=0.025)
    return parser.parse_args()


def evaluate_indices(
    model: v2.ConcavityNetV2,
    archive: np.lib.npyio.NpzFile,
    indices: np.ndarray,
    adapter: v2.InputAdapter,
    device: torch.device,
    args: argparse.Namespace,
) -> dict[str, float]:
    indices = np.asarray(indices, dtype=np.int64)
    if indices.size == 0:
        return {"cases": 0.0}
    loader = DataLoader(
        v2.EITDatasetV2(archive, indices),
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.workers,
        pin_memory=device.type == "cuda",
    )
    metrics, _ = v2.evaluate_synthetic(model, adapter, loader, device)
    return {"cases": float(indices.size), **metrics}


def validation_partitions(
    archive: np.lib.npyio.NpzFile,
    ordinary_limit: int,
) -> dict[str, np.ndarray]:
    validation = np.asarray(archive["validation_indices"], dtype=np.int64)
    notch_pixels = np.asarray(archive["indentation_pixels"], dtype=np.int64)
    partitions = {
        "combined": validation,
        "ordinary": validation[notch_pixels[validation] < ordinary_limit],
        "concave": validation[notch_pixels[validation] >= ordinary_limit],
    }
    for source in ("legacy", "biological"):
        key = f"{source}_validation_indices"
        if key in archive.files:
            source_indices = np.asarray(archive[key], dtype=np.int64)
            partitions[source] = source_indices
            partitions[f"{source}_ordinary"] = source_indices[
                notch_pixels[source_indices] < ordinary_limit
            ]
            partitions[f"{source}_concave"] = source_indices[
                notch_pixels[source_indices] >= ordinary_limit
            ]
    return partitions


def choose_candidate(
    summaries: dict[str, dict[str, dict[str, float]]],
    names: list[str],
    args: argparse.Namespace,
) -> dict[str, object]:
    reference = "vanilla"
    if reference not in summaries:
        raise ValueError("the leakage-controlled selection requires the vanilla reference model")
    baseline = summaries[reference]
    decisions: dict[str, dict[str, object]] = {}
    eligible: list[str] = []
    for name in names:
        metrics = summaries[name]
        combined_delta = metrics["combined"]["foreground_iou"] - baseline["combined"]["foreground_iou"]
        ordinary_delta = metrics["ordinary"]["foreground_iou"] - baseline["ordinary"]["foreground_iou"]
        source_deltas = {
            source: metrics[source]["foreground_iou"] - baseline[source]["foreground_iou"]
            for source in ("legacy", "biological")
            if source in metrics and source in baseline
        }
        score = (
            0.40 * metrics["combined"]["foreground_iou"]
            + 0.15 * metrics["combined"]["boundary_f1"]
            + 0.45 * metrics["combined"]["concavity_score"]
        )
        allowed = (
            ordinary_delta >= -args.ordinary_iou_tolerance
            and combined_delta >= -args.source_iou_tolerance
            and all(delta >= -args.source_iou_tolerance for delta in source_deltas.values())
        )
        decisions[name] = {
            "eligible": bool(allowed),
            "selection_score": float(score),
            "combined_iou_delta": float(combined_delta),
            "ordinary_iou_delta": float(ordinary_delta),
            "source_iou_deltas": {key: float(value) for key, value in source_deltas.items()},
        }
        if allowed:
            eligible.append(name)
    experts = [name for name in names if name != reference]
    eligible_experts = [name for name in eligible if name != reference]
    selection_pool = eligible_experts or experts or eligible
    selected = max(selection_pool, key=lambda name: decisions[name]["selection_score"])
    return {
        "selected_model": selected,
        "reference_model": reference,
        "eligible_models": eligible,
        "eligible_shape_experts": eligible_experts,
        "selected_model_passed_architecture_screen": selected in eligible,
        "constraints": {
            "ordinary_validation_iou_regression_at_most": args.ordinary_iou_tolerance,
            "combined_and_per_source_validation_iou_regression_at_most": args.source_iou_tolerance,
        },
        "objective": "0.40 * validation IoU + 0.15 * boundary F1 + 0.45 * concavity score",
        "note": "Architecture screening permits a bounded expert regression; the separately fitted protection gate enforces the tighter ordinary-case constraint.",
        "models": decisions,
    }


def main() -> None:
    args = parse_args()
    names = [name.strip() for name in args.models.split(",") if name.strip()]
    unknown = sorted(set(names) - set(v2.SPECS))
    if unknown:
        raise ValueError(f"unknown models {unknown}; choose from {sorted(v2.SPECS)}")
    if "vanilla" not in names:
        raise ValueError("--models must include vanilla for the protection constraints")
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required for this experiment; CPU training is intentionally disabled")

    dataset_path = args.dataset.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    archive = CachedArchive(np.load(dataset_path, allow_pickle=False))
    required = {
        "indentation_pixels",
        "legacy_validation_indices",
        "biological_validation_indices",
    }
    missing = sorted(required - set(archive.files))
    if missing:
        raise KeyError(f"joint dataset is missing {missing}")

    device = torch.device("cuda")
    print(f"device={device}; seed={args.seed}; models={names}", flush=True)
    trained: dict[str, v2.ConcavityNetV2] = {}
    histories: dict[str, list[dict[str, float]]] = {}
    for name in names:
        v2.set_seed(args.seed)
        trained[name], histories[name] = v2.train_one(name, archive, args, output_dir, device)

    adapter = v2.InputAdapter(archive["fov_mask"]).to(device)
    partitions = validation_partitions(archive, args.ordinary_notch_pixels)
    validation_summary = {
        name: {
            split: evaluate_indices(model, archive, indices, adapter, device, args)
            for split, indices in partitions.items()
        }
        for name, model in trained.items()
    }
    decision = choose_candidate(validation_summary, names, args)
    v2.save_training_curves(output_dir / "training_curves.png", histories)
    result = {
        "dataset": str(dataset_path),
        "output_dir": str(output_dir),
        "device": str(device),
        "cuda_device_name": torch.cuda.get_device_name(0),
        "seed": args.seed,
        "models": names,
        "model_specs": {name: v2.asdict(v2.SPECS[name]) for name in names},
        "validation": validation_summary,
        "selection": decision,
        "synthetic_test_labels_used_for_training_or_selection": False,
        "ktc_evaluation_labels_accessed": False,
        "official_training_calibration_samples": int(len(archive["calibration_labels"])),
        "args": vars(args) | {"dataset": str(args.dataset), "output_dir": str(args.output_dir)},
    }
    (output_dir / "selection_summary.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
