"""Strict final evaluation for the from-scratch topology-residual EIT network.

The checkpoint is selected without public KTC labels.  This script first checks
that the synthetic test cases are identical to the frozen earlier experiment,
then compares the direct trunk and topology-residual output with prior methods.
It also audits topology-induced damage on ordinary (non-concave) cases.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import binary_dilation, binary_erosion, binary_fill_holes

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from pytorch_eit.topology_residual_net import TopologyResidualEITNet
from pytorch_eit.topology_projection import resolve_closed_holes


GROUPS = {
    "base": "legacy_test",
    "biological": "biological_held_out_test",
    "stress": "deep_concavity_stress_test",
}
METHODS = (
    "vanilla", "shape_aware", "protected", "direct_base", "topology_residual", "topology_safe"
)
DISPLAY_NAMES = {
    "vanilla": "Vanilla U-Net",
    "shape_aware": "Prior shape-aware",
    "protected": "Prior protected",
    "direct_base": "New direct trunk",
    "topology_residual": "New topology-residual",
    "topology_safe": "New topology-safe",
}
METRICS = (
    "foreground_iou",
    "foreground_dice",
    "boundary_f1",
    "notch_preservation",
    "bank_retention",
    "false_negative_fraction",
    "spurious_hole_fraction",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=Path(r"E:\Codex\topology_residual_eit_v3_full\topology_residual_v3_best.pt"),
    )
    parser.add_argument(
        "--new-predictions",
        type=Path,
        default=Path(r"E:\Codex\topology_residual_eit_v3_full\test_predictions.npz"),
    )
    parser.add_argument(
        "--hole-resolver",
        type=Path,
        default=Path(r"E:\Codex\topology_residual_eit_v3_full\hole_resolver.json"),
    )
    parser.add_argument(
        "--prior-synthetic",
        type=Path,
        default=ROOT / "outputs" / "ktc_concavity_v3_biological" / "seed_20260831"
        / "evaluation" / "synthetic_predictions.npz",
    )
    parser.add_argument(
        "--prior-real",
        type=Path,
        default=ROOT / "outputs" / "ktc_concavity_v3_biological" / "seed_20260831"
        / "evaluation" / "real_predictions.npz",
    )
    parser.add_argument(
        "--dataset", type=Path, default=ROOT / "datasets" / "ktc_shape_nonlinear_v1.npz"
    )
    parser.add_argument(
        "--audit", type=Path, default=ROOT / "outputs" / "ktc2023_full_audit" / "summary.json"
    )
    parser.add_argument(
        "--output-dir", type=Path, default=Path(r"E:\Codex\topology_residual_eit_v3_final")
    )
    parser.add_argument("--batch-size", type=int, default=24)
    parser.add_argument("--bootstrap", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=20260911)
    return parser.parse_args()


def indentation_mask(labels: np.ndarray) -> np.ndarray:
    """Return the per-instance convex-hull indentation proxy for public labels."""
    from matplotlib.path import Path as MplPath
    from scipy.ndimage import label as connected_components
    from scipy.spatial import ConvexHull, QhullError

    foreground = labels != 0
    components, count = connected_components(foreground)
    result = np.zeros_like(foreground)
    yy, xx = np.indices(foreground.shape)
    points = np.column_stack((xx.ravel(), yy.ravel()))
    for component in range(1, count + 1):
        mask = components == component
        coordinates = np.argwhere(mask)
        if len(coordinates) < 3:
            continue
        xy = np.column_stack((coordinates[:, 1], coordinates[:, 0]))
        try:
            hull = ConvexHull(xy)
        except QhullError:
            continue
        polygon = MplPath(xy[hull.vertices])
        filled = polygon.contains_points(points, radius=1e-6).reshape(mask.shape)
        result |= filled & ~mask
    return result


def case_metrics(truth: np.ndarray, prediction: np.ndarray, notch: np.ndarray) -> dict[str, float]:
    truth_foreground = truth != 0
    predicted_foreground = prediction != 0
    notch = np.asarray(notch, dtype=bool)
    intersection = np.logical_and(truth_foreground, predicted_foreground).sum()
    union = np.logical_or(truth_foreground, predicted_foreground).sum()
    truth_edge = np.logical_xor(truth_foreground, binary_erosion(truth_foreground))
    predicted_edge = np.logical_xor(predicted_foreground, binary_erosion(predicted_foreground))
    tolerance = np.ones((3, 3), dtype=bool)
    precision = (
        (predicted_edge & binary_dilation(truth_edge, structure=tolerance)).sum()
        / max(1, predicted_edge.sum())
    )
    recall = (
        (truth_edge & binary_dilation(predicted_edge, structure=tolerance)).sum()
        / max(1, truth_edge.sum())
    )
    predicted_holes = binary_fill_holes(predicted_foreground) & ~predicted_foreground
    truth_holes = binary_fill_holes(truth_foreground) & ~truth_foreground
    spurious_holes = predicted_holes & ~truth_holes
    truth_area = max(1, int(truth_foreground.sum()))
    return {
        "foreground_iou": float(intersection / max(1, union)),
        "foreground_dice": float(2 * intersection / max(1, truth_foreground.sum() + predicted_foreground.sum())),
        "boundary_f1": float(2 * precision * recall / max(1e-9, precision + recall)),
        "notch_preservation": float((~predicted_foreground[notch]).mean()) if notch.any() else float("nan"),
        "bank_retention": float(predicted_foreground[truth_foreground].mean()) if truth_foreground.any() else float("nan"),
        "false_negative_fraction": float((truth_foreground & ~predicted_foreground).sum() / truth_area),
        "spurious_hole_fraction": float(spurious_holes.sum() / truth_area),
    }


def evaluate_cases(
    ids: np.ndarray,
    truths: np.ndarray,
    notches: np.ndarray,
    predictions: dict[str, np.ndarray],
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for index, case_id in enumerate(ids):
        has_notch = bool(notches[index].any())
        for method, values in predictions.items():
            rows.append(
                {
                    "id": str(case_id),
                    "method": method,
                    "has_notch": has_notch,
                    "notch_pixels": int(notches[index].sum()),
                    **case_metrics(truths[index], values[index], notches[index]),
                }
            )
    return rows


def aggregate(rows: list[dict[str, object]], methods: tuple[str, ...] = METHODS) -> dict[str, object]:
    result: dict[str, object] = {}
    for method in methods:
        selected = [row for row in rows if row["method"] == method]
        summary: dict[str, float] = {"cases": float(len(selected))}
        for metric in METRICS:
            values = np.asarray([row[metric] for row in selected], dtype=float)
            summary[metric] = float(np.nanmean(values)) if np.isfinite(values).any() else float("nan")
        result[method] = summary
    return result


def paired_bootstrap(
    rows: list[dict[str, object]], candidate: str, reference: str, repetitions: int, seed: int
) -> dict[str, object]:
    candidate_rows = {str(row["id"]): row for row in rows if row["method"] == candidate}
    reference_rows = {str(row["id"]): row for row in rows if row["method"] == reference}
    ids = sorted(candidate_rows.keys() & reference_rows.keys())
    rng = np.random.default_rng(seed)
    result: dict[str, object] = {"cases": len(ids)}
    for metric in METRICS:
        difference = np.asarray(
            [float(candidate_rows[key][metric]) - float(reference_rows[key][metric]) for key in ids]
        )
        difference = difference[np.isfinite(difference)]
        if difference.size == 0:
            continue
        sampled = rng.integers(0, difference.size, size=(repetitions, difference.size))
        means = difference[sampled].mean(axis=1)
        result[metric] = {
            "mean_difference": float(difference.mean()),
            "ci95_low": float(np.percentile(means, 2.5)),
            "ci95_high": float(np.percentile(means, 97.5)),
            "probability_positive": float((means > 0).mean()),
        }
    return result


def safeguard_audit(
    rows: list[dict[str, object]], candidate: str = "topology_residual"
) -> dict[str, object]:
    direct = {str(row["id"]): row for row in rows if row["method"] == "direct_base"}
    final = {str(row["id"]): row for row in rows if row["method"] == candidate}
    ids = sorted(direct.keys() & final.keys())
    iou_change = np.asarray(
        [float(final[case]["foreground_iou"]) - float(direct[case]["foreground_iou"]) for case in ids]
    )
    hole_change = np.asarray(
        [float(final[case]["spurious_hole_fraction"]) - float(direct[case]["spurious_hole_fraction"]) for case in ids]
    )
    return {
        "cases": len(ids),
        "mean_final_minus_direct_iou": float(iou_change.mean()),
        "median_final_minus_direct_iou": float(np.median(iou_change)),
        "worst_final_minus_direct_iou": float(iou_change.min()),
        "fraction_regressed_more_than_0_01_iou": float((iou_change < -0.01).mean()),
        "fraction_improved_more_than_0_01_iou": float((iou_change > 0.01).mean()),
        "mean_added_spurious_hole_fraction": float(hole_change.mean()),
        "fraction_with_added_spurious_hole": float((hole_change > 1e-6).mean()),
    }


def inward_trend_audit(
    rows: list[dict[str, object]], candidate: str = "topology_residual"
) -> dict[str, object]:
    direct = {str(row["id"]): row for row in rows if row["method"] == "direct_base"}
    final = {str(row["id"]): row for row in rows if row["method"] == candidate}
    ids = sorted(direct.keys() & final.keys())
    notch_change = np.asarray(
        [float(final[case]["notch_preservation"]) - float(direct[case]["notch_preservation"]) for case in ids]
    )
    iou_change = np.asarray(
        [float(final[case]["foreground_iou"]) - float(direct[case]["foreground_iou"]) for case in ids]
    )
    finite = np.isfinite(notch_change)
    notch_change = notch_change[finite]
    iou_change = iou_change[finite]
    return {
        "cases": int(notch_change.size),
        "mean_final_minus_direct_notch_preservation": float(notch_change.mean()),
        "median_final_minus_direct_notch_preservation": float(np.median(notch_change)),
        "fraction_with_notch_improvement_over_0_05": float((notch_change > 0.05).mean()),
        "fraction_with_notch_improvement_and_iou_loss_under_0_02": float(
            ((notch_change > 0.05) & (iou_change >= -0.02)).mean()
        ),
        "mean_final_minus_direct_iou": float(iou_change.mean()),
    }


@torch.no_grad()
def infer_public(
    checkpoint: Path,
    fov: np.ndarray,
    images: np.ndarray,
    voltages: np.ndarray,
    batch_size: int,
) -> dict[str, np.ndarray]:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    state = torch.load(checkpoint, map_location=device, weights_only=False)
    model = TopologyResidualEITNet(
        fov,
        base=int(state["base_channels"]),
        propagation_steps=int(state.get("propagation_steps", 14)),
        risk_aware=bool(state.get("risk_aware", False)),
    ).to(device)
    model.load_state_dict(state["model"])
    model.eval()
    saved: dict[str, list[np.ndarray]] = {
        "direct_base": [], "topology_residual": [], "effective_cutout": [],
        "mouth": [], "case_gate": []
    }
    for start in range(0, len(images), batch_size):
        image = torch.from_numpy(images[start : start + batch_size, None].astype(np.float32)).to(device)
        voltage = torch.from_numpy(voltages[start : start + batch_size].astype(np.float32)).to(device)
        output = model(image, voltage)
        direct = F.interpolate(output["base_probabilities"], (256, 256), mode="bilinear", align_corners=False)
        final = F.interpolate(output["probabilities"], (256, 256), mode="bilinear", align_corners=False)
        effective = F.interpolate(
            output["effective_cutout_probability"], (256, 256), mode="bilinear", align_corners=False
        )
        mouth = F.interpolate(
            output["mouth_probability"], (256, 256), mode="bilinear", align_corners=False
        )
        saved["direct_base"].append(direct.argmax(dim=1).cpu().numpy())
        saved["topology_residual"].append(final.argmax(dim=1).cpu().numpy())
        saved["effective_cutout"].append(effective[:, 0].cpu().numpy())
        saved["mouth"].append(mouth[:, 0].cpu().numpy())
        saved["case_gate"].append(output["case_gate"][:, 0, 0, 0].cpu().numpy())
    return {key: np.concatenate(values) for key, values in saved.items()}


def apply_hole_resolver(
    predictions: np.ndarray,
    effective_cutout: np.ndarray,
    mouth: np.ndarray,
    case_gate: np.ndarray,
    parameters: dict[str, object],
) -> tuple[np.ndarray, dict[str, float]]:
    """Apply the frozen truth-blind resolver and accumulate its audit counts."""
    result = np.empty_like(predictions)
    totals = {"holes_seen": 0.0, "holes_opened": 0.0, "holes_filled": 0.0}
    for index in range(len(predictions)):
        result[index], audit = resolve_closed_holes(
            predictions[index],
            effective_cutout[index],
            mouth[index],
            float(case_gate[index]),
            confidence_threshold=float(parameters["confidence_threshold"]),
            mouth_weight=float(parameters["mouth_weight"]),
            path_width=int(parameters["path_width"]),
        )
        for key in totals:
            totals[key] += float(audit[key])
    return result, totals


def save_rows(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def select_cases(notches: np.ndarray, ordinary: int = 2, concave: int = 5) -> np.ndarray:
    pixels = notches.reshape(len(notches), -1).sum(axis=1)
    ordinary_indices = np.flatnonzero(pixels == 0)[:ordinary]
    concave_indices = np.argsort(pixels)[-concave:][::-1]
    return np.concatenate((concave_indices, ordinary_indices)).astype(int)


def save_comparison(
    path: Path,
    title: str,
    ids: np.ndarray,
    truths: np.ndarray,
    inputs: np.ndarray,
    notches: np.ndarray,
    predictions: dict[str, np.ndarray],
    selected: np.ndarray,
) -> None:
    columns = ("truth", "linear EIT", *METHODS)
    figure, axes = plt.subplots(len(selected), len(columns), figsize=(15.8, 2.15 * len(selected)), squeeze=False)
    for row, index in enumerate(selected):
        linear = inputs[index]
        scale = max(float(np.percentile(np.abs(linear), 99)), 1e-6)
        panels = [
            (truths[index], "viridis", 0, 2),
            (linear, "coolwarm", -scale, scale),
            *[(predictions[method][index], "viridis", 0, 2) for method in METHODS],
        ]
        for column, (panel, cmap, vmin, vmax) in enumerate(panels):
            axes[row, column].imshow(panel, cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest")
            axes[row, column].set_axis_off()
            if row == 0:
                axes[row, column].set_title(DISPLAY_NAMES.get(columns[column], columns[column]), fontsize=9)
        axes[row, 0].set_ylabel(f"{ids[index]}\nnotch={int(notches[index].sum())}", fontsize=8)
    figure.suptitle(title, fontsize=14)
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def save_topology_panel(
    path: Path,
    title: str,
    ids: np.ndarray,
    truths: np.ndarray,
    inputs: np.ndarray,
    direct: np.ndarray,
    residual: np.ndarray,
    raw_final: np.ndarray,
    final: np.ndarray,
    selected: np.ndarray,
) -> None:
    columns = (
        "truth", "linear EIT", "direct trunk", "cutout evidence", "raw topology", "topology-safe"
    )
    figure, axes = plt.subplots(len(selected), len(columns), figsize=(13.8, 2.15 * len(selected)), squeeze=False)
    for row, index in enumerate(selected):
        linear = inputs[index]
        scale = max(float(np.percentile(np.abs(linear), 99)), 1e-6)
        panels = (
            (truths[index], "viridis", 0, 2),
            (linear, "coolwarm", -scale, scale),
            (direct[index], "viridis", 0, 2),
            (residual[index], "magma", 0, 1),
            (raw_final[index], "viridis", 0, 2),
            (final[index], "viridis", 0, 2),
        )
        for column, (panel, cmap, vmin, vmax) in enumerate(panels):
            axes[row, column].imshow(panel, cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest")
            axes[row, column].set_axis_off()
            if row == 0:
                axes[row, column].set_title(columns[column], fontsize=9)
        axes[row, 0].set_ylabel(str(ids[index]), fontsize=8)
    figure.suptitle(title, fontsize=14)
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def save_metric_figure(path: Path, summaries: dict[str, dict[str, object]]) -> None:
    groups = ("biological_concave", "biological_ordinary", "stress", "public_nonconvex")
    metrics = ("foreground_iou", "notch_preservation", "bank_retention")
    figure, axes = plt.subplots(1, len(metrics), figsize=(15.0, 4.3))
    x = np.arange(len(groups))
    width = 0.135
    for method_index, method in enumerate(METHODS):
        for axis, metric in zip(axes, metrics):
            values = [float(summaries[group][method][metric]) for group in groups]
            axis.bar(
                x + (method_index - (len(METHODS) - 1) / 2) * width,
                values,
                width,
                label=DISPLAY_NAMES[method],
            )
    labels = ("biological\nconcave", "biological\nordinary", "deep stress", "public KTC\nnonconvex")
    for axis, metric in zip(axes, metrics):
        axis.set_title(metric.replace("_", " "))
        axis.set_xticks(x, labels)
        axis.set_ylim(0.0, 1.0)
        axis.grid(axis="y", alpha=0.25)
    axes[0].legend(fontsize=7, loc="lower left")
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    new = np.load(args.new_predictions.resolve())
    prior = np.load(args.prior_synthetic.resolve())
    resolver_document = json.loads(args.hole_resolver.resolve().read_text(encoding="utf-8"))
    resolver_parameters = resolver_document["best"]
    synthetic_rows: list[dict[str, object]] = []
    summaries: dict[str, dict[str, object]] = {}
    comparisons: dict[str, object] = {}
    safeguard: dict[str, object] = {}
    inward_trend: dict[str, object] = {}
    resolver_audit: dict[str, object] = {}

    for group_index, (group, prefix) in enumerate(GROUPS.items()):
        truth = new[f"{group}_truth"]
        if not np.array_equal(truth, prior[f"{prefix}_truth"]):
            raise ValueError(f"{group} truth differs between frozen experiments")
        ids = prior[f"{prefix}_ids"]
        notch = new[f"{group}_cutout"].astype(bool)
        topology_safe, resolver_audit[group] = apply_hole_resolver(
            new[f"{group}_prediction"],
            new[f"{group}_effective_cutout"],
            new[f"{group}_mouth"],
            new[f"{group}_case_gate"],
            resolver_parameters,
        )
        predictions = {
            "vanilla": prior[f"{prefix}_vanilla"],
            "shape_aware": prior[f"{prefix}_candidate"],
            "protected": prior[f"{prefix}_protected"],
            "direct_base": new[f"{group}_base_prediction"],
            "topology_residual": new[f"{group}_prediction"],
            "topology_safe": topology_safe,
        }
        rows = evaluate_cases(ids, truth, notch, predictions)
        for row in rows:
            row["group"] = group
        synthetic_rows.extend(rows)
        concave_rows = [row for row in rows if bool(row["has_notch"])]
        ordinary_rows = [row for row in rows if not bool(row["has_notch"])]
        summaries[group] = aggregate(rows)
        if concave_rows:
            summaries[f"{group}_concave"] = aggregate(concave_rows)
            inward_trend[group] = {
                method: inward_trend_audit(concave_rows, method)
                for method in ("topology_residual", "topology_safe")
            }
        if ordinary_rows:
            summaries[f"{group}_ordinary"] = aggregate(ordinary_rows)
            safeguard[group] = {
                method: safeguard_audit(ordinary_rows, method)
                for method in ("topology_residual", "topology_safe")
            }
        comparisons[group] = {
            baseline: paired_bootstrap(
                rows, "topology_safe", baseline, args.bootstrap, args.seed + 100 * group_index
            )
            for baseline in METHODS[:-1]
        }
        selected = select_cases(notch)
        save_comparison(
            output_dir / f"{group}_comparison.png",
            f"Independent {group} test",
            ids,
            truth,
            new[f"{group}_image"],
            notch,
            predictions,
            selected,
        )
        save_topology_panel(
            output_dir / f"{group}_topology_mechanism.png",
            f"Topology mechanism on independent {group} cases",
            ids,
            truth,
            new[f"{group}_image"],
            predictions["direct_base"],
            new[f"{group}_effective_cutout"],
            predictions["topology_residual"],
            predictions["topology_safe"],
            selected,
        )

    dataset = np.load(args.dataset.resolve(), allow_pickle=False)
    prior_real = np.load(args.prior_real.resolve())
    public_truth = prior_real["truth"]
    public_ids = prior_real["ids"]
    public_inference = infer_public(
        args.checkpoint.resolve(),
        np.asarray(dataset["fov_mask"], dtype=np.uint8),
        np.asarray(dataset["real_linear_images"], dtype=np.float32),
        np.asarray(dataset["real_voltages"], dtype=np.float32),
        args.batch_size,
    )
    public_notch = np.stack([indentation_mask(labels) for labels in public_truth])
    public_safe, resolver_audit["public_ktc"] = apply_hole_resolver(
        public_inference["topology_residual"],
        public_inference["effective_cutout"],
        public_inference["mouth"],
        public_inference["case_gate"],
        resolver_parameters,
    )
    public_predictions = {
        "vanilla": prior_real["vanilla"],
        "shape_aware": prior_real["candidate"],
        "protected": prior_real["protected"],
        "direct_base": public_inference["direct_base"],
        "topology_residual": public_inference["topology_residual"],
        "topology_safe": public_safe,
    }
    public_rows = evaluate_cases(public_ids, public_truth, public_notch, public_predictions)
    for row in public_rows:
        row["group"] = "public_ktc"
    audit = json.loads(args.audit.resolve().read_text(encoding="utf-8"))
    nonconvex_ids = set(map(str, audit["nonconvex_ids"]))
    nonconvex_rows = [row for row in public_rows if str(row["id"]) in nonconvex_ids]
    ordinary_rows = [row for row in public_rows if str(row["id"]) not in nonconvex_ids]
    summaries["public_all"] = aggregate(public_rows)
    summaries["public_nonconvex"] = aggregate(nonconvex_rows)
    summaries["public_ordinary"] = aggregate(ordinary_rows)
    inward_trend["public_nonconvex"] = {
        method: inward_trend_audit(nonconvex_rows, method)
        for method in ("topology_residual", "topology_safe")
    }
    safeguard["public_ordinary"] = {
        method: safeguard_audit(ordinary_rows, method)
        for method in ("topology_residual", "topology_safe")
    }
    comparisons["public_nonconvex"] = {
        baseline: paired_bootstrap(
            nonconvex_rows, "topology_safe", baseline, args.bootstrap, args.seed + 701
        )
        for baseline in METHODS[:-1]
    }
    strict_indices = np.asarray(
        [index for index, value in enumerate(public_ids) if str(value) in nonconvex_ids], dtype=int
    )
    strict_order = strict_indices[
        np.argsort(public_notch[strict_indices].reshape(len(strict_indices), -1).sum(axis=1))[::-1]
    ][:8]
    save_comparison(
        output_dir / "public_ktc_nonconvex_comparison.png",
        "Public KTC2023 audited non-convex cases",
        public_ids,
        public_truth,
        np.asarray(dataset["real_linear_images"]),
        public_notch,
        public_predictions,
        strict_order,
    )
    save_topology_panel(
        output_dir / "public_ktc_topology_mechanism.png",
        "Public KTC2023: direct trunk and learned topology residual",
        public_ids,
        public_truth,
        np.asarray(dataset["real_linear_images"]),
        public_predictions["direct_base"],
        public_inference["effective_cutout"],
        public_predictions["topology_residual"],
        public_predictions["topology_safe"],
        strict_order,
    )

    save_rows(output_dir / "synthetic_case_metrics.csv", synthetic_rows)
    save_rows(output_dir / "public_ktc_case_metrics.csv", public_rows)
    np.savez_compressed(
        output_dir / "public_ktc_predictions.npz",
        ids=public_ids,
        truth=public_truth,
        notch=public_notch.astype(np.uint8),
        effective_cutout=public_inference["effective_cutout"],
        mouth=public_inference["mouth"],
        case_gate=public_inference["case_gate"],
        **public_predictions,
    )
    save_metric_figure(output_dir / "unified_metric_comparison.png", summaries)
    result = {
        "method": "from-scratch direct reconstruction with validated topology-safe projection",
        "checkpoint": str(args.checkpoint.resolve()),
        "synthetic_truths_byte_identical_across_experiments": True,
        "public_ktc_truth_used_for_training_or_model_selection": False,
        "hole_resolver_selection_data": resolver_document["selection_data"],
        "hole_resolver_parameters": {
            key: resolver_parameters[key]
            for key in ("confidence_threshold", "mouth_weight", "path_width")
        },
        "hole_resolver_audit": resolver_audit,
        "summaries": summaries,
        "ordinary_safeguard_audit": safeguard,
        "inward_trend_audit": inward_trend,
        "paired_bootstrap_topology_safe_minus_baseline": comparisons,
    }
    (output_dir / "comparison_summary.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
