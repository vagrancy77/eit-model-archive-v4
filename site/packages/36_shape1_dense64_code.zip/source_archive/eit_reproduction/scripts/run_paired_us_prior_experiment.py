from __future__ import annotations

import argparse
import json
import os
import random
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import scipy.io as sio
from PIL import Image


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    import torch

    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def save_png(labels: np.ndarray, path: Path) -> None:
    Image.fromarray(np.clip(labels * 127.5, 0, 255).astype(np.uint8)).save(path)


def build_scenarios(mask: np.ndarray) -> dict[str, dict[str, np.ndarray]]:
    from run_us_prior_robustness_experiment import build_scenarios as _build

    return _build(mask)


def main() -> None:
    project_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description="Paired-seed EIT fallback validation.")
    parser.add_argument("--repo-root", type=Path, default=project_root / "external" / "KTC2023-ABC2")
    parser.add_argument("--output-dir", type=Path, default=project_root / "outputs" / "us_prior_paired_250")
    parser.add_argument("--num-iter", type=int, default=250)
    parser.add_argument("--seed", type=int, default=20260802)
    parser.add_argument("--geo-lambda", type=float, default=2e-2)
    parser.add_argument("--reliability-reg", type=float, default=5e-4)
    parser.add_argument("--registration-reg", type=float, default=5e-4)
    parser.add_argument(
        "--no-oracle-reliability",
        action="store_true",
        help="Do not scale reliability using the known synthetic corruption type.",
    )
    args = parser.parse_args()

    repo_root = args.repo_root.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    os.chdir(repo_root)
    sys.path.insert(0, str(repo_root))
    sys.path.insert(0, str(project_root / "scripts"))
    from utils import solver
    from run_us_prior_robustness_experiment import metrics

    input_path = repo_root / "inputs" / "data1.mat"
    truth_path = repo_root / "groundTruths" / "true1.mat"
    truth = np.asarray(sio.loadmat(truth_path)["truth"], dtype=np.int64)
    from run_us_prior_robustness_experiment import build_scenarios as build_scenarios_configured

    scenarios = build_scenarios_configured(
        (truth > 0).astype(np.float64), oracle_quality=not args.no_oracle_reliability
    )
    rows: list[dict[str, object]] = []
    image_methods = ("baseline", "hard_mask", "registration", "fallback")

    for scenario_index, (scenario_name, scenario) in enumerate(scenarios.items(), start=1):
        seed = args.seed + scenario_index * 100
        prior_hard = np.flipud(scenario["hard_mask"]).copy()
        prior_mask = np.flipud(scenario["mask"]).copy()
        reliability = np.flipud(scenario["reliability"]).copy()
        configurations = {
            "baseline": dict(),
            "hard_mask": dict(prior_mask=prior_hard, geo_lambda=0.0, hard_prior=True),
            "registration": dict(
                prior_mask=prior_mask,
                prior_reliability=reliability,
                geo_lambda=args.geo_lambda,
                learn_reliability=True,
                reliability_reg=args.reliability_reg,
                learn_registration=True,
                registration_reg=args.registration_reg,
            ),
            "fallback": dict(
                prior_mask=prior_mask,
                prior_reliability=reliability,
                geo_lambda=0.0,
                learn_reliability=True,
                reliability_reg=args.reliability_reg,
                learn_registration=True,
                registration_reg=args.registration_reg,
                reliability_fallback=True,
            ),
        }
        for method_name in image_methods:
            set_seed(seed)
            reconstruction, details = solver.solve(
                str(input_path),
                1,
                num_iter_override=args.num_iter,
                progress_every=0,
                return_details=True,
                **configurations[method_name],
            )
            save_png(reconstruction, output_dir / f"{scenario_name}_{method_name}.png")
            if details.get("final_registration_raw") is not None:
                np.save(output_dir / f"{scenario_name}_{method_name}_registration_raw.npy", details["final_registration_raw"])
            rows.append({
                "scenario": scenario_name,
                "method": method_name,
                "seed": seed,
                "metrics": metrics(truth, reconstruction),
                "final_total_loss": details["final_total_loss"],
            })

    summary = {
        "experiment": "paired_seed_eit_fallback_validation",
        "num_iter": args.num_iter,
        "base_seed": args.seed,
        "paired_seed_protocol": True,
        "oracle_reliability": not args.no_oracle_reliability,
        "rows": rows,
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    figure, axes = plt.subplots(5, 6, figsize=(18, 15), squeeze=False, constrained_layout=True)
    for row_index, scenario_name in enumerate(scenarios):
        scenario = scenarios[scenario_name]
        axes[row_index, 0].imshow(scenario["mask"], cmap="gray", vmin=0, vmax=1)
        axes[row_index, 0].set_title(f"{scenario_name}: US prior")
        axes[row_index, 1].imshow(truth, cmap="gray", vmin=0, vmax=2)
        axes[row_index, 1].set_title("Ground truth")
        for col, method_name in enumerate(image_methods, start=2):
            image = np.asarray(Image.open(output_dir / f"{scenario_name}_{method_name}.png"))
            axes[row_index, col].imshow(image, cmap="gray", vmin=0, vmax=255)
            axes[row_index, col].set_title(method_name.replace("_", " "))
        for col in range(6):
            axes[row_index, col].set_axis_off()
    figure.suptitle("Paired-seed ultrasound prior / EIT fallback validation", fontsize=15)
    figure.savefig(output_dir / "comparison.png", dpi=220)
    plt.close(figure)
    print(f"Saved {output_dir / 'summary.json'}")
    print(f"Saved {output_dir / 'comparison.png'}")


if __name__ == "__main__":
    main()
