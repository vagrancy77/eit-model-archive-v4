from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import scipy.io as sio
from PIL import Image


def parse_args() -> argparse.Namespace:
    project_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(
        description=(
            "Render side-by-side KTC2023-ABC2 reference figures using the "
            "bundled ground truths, bundled outputs, and optional local smoke outputs."
        )
    )
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=project_root / "external" / "KTC2023-ABC2",
    )
    parser.add_argument(
        "--smoke-output-dir",
        type=Path,
        default=project_root / "outputs" / "ktc2023_abc2_smoke",
    )
    parser.add_argument(
        "--output-path",
        type=Path,
        default=project_root
        / "outputs"
        / "ktc2023_abc2_reference"
        / "ktc2023_abc2_reference_examples.png",
    )
    return parser.parse_args()


def png_to_labels(path: Path) -> np.ndarray:
    image = np.asarray(Image.open(path), dtype=np.float64)
    return np.rint(image * 2.0 / 255.0).astype(np.int64)


def main() -> None:
    args = parse_args()
    repo_root = args.repo_root.resolve()
    smoke_output_dir = args.smoke_output_dir.resolve()
    output_path = args.output_path.resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    truth_files = sorted((repo_root / "groundTruths").glob("true*.mat"))
    n_cases = len(truth_files)
    show_smoke = smoke_output_dir.exists() and any(smoke_output_dir.glob("data*.png"))
    n_cols = 3 if show_smoke else 2

    figure, axes = plt.subplots(
        n_cases,
        n_cols,
        figsize=(4.2 * n_cols, 3.6 * n_cases),
        constrained_layout=True,
    )
    if n_cases == 1:
        axes = np.array([axes])
    if n_cols == 1:
        axes = axes[:, None]

    cmap = "gray"
    vmin, vmax = 0, 2

    for row, truth_path in enumerate(truth_files):
        case_idx = row + 1
        truth = sio.loadmat(truth_path)["truth"]
        bundled = png_to_labels(repo_root / "outputs" / f"data{case_idx}.png")

        axes[row, 0].imshow(truth, cmap=cmap, vmin=vmin, vmax=vmax)
        axes[row, 0].set_title(f"Ground truth {case_idx}")
        axes[row, 0].set_axis_off()

        axes[row, 1].imshow(bundled, cmap=cmap, vmin=vmin, vmax=vmax)
        axes[row, 1].set_title(f"Bundled output {case_idx}")
        axes[row, 1].set_axis_off()

        if show_smoke:
            smoke_path = smoke_output_dir / f"data{case_idx}.png"
            if smoke_path.exists():
                smoke = png_to_labels(smoke_path)
            else:
                smoke = np.zeros_like(truth)
            axes[row, 2].imshow(smoke, cmap=cmap, vmin=vmin, vmax=vmax)
            axes[row, 2].set_title(f"Local smoke output {case_idx}")
            axes[row, 2].set_axis_off()

    figure.suptitle("KTC2023-ABC2 DIP+TV reference comparison", fontsize=14)
    figure.savefig(output_path, dpi=220)
    plt.close(figure)
    print(f"Saved figure to {output_path}")


if __name__ == "__main__":
    main()
