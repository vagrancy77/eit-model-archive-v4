"""Search fixed physics/neural score mixtures on frozen complete-level OOF models."""
from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np
import torch

import train_ktc_spatial_topology_bay_oof as core


def parse_args():
    root = Path(__file__).resolve().parents[1]
    p = argparse.ArgumentParser()
    p.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    p.add_argument("--pool", type=Path, default=root / "outputs" / "ktc_cross_representation_pool_seed20260820" / "public_21.npz")
    p.add_argument("--cache-dir", type=Path, default=Path(r"E:\Codex\ktc_expanded_pure_bay_candidate_cache_seed20260820"))
    p.add_argument("--target-dir", type=Path, default=Path(r"E:\Codex\ktc_expanded_pure_bay_training_targets_seed20260820"))
    p.add_argument("--pretrained", type=Path, default=Path(r"E:\Codex\ktc_synthetic_pure_bay_physics_ranker_seed20260820\synthetic_bay_risk_ranker.pt"))
    p.add_argument("--model-dir", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--patch-size", type=int, default=20)
    return p.parse_args()


def zscore(values):
    med = np.median(values)
    scale = (np.quantile(values, .75) - np.quantile(values, .25)) / 1.349
    return (values - med) / max(float(scale), float(np.std(values)), 1e-5)


def metrics(cases, choices):
    values = np.stack([case.targets[index] for case, index in zip(cases, choices)])
    changed = choices != 0
    finite = np.isfinite(values[:, 2])
    safe = (
        np.all(values[:, 0] >= -1e-9) and np.all(values[:, 1] >= -.005)
        and (not np.any(changed & finite & (values[:, 2] < -1e-9)))
        and (not np.any(changed & np.isfinite(values[:, 4]) & (values[:, 4] < -.020)))
    )
    useful = changed & (values[:, 0] >= .002) & finite & (values[:, 2] >= .005)
    return {"safe": bool(safe), "changed": int(changed.sum()), "useful": int(useful.sum()),
            "mean_iou": float(values[:, 0].mean()), "strict_iou": float(values[:0,0].mean()) if False else 0.0,
            "min_iou": float(values[:, 0].min())}


def main():
    args = parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    pretrained = torch.load(args.pretrained.resolve(), map_location="cpu", weights_only=False)
    cases, _, _ = core.load_public_cases(args)
    fronts = {case.case_id: core.candidate_front(case, 1536) for case in cases}
    patches = core.build_spatial_inputs(args, cases, fronts, device)
    evidence = {}
    for level in sorted({case.level for case in cases}):
        payload = torch.load(args.model_dir.resolve() / f"exclude_{level}.pt", map_location=device, weights_only=False)
        channels = next(iter(patches.values())).shape[1]
        models=[]
        for member,state in enumerate(payload["models"]):
            model=core.SpatialTopologyRanker(pretrained["models"][member % len(pretrained["models"])],channels).to(device)
            model.load_state_dict(state); model.eval(); models.append(model)
        for case in cases:
            if case.level != level: continue
            evidence[case.case_id]=core.predict_case(case,fronts[case.case_id],patches[case.case_id],models,pretrained,payload["target_mean"],payload["target_scale"],device,feature_normalization="relative")
    rows=[]
    strict_ids=set(core.STRICT_INWARD_IDS)
    for max_removal in (0.08, 0.12, 0.16, 0.20, 0.25, 0.35):
     for gamma in np.linspace(-3,3,25):
      for phys_name,phys_col in [("cv_mean",76),("cv_min",78),("cv_pos",80),("fixed_global",81),("fixed_drive",82),("fixed_consensus",None),("pool_agreement",114),("background",117)]:
       for threshold in np.linspace(-2,2,17):
        choices=[]
        for case in cases:
          ev=evidence[case.case_id]; valid=case.valid.copy(); valid &= case.removed <= max_removal; valid[0]=True
          neural=zscore(ev.score)
          if phys_col is None: phys=zscore(case.features[:,81:85].mean(1))
          else: phys=zscore(case.features[:,phys_col])
          score=neural+gamma*phys
          index=int(np.argmax(np.where(valid,score,-np.inf)))
          choices.append(index if score[index]>=threshold else 0)
        choices=np.asarray(choices); vals=np.stack([c.targets[i] for c,i in zip(cases,choices)]); ch=choices!=0; finite=np.isfinite(vals[:,2]);
        safe=(vals[:,0].min()>=-1e-9 and vals[:,1].min()>=-.005 and not np.any(ch&finite&(vals[:,2]<-1e-9)) and not np.any(ch&np.isfinite(vals[:,4])&(vals[:,4]<-.020)))
        useful=ch&(vals[:,0]>=.002)&finite&(vals[:,2]>=.005)
        rows.append({"max_removal":max_removal,"gamma":gamma,"physics":phys_name,"threshold":threshold,"safe":safe,"changed":int(ch.sum()),"useful":int(useful.sum()),"all_iou":float(vals[:,0].mean()),"strict_iou":float(vals[[c.case_id in strict_ids for c in cases],0].mean()),"ordinary_iou":float(vals[[c.case_id not in strict_ids for c in cases],0].mean()),"strict_changed":int(ch[[c.case_id in strict_ids for c in cases]].sum()),"strict_useful":int(useful[[c.case_id in strict_ids for c in cases]].sum())})
    args.output.resolve().parent.mkdir(parents=True,exist_ok=True)
    with args.output.resolve().open('w',newline='',encoding='utf-8') as f:
      w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    valid=[r for r in rows if r['safe'] and r['strict_useful']>0 and r['strict_iou']>=0 and r['ordinary_iou']>=0]
    for r in sorted(valid,key=lambda x:(x['strict_iou']+x['ordinary_iou'],x['strict_useful']),reverse=True)[:30]: print(r)

if __name__=='__main__': main()
