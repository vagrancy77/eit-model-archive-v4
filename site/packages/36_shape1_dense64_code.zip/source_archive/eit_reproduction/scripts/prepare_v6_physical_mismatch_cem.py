"""Generate an independent nonlinear-CEM physical-mismatch test set.

This is an evaluation-only archive.  The same held-out lesion geometry is
solved under nominal physics, out-of-range global contact impedance,
heterogeneous per-electrode contact impedance, a smooth heterogeneous
background, and their combination.  Every condition uses a matched reference
solve, so the archive remains a differential-EIT experiment.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import scipy as sp

from prepare_ktc_biological_concavity import FAMILIES, generate_geometry


CONDITIONS = (
    "nominal",
    "contact_global_2p4x",
    "contact_heterogeneous_logsd0p55",
    "background_smooth_0p16",
    "combined_contact_background",
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--samples", type=int, default=96)
    parser.add_argument("--resolution", type=int, default=64)
    parser.add_argument("--seed", type=int, default=20261107)
    parser.add_argument("--snr-db", type=float, default=40.0)
    parser.add_argument("--voltage-scale", type=float, default=2.0)
    parser.add_argument(
        "--base-dataset", type=Path,
        default=root / "datasets" / "ktc_shape_nonlinear_v1.npz",
    )
    parser.add_argument(
        "--repo-root", type=Path,
        default=root / "external" / "KTC2023-ABC2",
    )
    parser.add_argument(
        "--reference", type=Path,
        default=(
            root / "datasets" / "ktc2023_full" / "v3" / "evaluation_full"
            / "EvaluationData_full" / "evaluation_datasets" / "level1" / "ref.mat"
        ),
    )
    parser.add_argument(
        "--output", type=Path,
        default=root / "datasets" / "ktc_v6_physical_mismatch_cem_v1.npz",
    )
    return parser.parse_args()


def build_forward_solver(repo_root: Path, reference: Path):
    """Build the public KTC complete-electrode-model forward solver.

    This local loader intentionally avoids importing ``utils.solver`` because
    that module also imports the DIP/PyTorch reconstruction stack.  Only the
    public meshing and CEM forward modules are required for data generation.
    """
    from utils import KTCFwd, KTCMeshing

    nel = 32
    data = sp.io.loadmat(str(reference))
    injections = data["Injref"]
    reference_electrodes = data["Uelref"]
    measurement_pattern = data["Mpat"]
    included = np.ones((nel - 1, 76), dtype=bool)

    mesh_data = sp.io.loadmat(str(repo_root / "utils" / "reference_files" / "Mesh_sparse.mat"))
    coordinates = mesh_data["g"]
    topology = [value[0].flatten() for value in mesh_data["Element"]["Topology"].tolist()]
    electrode_elements = mesh_data["ElementE"].tolist()
    for index in range(len(electrode_elements)):
        if len(electrode_elements[index][0]) > 0:
            values = electrode_elements[index][0][0]
            electrode_elements[index] = [values[0], values[1:len(values)]]
        else:
            electrode_elements[index] = []
    node_coordinates = mesh_data["Node"]["Coordinate"]
    node_connections = mesh_data["Node"]["ElementConnection"]
    nodes = [KTCMeshing.NODE(value[0].flatten(), []) for value in node_coordinates]
    for index in range(node_coordinates.shape[0]):
        nodes[index].ElementConnection = node_connections[index][0].flatten()
    elements = [KTCMeshing.ELEMENT(index, []) for index in topology]
    for index in range(len(topology)):
        elements[index].Electrode = electrode_elements[index]

    coordinates2 = mesh_data["g2"]
    topology2 = [value[0].flatten() for value in mesh_data["Element2"]["Topology"].tolist()]
    electrode_elements2 = mesh_data["Element2E"].tolist()
    for index in range(len(electrode_elements2)):
        if len(electrode_elements2[index][0]) > 0:
            values = electrode_elements2[index][0][0]
            electrode_elements2[index] = [values[0], values[1:len(values)]]
        else:
            electrode_elements2[index] = []
    node_coordinates2 = mesh_data["Node2"]["Coordinate"]
    node_connections2 = mesh_data["Node2"]["ElementConnection"]
    nodes2 = [KTCMeshing.NODE(value[0].flatten(), []) for value in node_coordinates2]
    for index in range(node_coordinates2.shape[0]):
        nodes2[index].ElementConnection = node_connections2[index][0].flatten()
    elements2 = [KTCMeshing.ELEMENT(index, []) for index in topology2]
    for index in range(len(topology2)):
        elements2[index].Electrode = electrode_elements2[index]

    mesh = KTCMeshing.Mesh(
        mesh_data["H"], coordinates, mesh_data["elfaces"][0].tolist(), nodes, elements
    )
    mesh2 = KTCMeshing.Mesh(
        mesh_data["H2"], coordinates2, mesh_data["elfaces2"][0].tolist(), nodes2, elements2
    )
    forward = KTCFwd.EITFEM(mesh2, injections, measurement_pattern, included)
    forward.SetInvGamma(0.05, 0.01, reference_electrodes)
    sigma0 = np.ones((len(mesh.g), 1), dtype=np.float64) * 0.7927
    contact0 = np.ones((nel, 1), dtype=np.float64) * 1e-6
    return forward, sigma0, contact0, np.asarray(coordinates, dtype=np.float64)


def smooth_background(
    coordinates: np.ndarray,
    case_index: int,
    seed: int,
    amplitude: float = 0.16,
) -> np.ndarray:
    centered = coordinates - coordinates.mean(axis=0, keepdims=True)
    scale = np.max(np.linalg.norm(centered, axis=1)).clip(min=1e-9)
    x = centered[:, 0] / scale
    y = centered[:, 1] / scale
    rng = np.random.default_rng(seed + 7919 * (case_index + 1))
    angle = float(rng.uniform(-np.pi, np.pi))
    phase = float(rng.uniform(-np.pi, np.pi))
    first = np.sin(np.pi * (np.cos(angle) * x + np.sin(angle) * y) + phase)
    second = 0.55 * np.cos(
        1.6 * np.pi * (-np.sin(angle) * x + np.cos(angle) * y) - 0.7 * phase
    )
    center = rng.uniform(-0.45, 0.45, size=2)
    bump = 0.70 * np.exp(-((x - center[0]) ** 2 + (y - center[1]) ** 2) / 0.22)
    field = first + second + bump
    field -= field.mean()
    field /= max(1e-8, float(np.max(np.abs(field))))
    return (amplitude * field).astype(np.float64)[:, None]


def heterogeneous_contact(case_index: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed + 104729 * (case_index + 1))
    values = np.exp(rng.normal(0.0, 0.55, size=32))
    values /= np.exp(np.mean(np.log(values)))
    return np.clip(values, 0.35, 2.8).astype(np.float64)[:, None]


def condition_physics(
    condition: str,
    case_index: int,
    sigma0: np.ndarray,
    contact0: np.ndarray,
    coordinates: np.ndarray,
    seed: int,
) -> tuple[np.ndarray, np.ndarray]:
    if condition == "nominal":
        return sigma0.copy(), contact0.copy()
    if condition == "contact_global_2p4x":
        return sigma0.copy(), 2.4 * contact0
    background = sigma0.copy()
    contact = contact0.copy()
    if condition in {"background_smooth_0p16", "combined_contact_background"}:
        background = np.clip(
            background + smooth_background(coordinates, case_index, seed), 0.25, None
        )
    if condition == "contact_heterogeneous_logsd0p55":
        contact *= heterogeneous_contact(case_index, seed)
    elif condition == "combined_contact_background":
        contact *= 2.2 * heterogeneous_contact(case_index, seed + 17)
    elif condition != "background_smooth_0p16":
        raise ValueError(condition)
    return background, contact


def solve_archive(args: argparse.Namespace) -> dict[str, np.ndarray]:
    geometry = generate_geometry(
        args.samples,
        args.resolution,
        args.seed,
        train_end=0,
        validation_end=0,
    )
    base = np.load(args.base_dataset.resolve(), allow_pickle=False)
    node_to_raw_pixel = np.asarray(base["node_to_raw_pixel"], dtype=np.int64)
    raw_pixel_to_node = np.asarray(base["raw_pixel_to_node"], dtype=np.int64)
    reconstruction_operator = np.asarray(base["reconstruction_operator"], dtype=np.float32)
    raw_delta = np.flip(geometry["delta"], axis=1).reshape(args.samples, -1)
    node_delta = raw_delta[:, node_to_raw_pixel].astype(np.float64)

    old_cwd = Path.cwd()
    repo_root = args.repo_root.resolve()
    os.chdir(repo_root)
    sys.path.insert(0, str(repo_root))
    try:
        forward, sigma0, contact0, coordinates = build_forward_solver(
            repo_root, args.reference.resolve()
        )
        clean = np.empty(
            (len(CONDITIONS), args.samples, reconstruction_operator.shape[1]),
            dtype=np.float32,
        )
        constant_references: dict[str, np.ndarray] = {}
        for condition_index, condition in enumerate(CONDITIONS):
            print(f"CEM condition {condition_index + 1}/{len(CONDITIONS)}: {condition}", flush=True)
            for case_index in range(args.samples):
                background, contact = condition_physics(
                    condition, case_index, sigma0, contact0, coordinates, args.seed
                )
                if condition in {"nominal", "contact_global_2p4x"}:
                    if condition not in constant_references:
                        constant_references[condition] = np.asarray(
                            forward.SolveForward(background.copy(), contact.copy())
                        ).reshape(-1)
                    reference = constant_references[condition]
                else:
                    reference = np.asarray(
                        forward.SolveForward(background.copy(), contact.copy())
                    ).reshape(-1)
                lesion_sigma = np.clip(
                    background + node_delta[case_index, :, None], 0.05, None
                )
                measured = np.asarray(
                    forward.SolveForward(lesion_sigma, contact.copy())
                ).reshape(-1)
                clean[condition_index, case_index] = (
                    args.voltage_scale * (measured - reference)
                ).astype(np.float32)
                if (case_index + 1) % 12 == 0 or case_index + 1 == args.samples:
                    print(
                        f"  {condition}: {case_index + 1}/{args.samples}",
                        flush=True,
                    )
    finally:
        os.chdir(old_cwd)

    rng = np.random.default_rng(args.seed + 23)
    standard_noise = rng.normal(size=(args.samples, clean.shape[2])).astype(np.float32)
    voltages = clean.copy()
    for condition_index in range(len(CONDITIONS)):
        rms = np.sqrt(
            np.mean(clean[condition_index].astype(np.float64) ** 2, axis=1, keepdims=True)
        ).astype(np.float32)
        voltages[condition_index] += standard_noise * (
            rms / (10.0 ** (args.snr_db / 20.0)) + 1e-9
        )
    nodes = voltages @ reconstruction_operator.T
    raw = nodes[:, :, raw_pixel_to_node].reshape(
        len(CONDITIONS), args.samples, args.resolution, args.resolution
    )
    linear_images = np.flip(raw, axis=2).astype(np.float32)
    case_ids = np.asarray([f"cem_shift_{index:03d}" for index in range(args.samples)])
    return {
        **geometry,
        "case_ids": case_ids,
        "conditions": np.asarray(CONDITIONS),
        "voltages": voltages.astype(np.float32),
        "clean_voltages": clean.astype(np.float32),
        "linear_images": linear_images,
        "jacobian": np.asarray(base["jacobian"], dtype=np.float32),
        "reconstruction_operator": reconstruction_operator,
        "node_to_raw_pixel": node_to_raw_pixel,
        "raw_pixel_to_node": raw_pixel_to_node,
        "node_coordinates": np.asarray(base["node_coordinates"], dtype=np.float32),
        "snr_db": np.asarray(args.snr_db, dtype=np.float32),
    }


def save_preview(path: Path, data: dict[str, np.ndarray]) -> None:
    family_codes = np.asarray(data["family_codes"])
    indices = [int(np.flatnonzero(family_codes == code)[0]) for code in range(4, 8)]
    figure, axes = plt.subplots(len(indices), len(CONDITIONS) + 1, figsize=(16.0, 9.5))
    for row, index in enumerate(indices):
        family = FAMILIES[int(family_codes[index])]
        axes[row, 0].imshow(data["labels"][index], cmap="viridis", interpolation="nearest")
        axes[row, 0].set_title(f"truth: {family}", fontsize=9)
        axes[row, 0].set_axis_off()
        for column, condition in enumerate(CONDITIONS, start=1):
            axes[row, column].imshow(
                data["linear_images"][column - 1, index], cmap="coolwarm"
            )
            axes[row, column].set_title(condition.replace("_", " "), fontsize=8)
            axes[row, column].set_axis_off()
    figure.suptitle("Independent nonlinear-CEM physical-mismatch archive")
    figure.tight_layout()
    figure.savefig(path, dpi=220)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    if args.samples < 4:
        raise ValueError("at least four samples are required")
    data = solve_archive(args)
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(output, **data)
    save_preview(output.with_name(output.stem + "_preview.png"), data)
    concave = np.asarray(data["cutout_masks"]).reshape(args.samples, -1).sum(axis=1) > 0
    summary = {
        "output": str(output),
        "samples": args.samples,
        "concave_cases": int(concave.sum()),
        "ordinary_cases": int((~concave).sum()),
        "conditions": list(CONDITIONS),
        "geometry_families": [FAMILIES[index] for index in range(4, 8)],
        "forward_model": "public KTC nonlinear complete electrode model",
        "differential_reference_recomputed_per_physical_condition": True,
        "snr_db": args.snr_db,
        "training_or_validation_use": False,
        "seed": args.seed,
    }
    output.with_suffix(".json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
