"""Nested multi-task ranker for physics/topology-aware KTC bay candidates.

The inference cache is label-free.  For every outer KTC level, all regression
heads and the identity fallback policy are fit/calibrated using only the other
complete levels.  The outer truth is accessed only after its three predictions
have been frozen.  Strict-inward IDs are used solely for the final report.
"""
from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np

from audit_ktc_instance_bay_topology import case_metrics, edit_metrics, paired_bootstrap
from train_ktc_instance_bay_nested_ranker import (
    CaseData,
    STRICT_INWARD_IDS,
    boundary_f1_per_case,
    case_filename,
    foreground_iou_per_case,
    load_cases,
    save_montage,
    topology_checks,
    write_csv,
)


HEAD_NAMES = ("foreground_iou", "boundary_f1", "bay_f1", "bay_depth_score")


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz"
    )
    parser.add_argument(
        "--cache-dir", type=Path,
        default=root / "outputs" / "ktc_instance_bay_candidate_cache_seed20260820",
    )
    parser.add_argument(
        "--target-dir", type=Path,
        default=Path(r"E:\Codex\ktc_instance_bay_training_targets_seed20260820"),
    )
    parser.add_argument(
        "--stage-one-dir", type=Path,
        default=root / "outputs" / "ktc_instance_bay_nested_ranker_seed20260820",
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=Path(r"E:\Codex\ktc_instance_bay_multitask_ranker_v4_seed20260820"),
    )
    parser.add_argument(
        "--pure-bay", action="store_true",
        help="Restrict actions to zero-expansion exterior-connected bay removals.",
    )
    parser.add_argument("--bootstrap-repetitions", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260820)
    return parser.parse_args()


@dataclass
class MultiCase:
    base: CaseData
    targets: dict[str, np.ndarray]

    @property
    def case_id(self) -> str:
        return self.base.case_id

    @property
    def level(self) -> str:
        return self.base.level


@dataclass
class RidgeHead:
    mean: np.ndarray
    scale: np.ndarray
    coefficients: np.ndarray

    def predict(self, features: np.ndarray) -> np.ndarray:
        standardized = (features - self.mean) / self.scale
        design = np.concatenate((np.ones((len(features), 1)), standardized), axis=1)
        return design @ self.coefficients


@dataclass(frozen=True)
class ShapePolicy:
    minimum_iou: float
    minimum_boundary: float
    minimum_bay: float
    minimum_depth: float
    shape_weight: float
    boundary_weight: float
    depth_weight: float
    uncertainty_multiplier: float
    minimum_agreement: float
    max_change: float
    max_removal: float


POLICIES = tuple(
    ShapePolicy(
        minimum_iou=iou,
        minimum_boundary=boundary,
        minimum_bay=bay,
        minimum_depth=depth,
        shape_weight=shape_weight,
        boundary_weight=boundary_weight,
        depth_weight=depth_weight,
        uncertainty_multiplier=uncertainty,
        minimum_agreement=agreement,
        max_change=max_change,
        max_removal=max_removal,
    )
    for iou in (0.005, 0.010, 0.020)
    for boundary in (0.000, 0.010)
    for bay in (0.000, 0.010, 0.030)
    for depth in (0.000,)
    for shape_weight in (0.50, 1.00)
    for boundary_weight in (0.20,)
    for depth_weight in (0.15,)
    for uncertainty in (0.0, 0.5)
    for agreement in (0.50, 0.84)
    for max_change in (0.36, 0.62)
    for max_removal in (0.18, 0.36)
) + (
    # Guaranteed no-op policy: it is eligible in every inner split and keeps
    # the method conservative when topology heads do not generalize.
    ShapePolicy(1.0, 1.0, 1.0, 1.0, 1.0, 0.20, 0.15, 1.0, 1.0, 0.36, 0.18),
)


PURE_BAY_POLICIES = tuple(
    ShapePolicy(
        minimum_iou=iou,
        minimum_boundary=boundary,
        minimum_bay=bay,
        minimum_depth=depth,
        shape_weight=shape_weight,
        boundary_weight=boundary_weight,
        depth_weight=depth_weight,
        uncertainty_multiplier=uncertainty,
        minimum_agreement=agreement,
        max_change=max_change,
        max_removal=max_removal,
    )
    for iou in (0.000, 0.002, 0.005, 0.010)
    for boundary in (-0.002, 0.000)
    for bay in (0.000, 0.005, 0.010)
    for depth in (0.000,)
    for shape_weight in (0.50, 1.00, 2.00)
    for boundary_weight in (0.20,)
    for depth_weight in (0.15,)
    for uncertainty in (0.0, 0.5, 1.0)
    for agreement in (0.50, 0.84, 1.0)
    for max_change in (0.18, 0.36)
    for max_removal in (0.18, 0.36)
) + (
    ShapePolicy(1.0, 1.0, 1.0, 1.0, 1.0, 0.20, 0.15, 1.0, 1.0, 0.18, 0.18),
)


def load_multicases(args: argparse.Namespace) -> tuple[list[MultiCase], np.ndarray, np.ndarray]:
    cases, truths, ids = load_cases(args.dataset, args.cache_dir)
    output: list[MultiCase] = []
    for case in cases:
        archive = np.load(args.target_dir.resolve() / case_filename(case.case_id), allow_pickle=False)
        names = [str(value) for value in archive["target_names"]]
        delta = np.asarray(archive["delta"], dtype=np.float64)
        if len(delta) != len(case.candidates):
            raise ValueError(f"target/candidate mismatch for {case.case_id}")
        output.append(MultiCase(
            base=case,
            targets={name: delta[:, names.index(name)] for name in HEAD_NAMES},
        ))
    return output, truths, ids


def training_weights(case: CaseData, target: np.ndarray, positive_weight: float, kind_balance: float) -> np.ndarray:
    weights = np.ones(len(target), dtype=np.float64)
    weights *= 1.0 + positive_weight * (target > 0.002)
    if kind_balance > 0.0:
        for kind in np.unique(case.kind):
            selected = case.kind == kind
            weights[selected] *= (len(target) / max(1, selected.sum())) ** kind_balance
    weights /= max(float(weights.sum()), 1e-12)
    return weights


def fit_head(
    cases: list[MultiCase],
    head: str,
    regularization: float,
    positive_weight: float,
    kind_balance: float,
    pure_bay: bool = False,
) -> RidgeHead:
    feature_parts: list[np.ndarray] = []
    target_parts: list[np.ndarray] = []
    weight_parts: list[np.ndarray] = []
    finite_cases = [case for case in cases if np.isfinite(case.targets[head]).any()]
    for case in finite_cases:
        target = case.targets[head]
        finite = np.isfinite(target)
        if pure_bay:
            deployment_domain = (
                ((case.base.kind == 2) & (case.base.removed >= 0.005)
                 & (case.base.added <= 1e-8) & (case.base.new_holes == 0)
                 & (case.base.open_fraction >= 0.995))
                | (case.base.kind == 0)
            )
            finite &= deployment_domain
        feature_parts.append(case.base.features[finite])
        target_parts.append(np.clip(target[finite], -0.60, 0.60))
        weights = training_weights(
            case.base, np.nan_to_num(target, nan=0.0), positive_weight, kind_balance
        )[finite]
        weights /= max(float(weights.sum()), 1e-12)
        weight_parts.append(weights / len(finite_cases))
    features = np.concatenate(feature_parts)
    targets = np.concatenate(target_parts)
    weights = np.concatenate(weight_parts)
    weights /= max(float(weights.sum()), 1e-12)
    mean = np.sum(features * weights[:, None], axis=0)
    variance = np.sum(np.square(features - mean) * weights[:, None], axis=0)
    scale = np.sqrt(variance).clip(min=1e-5)
    design = np.concatenate((
        np.ones((len(features), 1)), (features - mean) / scale,
    ), axis=1)
    root_weight = np.sqrt(weights * len(weights))
    weighted_design = design * root_weight[:, None]
    penalty = np.eye(design.shape[1]) * regularization
    penalty[0, 0] = 0.0
    coefficients = np.linalg.solve(
        weighted_design.T @ weighted_design + penalty,
        weighted_design.T @ (targets * root_weight),
    )
    return RidgeHead(mean, scale, coefficients)


def fit_heads(
    cases: list[MultiCase], parameters: dict[str, float], pure_bay: bool = False,
) -> dict[str, RidgeHead]:
    return {
        head: fit_head(cases, head, pure_bay=pure_bay, **parameters)
        for head in HEAD_NAMES
    }


def predict_ensemble(
    ensembles: list[dict[str, RidgeHead]],
    case: MultiCase,
) -> dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]]:
    output: dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]] = {}
    for head in HEAD_NAMES:
        matrix = np.stack([model[head].predict(case.base.features) for model in ensembles])
        matrix -= matrix[:, :1]
        output[head] = (matrix.mean(axis=0), matrix.std(axis=0), (matrix > 0.0).mean(axis=0))
    return output


def inner_predictions(
    cases: list[MultiCase],
    parameters: dict[str, float],
    pure_bay: bool = False,
) -> dict[str, dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]]]:
    output: dict[str, dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]]] = {}
    levels = sorted({case.level for case in cases})
    for held_level in levels:
        remaining = [case for case in cases if case.level != held_level]
        remaining_levels = sorted({case.level for case in remaining})
        ensembles = [
            fit_heads(
                [case for case in remaining if case.level != omitted], parameters, pure_bay
            )
            for omitted in remaining_levels
        ]
        ensembles.append(fit_heads(remaining, parameters, pure_bay))
        for case in cases:
            if case.level == held_level:
                output[case.case_id] = predict_ensemble(ensembles, case)
    return output


def physical_valid(case: CaseData, policy: ShapePolicy, pure_bay: bool = False) -> np.ndarray:
    valid = (
        (case.kind == 2)
        & (case.removed >= 0.005)
        & (case.local_change >= 0.015)
        & (case.new_holes == 0)
        & (case.open_fraction >= 0.995)
        & (case.change <= policy.max_change)
        & (case.removed <= policy.max_removal)
    )
    if pure_bay:
        valid &= case.added <= 1e-8
    else:
        valid &= case.added >= 0.005
        valid &= case.added_polarity_evidence >= 0.50
    valid[0] = True
    return valid


def choose(
    case: MultiCase,
    predictions: dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]],
    policy: ShapePolicy,
    pure_bay: bool = False,
) -> tuple[int, float]:
    lower: dict[str, np.ndarray] = {}
    for head, (mean, std, agreement) in predictions.items():
        lower[head] = mean - policy.uncertainty_multiplier * std
    valid = physical_valid(case.base, policy, pure_bay)
    valid &= predictions["foreground_iou"][2] >= policy.minimum_agreement
    valid &= lower["foreground_iou"] >= policy.minimum_iou
    valid &= lower["boundary_f1"] >= policy.minimum_boundary
    valid &= lower["bay_f1"] >= policy.minimum_bay
    valid &= lower["bay_depth_score"] >= policy.minimum_depth
    valid[0] = True
    valid[0] = True
    score = (
        lower["foreground_iou"]
        + policy.boundary_weight * lower["boundary_f1"]
        + policy.shape_weight * lower["bay_f1"]
        + policy.depth_weight * lower["bay_depth_score"]
    )
    score = np.where(valid, score, -np.inf)
    choice = int(np.argmax(score))
    return choice, float(score[choice])


def evaluate_policy(
    cases: list[MultiCase],
    predictions: dict[str, dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]]],
    policy: ShapePolicy,
    pure_bay: bool = False,
) -> dict[str, object]:
    choices = np.asarray([
        choose(case, predictions[case.case_id], policy, pure_bay)[0] for case in cases
    ])
    changed = choices != 0
    values = {
        head: np.asarray([case.targets[head][choice] for case, choice in zip(cases, choices)])
        for head in HEAD_NAMES
    }
    finite_bay = np.isfinite(values["bay_f1"])
    eligible = (
        not np.any(values["foreground_iou"] < -1e-9)
        and not np.any(values["boundary_f1"] < -0.005)
        and not np.any(values["bay_f1"][changed & finite_bay] < -1e-9)
        and not np.any(values["bay_depth_score"][changed & finite_bay] < -0.02)
    )
    bay_values = np.nan_to_num(values["bay_f1"], nan=0.0)
    utility = values["foreground_iou"] + 0.25 * values["boundary_f1"] + 0.50 * bay_values
    return {
        "choices": choices,
        "eligible": bool(eligible),
        "changed": int(changed.sum()),
        "improved_iou": int(np.count_nonzero(values["foreground_iou"] > 1e-9)),
        "joint_improved": int(np.count_nonzero(
            changed & (values["foreground_iou"] > 1e-9) & ((~finite_bay) | (values["bay_f1"] > 1e-9))
        )),
        "harmed_iou": int(np.count_nonzero(values["foreground_iou"] < -1e-9)),
        "harmed_boundary": int(np.count_nonzero(values["boundary_f1"] < -0.005)),
        "harmed_bay": int(np.count_nonzero(changed & finite_bay & (values["bay_f1"] < -1e-9))),
        "mean_iou": float(values["foreground_iou"].mean()),
        "mean_boundary": float(values["boundary_f1"].mean()),
        "mean_bay": float(np.nanmean(values["bay_f1"])),
        "mean_utility": float(utility.mean()),
        "minimum_iou": float(values["foreground_iou"].min()),
        "minimum_bay_changed": (
            float(np.nanmin(values["bay_f1"][changed & finite_bay]))
            if np.any(changed & finite_bay) else 0.0
        ),
    }


def select_policy(
    cases: list[MultiCase],
    predictions: dict[str, dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]]],
    pure_bay: bool = False,
) -> tuple[ShapePolicy, dict[str, object], list[dict[str, object]]]:
    best: tuple[tuple[float, ...], ShapePolicy, dict[str, object]] | None = None
    rows: list[dict[str, object]] = []
    policies = PURE_BAY_POLICIES if pure_bay else POLICIES
    for policy in policies:
        result = evaluate_policy(cases, predictions, policy, pure_bay)
        row = {**asdict(policy), **{key: value for key, value in result.items() if key != "choices"}}
        rows.append(row)
        key = (
            1.0 if result["eligible"] else 0.0,
            float(result["mean_utility"]),
            float(result["joint_improved"]),
            float(result["mean_iou"]),
            float(result["mean_bay"]),
            -float(result["changed"]),
        )
        if best is None or key > best[0]:
            best = (key, policy, result)
    assert best is not None
    return best[1], best[2], rows


def fit_outer_ensemble(
    cases: list[MultiCase], parameters: dict[str, float], pure_bay: bool = False,
) -> list[dict[str, RidgeHead]]:
    levels = sorted({case.level for case in cases})
    ensembles = [
        fit_heads([case for case in cases if case.level != omitted], parameters, pure_bay)
        for omitted in levels
    ]
    ensembles.append(fit_heads(cases, parameters, pure_bay))
    return ensembles


def group_summary(
    selected: np.ndarray,
    truths: np.ndarray,
    baselines: np.ndarray,
    predictions: np.ndarray,
    repetitions: int,
    seed: int,
) -> dict[str, object]:
    indices = np.flatnonzero(selected)
    before_iou = foreground_iou_per_case(truths[indices], baselines[indices])
    after_iou = foreground_iou_per_case(truths[indices], predictions[indices])
    before_boundary = boundary_f1_per_case(truths[indices], baselines[indices])
    after_boundary = boundary_f1_per_case(truths[indices], predictions[indices])
    before_geometry = [case_metrics(truths[i], baselines[i]) for i in indices]
    after_geometry = [case_metrics(truths[i], predictions[i]) for i in indices]
    output: dict[str, object] = {
        "case_count": int(len(indices)),
        "changed_cases": int(np.count_nonzero(np.any(
            predictions[indices] != baselines[indices], axis=(1, 2)
        ))),
        "improved_iou_cases": int(np.count_nonzero(after_iou > before_iou + 1e-9)),
        "harmed_iou_cases": int(np.count_nonzero(after_iou < before_iou - 1e-9)),
        "baseline_iou": float(before_iou.mean()),
        "final_iou": float(after_iou.mean()),
        "delta_iou": paired_bootstrap(after_iou - before_iou, repetitions, seed),
        "baseline_boundary_f1": float(before_boundary.mean()),
        "final_boundary_f1": float(after_boundary.mean()),
        "delta_boundary_f1": paired_bootstrap(after_boundary - before_boundary, repetitions, seed + 1),
    }
    for metric in ("bay_f1", "bay_depth_score", "bay_direction_score"):
        before = np.asarray([float(row[metric]) for row in before_geometry])
        after = np.asarray([float(row[metric]) for row in after_geometry])
        output[f"baseline_{metric}"] = float(np.nanmean(before))
        output[f"final_{metric}"] = float(np.nanmean(after))
        output[f"delta_{metric}"] = paired_bootstrap(after - before, repetitions, seed + 2)
    return output


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    cases, truths, ids = load_multicases(args)
    stage_one = json.loads(
        (args.stage_one_dir.resolve() / "fold_policies.json").read_text(encoding="utf-8")
    )
    parameters_by_level = {str(row["outer_level"]): {
        "regularization": float(row["regularization"]),
        "positive_weight": float(row["positive_weight"]),
        "kind_balance": float(row["kind_balance"]),
    } for row in stage_one}
    baselines = np.stack([case.base.candidates[0] for case in cases])
    predictions = baselines.copy()
    choices = np.zeros(len(cases), dtype=np.int64)
    confidence = np.zeros(len(cases), dtype=np.float64)
    policy_rows: list[dict[str, object]] = []
    calibration_rows: list[dict[str, object]] = []
    for fold, outer_level in enumerate(sorted(parameters_by_level)):
        parameters = parameters_by_level[outer_level]
        training = [case for case in cases if case.level != outer_level]
        inner = inner_predictions(training, parameters, args.pure_bay)
        policy, inner_result, calibration = select_policy(training, inner, args.pure_bay)
        calibration_rows.extend({"outer_level": outer_level, **row} for row in calibration)
        ensemble = fit_outer_ensemble(training, parameters, args.pure_bay)
        outer_choices: list[int] = []
        for index, case in enumerate(cases):
            if case.level != outer_level:
                continue
            evidence = predict_ensemble(ensemble, case)
            choice, score = choose(case, evidence, policy, args.pure_bay)
            predictions[index] = case.base.candidates[choice]
            choices[index] = choice
            confidence[index] = score
            outer_choices.append(choice)
        record = {
            "outer_level": outer_level,
            **parameters,
            **asdict(policy),
            **{f"inner_oof_{key}": value for key, value in inner_result.items() if key != "choices"},
            "outer_choices": outer_choices,
        }
        policy_rows.append(record)
        print(f"fold {fold + 1}/7: {record}", flush=True)
    before_iou = foreground_iou_per_case(truths, baselines)
    after_iou = foreground_iou_per_case(truths, predictions)
    before_boundary = boundary_f1_per_case(truths, baselines)
    after_boundary = boundary_f1_per_case(truths, predictions)
    rows: list[dict[str, object]] = []
    for index, case in enumerate(cases):
        before_geometry = case_metrics(truths[index], baselines[index])
        after_geometry = case_metrics(truths[index], predictions[index])
        row: dict[str, object] = {
            "id": case.case_id,
            "strict_inward": case.case_id in STRICT_INWARD_IDS,
            "choice": int(choices[index]),
            "confidence_score": float(confidence[index]),
            "baseline_iou": float(before_iou[index]),
            "final_iou": float(after_iou[index]),
            "delta_iou": float(after_iou[index] - before_iou[index]),
            "baseline_boundary_f1": float(before_boundary[index]),
            "final_boundary_f1": float(after_boundary[index]),
            "delta_boundary_f1": float(after_boundary[index] - before_boundary[index]),
            **topology_checks(baselines[index], predictions[index]),
            **edit_metrics(truths[index], baselines[index], predictions[index]),
        }
        for metric in ("bay_iou", "bay_f1", "bay_depth_score", "bay_direction_score"):
            row[f"baseline_{metric}"] = before_geometry[metric]
            row[f"final_{metric}"] = after_geometry[metric]
            row[f"delta_{metric}"] = float(after_geometry[metric] - before_geometry[metric])
        rows.append(row)
    strict = np.asarray([case.case_id in STRICT_INWARD_IDS for case in cases])
    groups = {
        "all": group_summary(np.ones(len(cases), dtype=bool), truths, baselines, predictions, args.bootstrap_repetitions, args.seed),
        "strict_inward": group_summary(strict, truths, baselines, predictions, args.bootstrap_repetitions, args.seed + 10),
        "ordinary": group_summary(~strict, truths, baselines, predictions, args.bootstrap_repetitions, args.seed + 20),
    }
    write_csv(output_dir / "public_case_metrics.csv", rows)
    write_csv(output_dir / "calibration_grid.csv", calibration_rows)
    (output_dir / "fold_policies.json").write_text(
        json.dumps(policy_rows, indent=2), encoding="utf-8"
    )
    np.savez_compressed(
        output_dir / "predictions.npz", ids=ids, truths=truths, baseline=baselines,
        prediction=predictions, choices=choices, confidence_score=confidence,
    )
    save_montage(
        output_dir / "strict_inward_multitask.png", truths, baselines, predictions,
        baselines, ids, np.flatnonzero(strict),
    )
    summary = {
        "method": (
            "nested multi-task ridge ranker with a pure exterior-bay action gate"
            if args.pure_bay else
            "nested multi-task ridge ranker with a physical compensated-bay action gate"
        ),
        "status": "complete-level outer-fold evaluation",
        "outer_truth_used_for_training_or_policy_selection": False,
        "strict_inward_ids_used_for_training_or_policy_selection": False,
        "inference_cache_contains_public_truth": False,
        "training_target_cache_is_never_an_inference_feature": True,
        "heads": HEAD_NAMES,
        "physical_constraints": {
            "compensated_exterior_bay": not args.pure_bay,
            "pure_exterior_bay": args.pure_bay,
            "minimum_local_change": 0.015,
            "minimum_added_polarity_evidence": 0.50,
            "new_holes_forbidden": True,
            "identity_fallback": True,
        },
        "groups": groups,
        "fold_policies": policy_rows,
        "args": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
    }
    (output_dir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(groups, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
