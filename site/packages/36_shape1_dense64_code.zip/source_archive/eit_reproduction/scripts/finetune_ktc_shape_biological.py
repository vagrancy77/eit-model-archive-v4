"""Domain-balanced fine-tuning of the frozen KTC shape-aware network.

The encoder is kept fixed. Decoder/head weights learn smooth cell-like bays,
while vanilla-network distillation and ordinary calibration cases protect the
baseline geometry. Public KTC evaluation labels are never loaded here.
"""
from __future__ import annotations

import argparse
import json
import math
import random
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset

import finalize_ktc_topology_selective as core
import train_ktc_concavity_network as net
from prepare_ktc_shape_dataset import signed_distance


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--checkpoint-dir", type=Path, default=root / "outputs" / "ktc_shape_network_v1")
    parser.add_argument("--output-dir", type=Path, default=Path(r"E:\Codex\ktc_shape_biological_finetune_cpu"))
    parser.add_argument("--train-samples", type=int, default=1200)
    parser.add_argument("--validation-samples", type=int, default=420)
    parser.add_argument("--original-samples", type=int, default=800)
    parser.add_argument("--epochs", type=int, default=18)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--learning-rate", type=float, default=1e-4)
    parser.add_argument("--patience", type=int, default=6)
    parser.add_argument("--seed", type=int, default=20261021)
    return parser.parse_args()


class ArrayDataset(Dataset):
    def __init__(self, images, labels, delta, sdf, indent, voltage, concave):
        self.images = np.asarray(images, dtype=np.float32)
        self.labels = np.asarray(labels, dtype=np.int64)
        self.delta = np.asarray(delta, dtype=np.float32)
        self.sdf = np.asarray(sdf, dtype=np.float32)
        self.indent = np.asarray(indent, dtype=np.float32)
        self.voltage = np.asarray(voltage, dtype=np.float32)
        self.concave = np.asarray(concave, dtype=bool)

    def __len__(self):
        return len(self.images)

    def __getitem__(self, index):
        return {
            "image": torch.from_numpy(self.images[index][None]),
            "labels": torch.from_numpy(self.labels[index]),
            "delta": torch.from_numpy(self.delta[index][None]),
            "sdf": torch.from_numpy(self.sdf[index][None]),
            "indent": torch.from_numpy(self.indent[index][None]),
            "voltage": torch.from_numpy(self.voltage[index]),
            "concave": torch.tensor(self.concave[index], dtype=torch.bool),
        }


def gradients(image: torch.Tensor):
    return image[:, :, 1:] - image[:, :, :-1], image[:, :, :, 1:] - image[:, :, :, :-1]


def loss_function(outputs, teacher_logits, batch, class_weights, physics):
    logits = outputs["logits"]
    probabilities = torch.softmax(logits, dim=1)
    foreground = probabilities[:, 1:].sum(dim=1, keepdim=True)
    target_foreground = (batch["labels"] != 0).float().unsqueeze(1)
    ce = F.cross_entropy(logits, batch["labels"], weight=class_weights)
    dice = net.soft_dice_loss(logits, batch["labels"])
    sdf = F.smooth_l1_loss(outputs["sdf"], batch["sdf"], beta=0.08)
    conductivity = F.smooth_l1_loss(outputs["delta"], batch["delta"], beta=0.08)
    py, px = gradients(foreground)
    ty, tx = gradients(target_foreground)
    boundary = F.l1_loss(py, ty) + F.l1_loss(px, tx)
    indentation = (foreground * batch["indent"]).sum() / (batch["indent"].sum() + 1.0)

    with torch.no_grad():
        teacher_probability = torch.softmax(teacher_logits, dim=1)
        teacher_confidence = teacher_probability.max(dim=1, keepdim=True).values
        ordinary = (~batch["concave"]).float().reshape(-1, 1, 1, 1)
        protected = (ordinary + (1.0 - ordinary) * (batch["indent"] < 0.5)).clamp_max(1.0)
        protected = protected * (teacher_confidence >= 0.70)
    distill_map = -(teacher_probability * torch.log_softmax(logits, dim=1)).sum(dim=1, keepdim=True)
    distillation = (distill_map * protected).sum() / (protected.sum() + 1.0)
    physical = physics.loss(outputs["delta"], batch["voltage"])
    total = (
        ce + dice + 0.45 * sdf + 0.30 * conductivity + 0.30 * boundary
        + 0.75 * indentation + 0.30 * distillation + 1e-4 * physical
    )
    return total


def calibration_protection_loss(outputs, teacher_logits, labels, sdf, class_weights):
    logits = outputs["logits"]
    target_foreground = (labels != 0).float().unsqueeze(1)
    foreground = torch.softmax(logits, dim=1)[:, 1:].sum(dim=1, keepdim=True)
    py, px = gradients(foreground)
    ty, tx = gradients(target_foreground)
    boundary = F.l1_loss(py, ty) + F.l1_loss(px, tx)
    teacher_probability = torch.softmax(teacher_logits, dim=1)
    distillation = -(teacher_probability * torch.log_softmax(logits, dim=1)).sum(dim=1).mean()
    return (
        F.cross_entropy(logits, labels, weight=class_weights)
        + net.soft_dice_loss(logits, labels)
        + 0.35 * F.smooth_l1_loss(outputs["sdf"], sdf, beta=0.08)
        + 0.25 * boundary + 0.45 * distillation
    )


@torch.no_grad()
def predict(model, adapter, images, batch_size, device):
    model.eval()
    predictions = []
    for start in range(0, len(images), batch_size):
        image = torch.from_numpy(images[start:start + batch_size, None].astype(np.float32)).to(device)
        predictions.append(model(adapter(image))["logits"].argmax(dim=1).cpu().numpy())
    return np.concatenate(predictions)


def aggregate(truths, predictions, indent, group):
    rows = [net.confusion_metrics(t, p, i.astype(bool)) for t, p, i in zip(truths, predictions, indent)]
    selected = [rows[i] for i in np.flatnonzero(group)]
    return net.aggregate_rows(selected)


def validation_score(model, adapter, data, original, calibration, batch_size, device):
    bp = predict(model, adapter, data["images"], batch_size, device)
    op = predict(model, adapter, original["images"], batch_size, device)
    cp = predict(model, adapter, calibration["images"], batch_size, device)
    concave = aggregate(data["labels"], bp, data["indent"], data["concave"])
    ordinary = aggregate(data["labels"], bp, data["indent"], ~data["concave"])
    original_all = aggregate(original["labels"], op, original["indent"], np.ones(len(op), dtype=bool))
    calibration_all = aggregate(
        calibration["labels"], cp, calibration["indent"], np.ones(len(cp), dtype=bool)
    )
    score = (
        0.25 * concave["foreground_iou"] + 0.10 * concave["boundary_f1"]
        + 0.30 * concave["notch_preservation"] + 0.15 * ordinary["foreground_iou"]
        + 0.10 * original_all["foreground_iou"] + 0.10 * calibration_all["foreground_iou"]
    )
    return float(score), {
        "biological_concave": concave,
        "biological_ordinary": ordinary,
        "original": original_all,
        "calibration": calibration_all,
    }


def biological(archive, samples, seed):
    labels, delta, indent, concave, voltage, images = core.generate_biological_ood(archive, samples, seed)
    sdf = np.stack([signed_distance(item) for item in labels]).astype(np.float32)
    return {
        "images": images, "labels": labels, "delta": delta, "sdf": sdf,
        "indent": indent, "concave": concave, "voltage": voltage,
    }


def main():
    args = parse_args()
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.set_num_threads(max(1, min(12, torch.get_num_threads())))
    device = torch.device("cpu")
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    archive = np.load(args.dataset.resolve(), allow_pickle=False)
    print("generate biological train/validation sets", flush=True)
    train_bio = biological(archive, args.train_samples, args.seed + 100)
    validation = biological(archive, args.validation_samples, args.seed + 200)

    rng = np.random.default_rng(args.seed)
    selected = rng.choice(archive["train_indices"], size=args.original_samples, replace=False)
    original_train = {
        "images": archive["linear_images"][selected], "labels": archive["labels"][selected],
        "delta": archive["delta"][selected], "sdf": archive["signed_distance"][selected],
        "indent": archive["indentation_masks"][selected],
        "concave": core.materially_concave(archive["labels"][selected], archive["indentation_masks"][selected]),
        "voltage": archive["clean_voltages"][selected],
    }
    combined = {key: np.concatenate((train_bio[key], original_train[key])) for key in train_bio}
    dataset = ArrayDataset(
        combined["images"], combined["labels"], combined["delta"], combined["sdf"],
        combined["indent"], combined["voltage"], combined["concave"],
    )
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=True, num_workers=0, drop_last=True)
    original_validation_indices = archive["validation_indices"]
    original_validation = {
        "images": archive["linear_images"][original_validation_indices],
        "labels": archive["labels"][original_validation_indices],
        "indent": archive["indentation_masks"][original_validation_indices],
    }
    calibration = {
        "images": archive["calibration_linear_images"], "labels": archive["calibration_labels"],
        "indent": archive["calibration_indentation_masks"],
    }

    adapter = net.InputAdapter(archive["fov_mask"]).to(device)
    teacher = net.ConcavityUNet(32, False).to(device)
    teacher.load_state_dict(torch.load(args.checkpoint_dir / "vanilla_best.pt", map_location=device, weights_only=False)["model"])
    teacher.eval()
    for parameter in teacher.parameters():
        parameter.requires_grad_(False)
    model = net.ConcavityUNet(32, True).to(device)
    model.load_state_dict(torch.load(args.checkpoint_dir / "shape_best.pt", map_location=device, weights_only=False)["model"])
    for name, parameter in model.named_parameters():
        parameter.requires_grad_(name.startswith(("dec0", "segmentation", "sdf_head", "delta_head")))
    optimizer = torch.optim.AdamW(
        [parameter for parameter in model.parameters() if parameter.requires_grad],
        lr=args.learning_rate, weight_decay=1e-4,
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    counts = np.bincount(combined["labels"].reshape(-1), minlength=3).astype(np.float64)
    weights = np.sqrt(counts.sum() / np.maximum(counts, 1.0)); weights /= weights.mean()
    class_weights = torch.from_numpy(weights.astype(np.float32)).to(device)
    physics = net.PhysicsOperator(
        torch.from_numpy(archive["jacobian"]).to(device),
        torch.from_numpy(archive["node_to_raw_pixel"]).long().to(device), 2.0,
    )

    checkpoint = output / "shape_biological_best.pt"
    history = []
    best_score = -math.inf
    stale = 0
    baseline_metrics = None
    calibration_image = torch.from_numpy(
        archive["calibration_linear_images"][:, None].astype(np.float32)
    ).to(device)
    calibration_labels = torch.from_numpy(archive["calibration_labels"].astype(np.int64)).to(device)
    calibration_sdf = torch.from_numpy(
        archive["calibration_signed_distance"][:, None].astype(np.float32)
    ).to(device)
    for epoch in range(args.epochs + 1):
        score, metrics = validation_score(
            model, adapter, validation, original_validation, calibration,
            args.batch_size, device,
        )
        row = {"epoch": epoch, "score": score, "metrics": metrics}
        if baseline_metrics is None:
            baseline_metrics = metrics
        eligible = bool(
            metrics["calibration"]["foreground_iou"]
            >= baseline_metrics["calibration"]["foreground_iou"] - 0.005
            and metrics["original"]["foreground_iou"]
            >= baseline_metrics["original"]["foreground_iou"] - 0.010
            and metrics["biological_concave"]["notch_preservation"]
            >= baseline_metrics["biological_concave"]["notch_preservation"] - 0.002
        )
        row["eligible"] = eligible
        history.append(row)
        print(
            f"epoch {epoch:02d}: score={score:.5f} bio IoU={metrics['biological_concave']['foreground_iou']:.4f} "
            f"notch={metrics['biological_concave']['notch_preservation']:.4f} "
            f"ordinary={metrics['biological_ordinary']['foreground_iou']:.4f} "
            f"original={metrics['original']['foreground_iou']:.4f} calibration={metrics['calibration']['foreground_iou']:.4f}",
            flush=True,
        )
        if eligible and score > best_score + 1e-5:
            best_score = score
            stale = 0
            torch.save({
                "model": model.state_dict(), "base_channels": 32, "shape_aware": True,
                "epoch": epoch, "selection_score": score, "metrics": metrics,
                "public_ktc_evaluation_truth_used": False,
            }, checkpoint)
        else:
            stale += 1
        if epoch == args.epochs or (epoch > 0 and stale >= args.patience):
            break
        model.train()
        losses = []
        for batch in loader:
            batch = {key: value.to(device) for key, value in batch.items()}
            optimizer.zero_grad(set_to_none=True)
            adapted = adapter(batch["image"])
            with torch.no_grad():
                teacher_logits = teacher(adapted)["logits"]
            outputs = model(adapted)
            loss = loss_function(outputs, teacher_logits, batch, class_weights, physics)
            calibration_adapted = adapter(calibration_image)
            with torch.no_grad():
                calibration_teacher = teacher(calibration_adapted)["logits"]
            calibration_outputs = model(calibration_adapted)
            loss = loss + 0.65 * calibration_protection_loss(
                calibration_outputs, calibration_teacher, calibration_labels,
                calibration_sdf, class_weights,
            )
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 3.0)
            optimizer.step()
            losses.append(float(loss.detach()))
        scheduler.step()
        row["train_loss"] = float(np.mean(losses))

    (output / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    final = {
        "checkpoint": str(checkpoint), "best_score": best_score,
        "best_epoch": int(torch.load(checkpoint, map_location="cpu", weights_only=False)["epoch"]),
        "public_ktc_evaluation_truth_used": False, "args": vars(args),
    }
    final["args"] = {key: str(value) if isinstance(value, Path) else value for key, value in final["args"].items()}
    (output / "summary.json").write_text(json.dumps(final, indent=2), encoding="utf-8")
    print(json.dumps(final, indent=2), flush=True)


if __name__ == "__main__":
    main()
