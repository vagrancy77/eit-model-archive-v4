"""Level-held-out public-domain adaptation for local EIT candidate fusion.

Seven outer folds hold out one complete KTC difficulty level (three cases).
Within each outer fold, another complete level selects the checkpoint and edit
policy.  The outer labels are first accessed after all held-out predictions
have been assembled.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import random
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, WeightedRandomSampler

from train_ktc_concavity_network_v2 import evaluate_real_predictions, indentation_mask
from train_ktc_cross_representation_pixel_fusion import (
    STRICT_INWARD_IDS,
    FusionDataset,
    PixelCandidateFusionNet,
    SplitArrays,
    apply_fields,
    compute_loss,
    depth_weights,
    foreground_iou_per_case,
    infer_fields,
    load_pool,
    metric_for,
    paired_bootstrap,
    prepare_split,
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    parser.add_argument("--pool-dir", type=Path, default=root / "outputs" / "ktc_cross_representation_pool_seed20260820")
    parser.add_argument(
        "--pretrained", type=Path,
        default=root / "outputs" / "ktc_cross_representation_pixel_fusion_seed20260820" / "pixel_fusion_best.pt",
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=root / "outputs" / "ktc_public_level_cv_pixel_fusion_seed20260820",
    )
    parser.add_argument("--epochs", type=int, default=36)
    parser.add_argument("--patience", type=int, default=8)
    parser.add_argument("--samples-per-epoch", type=int, default=420)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--public-batch-size", type=int, default=1)
    parser.add_argument("--learning-rate", type=float, default=1.5e-4)
    parser.add_argument("--weight-decay", type=float, default=2e-4)
    parser.add_argument("--bootstrap-repetitions", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260820)
    parser.add_argument("--fold-limit", type=int, default=0, help="Smoke-test only; 0 runs all seven folds.")
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = True


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        return
    keys = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def resize_labels(values: np.ndarray, size: int = 64) -> np.ndarray:
    tensor = torch.from_numpy(values.astype(np.float32))
    if tensor.ndim == 3:
        tensor = tensor[:, None]
    resized = F.interpolate(tensor, size=(size, size), mode="nearest")[:, 0]
    return resized.numpy().astype(np.uint8)


def public_split_64(
    archive: np.lib.npyio.NpzFile,
    public_candidates: np.ndarray,
    selected: np.ndarray,
    name: str,
    source: str,
) -> SplitArrays:
    truths = resize_labels(np.asarray(archive["real_labels"])[selected])
    candidates = np.stack([resize_labels(candidate[selected]) for candidate in public_candidates])
    cutouts = np.stack([indentation_mask(truth).astype(np.uint8) for truth in truths])
    return SplitArrays(
        name=name,
        source=source,
        indices=np.asarray(selected, dtype=np.int64),
        images=np.asarray(archive["real_linear_images"])[selected].astype(np.float32),
        voltages=np.asarray(archive["real_voltages"])[selected].astype(np.float32),
        truths=truths,
        candidates=candidates,
        cutouts=cutouts,
        depths=depth_weights(cutouts),
        families=np.full(len(selected), -1, dtype=np.int16),
    )


def public_split_highres(
    archive: np.lib.npyio.NpzFile,
    public_candidates: np.ndarray,
    selected: np.ndarray,
    name: str,
) -> SplitArrays:
    # Outer-fold truth is deliberately absent during inference. SplitArrays
    # requires the field, but infer_fields only consumes images, voltages, and
    # candidates; zeros make that separation explicit and auditable.
    height, width = public_candidates.shape[-2:]
    truths = np.zeros((len(selected), height, width), dtype=np.uint8)
    return SplitArrays(
        name=name,
        source="base",
        indices=np.asarray(selected, dtype=np.int64),
        images=np.asarray(archive["real_linear_images"])[selected].astype(np.float32),
        voltages=np.asarray(archive["real_voltages"])[selected].astype(np.float32),
        truths=truths,
        candidates=public_candidates[:, selected],
        cutouts=np.zeros_like(truths),
        depths=np.zeros_like(truths, dtype=np.float32),
        families=np.full(len(selected), -1, dtype=np.int16),
    )


@torch.no_grad()
def validation_loss(model: PixelCandidateFusionNet, split: SplitArrays, device: torch.device, batch_size: int) -> float:
    loader = DataLoader(FusionDataset(split), batch_size=batch_size, shuffle=False)
    values: list[float] = []
    model.eval()
    for batch in loader:
        moved = {name: value.to(device) for name, value in batch.items()}
        output = model(moved["image"], moved["voltage"], moved["candidates"])
        loss, _ = compute_loss(output, moved)
        values.append(float(loss.detach()))
    return float(np.mean(values))


def fine_tune_fold(
    fold: int,
    public_train: SplitArrays,
    public_validation: SplitArrays,
    base_train: SplitArrays,
    stress_train: SplitArrays,
    base_validation: SplitArrays,
    stress_validation: SplitArrays,
    candidate_count: int,
    fov: np.ndarray,
    pretrained: dict[str, object],
    args: argparse.Namespace,
    output_dir: Path,
    device: torch.device,
) -> tuple[PixelCandidateFusionNet, list[dict[str, float]]]:
    set_seed(args.seed + fold)
    model = PixelCandidateFusionNet(candidate_count, int(pretrained["base_channels"]), fov).to(device)
    model.load_state_dict(pretrained["model"])
    dataset = FusionDataset([public_train, base_train, stress_train])
    weights = np.concatenate((
        np.full(len(public_train.indices), 0.55 / max(1, len(public_train.indices))),
        np.full(len(base_train.indices), 0.20 / len(base_train.indices)),
        np.full(len(stress_train.indices), 0.25 / len(stress_train.indices)),
    ))
    sampler = WeightedRandomSampler(
        weights, num_samples=args.samples_per_epoch, replacement=True,
        generator=torch.Generator().manual_seed(args.seed + fold),
    )
    loader = DataLoader(dataset, batch_size=args.batch_size, sampler=sampler, drop_last=False)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    checkpoint = output_dir / f"fold_{fold}_best.pt"
    history: list[dict[str, float]] = []
    best = math.inf
    stale = 0
    for epoch in range(1, args.epochs + 1):
        model.train()
        losses: list[float] = []
        for batch in loader:
            moved = {name: value.to(device, non_blocking=True) for name, value in batch.items()}
            optimizer.zero_grad(set_to_none=True)
            with torch.amp.autocast("cuda", enabled=device.type == "cuda"):
                output = model(moved["image"], moved["voltage"], moved["candidates"])
                loss, _ = compute_loss(output, moved)
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 4.0)
            scaler.step(optimizer)
            scaler.update()
            losses.append(float(loss.detach()))
        scheduler.step()
        public_loss = validation_loss(model, public_validation, device, args.batch_size)
        base_loss = validation_loss(model, base_validation, device, args.batch_size)
        stress_loss = validation_loss(model, stress_validation, device, args.batch_size)
        combined = 0.65 * public_loss + 0.15 * base_loss + 0.20 * stress_loss
        row = {
            "fold": float(fold), "epoch": float(epoch), "train_loss": float(np.mean(losses)),
            "public_validation_loss": public_loss, "base_validation_loss": base_loss,
            "stress_validation_loss": stress_loss, "combined_validation_loss": combined,
        }
        history.append(row)
        if epoch == 1 or epoch % 4 == 0:
            print(
                f"fold {fold} epoch {epoch:02d}: train={row['train_loss']:.4f} "
                f"public={public_loss:.4f} synthetic=({base_loss:.4f},{stress_loss:.4f})", flush=True,
            )
        if combined < best - 1e-4:
            best = combined
            stale = 0
            torch.save({
                "model": model.state_dict(), "base_channels": int(pretrained["base_channels"]),
                "fold": fold, "epoch": epoch, "validation_loss": combined,
            }, checkpoint)
        else:
            stale += 1
            if stale >= args.patience:
                break
    state = torch.load(checkpoint, map_location=device, weights_only=False)
    model.load_state_dict(state["model"])
    model.eval()
    return model, history


def calibrate_fold(
    model: PixelCandidateFusionNet,
    public_validation: SplitArrays,
    base_validation: SplitArrays,
    stress_validation: SplitArrays,
    device: torch.device,
    batch_size: int,
) -> tuple[dict[str, object], list[dict[str, object]]]:
    public_fields = infer_fields(model, public_validation, device, batch_size)
    base_fields = infer_fields(model, base_validation, device, batch_size)
    stress_fields = infer_fields(model, stress_validation, device, batch_size)
    base_reference = metric_for(base_validation, base_validation.candidates[0])
    stress_reference = metric_for(stress_validation, stress_validation.candidates[0])
    rows: list[dict[str, object]] = []
    for alpha in (0.0, 0.25, 0.50, 0.75, 1.0):
        for threshold in (0.0, 0.25, 0.40, 0.50, 0.60, 0.70, 0.80):
            public_prediction = apply_fields(public_validation.candidates[0], *public_fields, alpha, threshold)
            base_prediction = apply_fields(base_validation.candidates[0], *base_fields, alpha, threshold)
            stress_prediction = apply_fields(stress_validation.candidates[0], *stress_fields, alpha, threshold)
            public_iou = float(foreground_iou_per_case(public_validation.truths, public_prediction).mean())
            public_boundary = metric_for(public_validation, public_prediction)["boundary_f1"]
            base_metric = metric_for(base_validation, base_prediction)
            stress_metric = metric_for(stress_validation, stress_prediction)
            eligible = (
                base_metric["foreground_iou"] >= base_reference["foreground_iou"] - 0.004
                and base_metric["boundary_f1"] >= base_reference["boundary_f1"] - 0.006
                and stress_metric["foreground_iou"] >= stress_reference["foreground_iou"] - 0.008
                and stress_metric["bank_retention"] >= stress_reference["bank_retention"] - 0.018
            )
            rows.append({
                "alpha": alpha, "gate_threshold": threshold, "eligible": bool(eligible),
                "public_validation_iou": public_iou, "public_validation_boundary_f1": public_boundary,
                "base_validation_iou": base_metric["foreground_iou"],
                "stress_validation_iou": stress_metric["foreground_iou"],
                "stress_open_deep": stress_metric["open_deep_cutout_recovery"],
                "stress_bank": stress_metric["bank_retention"],
            })
    eligible = [row for row in rows if row["eligible"]]
    identity = next(row for row in rows if row["alpha"] == 0.0 and row["gate_threshold"] == 0.0)
    selected = max(eligible, key=lambda row: (
        float(row["public_validation_iou"]), float(row["public_validation_boundary_f1"]),
        float(row["stress_open_deep"]),
    )) if eligible else identity
    return selected, rows


def metric_subgroup(
    name: str,
    prediction: np.ndarray,
    baseline: np.ndarray,
    truths: np.ndarray,
    ids: np.ndarray,
    selected: np.ndarray,
    repetitions: int,
    seed: int,
) -> tuple[dict[str, object], list[dict[str, object]]]:
    baseline_summary, baseline_rows = evaluate_real_predictions(
        name + "_baseline", baseline[selected], truths[selected], ids[selected]
    )
    proposed_summary, proposed_rows = evaluate_real_predictions(
        name, prediction[selected], truths[selected], ids[selected]
    )
    return {
        "baseline": baseline_summary,
        "level_cv_fusion": proposed_summary,
        "bootstrap_iou": paired_bootstrap(
            truths[selected], baseline[selected], prediction[selected], repetitions, seed,
        ),
    }, baseline_rows + proposed_rows


def save_public_montage(
    path: Path,
    truths: np.ndarray,
    baseline: np.ndarray,
    prediction: np.ndarray,
    ids: np.ndarray,
    selected: np.ndarray,
) -> None:
    differences = foreground_iou_per_case(truths, prediction) - foreground_iou_per_case(truths, baseline)
    figure, axes = plt.subplots(len(selected), 4, figsize=(9.6, 2.35 * len(selected)), squeeze=False)
    for row, index in enumerate(selected):
        removed = ((baseline[index] != 0) & (prediction[index] == 0)).astype(np.uint8)
        images = (
            (truths[index], f"{ids[index]} truth", 0, 2),
            (baseline[index], "synthetic-only baseline", 0, 2),
            (prediction[index], f"level-held-out fusion\nDelta IoU {differences[index]:+.3f}", 0, 2),
            (removed, "removed foreground", 0, 1),
        )
        for column, (image, title, low, high) in enumerate(images):
            axes[row, column].imshow(image, cmap="viridis", vmin=low, vmax=high, interpolation="nearest")
            axes[row, column].set_title(title, fontsize=9)
            axes[row, column].set_axis_off()
    figure.suptitle("Public KTC2023 strict inward cases: complete-level-held-out adaptation", y=0.995)
    figure.subplots_adjust(top=0.965, hspace=0.28, wspace=0.08)
    figure.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    base_archive = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress_archive = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    pool_dir = args.pool_dir.resolve()
    names, public_indices, public_candidates = load_pool(pool_dir / "public_21.npz")
    ids = np.asarray(base_archive["real_ids"])
    expected_public_indices = np.arange(len(ids), dtype=np.int64)
    if not np.array_equal(public_indices, expected_public_indices):
        raise ValueError(
            "public candidate pool is not in real_ids order: "
            f"expected {expected_public_indices.tolist()}, found {public_indices.tolist()}"
        )
    levels = np.asarray([str(case_id).split("/")[0] for case_id in ids])
    unique_levels = sorted(set(levels))
    if len(unique_levels) != 7:
        raise ValueError(f"expected seven KTC levels, found {unique_levels}")
    base_names, base_train = prepare_split("base_train", "base", base_archive, pool_dir)
    _, base_validation = prepare_split("base_validation", "base", base_archive, pool_dir)
    _, base_test = prepare_split("base_test", "base", base_archive, pool_dir)
    stress_names, stress_train = prepare_split("stress_train", "stress", stress_archive, pool_dir)
    _, stress_validation = prepare_split("stress_validation", "stress", stress_archive, pool_dir)
    _, stress_test = prepare_split("stress_test", "stress", stress_archive, pool_dir)
    if names != base_names or names != stress_names:
        raise ValueError("candidate ordering mismatch")
    pretrained = torch.load(args.pretrained.resolve(), map_location="cpu", weights_only=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    prediction = np.zeros_like(public_candidates[0], dtype=np.uint8)
    predicted_mask = np.zeros(len(ids), dtype=bool)
    histories: list[dict[str, float]] = []
    policies: list[dict[str, object]] = []
    synthetic_audits: list[dict[str, object]] = []
    fold_count = len(unique_levels) if args.fold_limit <= 0 else min(args.fold_limit, len(unique_levels))
    for fold, outer_level in enumerate(unique_levels[:fold_count]):
        inner_level = unique_levels[(fold + 1) % len(unique_levels)]
        outer = np.flatnonzero(levels == outer_level)
        inner = np.flatnonzero(levels == inner_level)
        train = np.flatnonzero((levels != outer_level) & (levels != inner_level))
        print(
            f"fold {fold}: train levels={sorted(set(levels[train]))}; inner={inner_level}; outer={outer_level}",
            flush=True,
        )
        public_train = public_split_64(base_archive, public_candidates, train, f"fold_{fold}_train", "stress")
        public_validation = public_split_64(base_archive, public_candidates, inner, f"fold_{fold}_validation", "stress")
        model, history = fine_tune_fold(
            fold, public_train, public_validation, base_train, stress_train,
            base_validation, stress_validation, len(names), np.asarray(base_archive["fov_mask"]),
            pretrained, args, output_dir, device,
        )
        histories.extend(history)
        policy, grid = calibrate_fold(
            model, public_validation, base_validation, stress_validation, device, args.batch_size,
        )
        policy = {"fold": fold, "outer_level": outer_level, "inner_level": inner_level, **policy}
        policies.append(policy)
        write_csv(output_dir / f"fold_{fold}_calibration.csv", grid)
        print(f"fold {fold} policy={policy}", flush=True)
        outer_split = public_split_highres(base_archive, public_candidates, outer, f"fold_{fold}_outer")
        fields = infer_fields(model, outer_split, device, args.public_batch_size)
        fold_prediction = apply_fields(
            outer_split.candidates[0], *fields,
            float(policy["alpha"]), float(policy["gate_threshold"]),
        )
        prediction[outer] = fold_prediction
        predicted_mask[outer] = True
        # Synthetic test auditing never influences the fold checkpoint or policy.
        base_fields = infer_fields(model, base_test, device, args.batch_size)
        stress_fields = infer_fields(model, stress_test, device, args.batch_size)
        base_pred = apply_fields(base_test.candidates[0], *base_fields, float(policy["alpha"]), float(policy["gate_threshold"]))
        stress_pred = apply_fields(stress_test.candidates[0], *stress_fields, float(policy["alpha"]), float(policy["gate_threshold"]))
        synthetic_audits.append({
            "fold": fold,
            "base_test": metric_for(base_test, base_pred),
            "stress_test": metric_for(stress_test, stress_pred),
        })
        del model
        if device.type == "cuda":
            torch.cuda.empty_cache()
    write_csv(output_dir / "training_history.csv", histories)
    (output_dir / "fold_policies.json").write_text(json.dumps(policies, indent=2), encoding="utf-8")
    if not predicted_mask.all():
        # A requested smoke run intentionally leaves the remaining levels at baseline.
        prediction[~predicted_mask] = public_candidates[0, ~predicted_mask]
    # Public truth is first materialized only after every requested outer-fold
    # prediction, checkpoint, and policy decision has been finalized.
    truths = np.asarray(base_archive["real_labels"], dtype=np.uint8)
    baseline = public_candidates[0]
    strict = np.asarray([str(case_id) in STRICT_INWARD_IDS for case_id in ids])
    all_mask = predicted_mask if args.fold_limit > 0 else np.ones(len(ids), dtype=bool)
    strict_mask = strict & all_mask
    ordinary_mask = (~strict) & all_mask
    all_metrics, all_rows = metric_subgroup(
        "level_cv_fusion", prediction, baseline, truths, ids, all_mask,
        args.bootstrap_repetitions, args.seed + 10,
    )
    strict_metrics, strict_rows = metric_subgroup(
        "level_cv_fusion_strict", prediction, baseline, truths, ids, strict_mask,
        args.bootstrap_repetitions, args.seed + 11,
    ) if strict_mask.any() else ({}, [])
    ordinary_metrics, ordinary_rows = metric_subgroup(
        "level_cv_fusion_ordinary", prediction, baseline, truths, ids, ordinary_mask,
        args.bootstrap_repetitions, args.seed + 12,
    ) if ordinary_mask.any() else ({}, [])
    differences = foreground_iou_per_case(truths[all_mask], prediction[all_mask]) - foreground_iou_per_case(
        truths[all_mask], baseline[all_mask]
    )
    case_rows: list[dict[str, object]] = []
    for index in np.flatnonzero(all_mask):
        before = foreground_iou_per_case(truths[index:index + 1], baseline[index:index + 1])[0]
        after = foreground_iou_per_case(truths[index:index + 1], prediction[index:index + 1])[0]
        case_rows.append({
            "id": str(ids[index]), "strict_inward": bool(strict[index]),
            "baseline_iou": float(before), "level_cv_fusion_iou": float(after), "delta_iou": float(after - before),
        })
    write_csv(output_dir / "public_case_differences.csv", case_rows)
    write_csv(output_dir / "public_method_metrics.csv", all_rows + strict_rows + ordinary_rows)
    if strict_mask.any():
        save_public_montage(
            output_dir / "public_strict_inward_level_cv.png", truths, baseline, prediction, ids,
            np.flatnonzero(strict_mask),
        )
    np.savez_compressed(
        output_dir / "predictions.npz", prediction=prediction, predicted_mask=predicted_mask,
        baseline=baseline, ids=ids,
    )
    summary = {
        "method": "nested complete-level-held-out public-domain adaptation of pixel candidate fusion",
        "outer_folds_completed": fold_count,
        "public_evaluation": {
            "all": all_metrics, "strict_inward": strict_metrics, "ordinary": ordinary_metrics,
            "improved_cases": int(np.count_nonzero(differences > 1e-6)),
            "harmed_cases": int(np.count_nonzero(differences < -1e-6)),
            "material_improvements": int(np.count_nonzero(differences >= 0.01)),
            "material_harms": int(np.count_nonzero(differences <= -0.01)),
        },
        "fold_policies": policies,
        "synthetic_test_audits": synthetic_audits,
        "leakage_policy": "outer level labels are excluded from training, checkpoint selection, and policy calibration",
        "outer_truth_used_for_training_or_selection": False,
        "device": str(device),
        "seed": args.seed,
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
