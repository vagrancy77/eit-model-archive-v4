"""Validation-select a minimum-path plus learned-width non-convex decoder.

Every enclosed cavity receives the narrowest geodesic connection.  The frozen
candidate scorer only decides whether evidence supports widening that path.
This combines the connectivity gain of the deterministic decoder with the
bank protection learned from sealed-cutout and false-hole augmentations.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
import torch
from scipy.ndimage import zoom

from fuse_ktc_joint_shape_models import blend, load_model
from prepare_ktc_deep_concavity_stress import FAMILIES
from train_ktc_candidate_opening_refiner import (
    CandidateActionNet,
    apply_scored_actions,
    infer_pair,
    inference_records,
    paired_bootstrap,
    save_grid,
    score_actions,
)
from train_ktc_concavity_network import InputAdapter
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_highres_refiner import load_dip_four_case_predictions, load_official_four_case_truths
from train_ktc_implicit_boolean_network import standard_metrics, stress_metrics


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    parser.add_argument("--checkpoint", type=Path, default=Path("E:/Codex/ktc_candidate_opening_seed20260820/best.pt"))
    parser.add_argument("--conservative", type=Path, default=Path("E:/Codex/ktc_joint_shape_pretrained_seed20260820/best.pt"))
    parser.add_argument("--aggressive", type=Path, default=Path("E:/Codex/ktc_joint_shape_network_seed20260820/best.pt"))
    parser.add_argument("--output-dir", type=Path, default=Path("E:/Codex/ktc_candidate_hybrid_seed20260820"))
    parser.add_argument("--batch-size", type=int, default=48)
    parser.add_argument("--seed", type=int, default=20260820)
    return parser.parse_args()


def select_decoder(
    model: CandidateActionNet,
    normalization: dict[str, np.ndarray],
    base: np.lib.npyio.NpzFile,
    stress: np.lib.npyio.NpzFile,
    conservative_model,
    aggressive_model,
    adapter: InputAdapter,
    device: torch.device,
    batch_size: int,
) -> tuple[dict[str, object], list[dict[str, object]]]:
    bi, si = np.asarray(base["validation_indices"]), np.asarray(stress["validation_indices"])
    bc, ba = infer_pair(conservative_model, aggressive_model, adapter, base["linear_images"][bi], base["voltages"][bi], device, batch_size)
    sc, sa = infer_pair(conservative_model, aggressive_model, adapter, stress["linear_images"][si], stress["voltages"][si], device, batch_size)
    base_raw, stress_raw = blend(bc, ba, 0.5), blend(sc, sa, 0.5)
    base_records = inference_records(base["linear_images"][bi], base_raw, bc, ba)
    stress_records = inference_records(stress["linear_images"][si], stress_raw, sc, sa)
    score_actions(model, base_records, normalization["mean"], normalization["scale"], device)
    score_actions(model, stress_records, normalization["mean"], normalization["scale"], device)
    base_reference = standard_metrics(base["labels"][bi], base_raw, base["indentation_masks"][bi])
    stress_reference, _, _ = stress_metrics(stress["labels"][si], stress_raw, stress["cutout_masks"][si], stress["cutout_depth_weights"][si], stress["family_codes"][si])
    rows: list[dict[str, object]] = []
    for fallback_path in (False, True):
        for width_bonus in (0.0, 0.03, 0.06, 0.10, 0.15, 0.22):
            for threshold in np.linspace(0.20, 0.90, 15):
                bp, bo, _ = apply_scored_actions(base_raw, base_records, float(threshold), width_bonus, fallback_path)
                sp, so, _ = apply_scored_actions(stress_raw, stress_records, float(threshold), width_bonus, fallback_path)
                bm = standard_metrics(base["labels"][bi], bp, base["indentation_masks"][bi])
                sm, _, _ = stress_metrics(stress["labels"][si], sp, stress["cutout_masks"][si], stress["cutout_depth_weights"][si], stress["family_codes"][si])
                eligible = (
                    bm["foreground_iou"] >= base_reference["foreground_iou"] - 0.008
                    and sm["foreground_iou"] >= stress_reference["foreground_iou"] - 0.012
                    and sm["bank_retention"] >= stress_reference["bank_retention"] - 0.020
                )
                score = (
                    0.15 * bm["foreground_iou"] + 0.18 * sm["foreground_iou"]
                    + 0.32 * sm["open_deep_cutout_recovery"] + 0.17 * sm["bank_retention"]
                    + 0.18 * sm["topology_structural_joint"]
                )
                rows.append({
                    "fallback_path": fallback_path, "threshold": float(threshold), "width_bonus": width_bonus,
                    "eligible": bool(eligible), "score": float(score), "base_actions": bo, "stress_actions": so,
                    "base": bm, "stress": sm,
                })
    eligible = [row for row in rows if row["eligible"]]
    return max(eligible or rows, key=lambda row: float(row["score"])), rows


def main() -> None:
    args = parse_args()
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    base = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    adapter = InputAdapter(base["fov_mask"]).to(device)
    conservative_model = load_model(args.conservative, device)
    aggressive_model = load_model(args.aggressive, device)
    state = torch.load(args.checkpoint.resolve(), map_location=device, weights_only=False)
    model = CandidateActionNet().to(device)
    model.load_state_dict(state["model"])
    normalization = {"mean": np.asarray(state["feature_mean"]), "scale": np.asarray(state["feature_scale"])}
    selected, candidates = select_decoder(model, normalization, base, stress, conservative_model, aggressive_model, adapter, device, args.batch_size)
    (out / "validation_candidates.json").write_text(json.dumps(candidates, indent=2), encoding="utf-8")
    threshold, width_bonus, fallback_path = float(selected["threshold"]), float(selected["width_bonus"]), bool(selected["fallback_path"])
    print(json.dumps(selected, indent=2), flush=True)

    bi, si = np.asarray(base["test_indices"]), np.asarray(stress["test_indices"])
    bc, ba = infer_pair(conservative_model, aggressive_model, adapter, base["linear_images"][bi], base["voltages"][bi], device, args.batch_size)
    sc, sa = infer_pair(conservative_model, aggressive_model, adapter, stress["linear_images"][si], stress["voltages"][si], device, args.batch_size)
    base_raw, stress_raw = blend(bc, ba, 0.5), blend(sc, sa, 0.5)
    base_records = inference_records(base["linear_images"][bi], base_raw, bc, ba)
    stress_records = inference_records(stress["linear_images"][si], stress_raw, sc, sa)
    score_actions(model, base_records, normalization["mean"], normalization["scale"], device)
    score_actions(model, stress_records, normalization["mean"], normalization["scale"], device)
    bp, bo, accepted_base = apply_scored_actions(base_raw, base_records, threshold, width_bonus, fallback_path)
    sp, so, accepted_stress = apply_scored_actions(stress_raw, stress_records, threshold, width_bonus, fallback_path)
    bm = standard_metrics(base["labels"][bi], bp, base["indentation_masks"][bi])
    raw_sm, _, raw_rows = stress_metrics(stress["labels"][si], stress_raw, stress["cutout_masks"][si], stress["cutout_depth_weights"][si], stress["family_codes"][si])
    sm, family, rows = stress_metrics(stress["labels"][si], sp, stress["cutout_masks"][si], stress["cutout_depth_weights"][si], stress["family_codes"][si])
    bootstrap = paired_bootstrap(raw_rows, rows, 10000, args.seed)

    rc, ra = infer_pair(conservative_model, aggressive_model, adapter, base["real_linear_images"], base["real_voltages"], device, args.batch_size, 256)
    real_raw = blend(rc, ra, 0.5)
    real_images = zoom(base["real_linear_images"], (1.0, 4.0, 4.0), order=1)
    real_records = inference_records(real_images, real_raw, rc, ra, scale=4)
    score_actions(model, real_records, normalization["mean"], normalization["scale"], device)
    rp, ro, accepted_real = apply_scored_actions(real_raw, real_records, threshold, width_bonus, fallback_path)
    raw_rm, _ = evaluate_real_predictions("raw_fusion", real_raw, base["real_labels"], base["real_ids"])
    rm, real_rows = evaluate_real_predictions("candidate_hybrid", rp, base["real_labels"], base["real_ids"])

    cc, ca = infer_pair(conservative_model, aggressive_model, adapter, base["calibration_linear_images"], base["calibration_voltages"], device, args.batch_size)
    calibration_raw = blend(cc, ca, 0.5)
    calibration_records = inference_records(base["calibration_linear_images"], calibration_raw, cc, ca)
    score_actions(model, calibration_records, normalization["mean"], normalization["scale"], device)
    cp, co, accepted_calibration = apply_scored_actions(calibration_raw, calibration_records, threshold, width_bonus, fallback_path)
    official_truth, official_ids = load_official_four_case_truths(Path(__file__).resolve().parents[1] / "external" / "KTC2023-ABC2")
    official_raw = np.repeat(np.repeat(calibration_raw, 4, axis=1), 4, axis=2)
    official_prediction = np.repeat(np.repeat(cp, 4, axis=1), 4, axis=2)
    official_summary = {}
    official_rows = []
    for name, prediction in (("DIP_TV", load_dip_four_case_predictions(Path(__file__).resolve().parents[1])), ("raw_fusion", official_raw), ("candidate_hybrid", official_prediction)):
        official_summary[name], case_rows = evaluate_real_predictions(name, prediction, official_truth, official_ids)
        official_rows.extend(case_rows)

    changed = np.flatnonzero(np.any(stress_raw != sp, axis=(1, 2)))
    improvement = np.asarray([rows[i]["topology_structural_joint"] - raw_rows[i]["topology_structural_joint"] for i in changed]) if len(changed) else np.empty(0)
    if len(changed):
        focus = changed[np.argsort(improvement)[::-1][:min(24, len(changed))]]
        save_grid(out / "stress_changed_cases.png", stress["labels"][si], stress_raw, sp, [FAMILIES[int(stress["family_codes"][si][i])] for i in focus], focus)
    family_focus = []
    for code in range(len(FAMILIES)):
        options = np.flatnonzero(stress["family_codes"][si] == code)
        family_focus.append(int(options[np.argmax(stress["cutout_depth_weights"][si][options].sum(axis=(1, 2)))]))
    save_grid(out / "stress_family_cases.png", stress["labels"][si], stress_raw, sp, list(FAMILIES), np.asarray(family_focus))
    real_changed = np.flatnonzero(np.any(real_raw != rp, axis=(1, 2)))
    if len(real_changed):
        save_grid(out / "real_changed_cases.png", base["real_labels"], real_raw, rp, [str(base["real_ids"][i]) for i in real_changed], real_changed)
    save_grid(out / "official_four_cases.png", official_truth, official_raw, official_prediction, [str(item) for item in official_ids], np.arange(4))

    np.savez_compressed(out / "predictions.npz", base=bp, stress=sp, stress_raw=stress_raw, real=rp, real_raw=real_raw, calibration=official_prediction, calibration_raw=official_raw)
    with (out / "stress_bootstrap.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(bootstrap[0])); writer.writeheader(); writer.writerows(bootstrap)
    with (out / "official_four_metrics.csv").open("w", newline="", encoding="utf-8") as handle:
        keys = sorted({key for row in official_rows for key in row}); writer = csv.DictWriter(handle, fieldnames=keys); writer.writeheader(); writer.writerows(official_rows)
    result = {
        "method": "minimum geodesic path with augmentation-trained adaptive width",
        "selected": selected,
        "test": {
            "base_actions": bo, "stress_actions": so, "real_actions": ro, "calibration_actions": co,
            "base": bm, "stress_raw": raw_sm, "stress_hybrid": sm, "stress_by_family": family,
            "bootstrap": bootstrap, "real_raw": raw_rm, "real_hybrid": rm, "real_cases": real_rows,
            "official_four": official_summary, "accepted_base": accepted_base,
            "accepted_stress": accepted_stress, "accepted_real": accepted_real,
            "accepted_calibration": accepted_calibration,
        },
        "checkpoint": str(args.checkpoint.resolve()),
        "evaluation_truth_used_for_selection": False,
    }
    (out / "summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result["test"], ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
