"""Build a deployable cross-representation candidate pool for concave EIT.

Every candidate is regenerated from frozen checkpoints on the same inputs.
Synthetic train/validation/test splits are cached separately.  Public KTC
truth is never used to construct a candidate; it is opened only for the final
representation audit after all predictions have been generated.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import random
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F

from calibrate_ktc_implicit_boolean import RawFields, predict_from_fields
from fuse_ktc_concavity_models import load_model
from train_ktc_concavity_network import InputAdapter
from train_ktc_highres_refiner import load_coarse_ensemble
from train_ktc_implicit_boolean_network import ImplicitBooleanNet, standard_metrics, stress_metrics
from train_ktc_topology_refiner import TopologyRefiner, load_coarse


STRICT_INWARD_IDS = (
    "level_2/1", "level_2/3", "level_3/2", "level_5/2",
    "level_6/2", "level_6/3", "level_7/1", "level_7/2", "level_7/3",
)
IMPLICIT_SPECS = (
    ("implicit_very_safe", -2.50, 0.35, 0.70),
    ("implicit_safe", -2.25, 0.35, 1.00),
    ("implicit_calibrated", -2.00, 0.35, 1.00),
    ("implicit_mild", -1.75, 0.50, 0.85),
    ("implicit_balanced", -1.75, 0.65, 1.00),
    ("implicit_strong", -1.50, 0.80, 1.00),
)


@dataclass
class FrozenModels:
    primary: list[torch.nn.Module]
    secondary: list[torch.nn.Module]
    topology_coarse: torch.nn.Module
    topology_refiner: TopologyRefiner
    implicit_coarse: torch.nn.Module
    implicit: ImplicitBooleanNet


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    parser.add_argument(
        "--primary-checkpoints", nargs=3, type=Path,
        default=[
            root / "outputs" / "ktc_concavity_components_seed20260820" / "boundary_best.pt",
            root / "outputs" / "ktc_concavity_components_seed20260820" / "indent_best.pt",
            root / "outputs" / "ktc_concavity_components_seed20260820" / "voltage_best.pt",
        ],
    )
    parser.add_argument(
        "--secondary-checkpoints", nargs=3, type=Path,
        default=[
            root / "outputs" / "ktc_concavity_components_seed20260821" / "boundary_best.pt",
            root / "outputs" / "ktc_concavity_components_seed20260821" / "indent_best.pt",
            root / "outputs" / "ktc_concavity_components_seed20260821" / "voltage_best.pt",
        ],
    )
    parser.add_argument(
        "--topology-checkpoint", type=Path,
        default=root / "outputs" / "ktc_topology_refiner_seed20260819" / "refiner_best.pt",
    )
    parser.add_argument(
        "--implicit-checkpoint", type=Path,
        default=root / "outputs" / "ktc_implicit_boolean_seed20260829" / "implicit_boolean_best.pt",
    )
    parser.add_argument(
        "--implicit-coarse-checkpoints", nargs=3, type=Path,
        default=[
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "boundary_best.pt",
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "indent_best.pt",
            root / "outputs" / "ktc_concavity_voltage_seed20260819" / "voltage_best.pt",
        ],
    )
    parser.add_argument("--implicit-coarse-weights", nargs=3, type=float, default=[0.30, 0.40, 0.30])
    parser.add_argument("--output-dir", type=Path, default=root / "outputs" / "ktc_cross_representation_pool_seed20260820")
    parser.add_argument("--batch-size", type=int, default=24)
    parser.add_argument("--seed", type=int, default=20260820)
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def load_models(args: argparse.Namespace, device: torch.device) -> FrozenModels:
    primary = [load_model(path, device) for path in args.primary_checkpoints]
    secondary = [load_model(path, device) for path in args.secondary_checkpoints]

    topology_state = torch.load(args.topology_checkpoint.resolve(), map_location=device, weights_only=False)
    topology_coarse, _ = load_coarse(Path(str(topology_state["coarse_checkpoint"])), device)
    topology_refiner = TopologyRefiner(int(topology_state["base_channels"])).to(device)
    topology_refiner.load_state_dict(topology_state["model"])
    topology_refiner.eval().requires_grad_(False)

    implicit_coarse, _, _ = load_coarse_ensemble(
        args.implicit_coarse_checkpoints, args.implicit_coarse_weights, device
    )
    implicit_state = torch.load(args.implicit_checkpoint.resolve(), map_location=device, weights_only=False)
    implicit = ImplicitBooleanNet(int(implicit_state["base_channels"])).to(device)
    incompatible = implicit.load_state_dict(implicit_state["model"], strict=False)
    allowed_missing = tuple(
        key for key in incompatible.missing_keys if key.startswith(("mouth_head.", "bank_head."))
    )
    if tuple(incompatible.missing_keys) != allowed_missing or incompatible.unexpected_keys:
        raise RuntimeError(
            "implicit checkpoint mismatch outside the permitted post-checkpoint mouth/bank heads: "
            f"missing={incompatible.missing_keys}, unexpected={incompatible.unexpected_keys}"
        )
    if allowed_missing:
        print("legacy implicit checkpoint: unused mouth/bank auxiliary heads are freshly initialized", flush=True)
    implicit.eval().requires_grad_(False)
    return FrozenModels(primary, secondary, topology_coarse, topology_refiner, implicit_coarse, implicit)


def interpolate_probability(probability: torch.Tensor, size: int) -> torch.Tensor:
    if probability.shape[-1] == size:
        return probability
    logits = F.interpolate(torch.log(probability.clamp_min(1e-7)), size=(size, size), mode="bilinear", align_corners=False)
    return torch.softmax(logits, dim=1)


def log_fusion(probabilities: list[torch.Tensor]) -> torch.Tensor:
    weights = (0.30, 0.40, 0.30)
    score = sum(weight * torch.log(probability.clamp_min(1e-7)) for weight, probability in zip(weights, probabilities))
    return score.argmax(dim=1)


@torch.no_grad()
def generate_candidates(
    models: FrozenModels,
    adapter: InputAdapter,
    images: np.ndarray,
    voltages: np.ndarray,
    device: torch.device,
    batch_size: int,
    output_size: int,
) -> tuple[list[str], np.ndarray]:
    names = [
        "fusion_primary", "boundary_primary", "indent_primary", "voltage_primary",
        "fusion_secondary", "topology_boundary", "topology_refiner",
        *[spec[0] for spec in IMPLICIT_SPECS],
    ]
    chunks: list[list[np.ndarray]] = [[] for _ in names]
    for start in range(0, len(images), batch_size):
        stop = min(len(images), start + batch_size)
        image = torch.from_numpy(images[start:stop, None].astype(np.float32)).to(device)
        voltage = torch.from_numpy(voltages[start:stop].astype(np.float32)).to(device)
        adapted = adapter(image)

        primary = [interpolate_probability(torch.softmax(model(adapted, voltage)["logits"], dim=1), output_size) for model in models.primary]
        secondary = [interpolate_probability(torch.softmax(model(adapted, voltage)["logits"], dim=1), output_size) for model in models.secondary]
        chunks[0].append(log_fusion(primary).cpu().numpy().astype(np.uint8))
        for index, probability in enumerate(primary, start=1):
            chunks[index].append(probability.argmax(dim=1).cpu().numpy().astype(np.uint8))
        chunks[4].append(log_fusion(secondary).cpu().numpy().astype(np.uint8))

        topology_probability = torch.softmax(models.topology_coarse(adapted, voltage)["logits"], dim=1)
        topology_logits = models.topology_refiner(adapted, topology_probability)["logits"]
        topology_probability = interpolate_probability(topology_probability, output_size)
        topology_logits = F.interpolate(topology_logits, size=(output_size, output_size), mode="bilinear", align_corners=False)
        chunks[5].append(topology_probability.argmax(dim=1).cpu().numpy().astype(np.uint8))
        chunks[6].append(topology_logits.argmax(dim=1).cpu().numpy().astype(np.uint8))

        coarse_probability = torch.softmax(models.implicit_coarse(adapted, voltage)["logits"], dim=1)
        implicit_output = models.implicit(adapted, voltage, coarse_probability)
        fields = RawFields(
            coarse_prediction=coarse_probability.argmax(dim=1).cpu().numpy().astype(np.uint8),
            coarse_probability=coarse_probability.float().cpu().numpy(),
            coarse_field=implicit_output["coarse_field"][:, 0].float().cpu().numpy(),
            support_residual=implicit_output["support_residual"][:, 0].float().cpu().numpy(),
            cutout_residual=implicit_output["cutout_residual"][:, 0].float().cpu().numpy(),
            polarity=implicit_output["polarity_probability"].float().cpu().numpy(),
        )
        for offset, (_, bias, support_scale, cutout_scale) in enumerate(IMPLICIT_SPECS, start=7):
            chunks[offset].append(
                predict_from_fields(fields, bias, support_scale, cutout_scale, output_size=output_size)
            )
        print(f"candidate inference {stop}/{len(images)}", flush=True)
    candidates = np.stack([np.concatenate(values) for values in chunks])
    return names, candidates


def write_split(
    path: Path,
    names: list[str],
    indices: np.ndarray,
    candidates: np.ndarray,
) -> None:
    np.savez_compressed(
        path,
        candidate_names=np.asarray(names),
        indices=np.asarray(indices, dtype=np.int64),
        candidates=np.asarray(candidates, dtype=np.uint8),
    )


def generate_or_load_split(
    output_dir: Path,
    split_name: str,
    models: FrozenModels,
    adapter: InputAdapter,
    images: np.ndarray,
    voltages: np.ndarray,
    indices: np.ndarray,
    device: torch.device,
    args: argparse.Namespace,
    output_size: int = 64,
) -> tuple[list[str], np.ndarray]:
    path = output_dir / f"{split_name}.npz"
    if path.exists() and not args.force:
        archive = np.load(path, allow_pickle=False)
        print(f"reusing {path}", flush=True)
        return [str(value) for value in archive["candidate_names"]], np.asarray(archive["candidates"], dtype=np.uint8)
    print(f"generating {split_name}: {len(indices)} cases at {output_size} x {output_size}", flush=True)
    names, candidates = generate_candidates(
        models, adapter, images[indices], voltages[indices], device, args.batch_size, output_size
    )
    write_split(path, names, indices, candidates)
    return names, candidates


def foreground_iou(truths: np.ndarray, predictions: np.ndarray) -> np.ndarray:
    truth = truths != 0
    prediction = predictions != 0
    intersection = np.logical_and(truth, prediction).sum(axis=(1, 2))
    union = np.logical_or(truth, prediction).sum(axis=(1, 2))
    return intersection / np.maximum(union, 1)


def save_public_oracle(
    path: Path,
    truths: np.ndarray,
    ids: np.ndarray,
    candidates: np.ndarray,
    names: list[str],
    selected: np.ndarray,
) -> None:
    indices = [index for index, case_id in enumerate(ids) if str(case_id) in STRICT_INWARD_IDS]
    figure, axes = plt.subplots(len(indices), 5, figsize=(13.0, 2.65 * len(indices)), squeeze=False)
    for row, index in enumerate(indices):
        baseline = candidates[0, index]
        oracle = candidates[int(selected[index]), index]
        removed = (baseline != 0) & (oracle == 0)
        bank = (baseline == 0) & (oracle != 0)
        before = foreground_iou(truths[index:index + 1], baseline[None])[0]
        after = foreground_iou(truths[index:index + 1], oracle[None])[0]
        panels = (
            (truths[index], "truth", "viridis", 2),
            (baseline, f"fusion baseline\nIoU={before:.3f}", "viridis", 2),
            (oracle, f"small-pool oracle\nIoU={after:.3f}", "viridis", 2),
            (removed, "removed from baseline", "magma", 1),
            (bank, "added to baseline", "magma", 1),
        )
        for column, (image, title, cmap, vmax) in enumerate(panels):
            axes[row, column].imshow(image, cmap=cmap, vmin=0, vmax=vmax, interpolation="nearest")
            axes[row, column].set_title(title, fontsize=8)
            axes[row, column].set_axis_off()
        axes[row, 0].set_ylabel(f"{ids[index]}\n{names[int(selected[index])]}", fontsize=8)
    figure.suptitle("Deployable cross-representation pool: strict inward KTC cases", fontsize=13)
    figure.tight_layout()
    figure.savefig(path, dpi=190)
    plt.close(figure)


def audit_split(
    names: list[str],
    candidates: np.ndarray,
    truths: np.ndarray,
) -> tuple[list[dict[str, object]], dict[str, object], np.ndarray]:
    iou = np.stack([foreground_iou(truths, prediction) for prediction in candidates])
    choice = np.argmax(iou, axis=0)
    rows = [
        {
            "candidate": name,
            "mean_foreground_iou": float(values.mean()),
            "wins": int(np.count_nonzero(choice == index)),
        }
        for index, (name, values) in enumerate(zip(names, iou))
    ]
    summary = {
        "baseline_mean_foreground_iou": float(iou[0].mean()),
        "oracle_mean_foreground_iou": float(iou[choice, np.arange(len(choice))].mean()),
        "oracle_changed_cases": int(np.count_nonzero(choice != 0)),
    }
    return rows, summary, choice


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    base = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"device={device}; loading frozen representations", flush=True)
    models = load_models(args, device)
    adapter = InputAdapter(base["fov_mask"]).to(device)

    split_specs = (
        ("base_train", base, "train_indices"),
        ("base_validation", base, "validation_indices"),
        ("base_test", base, "test_indices"),
        ("stress_train", stress, "train_indices"),
        ("stress_validation", stress, "validation_indices"),
        ("stress_test", stress, "test_indices"),
    )
    split_candidates: dict[str, np.ndarray] = {}
    names: list[str] | None = None
    for split_name, archive, index_key in split_specs:
        indices = np.asarray(archive[index_key], dtype=np.int64)
        current_names, candidates = generate_or_load_split(
            output_dir, split_name, models, adapter,
            archive["linear_images"], archive["voltages"], indices,
            device, args,
        )
        if names is None:
            names = current_names
        elif current_names != names:
            raise RuntimeError(f"candidate mismatch in {split_name}")
        split_candidates[split_name] = candidates
    assert names is not None

    real_indices = np.arange(len(base["real_linear_images"]), dtype=np.int64)
    real_names, real_candidates = generate_or_load_split(
        output_dir, "public_21", models, adapter,
        base["real_linear_images"], base["real_voltages"], real_indices,
        device, args, output_size=256,
    )
    if real_names != names:
        raise RuntimeError("public candidate mismatch")

    audit_rows: list[dict[str, object]] = []
    split_summary: dict[str, object] = {}
    for split_name, archive, index_key in (
        ("base_validation", base, "validation_indices"),
        ("base_test", base, "test_indices"),
        ("stress_validation", stress, "validation_indices"),
        ("stress_test", stress, "test_indices"),
    ):
        indices = np.asarray(archive[index_key], dtype=np.int64)
        rows, summary, _ = audit_split(names, split_candidates[split_name], archive["labels"][indices])
        split_summary[split_name] = summary
        audit_rows.extend({"split": split_name, **row} for row in rows)

    # Public labels are used only below this point, after pool construction.
    public_truth = np.asarray(base["real_labels"], dtype=np.uint8)
    public_ids = np.asarray(base["real_ids"])
    public_rows, public_summary, public_choice = audit_split(names, real_candidates, public_truth)
    strict = np.asarray([str(case_id) in STRICT_INWARD_IDS for case_id in public_ids])
    public_iou = np.stack([foreground_iou(public_truth, prediction) for prediction in real_candidates])
    strict_choice = np.argmax(public_iou[:, strict], axis=0)
    ordinary_choice = np.argmax(public_iou[:, ~strict], axis=0)
    public_summary.update(
        strict_inward_baseline_iou=float(public_iou[0, strict].mean()),
        strict_inward_oracle_iou=float(public_iou[:, strict].max(axis=0).mean()),
        ordinary_baseline_iou=float(public_iou[0, ~strict].mean()),
        ordinary_oracle_iou=float(public_iou[:, ~strict].max(axis=0).mean()),
        strict_inward_oracle_changed=int(np.count_nonzero(strict_choice != 0)),
        ordinary_oracle_changed=int(np.count_nonzero(ordinary_choice != 0)),
    )
    split_summary["public_21"] = public_summary
    audit_rows.extend({"split": "public_21", **row} for row in public_rows)

    with (output_dir / "candidate_metrics.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(audit_rows[0]))
        writer.writeheader()
        writer.writerows(audit_rows)
    save_public_oracle(
        output_dir / "public_strict_inward_small_pool_oracle.png",
        public_truth, public_ids, real_candidates, names, public_choice,
    )
    result = {
        "method": "uniform frozen cross-representation candidate pool",
        "candidate_names": names,
        "candidate_count": len(names),
        "splits": split_summary,
        "data_policy": "all candidates are checkpoint-only predictions; public truth is used only for final audit",
        "evaluation_truth_used_for_candidate_generation": False,
        "device": str(device),
        "seed": args.seed,
        "checkpoints": {
            "primary": [str(path.resolve()) for path in args.primary_checkpoints],
            "secondary": [str(path.resolve()) for path in args.secondary_checkpoints],
            "topology": str(args.topology_checkpoint.resolve()),
            "implicit": str(args.implicit_checkpoint.resolve()),
            "implicit_coarse": [str(path.resolve()) for path in args.implicit_coarse_checkpoints],
        },
    }
    (output_dir / "summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
