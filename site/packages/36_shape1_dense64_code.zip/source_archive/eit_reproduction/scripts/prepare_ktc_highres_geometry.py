"""Regenerate the synthetic KTC shapes at higher spatial resolution.

The nonlinear CEM voltages do not need to be simulated again: geometry and
material decisions are replayed with the original 64-pixel accept/reject rule,
then the same continuous shape is rasterized at both 64 and target resolution.
An exact comparison against the original archive detects any RNG drift before
the high-resolution labels are saved.
"""
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
import scipy.io as sio
from PIL import Image
from scipy.ndimage import distance_transform_edt

from prepare_ktc_shape_dataset import (
    SHAPE_NAMES,
    SHAPE_TO_CODE,
    draw_shape,
    instance_indentation_mask,
)


CONCAVE_NAMES = {
    "star", "cross", "crescent", "c_shape", "u_shape", "l_shape",
    "heart", "kidney", "lobed", "random_polygon",
}


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--output", type=Path, default=root / "datasets" / "ktc_shape_geometry_128_v1.npz")
    parser.add_argument("--resolution", type=int, default=128)
    parser.add_argument("--seed", type=int, default=20260819)
    parser.add_argument("--official-repo", type=Path, default=root / "external" / "KTC2023-ABC2")
    return parser.parse_args()


def normalized_signed_distance(labels: np.ndarray, resolution: int) -> np.ndarray:
    foreground = labels != 0
    distance = distance_transform_edt(foreground) - distance_transform_edt(~foreground)
    # Preserve the physical normalization used by the 64 x 64 archive.
    scale = 12.0 * resolution / 64.0
    return np.clip(distance / scale, -1.0, 1.0).astype(np.float32)


def replay_geometry(samples: int, target_resolution: int, seed: int) -> dict[str, np.ndarray]:
    if target_resolution <= 64:
        raise ValueError("target resolution must be greater than 64")
    rng = np.random.default_rng(seed)
    coordinates_64 = np.linspace(-1.0, 1.0, 64, dtype=np.float32)
    coordinates_high = np.linspace(-1.0, 1.0, target_resolution, dtype=np.float32)
    x64, y64 = np.meshgrid(coordinates_64, coordinates_64)
    xh, yh = np.meshgrid(coordinates_high, coordinates_high)
    fov64 = x64 * x64 + y64 * y64 <= 0.98**2
    fov_high = xh * xh + yh * yh <= 0.98**2

    labels64 = np.zeros((samples, 64, 64), dtype=np.uint8)
    delta64 = np.zeros((samples, 64, 64), dtype=np.float32)
    labels_high = np.zeros((samples, target_resolution, target_resolution), dtype=np.uint8)
    shape_codes = np.full((samples, 4), -1, dtype=np.int16)
    shape_counts = np.zeros(samples, dtype=np.int16)

    for sample_index in range(samples):
        count = int(rng.integers(1, 5))
        shape_counts[sample_index] = count
        forced_concave = sample_index % 2 == 0
        kinds = list(rng.choice(SHAPE_NAMES, size=count, replace=True))
        if forced_concave and not any(kind in CONCAVE_NAMES for kind in kinds):
            kinds[0] = str(rng.choice(sorted(CONCAVE_NAMES)))

        for object_index, kind_value in enumerate(kinds):
            kind = str(kind_value)
            state_before = copy.deepcopy(rng.bit_generator.state)
            mask64 = draw_shape(kind, x64, y64, rng) & fov64
            state_after = copy.deepcopy(rng.bit_generator.state)
            rng.bit_generator.state = state_before
            mask_high = draw_shape(kind, xh, yh, rng) & fov_high
            # Resolution does not change random consumption inside draw_shape.
            rng.bit_generator.state = state_after

            # This is deliberately based on the original 64-pixel mask. It
            # preserves every later class, contrast, and shape RNG decision.
            if mask64.sum() < 12:
                continue
            class_id = 1 if rng.uniform() < 0.56 else 2
            contrast = -float(rng.uniform(0.22, 0.92)) if class_id == 1 else float(rng.uniform(0.22, 1.10))
            labels64[sample_index][mask64] = class_id
            delta64[sample_index][mask64] = contrast
            labels_high[sample_index][mask_high] = class_id
            shape_codes[sample_index, object_index] = SHAPE_TO_CODE[kind]

        if (sample_index + 1) % 250 == 0 or sample_index + 1 == samples:
            print(f"replayed geometry {sample_index + 1}/{samples}", flush=True)

    indentation_high = np.empty_like(labels_high, dtype=np.uint8)
    sdf_high = np.empty(labels_high.shape, dtype=np.float32)
    for sample_index, labels in enumerate(labels_high):
        indentation_high[sample_index] = instance_indentation_mask(labels).astype(np.uint8)
        sdf_high[sample_index] = normalized_signed_distance(labels, target_resolution)
        if (sample_index + 1) % 250 == 0 or sample_index + 1 == samples:
            print(f"computed high-resolution targets {sample_index + 1}/{samples}", flush=True)

    return {
        "labels64": labels64,
        "delta64": delta64,
        "labels_high": labels_high,
        "signed_distance_high": sdf_high,
        "indentation_masks_high": indentation_high,
        "shape_codes": shape_codes,
        "shape_counts": shape_counts,
        "fov_mask_high": fov_high.astype(np.uint8),
    }


def official_calibration_targets(repo: Path, resolution: int) -> dict[str, np.ndarray]:
    labels = []
    for sample in range(1, 5):
        truth = sio.loadmat(repo / "groundTruths" / f"true{sample}.mat")["truth"].astype(np.uint8)
        resized = np.asarray(
            Image.fromarray(truth).resize((resolution, resolution), resample=Image.Resampling.NEAREST)
        )
        labels.append(resized)
    labels_array = np.stack(labels)
    return {
        "calibration_labels_high": labels_array,
        "calibration_signed_distance_high": np.stack(
            [normalized_signed_distance(item, resolution) for item in labels_array]
        ),
        "calibration_indentation_masks_high": np.stack(
            [instance_indentation_mask(item).astype(np.uint8) for item in labels_array]
        ),
    }


def main() -> None:
    args = parse_args()
    archive = np.load(args.dataset.resolve(), allow_pickle=False)
    samples = int(archive["labels"].shape[0])
    generated = replay_geometry(samples, args.resolution, args.seed)

    audit = {
        "labels64_exact": bool(np.array_equal(generated["labels64"], archive["labels"])),
        "delta64_exact": bool(np.array_equal(generated["delta64"], archive["delta"])),
        "shape_codes_exact": bool(np.array_equal(generated["shape_codes"], archive["shape_codes"])),
        "shape_counts_exact": bool(np.array_equal(generated["shape_counts"], archive["shape_counts"])),
        "label_pixel_mismatch": float(np.mean(generated["labels64"] != archive["labels"])),
        "delta_max_abs_error": float(np.max(np.abs(generated["delta64"] - archive["delta"]))),
    }
    if not all(audit[key] for key in ("labels64_exact", "delta64_exact", "shape_codes_exact", "shape_counts_exact")):
        raise RuntimeError(f"high-resolution replay drifted from the source archive: {audit}")

    calibration = official_calibration_targets(args.official_repo.resolve(), args.resolution)
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        output,
        labels=generated["labels_high"],
        signed_distance=generated["signed_distance_high"],
        indentation_masks=generated["indentation_masks_high"],
        fov_mask=generated["fov_mask_high"],
        shape_codes=generated["shape_codes"],
        shape_counts=generated["shape_counts"],
        train_indices=archive["train_indices"],
        validation_indices=archive["validation_indices"],
        test_indices=archive["test_indices"],
        **calibration,
    )
    summary = {
        "source_dataset": str(args.dataset.resolve()),
        "output": str(output),
        "samples": samples,
        "source_resolution": 64,
        "target_resolution": args.resolution,
        "seed": args.seed,
        "audit": audit,
        "voltages_reused_without_resimulation": True,
        "evaluation_truth_used": False,
        "official_training_truth_used_for_calibration": True,
    }
    summary_path = output.with_suffix(".json")
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
