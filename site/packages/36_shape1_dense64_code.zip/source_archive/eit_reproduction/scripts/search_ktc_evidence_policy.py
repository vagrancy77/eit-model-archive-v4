"""Search calibrated policies over the frozen spatial expert's evidence.

This probes whether the candidate ranker already contains a useful signal in
its regression/classification heads that the original hard policy discarded.
It is a diagnostic only; the final policy must be selected in nested OOF.
"""
from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np
import torch

import train_ktc_spatial_topology_bay_oof as core


def args():
    root = Path(__file__).resolve().parents[1]
    p = argparse.ArgumentParser()
    p.add_argument("--model-dir", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--feature-normalization", choices=("global", "relative"), default="relative")
    p.add_argument("--front-size", type=int, default=1536)
    p.add_argument("--patch-size", type=int, default=20)
    p.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    p.add_argument("--pool", type=Path, default=root / "outputs" / "ktc_cross_representation_pool_seed20260820" / "public_21.npz")
    p.add_argument("--cache-dir", type=Path, default=Path(r"E:\Codex\ktc_expanded_pure_bay_candidate_cache_seed20260820"))
    p.add_argument("--target-dir", type=Path, default=Path(r"E:\Codex\ktc_expanded_pure_bay_training_targets_seed20260820"))
    p.add_argument("--pretrained", type=Path, default=Path(r"E:\Codex\ktc_synthetic_pure_bay_physics_ranker_seed20260820\synthetic_bay_risk_ranker.pt"))
    return p.parse_args()


def z(v):
    v = np.asarray(v, float); v = np.nan_to_num(v)
    return (v - np.median(v)) / max(float(np.std(v)), 1e-5)


def main():
    a = args(); device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    pretrained = torch.load(a.pretrained.resolve(), map_location="cpu", weights_only=False)
    cases, _, _ = core.load_public_cases(a)
    fronts = {c.case_id: core.candidate_front(c, a.front_size) for c in cases}
    patches = core.build_spatial_inputs(a, cases, fronts, device)
    evidence = {}
    for level in sorted({c.level for c in cases}):
        payload = torch.load(a.model_dir.resolve() / f"exclude_{level}.pt", map_location=device, weights_only=False)
        channels = next(iter(patches.values())).shape[1]; models = []
        for m, state in enumerate(payload["models"]):
            model = core.SpatialTopologyRanker(pretrained["models"][m % len(pretrained["models"])], channels).to(device)
            model.load_state_dict(state); model.eval(); models.append(model)
        for c in cases:
            if c.level == level:
                evidence[c.case_id] = core.predict_case(c, fronts[c.case_id], patches[c.case_id], models, pretrained, payload["target_mean"], payload["target_scale"], device, feature_normalization=a.feature_normalization)
    strict = np.asarray([c.case_id in core.STRICT_INWARD_IDS for c in cases])
    rows = []
    modes = ["score", "reg_iou", "reg_bay", "joint", "score_reg", "score_prob", "reg_joint"]
    for limit in (.08, .12, .16, .20, .25, .35):
      for mode in modes:
       for uncertainty in (0, .5, 1.0):
        for threshold in np.linspace(-1, 1, 17):
         choices=[]
         for c in cases:
            e=evidence[c.case_id]; valid=c.valid.copy() & (c.removed<=limit); valid[0]=True
            score=e.score-uncertainty*e.score_std
            reg=e.regression-uncertainty*e.regression_std
            prob=e.probability-uncertainty*e.probability_std
            if mode=="score": s=z(score)
            elif mode=="reg_iou": s=z(reg[:,0])
            elif mode=="reg_bay": s=z(reg[:,2])
            elif mode=="joint": s=z(prob[:,5])
            elif mode=="score_reg": s=z(score)+.8*z(reg[:,0])+.7*z(reg[:,2])+.25*z(reg[:,1])
            elif mode=="score_prob": s=z(score)+.8*z(prob[:,5])+.4*z(prob[:,0])
            else: s=z(reg[:,0])+.8*z(reg[:,2])+.8*z(prob[:,5])
            # These are soft, not truth-based, safety gates.
            valid &= reg[:,0]>=-.05; valid &= reg[:,1]>=-.12; valid &= prob[:,5]>=.10
            idx=int(np.argmax(np.where(valid,s,-np.inf)))
            choices.append(idx if s[idx]>=threshold else 0)
         choices=np.asarray(choices); vals=np.stack([c.targets[i] for c,i in zip(cases,choices)]); changed=choices!=0
         finite=np.isfinite(vals[:,2]); safe=(vals[:,0].min()>=-1e-9 and vals[:,1].min()>=-.005 and not np.any(changed&finite&(vals[:,2]<0)) and not np.any(changed&np.isfinite(vals[:,4])&(vals[:,4]<-.02)))
         useful=changed&(vals[:,0]>=.002)&finite&(vals[:,3]>=.005)&(vals[:,4]>=-.02)
         rows.append({"limit":limit,"mode":mode,"uncertainty":uncertainty,"threshold":threshold,"safe":bool(safe),"changed":int(changed.sum()),"useful":int(useful.sum()),"all_iou":float(vals[:,0].mean()),"strict_iou":float(vals[strict,0].mean()),"ordinary_iou":float(vals[~strict,0].mean()),"strict_bay_f1":float(np.nanmean(vals[strict,3])),"strict_useful":int(useful[strict].sum()),"ordinary_harmed":int(np.count_nonzero(vals[~strict,0]<0))})
    a.output.resolve().parent.mkdir(parents=True,exist_ok=True)
    with a.output.resolve().open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    good=[r for r in rows if r["safe"] and r["strict_useful"]>0]
    for r in sorted(good,key=lambda x:(x["strict_iou"],x["strict_bay_f1"]),reverse=True)[:40]: print(r)


if __name__ == "__main__": main()
