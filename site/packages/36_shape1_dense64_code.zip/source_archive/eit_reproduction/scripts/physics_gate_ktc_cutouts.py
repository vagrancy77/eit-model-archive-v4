"""Physics-gated selection of inward-boundary candidates.

The hull-cutout network proposes a monotone family of carve-only candidates:
no candidate may add foreground or change conductivity class.  Positive and
negative conductivity amplitudes are fitted for every candidate using the KTC
Jacobian.  A validation-selected measurement-gain threshold and change penalty
decide whether a proposed cutout is accepted for each case.
"""
from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from scipy import ndimage as ndi

from train_ktc_concavity_network import (
    InputAdapter,
    aggregate_rows,
    confusion_metrics,
    save_focus_montage,
    save_real_montage,
    write_rows,
)
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_highres_refiner import load_coarse_ensemble
from train_ktc_hull_cutout_network import HullCutoutNet


BIASES = (-2.00, -1.50, -1.00, -0.50, 0.00, 0.50, 1.00)
MAX_COARSE_FOREGROUND_CONFIDENCES = (0.55, 0.65, 0.75, 0.85, 1.01)
CANDIDATE_SPECS = tuple(itertools.product(BIASES, MAX_COARSE_FOREGROUND_CONFIDENCES))
PENALTIES = (0.0, 0.01, 0.03, 0.10, 0.30, 1.0, 3.0, 10.0)
MIN_GAINS = (0.0, 0.0001, 0.0003, 0.001, 0.003, 0.010, 0.030)
MIN_FOLD_AGREEMENTS = (0.50, 0.75, 1.00)
PHYSICS_FOLDS = 4
MAX_COMPONENT_REMOVALS = (0.08, 0.12, 0.16, 0.20, 0.25, 0.30, 0.40, 1.0)
MIN_COMPONENT_PIXELS = 6


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument(
        "--cutout-checkpoint",
        type=Path,
        default=root / "outputs" / "ktc_hull_cutout_formal_seed20260819" / "hull_cutout_best.pt",
    )
    parser.add_argument(
        "--coarse-checkpoint",
        nargs="+",
        type=Path,
        default=[
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "boundary_best.pt",
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "indent_best.pt",
            root / "outputs" / "ktc_concavity_voltage_seed20260819" / "voltage_best.pt",
        ],
    )
    parser.add_argument("--coarse-weights", nargs="+", type=float, default=[0.30, 0.40, 0.30])
    parser.add_argument("--output-dir", type=Path, default=root / "outputs" / "ktc_physics_gated_cutouts")
    parser.add_argument("--batch-size", type=int, default=20)
    parser.add_argument("--iou-tolerance", type=float, default=0.012)
    parser.add_argument("--boundary-tolerance", type=float, default=0.005)
    return parser.parse_args()


@torch.no_grad()
def propose_candidates(
    coarse: torch.nn.Module,
    model: HullCutoutNet,
    adapter: InputAdapter,
    images: np.ndarray,
    voltages: np.ndarray,
    device: torch.device,
    batch_size: int,
    real_resolution: bool,
) -> tuple[np.ndarray, np.ndarray, np.ndarray | None, np.ndarray | None]:
    coarse64_chunks: list[np.ndarray] = []
    candidate64_chunks: list[list[np.ndarray]] = [[] for _ in CANDIDATE_SPECS]
    coarse256_chunks: list[np.ndarray] = []
    candidate256_chunks: list[list[np.ndarray]] = [[] for _ in CANDIDATE_SPECS]
    for start in range(0, len(images), batch_size):
        image = torch.from_numpy(images[start:start + batch_size, None].astype(np.float32)).to(device)
        voltage = torch.from_numpy(voltages[start:start + batch_size].astype(np.float32)).to(device)
        adapted = adapter(image)
        coarse_probability = torch.softmax(coarse(adapted, voltage)["logits"], dim=1)
        coarse_foreground_probability = coarse_probability[:, 1:].sum(dim=1)
        coarse64 = coarse_probability.argmax(dim=1)
        coarse64_chunks.append(coarse64.cpu().numpy().astype(np.uint8))
        if real_resolution:
            coarse256_logits = F.interpolate(
                torch.log(coarse_probability.clamp_min(1e-7)),
                size=(256, 256),
                mode="bilinear",
                align_corners=False,
            )
            coarse256 = coarse256_logits.argmax(dim=1)
            coarse256_chunks.append(coarse256.cpu().numpy().astype(np.uint8))
            coarse_foreground_probability256 = F.interpolate(
                coarse_foreground_probability[:, None],
                size=(256, 256),
                mode="bilinear",
                align_corners=False,
            )[:, 0]
        candidate_index = 0
        for bias in BIASES:
            output = model(adapted, voltage, coarse_probability, cutout_bias=bias)
            foreground64 = output["foreground_probability"][:, 0] >= 0.5
            if real_resolution:
                foreground256 = F.interpolate(
                    output["foreground_probability"],
                    size=(256, 256),
                    mode="bilinear",
                    align_corners=False,
                )[:, 0] >= 0.5
            for max_confidence in MAX_COARSE_FOREGROUND_CONFIDENCES:
                keep64 = torch.logical_or(
                    foreground64, coarse_foreground_probability > max_confidence
                )
                carved64 = torch.where(keep64, coarse64, torch.zeros_like(coarse64))
                candidate64_chunks[candidate_index].append(carved64.cpu().numpy().astype(np.uint8))
                if real_resolution:
                    keep256 = torch.logical_or(
                        foreground256, coarse_foreground_probability256 > max_confidence
                    )
                    carved256 = torch.where(keep256, coarse256, torch.zeros_like(coarse256))
                    candidate256_chunks[candidate_index].append(
                        carved256.cpu().numpy().astype(np.uint8)
                    )
                candidate_index += 1
    coarse64_array = np.concatenate(coarse64_chunks)
    candidate64_array = np.stack([np.concatenate(chunks) for chunks in candidate64_chunks])
    if not real_resolution:
        return coarse64_array, candidate64_array, None, None
    return (
        coarse64_array,
        candidate64_array,
        np.concatenate(coarse256_chunks),
        np.stack([np.concatenate(chunks) for chunks in candidate256_chunks]),
    )


def fit_voltage_residuals(
    labels: np.ndarray,
    voltages: np.ndarray,
    jacobian: np.ndarray,
    node_to_raw_pixel: np.ndarray,
) -> np.ndarray:
    """Fit nonnegative magnitudes for negative and positive conductivity."""
    negative_pixels = np.flip(labels == 1, axis=1).reshape(len(labels), -1).astype(np.float64)
    positive_pixels = np.flip(labels == 2, axis=1).reshape(len(labels), -1).astype(np.float64)
    negative_nodes = negative_pixels[:, node_to_raw_pixel]
    positive_nodes = positive_pixels[:, node_to_raw_pixel]
    j = np.asarray(jacobian, dtype=np.float64)
    basis_negative = -2.0 * (negative_nodes @ j.T)
    basis_positive = 2.0 * (positive_nodes @ j.T)
    target = np.asarray(voltages, dtype=np.float64)
    result = np.empty(len(labels), dtype=np.float64)
    for index in range(len(labels)):
        y = target[index]
        columns = (basis_negative[index], basis_positive[index])
        candidates = [np.zeros_like(y)]
        for column in columns:
            coefficient = max(0.0, float(np.dot(column, y) / max(np.dot(column, column), 1e-12)))
            candidates.append(coefficient * column)
        matrix = np.column_stack(columns)
        gram = matrix.T @ matrix + 1e-8 * np.eye(2)
        coefficient = np.linalg.solve(gram, matrix.T @ y)
        if np.all(coefficient >= 0.0):
            candidates.append(matrix @ coefficient)
        errors = [float(np.mean(np.square(candidate - y))) for candidate in candidates]
        result[index] = min(errors) / max(float(np.mean(np.square(y))), 1e-12)
    return result


def fit_voltage_cross_validated_residuals(
    labels: np.ndarray,
    voltages: np.ndarray,
    jacobian: np.ndarray,
    node_to_raw_pixel: np.ndarray,
    folds: int = PHYSICS_FOLDS,
) -> np.ndarray:
    """Fit conductivity amplitudes on drive-pattern folds and test held-out rows."""
    negative_pixels = np.flip(labels == 1, axis=1).reshape(len(labels), -1).astype(np.float64)
    positive_pixels = np.flip(labels == 2, axis=1).reshape(len(labels), -1).astype(np.float64)
    negative_nodes = negative_pixels[:, node_to_raw_pixel]
    positive_nodes = positive_pixels[:, node_to_raw_pixel]
    j = np.asarray(jacobian, dtype=np.float64)
    basis_negative = -2.0 * (negative_nodes @ j.T)
    basis_positive = 2.0 * (positive_nodes @ j.T)
    target = np.asarray(voltages, dtype=np.float64)
    if target.shape[1] % 31 != 0:
        raise ValueError("KTC voltage rows must contain 31 measurements per drive pattern")
    drive_ids = np.repeat(np.arange(target.shape[1] // 31), 31)
    result = np.empty((len(labels), folds), dtype=np.float64)
    for sample_index in range(len(labels)):
        y = target[sample_index]
        columns = np.column_stack(
            (basis_negative[sample_index], basis_positive[sample_index])
        )
        for fold in range(folds):
            held_out = drive_ids % folds == fold
            training = ~held_out
            y_train = y[training]
            matrix_train = columns[training]
            coefficient_candidates = [np.zeros(2, dtype=np.float64)]
            for column_index in range(2):
                column = matrix_train[:, column_index]
                coefficient = max(
                    0.0,
                    float(np.dot(column, y_train) / max(np.dot(column, column), 1e-12)),
                )
                values = np.zeros(2, dtype=np.float64)
                values[column_index] = coefficient
                coefficient_candidates.append(values)
            gram = matrix_train.T @ matrix_train + 1e-8 * np.eye(2)
            both = np.linalg.solve(gram, matrix_train.T @ y_train)
            if np.all(both >= 0.0):
                coefficient_candidates.append(both)
            training_errors = [
                float(np.mean(np.square(matrix_train @ coefficient - y_train)))
                for coefficient in coefficient_candidates
            ]
            fitted = coefficient_candidates[int(np.argmin(training_errors))]
            held_target = y[held_out]
            held_error = float(np.mean(np.square(columns[held_out] @ fitted - held_target)))
            result[sample_index, fold] = held_error / max(
                float(np.mean(np.square(held_target))), 1e-12
            )
    return result


def candidate_physics(
    coarse_labels: np.ndarray,
    candidates: np.ndarray,
    voltages: np.ndarray,
    archive: np.lib.npyio.NpzFile,
    return_folds: bool = False,
) -> tuple[np.ndarray, np.ndarray] | tuple[np.ndarray, np.ndarray, np.ndarray]:
    all_labels = np.concatenate((coarse_labels[None], candidates), axis=0)
    fold_residuals = np.stack(
        [
            fit_voltage_cross_validated_residuals(
                labels,
                voltages,
                archive["jacobian"],
                archive["node_to_raw_pixel"],
            )
            for labels in all_labels
        ]
    )
    residuals = fold_residuals.mean(axis=2)
    fov = archive["fov_mask"].astype(bool)
    changes = np.zeros_like(residuals)
    for candidate_index in range(1, len(all_labels)):
        changes[candidate_index] = np.logical_and(
            all_labels[candidate_index] != coarse_labels, fov[None]
        ).reshape(len(coarse_labels), -1).sum(axis=1) / max(1, int(fov.sum()))
    if return_folds:
        return residuals, changes, fold_residuals
    return residuals, changes


def candidate_geometry_risks(
    coarse_labels: np.ndarray,
    candidates: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """Measure destructive carving and newly enclosed background per candidate.

    A genuine inward bay is background connected to the exterior.  New closed
    holes are therefore rejected.  The component-wise removal ratio prevents a
    small lesion from being destroyed while a second large lesion hides the
    change in a global area fraction.
    """
    all_labels = np.concatenate((coarse_labels[None], candidates), axis=0)
    component_removal = np.zeros(all_labels.shape[:2], dtype=np.float64)
    new_hole_pixels = np.zeros(all_labels.shape[:2], dtype=np.float64)
    structure = ndi.generate_binary_structure(2, 2)
    for sample_index, coarse in enumerate(coarse_labels):
        coarse_foreground = coarse != 0
        components, count = ndi.label(coarse_foreground, structure=structure)
        coarse_holes = ndi.binary_fill_holes(coarse_foreground) & ~coarse_foreground
        for candidate_index in range(1, len(all_labels)):
            candidate_foreground = all_labels[candidate_index, sample_index] != 0
            removed = coarse_foreground & ~candidate_foreground
            worst = 0.0
            for component_id in range(1, count + 1):
                component = components == component_id
                area = int(component.sum())
                if area < MIN_COMPONENT_PIXELS:
                    continue
                worst = max(worst, float((removed & component).sum()) / area)
            component_removal[candidate_index, sample_index] = worst
            candidate_holes = ndi.binary_fill_holes(candidate_foreground) & ~candidate_foreground
            new_hole_pixels[candidate_index, sample_index] = float(
                np.logical_and(candidate_holes, ~coarse_holes).sum()
            )
    return component_removal, new_hole_pixels


def choose_indices(
    residuals: np.ndarray,
    changes: np.ndarray,
    penalty: float,
    min_gain: float,
    component_removal: np.ndarray | None = None,
    new_hole_pixels: np.ndarray | None = None,
    max_component_removal: float = 1.0,
    fold_residuals: np.ndarray | None = None,
    min_fold_agreement: float = 0.0,
) -> np.ndarray:
    baseline = residuals[0].clip(1e-12)
    ratio = residuals / baseline[None]
    objective = ratio + penalty * changes
    objective[1:, (1.0 - ratio[1:] < min_gain).all(axis=0)] = np.inf
    # Apply the gain condition per candidate and sample rather than allowing a
    # low-change but measurement-neutral cutout to beat identity numerically.
    objective[1:] = np.where(1.0 - ratio[1:] >= min_gain, objective[1:], np.inf)
    if component_removal is not None:
        objective = np.where(component_removal <= max_component_removal + 1e-12, objective, np.inf)
    if new_hole_pixels is not None:
        objective = np.where(new_hole_pixels <= 0.0, objective, np.inf)
    if fold_residuals is not None and min_fold_agreement > 0.0:
        fold_baseline = fold_residuals[0].clip(1e-12)
        fold_gain = 1.0 - fold_residuals / fold_baseline[None]
        agreement = (fold_gain >= min_gain).mean(axis=2)
        objective = np.where(agreement >= min_fold_agreement, objective, np.inf)
    return objective.argmin(axis=0)


def gather_candidates(coarse: np.ndarray, candidates: np.ndarray, selected: np.ndarray) -> np.ndarray:
    all_predictions = np.concatenate((coarse[None], candidates), axis=0)
    return all_predictions[selected, np.arange(len(selected))]


def metrics_for(truths: np.ndarray, predictions: np.ndarray, indentations: np.ndarray) -> dict[str, float]:
    rows = [
        confusion_metrics(truth, prediction, indentation)
        for truth, prediction, indentation in zip(truths, predictions, indentations)
    ]
    return aggregate_rows(rows)


def selection_score(metrics: dict[str, float]) -> float:
    return float(
        0.45 * metrics["foreground_iou"]
        + 0.25 * metrics["boundary_f1"]
        + 0.30 * metrics["concavity_score"]
    )


def casewise_iou_safety(
    truths: np.ndarray,
    baseline: np.ndarray,
    predictions: np.ndarray,
) -> dict[str, float]:
    truth_foreground = truths != 0
    baseline_foreground = baseline != 0
    prediction_foreground = predictions != 0

    def values(predicted: np.ndarray) -> np.ndarray:
        intersection = np.logical_and(truth_foreground, predicted).reshape(len(truths), -1).sum(axis=1)
        union = np.logical_or(truth_foreground, predicted).reshape(len(truths), -1).sum(axis=1)
        return intersection / np.maximum(union, 1)

    delta = values(prediction_foreground) - values(baseline_foreground)
    tail_count = max(1, int(np.ceil(0.10 * len(delta))))
    ordered = np.sort(delta)
    return {
        "mean_iou_delta": float(delta.mean()),
        "p05_iou_delta": float(np.quantile(delta, 0.05)),
        "cvar10_iou_delta": float(ordered[:tail_count].mean()),
        "worst_iou_delta": float(ordered[0]),
        "drop_gt_0_10_rate": float((delta < -0.10).mean()),
        "improvement_rate": float((delta > 1e-9).mean()),
    }


def risk_adjusted_selection_score(
    metrics: dict[str, float],
    safety: dict[str, float],
) -> float:
    # CVaR makes a rule pay for the worst decile rather than hiding a
    # destructive carve behind many small average improvements.
    return selection_score(metrics) + 0.10 * min(0.0, safety["cvar10_iou_delta"])


def save_selection_histogram(path: Path, selected: np.ndarray, title: str) -> None:
    labels = [
        "identity",
        *[f"b={bias:+.1f}, c<{confidence:.2f}" for bias, confidence in CANDIDATE_SPECS],
    ]
    counts = np.bincount(selected, minlength=len(labels))
    figure, axis = plt.subplots(figsize=(16.0, 4.5))
    axis.bar(np.arange(len(labels)), counts, color="#2f6f73")
    axis.set_xticks(np.arange(len(labels)), labels, rotation=65, ha="right", fontsize=7)
    axis.set_ylabel("cases")
    axis.set_title(title)
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    archive = np.load(args.dataset.resolve(), allow_pickle=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    coarse, _, coarse_weights = load_coarse_ensemble(
        args.coarse_checkpoint, args.coarse_weights, device
    )
    state = torch.load(args.cutout_checkpoint.resolve(), map_location=device, weights_only=False)
    model = HullCutoutNet(int(state["base_channels"])).to(device)
    model.load_state_dict(state["model"])
    model.eval()
    adapter = InputAdapter(archive["fov_mask"]).to(device)
    print(
        f"device={device}; candidates={len(CANDIDATE_SPECS)} bias-confidence pairs; "
        f"coarse_weights={coarse_weights}",
        flush=True,
    )

    validation_indices = archive["validation_indices"]
    validation_coarse, validation_candidates, _, _ = propose_candidates(
        coarse,
        model,
        adapter,
        archive["linear_images"][validation_indices],
        archive["voltages"][validation_indices],
        device,
        args.batch_size,
        real_resolution=False,
    )
    validation_residuals, validation_changes, validation_fold_residuals = candidate_physics(
        validation_coarse,
        validation_candidates,
        archive["voltages"][validation_indices],
        archive,
        return_folds=True,
    )
    validation_removal, validation_new_holes = candidate_geometry_risks(
        validation_coarse, validation_candidates
    )
    validation_truth = archive["labels"][validation_indices]
    validation_indent = archive["indentation_masks"][validation_indices]
    baseline_metrics = metrics_for(validation_truth, validation_coarse, validation_indent)
    records: list[dict[str, object]] = []
    for penalty, min_gain, max_component_removal, min_fold_agreement in itertools.product(
        PENALTIES, MIN_GAINS, MAX_COMPONENT_REMOVALS, MIN_FOLD_AGREEMENTS
    ):
        selected = choose_indices(
            validation_residuals,
            validation_changes,
            penalty,
            min_gain,
            validation_removal,
            validation_new_holes,
            max_component_removal,
            validation_fold_residuals,
            min_fold_agreement,
        )
        predictions = gather_candidates(validation_coarse, validation_candidates, selected)
        metrics = metrics_for(validation_truth, predictions, validation_indent)
        safety = casewise_iou_safety(validation_truth, validation_coarse, predictions)
        eligible = (
            metrics["foreground_iou"] >= baseline_metrics["foreground_iou"] - args.iou_tolerance
            and metrics["boundary_f1"] >= baseline_metrics["boundary_f1"] - args.boundary_tolerance
            and metrics["concavity_score"] > baseline_metrics["concavity_score"]
        )
        records.append(
            {
                "penalty": penalty,
                "min_gain": min_gain,
                "max_component_removal": max_component_removal,
                "min_fold_agreement": min_fold_agreement,
                "metrics": metrics,
                "casewise_safety": safety,
                "eligible": eligible,
                "score": risk_adjusted_selection_score(metrics, safety) if eligible else None,
                "modified_cases": int((selected != 0).sum()),
            }
        )
    baseline_record = {
        "penalty": None,
        "min_gain": None,
        "max_component_removal": None,
        "min_fold_agreement": None,
        "method": "identity",
        "metrics": baseline_metrics,
        "casewise_safety": {
            "mean_iou_delta": 0.0,
            "p05_iou_delta": 0.0,
            "cvar10_iou_delta": 0.0,
            "worst_iou_delta": 0.0,
            "drop_gt_0_10_rate": 0.0,
            "improvement_rate": 0.0,
        },
        "eligible": True,
        "score": selection_score(baseline_metrics),
        "modified_cases": 0,
    }
    eligible = [record for record in records if record["eligible"]]
    selected_record = max([baseline_record, *eligible], key=lambda item: float(item["score"]))
    print(f"validation baseline: {baseline_metrics}", flush=True)
    print(f"validation selected: {selected_record}", flush=True)
    selection = {
        "baseline": baseline_metrics,
        "search": records,
        "selected": selected_record,
        "evaluation_truth_accessed": False,
    }
    (output_dir / "validation_selection.json").write_text(json.dumps(selection, indent=2), encoding="utf-8")

    test_indices = archive["test_indices"]
    test_coarse, test_candidates, _, _ = propose_candidates(
        coarse,
        model,
        adapter,
        archive["linear_images"][test_indices],
        archive["voltages"][test_indices],
        device,
        args.batch_size,
        real_resolution=False,
    )
    if selected_record["penalty"] is None:
        test_selected = np.zeros(len(test_indices), dtype=np.int64)
    else:
        test_residuals, test_changes, test_fold_residuals = candidate_physics(
            test_coarse,
            test_candidates,
            archive["voltages"][test_indices],
            archive,
            return_folds=True,
        )
        test_removal, test_new_holes = candidate_geometry_risks(test_coarse, test_candidates)
        test_selected = choose_indices(
            test_residuals,
            test_changes,
            float(selected_record["penalty"]),
            float(selected_record["min_gain"]),
            test_removal,
            test_new_holes,
            float(selected_record["max_component_removal"]),
            test_fold_residuals,
            float(selected_record["min_fold_agreement"]),
        )
    test_prediction = gather_candidates(test_coarse, test_candidates, test_selected)
    test_baseline_metrics = metrics_for(
        archive["labels"][test_indices], test_coarse, archive["indentation_masks"][test_indices]
    )
    test_metrics = metrics_for(
        archive["labels"][test_indices], test_prediction, archive["indentation_masks"][test_indices]
    )
    print(f"untouched test baseline: {test_baseline_metrics}", flush=True)
    print(f"untouched test physics gate: {test_metrics}; modified={(test_selected != 0).sum()}", flush=True)

    # Evaluation truths remain untouched until selection and synthetic test.
    real_coarse64, real_candidates64, real_coarse, real_candidates = propose_candidates(
        coarse,
        model,
        adapter,
        archive["real_linear_images"],
        archive["real_voltages"],
        device,
        args.batch_size,
        real_resolution=True,
    )
    assert real_coarse is not None and real_candidates is not None
    if selected_record["penalty"] is None:
        real_selected = np.zeros(len(real_coarse), dtype=np.int64)
    else:
        real_residuals, real_changes, real_fold_residuals = candidate_physics(
            real_coarse64,
            real_candidates64,
            archive["real_voltages"],
            archive,
            return_folds=True,
        )
        real_removal, real_new_holes = candidate_geometry_risks(real_coarse64, real_candidates64)
        real_selected = choose_indices(
            real_residuals,
            real_changes,
            float(selected_record["penalty"]),
            float(selected_record["min_gain"]),
            real_removal,
            real_new_holes,
            float(selected_record["max_component_removal"]),
            real_fold_residuals,
            float(selected_record["min_fold_agreement"]),
        )
    real_prediction = gather_candidates(real_coarse, real_candidates, real_selected)
    real_truths = archive["real_labels"]
    real_ids = archive["real_ids"]
    predictions = {"coarse_fusion": real_coarse, "physics_gated_cutout": real_prediction}
    real_summary: dict[str, dict[str, float]] = {}
    real_rows: list[dict[str, object]] = []
    for name, values in predictions.items():
        real_summary[name], rows = evaluate_real_predictions(name, values, real_truths, real_ids)
        real_rows.extend(rows)
        print(f"real 21 {name}: {real_summary[name]}", flush=True)
    write_rows(output_dir / "real_case_metrics.csv", real_rows)
    save_real_montage(
        output_dir / "real_all_21_comparison.png", real_truths, real_ids, predictions, real_rows
    )
    save_focus_montage(
        output_dir / "real_most_concave_comparison.png", real_truths, real_ids, predictions, real_rows
    )
    save_selection_histogram(
        output_dir / "real_candidate_selection.png",
        real_selected,
        "Physics-gated cutout selection on 21 KTC cases",
    )
    np.savez_compressed(
        output_dir / "predictions.npz",
        test_selected=test_selected,
        real_selected=real_selected,
        real_coarse=real_coarse,
        real_physics_gated=real_prediction,
    )
    result = {
        "method": "validation-selected, measurement-consistent, component-safe carve-only cutouts",
        "candidate_biases": BIASES,
        "candidate_max_coarse_foreground_confidences": MAX_COARSE_FOREGROUND_CONFIDENCES,
        "candidate_specs": CANDIDATE_SPECS,
        "max_component_removal_candidates": MAX_COMPONENT_REMOVALS,
        "min_fold_agreement_candidates": MIN_FOLD_AGREEMENTS,
        "physics_cross_validation_folds": PHYSICS_FOLDS,
        "new_enclosed_holes_allowed": False,
        "validation_selection": selection,
        "synthetic_untouched_test": {
            "coarse_fusion": test_baseline_metrics,
            "physics_gated_cutout": test_metrics,
            "modified_cases": int((test_selected != 0).sum()),
        },
        "real_evaluation": real_summary,
        "real_modified_cases": int((real_selected != 0).sum()),
        "real_selected_candidate_indices": real_selected.tolist(),
        "evaluation_truth_used_for_training_or_selection": False,
        "args": vars(args) | {
            "dataset": str(args.dataset),
            "cutout_checkpoint": str(args.cutout_checkpoint),
            "coarse_checkpoint": [str(path) for path in args.coarse_checkpoint],
            "output_dir": str(args.output_dir),
        },
    }
    (output_dir / "summary.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
