param(
    [int[]]$Seeds = @(20260912, 20260913, 20260914),
    [string]$Python = 'E:\conda-envs\pytorch-gpu\python.exe',
    [string]$Root = 'E:\Codex'
)

$ErrorActionPreference = 'Stop'
$trainScript = Join-Path $Root 'eit_reproduction\scripts\train_topology_residual_eit_v3.py'

foreach ($seed in $Seeds) {
    $outputDir = Join-Path $Root "topology_risk_eit_v4_seed_$seed"
    $summary = Join-Path $outputDir 'summary.json'
    $log = Join-Path $outputDir 'training_console.log'

    if (Test-Path -LiteralPath $summary) {
        Write-Host "seed=$seed already complete; skipping"
        continue
    }

    New-Item -ItemType Directory -Force -Path $outputDir | Out-Null
    Write-Host "seed=$seed training started at $(Get-Date -Format o)"

    & $Python $trainScript `
        --output-dir $outputDir `
        --epochs 80 `
        --patience 18 `
        --batch-size 18 `
        --base-channels 28 `
        --learning-rate 0.0004 `
        --weight-decay 0.0001 `
        --stress-repeat 2 `
        --ordinary-repeat 4 `
        --architecture v4 `
        --seed $seed `
        --device cuda `
        --physics-weight 0.00015 `
        --topology-start 4 `
        --topology-ramp 10 `
        --progress-every 4 `
        --disable-amp 2>&1 | Tee-Object -FilePath $log

    if ($LASTEXITCODE -ne 0) {
        throw "seed=$seed training failed with exit code $LASTEXITCODE"
    }
    if (-not (Test-Path -LiteralPath $summary)) {
        throw "seed=$seed exited without summary.json"
    }
    Write-Host "seed=$seed training completed at $(Get-Date -Format o)"
}
