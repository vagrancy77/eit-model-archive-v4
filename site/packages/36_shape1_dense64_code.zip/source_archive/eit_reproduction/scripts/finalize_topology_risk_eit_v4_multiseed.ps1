param(
    [int[]]$Seeds = @(20260912, 20260913, 20260914),
    [string]$Python = 'E:\conda-envs\pytorch-gpu\python.exe',
    [string]$Root = 'E:\Codex',
    [int]$Bootstrap = 10000
)

$ErrorActionPreference = 'Stop'
$scriptRoot = Join-Path $Root 'eit_reproduction\scripts'
$calibrate = Join-Path $scriptRoot 'calibrate_topology_hole_resolver.py'
$evaluate = Join-Path $scriptRoot 'evaluate_topology_residual_eit_v3.py'
$aggregate = Join-Path $scriptRoot 'aggregate_topology_risk_eit_v4_multiseed.py'
$aggregateRuns = @('20260911=E:\Codex\topology_risk_eit_v4_final')

foreach ($seed in $Seeds) {
    $trainingDir = Join-Path $Root "topology_risk_eit_v4_seed_$seed"
    $checkpoint = Join-Path $trainingDir 'topology_residual_v4_best.pt'
    $predictions = Join-Path $trainingDir 'test_predictions.npz'
    $resolver = Join-Path $trainingDir 'hole_resolver.json'
    $finalDir = Join-Path $Root "topology_risk_eit_v4_seed_${seed}_final"
    $finalSummary = Join-Path $finalDir 'comparison_summary.json'

    foreach ($required in @($checkpoint, $predictions)) {
        if (-not (Test-Path -LiteralPath $required)) {
            throw "Missing training output: $required"
        }
    }

    if (-not (Test-Path -LiteralPath $resolver)) {
        Write-Host "seed=$seed synthetic-validation resolver calibration started at $(Get-Date -Format o)"
        & $Python $calibrate `
            --checkpoint $checkpoint `
            --output $resolver `
            --batch-size 24
        if ($LASTEXITCODE -ne 0) {
            throw "seed=$seed resolver calibration failed with exit code $LASTEXITCODE"
        }
    } else {
        Write-Host "seed=$seed resolver already calibrated; skipping"
    }

    if (-not (Test-Path -LiteralPath $finalSummary)) {
        Write-Host "seed=$seed frozen evaluation started at $(Get-Date -Format o)"
        & $Python $evaluate `
            --checkpoint $checkpoint `
            --new-predictions $predictions `
            --hole-resolver $resolver `
            --output-dir $finalDir `
            --bootstrap 5000 `
            --seed $seed
        if ($LASTEXITCODE -ne 0) {
            throw "seed=$seed frozen evaluation failed with exit code $LASTEXITCODE"
        }
    } else {
        Write-Host "seed=$seed frozen evaluation already complete; skipping"
    }
    $aggregateRuns += "$seed=$finalDir"
}

$aggregateDir = Join-Path $Root 'topology_risk_eit_v4_multiseed_final'
Write-Host "four-seed hierarchical analysis started at $(Get-Date -Format o)"
& $Python $aggregate `
    --runs $aggregateRuns `
    --output-dir $aggregateDir `
    --bootstrap $Bootstrap `
    --seed 20260915
if ($LASTEXITCODE -ne 0) {
    throw "four-seed analysis failed with exit code $LASTEXITCODE"
}
Write-Host "multi-seed finalization completed at $(Get-Date -Format o)"
