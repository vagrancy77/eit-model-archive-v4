"""Train a measurement-conditioned expert residual for non-convex EIT.

The frozen occupancy refiner is deliberately kept as the identity path.  A
small residual bank is trained only on the independent deep-concavity stress
set.  A global measurement feature predicts which geometric failure family is
present (deep C, U, keyhole, ...), and a soft mixture of level-set fields adds
the corresponding correction.  This keeps ordinary KTC-shaped objects on the
previous reconstruction while giving narrow re-entrant objects a dedicated
shape prior.
"""
from __future__ import annotations

import argparse
import json
import math
import random
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader

from train_ktc_concavity_network import DecoderStage, InputAdapter, ResidualBlock, save_focus_montage, save_real_montage, write_rows
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_highres_refiner import load_coarse_ensemble
from train_ktc_implicit_boolean_network import (
    ImplicitBooleanNet,
    StructuralDataset,
    prepare_structural_arrays,
    standard_metrics,
    stress_metrics,
    soft_dice_loss,
    cutout_topology_loss,
)

# Importing the module rather than copying its frozen-field implementation
# keeps the checkpoint and preprocessing contract identical.
import train_ktc_levelset_occupancy_refiner as occupancy


FAMILY_NAMES = ("deep_c", "deep_u", "keyhole_bay", "crescent", "heart_notch", "sharp_star", "reentrant_v", "multi_object_gap")


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    p.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    p.add_argument("--boolean-checkpoint", type=Path, required=True)
    p.add_argument("--generic-checkpoint", type=Path, required=True)
    p.add_argument("--coarse-checkpoint", nargs="+", type=Path, default=[
        root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "boundary_best.pt",
        root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "indent_best.pt",
        root / "outputs" / "ktc_concavity_voltage_seed20260819" / "voltage_best.pt",
    ])
    p.add_argument("--coarse-weights", nargs="+", type=float, default=[0.30, 0.40, 0.30])
    p.add_argument("--output-dir", type=Path, required=True)
    p.add_argument("--epochs", type=int, default=24)
    p.add_argument("--patience", type=int, default=7)
    p.add_argument("--batch-size", type=int, default=24)
    p.add_argument("--base-channels", type=int, default=12)
    p.add_argument("--learning-rate", type=float, default=1.2e-3)
    p.add_argument("--workers", type=int, default=0)
    p.add_argument("--seed", type=int, default=20260820)
    return p.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)


class ExpertField(nn.Module):
    def __init__(self, base: int) -> None:
        super().__init__()
        self.coarse = nn.Conv2d(base * 16, 1, 1)
        self.middle = nn.Conv2d(base * 4, 1, 1)
        self.fine = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))
        for layer in (self.coarse, self.middle, self.fine[-1]):
            nn.init.zeros_(layer.weight); nn.init.zeros_(layer.bias)

    def forward(self, bottleneck: torch.Tensor, middle: torch.Tensor, fine: torch.Tensor) -> torch.Tensor:
        size = fine.shape[-2:]
        c = F.interpolate(self.coarse(bottleneck), size=size, mode="bicubic", align_corners=False)
        m = F.interpolate(self.middle(middle), size=size, mode="bicubic", align_corners=False)
        return 1.35 * torch.tanh(c) + 0.95 * torch.tanh(m) + 0.65 * torch.tanh(self.fine(fine))


class ShapeExpertResidual(nn.Module):
    """Shared multiscale encoder plus eight geometry-specific level-set fields."""

    def __init__(self, base: int = 12) -> None:
        super().__init__(); self.base = base
        self.stem = ResidualBlock(11, base)
        self.enc1 = ResidualBlock(base, base * 2)
        self.enc2 = ResidualBlock(base * 2, base * 4)
        self.enc3 = ResidualBlock(base * 4, base * 8)
        self.bottleneck = nn.Sequential(ResidualBlock(base * 8, base * 16), nn.Dropout2d(0.08), ResidualBlock(base * 16, base * 16))
        self.dec3 = DecoderStage(base * 16, base * 8, base * 8)
        self.dec2 = DecoderStage(base * 8, base * 4, base * 4)
        self.dec1 = DecoderStage(base * 4, base * 2, base * 2)
        self.dec0 = DecoderStage(base * 2, base, base)
        self.experts = nn.ModuleList([ExpertField(base) for _ in FAMILY_NAMES])
        self.family = nn.Sequential(nn.Linear(base * 16 + base * 4 * 4 + 11, base * 8), nn.SiLU(), nn.Dropout(0.1), nn.Linear(base * 8, len(FAMILY_NAMES)))
        self.gate = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))
        self.sdf = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))
        nn.init.zeros_(self.gate[-1].weight); nn.init.constant_(self.gate[-1].bias, -1.2)
        nn.init.zeros_(self.sdf[-1].weight); nn.init.zeros_(self.sdf[-1].bias)

    def forward(self, features: torch.Tensor, base_output: dict[str, torch.Tensor], family_target: torch.Tensor | None = None) -> dict[str, torch.Tensor]:
        e0 = self.stem(features); e1 = self.enc1(F.max_pool2d(e0, 2)); e2 = self.enc2(F.max_pool2d(e1, 2)); e3 = self.enc3(F.max_pool2d(e2, 2))
        bottleneck = self.bottleneck(F.max_pool2d(e3, 2)); d3 = self.dec3(bottleneck, e3); d2 = self.dec2(d3, e2); d1 = self.dec1(d2, e1); fine = self.dec0(d1, e0)
        pooled = F.adaptive_avg_pool2d(bottleneck, 1).flatten(1)
        global_stats = F.adaptive_avg_pool2d(features, 1).flatten(1)
        spatial_stats = F.adaptive_avg_pool2d(fine, (4, 4)).flatten(1)
        family_logits = self.family(torch.cat((pooled, spatial_stats, global_stats), dim=1))
        weights = torch.softmax(family_logits, dim=1)
        # Teacher-forced routing gives each expert a clean gradient during
        # training; inference always uses the measurement-only soft gate.
        if family_target is not None:
            weights = F.one_hot(family_target.clamp(0, len(FAMILY_NAMES) - 1), len(FAMILY_NAMES)).to(features.dtype)
        fields = torch.stack([head(bottleneck, d2, fine) for head in self.experts], dim=1)
        correction = (fields * weights[:, :, None, None, None]).sum(dim=1)
        gate = torch.sigmoid(self.gate(fine))
        base_fg = base_output["foreground"].clamp(1e-5, 1.0 - 1.0e-5)
        base_logit = torch.logit(base_fg)
        refined_field = base_logit + 2.15 * gate * correction
        foreground = torch.sigmoid(refined_field)
        polarity = base_output["probabilities"][:, 1:].clamp_min(1e-6); polarity = polarity / polarity.sum(dim=1, keepdim=True)
        probabilities = torch.cat((1.0 - foreground, foreground * polarity), dim=1).clamp_min(1e-7)
        return {"logits": torch.log(probabilities), "probabilities": probabilities, "foreground": foreground, "correction": correction, "gate": gate, "family_logits": family_logits, "sdf": torch.tanh(self.sdf(fine))}


def expert_loss(out: dict[str, torch.Tensor], base: dict[str, torch.Tensor], batch: dict[str, torch.Tensor], ramp: float) -> tuple[torch.Tensor, dict[str, float]]:
    labels = batch["labels"]; fg = out["foreground"]; target = (labels != 0).float().unsqueeze(1)
    ce = F.nll_loss(out["logits"], labels, weight=out["logits"].new_tensor((0.35, 1.25, 1.25))) + soft_dice_loss(out["logits"], labels)
    dy, dx = occupancy.gradients(fg); ty, tx = occupancy.gradients(target); boundary = F.l1_loss(dy, ty) + F.l1_loss(dx, tx)
    depth = 1.0 + 3.0 * batch["cutout_depth"]; rim = batch["cutout"] * F.max_pool2d(target, 11, 1, 5); banks = target * F.max_pool2d(batch["cutout"], 11, 1, 5)
    false_fill = occupancy.masked_mean(fg, rim * depth); false_bank = occupancy.masked_mean(1.0 - fg, banks)
    domain = F.max_pool2d(batch["support"], 9, 1, 4); topology = cutout_topology_loss((1.0 - fg) * domain, batch["cutout"], domain, 8)
    target_sdf = torch.minimum(batch["support_sdf"], -batch["cutout_sdf"]).clamp(-1.0, 1.0); sdf = F.smooth_l1_loss(out["sdf"], target_sdf, beta=0.08)
    family_ce = F.cross_entropy(out["family_logits"], batch["family"])
    residual = (out["gate"] * out["correction"].abs()).mean()
    total = ce + ramp * (0.26 * boundary + 0.24 * sdf + 0.78 * false_fill + 0.72 * false_bank + 0.34 * topology + 0.90 * family_ce + 0.012 * residual)
    return total, {"total": float(total.detach()), "ce": float(ce.detach()), "fill": float(false_fill.detach()), "bank": float(false_bank.detach()), "family": float(family_ce.detach())}


@torch.no_grad()
def predict(coarse, boolean, generic, expert, adapter, arrays, indices, device, batch_size):
    loader = DataLoader(StructuralDataset(arrays, indices, 1), batch_size=batch_size, shuffle=False); pred=[]; fam=[]
    for batch in loader:
        image=batch["image"].to(device); voltage=batch["voltage"].to(device); x,b=occupancy.frozen_fields(coarse,boolean,adapter,image,voltage); base=generic(x,b); out=expert(x,base)
        pred.append(out["logits"].argmax(1).cpu().numpy().astype(np.uint8)); fam.append(out["family_logits"].argmax(1).cpu().numpy().astype(np.int16))
    return np.concatenate(pred), np.concatenate(fam)


def main() -> None:
    args=parse_args(); set_seed(args.seed); out_dir=args.output_dir.resolve(); out_dir.mkdir(parents=True, exist_ok=True); device=torch.device("cuda" if torch.cuda.is_available() else "cpu")
    base_archive=np.load(args.base_dataset.resolve(),allow_pickle=False); stress_archive=np.load(args.stress_dataset.resolve(),allow_pickle=False); base=prepare_structural_arrays(base_archive,"base"); stress=prepare_structural_arrays(stress_archive,"stress")
    coarse,_,weights=load_coarse_ensemble(args.coarse_checkpoint,args.coarse_weights,device); bs=torch.load(args.boolean_checkpoint.resolve(),map_location=device,weights_only=False); boolean=ImplicitBooleanNet(int(bs["base_channels"])).to(device); boolean.load_state_dict(bs["model"],strict=False); boolean.eval(); boolean.requires_grad_(False)
    gs=torch.load(args.generic_checkpoint.resolve(),map_location=device,weights_only=False); generic=occupancy.OccupancyRefiner(int(gs["base_channels"])).to(device); generic.load_state_dict(gs["model"]); generic.eval(); generic.requires_grad_(False); adapter=InputAdapter(base_archive["fov_mask"]).to(device)
    expert=ShapeExpertResidual(args.base_channels).to(device); optim=torch.optim.AdamW(expert.parameters(),lr=args.learning_rate,weight_decay=1e-4); sched=torch.optim.lr_scheduler.CosineAnnealingLR(optim,T_max=args.epochs)
    train=DataLoader(StructuralDataset(stress,stress_archive["train_indices"],1),batch_size=args.batch_size,shuffle=True,drop_last=True,num_workers=args.workers,pin_memory=device.type=="cuda"); val=np.asarray(stress_archive["validation_indices"],dtype=np.int64); best=-math.inf; stale=0; history=[]; checkpoint=out_dir/"shape_expert_best.pt"
    for epoch in range(1,args.epochs+1):
        expert.train(); records=[]; ramp=min(1.0,epoch/5.0)
        for batch in train:
            moved={k:v.to(device,non_blocking=True) for k,v in batch.items()}; image=moved["image"]; voltage=moved["voltage"]
            with torch.no_grad(): x,b=occupancy.frozen_fields(coarse,boolean,adapter,image,voltage); base_out=generic(x,b)
            optim.zero_grad(set_to_none=True); out=expert(x,base_out,moved["family"]); loss,parts=expert_loss(out,b,moved,ramp); loss.backward(); torch.nn.utils.clip_grad_norm_(expert.parameters(),5.0); optim.step(); records.append(parts)
        sched.step(); expert.eval(); vp,vfam=predict(coarse,boolean,generic,expert,adapter,stress,val,device,args.batch_size); vm,_,_=stress_metrics(stress.labels[val],vp,stress.cutout[val],stress.cutout_depth[val],stress.family_codes[val]); fam_acc=float((vfam==stress.family_codes[val]).mean()); score=.30*vm["foreground_iou"]+.25*vm["open_deep_cutout_recovery"]+.20*vm["bank_retention"]+.15*vm["topology_structural_joint"]+.10*fam_acc; row={"epoch":epoch,"score":score,"foreground_iou":vm["foreground_iou"],"open_deep":vm["open_deep_cutout_recovery"],"bank":vm["bank_retention"],"topology":vm["topology_structural_joint"],"family_accuracy":fam_acc,"train_loss":float(np.mean([z["total"] for z in records]))}; history.append(row); print(f"epoch {epoch:03d}: score={score:.4f} iou={row['foreground_iou']:.4f} open={row['open_deep']:.4f} bank={row['bank']:.4f} family={fam_acc:.3f}",flush=True)
        if score>best+1e-5: best=score; stale=0; torch.save({"model":expert.state_dict(),"base_channels":args.base_channels,"epoch":epoch,"validation":row},checkpoint)
        else: stale+=1
        if stale>=args.patience: break
    expert.load_state_dict(torch.load(checkpoint,map_location=device,weights_only=False)["model"]); expert.eval(); test=np.asarray(stress_archive["test_indices"],dtype=np.int64); pred,fam=predict(coarse,boolean,generic,expert,adapter,stress,test,device,args.batch_size); sm,byfam,rows=stress_metrics(stress.labels[test],pred,stress.cutout[test],stress.cutout_depth[test],stress.family_codes[test]); base_idx=np.asarray(base_archive["test_indices"],dtype=np.int64); base_pred=generic_predictions(coarse,boolean,generic,adapter,base,base_idx,device,args.batch_size); bm=standard_metrics(base.labels[base_idx],base_pred,base.indentation[base_idx])
    # Real KTC is evaluated only after selection on the synthetic validation split.
    real_images=np.asarray(base_archive["real_linear_images"],dtype=np.float32); real_voltages=np.asarray(base_archive["real_voltages"],dtype=np.float32); chunks=[]
    for s in range(0,len(real_images),args.batch_size):
        image=torch.from_numpy(real_images[s:s+args.batch_size,None]).to(device); voltage=torch.from_numpy(real_voltages[s:s+args.batch_size]).to(device); x,b=occupancy.frozen_fields(coarse,boolean,adapter,image,voltage); g=generic(x,b); chunks.append(F.interpolate(expert(x,g)["logits"],size=(256,256),mode="bilinear",align_corners=False).argmax(1).cpu().numpy().astype(np.uint8))
    real_pred=np.concatenate(chunks); truth=np.asarray(base_archive["real_labels"]); ids=np.asarray(base_archive["real_ids"]); real_summary,real_rows=evaluate_real_predictions("shape_expert",real_pred,truth,ids); write_rows(out_dir/"real_case_metrics.csv",real_rows); save_real_montage(out_dir/"real_all_21_comparison.png",truth,ids,{"shape_expert":real_pred},real_rows); save_focus_montage(out_dir/"real_most_concave_comparison.png",truth,ids,{"shape_expert":real_pred},real_rows)
    np.savez_compressed(out_dir/"predictions.npz",stress_test_indices=test,stress_expert=pred,stress_family=fam,base_test_indices=base_idx,base_generic=base_pred,real_expert=real_pred)
    result={"method":"measurement-conditioned eight-family level-set expert residual","device":str(device),"seed":args.seed,"generic_checkpoint":str(args.generic_checkpoint.resolve()),"validation_history":history,"synthetic_test":{"base":bm,"stress":{"summary":sm,"by_family":byfam,"rows":rows}},"real_evaluation":{"shape_expert":real_summary},"family_names":list(FAMILY_NAMES),"evaluation_truth_used_for_training_or_selection":False}; (out_dir/"summary.json").write_text(json.dumps(result,indent=2,default=str),encoding="utf-8"); print(json.dumps(result,indent=2,default=str),flush=True)


@torch.no_grad()
def generic_predictions(coarse,boolean,generic,adapter,arrays,indices,device,batch_size):
    loader=DataLoader(StructuralDataset(arrays,indices,0),batch_size=batch_size,shuffle=False); pred=[]
    for batch in loader:
        image=batch["image"].to(device); voltage=batch["voltage"].to(device); x,b=occupancy.frozen_fields(coarse,boolean,adapter,image,voltage); pred.append(generic(x,b)["logits"].argmax(1).cpu().numpy().astype(np.uint8))
    return np.concatenate(pred)


if __name__ == "__main__": main()
