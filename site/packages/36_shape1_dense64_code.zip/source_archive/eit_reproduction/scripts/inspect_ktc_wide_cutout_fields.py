"""Visualize frozen cutout and bank evidence on all public KTC2023 cases."""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz"
    )
    parser.add_argument(
        "--predictions", type=Path,
        default=root / "outputs" / "ktc_bank_guarded_wide_cutout_seed20260820" / "predictions.npz",
    )
    parser.add_argument(
        "--output", type=Path,
        default=root / "outputs" / "ktc_bank_guarded_wide_cutout_seed20260820" / "public_field_diagnostics.png",
    )
    args = parser.parse_args()
    data = np.load(args.dataset.resolve(), allow_pickle=False)
    predictions = np.load(args.predictions.resolve(), allow_pickle=False)
    truth = data["real_labels"]
    raw = predictions["real_raw"]
    cutout = predictions["real_cutout_probability"][:, 0]
    bank = predictions["real_bank_probability"][:, 0]
    competition = cutout * (1.0 - bank)

    figure, axes = plt.subplots(len(truth), 5, figsize=(12.5, 2.05 * len(truth)), squeeze=False)
    columns = ("truth", "stable raw", "cutout probability", "bank probability", "cutout x (1-bank)")
    for row in range(len(truth)):
        images = (truth[row], raw[row], cutout[row], bank[row], competition[row])
        for column, image in enumerate(images):
            categorical = column < 2
            axes[row, column].imshow(
                image,
                cmap="viridis" if categorical else "magma",
                vmin=0,
                vmax=2 if categorical else 1,
                interpolation="nearest",
            )
            axes[row, column].set_axis_off()
            if row == 0:
                axes[row, column].set_title(columns[column], fontsize=9)
        axes[row, 0].set_ylabel(str(data["real_ids"][row]), fontsize=8)
    figure.suptitle("Frozen synthetic-trained topology evidence on all 21 public KTC2023 cases", fontsize=13)
    figure.tight_layout()
    args.output.resolve().parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(args.output.resolve(), dpi=165)
    plt.close(figure)
    print(args.output.resolve())


if __name__ == "__main__":
    main()
