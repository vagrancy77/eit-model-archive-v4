"""Evaluate a bank-preserving, dual-gated cutout decoder for non-convex EIT.

The decoder separates two decisions that should not be conflated:

1. a minimum geodesic path changes a closed cavity into an open indentation;
2. two independently trained networks must agree before that path is widened.

Unlike the first pixelwise decoder, the learned field is projected only onto a
local corridor around the mouth path.  It cannot grow around the full cavity
boundary, which was the main source of lesion-bank erosion in v2.  All decoder
thresholds are selected on synthetic validation data.  The independent stress
test, 21 public KTC2023 cases, and four ABC2 cases are evaluated only after the
policy is frozen.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from scipy.ndimage import distance_transform_edt, label as connected_components

from fuse_ktc_joint_shape_models import blend, load_model
from prepare_ktc_deep_concavity_stress import FAMILIES
from train_ktc_candidate_opening_refiner import (
    CandidateActionNet,
    inference_records as action_inference_records,
    paired_bootstrap,
    score_actions,
)
from train_ktc_concavity_network import InputAdapter
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_connected_cutout_refiner_v2 import (
    ConnectedCutoutNet,
    decode as pixel_decode,
    infer_pair,
    inference_records as pixel_inference_records,
    score_records as score_pixel_records,
)
from train_ktc_highres_refiner import load_dip_four_case_predictions, load_official_four_case_truths
from train_ktc_implicit_boolean_network import standard_metrics, stress_metrics


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    parser.add_argument("--action-checkpoint", type=Path, default=Path("E:/Codex/ktc_candidate_opening_seed20260820/best.pt"))
    parser.add_argument("--pixel-checkpoint", type=Path, default=Path("E:/Codex/ktc_connected_cutout_refiner_v2_seed20260820/best.pt"))
    parser.add_argument("--pixel-v2-archive", type=Path, default=Path("E:/Codex/ktc_connected_cutout_refiner_v2_seed20260820/predictions.npz"))
    parser.add_argument("--conservative", type=Path, default=Path("E:/Codex/ktc_joint_shape_pretrained_seed20260820/best.pt"))
    parser.add_argument("--aggressive", type=Path, default=Path("E:/Codex/ktc_joint_shape_network_seed20260820/best.pt"))
    parser.add_argument("--output-dir", type=Path, default=Path("E:/Codex/ktc_dual_gated_cutout_seed20260820"))
    parser.add_argument("--batch-size", type=int, default=48)
    parser.add_argument("--seed", type=int, default=20260820)
    return parser.parse_args()


def group_action_records(records: list[dict[str, object]]) -> dict[tuple[int, int], list[dict[str, object]]]:
    grouped: dict[tuple[int, int], list[dict[str, object]]] = {}
    for record in records:
        key = (int(record["sample"]), int(record["candidate"]))
        grouped.setdefault(key, []).append(record)
    return grouped


def decode_dual(
    raw: np.ndarray,
    pixel_records: list[dict[str, object]],
    action_records: list[dict[str, object]],
    policy: dict[str, object],
) -> tuple[np.ndarray, list[dict[str, object]]]:
    """Always open the minimum path; widen it only under dual agreement."""
    output = raw.copy()
    grouped_actions = group_action_records(action_records)
    accepted: list[dict[str, object]] = []
    widening_enabled = bool(policy.get("widening", True))

    for record in pixel_records:
        sample = int(record["sample"])
        candidate_id = int(record["candidate"])
        candidate = record["candidate_object"]
        foreground = output[sample] != 0
        path = candidate.path & foreground
        removal = path.copy()
        chosen_action: dict[str, object] | None = None

        if widening_enabled and float(record["accept_probability"]) >= float(policy["pixel_accept_threshold"]):
            options = grouped_actions.get((sample, candidate_id), [])
            viable = [
                option for option in options
                if float(option["probability"]) >= float(policy["action_threshold"])
                and float(option["predicted_utility"]) > float(policy["utility_threshold"])
            ]
            if viable:
                chosen_action = max(
                    viable,
                    key=lambda option: (
                        float(option["probability"])
                        + 0.20 * float(option["predicted_utility"])
                        + 0.06 * float(option["radius"]) / 3.0
                    ),
                )
                radius = min(int(chosen_action["radius"]), int(policy["max_radius"]))
                if radius > 0:
                    probability = np.asarray(record["probability"], dtype=np.float32)
                    channels = np.asarray(record["channels"], dtype=np.float32)
                    background_evidence = 0.35 * channels[2] + 0.65 * channels[3]
                    path_distance = distance_transform_edt(~candidate.path)
                    learned = (
                        (probability >= float(policy["pixel_threshold"]))
                        & (background_evidence >= float(policy["background_threshold"]))
                        & (path_distance <= radius)
                        & np.asarray(record["domain"], dtype=bool)
                        & foreground
                    )
                    # Keep only learned pixels connected to the mouth path.
                    proposal = candidate.path | learned
                    components, _ = connected_components(proposal, structure=np.ones((3, 3), dtype=np.uint8))
                    path_ids = np.unique(components[candidate.path])
                    path_ids = path_ids[path_ids != 0]
                    removal |= np.isin(components, path_ids) & foreground

        if removal.any():
            output[sample][removal] = 0
            accepted.append({
                "sample": sample,
                "candidate": candidate_id,
                "path_pixels": int(path.sum()),
                "removed_pixels": int(removal.sum()),
                "widened_pixels": int(removal.sum() - path.sum()),
                "pixel_accept_probability": float(record["accept_probability"]),
                "action_probability": None if chosen_action is None else float(chosen_action["probability"]),
                "predicted_utility": None if chosen_action is None else float(chosen_action["predicted_utility"]),
                "action_radius": None if chosen_action is None else int(chosen_action["radius"]),
            })
    return output, accepted


def path_anchor_policy() -> dict[str, object]:
    return {
        "widening": False,
        "action_threshold": 1.01,
        "utility_threshold": 1.01,
        "pixel_accept_threshold": 1.01,
        "pixel_threshold": 1.01,
        "background_threshold": 1.01,
        "max_radius": 0,
    }


def select_policy(
    base_raw: np.ndarray,
    stress_raw: np.ndarray,
    base_pixel_records: list[dict[str, object]],
    stress_pixel_records: list[dict[str, object]],
    base_action_records: list[dict[str, object]],
    stress_action_records: list[dict[str, object]],
    base_truth: np.ndarray,
    base_indent: np.ndarray,
    stress_truth: np.ndarray,
    stress_cutout: np.ndarray,
    stress_depth: np.ndarray,
    stress_family: np.ndarray,
) -> tuple[dict[str, object], list[dict[str, object]]]:
    anchor = path_anchor_policy()
    base_anchor, _ = decode_dual(base_raw, base_pixel_records, base_action_records, anchor)
    stress_anchor, _ = decode_dual(stress_raw, stress_pixel_records, stress_action_records, anchor)
    base_anchor_metric = standard_metrics(base_truth, base_anchor, base_indent)
    stress_anchor_metric, _, _ = stress_metrics(
        stress_truth, stress_anchor, stress_cutout, stress_depth, stress_family
    )

    rows: list[dict[str, object]] = []

    def add_row(policy: dict[str, object]) -> None:
        base_prediction, base_actions = decode_dual(base_raw, base_pixel_records, base_action_records, policy)
        stress_prediction, stress_actions = decode_dual(stress_raw, stress_pixel_records, stress_action_records, policy)
        base_metric = standard_metrics(base_truth, base_prediction, base_indent)
        stress_metric, _, _ = stress_metrics(
            stress_truth, stress_prediction, stress_cutout, stress_depth, stress_family
        )
        eligible = (
            base_metric["foreground_iou"] >= base_anchor_metric["foreground_iou"] - 0.0010
            and stress_metric["foreground_iou"] >= stress_anchor_metric["foreground_iou"] - 0.0025
            and stress_metric["bank_retention"] >= stress_anchor_metric["bank_retention"] - 0.0100
            and stress_metric["open_deep_cutout_recovery"] >= stress_anchor_metric["open_deep_cutout_recovery"] - 0.0020
            and stress_metric["topology_structural_joint"] >= stress_anchor_metric["topology_structural_joint"] - 0.0030
        )
        score = (
            0.10 * base_metric["foreground_iou"]
            + 0.16 * stress_metric["foreground_iou"]
            + 0.30 * stress_metric["open_deep_cutout_recovery"]
            + 0.20 * stress_metric["bank_retention"]
            + 0.24 * stress_metric["topology_structural_joint"]
        )
        rows.append({
            **policy,
            "eligible": bool(eligible),
            "score": float(score),
            "base_actions": len(base_actions),
            "stress_actions": len(stress_actions),
            "base_widened_pixels": int(sum(int(row["widened_pixels"]) for row in base_actions)),
            "stress_widened_pixels": int(sum(int(row["widened_pixels"]) for row in stress_actions)),
            "base": base_metric,
            "stress": stress_metric,
        })

    add_row(anchor)
    for action_threshold in (0.20, 0.35, 0.50, 0.65):
        for utility_threshold in (-0.10, 0.00, 0.15):
            for pixel_accept_threshold in (0.20, 0.40, 0.60):
                for pixel_threshold in (0.50, 0.65, 0.80):
                    for background_threshold in (0.05, 0.10, 0.20, 0.30):
                        add_row({
                            "widening": True,
                            "action_threshold": action_threshold,
                            "utility_threshold": utility_threshold,
                            "pixel_accept_threshold": pixel_accept_threshold,
                            "pixel_threshold": pixel_threshold,
                            "background_threshold": background_threshold,
                            "max_radius": 3,
                        })

    eligible = [row for row in rows if row["eligible"]]
    selected = max(eligible or rows, key=lambda row: float(row["score"]))
    return selected, rows


def save_comparison_grid(
    path: Path,
    truth: np.ndarray,
    raw: np.ndarray,
    path_prediction: np.ndarray,
    pixel_prediction: np.ndarray,
    dual_prediction: np.ndarray,
    indices: np.ndarray,
    labels: list[str],
) -> None:
    if len(indices) == 0:
        return
    columns = (truth, raw, path_prediction, pixel_prediction, dual_prediction)
    titles = ("truth", "raw fusion", "path anchor", "pixel v2", "dual-gated")
    figure, axes = plt.subplots(len(indices), len(columns), figsize=(12.5, 2.55 * len(indices)), squeeze=False)
    for row, index in enumerate(indices):
        for column, (array, title) in enumerate(zip(columns, titles)):
            axes[row, column].imshow(array[index], vmin=0, vmax=2)
            axes[row, column].set_axis_off()
            if row == 0:
                axes[row, column].set_title(title)
        axes[row, 0].set_ylabel(labels[row], fontsize=8)
    figure.tight_layout()
    figure.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(figure)


def score_models(
    truth: np.ndarray,
    raw: np.ndarray,
    path_prediction: np.ndarray,
    pixel_prediction: np.ndarray,
    dual_prediction: np.ndarray,
    cutout: np.ndarray,
    depth: np.ndarray,
    family: np.ndarray,
) -> tuple[dict[str, dict[str, float]], dict[str, list[dict[str, float]]], dict[str, dict[str, dict[str, float]]]]:
    summaries: dict[str, dict[str, float]] = {}
    rows: dict[str, list[dict[str, float]]] = {}
    families: dict[str, dict[str, dict[str, float]]] = {}
    for name, prediction in (
        ("raw_fusion", raw),
        ("path_anchor", path_prediction),
        ("pixel_v2", pixel_prediction),
        ("dual_gated", dual_prediction),
    ):
        summaries[name], family_summary, case_rows = stress_metrics(truth, prediction, cutout, depth, family)
        rows[name] = case_rows
        families[name] = family_summary
    return summaries, rows, families


def main() -> None:
    args = parse_args()
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    base = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    adapter = InputAdapter(base["fov_mask"]).to(device)
    conservative_model = load_model(args.conservative, device)
    aggressive_model = load_model(args.aggressive, device)

    action_state = torch.load(args.action_checkpoint.resolve(), map_location=device, weights_only=False)
    action_model = CandidateActionNet().to(device)
    action_model.load_state_dict(action_state["model"])
    action_mean = np.asarray(action_state["feature_mean"])
    action_scale = np.asarray(action_state["feature_scale"])

    pixel_state = torch.load(args.pixel_checkpoint.resolve(), map_location=device, weights_only=False)
    pixel_model = ConnectedCutoutNet().to(device)
    pixel_model.load_state_dict(pixel_state["model"])
    pixel_mean = np.asarray(pixel_state["feature_mean"])
    pixel_scale = np.asarray(pixel_state["feature_scale"])

    def prepare(images: np.ndarray, voltages: np.ndarray, size: int = 64):
        conservative, aggressive = infer_pair(
            conservative_model, aggressive_model, adapter, images, voltages, device, args.batch_size, size
        )
        raw = blend(conservative, aggressive, 0.5)
        pixels = pixel_inference_records(images, raw, conservative, aggressive)
        actions = action_inference_records(images, raw, conservative, aggressive)
        score_pixel_records(pixel_model, pixels, pixel_mean, pixel_scale, device, args.batch_size)
        score_actions(action_model, actions, action_mean, action_scale, device)
        return conservative, aggressive, raw, pixels, actions

    # Validation-only decoder selection.
    bi = np.asarray(base["validation_indices"])
    si = np.asarray(stress["validation_indices"])
    _, _, base_validation_raw, base_validation_pixels, base_validation_actions = prepare(
        base["linear_images"][bi], base["voltages"][bi]
    )
    _, _, stress_validation_raw, stress_validation_pixels, stress_validation_actions = prepare(
        stress["linear_images"][si], stress["voltages"][si]
    )
    selected, validation_rows = select_policy(
        base_validation_raw, stress_validation_raw,
        base_validation_pixels, stress_validation_pixels,
        base_validation_actions, stress_validation_actions,
        base["labels"][bi], base["indentation_masks"][bi],
        stress["labels"][si], stress["cutout_masks"][si],
        stress["cutout_depth_weights"][si], stress["family_codes"][si],
    )
    (out / "validation_grid.json").write_text(json.dumps(validation_rows, indent=2), encoding="utf-8")
    print("selected validation policy", flush=True)
    print(json.dumps(selected, indent=2), flush=True)

    # Independent synthetic test.
    bi = np.asarray(base["test_indices"])
    si = np.asarray(stress["test_indices"])
    _, _, base_raw, base_pixels, base_actions = prepare(base["linear_images"][bi], base["voltages"][bi])
    _, _, stress_raw, stress_pixels, stress_actions = prepare(stress["linear_images"][si], stress["voltages"][si])
    base_path, base_path_actions = decode_dual(base_raw, base_pixels, base_actions, path_anchor_policy())
    stress_path, stress_path_actions = decode_dual(stress_raw, stress_pixels, stress_actions, path_anchor_policy())
    base_dual, accepted_base = decode_dual(base_raw, base_pixels, base_actions, selected)
    stress_dual, accepted_stress = decode_dual(stress_raw, stress_pixels, stress_actions, selected)

    pixel_archive = np.load(args.pixel_v2_archive.resolve(), allow_pickle=False)
    stress_pixel = np.asarray(pixel_archive["stress"])
    base_pixel = np.asarray(pixel_archive["base"])
    stress_summaries, stress_rows, family_summaries = score_models(
        stress["labels"][si], stress_raw, stress_path, stress_pixel, stress_dual,
        stress["cutout_masks"][si], stress["cutout_depth_weights"][si], stress["family_codes"][si],
    )
    base_metrics = {
        "raw_fusion": standard_metrics(base["labels"][bi], base_raw, base["indentation_masks"][bi]),
        "path_anchor": standard_metrics(base["labels"][bi], base_path, base["indentation_masks"][bi]),
        "pixel_v2": standard_metrics(base["labels"][bi], base_pixel, base["indentation_masks"][bi]),
        "dual_gated": standard_metrics(base["labels"][bi], base_dual, base["indentation_masks"][bi]),
    }
    bootstrap = paired_bootstrap(stress_rows["raw_fusion"], stress_rows["dual_gated"], 10000, args.seed)

    # The 21 public KTC2023 cases are evaluated at native resolution after
    # projecting the validated 64 x 64 removal decision.
    _, _, real_raw64, real_pixels, real_actions = prepare(base["real_linear_images"], base["real_voltages"], 64)
    real_path64, _ = decode_dual(real_raw64, real_pixels, real_actions, path_anchor_policy())
    real_dual64, accepted_real = decode_dual(real_raw64, real_pixels, real_actions, selected)
    rc256, ra256 = infer_pair(
        conservative_model, aggressive_model, adapter,
        base["real_linear_images"], base["real_voltages"], device, args.batch_size, 256,
    )
    real_raw = blend(rc256, ra256, 0.5)
    real_path = real_raw.copy()
    real_dual = real_raw.copy()
    real_path[np.repeat(np.repeat(real_raw64 != real_path64, 4, axis=1), 4, axis=2)] = 0
    real_dual[np.repeat(np.repeat(real_raw64 != real_dual64, 4, axis=1), 4, axis=2)] = 0
    real_pixel = np.asarray(pixel_archive["real"])
    real_metrics: dict[str, dict[str, float]] = {}
    real_rows: dict[str, list[dict[str, object]]] = {}
    for name, prediction in (
        ("raw_fusion", real_raw), ("path_anchor", real_path),
        ("pixel_v2", real_pixel), ("dual_gated", real_dual),
    ):
        real_metrics[name], real_rows[name] = evaluate_real_predictions(
            name, prediction, base["real_labels"], base["real_ids"]
        )

    # Four original ABC2 cases remain calibration diagnostics only.
    _, _, calibration_raw64, calibration_pixels, calibration_actions = prepare(
        base["calibration_linear_images"], base["calibration_voltages"]
    )
    calibration_path64, _ = decode_dual(
        calibration_raw64, calibration_pixels, calibration_actions, path_anchor_policy()
    )
    calibration_dual64, accepted_calibration = decode_dual(
        calibration_raw64, calibration_pixels, calibration_actions, selected
    )
    official_truth, official_ids = load_official_four_case_truths(
        Path(__file__).resolve().parents[1] / "external" / "KTC2023-ABC2"
    )
    official_raw = np.repeat(np.repeat(calibration_raw64, 4, axis=1), 4, axis=2)
    official_path = np.repeat(np.repeat(calibration_path64, 4, axis=1), 4, axis=2)
    official_dual = np.repeat(np.repeat(calibration_dual64, 4, axis=1), 4, axis=2)
    official_pixel = np.asarray(pixel_archive["calibration"])
    official_summaries: dict[str, dict[str, float]] = {}
    official_rows: list[dict[str, object]] = []
    for name, prediction in (
        ("DIP_TV", load_dip_four_case_predictions(Path(__file__).resolve().parents[1])),
        ("raw_fusion", official_raw), ("path_anchor", official_path),
        ("pixel_v2", official_pixel), ("dual_gated", official_dual),
    ):
        official_summaries[name], rows = evaluate_real_predictions(name, prediction, official_truth, official_ids)
        official_rows.extend(rows)

    # Publication-style visual comparisons.
    changed = np.flatnonzero(np.any(stress_path != stress_dual, axis=(1, 2)))
    if len(changed):
        gains = np.asarray([
            stress_rows["dual_gated"][index]["topology_structural_joint"]
            - stress_rows["raw_fusion"][index]["topology_structural_joint"]
            for index in changed
        ])
        focus = changed[np.argsort(gains)[::-1][:min(20, len(changed))]]
        save_comparison_grid(
            out / "stress_changed_cases.png", stress["labels"][si], stress_raw, stress_path,
            stress_pixel, stress_dual, focus,
            [FAMILIES[int(stress["family_codes"][si][index])] for index in focus],
        )
    family_focus: list[int] = []
    for code in range(len(FAMILIES)):
        options = np.flatnonzero(stress["family_codes"][si] == code)
        family_focus.append(int(options[np.argmax(
            stress["cutout_depth_weights"][si][options].sum(axis=(1, 2))
        )]))
    save_comparison_grid(
        out / "stress_family_cases.png", stress["labels"][si], stress_raw, stress_path,
        stress_pixel, stress_dual, np.asarray(family_focus), list(FAMILIES),
    )
    worst = np.argsort([
        float(row["topology_structural_joint"]) for row in stress_rows["dual_gated"]
    ])[:16]
    save_comparison_grid(
        out / "stress_worst_cases.png", stress["labels"][si], stress_raw, stress_path,
        stress_pixel, stress_dual, worst,
        [FAMILIES[int(stress["family_codes"][si][index])] for index in worst],
    )
    real_changed = np.flatnonzero(np.any(real_raw != real_dual, axis=(1, 2)))
    if len(real_changed):
        save_comparison_grid(
            out / "real_changed_cases.png", base["real_labels"], real_raw, real_path,
            real_pixel, real_dual, real_changed,
            [str(base["real_ids"][index]) for index in real_changed],
        )
    save_comparison_grid(
        out / "official_four_cases.png", official_truth, official_raw, official_path,
        official_pixel, official_dual, np.arange(4), [str(item) for item in official_ids],
    )

    np.savez_compressed(
        out / "predictions.npz",
        base_raw=base_raw, base_path=base_path, base_pixel=base_pixel, base_dual=base_dual,
        stress_raw=stress_raw, stress_path=stress_path, stress_pixel=stress_pixel, stress_dual=stress_dual,
        real_raw=real_raw, real_path=real_path, real_pixel=real_pixel, real_dual=real_dual,
        calibration_raw=official_raw, calibration_path=official_path,
        calibration_pixel=official_pixel, calibration_dual=official_dual,
    )
    with (out / "stress_bootstrap.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(bootstrap[0]))
        writer.writeheader()
        writer.writerows(bootstrap)
    with (out / "official_four_metrics.csv").open("w", newline="", encoding="utf-8") as handle:
        fields = sorted({key for row in official_rows for key in row})
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(official_rows)

    result = {
        "method": "minimum-path topology opening plus dual-gated local learned widening",
        "geometric_fix": "pixel field is restricted to a mouth-path corridor and cannot erode the full cavity bank",
        "data_policy": "decoder selected on synthetic validation only; independent stress test, 21 KTC labels, and ABC2 cases held out",
        "selected": selected,
        "test": {
            "base": base_metrics,
            "stress": stress_summaries,
            "stress_by_family": family_summaries,
            "bootstrap_raw_to_dual": bootstrap,
            "real_21": real_metrics,
            "official_four": official_summaries,
            "actions": {
                "base_path_candidates": len(base_path_actions),
                "stress_path_candidates": len(stress_path_actions),
                "base_dual": accepted_base,
                "stress_dual": accepted_stress,
                "real_dual": accepted_real,
                "calibration_dual": accepted_calibration,
            },
        },
        "checkpoints": {
            "action": str(args.action_checkpoint.resolve()),
            "pixel": str(args.pixel_checkpoint.resolve()),
        },
        "evaluation_truth_used_for_selection": False,
    }
    (out / "summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result["test"], ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
