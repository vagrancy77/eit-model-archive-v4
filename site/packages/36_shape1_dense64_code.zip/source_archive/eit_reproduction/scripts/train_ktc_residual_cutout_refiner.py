"""Train a residual cutout locator for inward-concave EIT targets.

The stable conservative/aggressive fusion is frozen.  This network is not a
second semantic segmenter: it can only remove foreground pixels that the
frozen reconstruction already contains.  Separate removal and bank heads
learn which pixels close a true inward bay and which neighbouring lesion
pixels must survive.  At inference, a topology projection retains only
predicted removals connected to the exterior background.

Synthetic train/validation splits are used for fitting and decoder selection.
The synthetic test split, all 21 KTC2023 evaluation truths, and the four
official KTC training phantoms are opened only after the policy is frozen.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import random
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy.ndimage import binary_dilation, distance_transform_edt, label as connected_components
from torch.utils.data import ConcatDataset, DataLoader, Dataset

from evaluate_ktc_bank_guarded_wide_cutout import (
    CORE_FAMILY_CODES,
    PUBLIC_INWARD_BAY_IDS,
    core_metrics,
)
from fuse_ktc_joint_shape_models import load_model
from prepare_ktc_deep_concavity_stress import FAMILIES
from train_ktc_candidate_opening_refiner import paired_bootstrap
from train_ktc_concavity_network import (
    DecoderStage,
    InputAdapter,
    ResidualBlock,
    aggregate_rows,
)
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_implicit_boolean_network import (
    VoltageEncoder,
    balanced_bce,
    cutout_topology_loss,
    standard_metrics,
    stress_metrics,
)


INPUT_CHANNELS = 17


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    parser.add_argument("--conservative", type=Path, default=Path("E:/Codex/ktc_joint_shape_pretrained_seed20260820/best.pt"))
    parser.add_argument("--aggressive", type=Path, default=Path("E:/Codex/ktc_joint_shape_network_seed20260820/best.pt"))
    parser.add_argument(
        "--previous-predictions", type=Path,
        default=root / "outputs" / "ktc_bank_guarded_wide_cutout_seed20260820" / "predictions.npz",
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=root / "outputs" / "ktc_residual_cutout_refiner_seed20260820",
    )
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--patience", type=int, default=8)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--inference-batch-size", type=int, default=256)
    parser.add_argument("--base-channels", type=int, default=20)
    parser.add_argument("--learning-rate", type=float, default=1.2e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--stress-repeat", type=int, default=3)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--seed", type=int, default=20260820)
    parser.add_argument("--bootstrap-samples", type=int, default=10000)
    parser.add_argument(
        "--initial-checkpoint", type=Path, default=None,
        help="Checkpoint loaded by --evaluate-only; defaults to the output directory checkpoint.",
    )
    parser.add_argument(
        "--evaluate-only", action="store_true",
        help="Skip training, load --initial-checkpoint, and rerun decoder selection/evaluation.",
    )
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    keys = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def stable_probability(conservative: np.ndarray, aggressive: np.ndarray) -> np.ndarray:
    probability = 0.5 * (conservative.astype(np.float32) + aggressive.astype(np.float32))
    return probability / probability.sum(axis=1, keepdims=True).clip(min=1e-6)


def support_and_cutout(archive: np.lib.npyio.NpzFile, indices: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    truth_foreground = np.asarray(archive["labels"][indices] != 0)
    if "support_masks" in archive.files:
        support = np.asarray(archive["support_masks"][indices] != 0)
        cutout = np.asarray(archive["cutout_masks"][indices] != 0)
        depth = np.asarray(archive["cutout_depth_weights"][indices], dtype=np.float32)
    else:
        cutout = np.asarray(archive["indentation_masks"][indices] != 0)
        support = truth_foreground | cutout
        depth = np.zeros(cutout.shape, dtype=np.float32)
        for local in range(len(indices)):
            values = distance_transform_edt(cutout[local])
            depth[local] = values / max(float(values.max()), 1.0)
    return support, cutout, depth


def mouth_corridors(support: np.ndarray, cutout: np.ndarray) -> np.ndarray:
    result = np.zeros(cutout.shape, dtype=np.uint8)
    structure = np.ones((3, 3), dtype=bool)
    for index in range(len(cutout)):
        exterior_near = binary_dilation(~support[index], structure=structure, iterations=2)
        mouth = cutout[index] & exterior_near
        corridor = cutout[index] & binary_dilation(mouth, structure=structure, iterations=5)
        result[index] = corridor
    return result


class ResidualCutoutDataset(Dataset):
    def __init__(
        self,
        archive: np.lib.npyio.NpzFile,
        indices: np.ndarray,
        conservative: np.ndarray,
        aggressive: np.ndarray,
        source: int,
        training: bool,
        seed: int,
    ) -> None:
        self.archive = archive
        self.indices = np.asarray(indices, dtype=np.int64)
        self.conservative = np.asarray(conservative, dtype=np.float16)
        self.aggressive = np.asarray(aggressive, dtype=np.float16)
        self.source = source
        self.training = training
        self.seed = seed
        # NpzFile indexing decompresses a complete member.  Materialize each
        # selected split once instead of decompressing it in every __getitem__.
        self.images = np.asarray(archive["linear_images"][self.indices], dtype=np.float32)
        self.voltages = np.asarray(archive["voltages"][self.indices], dtype=np.float32)
        self.labels = np.asarray(archive["labels"][self.indices], dtype=np.uint8)
        self.support, self.cutout, self.depth = support_and_cutout(archive, self.indices)
        self.mouth = mouth_corridors(self.support, self.cutout)

    def __len__(self) -> int:
        return len(self.indices)

    @staticmethod
    def seal_probability(probability: np.ndarray, mask: np.ndarray, strength: float) -> np.ndarray:
        if not mask.any():
            return probability
        result = probability.copy()
        foreground_class = 1 + np.argmax(result[1:], axis=0)
        rows, columns = np.nonzero(mask)
        selected = foreground_class[rows, columns]
        result[:, rows, columns] *= 1.0 - strength
        result[0, rows, columns] = 0.035
        result[selected, rows, columns] += strength
        return result / result.sum(axis=0, keepdims=True).clip(min=1e-6)

    def __getitem__(self, item: int) -> dict[str, torch.Tensor]:
        index = int(self.indices[item])
        conservative = self.conservative[item].astype(np.float32)
        aggressive = self.aggressive[item].astype(np.float32)
        if self.training and self.cutout[item].any():
            # Deterministic per-worker randomness still changes across epochs
            # because the global RNG state advances with shuffled sampling.
            probability = 0.58 if self.source == 1 else 0.25
            if np.random.random() < probability:
                mask = self.mouth[item].astype(bool)
                strength = float(np.random.uniform(0.45, 0.72))
                conservative = self.seal_probability(conservative, mask, strength)
                aggressive = self.seal_probability(aggressive, mask, strength * 0.82)
        fusion = stable_probability(conservative[None], aggressive[None])[0]
        stable = fusion.argmax(axis=0)
        truth = self.labels[item].astype(np.int64)
        domain = stable != 0
        # This is an inward-concavity refiner, not a generic erosion model.
        # Exterior over-segmentation is therefore protected rather than used
        # as a positive removal target.
        remove = domain & (truth == 0) & self.cutout[item]
        bank = domain & ~remove
        exterior = exterior_background(domain)
        outer_bank = bank & binary_dilation(exterior, structure=np.ones((3, 3), dtype=bool))
        return {
            "image": torch.from_numpy(self.images[item][None]),
            "voltage": torch.from_numpy(self.voltages[item]),
            "conservative": torch.from_numpy(conservative),
            "aggressive": torch.from_numpy(aggressive),
            "domain": torch.from_numpy(domain.astype(np.float32)[None]),
            "remove": torch.from_numpy(remove.astype(np.float32)[None]),
            "bank": torch.from_numpy(bank.astype(np.float32)[None]),
            "outer_bank": torch.from_numpy(outer_bank.astype(np.float32)[None]),
            "cutout": torch.from_numpy(self.cutout[item].astype(np.float32)[None]),
            "depth": torch.from_numpy(self.depth[item].astype(np.float32)[None]),
            "mouth": torch.from_numpy(self.mouth[item].astype(np.float32)[None]),
            "source": torch.tensor(self.source, dtype=torch.int64),
            "index": torch.tensor(index, dtype=torch.int64),
        }


def assemble_features(adapted: torch.Tensor, conservative: torch.Tensor, aggressive: torch.Tensor) -> torch.Tensor:
    fusion = 0.5 * (conservative + aggressive)
    fusion = fusion / fusion.sum(dim=1, keepdim=True).clamp_min(1e-6)
    stable = F.one_hot(fusion.argmax(dim=1), num_classes=3).permute(0, 3, 1, 2).float()
    disagreement = (conservative - aggressive).abs().mean(dim=1, keepdim=True)
    entropy = -(fusion.clamp_min(1e-6) * fusion.clamp_min(1e-6).log()).sum(dim=1, keepdim=True) / math.log(3.0)
    return torch.cat((adapted, conservative, aggressive, fusion, stable, disagreement, entropy), dim=1)


class ResidualCutoutRefiner(nn.Module):
    def __init__(self, base: int) -> None:
        super().__init__()
        self.stem = ResidualBlock(INPUT_CHANNELS, base)
        self.enc1 = ResidualBlock(base, base * 2)
        self.enc2 = ResidualBlock(base * 2, base * 4)
        self.enc3 = ResidualBlock(base * 4, base * 8)
        self.bottleneck = nn.Sequential(
            ResidualBlock(base * 8, base * 16), nn.Dropout2d(0.10), ResidualBlock(base * 16, base * 16)
        )
        self.voltage = VoltageEncoder(base)
        self.voltage_gate = nn.Parameter(torch.tensor(-1.5))
        self.dec3 = DecoderStage(base * 16, base * 8, base * 8)
        self.dec2 = DecoderStage(base * 8, base * 4, base * 4)
        self.dec1 = DecoderStage(base * 4, base * 2, base * 2)
        self.dec0 = DecoderStage(base * 2, base, base)
        self.removal = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))
        self.bank = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))
        nn.init.zeros_(self.removal[-1].weight)
        nn.init.constant_(self.removal[-1].bias, -2.8)
        nn.init.zeros_(self.bank[-1].weight)
        nn.init.constant_(self.bank[-1].bias, 2.2)

    def forward(self, features: torch.Tensor, voltage: torch.Tensor) -> dict[str, torch.Tensor]:
        e0 = self.stem(features)
        e1 = self.enc1(F.max_pool2d(e0, 2))
        e2 = self.enc2(F.max_pool2d(e1, 2))
        e3 = self.enc3(F.max_pool2d(e2, 2))
        middle = self.bottleneck(F.max_pool2d(e3, 2))
        middle = middle + torch.sigmoid(self.voltage_gate) * self.voltage(voltage)
        d3 = self.dec3(middle, e3)
        d2 = self.dec2(d3, e2)
        d1 = self.dec1(d2, e1)
        fine = self.dec0(d1, e0)
        removal_logit = self.removal(fine)
        bank_logit = self.bank(fine)
        return {
            "removal_logit": removal_logit,
            "bank_logit": bank_logit,
            "removal_probability": torch.sigmoid(removal_logit),
            "bank_probability": torch.sigmoid(bank_logit),
        }


def masked_mean(value: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    numerator = (value * mask).sum(dim=(1, 2, 3))
    denominator = mask.sum(dim=(1, 2, 3))
    valid = denominator > 0
    return (numerator / denominator.clamp_min(1.0))[valid].mean() if valid.any() else value.new_zeros(())


def refiner_loss(output: dict[str, torch.Tensor], batch: dict[str, torch.Tensor]) -> tuple[torch.Tensor, dict[str, float]]:
    domain = batch["domain"]
    remove = batch["remove"]
    bank = batch["bank"]
    positive_weight = 1.0 + 3.0 * batch["depth"] + 1.5 * batch["mouth"]
    removal_loss = balanced_bce(output["removal_logit"], remove, domain, positive_weight)
    bank_loss = balanced_bce(output["bank_logit"], bank, domain)
    probability = output["removal_probability"] * domain
    bank_probability = output["bank_probability"] * domain
    false_cut = masked_mean(probability, bank)
    outer_false_cut = masked_mean(F.softplus(output["removal_logit"]), batch["outer_bank"])
    outer_bank_loss = masked_mean(F.softplus(-output["bank_logit"]), batch["outer_bank"])
    missed_cut = masked_mean(1.0 - probability, remove * positive_weight)
    overlap = masked_mean(probability * bank_probability, domain)
    topology = cutout_topology_loss(probability, remove, domain, 8)
    pred_dy = probability[:, :, 1:] - probability[:, :, :-1]
    pred_dx = probability[:, :, :, 1:] - probability[:, :, :, :-1]
    true_dy = remove[:, :, 1:] - remove[:, :, :-1]
    true_dx = remove[:, :, :, 1:] - remove[:, :, :, :-1]
    boundary = F.l1_loss(pred_dy, true_dy) + F.l1_loss(pred_dx, true_dx)
    total = (
        removal_loss + 0.48 * bank_loss + 2.60 * false_cut + 1.80 * outer_false_cut
        + 0.65 * outer_bank_loss + 0.35 * missed_cut + 0.14 * overlap
        + 0.20 * topology + 0.12 * boundary
    )
    pieces = {
        "total": total, "removal": removal_loss, "bank": bank_loss,
        "false_cut": false_cut, "outer_false_cut": outer_false_cut,
        "outer_bank": outer_bank_loss, "missed_cut": missed_cut,
        "overlap": overlap, "topology": topology, "boundary": boundary,
    }
    return total, {key: float(value.detach()) for key, value in pieces.items()}


@torch.no_grad()
def infer_fields(
    model: ResidualCutoutRefiner,
    adapter: InputAdapter,
    images: np.ndarray,
    voltages: np.ndarray,
    conservative: np.ndarray,
    aggressive: np.ndarray,
    device: torch.device,
    batch_size: int,
    target_size: int = 64,
) -> tuple[np.ndarray, np.ndarray]:
    model.eval()
    removal: list[np.ndarray] = []
    bank: list[np.ndarray] = []
    for start in range(0, len(images), batch_size):
        stop = start + batch_size
        image = torch.from_numpy(np.asarray(images[start:stop, None], dtype=np.float32)).to(device)
        voltage = torch.from_numpy(np.asarray(voltages[start:stop], dtype=np.float32)).to(device)
        conservative_tensor = torch.from_numpy(np.asarray(conservative[start:stop], dtype=np.float32)).to(device)
        aggressive_tensor = torch.from_numpy(np.asarray(aggressive[start:stop], dtype=np.float32)).to(device)
        features = assemble_features(adapter(image), conservative_tensor, aggressive_tensor)
        output = model(features, voltage)
        removal_logit = output["removal_logit"]
        bank_logit = output["bank_logit"]
        if target_size != removal_logit.shape[-1]:
            removal_logit = F.interpolate(removal_logit, size=(target_size, target_size), mode="bilinear", align_corners=False)
            bank_logit = F.interpolate(bank_logit, size=(target_size, target_size), mode="bilinear", align_corners=False)
        removal.append(torch.sigmoid(removal_logit).cpu().numpy()[:, 0])
        bank.append(torch.sigmoid(bank_logit).cpu().numpy()[:, 0])
    return np.concatenate(removal), np.concatenate(bank)


@torch.no_grad()
def validation_field_metrics(
    model: ResidualCutoutRefiner,
    adapter: InputAdapter,
    loader: DataLoader,
    device: torch.device,
) -> dict[str, float]:
    model.eval()
    positive_rows: list[dict[str, float]] = []
    false_fractions: list[float] = []
    outer_false_fractions: list[float] = []
    for batch in loader:
        moved = {key: value.to(device) for key, value in batch.items()}
        features = assemble_features(
            adapter(moved["image"]), moved["conservative"], moved["aggressive"]
        )
        output = model(features, moved["voltage"])
        probability = output["removal_probability"] * moved["domain"]
        predicted = probability >= 0.5
        target = moved["remove"] > 0.5
        domain = moved["domain"] > 0.5
        outer_bank = moved["outer_bank"] > 0.5
        for p, t, d, outer in zip(predicted[:, 0], target[:, 0], domain[:, 0], outer_bank[:, 0]):
            true_positive = float((p & t).sum())
            false_fraction = float((p & ~t & d).sum()) / max(1.0, float((~t & d).sum()))
            false_fractions.append(false_fraction)
            outer_false_fractions.append(float((p & outer).sum()) / max(1.0, float(outer.sum())))
            if bool(t.any()):
                precision = (true_positive + 1.0) / (float(p.sum()) + 1.0)
                recall = (true_positive + 1.0) / (float(t.sum()) + 1.0)
                dice = (2.0 * true_positive + 1.0) / (float(p.sum()) + float(t.sum()) + 1.0)
                positive_rows.append({"precision": precision, "recall": recall, "dice": dice})
    result = aggregate_rows(positive_rows) if positive_rows else {"precision": 0.0, "recall": 0.0, "dice": 0.0}
    result["false_fraction"] = float(np.mean(false_fractions)) if false_fractions else 0.0
    result["outer_false_fraction"] = float(np.mean(outer_false_fractions)) if outer_false_fractions else 0.0
    result["positive_cases"] = float(len(positive_rows))
    return result


@dataclass(frozen=True)
class DecoderPolicy:
    high_threshold: float
    low_threshold: float
    bank_threshold: float
    minimum_depth: int
    minimum_component: int


def exterior_background(foreground: np.ndarray) -> np.ndarray:
    components, _ = connected_components(~foreground, structure=np.ones((3, 3), dtype=np.uint8))
    border = np.unique(np.concatenate((components[0], components[-1], components[:, 0], components[:, -1])))
    return np.isin(components, border[border != 0])


def decode_one(
    stable: np.ndarray,
    removal_probability: np.ndarray,
    bank_probability: np.ndarray,
    policy: DecoderPolicy,
    scale: int = 1,
) -> tuple[np.ndarray, np.ndarray]:
    foreground = stable != 0
    if policy.high_threshold > 1.0:
        return stable.copy(), np.zeros_like(foreground)
    low = (
        foreground & (removal_probability >= policy.low_threshold)
        & (bank_probability <= policy.bank_threshold)
    )
    high = (
        foreground & (removal_probability >= policy.high_threshold)
        & (bank_probability <= policy.bank_threshold)
    )
    exterior = exterior_background(foreground)
    depth = distance_transform_edt(foreground)
    components, count = connected_components(low, structure=np.ones((3, 3), dtype=np.uint8))
    removal = np.zeros_like(foreground)
    structure = np.ones((3, 3), dtype=bool)
    for component in range(1, count + 1):
        region = components == component
        if int(region.sum()) < policy.minimum_component * scale * scale:
            continue
        if not np.any(region & high):
            continue
        if float(depth[region].max(initial=0.0)) < policy.minimum_depth * scale:
            continue
        if not np.any(binary_dilation(region, structure=structure) & exterior):
            continue
        removal |= region
    output = stable.copy()
    output[removal] = 0
    return output, removal


def decode_batch(
    stable: np.ndarray,
    removal_probability: np.ndarray,
    bank_probability: np.ndarray,
    policy: DecoderPolicy,
    scale: int = 1,
) -> tuple[np.ndarray, np.ndarray]:
    decoded = []
    removals = []
    for label, removal, bank in zip(stable, removal_probability, bank_probability):
        prediction, mask = decode_one(label, removal, bank, policy, scale)
        decoded.append(prediction)
        removals.append(mask)
    return np.stack(decoded), np.stack(removals)


def select_decoder(
    base: np.lib.npyio.NpzFile,
    stress: np.lib.npyio.NpzFile,
    base_indices: np.ndarray,
    stress_indices: np.ndarray,
    base_stable: np.ndarray,
    stress_stable: np.ndarray,
    base_removal: np.ndarray,
    base_bank: np.ndarray,
    stress_removal: np.ndarray,
    stress_bank: np.ndarray,
) -> tuple[dict[str, object], list[dict[str, object]]]:
    base_reference = standard_metrics(base["labels"][base_indices], base_stable, base["indentation_masks"][base_indices])
    core_reference, _ = core_metrics(stress, stress_indices, stress_stable)
    policies = [DecoderPolicy(1.01, 1.01, 0.0, 0, 1)]
    for high in (0.90, 0.95, 0.975, 0.99, 0.995):
        for low_offset in (0.00, 0.01, 0.03, 0.05):
            for bank_threshold in (0.05, 0.10, 0.20, 0.35):
                for minimum_depth in (0, 1, 2, 3):
                    for minimum_component in (2, 4, 8, 16):
                        policies.append(DecoderPolicy(high, max(0.0, high - low_offset), bank_threshold, minimum_depth, minimum_component))
    rows: list[dict[str, object]] = []
    for policy in policies:
        base_prediction, base_removed = decode_batch(base_stable, base_removal, base_bank, policy)
        stress_prediction, stress_removed = decode_batch(stress_stable, stress_removal, stress_bank, policy)
        base_metric = standard_metrics(base["labels"][base_indices], base_prediction, base["indentation_masks"][base_indices])
        core_metric, _ = core_metrics(stress, stress_indices, stress_prediction)
        eligible = (
            base_metric["foreground_iou"] >= base_reference["foreground_iou"] - 0.006
            and base_metric["boundary_f1"] >= base_reference["boundary_f1"] - 0.008
            and core_metric["foreground_iou"] >= core_reference["foreground_iou"] - 0.010
            and core_metric["bank_retention"] >= core_reference["bank_retention"] - 0.012
        )
        score = (
            0.08 * base_metric["foreground_iou"] + 0.12 * core_metric["foreground_iou"]
            + 0.35 * core_metric["open_deep_cutout_recovery"] + 0.20 * core_metric["bank_retention"]
            + 0.25 * core_metric["topology_structural_joint"]
        )
        rows.append({
            **policy.__dict__, "eligible": bool(eligible), "score": float(score),
            "base_removed_pixels": int(base_removed.sum()), "stress_removed_pixels": int(stress_removed.sum()),
            "base": base_metric, "core": core_metric,
        })
    eligible = [row for row in rows if row["eligible"]]
    selected = max(eligible or rows, key=lambda row: float(row["score"]))
    return selected, rows


def policy_from_record(record: dict[str, object]) -> DecoderPolicy:
    return DecoderPolicy(
        float(record["high_threshold"]), float(record["low_threshold"]),
        float(record["bank_threshold"]), int(record["minimum_depth"]),
        int(record["minimum_component"]),
    )


def probability_quantiles(values: np.ndarray, mask: np.ndarray) -> dict[str, float | int]:
    selected = np.asarray(values, dtype=np.float32)[np.asarray(mask, dtype=bool)]
    if selected.size == 0:
        return {"count": 0}
    levels = (0.0, 0.25, 0.50, 0.75, 0.90, 0.95, 0.975, 0.99, 0.995, 1.0)
    quantiles = np.quantile(selected, levels)
    result: dict[str, float | int] = {
        "count": int(selected.size),
        "mean": float(selected.mean()),
    }
    for level, value in zip(levels, quantiles):
        result[f"q{level:g}"] = float(value)
    return result


def probability_diagnostics(
    labels: np.ndarray,
    stable: np.ndarray,
    removal_probability: np.ndarray,
    bank_probability: np.ndarray,
    cutout: np.ndarray,
    depth_weight: np.ndarray | None = None,
) -> dict[str, object]:
    foreground = stable != 0
    truth_foreground = labels != 0
    false_foreground = foreground & ~truth_foreground
    cutout_removal = false_foreground & (cutout != 0)
    noncutout_false_foreground = false_foreground & (cutout == 0)
    protected_foreground = foreground & ~cutout_removal
    if depth_weight is None:
        deep_cutout_removal = cutout_removal
    else:
        deep_cutout_removal = cutout_removal & (depth_weight >= 0.50)
    outer_boundary = np.zeros_like(protected_foreground)
    structure = np.ones((3, 3), dtype=bool)
    for index, stable_foreground in enumerate(foreground):
        exterior = exterior_background(stable_foreground)
        outer_boundary[index] = protected_foreground[index] & binary_dilation(exterior, structure=structure)
    categories = {
        "target_cutout_removal": cutout_removal,
        "deep_cutout_true_removal": deep_cutout_removal,
        "protected_foreground": protected_foreground,
        "noncutout_false_foreground": noncutout_false_foreground,
        "outer_boundary_protected": outer_boundary,
    }
    return {
        "definitions": {
            "target_cutout_removal": "stable foreground incorrectly filling the known inward-cutout region",
            "deep_cutout_true_removal": "cutout true removal with normalized cutout depth >= 0.5",
            "protected_foreground": "all stable foreground outside the target inward-cutout correction",
            "noncutout_false_foreground": "external over-segmentation deliberately outside this refiner's scope",
            "outer_boundary_protected": "protected foreground touching the exterior background of the stable reconstruction",
        },
        "removal_probability": {
            name: probability_quantiles(removal_probability, mask) for name, mask in categories.items()
        },
        "bank_probability": {
            name: probability_quantiles(bank_probability, mask) for name, mask in categories.items()
        },
    }


def save_training_curve(path: Path, history: list[dict[str, float]]) -> None:
    figure, axes = plt.subplots(1, 2, figsize=(9.0, 3.4))
    epoch = [row["epoch"] for row in history]
    axes[0].plot(epoch, [row["train_loss"] for row in history], label="train loss")
    axes[0].set_xlabel("epoch"); axes[0].legend()
    for key in ("dice", "precision", "recall"):
        axes[1].plot(epoch, [row[key] for row in history], label=key)
    axes[1].set_xlabel("epoch"); axes[1].set_ylim(0, 1); axes[1].legend()
    figure.tight_layout(); figure.savefig(path, dpi=180); plt.close(figure)


def save_stress_grid(
    path: Path,
    stress: np.lib.npyio.NpzFile,
    indices: np.ndarray,
    stable: np.ndarray,
    guarded: np.ndarray,
    refined: np.ndarray,
    removal_probability: np.ndarray,
    bank_probability: np.ndarray,
) -> None:
    family_codes = stress["family_codes"][indices]
    focus: list[int] = []
    for code in CORE_FAMILY_CODES:
        candidates = np.flatnonzero(family_codes == code)
        weights = stress["cutout_depth_weights"][indices][candidates].sum(axis=(1, 2))
        focus.append(int(candidates[int(np.argmax(weights))]))
    figure, axes = plt.subplots(len(focus), 7, figsize=(16.2, 2.25 * len(focus)), squeeze=False)
    titles = ("truth", "stable", "guarded path", "removal p", "bank p", "residual", "removed")
    for row, index in enumerate(focus):
        removed = (stable[index] != refined[index]).astype(np.float32)
        images = (
            stress["labels"][indices][index], stable[index], guarded[index],
            removal_probability[index], bank_probability[index], refined[index], removed,
        )
        for column, image in enumerate(images):
            probability = column in (3, 4, 6)
            axes[row, column].imshow(image, cmap="magma" if probability else "viridis", vmin=0, vmax=1 if probability else 2)
            axes[row, column].set_axis_off()
            if row == 0: axes[row, column].set_title(titles[column], fontsize=9)
        axes[row, 0].set_ylabel(FAMILIES[int(family_codes[index])], fontsize=9)
    figure.suptitle("Independent deep-concavity stress test: residual exterior-connected cutout")
    figure.tight_layout(); figure.savefig(path, dpi=190); plt.close(figure)


def save_public_grid(
    path: Path,
    truths: np.ndarray,
    ids: np.ndarray,
    stable: np.ndarray,
    guarded: np.ndarray,
    refined: np.ndarray,
    removal_probability: np.ndarray,
) -> None:
    focus = [index for index, case_id in enumerate(ids) if str(case_id) in PUBLIC_INWARD_BAY_IDS]
    figure, axes = plt.subplots(len(focus), 6, figsize=(14.2, 2.25 * len(focus)), squeeze=False)
    titles = ("truth", "stable", "guarded path", "removal p", "residual", "removed")
    for row, index in enumerate(focus):
        changed = (stable[index] != refined[index]).astype(np.float32)
        images = (truths[index], stable[index], guarded[index], removal_probability[index], refined[index], changed)
        for column, image in enumerate(images):
            probability = column in (3, 5)
            axes[row, column].imshow(image, cmap="magma" if probability else "viridis", vmin=0, vmax=1 if probability else 2)
            axes[row, column].set_axis_off()
            if row == 0: axes[row, column].set_title(titles[column], fontsize=9)
        axes[row, 0].set_ylabel(str(ids[index]), fontsize=8)
    figure.suptitle("All public KTC2023 cases with an inward bay, notch, crescent, or reentrant boundary")
    figure.tight_layout(); figure.savefig(path, dpi=185); plt.close(figure)


def save_calibration_grid(
    path: Path,
    truths: np.ndarray,
    ids: np.ndarray,
    stable: np.ndarray,
    refined: np.ndarray,
    removal_probability: np.ndarray,
    bank_probability: np.ndarray,
) -> None:
    figure, axes = plt.subplots(len(ids), 6, figsize=(13.6, 2.4 * len(ids)), squeeze=False)
    titles = ("truth", "stable", "removal p", "bank p", "residual", "removed")
    for row in range(len(ids)):
        changed = (stable[row] != refined[row]).astype(np.float32)
        images = (truths[row], stable[row], removal_probability[row], bank_probability[row], refined[row], changed)
        for column, image in enumerate(images):
            probability = column in (2, 3, 5)
            axes[row, column].imshow(image, cmap="magma" if probability else "viridis", vmin=0, vmax=1 if probability else 2)
            axes[row, column].set_axis_off()
            if row == 0: axes[row, column].set_title(titles[column], fontsize=9)
        axes[row, 0].set_ylabel(str(ids[row]), fontsize=8)
    figure.suptitle("Four official KTC training phantoms; row 4 is the deep inward-concave target")
    figure.tight_layout(); figure.savefig(path, dpi=200); plt.close(figure)


def infer_pair(
    conservative_model: nn.Module,
    aggressive_model: nn.Module,
    adapter: InputAdapter,
    images: np.ndarray,
    voltages: np.ndarray,
    device: torch.device,
    batch_size: int,
    size: int = 64,
) -> tuple[np.ndarray, np.ndarray]:
    outputs: list[np.ndarray] = []
    for model in (conservative_model, aggressive_model):
        chunks: list[np.ndarray] = []
        model.eval()
        with torch.no_grad():
            for start in range(0, len(images), batch_size):
                stop = start + batch_size
                image = torch.from_numpy(np.asarray(images[start:stop, None], dtype=np.float32)).to(device)
                voltage = torch.from_numpy(np.asarray(voltages[start:stop], dtype=np.float32)).to(device)
                with torch.amp.autocast("cuda", enabled=device.type == "cuda"):
                    logits = model(adapter(image), voltage)["logits"]
                if size != logits.shape[-1]:
                    logits = F.interpolate(logits.float(), size=(size, size), mode="bilinear", align_corners=False)
                chunks.append(torch.softmax(logits.float(), dim=1).cpu().numpy())
        outputs.append(np.concatenate(chunks))
    return outputs[0], outputs[1]


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    base = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    adapter = InputAdapter(base["fov_mask"]).to(device)
    conservative_model = load_model(args.conservative, device)
    aggressive_model = load_model(args.aggressive, device)
    print(f"device={device}; precomputing frozen probabilities", flush=True)

    base_validation = np.asarray(base["validation_indices"], dtype=np.int64)
    stress_validation = np.asarray(stress["validation_indices"], dtype=np.int64)
    bvc, bva = infer_pair(conservative_model, aggressive_model, adapter, base["linear_images"][base_validation], base["voltages"][base_validation], device, args.inference_batch_size)
    svc, sva = infer_pair(conservative_model, aggressive_model, adapter, stress["linear_images"][stress_validation], stress["voltages"][stress_validation], device, args.inference_batch_size)
    checkpoint = (args.initial_checkpoint or (output_dir / "residual_cutout_best.pt")).resolve()
    history: list[dict[str, float]] = []
    if args.evaluate_only:
        if not checkpoint.exists():
            raise FileNotFoundError("--evaluate-only requires an existing --initial-checkpoint")
        state = torch.load(checkpoint, map_location=device, weights_only=False)
        model = ResidualCutoutRefiner(int(state.get("base_channels", args.base_channels))).to(device)
        model.load_state_dict(state["model"])
        model.eval()
        print(f"evaluation-only: loaded {checkpoint}", flush=True)
    else:
        base_train = np.asarray(base["train_indices"], dtype=np.int64)
        stress_train = np.asarray(stress["train_indices"], dtype=np.int64)
        btc, bta = infer_pair(conservative_model, aggressive_model, adapter, base["linear_images"][base_train], base["voltages"][base_train], device, args.inference_batch_size)
        stc, sta = infer_pair(conservative_model, aggressive_model, adapter, stress["linear_images"][stress_train], stress["voltages"][stress_train], device, args.inference_batch_size)
        base_training = ResidualCutoutDataset(base, base_train, btc, bta, 0, True, args.seed + 1)
        stress_training = ResidualCutoutDataset(stress, stress_train, stc, sta, 1, True, args.seed + 2)
        training = ConcatDataset((base_training, *([stress_training] * max(1, args.stress_repeat))))
        train_loader = DataLoader(training, batch_size=args.batch_size, shuffle=True, drop_last=True, num_workers=args.workers, pin_memory=device.type == "cuda")
        validation = ConcatDataset((
            ResidualCutoutDataset(base, base_validation, bvc, bva, 0, False, args.seed + 3),
            ResidualCutoutDataset(stress, stress_validation, svc, sva, 1, False, args.seed + 4),
        ))
        validation_loader = DataLoader(validation, batch_size=args.batch_size * 2, shuffle=False, num_workers=0)
        model = ResidualCutoutRefiner(args.base_channels).to(device)
        optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
        scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
        best_score = -math.inf
        stale = 0
        for epoch in range(1, args.epochs + 1):
            model.train()
            totals: list[float] = []
            for batch in train_loader:
                moved = {key: value.to(device, non_blocking=True) for key, value in batch.items()}
                optimizer.zero_grad(set_to_none=True)
                with torch.amp.autocast("cuda", enabled=device.type == "cuda"):
                    features = assemble_features(adapter(moved["image"]), moved["conservative"], moved["aggressive"])
                    output = model(features, moved["voltage"])
                    loss, _ = refiner_loss(output, moved)
                scaler.scale(loss).backward()
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
                scaler.step(optimizer); scaler.update()
                totals.append(float(loss.detach()))
            scheduler.step()
            field = validation_field_metrics(model, adapter, validation_loader, device)
            score = (
                0.25 * field["dice"] + 0.55 * field["precision"] + 0.20 * field["recall"]
                - 0.70 * field["false_fraction"] - 0.45 * field["outer_false_fraction"]
            )
            row = {"epoch": epoch, "train_loss": float(np.mean(totals)), "selection_score": float(score), **field}
            history.append(row)
            print(
                f"epoch {epoch:02d}: loss={row['train_loss']:.4f} dice={field['dice']:.3f} "
                f"precision={field['precision']:.3f} recall={field['recall']:.3f} "
                f"false={field['false_fraction']:.4f} outer={field['outer_false_fraction']:.4f}",
                flush=True,
            )
            if score > best_score + 1e-5:
                best_score = score; stale = 0
                torch.save({"model": model.state_dict(), "base_channels": args.base_channels, "epoch": epoch, "validation": row, "seed": args.seed}, checkpoint)
            else:
                stale += 1
            if epoch >= 12 and stale >= args.patience:
                print(f"early stopping after epoch {epoch}", flush=True)
                break
        state = torch.load(checkpoint, map_location=device, weights_only=False)
        model.load_state_dict(state["model"]); model.eval()
        (output_dir / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
        save_training_curve(output_dir / "training_curve.png", history)

    print("selecting topology decoder on synthetic validation only", flush=True)
    base_val_stable = stable_probability(bvc, bva).argmax(axis=1).astype(np.uint8)
    stress_val_stable = stable_probability(svc, sva).argmax(axis=1).astype(np.uint8)
    base_val_removal, base_val_bank = infer_fields(model, adapter, base["linear_images"][base_validation], base["voltages"][base_validation], bvc, bva, device, args.inference_batch_size)
    stress_val_removal, stress_val_bank = infer_fields(model, adapter, stress["linear_images"][stress_validation], stress["voltages"][stress_validation], svc, sva, device, args.inference_batch_size)
    probability_report = {
        "base_validation": probability_diagnostics(
            base["labels"][base_validation], base_val_stable, base_val_removal, base_val_bank,
            base["indentation_masks"][base_validation],
        ),
        "stress_validation": probability_diagnostics(
            stress["labels"][stress_validation], stress_val_stable, stress_val_removal, stress_val_bank,
            stress["cutout_masks"][stress_validation], stress["cutout_depth_weights"][stress_validation],
        ),
    }
    (output_dir / "validation_probability_diagnostics.json").write_text(
        json.dumps(probability_report, indent=2), encoding="utf-8"
    )
    selected, grid = select_decoder(
        base, stress, base_validation, stress_validation, base_val_stable, stress_val_stable,
        base_val_removal, base_val_bank, stress_val_removal, stress_val_bank,
    )
    (output_dir / "decoder_grid.json").write_text(json.dumps(grid, indent=2), encoding="utf-8")
    print(f"selected decoder={json.dumps(selected)}", flush=True)
    policy = policy_from_record(selected)

    # All choices are frozen before any test or public truth is evaluated.
    base_test = np.asarray(base["test_indices"], dtype=np.int64)
    stress_test = np.asarray(stress["test_indices"], dtype=np.int64)
    btc_test, bta_test = infer_pair(conservative_model, aggressive_model, adapter, base["linear_images"][base_test], base["voltages"][base_test], device, args.inference_batch_size)
    stc_test, sta_test = infer_pair(conservative_model, aggressive_model, adapter, stress["linear_images"][stress_test], stress["voltages"][stress_test], device, args.inference_batch_size)
    base_stable = stable_probability(btc_test, bta_test).argmax(axis=1).astype(np.uint8)
    stress_stable = stable_probability(stc_test, sta_test).argmax(axis=1).astype(np.uint8)
    base_removal, base_bank = infer_fields(model, adapter, base["linear_images"][base_test], base["voltages"][base_test], btc_test, bta_test, device, args.inference_batch_size)
    stress_removal, stress_bank = infer_fields(model, adapter, stress["linear_images"][stress_test], stress["voltages"][stress_test], stc_test, sta_test, device, args.inference_batch_size)
    base_refined, base_removed = decode_batch(base_stable, base_removal, base_bank, policy)
    stress_refined, stress_removed = decode_batch(stress_stable, stress_removal, stress_bank, policy)

    previous = np.load(args.previous_predictions.resolve(), allow_pickle=False)
    if not np.array_equal(previous["stress_test_indices"], stress_test):
        raise RuntimeError("Previous stress prediction order does not match the current held-out split")
    guarded_stress = np.asarray(previous["stress_path"], dtype=np.uint8)
    guarded_base = np.asarray(previous["base_path"], dtype=np.uint8)
    base_summary = {
        name: standard_metrics(base["labels"][base_test], prediction, base["indentation_masks"][base_test])
        for name, prediction in (("stable", base_stable), ("guarded_path", guarded_base), ("residual_cutout", base_refined))
    }
    stress_summary: dict[str, dict[str, float]] = {}
    stress_family: dict[str, dict[str, dict[str, float]]] = {}
    core_rows: dict[str, list[dict[str, float]]] = {}
    core_summary: dict[str, dict[str, float]] = {}
    for name, prediction in (("stable", stress_stable), ("guarded_path", guarded_stress), ("residual_cutout", stress_refined)):
        stress_summary[name], stress_family[name], _ = stress_metrics(
            stress["labels"][stress_test], prediction, stress["cutout_masks"][stress_test],
            stress["cutout_depth_weights"][stress_test], stress["family_codes"][stress_test],
        )
        core_summary[name], core_rows[name] = core_metrics(stress, stress_test, prediction)
    bootstrap_stable = paired_bootstrap(core_rows["stable"], core_rows["residual_cutout"], args.bootstrap_samples, args.seed)
    bootstrap_guarded = paired_bootstrap(core_rows["guarded_path"], core_rows["residual_cutout"], args.bootstrap_samples, args.seed + 1)

    real_images = np.asarray(base["real_linear_images"], dtype=np.float32)
    real_voltages = np.asarray(base["real_voltages"], dtype=np.float32)
    real_conservative, real_aggressive = infer_pair(conservative_model, aggressive_model, adapter, real_images, real_voltages, device, args.inference_batch_size, 256)
    real_stable = stable_probability(real_conservative, real_aggressive).argmax(axis=1).astype(np.uint8)
    # Refiner fields are inferred at 64 and continuously upsampled as logits.
    real_conservative_64, real_aggressive_64 = infer_pair(conservative_model, aggressive_model, adapter, real_images, real_voltages, device, args.inference_batch_size, 64)
    real_removal, real_bank = infer_fields(model, adapter, real_images, real_voltages, real_conservative_64, real_aggressive_64, device, args.inference_batch_size, 256)
    real_refined, real_removed = decode_batch(real_stable, real_removal, real_bank, policy, scale=4)
    guarded_real = np.asarray(previous["real_path"], dtype=np.uint8)
    real_summary: dict[str, dict[str, float]] = {}
    real_rows: list[dict[str, object]] = []
    for name, prediction in (("stable", real_stable), ("guarded_path", guarded_real), ("residual_cutout", real_refined)):
        real_summary[name], rows = evaluate_real_predictions(name, prediction, base["real_labels"], base["real_ids"])
        real_rows.extend(rows)
    inward_summary = {
        name: aggregate_rows([
            {key: float(value) for key, value in row.items() if key not in ("id", "method")}
            for row in real_rows if row["method"] == name and str(row["id"]) in PUBLIC_INWARD_BAY_IDS
        ])
        for name in ("stable", "guarded_path", "residual_cutout")
    }

    calibration_images = np.asarray(base["calibration_linear_images"], dtype=np.float32)
    calibration_voltages = np.asarray(base["calibration_voltages"], dtype=np.float32)
    cc, ca = infer_pair(conservative_model, aggressive_model, adapter, calibration_images, calibration_voltages, device, args.inference_batch_size)
    calibration_stable = stable_probability(cc, ca).argmax(axis=1).astype(np.uint8)
    calibration_removal, calibration_bank = infer_fields(model, adapter, calibration_images, calibration_voltages, cc, ca, device, args.inference_batch_size)
    calibration_refined, calibration_removed = decode_batch(calibration_stable, calibration_removal, calibration_bank, policy)
    calibration_summary: dict[str, dict[str, float]] = {}
    calibration_rows: list[dict[str, object]] = []
    for name, prediction in (("stable", calibration_stable), ("residual_cutout", calibration_refined)):
        calibration_summary[name], rows = evaluate_real_predictions(name, prediction, base["calibration_labels"], base["calibration_ids"])
        calibration_rows.extend(rows)

    save_stress_grid(output_dir / "stress_core_comparison.png", stress, stress_test, stress_stable, guarded_stress, stress_refined, stress_removal, stress_bank)
    save_public_grid(output_dir / "public_inward_bay_comparison.png", base["real_labels"], base["real_ids"], real_stable, guarded_real, real_refined, real_removal)
    save_calibration_grid(output_dir / "official_four_case_comparison.png", base["calibration_labels"], base["calibration_ids"], calibration_stable, calibration_refined, calibration_removal, calibration_bank)
    write_csv(output_dir / "real_case_metrics.csv", real_rows)
    write_csv(output_dir / "official_four_case_metrics.csv", calibration_rows)
    write_csv(output_dir / "bootstrap_stable_to_residual.csv", bootstrap_stable)
    write_csv(output_dir / "bootstrap_guarded_to_residual.csv", bootstrap_guarded)
    np.savez_compressed(
        output_dir / "predictions.npz",
        base_test_indices=base_test, base_stable=base_stable, base_refined=base_refined, base_removed=base_removed,
        stress_test_indices=stress_test, stress_stable=stress_stable, stress_guarded=guarded_stress,
        stress_refined=stress_refined, stress_removed=stress_removed, stress_removal_probability=stress_removal,
        stress_bank_probability=stress_bank, real_stable=real_stable, real_guarded=guarded_real,
        real_refined=real_refined, real_removed=real_removed, real_removal_probability=real_removal,
        real_bank_probability=real_bank, calibration_stable=calibration_stable,
        calibration_refined=calibration_refined, calibration_removed=calibration_removed,
        calibration_removal_probability=calibration_removal, calibration_bank_probability=calibration_bank,
    )
    result = {
        "method": "frozen stable reconstruction + residual cutout/bank locator + exterior-connected topology projection",
        "algorithmic_scope": "inward concavities only; output can remove filled-in bay pixels but cannot globally re-segment or add foreground",
        "literature_basis": [
            "multi-reconstruction conditional inputs used by public KTC2023 post-processing code",
            "Boolean/level-set separation of support and inward cutout geometry in EIT",
            "topology-aware clDice supervision and exterior-connected component projection",
        ],
        "data_policy": "synthetic train/validation only for fitting and decoder selection; synthetic test, 21 KTC truths, and official four truths held out",
        "checkpoint": {"epoch": int(state["epoch"]), "validation": state["validation"]},
        "checkpoint_path": str(checkpoint),
        "validation_probability_diagnostics": probability_report,
        "selected_on_synthetic_validation": selected,
        "test": {
            "base": base_summary,
            "stress_all": stress_summary,
            "stress_core_inward_families": core_summary,
            "stress_by_family": stress_family,
            "bootstrap_core_stable_to_residual": bootstrap_stable,
            "bootstrap_core_guarded_to_residual": bootstrap_guarded,
            "public_all_21": real_summary,
            "public_inward_subset": {"ids": list(PUBLIC_INWARD_BAY_IDS), "metrics": inward_summary},
            "official_four": calibration_summary,
            "removed_pixels": {
                "base": int(base_removed.sum()), "stress": int(stress_removed.sum()),
                "public": int(real_removed.sum()), "official_four": int(calibration_removed.sum()),
            },
        },
        "core_inward_families": [FAMILIES[code] for code in CORE_FAMILY_CODES],
        "evaluation_truth_used_for_training_or_selection": False,
        "device": str(device),
        "args": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
    }
    (output_dir / "summary.json").write_text(json.dumps(result, indent=2, default=str), encoding="utf-8")
    print(json.dumps({"selected": selected, "test": result["test"]}, indent=2, default=str), flush=True)


if __name__ == "__main__":
    main()
