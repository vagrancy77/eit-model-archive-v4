"""Evaluate frozen four-seed v6 models on exact nonlinear-CEM shifts."""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import evaluate_topology_measurement_robustness as legacy
import evaluate_v6_measurement_robustness as shift


METHODS = shift.METHODS
METRICS = shift.METRICS


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", nargs="+", required=True, help="seed=v6_run_directory")
    parser.add_argument(
        "--dataset", type=Path,
        default=ROOT / "datasets" / "ktc_v6_physical_mismatch_cem_v1.npz",
    )
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--batch-size", type=int, default=28)
    parser.add_argument("--bootstrap", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20261119)
    parser.add_argument("--device", choices=("auto", "cuda", "cpu"), default="auto")
    parser.add_argument("--max-cases", type=int, default=0)
    return parser.parse_args()


def load_archive(path: Path, max_cases: int) -> tuple[legacy.Group, tuple[str, ...], dict[str, tuple[np.ndarray, np.ndarray]], dict[str, np.ndarray]]:
    archive = np.load(path.resolve(), allow_pickle=False)
    count = len(archive["case_ids"])
    if max_cases > 0:
        count = min(count, max_cases)
    conditions = tuple(str(value) for value in archive["conditions"])
    labels = np.asarray(archive["labels"][:count], dtype=np.uint8)
    group = legacy.Group(
        name="physical_cem",
        ids=np.asarray(archive["case_ids"][:count]),
        truth=labels,
        cutout=np.asarray(
            [shift.v6.indentation_mask(label) for label in labels], dtype=np.uint8
        ),
        voltage=np.asarray(archive["voltages"][0, :count], dtype=np.float32),
        native_image=np.asarray(archive["linear_images"][0, :count], dtype=np.float32),
        fov=np.asarray(archive["fov_mask"], dtype=np.uint8),
        reconstruction_operator=np.asarray(archive["reconstruction_operator"], dtype=np.float32),
        raw_pixel_to_node=np.asarray(archive["raw_pixel_to_node"], dtype=np.int64),
        audited_concave=np.asarray(
            archive["cutout_masks"][:count].reshape(count, -1).any(axis=1), dtype=bool
        ),
    )
    prepared = {
        condition: (
            np.asarray(archive["voltages"][index, :count], dtype=np.float32),
            np.asarray(archive["linear_images"][index, :count], dtype=np.float32),
        )
        for index, condition in enumerate(conditions)
    }
    physics = {
        "jacobian": np.asarray(archive["jacobian"], dtype=np.float32),
        "node_to_raw_pixel": np.asarray(archive["node_to_raw_pixel"], dtype=np.int64),
    }
    return group, conditions, prepared, physics


def matrix(
    lookup: dict[tuple[str, str, str, str], dict[str, object]],
    seeds: list[str],
    condition: str,
    ids: list[str],
    method: str,
    metric: str,
) -> np.ndarray:
    return np.asarray(
        [
            [float(lookup[(seed, condition, case_id, method)][metric]) for case_id in ids]
            for seed in seeds
        ],
        dtype=np.float64,
    )


def summarize(
    rows: list[dict[str, object]],
    conditions: tuple[str, ...],
    repetitions: int,
    random_seed: int,
) -> dict[str, object]:
    seeds = sorted({str(row["seed"]) for row in rows})
    lookup = {
        (str(row["seed"]), str(row["condition"]), str(row["case_id"]), str(row["method"])): row
        for row in rows
    }
    reference = [
        row for row in rows
        if row["seed"] == seeds[0] and row["condition"] == conditions[0]
        and row["method"] == "anchor_v4"
    ]
    ids_by_subset = {
        subset: sorted(
            str(row["case_id"]) for row in reference
            if subset == "all" or row["subset"] == subset
        )
        for subset in ("all", "concave", "ordinary")
    }
    ids_by_subset = {key: value for key, value in ids_by_subset.items() if value}
    rng = np.random.default_rng(random_seed)
    groups: dict[str, object] = {}
    for subset, ids in ids_by_subset.items():
        nominal = {
            (method, metric): matrix(
                lookup, seeds, conditions[0], ids, method, metric
            )
            for method in METHODS for metric in METRICS
        }
        condition_results: dict[str, object] = {}
        for condition in conditions:
            matrices = {
                (method, metric): matrix(lookup, seeds, condition, ids, method, metric)
                for method in METHODS for metric in METRICS
            }
            statistics: dict[str, object] = {}
            for method in METHODS:
                statistics[method] = {
                    metric: {
                        "pooled_mean": float(np.nanmean(matrices[(method, metric)])),
                        "per_seed_means": [
                            float(np.nanmean(value)) for value in matrices[(method, metric)]
                        ],
                    }
                    for metric in METRICS
                    if np.isfinite(matrices[(method, metric)]).any()
                }
                selections = [
                    float(lookup[(seed, condition, case_id, method)]["gate_selected"])
                    for seed in seeds for case_id in ids
                ]
                statistics[method]["selected_fraction"] = float(np.mean(selections))
            comparisons: dict[str, object] = {}
            for method in ("candidate_v6", "gated_v6"):
                comparisons[f"{method}_minus_anchor_v4"] = {}
                for metric in METRICS:
                    value = shift.hierarchical_bootstrap(
                        matrices[(method, metric)] - matrices[("anchor_v4", metric)],
                        repetitions,
                        rng,
                    )
                    if value is not None:
                        comparisons[f"{method}_minus_anchor_v4"][metric] = value
            degradation: dict[str, object] = {}
            if condition != conditions[0]:
                for method in METHODS:
                    degradation[method] = {}
                    for metric in METRICS:
                        value = shift.hierarchical_bootstrap(
                            matrices[(method, metric)] - nominal[(method, metric)],
                            repetitions,
                            rng,
                        )
                        if value is not None:
                            degradation[method][metric] = value
            condition_results[condition] = {
                "method_statistics": statistics,
                "comparisons": comparisons,
                "degradation_from_nominal": degradation,
            }
        groups[subset] = {
            "cases_per_seed": len(ids),
            "conditions": condition_results,
        }
    return {
        "seeds": seeds,
        "conditions": list(conditions),
        "groups": groups,
        "bootstrap_repetitions": repetitions,
    }


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def write_table(path: Path, summary: dict[str, object]) -> None:
    rows: list[dict[str, object]] = []
    for subset in ("concave", "ordinary"):
        if subset not in summary["groups"]:
            continue
        group = summary["groups"][subset]
        for condition in summary["conditions"]:
            data = group["conditions"][condition]
            effect = data["comparisons"]["gated_v6_minus_anchor_v4"]
            for method in ("anchor_v4", "gated_v6"):
                stats = data["method_statistics"][method]
                rows.append(
                    {
                        "subset": subset,
                        "cases_per_seed": group["cases_per_seed"],
                        "condition": condition,
                        "method": method,
                        "foreground_iou": stats["foreground_iou"]["pooled_mean"],
                        "boundary_f1": stats["boundary_f1"]["pooled_mean"],
                        "notch_preservation": stats.get("notch_preservation", {}).get(
                            "pooled_mean", ""
                        ),
                        "selected_fraction": stats["selected_fraction"],
                        "gated_minus_anchor_iou": effect["foreground_iou"]["mean_difference"],
                        "gated_minus_anchor_notch": effect.get("notch_preservation", {}).get(
                            "mean_difference", ""
                        ),
                    }
                )
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def plot_summary(path: Path, summary: dict[str, object]) -> None:
    conditions = tuple(summary["conditions"])
    figure, axes = plt.subplots(2, 2, figsize=(13.5, 8.0))
    panels = (
        ("concave", "foreground_iou"),
        ("concave", "notch_preservation"),
        ("ordinary", "foreground_iou"),
        ("ordinary", "boundary_f1"),
    )
    colors = {"anchor_v4": "#4d4d4d", "gated_v6": "#087f5b"}
    for axis, (subset, metric) in zip(axes.flat, panels):
        group = summary["groups"][subset]
        for method in ("anchor_v4", "gated_v6"):
            values = [
                group["conditions"][condition]["method_statistics"][method][metric][
                    "pooled_mean"
                ]
                for condition in conditions
            ]
            axis.plot(values, marker="o", linewidth=2, color=colors[method], label=method)
        axis.set_xticks(
            range(len(conditions)),
            [value.replace("_", " ") for value in conditions],
            rotation=30,
            ha="right",
            fontsize=8,
        )
        axis.set_title(f"{subset}: {metric.replace('_', ' ')}")
        axis.grid(alpha=0.23)
    axes[0, 1].legend(frameon=False)
    figure.suptitle("Independent nonlinear-CEM physical distribution shift")
    figure.tight_layout()
    figure.savefig(path, dpi=240)
    plt.close(figure)


def plot_effects(path: Path, summary: dict[str, object]) -> None:
    conditions = tuple(summary["conditions"])
    subsets = ("concave", "ordinary")
    figure, axes = plt.subplots(1, 2, figsize=(13.0, 4.8))
    for axis, subset in zip(axes, subsets):
        group = summary["groups"][subset]
        values = [
            group["conditions"][condition]["comparisons"]["gated_v6_minus_anchor_v4"]
            ["foreground_iou"]["mean_difference"]
            for condition in conditions
        ]
        lows = [
            group["conditions"][condition]["comparisons"]["gated_v6_minus_anchor_v4"]
            ["foreground_iou"]["ci95_low"]
            for condition in conditions
        ]
        highs = [
            group["conditions"][condition]["comparisons"]["gated_v6_minus_anchor_v4"]
            ["foreground_iou"]["ci95_high"]
            for condition in conditions
        ]
        values_array = np.asarray(values)
        error = np.maximum(
            0.0,
            np.vstack((values_array - np.asarray(lows), np.asarray(highs) - values_array)),
        )
        axis.errorbar(range(len(conditions)), values_array, yerr=error, fmt="o", capsize=4)
        axis.axhline(0.0, color="black", linestyle="--", linewidth=1)
        axis.set_xticks(
            range(len(conditions)),
            [value.replace("_", " ") for value in conditions],
            rotation=30,
            ha="right",
            fontsize=8,
        )
        axis.set_title(f"{subset}: gated v6 minus v4 IoU")
        axis.grid(alpha=0.22)
    figure.tight_layout()
    figure.savefig(path, dpi=240)
    plt.close(figure)


def plot_examples(
    path: Path,
    group: legacy.Group,
    conditions: tuple[str, ...],
    prepared: dict[str, tuple[np.ndarray, np.ndarray]],
    outputs: dict[str, dict[str, np.ndarray]],
) -> None:
    concave = np.flatnonzero(group.cutout.reshape(len(group.ids), -1).sum(axis=1) > 0)
    index = int(concave[len(concave) // 2])
    short_labels = {
        "nominal": "Nominal",
        "contact_global_2p4x": "Global contact 2.4x",
        "contact_heterogeneous_logsd0p55": "Heterogeneous contact",
        "background_smooth_0p16": "Smooth background",
        "combined_contact_background": "Combined mismatch",
    }
    figure, axes = plt.subplots(len(conditions), 5, figsize=(13.0, 2.55 * len(conditions)))
    for row, condition in enumerate(conditions):
        result = outputs[condition]
        panels = (
            (group.truth[index], "Truth"),
            (prepared[condition][1][index], "Linear EIT"),
            (result["anchor_v4"][index], "v4 anchor"),
            (result["candidate_v6"][index], "v6 candidate"),
            (result["gated_v6"][index], "Gated v6"),
        )
        for column, (image, title) in enumerate(panels):
            axes[row, column].imshow(image, cmap="viridis", interpolation="nearest")
            if row == 0:
                axes[row, column].set_title(title, fontsize=10)
            axes[row, column].set_axis_off()
        axes[row, 0].set_ylabel(short_labels.get(condition, condition), fontsize=9)
        axes[row, 4].text(
            0.03,
            0.06,
            f"gate={bool(result['selected'][index])}",
            transform=axes[row, 4].transAxes,
            color="white",
            fontsize=8,
            bbox={"facecolor": "black", "alpha": 0.55, "pad": 2},
        )
    figure.suptitle("Exact CEM mismatch: representative independent concave case")
    figure.tight_layout()
    figure.savefig(path, dpi=240)
    plt.close(figure)


def write_report(path: Path, summary: dict[str, object]) -> None:
    lines = [
        "# V6 Exact Nonlinear-CEM Physical-Mismatch Report",
        "",
        "The v4 anchor, v6 corrector, quantile gate, and gate rules were frozen. The archive is evaluation-only.",
        "",
        "| Subset | Condition | gated-v4 IoU (95% CI) | gated-v4 Notch (95% CI) | gated IoU degradation |",
        "|---|---|---:|---:|---:|",
    ]
    for subset in ("concave", "ordinary"):
        group = summary["groups"][subset]
        for condition in summary["conditions"]:
            data = group["conditions"][condition]
            effect = data["comparisons"]["gated_v6_minus_anchor_v4"]
            iou = effect["foreground_iou"]
            notch = effect.get("notch_preservation")
            notch_text = "n/a" if notch is None else (
                f"{notch['mean_difference']:+.5f} [{notch['ci95_low']:+.5f}, {notch['ci95_high']:+.5f}]"
            )
            degradation = data["degradation_from_nominal"].get("gated_v6", {}).get(
                "foreground_iou"
            )
            degradation_text = "nominal" if degradation is None else (
                f"{degradation['mean_difference']:+.5f} [{degradation['ci95_low']:+.5f}, {degradation['ci95_high']:+.5f}]"
            )
            lines.append(
                f"| {subset} | {condition} | {iou['mean_difference']:+.5f} "
                f"[{iou['ci95_low']:+.5f}, {iou['ci95_high']:+.5f}] | {notch_text} | {degradation_text} |"
            )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    run_paths = shift.parse_keyed(args.runs)
    device = shift.choose_device(args.device)
    group, conditions, prepared, physics = load_archive(args.dataset, args.max_cases)
    fov = torch.from_numpy(group.fov.astype(np.float32))[None, None].to(device)
    jacobian = torch.from_numpy(physics["jacobian"]).to(device)
    node_to_raw_pixel = torch.from_numpy(physics["node_to_raw_pixel"]).to(device)
    rows: list[dict[str, object]] = []
    examples: dict[str, dict[str, np.ndarray]] = {}
    first_seed = next(iter(run_paths))
    rules: dict[str, object] = {}
    for model_seed, directory in run_paths.items():
        run, v4_model = shift.load_frozen_run(model_seed, directory, group.fov, device)
        rules[model_seed] = run.gate_rule
        print(f"seed={model_seed} loaded frozen v4/v6/gate", flush=True)
        for condition in conditions:
            voltage, image = prepared[condition]
            output = shift.infer_condition(
                run,
                v4_model,
                voltage,
                image,
                tuple(group.truth.shape[-2:]),
                fov,
                jacobian,
                node_to_raw_pixel,
                args.batch_size,
                device,
            )
            shift.append_rows(rows, model_seed, condition, group, output)
            if model_seed == first_seed:
                examples[condition] = output
            print(f"  completed {condition}", flush=True)
        del run, v4_model
        if device.type == "cuda":
            torch.cuda.empty_cache()

    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    write_rows(output_dir / "v6_physical_mismatch_case_metrics.csv", rows)
    summary = summarize(rows, conditions, args.bootstrap, args.seed)
    summary.update(
        {
            "dataset": str(args.dataset.resolve()),
            "frozen_gate_rules": rules,
            "protocol": {
                "nonlinear_complete_electrode_model_resolved_per_condition": True,
                "matched_differential_reference_per_condition": True,
                "evaluation_archive_used_for_training_or_selection": False,
                "test_truth_used_for_adaptation": False,
                "paired_geometry_and_conditions_across_model_seeds": True,
            },
        }
    )
    (output_dir / "v6_physical_mismatch_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    write_table(output_dir / "v6_physical_mismatch_paper_table.csv", summary)
    plot_summary(output_dir / "v6_physical_mismatch_curves.png", summary)
    plot_effects(output_dir / "v6_physical_mismatch_effects.png", summary)
    plot_examples(
        output_dir / "v6_physical_mismatch_examples.png",
        group,
        conditions,
        prepared,
        examples,
    )
    write_report(output_dir / "V6_PHYSICAL_MISMATCH_REPORT.md", summary)
    print(json.dumps({"output_dir": str(output_dir), "rows": len(rows)}, indent=2), flush=True)


if __name__ == "__main__":
    main()
