"""Fuse the frozen three-branch EIT ensemble with a topology refiner.

Only one coefficient is selected: how much the refiner contributes relative
to the already frozen 0.3/0.4/0.3 log-probability ensemble. Selection uses the
synthetic validation split. Synthetic test and public KTC labels are accessed
only after that coefficient is fixed.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader

from fuse_ktc_concavity_models import load_model, real_probabilities, synthetic_probabilities
from train_ktc_concavity_network import InputAdapter, save_focus_montage, save_real_montage, write_rows
from train_ktc_concavity_network_v2 import EITDatasetV2, evaluate_real_predictions, selection_score
from train_ktc_topology_refiner import TopologyRefiner


BASE_WEIGHTS = (0.3, 0.4, 0.3)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--component-checkpoints", nargs=3, type=Path, required=True)
    parser.add_argument("--refiner-checkpoint", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--batch-size", type=int, default=24)
    parser.add_argument("--alpha-step", type=float, default=0.05)
    parser.add_argument("--max-alpha", type=float, default=0.60)
    parser.add_argument("--iou-tolerance", type=float, default=0.005)
    parser.add_argument("--boundary-tolerance", type=float, default=0.010)
    parser.add_argument("--fixed-alpha", type=float)
    return parser.parse_args()


def load_refiner(path: Path, device: torch.device) -> tuple[TopologyRefiner, dict[str, object]]:
    state = torch.load(path.resolve(), map_location=device, weights_only=False)
    model = TopologyRefiner(int(state["base_channels"])).to(device)
    model.load_state_dict(state["model"])
    model.eval()
    return model, state


@torch.no_grad()
def synthetic_refiner_probabilities(
    boundary_model: torch.nn.Module,
    refiner: TopologyRefiner,
    adapter: InputAdapter,
    archive: np.lib.npyio.NpzFile,
    indices: np.ndarray,
    device: torch.device,
    batch_size: int,
) -> np.ndarray:
    loader = DataLoader(EITDatasetV2(archive, indices), batch_size=batch_size, shuffle=False, num_workers=0)
    chunks: list[np.ndarray] = []
    for batch in loader:
        image = adapter(batch["image"].to(device))
        voltage = batch["input_voltage"].to(device)
        boundary_probability = torch.softmax(boundary_model(image, voltage)["logits"], dim=1)
        probability = torch.softmax(refiner(image, boundary_probability)["logits"], dim=1)
        chunks.append(probability.cpu().numpy().astype(np.float32))
    return np.concatenate(chunks)


@torch.no_grad()
def real_refiner_probabilities(
    boundary_model: torch.nn.Module,
    refiner: TopologyRefiner,
    adapter: InputAdapter,
    images: np.ndarray,
    voltages: np.ndarray,
    device: torch.device,
    batch_size: int,
) -> np.ndarray:
    chunks: list[np.ndarray] = []
    for start in range(0, len(images), batch_size):
        image = torch.from_numpy(images[start : start + batch_size, None].astype(np.float32)).to(device)
        voltage = torch.from_numpy(voltages[start : start + batch_size].astype(np.float32)).to(device)
        adapted = adapter(image)
        boundary_probability = torch.softmax(boundary_model(adapted, voltage)["logits"], dim=1)
        logits = refiner(adapted, boundary_probability)["logits"]
        logits = F.interpolate(logits, size=(256, 256), mode="bilinear", align_corners=False)
        chunks.append(torch.softmax(logits, dim=1).cpu().numpy().astype(np.float32))
    return np.concatenate(chunks)


def log_score(probabilities: list[np.ndarray], weights: tuple[float, ...]) -> np.ndarray:
    return sum(weight * np.log(np.clip(probability, 1e-7, 1.0)) for probability, weight in zip(probabilities, weights))


def prediction_from_scores(base_score: np.ndarray, refiner_probability: np.ndarray, alpha: float) -> np.ndarray:
    score = (1.0 - alpha) * base_score + alpha * np.log(np.clip(refiner_probability, 1e-7, 1.0))
    return score.argmax(axis=1).astype(np.uint8)


def metrics_for_predictions(
    predictions: np.ndarray,
    truths: np.ndarray,
    indentations: np.ndarray,
) -> dict[str, float]:
    from train_ktc_concavity_network import aggregate_rows, confusion_metrics

    return aggregate_rows(
        [
            confusion_metrics(truth, prediction, indentation)
            for truth, prediction, indentation in zip(truths, predictions, indentations)
        ]
    )


def alpha_grid(step: float, maximum: float) -> list[float]:
    denominator = int(round(1.0 / step))
    count = int(round(maximum * denominator))
    return [index / denominator for index in range(count + 1)]


def write_alpha_search(path: Path, rows: list[dict[str, float]]) -> None:
    fields = [
        "alpha",
        "eligible",
        "selection_score",
        "foreground_iou",
        "foreground_dice",
        "boundary_f1",
        "notch_preservation",
        "concavity_score",
        "class_1_iou",
        "class_2_iou",
    ]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key) for key in fields})


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    archive = np.load(args.dataset.resolve(), allow_pickle=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    components = [load_model(path, device) for path in args.component_checkpoints]
    refiner, refiner_state = load_refiner(args.refiner_checkpoint, device)
    adapter = InputAdapter(archive["fov_mask"]).to(device)

    validation_components, validation_truths, validation_indentations = synthetic_probabilities(
        components,
        adapter,
        archive,
        archive["validation_indices"],
        device,
        args.batch_size,
    )
    validation_refiner = synthetic_refiner_probabilities(
        components[0],
        refiner,
        adapter,
        archive,
        archive["validation_indices"],
        device,
        args.batch_size,
    )
    validation_base_score = log_score(validation_components, BASE_WEIGHTS)
    base_metrics = metrics_for_predictions(
        validation_base_score.argmax(axis=1).astype(np.uint8), validation_truths, validation_indentations
    )
    alphas = [args.fixed_alpha] if args.fixed_alpha is not None else alpha_grid(args.alpha_step, args.max_alpha)
    search_rows: list[dict[str, float]] = []
    for alpha in alphas:
        predictions = prediction_from_scores(validation_base_score, validation_refiner, float(alpha))
        metrics = metrics_for_predictions(predictions, validation_truths, validation_indentations)
        eligible = (
            metrics["foreground_iou"] >= base_metrics["foreground_iou"] - args.iou_tolerance
            and metrics["boundary_f1"] >= base_metrics["boundary_f1"] - args.boundary_tolerance
        )
        search_rows.append(
            {
                "alpha": float(alpha),
                "eligible": float(eligible),
                "selection_score": selection_score(metrics),
                **metrics,
            }
        )
    eligible_rows = [row for row in search_rows if row["eligible"] > 0]
    if not eligible_rows:
        raise RuntimeError("No topology-fusion coefficient satisfies the validation constraints")
    selected = max(eligible_rows, key=lambda row: (row["selection_score"], row["concavity_score"]))
    selected_alpha = float(selected["alpha"])
    write_alpha_search(output_dir / "validation_alpha_search.csv", search_rows)
    print(f"selected alpha={selected_alpha:.2f}; validation={selected}", flush=True)

    test_components, test_truths, test_indentations = synthetic_probabilities(
        components, adapter, archive, archive["test_indices"], device, args.batch_size
    )
    test_refiner = synthetic_refiner_probabilities(
        components[0], refiner, adapter, archive, archive["test_indices"], device, args.batch_size
    )
    test_base_score = log_score(test_components, BASE_WEIGHTS)
    test_predictions = {
        "fusion": test_base_score.argmax(axis=1).astype(np.uint8),
        "refiner": test_refiner.argmax(axis=1).astype(np.uint8),
        "topology_fusion": prediction_from_scores(test_base_score, test_refiner, selected_alpha),
    }
    synthetic_summary = {
        name: metrics_for_predictions(prediction, test_truths, test_indentations)
        for name, prediction in test_predictions.items()
    }
    print(f"synthetic untouched test={synthetic_summary}", flush=True)

    # Public KTC evaluation truth is first accessed after validation selection
    # and synthetic-test reporting are complete.
    real_components = real_probabilities(
        components,
        adapter,
        archive["real_linear_images"],
        archive["real_voltages"],
        device,
        args.batch_size,
    )
    real_refiner = real_refiner_probabilities(
        components[0],
        refiner,
        adapter,
        archive["real_linear_images"],
        archive["real_voltages"],
        device,
        args.batch_size,
    )
    real_base_score = log_score(real_components, BASE_WEIGHTS)
    real_predictions = {
        "boundary": real_components[0].argmax(axis=1).astype(np.uint8),
        "fusion": real_base_score.argmax(axis=1).astype(np.uint8),
        "refiner": real_refiner.argmax(axis=1).astype(np.uint8),
        "topology_fusion": prediction_from_scores(real_base_score, real_refiner, selected_alpha),
    }
    real_truths = archive["real_labels"]
    real_ids = archive["real_ids"]
    real_summary: dict[str, dict[str, float]] = {}
    real_rows: list[dict[str, object]] = []
    for name, predictions in real_predictions.items():
        real_summary[name], rows = evaluate_real_predictions(name, predictions, real_truths, real_ids)
        real_rows.extend(rows)
        print(f"real test {name}: {real_summary[name]}", flush=True)
    write_rows(output_dir / "real_case_metrics.csv", real_rows)
    save_real_montage(output_dir / "real_all_21_comparison.png", real_truths, real_ids, real_predictions, real_rows)
    save_focus_montage(output_dir / "real_most_concave_comparison.png", real_truths, real_ids, real_predictions, real_rows)
    np.savez_compressed(
        output_dir / "real_predictions.npz",
        ids=real_ids,
        truth=real_truths,
        **real_predictions,
    )

    result = {
        "dataset": str(args.dataset.resolve()),
        "component_checkpoints": [str(path.resolve()) for path in args.component_checkpoints],
        "base_weights": dict(zip(("boundary", "indent", "voltage"), BASE_WEIGHTS)),
        "refiner_checkpoint": str(args.refiner_checkpoint.resolve()),
        "refiner_epoch": int(refiner_state.get("epoch", -1)),
        "selection_data": "synthetic validation only",
        "selected_alpha": selected_alpha,
        "validation_base": base_metrics,
        "validation_selected": selected,
        "constraints": {
            "minimum_iou": base_metrics["foreground_iou"] - args.iou_tolerance,
            "minimum_boundary_f1": base_metrics["boundary_f1"] - args.boundary_tolerance,
            "selected_satisfies_constraints": True,
        },
        "synthetic_untouched_test": synthetic_summary,
        "real_untouched_test": real_summary,
        "evaluation_truth_used_for_selection": False,
    }
    (output_dir / "summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
