"""Generate nonlinear-CEM data for smooth, lesion-like concave targets.

Training/validation shapes and final test shapes use disjoint generators.  The
test split therefore measures whether a model learned an inward-boundary rule
rather than memorizing a finite family of phantom templates.
"""
from __future__ import annotations

import argparse
import json
import os
import random
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import binary_closing, binary_fill_holes, label as connected_components

from prepare_ktc_shape_dataset import (
    convex_hull_mask,
    instance_indentation_mask,
    rotate,
    signed_distance,
)


TRAIN_FAMILIES = (
    "oval_control",
    "shallow_bay",
    "soft_kidney",
    "lobulated_nodule",
)
TEST_FAMILIES = (
    "rounded_control",
    "asymmetric_bay",
    "fused_cell_cluster",
    "smooth_crescent",
)
FAMILIES = TRAIN_FAMILIES + TEST_FAMILIES


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--samples", type=int, default=2400)
    parser.add_argument("--resolution", type=int, default=64)
    parser.add_argument("--seed", type=int, default=20260831)
    parser.add_argument("--forward-mode", choices=("nonlinear", "linear"), default="nonlinear")
    parser.add_argument("--voltage-scale", type=float, default=2.0)
    parser.add_argument("--contact-jitter", type=float, default=0.16)
    parser.add_argument("--train-fraction", type=float, default=2.0 / 3.0)
    parser.add_argument("--validation-fraction", type=float, default=1.0 / 6.0)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--repo-root", type=Path, default=root / "external" / "KTC2023-ABC2")
    parser.add_argument(
        "--ktc-root",
        type=Path,
        default=root / "datasets" / "ktc2023_full" / "v3" / "evaluation_full" / "EvaluationData_full",
    )
    parser.add_argument("--output", type=Path, default=root / "datasets" / "ktc_biological_concavity_v1.npz")
    return parser.parse_args()


def local_frame(
    x: np.ndarray,
    y: np.ndarray,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray, float, float]:
    sx = float(rng.uniform(0.20, 0.37))
    sy = float(rng.uniform(0.18, 0.35))
    limit = max(0.08, 0.72 - max(sx, sy))
    radius = limit * np.sqrt(float(rng.uniform()))
    angle = float(rng.uniform(-np.pi, np.pi))
    cx, cy = radius * np.cos(angle), radius * np.sin(angle)
    lx, ly = rotate(x - cx, y - cy, float(rng.uniform(-np.pi, np.pi)))
    return lx, ly, sx, sy


def _keep_largest(mask: np.ndarray) -> np.ndarray:
    components, count = connected_components(mask)
    if count <= 1:
        return mask
    sizes = np.bincount(components.ravel())
    sizes[0] = 0
    return components == int(np.argmax(sizes))


def draw_primary(
    family: str,
    x: np.ndarray,
    y: np.ndarray,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray]:
    lx, ly, sx, sy = local_frame(x, y, rng)
    ellipse = (lx / sx) ** 2 + (ly / sy) ** 2 <= 1.0

    if family in {"oval_control", "rounded_control"}:
        theta = np.arctan2(ly / sy, lx / sx)
        radius = np.hypot(lx / sx, ly / sy)
        modulation = 1.0 + 0.035 * np.cos(2.0 * theta + float(rng.uniform(-np.pi, np.pi)))
        foreground = radius <= modulation
        support = foreground.copy()
    elif family == "shallow_bay":
        depth = float(rng.uniform(0.16, 0.34))
        vertical = float(rng.uniform(0.22, 0.48))
        notch = ((lx - sx * (1.0 - 0.35 * depth)) / (sx * depth)) ** 2 + (
            (ly - sy * float(rng.uniform(-0.30, 0.30))) / (sy * vertical)
        ) ** 2 <= 1.0
        support = ellipse
        foreground = support & ~notch
    elif family == "soft_kidney":
        shift = sx * float(rng.uniform(0.48, 0.72))
        notch = ((lx - shift) / (sx * float(rng.uniform(0.45, 0.62)))) ** 2 + (
            ly / (sy * float(rng.uniform(0.58, 0.82)))
        ) ** 2 <= 1.0
        support = ellipse
        foreground = support & ~notch
    elif family == "lobulated_nodule":
        theta = np.arctan2(ly / sy, lx / sx)
        radius = np.hypot(lx / sx, ly / sy)
        phase = float(rng.uniform(-np.pi, np.pi))
        lobes = int(rng.integers(3, 6))
        boundary = 0.82 + float(rng.uniform(0.08, 0.15)) * np.cos(lobes * theta + phase)
        boundary += 0.035 * np.cos((lobes + 1) * theta - 0.5 * phase)
        foreground = radius <= boundary
        support = convex_hull_mask(foreground)
    elif family == "asymmetric_bay":
        support = ellipse
        center_x = sx * float(rng.uniform(0.55, 0.82))
        center_y = sy * float(rng.uniform(-0.42, 0.42))
        notch = ((lx - center_x) / (sx * float(rng.uniform(0.28, 0.46)))) ** 2 + (
            (ly - center_y) / (sy * float(rng.uniform(0.30, 0.56)))
        ) ** 2 <= 1.0
        foreground = support & ~notch
    elif family == "fused_cell_cluster":
        r1x, r1y = sx * 0.72, sy * float(rng.uniform(0.68, 0.88))
        r2x, r2y = sx * 0.70, sy * float(rng.uniform(0.66, 0.90))
        offset = sx * float(rng.uniform(0.36, 0.53))
        vertical = sy * float(rng.uniform(-0.28, 0.28))
        first = ((lx + offset) / r1x) ** 2 + ((ly - vertical) / r1y) ** 2 <= 1.0
        second = ((lx - offset) / r2x) ** 2 + ((ly + vertical) / r2y) ** 2 <= 1.0
        foreground = binary_closing(first | second, iterations=1)
        support = convex_hull_mask(foreground)
    elif family == "smooth_crescent":
        support = ellipse
        shift_x = sx * float(rng.uniform(0.32, 0.50))
        shift_y = sy * float(rng.uniform(-0.16, 0.16))
        inner = ((lx - shift_x) / (sx * float(rng.uniform(0.60, 0.76)))) ** 2 + (
            (ly - shift_y) / (sy * float(rng.uniform(0.62, 0.78)))
        ) ** 2 <= 1.0
        foreground = support & ~inner
    else:
        raise ValueError(f"unknown family: {family}")

    foreground = _keep_largest(binary_closing(foreground, iterations=1))
    support = binary_fill_holes(support | foreground).astype(bool)
    return foreground, support


def add_secondary_lesion(
    labels: np.ndarray,
    delta: np.ndarray,
    x: np.ndarray,
    y: np.ndarray,
    rng: np.random.Generator,
) -> None:
    if rng.uniform() >= 0.32:
        return
    radius = float(rng.uniform(0.10, 0.18))
    angle = float(rng.uniform(-np.pi, np.pi))
    distance = float(rng.uniform(0.38, 0.64))
    cx, cy = distance * np.cos(angle), distance * np.sin(angle)
    sx, sy = radius * float(rng.uniform(0.85, 1.30)), radius * float(rng.uniform(0.75, 1.20))
    lesion = ((x - cx) / sx) ** 2 + ((y - cy) / sy) ** 2 <= 1.0
    lesion &= labels == 0
    if lesion.sum() < 10:
        return
    class_id = 1 if rng.uniform() < 0.5 else 2
    contrast = -float(rng.uniform(0.22, 0.72)) if class_id == 1 else float(rng.uniform(0.22, 0.88))
    labels[lesion] = class_id
    delta[lesion] = contrast


def generate_geometry(
    samples: int,
    resolution: int,
    seed: int,
    train_end: int,
    validation_end: int,
) -> dict[str, np.ndarray]:
    rng = np.random.default_rng(seed)
    coordinates = np.linspace(-1.0, 1.0, resolution, dtype=np.float32)
    x, y = np.meshgrid(coordinates, coordinates)
    fov = x * x + y * y <= 0.98**2
    labels = np.zeros((samples, resolution, resolution), dtype=np.uint8)
    delta = np.zeros((samples, resolution, resolution), dtype=np.float32)
    support_masks = np.zeros_like(labels)
    cutout_masks = np.zeros_like(labels)
    indentation_masks = np.zeros_like(labels)
    signed_distances = np.zeros_like(delta)
    family_codes = np.zeros(samples, dtype=np.int16)
    is_ood = np.zeros(samples, dtype=np.uint8)

    for index in range(samples):
        families = TRAIN_FAMILIES if index < validation_end else TEST_FAMILIES
        family = families[index % len(families)]
        foreground, support = draw_primary(family, x, y, rng)
        foreground &= fov
        support &= fov
        class_id = 1 if rng.uniform() < 0.56 else 2
        contrast = -float(rng.uniform(0.22, 0.86)) if class_id == 1 else float(rng.uniform(0.22, 1.02))
        sample_labels = np.zeros((resolution, resolution), dtype=np.uint8)
        sample_delta = np.zeros((resolution, resolution), dtype=np.float32)
        sample_labels[foreground] = class_id
        sample_delta[foreground] = contrast
        add_secondary_lesion(sample_labels, sample_delta, x, y, rng)
        cutout = support & ~foreground

        labels[index] = sample_labels
        delta[index] = sample_delta
        support_masks[index] = support
        cutout_masks[index] = cutout
        indentation_masks[index] = instance_indentation_mask(sample_labels) | cutout
        signed_distances[index] = signed_distance(sample_labels)
        family_codes[index] = FAMILIES.index(family)
        is_ood[index] = int(index >= validation_end)

    return {
        "labels": labels,
        "delta": delta,
        "support_masks": support_masks,
        "cutout_masks": cutout_masks,
        "indentation_masks": indentation_masks,
        "signed_distance": signed_distances,
        "family_codes": family_codes,
        "is_ood": is_ood,
        "fov_mask": fov.astype(np.uint8),
    }


def save_preview(path: Path, data: dict[str, np.ndarray], linear: np.ndarray) -> None:
    indices = [int(np.flatnonzero(data["family_codes"] == code)[0]) for code in range(len(FAMILIES))]
    figure, axes = plt.subplots(len(indices), 4, figsize=(10.5, 2.15 * len(indices)), squeeze=False)
    for row, index in enumerate(indices):
        family = FAMILIES[int(data["family_codes"][index])]
        for column, (image, title) in enumerate((
            (data["labels"][index], family),
            (data["support_masks"][index], "outer support"),
            (data["cutout_masks"][index], "inward background"),
            (linear[index], "linear EIT input"),
        )):
            axes[row, column].imshow(image, cmap="viridis", interpolation="nearest")
            axes[row, column].set_title(title)
            axes[row, column].set_axis_off()
    figure.suptitle("Smooth biological-style concavity data (test families are held out)")
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    if args.samples < 240:
        raise ValueError("at least 240 samples are required")
    random.seed(args.seed)
    np.random.seed(args.seed)
    train_end = int(round(args.samples * args.train_fraction))
    validation_end = train_end + int(round(args.samples * args.validation_fraction))
    if validation_end >= args.samples:
        raise ValueError("train and validation fractions leave no test split")
    geometry = generate_geometry(args.samples, args.resolution, args.seed, train_end, validation_end)

    base = np.load(args.base_dataset.resolve(), allow_pickle=False)
    jacobian = np.asarray(base["jacobian"], dtype=np.float32)
    node_to_raw_pixel = np.asarray(base["node_to_raw_pixel"], dtype=np.int64)
    raw_pixel_to_node = np.asarray(base["raw_pixel_to_node"], dtype=np.int64)
    reconstruction_operator = np.asarray(base["reconstruction_operator"], dtype=np.float32)
    raw_delta = np.flip(geometry["delta"], axis=1).reshape(args.samples, -1)
    node_delta = raw_delta[:, node_to_raw_pixel]

    if args.forward_mode == "linear":
        clean_voltage = args.voltage_scale * (node_delta @ jacobian.T)
        contact_scales = np.ones(args.samples, dtype=np.float32)
    else:
        old_cwd = Path.cwd()
        repo_root = args.repo_root.resolve()
        ktc_root = args.ktc_root.resolve()
        os.chdir(repo_root)
        sys.path.insert(0, str(repo_root))
        try:
            from utils import solver

            matrices = solver.get_solver_matrices(
                str(ktc_root / "evaluation_datasets" / "level1" / "data1.mat"),
                1,
                0.7927,
                reference_data_path=str(ktc_root / "evaluation_datasets" / "level1" / "ref.mat"),
            )
            forward = matrices["forward_solver"]
            sigma0 = np.asarray(matrices["sigma0"], dtype=np.float64)
            z0 = np.asarray(matrices["contact_impedance"], dtype=np.float64)
            clean_voltage = np.empty((args.samples, jacobian.shape[0]), dtype=np.float32)
            contact_scales = np.empty(args.samples, dtype=np.float32)
            rng = np.random.default_rng(args.seed + 11)
            for index in range(args.samples):
                scale = float(np.exp(rng.normal(0.0, args.contact_jitter)))
                z = z0 * scale
                reference = np.asarray(forward.SolveForward(sigma0.copy(), z.copy())).reshape(-1)
                sigma = sigma0 + node_delta[index, :, None].astype(np.float64)
                measured = np.asarray(forward.SolveForward(sigma, z.copy())).reshape(-1)
                clean_voltage[index] = (args.voltage_scale * (measured - reference)).astype(np.float32)
                contact_scales[index] = scale
                if (index + 1) % 25 == 0 or index + 1 == args.samples:
                    print(f"biological nonlinear forward solves {index + 1}/{args.samples}", flush=True)
        finally:
            os.chdir(old_cwd)

    rng = np.random.default_rng(args.seed + 23)
    snr_db = rng.uniform(24.0, 58.0, size=args.samples).astype(np.float32)
    gain = rng.uniform(0.88, 1.12, size=args.samples).astype(np.float32)
    voltages = clean_voltage.copy()
    for index in range(args.samples):
        rms = float(np.sqrt(np.mean(clean_voltage[index] ** 2)))
        noise_rms = rms / (10.0 ** (float(snr_db[index]) / 20.0))
        voltages[index] = gain[index] * clean_voltage[index]
        voltages[index] += rng.normal(0.0, noise_rms + 1e-9, size=voltages.shape[1])

    linear_nodes = voltages @ reconstruction_operator.T
    raw_linear = linear_nodes[:, raw_pixel_to_node].reshape(args.samples, args.resolution, args.resolution)
    linear_images = np.flip(raw_linear, axis=1).astype(np.float32)
    train_indices = np.arange(0, train_end, dtype=np.int64)
    validation_indices = np.arange(train_end, validation_end, dtype=np.int64)
    test_indices = np.arange(validation_end, args.samples, dtype=np.int64)

    copied = {
        key: base[key]
        for key in base.files
        if key.startswith("real_") or key.startswith("calibration_")
    }
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        output,
        **geometry,
        voltages=voltages.astype(np.float32),
        clean_voltages=clean_voltage.astype(np.float32),
        linear_images=linear_images,
        train_indices=train_indices,
        validation_indices=validation_indices,
        test_indices=test_indices,
        jacobian=jacobian,
        reconstruction_operator=reconstruction_operator,
        node_to_raw_pixel=node_to_raw_pixel,
        raw_pixel_to_node=raw_pixel_to_node,
        node_coordinates=base["node_coordinates"],
        snr_db=snr_db,
        voltage_gain=gain,
        contact_impedance_scale=contact_scales,
        **copied,
    )
    save_preview(output.with_name(output.stem + "_preview.png"), geometry, linear_images)
    summary = {
        "output": str(output),
        "samples": args.samples,
        "resolution": args.resolution,
        "train_families": list(TRAIN_FAMILIES),
        "held_out_test_families": list(TEST_FAMILIES),
        "splits": {
            "train": int(train_indices.size),
            "validation": int(validation_indices.size),
            "test": int(test_indices.size),
        },
        "forward_mode": args.forward_mode,
        "contact_jitter_log_std": args.contact_jitter,
        "snr_db_range": [float(snr_db.min()), float(snr_db.max())],
        "evaluation_truth_used_for_training": False,
        "seed": args.seed,
    }
    output.with_suffix(".json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
