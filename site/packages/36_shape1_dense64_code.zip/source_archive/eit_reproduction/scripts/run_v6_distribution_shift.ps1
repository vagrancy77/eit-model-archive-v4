$ErrorActionPreference = "Stop"

$python = "E:\Anaconda\envs\myenv\python.exe"
$root = "E:\Codex"
$project = Join-Path $root "eit_reproduction"
$physicalDataset = Join-Path $project "datasets\ktc_v6_physical_mismatch_cem_v1.npz"
$measurementScript = Join-Path $project "scripts\evaluate_v6_measurement_robustness.py"
$physicalScript = Join-Path $project "scripts\evaluate_v6_physical_mismatch.py"

$runArguments = @()
$runArguments += "20260911=$(Join-Path $root 'topology_local_eit_v6_corrected_seed_20260911')"
$runArguments += "20260912=$(Join-Path $root 'topology_local_eit_v6_corrected_seed_20260912')"
$runArguments += "20260913=$(Join-Path $root 'topology_local_eit_v6_corrected_seed_20260913')"
$runArguments += "20260914=$(Join-Path $root 'topology_local_eit_v6_corrected_seed_20260914')"
if ($runArguments.Count -ne 4) {
    throw "expected four independent seed=run arguments, got $($runArguments.Count)"
}

if (-not (Test-Path -LiteralPath $physicalDataset)) {
    throw "missing exact-CEM archive: $physicalDataset"
}

Set-Location $project
$measurementOutput = Join-Path $root "topology_local_eit_v6_corrected_measurement_shift_final"
$measurementArguments = @(
    $measurementScript
    "--runs"
) + $runArguments + @(
    "--output-dir", $measurementOutput
    "--device", "cuda"
    "--batch-size", "28"
    "--bootstrap", "10000"
    "--seed", "20261103"
)
& $python @measurementArguments
if ($LASTEXITCODE -ne 0) {
    throw "v6 measurement-shift evaluation failed with exit code $LASTEXITCODE"
}

$physicalOutput = Join-Path $root "topology_local_eit_v6_corrected_physical_mismatch_final"
$physicalArguments = @(
    $physicalScript
    "--runs"
) + $runArguments + @(
    "--dataset", $physicalDataset
    "--output-dir", $physicalOutput
    "--device", "cuda"
    "--batch-size", "28"
    "--bootstrap", "10000"
    "--seed", "20261119"
)
& $python @physicalArguments
if ($LASTEXITCODE -ne 0) {
    throw "v6 exact-CEM physical-mismatch evaluation failed with exit code $LASTEXITCODE"
}

Write-Host "v6 distribution-shift workflow completed"
Write-Host "measurement: $measurementOutput"
Write-Host "exact CEM: $physicalOutput"
