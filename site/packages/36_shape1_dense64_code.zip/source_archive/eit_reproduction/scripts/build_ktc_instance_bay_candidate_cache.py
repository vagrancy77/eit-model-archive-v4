"""Cache truth-blind instance-bay candidates and inference-time evidence.

Each public KTC case is written to a separate compressed archive because the
number of admissible candidates varies by case.  Candidate generation and all
cached features are independent of the public labels.  Labels are deliberately
not written to the cache.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import torch

from audit_ktc_instance_bay_candidates import (
    fit_voltage_cv_torch,
    generate_candidates,
    generate_expanded_pure_candidates,
    nearest_resize,
)
from evaluate_ktc_cross_pool_physics_ranking import residual_scores
from train_ktc_cross_representation_ranker import candidate_descriptors


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz"
    )
    parser.add_argument(
        "--pool", type=Path,
        default=root / "outputs" / "ktc_cross_representation_pool_seed20260820" / "public_21.npz",
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=root / "outputs" / "ktc_instance_bay_candidate_cache_seed20260820",
    )
    parser.add_argument("--angles", type=int, default=12)
    parser.add_argument("--max-components", type=int, default=3)
    parser.add_argument("--min-component-fraction", type=float, default=0.0015)
    parser.add_argument("--physics-chunk", type=int, default=256)
    parser.add_argument(
        "--expanded-pure", action="store_true",
        help="Use the expanded zero-addition deformed bay bank.",
    )
    parser.add_argument("--seed", type=int, default=20260820)
    return parser.parse_args()


def pairwise_mask_iou(left: np.ndarray, right: np.ndarray) -> np.ndarray:
    """Return all foreground IoUs for left (N,H,W) and right (M,H,W)."""
    left_fg = left != 0
    right_fg = right != 0
    intersection = np.logical_and(left_fg[:, None], right_fg[None]).sum(axis=(2, 3))
    union = np.logical_or(left_fg[:, None], right_fg[None]).sum(axis=(2, 3))
    return (intersection / np.maximum(union, 1)).astype(np.float32)


def pairwise_label_agreement(left: np.ndarray, right: np.ndarray, fov: np.ndarray) -> np.ndarray:
    matches = left[:, None] == right[None]
    return matches[..., fov].mean(axis=2).astype(np.float32)


def vote_features(
    candidates: np.ndarray,
    pool_candidates: np.ndarray,
    fov: np.ndarray,
) -> np.ndarray:
    """Summarize ensemble support for each candidate's additions/removals."""
    baseline = candidates[0]
    baseline_fg = baseline != 0
    vote_fg = (pool_candidates != 0).mean(axis=0)
    vote_class_one = (pool_candidates == 1).mean(axis=0)
    vote_class_two = (pool_candidates == 2).mean(axis=0)
    output = np.zeros((len(candidates), 8), dtype=np.float32)
    for index, candidate in enumerate(candidates):
        foreground = candidate != 0
        removed = baseline_fg & ~foreground & fov
        added = ~baseline_fg & foreground & fov
        changed = (removed | added) & fov
        candidate_class_vote = np.where(
            candidate == 1, vote_class_one, np.where(candidate == 2, vote_class_two, 1.0 - vote_fg)
        )
        output[index] = (
            float(np.mean(1.0 - vote_fg[removed])) if removed.any() else 0.0,
            float(np.mean(vote_fg[removed])) if removed.any() else 0.0,
            float(np.mean(vote_fg[added])) if added.any() else 0.0,
            float(np.mean(1.0 - vote_fg[added])) if added.any() else 0.0,
            float(np.mean(candidate_class_vote[changed])) if changed.any() else 1.0,
            float(np.mean(candidate_class_vote[fov])),
            float(np.mean(np.abs(vote_fg[changed] - 0.5))) if changed.any() else 0.5,
            float(np.mean(np.var(np.stack((vote_class_one, vote_class_two, 1.0 - vote_fg)), axis=0)[changed]))
            if changed.any() else 0.0,
        )
    return output


def metadata_arrays(metadata: list[dict[str, object]]) -> dict[str, np.ndarray]:
    kind_code = {"identity": 0, "expansion": 1, "bay": 2}
    profile_code = {"": 0, "u": 1, "v": 2, "keyhole": 3}

    def number(row: dict[str, object], key: str, default: float = 0.0) -> float:
        value = row.get(key, default)
        result = float(value) if value is not None else default
        return result if math.isfinite(result) else default

    angles = np.deg2rad([number(row, "angle_degrees") for row in metadata])
    return {
        "meta_kind": np.asarray([kind_code[str(row["kind"])] for row in metadata], dtype=np.int8),
        "meta_class_id": np.asarray([number(row, "class_id") for row in metadata], dtype=np.int8),
        "meta_component_rank": np.asarray(
            [number(row, "component_rank", -1.0) for row in metadata], dtype=np.int8
        ),
        "meta_profile": np.asarray(
            [profile_code[str(row.get("profile", ""))] for row in metadata], dtype=np.int8
        ),
        "meta_angle_sin": np.sin(angles).astype(np.float32),
        "meta_angle_cos": np.cos(angles).astype(np.float32),
        "meta_depth": np.asarray([number(row, "depth_fraction") for row in metadata], dtype=np.float32),
        "meta_width": np.asarray([number(row, "width_fraction") for row in metadata], dtype=np.float32),
        "meta_expansion": np.asarray(
            [number(row, "expansion_fraction") for row in metadata], dtype=np.float32
        ),
        "meta_removed": np.asarray([number(row, "removed_fraction") for row in metadata], dtype=np.float32),
        "meta_added": np.asarray([number(row, "added_fraction") for row in metadata], dtype=np.float32),
        "meta_open": np.asarray(
            [number(row, "open_removed_fraction", 1.0) for row in metadata], dtype=np.float32
        ),
        "meta_new_holes": np.asarray(
            [number(row, "new_hole_pixels") for row in metadata], dtype=np.float32
        ),
        "meta_radius": np.asarray([number(row, "equivalent_radius") for row in metadata], dtype=np.float32),
        "meta_span": np.asarray([number(row, "span") for row in metadata], dtype=np.float32),
    }


def case_filename(case_id: str) -> str:
    return case_id.replace("/", "__") + ".npz"


def main() -> None:
    args = parse_args()
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    archive = np.load(args.dataset.resolve(), allow_pickle=False)
    pool = np.load(args.pool.resolve(), allow_pickle=False)
    pool_names = np.asarray(pool["candidate_names"])
    baseline_index = list(pool_names).index("fusion_primary")
    baselines = np.asarray(pool["candidates"][baseline_index], dtype=np.uint8)
    pool_candidates = np.asarray(pool["candidates"], dtype=np.uint8)
    ids = np.asarray(archive["real_ids"])
    images = np.asarray(archive["real_linear_images"], dtype=np.float32)
    voltages = np.asarray(archive["real_voltages"], dtype=np.float32)
    fov = np.asarray(archive["fov_mask"], dtype=bool)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    jacobian = torch.from_numpy(np.asarray(archive["jacobian"], dtype=np.float32)).to(device)
    node_map = torch.from_numpy(np.asarray(archive["node_to_raw_pixel"], dtype=np.int64)).to(device)
    manifest: list[dict[str, object]] = []
    print(f"device={device}; cases={len(ids)}; truth-blind cache={output_dir}", flush=True)
    for case_index, (case_id_value, baseline, image, voltage) in enumerate(
        zip(ids, baselines, images, voltages)
    ):
        case_id = str(case_id_value)
        path = output_dir / case_filename(case_id)
        generator = generate_expanded_pure_candidates if args.expanded_pure else generate_candidates
        candidates, metadata = generator(
            baseline, args.angles, args.max_components, args.min_component_fraction
        )
        candidates64 = nearest_resize(candidates, 64).astype(np.uint8)
        pool64 = nearest_resize(pool_candidates[:, case_index], 64).astype(np.uint8)
        fold_residuals = fit_voltage_cv_torch(
            candidates64, voltage, jacobian, node_map, args.physics_chunk
        ).astype(np.float32)
        descriptors = candidate_descriptors(
            image[None], candidates64[:, None], fov
        )[0].astype(np.float32)
        fixed_scores, contrasts, saturated = residual_scores(
            candidates64[:, None], voltage[None], archive["jacobian"], archive["node_to_raw_pixel"]
        )
        pair_iou = pairwise_mask_iou(candidates64, pool64)
        pair_agreement = pairwise_label_agreement(candidates64, pool64, fov)
        votes = vote_features(candidates64, pool64, fov)
        payload: dict[str, np.ndarray] = {
            "case_id": np.asarray(case_id),
            "candidates": candidates,
            "candidates64": candidates64,
            "metadata_json": np.asarray([json.dumps(row, sort_keys=True) for row in metadata]),
            "descriptors": descriptors,
            "cv_fold_residuals": fold_residuals,
            "pool_names": pool_names,
            "pool_foreground_iou": pair_iou,
            "pool_label_agreement": pair_agreement,
            "vote_features": votes,
            "fixed_contrasts": contrasts[0].astype(np.float32),
            "fixed_saturated": np.asarray(bool(saturated[0])),
        }
        for name, values in fixed_scores.items():
            payload[f"fixed_{name}"] = values[:, 0].astype(np.float32)
        payload.update(metadata_arrays(metadata))
        np.savez_compressed(path, **payload)
        manifest.append({"id": case_id, "file": path.name, "candidate_count": len(candidates)})
        print(
            f"{case_index + 1:02d}/{len(ids)} {case_id}: {len(candidates)} candidates -> {path.name}",
            flush=True,
        )
    summary = {
        "status": "truth-blind inference cache",
        "public_labels_read": False,
        "candidate_family": (
            "expanded pure deformed exterior-connected bay"
            if args.expanded_pure else "instance-wise exterior-connected parametric bay"
        ),
        "pool_names": pool_names.tolist(),
        "device": str(device),
        "cases": manifest,
        "args": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
    }
    (output_dir / "manifest.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
