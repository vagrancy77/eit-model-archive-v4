"""Nested level-held-out, topology-safe ranker for instance-bay candidates.

The deployable method has two stages.  A case-balanced ridge ensemble predicts
each candidate's IoU gain relative to the frozen neural baseline.  A separate
identity fallback accepts a shape edit only when the ensemble lower-confidence
score and vote agreement clear thresholds calibrated on inner, complete-level
held-out predictions.  The strict-inward case list is used only in the final
report and never in fitting, calibration, or candidate selection.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy import ndimage as ndi

from audit_ktc_instance_bay_candidates import STRICT_INWARD_IDS
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_cross_representation_pixel_fusion import (
    foreground_iou_per_case,
    paired_bootstrap,
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz"
    )
    parser.add_argument(
        "--cache-dir", type=Path,
        default=root / "outputs" / "ktc_instance_bay_candidate_cache_seed20260820",
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=root / "outputs" / "ktc_instance_bay_nested_ranker_seed20260820",
    )
    parser.add_argument("--bootstrap-repetitions", type=int, default=10000)
    parser.add_argument("--fold-limit", type=int, default=0)
    parser.add_argument("--seed", type=int, default=20260820)
    return parser.parse_args()


def case_filename(case_id: str) -> str:
    return case_id.replace("/", "__") + ".npz"


def foreground_iou(truth: np.ndarray, prediction: np.ndarray) -> float:
    target = truth != 0
    estimate = prediction != 0
    return float(np.logical_and(target, estimate).sum() / max(1, np.logical_or(target, estimate).sum()))


def boundary_f1_per_case(truths: np.ndarray, predictions: np.ndarray, tolerance: int = 2) -> np.ndarray:
    structure = np.ones((3, 3), dtype=np.uint8)
    result = np.zeros(len(truths), dtype=np.float64)
    for index, (truth, prediction) in enumerate(zip(truths, predictions)):
        target = truth != 0
        estimate = prediction != 0
        target_boundary = ndi.binary_dilation(target, structure=structure) ^ ndi.binary_erosion(target, structure=structure)
        estimate_boundary = ndi.binary_dilation(estimate, structure=structure) ^ ndi.binary_erosion(estimate, structure=structure)
        target_near = ndi.binary_dilation(target_boundary, iterations=tolerance)
        estimate_near = ndi.binary_dilation(estimate_boundary, iterations=tolerance)
        precision = np.logical_and(estimate_boundary, target_near).sum() / max(1, estimate_boundary.sum())
        recall = np.logical_and(target_boundary, estimate_near).sum() / max(1, target_boundary.sum())
        result[index] = 2.0 * precision * recall / max(precision + recall, 1e-12)
    return result


@dataclass
class CaseData:
    case_id: str
    level: str
    candidates: np.ndarray
    features: np.ndarray
    targets: np.ndarray
    removed: np.ndarray
    added: np.ndarray
    change: np.ndarray
    new_holes: np.ndarray
    open_fraction: np.ndarray
    kind: np.ndarray
    class_id: np.ndarray
    local_change: np.ndarray
    added_polarity_evidence: np.ndarray


@dataclass
class RidgeModel:
    mean: np.ndarray
    scale: np.ndarray
    coefficients: np.ndarray

    def predict(self, features: np.ndarray) -> np.ndarray:
        standardized = (features - self.mean) / self.scale
        design = np.concatenate((np.ones((len(features), 1)), standardized), axis=1)
        return design @ self.coefficients


def one_hot(values: np.ndarray, count: int) -> np.ndarray:
    return np.eye(count, dtype=np.float32)[np.clip(values.astype(np.int64), 0, count - 1)]


def finite_gain(values: np.ndarray) -> np.ndarray:
    reference = max(abs(float(values[0])), 1e-12)
    return np.clip(np.nan_to_num(1.0 - values / reference, nan=-2.0, posinf=-2.0, neginf=-2.0), -2.0, 1.0)


def build_case_features(cache: np.lib.npyio.NpzFile) -> np.ndarray:
    descriptors = np.asarray(cache["descriptors"], dtype=np.float32)
    descriptor_delta = descriptors - descriptors[:1]
    baseline_descriptor = np.broadcast_to(descriptors[:1], descriptors.shape)
    cv = np.asarray(cache["cv_fold_residuals"], dtype=np.float32)
    cv_gain = np.clip(1.0 - cv / np.maximum(cv[:1], 1e-12), -2.0, 1.0)
    cv_summary = np.stack((
        cv_gain.mean(axis=1), cv_gain.std(axis=1), cv_gain.min(axis=1),
        cv_gain.max(axis=1), (cv_gain > 0.0).mean(axis=1),
    ), axis=1)
    fixed = np.stack([
        finite_gain(np.asarray(cache[f"fixed_{name}"], dtype=np.float32))
        for name in ("global_nmse", "drive_median_nmse", "cosine", "hybrid_ratio")
    ], axis=1)
    pool_iou = np.asarray(cache["pool_foreground_iou"], dtype=np.float32)
    pool_agreement = np.asarray(cache["pool_label_agreement"], dtype=np.float32)
    pool_features = np.concatenate((
        pool_iou - pool_iou[:1],
        pool_agreement - pool_agreement[:1],
        np.stack((
            pool_iou.mean(axis=1), pool_iou.max(axis=1), pool_iou.std(axis=1),
            pool_agreement.mean(axis=1), pool_agreement.max(axis=1), pool_agreement.std(axis=1),
        ), axis=1),
    ), axis=1)
    kind = np.asarray(cache["meta_kind"], dtype=np.int64)
    class_id = np.asarray(cache["meta_class_id"], dtype=np.int64)
    component = np.asarray(cache["meta_component_rank"], dtype=np.int64) + 1
    profile = np.asarray(cache["meta_profile"], dtype=np.int64)
    metadata = np.stack([
        np.asarray(cache[key], dtype=np.float32)
        for key in (
            "meta_angle_sin", "meta_angle_cos", "meta_depth", "meta_width",
            "meta_expansion", "meta_removed", "meta_added", "meta_open",
            "meta_radius", "meta_span",
        )
    ], axis=1)
    categorical = np.concatenate((
        one_hot(kind, 3), one_hot(class_id, 3), one_hot(component, 4), one_hot(profile, 4)
    ), axis=1)
    votes = np.asarray(cache["vote_features"], dtype=np.float32)
    saturation = np.full((len(descriptors), 1), float(bool(cache["fixed_saturated"])), dtype=np.float32)
    return np.concatenate((
        descriptor_delta, descriptors, baseline_descriptor, cv_gain, cv_summary,
        fixed, pool_features, votes, metadata, categorical, saturation,
    ), axis=1).astype(np.float64)


def load_cases(dataset: Path, cache_dir: Path) -> tuple[list[CaseData], np.ndarray, np.ndarray]:
    archive = np.load(dataset.resolve(), allow_pickle=False)
    ids = np.asarray(archive["real_ids"])
    truths = np.asarray(archive["real_labels"], dtype=np.uint8)
    cases: list[CaseData] = []
    for index, case_id_value in enumerate(ids):
        case_id = str(case_id_value)
        cache = np.load(cache_dir.resolve() / case_filename(case_id), allow_pickle=False)
        candidates = np.asarray(cache["candidates"], dtype=np.uint8)
        ious = np.asarray([foreground_iou(truths[index], value) for value in candidates])
        removed = np.asarray(cache["meta_removed"], dtype=np.float64)
        added = np.asarray(cache["meta_added"], dtype=np.float64)
        descriptors = np.asarray(cache["descriptors"], dtype=np.float64)
        class_id = np.asarray(cache["meta_class_id"], dtype=np.int64)
        added_polarity = np.where(
            class_id == 1, -descriptors[:, 17],
            np.where(class_id == 2, descriptors[:, 17], 0.0),
        )
        cases.append(CaseData(
            case_id=case_id,
            level=case_id.split("/")[0],
            candidates=candidates,
            features=build_case_features(cache),
            targets=ious - ious[0],
            removed=removed,
            added=added,
            change=removed + added,
            new_holes=np.asarray(cache["meta_new_holes"], dtype=np.float64),
            open_fraction=np.asarray(cache["meta_open"], dtype=np.float64),
            kind=np.asarray(cache["meta_kind"], dtype=np.int64),
            class_id=class_id,
            local_change=descriptors[:, 3],
            added_polarity_evidence=added_polarity,
        ))
    return cases, truths, ids


def fit_ridge(
    cases: list[CaseData],
    regularization: float,
    positive_weight: float,
    kind_balance: float,
) -> RidgeModel:
    features = np.concatenate([case.features for case in cases])
    targets = np.concatenate([np.clip(case.targets, -0.30, 0.20) for case in cases])
    all_weights: list[np.ndarray] = []
    for case in cases:
        count = len(case.targets)
        weights = np.ones(count, dtype=np.float64)
        weights *= 1.0 + positive_weight * (case.targets > 0.002)
        if kind_balance > 0:
            # Infer kind from one-hot columns located immediately before the
            # final saturation feature: 3+3+4+4 categorical dimensions.
            kind_one_hot = case.features[:, -15:-12]
            kinds = kind_one_hot.argmax(axis=1)
            for kind in np.unique(kinds):
                selected = kinds == kind
                weights[selected] *= (count / max(1, selected.sum())) ** kind_balance
        weights /= max(float(weights.sum()), 1e-12)
        all_weights.append(weights / len(cases))
    weights = np.concatenate(all_weights)
    mean = np.sum(features * weights[:, None], axis=0)
    variance = np.sum(np.square(features - mean) * weights[:, None], axis=0)
    scale = np.sqrt(variance).clip(min=1e-5)
    standardized = (features - mean) / scale
    design = np.concatenate((np.ones((len(features), 1)), standardized), axis=1)
    root_weight = np.sqrt(weights * len(weights) / max(float(weights.sum()), 1e-12))
    weighted_design = design * root_weight[:, None]
    weighted_target = targets * root_weight
    penalty = np.eye(design.shape[1]) * regularization
    penalty[0, 0] = 0.0
    coefficients = np.linalg.solve(
        weighted_design.T @ weighted_design + penalty,
        weighted_design.T @ weighted_target,
    )
    return RidgeModel(mean, scale, coefficients)


def predict_ensemble(models: list[RidgeModel], case: CaseData) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    matrix = np.stack([model.predict(case.features) for model in models])
    matrix -= matrix[:, :1]
    return matrix.mean(axis=0), matrix.std(axis=0), (matrix > 0.0).mean(axis=0)


@dataclass(frozen=True)
class Policy:
    threshold: float
    uncertainty_multiplier: float
    minimum_model_agreement: float
    max_change: float
    max_removal: float


POLICIES = tuple(
    Policy(threshold, uncertainty, agreement, max_change, max_removal)
    for threshold in (0.0025, 0.005, 0.010, 0.020, 0.040, 1.0)
    for uncertainty in (0.0, 0.5, 1.0)
    for agreement in (0.50, 0.67, 0.84, 1.0)
    for max_change in (0.18, 0.36, 0.62)
    for max_removal in (0.18, 0.36, 0.62)
)


def choose_candidate(
    case: CaseData,
    mean: np.ndarray,
    std: np.ndarray,
    agreement: np.ndarray,
    policy: Policy,
) -> tuple[int, float]:
    lower = mean - policy.uncertainty_multiplier * std
    valid = (
        (case.change <= policy.max_change)
        & (case.removed <= policy.max_removal)
        & (case.new_holes == 0)
        & (case.open_fraction >= 0.995)
        & (agreement >= policy.minimum_model_agreement)
    )
    valid[0] = True
    score = np.where(valid, lower, -np.inf)
    choice = int(np.argmax(score))
    gain = float(score[choice])
    if choice == 0 or gain < policy.threshold:
        return 0, gain
    return choice, gain


def inner_ensemble_predictions(
    cases: list[CaseData],
    regularization: float,
    positive_weight: float,
    kind_balance: float,
) -> dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]]:
    levels = sorted({case.level for case in cases})
    predictions: dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]] = {}
    for held_level in levels:
        held_cases = [case for case in cases if case.level == held_level]
        remaining_levels = [level for level in levels if level != held_level]
        models = [
            fit_ridge(
                [case for case in cases if case.level not in (held_level, omitted_level)],
                regularization, positive_weight, kind_balance,
            )
            for omitted_level in remaining_levels
        ]
        models.append(fit_ridge(
            [case for case in cases if case.level != held_level],
            regularization, positive_weight, kind_balance,
        ))
        for case in held_cases:
            predictions[case.case_id] = predict_ensemble(models, case)
    return predictions


def policy_result(
    cases: list[CaseData],
    predictions: dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]],
    policy: Policy,
) -> dict[str, object]:
    choices: list[int] = []
    deltas: list[float] = []
    for case in cases:
        choice, _ = choose_candidate(case, *predictions[case.case_id], policy)
        choices.append(choice)
        deltas.append(float(case.targets[choice]))
    delta = np.asarray(deltas)
    changed = np.asarray(choices) != 0
    return {
        "choices": choices,
        "mean_delta": float(delta.mean()),
        "minimum_delta": float(delta.min()),
        "harmed": int(np.count_nonzero(delta < -1e-9)),
        "improved": int(np.count_nonzero(delta > 1e-9)),
        "material_improved": int(np.count_nonzero(delta >= 0.01)),
        "changed": int(changed.sum()),
        "mean_changed_delta": float(delta[changed].mean()) if changed.any() else 0.0,
    }


def calibrate_outer(
    training_cases: list[CaseData],
) -> tuple[dict[str, float], Policy, list[RidgeModel], list[dict[str, object]]]:
    rows: list[dict[str, object]] = []
    best: tuple[tuple[float, ...], dict[str, float], Policy] | None = None
    for regularization in (0.3, 1.0, 3.0, 10.0, 30.0, 100.0):
        for positive_weight in (0.0, 2.0, 6.0):
            for kind_balance in (0.0, 0.5, 1.0):
                print(
                    f"  inner calibration ridge={regularization:g}, "
                    f"positive_weight={positive_weight:g}, kind_balance={kind_balance:g}",
                    flush=True,
                )
                inner = inner_ensemble_predictions(
                    training_cases, regularization, positive_weight, kind_balance
                )
                for policy in POLICIES:
                    result = policy_result(training_cases, inner, policy)
                    # The safety gate is calibrated without subgroup labels.
                    # Any inner-OOF harm makes a policy ineligible.  Identity
                    # is always present, so an eligible fallback always exists.
                    eligible = int(result["harmed"]) == 0
                    row = {
                        "regularization": regularization,
                        "positive_weight": positive_weight,
                        "kind_balance": kind_balance,
                        **policy.__dict__,
                        **{key: value for key, value in result.items() if key != "choices"},
                        "eligible": eligible,
                    }
                    rows.append(row)
                    key = (
                        1.0 if eligible else 0.0,
                        float(result["mean_delta"]),
                        float(result["material_improved"]),
                        float(result["improved"]),
                        -float(result["changed"]),
                        -policy.threshold,
                    )
                    parameters = {
                        "regularization": regularization,
                        "positive_weight": positive_weight,
                        "kind_balance": kind_balance,
                    }
                    if best is None or key > best[0]:
                        best = (key, parameters, policy)
    assert best is not None
    parameters, policy = best[1], best[2]
    levels = sorted({case.level for case in training_cases})
    models = [
        fit_ridge(
            [case for case in training_cases if case.level != omitted],
            parameters["regularization"], parameters["positive_weight"], parameters["kind_balance"],
        )
        for omitted in levels
    ]
    models.append(fit_ridge(
        training_cases, parameters["regularization"], parameters["positive_weight"],
        parameters["kind_balance"],
    ))
    return parameters, policy, models, rows


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        return
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def topology_checks(baseline: np.ndarray, prediction: np.ndarray) -> dict[str, int | float]:
    before = baseline != 0
    after = prediction != 0
    before_holes = ndi.binary_fill_holes(before) & ~before
    after_holes = ndi.binary_fill_holes(after) & ~after
    removed = before & ~after
    if removed.any():
        background_components, _ = ndi.label(~after, structure=np.ones((3, 3), dtype=np.uint8))
        border_ids = np.unique(np.concatenate((
            background_components[0], background_components[-1],
            background_components[:, 0], background_components[:, -1],
        )))
        exterior = np.isin(background_components, border_ids[border_ids != 0])
        exterior_fraction = float(np.logical_and(removed, exterior).sum() / removed.sum())
    else:
        exterior_fraction = 1.0
    return {
        "new_hole_pixels": int(np.logical_and(after_holes, ~before_holes).sum()),
        "removed_exterior_connected_fraction": exterior_fraction,
    }


def save_montage(
    path: Path,
    truths: np.ndarray,
    baselines: np.ndarray,
    predictions: np.ndarray,
    oracles: np.ndarray,
    ids: np.ndarray,
    selected: np.ndarray,
) -> None:
    before = foreground_iou_per_case(truths, baselines)
    after = foreground_iou_per_case(truths, predictions)
    best = foreground_iou_per_case(truths, oracles)
    figure, axes = plt.subplots(len(selected), 5, figsize=(13.0, 2.45 * len(selected)), squeeze=False)
    for row, index in enumerate(selected):
        change = baselines[index] != predictions[index]
        panels = (
            (truths[index], f"{ids[index]} truth", "viridis", 2),
            (baselines[index], f"baseline IoU {before[index]:.3f}", "viridis", 2),
            (predictions[index], f"nested ranker IoU {after[index]:.3f}\ndelta {after[index]-before[index]:+.3f}", "viridis", 2),
            (oracles[index], f"candidate oracle {best[index]:.3f}", "viridis", 2),
            (change, "deployed change mask", "magma", 1),
        )
        for column, (image, title, cmap, high) in enumerate(panels):
            axes[row, column].imshow(image, cmap=cmap, vmin=0, vmax=high, interpolation="nearest")
            axes[row, column].set_title(title, fontsize=8)
            axes[row, column].set_axis_off()
    figure.suptitle("Physics- and topology-aware instance-bay reconstruction (complete-level OOF)", fontsize=13)
    figure.tight_layout()
    figure.savefig(path, dpi=190)
    plt.close(figure)


def summarize_group(
    name: str,
    selected: np.ndarray,
    truths: np.ndarray,
    baselines: np.ndarray,
    predictions: np.ndarray,
    oracles: np.ndarray,
    ids: np.ndarray,
    repetitions: int,
    seed: int,
) -> dict[str, object]:
    if not selected.any():
        return {"case_count": 0, "status": "not evaluated in partial fold run"}
    before = foreground_iou_per_case(truths[selected], baselines[selected])
    after = foreground_iou_per_case(truths[selected], predictions[selected])
    delta = after - before
    baseline_metrics, _ = evaluate_real_predictions(
        name + "_baseline", baselines[selected], truths[selected], ids[selected]
    )
    final_metrics, _ = evaluate_real_predictions(
        name + "_final", predictions[selected], truths[selected], ids[selected]
    )
    oracle_metrics, _ = evaluate_real_predictions(
        name + "_oracle", oracles[selected], truths[selected], ids[selected]
    )
    return {
        "case_count": int(selected.sum()),
        "baseline": baseline_metrics,
        "final": final_metrics,
        "oracle": oracle_metrics,
        "changed_cases": int(np.count_nonzero(np.any(
            predictions[selected] != baselines[selected], axis=(1, 2)
        ))),
        "improved_cases": int(np.count_nonzero(delta > 1e-9)),
        "harmed_cases": int(np.count_nonzero(delta < -1e-9)),
        "minimum_iou_delta": float(delta.min()),
        "bootstrap_iou": paired_bootstrap(
            truths[selected], baselines[selected], predictions[selected], repetitions, seed
        ),
    }


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    cases, truths, ids = load_cases(args.dataset, args.cache_dir)
    levels = sorted({case.level for case in cases})
    if args.fold_limit > 0:
        levels = levels[: args.fold_limit]
    predictions = np.stack([case.candidates[0] for case in cases])
    choices = np.zeros(len(cases), dtype=np.int64)
    predicted = np.zeros(len(cases), dtype=bool)
    confidence = np.zeros(len(cases), dtype=np.float64)
    fold_records: list[dict[str, object]] = []
    calibration_rows: list[dict[str, object]] = []
    for fold, outer_level in enumerate(levels):
        training_cases = [case for case in cases if case.level != outer_level]
        parameters, policy, models, calibration = calibrate_outer(training_cases)
        for row in calibration:
            calibration_rows.append({"outer_level": outer_level, **row})
        outer_choices: list[int] = []
        for index, case in enumerate(cases):
            if case.level != outer_level:
                continue
            mean, std, agreement = predict_ensemble(models, case)
            choice, lower_score = choose_candidate(case, mean, std, agreement, policy)
            predictions[index] = case.candidates[choice]
            choices[index] = choice
            confidence[index] = lower_score
            predicted[index] = True
            outer_choices.append(choice)
        selected_calibration = max(
            (row for row in calibration if bool(row["eligible"])),
            key=lambda row: (
                float(row["mean_delta"]), float(row["material_improved"]),
                float(row["improved"]), -float(row["changed"]), -float(row["threshold"]),
            ),
        )
        fold_record = {
            "outer_level": outer_level,
            **parameters,
            **policy.__dict__,
            "inner_oof_mean_delta": selected_calibration["mean_delta"],
            "inner_oof_changed": selected_calibration["changed"],
            "inner_oof_improved": selected_calibration["improved"],
            "inner_oof_harmed": selected_calibration["harmed"],
            "outer_choices": outer_choices,
        }
        fold_records.append(fold_record)
        print(f"fold {fold + 1}/{len(levels)} {outer_level}: {fold_record}", flush=True)
    baselines = np.stack([case.candidates[0] for case in cases])
    oracles = np.stack([
        case.candidates[int(np.argmax(case.targets))] for case in cases
    ])
    before = foreground_iou_per_case(truths, baselines)
    after = foreground_iou_per_case(truths, predictions)
    oracle_iou = foreground_iou_per_case(truths, oracles)
    boundary_before = boundary_f1_per_case(truths, baselines)
    boundary_after = boundary_f1_per_case(truths, predictions)
    rows: list[dict[str, object]] = []
    for index, case in enumerate(cases):
        topology = topology_checks(baselines[index], predictions[index])
        rows.append({
            "id": case.case_id,
            "strict_inward": case.case_id in STRICT_INWARD_IDS,
            "predicted": bool(predicted[index]),
            "choice": int(choices[index]),
            "confidence_lower_score": float(confidence[index]),
            "baseline_iou": float(before[index]),
            "final_iou": float(after[index]),
            "delta_iou": float(after[index] - before[index]),
            "oracle_iou": float(oracle_iou[index]),
            "baseline_boundary_f1": float(boundary_before[index]),
            "final_boundary_f1": float(boundary_after[index]),
            "delta_boundary_f1": float(boundary_after[index] - boundary_before[index]),
            **topology,
        })
    strict = np.asarray([case.case_id in STRICT_INWARD_IDS for case in cases]) & predicted
    ordinary = ~np.asarray([case.case_id in STRICT_INWARD_IDS for case in cases]) & predicted
    complete = predicted.copy()
    groups = {
        "all": summarize_group(
            "all", complete, truths, baselines, predictions, oracles, ids,
            args.bootstrap_repetitions, args.seed,
        ),
        "strict_inward": summarize_group(
            "strict_inward", strict, truths, baselines, predictions, oracles, ids,
            args.bootstrap_repetitions, args.seed + 1,
        ),
        "ordinary": summarize_group(
            "ordinary", ordinary, truths, baselines, predictions, oracles, ids,
            args.bootstrap_repetitions, args.seed + 2,
        ),
    }
    write_csv(output_dir / "public_case_metrics.csv", rows)
    write_csv(output_dir / "calibration_grid.csv", calibration_rows)
    (output_dir / "fold_policies.json").write_text(
        json.dumps(fold_records, indent=2), encoding="utf-8"
    )
    np.savez_compressed(
        output_dir / "predictions.npz", ids=ids, truths=truths, baseline=baselines,
        prediction=predictions, oracle=oracles, choices=choices,
        confidence_lower_score=confidence, predicted_mask=predicted,
    )
    if strict.any():
        save_montage(
            output_dir / "strict_inward_nested_ranker.png", truths, baselines,
            predictions, oracles, ids, np.flatnonzero(strict),
        )
    summary = {
        "method": "case-balanced ridge ensemble plus nested level-held-out identity safety gate",
        "status": "deployable complete-level out-of-fold evaluation" if predicted.all() else "partial smoke test",
        "test_truth_used_for_candidate_generation_or_features": False,
        "outer_fold_truth_used_for_model_or_policy_selection": False,
        "strict_inward_ids_used_for_selection": False,
        "identity_fallback_always_available": True,
        "topology_constraints": {
            "exterior_connected_removed_region": True,
            "forbid_new_holes": True,
            "preserve_lesion_classes_and_other_instances": True,
        },
        "groups": groups,
        "fold_policies": fold_records,
        "args": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
    }
    (output_dir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(groups, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
