"""Validation-only fusion of complementary non-convex EIT segmenters.

The fusion weights and pooling rule are selected exclusively on the synthetic
validation split. Synthetic test and public KTC evaluation labels are read only
after that decision is frozen.
"""
from __future__ import annotations

import argparse
import csv
import itertools
import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader

from train_ktc_concavity_network import (
    InputAdapter,
    aggregate_rows,
    confusion_metrics,
    indentation_mask,
    save_focus_montage,
    save_real_montage,
    write_rows,
)
from train_ktc_concavity_network_v2 import (
    ConcavityNetV2,
    EITDatasetV2,
    ModelSpec,
    evaluate_real_predictions,
    selection_score,
)


@dataclass(frozen=True)
class Candidate:
    pooling: str
    weights: tuple[float, ...]

    @property
    def name(self) -> str:
        weights = "_".join(f"{value:.2f}" for value in self.weights)
        return f"{self.pooling}_{weights}"


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument(
        "--checkpoints",
        nargs="+",
        type=Path,
        required=True,
        help="Ordered checkpoints to combine; their order defines the reported weights.",
    )
    parser.add_argument("--names", nargs="+", required=True)
    parser.add_argument("--output-dir", type=Path, default=root / "outputs" / "ktc_concavity_fusion")
    parser.add_argument("--batch-size", type=int, default=20)
    parser.add_argument("--pair-step", type=float, default=0.05)
    parser.add_argument("--multi-step", type=float, default=0.10)
    parser.add_argument("--iou-tolerance", type=float, default=0.005)
    parser.add_argument("--boundary-tolerance", type=float, default=0.010)
    parser.add_argument("--fixed-weights", nargs="+", type=float)
    parser.add_argument("--fixed-pooling", choices=("probability", "log_probability"))
    return parser.parse_args()


def load_model(path: Path, device: torch.device) -> ConcavityNetV2:
    state = torch.load(path.resolve(), map_location=device, weights_only=False)
    spec = ModelSpec(**state["spec"])
    model = ConcavityNetV2(int(state["base_channels"]), spec).to(device)
    model.load_state_dict(state["model"])
    model.eval()
    return model


@torch.no_grad()
def synthetic_probabilities(
    models: list[ConcavityNetV2],
    adapter: InputAdapter,
    archive: np.lib.npyio.NpzFile,
    indices: np.ndarray,
    device: torch.device,
    batch_size: int,
) -> tuple[list[np.ndarray], np.ndarray, np.ndarray]:
    loader = DataLoader(EITDatasetV2(archive, indices), batch_size=batch_size, shuffle=False, num_workers=0)
    component_chunks: list[list[np.ndarray]] = [[] for _ in models]
    truths: list[np.ndarray] = []
    indentations: list[np.ndarray] = []
    for batch in loader:
        image = adapter(batch["image"].to(device))
        voltage = batch["input_voltage"].to(device)
        for chunks, model in zip(component_chunks, models):
            probability = torch.softmax(model(image, voltage)["logits"], dim=1)
            chunks.append(probability.cpu().numpy().astype(np.float32))
        truths.append(batch["labels"].numpy())
        indentations.append(batch["indent"].numpy()[:, 0])
    return (
        [np.concatenate(chunks) for chunks in component_chunks],
        np.concatenate(truths),
        np.concatenate(indentations),
    )


@torch.no_grad()
def real_probabilities(
    models: list[ConcavityNetV2],
    adapter: InputAdapter,
    images: np.ndarray,
    voltages: np.ndarray,
    device: torch.device,
    batch_size: int,
) -> list[np.ndarray]:
    component_chunks: list[list[np.ndarray]] = [[] for _ in models]
    for start in range(0, len(images), batch_size):
        image = torch.from_numpy(images[start : start + batch_size, None].astype(np.float32)).to(device)
        voltage = torch.from_numpy(voltages[start : start + batch_size].astype(np.float32)).to(device)
        image = adapter(image)
        for chunks, model in zip(component_chunks, models):
            logits = model(image, voltage)["logits"]
            logits = F.interpolate(logits, size=(256, 256), mode="bilinear", align_corners=False)
            chunks.append(torch.softmax(logits, dim=1).cpu().numpy().astype(np.float32))
    return [np.concatenate(chunks) for chunks in component_chunks]


def candidate_grid(count: int, pair_step: float, multi_step: float) -> list[Candidate]:
    if count < 2:
        raise ValueError("At least two checkpoints are required for fusion")
    weights: set[tuple[float, ...]] = set()
    for index in range(count):
        one_hot = [0.0] * count
        one_hot[index] = 1.0
        weights.add(tuple(one_hot))
    pair_denominator = int(round(1.0 / pair_step))
    for left, right in itertools.combinations(range(count), 2):
        for numerator in range(1, pair_denominator):
            item = [0.0] * count
            item[left] = numerator / pair_denominator
            item[right] = 1.0 - item[left]
            weights.add(tuple(item))
    multi_denominator = int(round(1.0 / multi_step))
    if count == 3:
        for first in range(multi_denominator + 1):
            for second in range(multi_denominator + 1 - first):
                third = multi_denominator - first - second
                weights.add(tuple(value / multi_denominator for value in (first, second, third)))
    candidates = []
    for pooling in ("probability", "log_probability"):
        candidates.extend(Candidate(pooling, values) for values in sorted(weights))
    return candidates


def blend(probabilities: list[np.ndarray], candidate: Candidate) -> np.ndarray:
    active = [(probability, weight) for probability, weight in zip(probabilities, candidate.weights) if weight > 0]
    if candidate.pooling == "probability":
        score = sum(weight * probability for probability, weight in active)
    elif candidate.pooling == "log_probability":
        score = sum(weight * np.log(np.clip(probability, 1e-7, 1.0)) for probability, weight in active)
    else:
        raise ValueError(candidate.pooling)
    return np.argmax(score, axis=1).astype(np.uint8)


def metrics_for_predictions(
    predictions: np.ndarray,
    truths: np.ndarray,
    indentations: np.ndarray,
) -> dict[str, float]:
    rows = [
        confusion_metrics(truth, prediction, indentation)
        for truth, prediction, indentation in zip(truths, predictions, indentations)
    ]
    return aggregate_rows(rows)


def select_candidate(
    probabilities: list[np.ndarray],
    truths: np.ndarray,
    indentations: np.ndarray,
    candidates: list[Candidate],
    iou_tolerance: float,
    boundary_tolerance: float,
) -> tuple[Candidate, list[dict[str, object]], dict[str, float]]:
    rows: list[dict[str, object]] = []
    for candidate in candidates:
        metrics = metrics_for_predictions(blend(probabilities, candidate), truths, indentations)
        rows.append(
            {
                "candidate": candidate.name,
                "pooling": candidate.pooling,
                "weights": list(candidate.weights),
                "selection_score": selection_score(metrics),
                **metrics,
            }
        )
    component_rows = [row for row in rows if sum(weight > 0 for weight in row["weights"]) == 1]
    reference_iou = max(float(row["foreground_iou"]) for row in component_rows)
    reference_boundary = max(float(row["boundary_f1"]) for row in component_rows)
    eligible = [
        row
        for row in rows
        if float(row["foreground_iou"]) >= reference_iou - iou_tolerance
        and float(row["boundary_f1"]) >= reference_boundary - boundary_tolerance
    ]
    if not eligible:
        raise RuntimeError("No fusion candidate satisfies the predeclared region and boundary constraints")
    best = max(eligible, key=lambda row: (float(row["selection_score"]), float(row["concavity_score"])))
    selected = next(candidate for candidate in candidates if candidate.name == best["candidate"])
    constraints = {
        "best_component_iou": reference_iou,
        "best_component_boundary_f1": reference_boundary,
        "minimum_iou": reference_iou - iou_tolerance,
        "minimum_boundary_f1": reference_boundary - boundary_tolerance,
        "eligible_candidates": float(len(eligible)),
    }
    return selected, rows, constraints


def write_search(path: Path, rows: list[dict[str, object]], names: list[str]) -> None:
    fields = [
        "candidate", "pooling", *[f"weight_{name}" for name in names], "selection_score",
        "foreground_iou", "foreground_dice", "boundary_f1", "notch_preservation", "concavity_score",
        "class_1_iou", "class_2_iou", "notch_pixels",
    ]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            flat = {key: row.get(key) for key in fields}
            for name, value in zip(names, row["weights"]):
                flat[f"weight_{name}"] = value
            writer.writerow(flat)


def main() -> None:
    args = parse_args()
    if len(args.names) != len(args.checkpoints):
        raise ValueError("--names and --checkpoints must have equal lengths")
    if len(set(args.names)) != len(args.names):
        raise ValueError("Component names must be unique")
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    archive = np.load(args.dataset.resolve(), allow_pickle=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    models = [load_model(path, device) for path in args.checkpoints]
    adapter = InputAdapter(archive["fov_mask"]).to(device)

    validation_probabilities, validation_truths, validation_indentations = synthetic_probabilities(
        models, adapter, archive, archive["validation_indices"], device, args.batch_size
    )
    fixed_mode = args.fixed_weights is not None or args.fixed_pooling is not None
    if fixed_mode:
        if args.fixed_weights is None or args.fixed_pooling is None:
            raise ValueError("--fixed-weights and --fixed-pooling must be supplied together")
        if len(args.fixed_weights) != len(models):
            raise ValueError("--fixed-weights must contain one value per checkpoint")
        if any(value < 0 for value in args.fixed_weights) or not np.isclose(sum(args.fixed_weights), 1.0):
            raise ValueError("Fixed weights must be non-negative and sum to one")
        selected = Candidate(args.fixed_pooling, tuple(args.fixed_weights))
        component_candidates = []
        for index in range(len(models)):
            one_hot = [0.0] * len(models)
            one_hot[index] = 1.0
            component_candidates.append(Candidate(args.fixed_pooling, tuple(one_hot)))
        fixed_candidates = component_candidates + [selected]
        search_rows = []
        for candidate in fixed_candidates:
            metrics = metrics_for_predictions(
                blend(validation_probabilities, candidate), validation_truths, validation_indentations
            )
            search_rows.append(
                {
                    "candidate": candidate.name,
                    "pooling": candidate.pooling,
                    "weights": list(candidate.weights),
                    "selection_score": selection_score(metrics),
                    **metrics,
                }
            )
        component_rows = search_rows[: len(models)]
        reference_iou = max(float(row["foreground_iou"]) for row in component_rows)
        reference_boundary = max(float(row["boundary_f1"]) for row in component_rows)
        selected_metrics = search_rows[-1]
        constraints = {
            "mode": "weights frozen from the first validation-only run",
            "best_component_iou": reference_iou,
            "best_component_boundary_f1": reference_boundary,
            "minimum_iou": reference_iou - args.iou_tolerance,
            "minimum_boundary_f1": reference_boundary - args.boundary_tolerance,
            "selected_satisfies_constraints": bool(
                float(selected_metrics["foreground_iou"]) >= reference_iou - args.iou_tolerance
                and float(selected_metrics["boundary_f1"]) >= reference_boundary - args.boundary_tolerance
            ),
        }
    else:
        candidates = candidate_grid(len(models), args.pair_step, args.multi_step)
        selected, search_rows, constraints = select_candidate(
            validation_probabilities,
            validation_truths,
            validation_indentations,
            candidates,
            args.iou_tolerance,
            args.boundary_tolerance,
        )
    write_search(output_dir / "validation_fusion_search.csv", search_rows, args.names)
    selected_row = next(row for row in search_rows if row["candidate"] == selected.name)
    print(f"frozen fusion: {selected.name}; validation={selected_row}", flush=True)

    test_probabilities, test_truths, test_indentations = synthetic_probabilities(
        models, adapter, archive, archive["test_indices"], device, args.batch_size
    )
    synthetic_predictions = {name: probability.argmax(axis=1) for name, probability in zip(args.names, test_probabilities)}
    synthetic_predictions["fusion"] = blend(test_probabilities, selected)
    synthetic_summary = {
        name: metrics_for_predictions(prediction, test_truths, test_indentations)
        for name, prediction in synthetic_predictions.items()
    }
    print(f"synthetic untouched test={synthetic_summary}", flush=True)

    # Public evaluation labels are first accessed below, after selection and
    # independent synthetic testing are complete.
    real_images = archive["real_linear_images"]
    real_voltages = archive["real_voltages"]
    real_probabilities_by_model = real_probabilities(
        models, adapter, real_images, real_voltages, device, args.batch_size
    )
    real_predictions = {
        name: probability.argmax(axis=1) for name, probability in zip(args.names, real_probabilities_by_model)
    }
    real_predictions["fusion"] = blend(real_probabilities_by_model, selected)
    real_truths = archive["real_labels"]
    real_ids = archive["real_ids"]
    real_summary: dict[str, dict[str, float]] = {}
    real_rows: list[dict[str, object]] = []
    for name, prediction in real_predictions.items():
        summary, rows = evaluate_real_predictions(name, prediction, real_truths, real_ids)
        real_summary[name] = summary
        real_rows.extend(rows)
    np.savez_compressed(
        output_dir / "real_predictions.npz",
        ids=real_ids,
        truth=real_truths.astype(np.uint8),
        **{name: prediction.astype(np.uint8) for name, prediction in real_predictions.items()},
    )
    write_rows(output_dir / "real_case_metrics.csv", real_rows)
    save_real_montage(output_dir / "real_all_21_comparison.png", real_truths, real_ids, real_predictions, real_rows)
    save_focus_montage(output_dir / "real_most_concave_comparison.png", real_truths, real_ids, real_predictions, real_rows)

    result = {
        "dataset": str(args.dataset.resolve()),
        "device": str(device),
        "component_names": args.names,
        "checkpoints": [str(path.resolve()) for path in args.checkpoints],
        "selection_data": (
            "fixed weights from the first synthetic-validation run" if fixed_mode else "synthetic validation only"
        ),
        "selection_rule": "0.55 * IoU + 0.20 * boundary F1 + 0.25 * joint concavity, subject to region/boundary floors",
        "constraints": constraints,
        "selected": {"pooling": selected.pooling, "weights": dict(zip(args.names, selected.weights))},
        "validation_selected": selected_row,
        "synthetic_untouched_test": synthetic_summary,
        "real_untouched_test": real_summary,
        "evaluation_truth_used_for_selection": False,
    }
    (output_dir / "summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
