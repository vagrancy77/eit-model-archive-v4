#!/usr/bin/env bash
set -euo pipefail

cd /mnt/e/Codex/eit_reproduction
python reproduce_gn4ip.py
python scripts/plot_gn4ip_paper_style.py
python scripts/validate_gn4ip_reproduction.py
