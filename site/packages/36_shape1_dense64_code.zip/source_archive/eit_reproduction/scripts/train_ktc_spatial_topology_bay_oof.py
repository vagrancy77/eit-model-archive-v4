"""Spatial pairwise physics/topology reconstruction of concave EIT boundaries.

Each exterior-connected bay candidate is represented by a canonical local
patch containing the linear EIT image, public-pool consensus, the baseline,
and the proposed removal. Public labels are confined to complete-level
training folds and nested inner calibration folds.
"""
from __future__ import annotations

import argparse
import copy
import itertools
import json
import random
from dataclasses import asdict
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from audit_ktc_instance_bay_candidates import nearest_resize
from audit_ktc_instance_bay_topology import case_metrics, edit_metrics
from train_ktc_cross_representation_ranker import normalized_images
from train_ktc_instance_bay_nested_ranker import (
    STRICT_INWARD_IDS,
    boundary_f1_per_case,
    foreground_iou_per_case,
    save_montage,
    topology_checks,
)
from train_ktc_pairwise_topology_bay_oof import (
    IDENTITY_POLICY,
    Evidence,
    candidate_front,
    front_audit,
    group_summary,
    material_mask,
    physics_priority,
    policy_result,
    select_policy,
    target_utility,
    training_scores,
    write_csv,
)
from train_ktc_setaware_pure_bay_oof import (
    CLASS_NAMES,
    TARGET_NAMES,
    PublicCase,
    class_targets,
    load_public_cases,
)
from train_ktc_synthetic_bay_risk_ranker import RiskRankVerifier


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument(
        "--pool", type=Path,
        default=root / "outputs" / "ktc_cross_representation_pool_seed20260820" / "public_21.npz",
    )
    parser.add_argument(
        "--cache-dir", type=Path,
        default=Path(r"E:\Codex\ktc_expanded_pure_bay_candidate_cache_seed20260820"),
    )
    parser.add_argument(
        "--target-dir", type=Path,
        default=Path(r"E:\Codex\ktc_expanded_pure_bay_training_targets_seed20260820"),
    )
    parser.add_argument(
        "--pretrained", type=Path,
        default=Path(r"E:\Codex\ktc_synthetic_pure_bay_physics_ranker_seed20260820")
        / "synthetic_bay_risk_ranker.pt",
    )
    parser.add_argument(
        "--synthetic-cache", type=Path,
        default=Path(r"E:\Codex\ktc_synthetic_instance_bay_cache_physics_base_seed20260820")
        / "base_train",
    )
    parser.add_argument(
        "--synthetic-pretrain-checkpoint", type=Path,
        default=Path(r"E:\Codex\ktc_spatial_topology_synthetic_pretrain_seed20260820.pt"),
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=Path(r"E:\Codex\ktc_spatial_topology_bay_oof_seed20260820"),
    )
    parser.add_argument("--epochs", type=int, default=60)
    parser.add_argument("--ensemble-size", type=int, default=3)
    parser.add_argument("--case-batch-size", type=int, default=4)
    parser.add_argument("--front-size", type=int, default=1536)
    parser.add_argument("--patch-size", type=int, default=20)
    parser.add_argument(
        "--feature-normalization", choices=("global", "relative"), default="relative",
        help="Use pretrained global scaling or robust within-case candidate scaling.",
    )
    parser.add_argument("--synthetic-pretrain-epochs", type=int, default=8)
    parser.add_argument("--synthetic-pretrain-cases", type=int, default=320)
    parser.add_argument("--positives-per-case", type=int, default=28)
    parser.add_argument("--hard-negatives-per-case", type=int, default=80)
    parser.add_argument("--random-negatives-per-case", type=int, default=80)
    parser.add_argument("--learning-rate", type=float, default=2e-4)
    parser.add_argument("--weight-decay", type=float, default=2e-4)
    parser.add_argument("--bootstrap-repetitions", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260820)
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--force-synthetic-pretrain", action="store_true")
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def normalize_candidate_features(
    selected: np.ndarray, reference: np.ndarray,
    feature_mean: np.ndarray, feature_scale: np.ndarray,
    mode: str,
) -> np.ndarray:
    if mode == "global":
        return np.clip((selected - feature_mean) / feature_scale, -12.0, 12.0).astype(np.float32)
    median = np.median(reference, axis=0)
    lower, upper = np.quantile(reference, (0.25, 0.75), axis=0)
    scale = (upper - lower) / 1.349
    fallback = np.std(reference, axis=0)
    scale = np.where(scale > 1e-5, scale, fallback)
    scale = np.maximum(scale, 1e-5)
    return np.clip((selected - median) / scale, -12.0, 12.0).astype(np.float32)


def static_maps(
    image: np.ndarray, baseline64: np.ndarray, pool64: np.ndarray, fov: np.ndarray,
) -> np.ndarray:
    normalized = normalized_images(image[None], fov)[0]
    gy, gx = np.gradient(normalized)
    gradient = np.hypot(gx, gy)
    gradient /= max(float(np.quantile(gradient[fov], 0.95)), 1e-6)
    pool_fg = pool64 != 0
    vote_fg = pool_fg.mean(0)
    vote_uncertainty = pool_fg.std(0)
    signed_vote = (pool64 == 2).mean(0) - (pool64 == 1).mean(0)
    baseline_signed = np.where(baseline64 == 1, -1.0, np.where(baseline64 == 2, 1.0, 0.0))
    return np.stack((
        normalized, np.clip(gradient, 0.0, 3.0), 1.0 - vote_fg,
        vote_uncertainty, signed_vote, baseline64 != 0, baseline_signed,
    )).astype(np.float32)


@torch.no_grad()
def canonical_patches(
    maps: np.ndarray, baseline64: np.ndarray, candidates64: np.ndarray,
    angle_sin: np.ndarray, angle_cos: np.ndarray, patch_size: int,
    device: torch.device, chunk: int = 256,
) -> np.ndarray:
    count, height, width = candidates64.shape
    baseline_fg = baseline64 != 0
    removed = baseline_fg[None] & (candidates64 == 0)
    candidate_fg = candidates64 != 0
    cy = np.full(count, (height - 1) / 2, dtype=np.float32)
    cx = np.full(count, (width - 1) / 2, dtype=np.float32)
    side = np.full(count, min(height, width) * 0.96, dtype=np.float32)
    for index in range(1, count):
        yy, xx = np.nonzero(removed[index])
        if len(yy):
            cy[index], cx[index] = float(np.mean(yy)), float(np.mean(xx))
            span = max(int(np.ptp(yy)) + 1, int(np.ptp(xx)) + 1)
            side[index] = float(np.clip(1.8 * span, 14.0, 58.0))
    axis = torch.linspace(-1.0, 1.0, patch_size, device=device)
    vv, uu = torch.meshgrid(axis, axis, indexing="ij")
    maps_t = torch.from_numpy(maps).to(device)
    removed_t = torch.from_numpy(removed.astype(np.float32)).to(device)
    candidate_t = torch.from_numpy(candidate_fg.astype(np.float32)).to(device)
    output = np.empty((count, maps.shape[0] + 2, patch_size, patch_size), dtype=np.float16)
    for start in range(0, count, chunk):
        stop = min(start + chunk, count)
        n = stop - start
        sin = torch.from_numpy(angle_sin[start:stop]).to(device)[:, None, None]
        cos = torch.from_numpy(angle_cos[start:stop]).to(device)[:, None, None]
        half = torch.from_numpy(side[start:stop] / 2.0).to(device)[:, None, None]
        centre_y = torch.from_numpy(cy[start:stop]).to(device)[:, None, None]
        centre_x = torch.from_numpy(cx[start:stop]).to(device)[:, None, None]
        # u follows the tangent and v follows the inward/outward radial axis.
        source_y = centre_y + half * (-cos * uu + sin * vv)
        source_x = centre_x + half * (sin * uu + cos * vv)
        grid = torch.stack((
            2.0 * source_x / max(width - 1, 1) - 1.0,
            2.0 * source_y / max(height - 1, 1) - 1.0,
        ), dim=-1)
        fixed = F.grid_sample(
            maps_t[None].expand(n, -1, -1, -1), grid,
            mode="bilinear", padding_mode="zeros", align_corners=True,
        )
        masks = torch.stack((removed_t[start:stop], candidate_t[start:stop]), dim=1)
        masks = F.grid_sample(
            masks, grid, mode="bilinear", padding_mode="zeros", align_corners=True,
        )
        output[start:stop] = torch.cat((fixed, masks), dim=1).cpu().numpy().astype(np.float16)
    return output


def build_spatial_inputs(
    args: argparse.Namespace, cases: list[PublicCase], fronts: dict[str, np.ndarray],
    device: torch.device,
) -> dict[str, np.ndarray]:
    archive = np.load(args.dataset.resolve(), allow_pickle=False)
    pool = np.load(args.pool.resolve(), allow_pickle=False)
    images = np.asarray(archive["real_linear_images"], dtype=np.float32)
    fov = np.asarray(archive["fov_mask"], dtype=bool)
    pool_candidates = np.asarray(pool["candidates"], dtype=np.uint8)
    output = {}
    for case_index, case in enumerate(cases):
        front = fronts[case.case_id]
        cache_name = case.case_id.replace("/", "__") + ".npz"
        cache = np.load(args.cache_dir.resolve() / cache_name, allow_pickle=False)
        candidates64 = np.asarray(cache["candidates64"], dtype=np.uint8)[front]
        pool64 = nearest_resize(pool_candidates[:, case_index], 64).astype(np.uint8)
        maps = static_maps(images[case_index], candidates64[0], pool64, fov)
        output[case.case_id] = canonical_patches(
            maps, candidates64[0], candidates64,
            case.features[front, 125].astype(np.float32),
            case.features[front, 126].astype(np.float32),
            args.patch_size, device,
        )
        print(
            f"patch {case_index + 1:02d}/{len(cases)} {case.case_id}: "
            f"{output[case.case_id].shape}", flush=True,
        )
    return output


class SpatialTopologyRanker(nn.Module):
    def __init__(self, pretrained_state: dict[str, torch.Tensor], patch_channels: int) -> None:
        super().__init__()
        source = RiskRankVerifier(150)
        source.load_state_dict(pretrained_state)
        self.scalar = copy.deepcopy(source.trunk)
        self.patch = nn.Sequential(
            nn.Conv2d(patch_channels, 24, 3, padding=1), nn.GroupNorm(6, 24), nn.SiLU(),
            nn.Conv2d(24, 32, 3, stride=2, padding=1), nn.GroupNorm(8, 32), nn.SiLU(),
            nn.Conv2d(32, 48, 3, stride=2, padding=1), nn.GroupNorm(8, 48), nn.SiLU(),
            nn.Conv2d(48, 64, 3, stride=2, padding=1), nn.GroupNorm(8, 64), nn.SiLU(),
            nn.AdaptiveAvgPool2d(1), nn.Flatten(),
        )
        self.fusion = nn.Sequential(
            nn.Linear(160, 160), nn.LayerNorm(160), nn.SiLU(), nn.Dropout(0.08),
            nn.Linear(160, 96), nn.SiLU(),
        )
        self.score = nn.Linear(96, 1)
        self.regression = nn.Linear(96, len(TARGET_NAMES))
        self.classification = nn.Linear(96, len(CLASS_NAMES))
        self.case_head = nn.Sequential(nn.Linear(96, 64), nn.SiLU(), nn.Linear(64, 1))

    def forward(self, features: torch.Tensor, patches: torch.Tensor):
        latent = self.fusion(torch.cat((self.scalar(features), self.patch(patches)), dim=1))
        return (
            self.score(latent).squeeze(1), self.regression(latent),
            self.classification(latent), self.case_head(latent).squeeze(1),
        )


def synthetic_values(targets: np.ndarray, removed: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    material = (
        (targets[:, 0] >= 0.002) & (targets[:, 1] >= -0.005)
        & (targets[:, 2] >= 0.030) & (targets[:, 3] >= -0.020)
        & (targets[:, 4] >= -0.020)
    )
    values = (
        targets[:, 0] + 0.25 * targets[:, 1] + 0.80 * targets[:, 2]
        + 0.15 * targets[:, 3] + 0.12 * targets[:, 4] - 0.015 * removed
    )
    values -= (
        7.0 * np.maximum(-targets[:, 0], 0.0)
        + 2.0 * np.maximum(-0.005 - targets[:, 1], 0.0)
        + 3.0 * np.maximum(-targets[:, 2], 0.0)
        + np.maximum(-0.020 - targets[:, 3], 0.0)
    )
    if np.any(material):
        values[~material] -= 0.025
    else:
        values = np.minimum(values, -0.01 - 0.05 * removed)
    values[0] = 0.0
    return values.astype(np.float32), material


def synthetic_classes(targets: np.ndarray) -> np.ndarray:
    return np.column_stack((
        targets[:, 0] >= 0.0,
        targets[:, 1] >= -0.005,
        targets[:, 3] >= -0.020,
        targets[:, 2] >= 0.030,
        targets[:, 4] >= -0.020,
        (targets[:, 0] >= 0.002) & (targets[:, 1] >= -0.005)
        & (targets[:, 2] >= 0.030) & (targets[:, 3] >= -0.020)
        & (targets[:, 4] >= -0.020),
    )).astype(np.float32)


def synthetic_spatial_pretrain(
    args: argparse.Namespace, pretrained: dict[str, object], device: torch.device,
) -> dict[str, torch.Tensor]:
    checkpoint = args.synthetic_pretrain_checkpoint.resolve()
    if checkpoint.exists() and not args.force_synthetic_pretrain:
        payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
        if (
            payload.get("patch_size") == args.patch_size
            and payload.get("feature_normalization", "global") == args.feature_normalization
        ):
            print(f"loaded synthetic spatial pretrain: {checkpoint}", flush=True)
            return payload["model"]
    set_seed(args.seed)
    dataset = np.load(args.dataset.resolve(), allow_pickle=False)
    pool = np.load(args.pool.parent.resolve() / "base_train.npz", allow_pickle=False)
    pool_indices = np.asarray(pool["indices"], dtype=np.int64)
    pool_lookup = {int(value): index for index, value in enumerate(pool_indices)}
    pool_candidates = np.asarray(pool["candidates"], dtype=np.uint8)
    fov = np.asarray(dataset["fov_mask"], dtype=bool)
    images = np.asarray(dataset["linear_images"], dtype=np.float32)
    paths = sorted(args.synthetic_cache.resolve().glob("sample_*.npz"))
    rng = np.random.default_rng(args.seed)
    if args.synthetic_pretrain_cases > 0 and len(paths) > args.synthetic_pretrain_cases:
        chosen = np.sort(rng.choice(len(paths), args.synthetic_pretrain_cases, replace=False))
        paths = [paths[int(index)] for index in chosen]
    model = SpatialTopologyRanker(pretrained["models"][0], 9).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=3e-4, weight_decay=args.weight_decay
    )
    feature_mean = np.asarray(pretrained["feature_mean"], dtype=np.float32)
    feature_scale = np.asarray(pretrained["feature_scale"], dtype=np.float32)
    target_mean = np.asarray(pretrained["target_mean"], dtype=np.float32)
    target_scale = np.maximum(np.asarray(pretrained["target_scale"], dtype=np.float32), 1e-4)
    tm, ts = torch.from_numpy(target_mean).to(device), torch.from_numpy(target_scale).to(device)
    history = []
    for epoch in range(args.synthetic_pretrain_epochs):
        model.train()
        epoch_losses = []
        for path_index in rng.permutation(len(paths)):
            cache = np.load(paths[int(path_index)], allow_pickle=False)
            candidates = np.asarray(cache["candidates"], dtype=np.uint8)
            features = np.asarray(cache["features"], dtype=np.float32)
            targets = np.asarray(cache["target_delta"], dtype=np.float32)
            removed = np.asarray(cache["meta_removed"], dtype=np.float32)
            valid = (
                (np.asarray(cache["meta_kind"]) == 2) & (removed >= 0.005)
                & (np.asarray(cache["meta_added"]) <= 1e-8)
                & (np.asarray(cache["meta_open"]) >= 0.995)
                & (np.asarray(cache["meta_new_holes"]) == 0)
            )
            valid[0] = True
            front = np.flatnonzero(valid)
            values, material = synthetic_values(targets[front], removed[front])
            positives = np.flatnonzero(material)
            if len(positives):
                positives = positives[np.argsort(values[positives])[-args.positives_per_case:]]
            else:
                positives = np.asarray([0], dtype=np.int64)
            excluded = np.zeros(len(front), dtype=bool)
            excluded[positives] = True
            negative = np.flatnonzero(~excluded)
            priority = physics_priority(features[front])
            hard_physics = negative[np.argsort(priority[negative])[-args.hard_negatives_per_case:]]
            hard_target = negative[np.argsort(values[negative])[-args.hard_negatives_per_case:]]
            count = min(args.random_negatives_per_case, len(negative))
            random_negative = rng.choice(negative, count, replace=False) if count else np.empty(0, int)
            positions = np.unique(np.concatenate(([0], positives, hard_physics, hard_target, random_negative)))
            selected = front[positions]
            global_index = int(np.asarray(cache["global_index"]).item())
            pool_position = pool_lookup[global_index]
            maps = static_maps(
                images[global_index], candidates[0], pool_candidates[:, pool_position], fov
            )
            patch = canonical_patches(
                maps, candidates[0], candidates[selected],
                np.asarray(cache["meta_angle_sin"], dtype=np.float32)[selected],
                np.asarray(cache["meta_angle_cos"], dtype=np.float32)[selected],
                args.patch_size, device,
            )
            normalized_features = normalize_candidate_features(
                features[selected], features[front], feature_mean, feature_scale,
                args.feature_normalization,
            )
            feature_t = torch.from_numpy(normalized_features).to(device)
            patch_t = torch.from_numpy(patch.astype(np.float32)).to(device)
            scores, regression, logits, case_logits = model(feature_t, patch_t)
            target_t = torch.from_numpy(targets[selected]).to(device)
            normalized = (target_t - tm) / ts
            regression_loss = F.smooth_l1_loss(regression, normalized, beta=0.35)
            classes = torch.from_numpy(synthetic_classes(targets[selected])).to(device)
            classification_loss = F.binary_cross_entropy_with_logits(logits, classes)
            rank_loss = pairwise_loss(scores, positions, values, material, rng)
            distribution = torch.softmax(torch.from_numpy(values[positions]).to(device) / 0.055, dim=0)
            list_loss = -torch.sum(distribution * F.log_softmax(scores, dim=0))
            identity_position = int(np.flatnonzero(positions == 0)[0])
            action_target = torch.tensor(float(np.any(material)), device=device)
            action_loss = F.binary_cross_entropy_with_logits(
                case_logits[identity_position], action_target
            )
            loss = (
                rank_loss + 0.25 * list_loss + 0.25 * regression_loss
                + 0.20 * classification_loss + 0.20 * action_loss
            )
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            epoch_losses.append(float(loss.detach()))
        record = {"epoch": epoch + 1, "loss": float(np.mean(epoch_losses))}
        history.append(record)
        print(f"synthetic spatial pretrain {epoch + 1}/{args.synthetic_pretrain_epochs}: {record}", flush=True)
    model.eval()
    state = {key: value.detach().cpu() for key, value in model.state_dict().items()}
    checkpoint.parent.mkdir(parents=True, exist_ok=True)
    torch.save({
        "model": state, "patch_size": args.patch_size,
        "feature_normalization": args.feature_normalization,
        "training_cases": len(paths), "history": history,
        "public_cases_used": False,
    }, checkpoint)
    return state


def target_normalization(cases: list[PublicCase], fronts: dict[str, np.ndarray]):
    rows = np.concatenate([case.targets[fronts[case.case_id]] for case in cases])
    mean = np.asarray([np.nanmean(rows[:, i]) for i in range(rows.shape[1])], dtype=np.float32)
    scale = np.asarray([np.nanstd(rows[:, i]) for i in range(rows.shape[1])], dtype=np.float32)
    return mean, np.maximum(scale, 1e-4)


def positive_weights(cases: list[PublicCase], fronts: dict[str, np.ndarray]):
    rows = np.concatenate([class_targets(case.targets[fronts[case.case_id]]) for case in cases])
    positive = rows.sum(0)
    weights = np.clip((len(rows) - positive) / np.maximum(positive, 1), 1, 40).astype(np.float32)
    action = sum(np.any(material_mask(case.targets[fronts[case.case_id]])) for case in cases)
    action_weight = float(np.clip((len(cases) - action) / max(action, 1), 1, 12))
    return weights, action_weight


def sample_positions(
    case: PublicCase, front: np.ndarray, args: argparse.Namespace,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    values, material = training_scores(case, front)
    positives = np.flatnonzero(material)
    if len(positives):
        positives = positives[np.argsort(values[positives])[-args.positives_per_case:]]
    else:
        positives = np.asarray([0], dtype=np.int64)
    excluded = np.zeros(len(front), dtype=bool)
    excluded[positives] = True
    negative = np.flatnonzero(~excluded)
    priority = physics_priority(case.features[front])
    hard_physics = negative[np.argsort(priority[negative])[-args.hard_negatives_per_case:]]
    hard_target = negative[np.argsort(values[negative])[-args.hard_negatives_per_case:]]
    count = min(args.random_negatives_per_case, len(negative))
    random_negative = rng.choice(negative, count, replace=False) if count else np.empty(0, int)
    positions = np.unique(np.concatenate(([0], positives, hard_physics, hard_target, random_negative)))
    return positions, values, material


def pairwise_loss(
    scores: torch.Tensor, positions: np.ndarray, values: np.ndarray,
    material: np.ndarray, rng: np.random.Generator,
) -> torch.Tensor:
    local = {int(position): index for index, position in enumerate(positions)}
    positives = np.flatnonzero(material)
    positives = positives[np.isin(positives, positions)]
    if len(positives):
        positives = positives[np.argsort(values[positives])[-28:]]
    else:
        positives = np.asarray([0], dtype=np.int64)
    negatives = positions[~np.isin(positions, positives)]
    left = np.repeat(positives, len(negatives))
    right = np.tile(negatives, len(positives))
    gap = values[left] - values[right]
    keep = gap >= 0.005
    left, right, gap = left[keep], right[keep], gap[keep]
    if not len(left):
        return scores.sum() * 0.0
    if len(left) > 896:
        choice = rng.choice(len(left), 896, replace=False)
        left, right, gap = left[choice], right[choice], gap[choice]
    left_t = torch.as_tensor([local[int(x)] for x in left], device=scores.device)
    right_t = torch.as_tensor([local[int(x)] for x in right], device=scores.device)
    margin = torch.as_tensor(np.clip(gap, 0.01, 0.20), dtype=torch.float32, device=scores.device)
    weight = 1.0 + 2.0 * torch.clamp(margin / 0.10, max=1.0)
    return (weight * F.softplus(-(scores[left_t] - scores[right_t] - margin) / 0.12)).mean()


def train_one(
    cases: list[PublicCase], fronts: dict[str, np.ndarray], patches: dict[str, np.ndarray],
    pretrained_state: dict[str, torch.Tensor], feature_mean: np.ndarray, feature_scale: np.ndarray,
    target_mean: np.ndarray, target_scale: np.ndarray, args: argparse.Namespace,
    seed: int, device: torch.device,
    initial_state: dict[str, torch.Tensor] | None = None,
):
    set_seed(seed)
    patch_channels = next(iter(patches.values())).shape[1]
    model = SpatialTopologyRanker(pretrained_state, patch_channels).to(device)
    if initial_state is not None:
        model.load_state_dict(initial_state)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    tm, ts = torch.from_numpy(target_mean).to(device), torch.from_numpy(target_scale).to(device)
    pos_np, action_pos = positive_weights(cases, fronts)
    pos_weight = torch.from_numpy(pos_np).to(device)
    action_weight = torch.tensor(action_pos, device=device)
    rng = np.random.default_rng(seed)
    history = []
    for epoch in range(args.epochs):
        model.train()
        order = rng.permutation(len(cases))
        losses = []
        for start in range(0, len(order), args.case_batch_size):
            case_losses = []
            for case_number in order[start:start + args.case_batch_size]:
                case = cases[int(case_number)]
                front = fronts[case.case_id]
                positions, values, material = sample_positions(case, front, args, rng)
                normalized_features = normalize_candidate_features(
                    case.features[front[positions]], case.features[front],
                    feature_mean, feature_scale, args.feature_normalization,
                )
                features = torch.from_numpy(normalized_features).to(device)
                patch = torch.from_numpy(patches[case.case_id][positions].astype(np.float32)).to(device)
                scores, regression, logits, case_logits = model(features, patch)
                targets = torch.from_numpy(case.targets[front[positions]]).to(device)
                finite = torch.isfinite(targets)
                normalized = (torch.nan_to_num(targets) - tm) / ts
                regression_loss = F.smooth_l1_loss(
                    regression[finite], normalized[finite], beta=0.35
                )
                classes_np = class_targets(case.targets[front[positions]])
                classes = torch.from_numpy(classes_np).to(device)
                classification_loss = F.binary_cross_entropy_with_logits(
                    logits, classes, pos_weight=pos_weight
                )
                rank_loss = pairwise_loss(scores, positions, values, material, rng)
                value_t = torch.from_numpy(values[positions]).to(device)
                distribution = torch.softmax(value_t / 0.055, dim=0)
                list_loss = -torch.sum(distribution * F.log_softmax(scores, dim=0))
                action_target = torch.tensor(float(np.any(material)), device=device)
                identity_position = int(np.flatnonzero(positions == 0)[0])
                action_loss = F.binary_cross_entropy_with_logits(
                    case_logits[identity_position], action_target,
                    pos_weight=action_weight if action_target > 0 else None,
                )
                identity_loss = scores[identity_position].square() + F.smooth_l1_loss(
                    regression[identity_position], -tm / ts, beta=0.35
                )
                case_losses.append(
                    rank_loss + 0.25 * list_loss + 0.35 * regression_loss
                    + 0.30 * classification_loss + 0.35 * action_loss + 0.04 * identity_loss
                )
            loss = torch.stack(case_losses).mean()
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            losses.append(float(loss.detach()))
        history.append({"epoch": epoch + 1, "loss": float(np.mean(losses))})
    model.eval()
    return model, history


def train_or_load_ensemble(
    name: str, training: list[PublicCase], fronts: dict[str, np.ndarray],
    patches: dict[str, np.ndarray], pretrained: dict[str, object],
    args: argparse.Namespace, device: torch.device,
    initial_state: dict[str, torch.Tensor] | None = None,
):
    model_dir = args.output_dir.resolve() / "model_cache"
    model_dir.mkdir(parents=True, exist_ok=True)
    path = model_dir / f"{name}.pt"
    if path.exists() and not args.force:
        payload = torch.load(path, map_location=device, weights_only=False)
        if payload.get("feature_normalization", "global") != args.feature_normalization:
            raise ValueError(
                f"cached model normalization mismatch: {path}; use --force or another output directory"
            )
        models = []
        channels = next(iter(patches.values())).shape[1]
        for member, state in enumerate(payload["models"]):
            model = SpatialTopologyRanker(
                pretrained["models"][member % len(pretrained["models"])], channels
            ).to(device)
            model.load_state_dict(state)
            model.eval()
            models.append(model)
        return models, payload["target_mean"], payload["target_scale"]
    target_mean, target_scale = target_normalization(training, fronts)
    models, histories = [], {}
    for member in range(args.ensemble_size):
        seed = args.seed + member
        model, history = train_one(
            training, fronts, patches,
            pretrained["models"][member % len(pretrained["models"])],
            np.asarray(pretrained["feature_mean"], dtype=np.float32),
            np.asarray(pretrained["feature_scale"], dtype=np.float32),
            target_mean, target_scale, args, seed, device, initial_state,
        )
        models.append(model)
        histories[str(seed)] = history
    torch.save({
        "models": [model.state_dict() for model in models],
        "target_mean": target_mean, "target_scale": target_scale,
        "training_case_ids": [case.case_id for case in training],
        "front_size": args.front_size, "patch_size": args.patch_size,
        "feature_normalization": args.feature_normalization,
    }, path)
    (model_dir / f"{name}_history.json").write_text(
        json.dumps(histories, indent=2), encoding="utf-8"
    )
    return models, target_mean, target_scale


@torch.no_grad()
def predict_case(
    case: PublicCase, front: np.ndarray, patch: np.ndarray,
    models: list[SpatialTopologyRanker], pretrained: dict[str, object],
    target_mean: np.ndarray, target_scale: np.ndarray,
    device: torch.device, chunk: int = 256,
    feature_normalization: str = "relative",
) -> Evidence:
    feature_mean = np.asarray(pretrained["feature_mean"], dtype=np.float32)
    feature_scale = np.asarray(pretrained["feature_scale"], dtype=np.float32)
    normalized_features = normalize_candidate_features(
        case.features[front], case.features[front], feature_mean, feature_scale,
        feature_normalization,
    )
    member_scores, member_regression, member_probability, member_case = [], [], [], []
    for model in models:
        scores, regressions, probabilities = [], [], []
        case_probability = None
        for start in range(0, len(front), chunk):
            stop = min(start + chunk, len(front))
            features = torch.from_numpy(normalized_features[start:stop]).to(device)
            patches_t = torch.from_numpy(patch[start:stop].astype(np.float32)).to(device)
            score, regression, logits, case_logits = model(features, patches_t)
            scores.append(score.cpu().numpy())
            regressions.append(regression.cpu().numpy() * target_scale + target_mean)
            probabilities.append(torch.sigmoid(logits).cpu().numpy())
            if start == 0:
                case_probability = float(torch.sigmoid(case_logits[0]))
        score = np.concatenate(scores)
        member_scores.append(score - score[0])
        member_regression.append(np.concatenate(regressions))
        member_probability.append(np.concatenate(probabilities))
        member_case.append(case_probability)
    count = len(case.features)
    score_mean, score_std = np.full(count, -np.inf, np.float32), np.full(count, np.inf, np.float32)
    reg_mean = np.full((count, len(TARGET_NAMES)), -np.inf, np.float32)
    reg_std = np.full((count, len(TARGET_NAMES)), np.inf, np.float32)
    prob_mean = np.zeros((count, len(CLASS_NAMES)), np.float32)
    prob_std = np.full((count, len(CLASS_NAMES)), np.inf, np.float32)
    scores = np.stack(member_scores)
    regressions = np.stack(member_regression)
    probabilities = np.stack(member_probability)
    score_mean[front], score_std[front] = scores.mean(0), scores.std(0)
    reg_mean[front], reg_std[front] = regressions.mean(0), regressions.std(0)
    prob_mean[front], prob_std[front] = probabilities.mean(0), probabilities.std(0)
    score_mean[0] = score_std[0] = 0.0
    reg_mean[0] = reg_std[0] = 0.0
    return Evidence(
        score_mean, score_std, reg_mean, reg_std, prob_mean, prob_std,
        float(np.mean(member_case)), float(np.std(member_case)),
    )


def choose(case: PublicCase, evidence: Evidence, policy) -> int:
    case_lower = evidence.case_probability - policy.uncertainty * evidence.case_probability_std
    if case_lower < policy.case_probability:
        return 0
    if policy.uncertainty > 0:
        probability = evidence.probability - policy.uncertainty * evidence.probability_std
        regression = evidence.regression - policy.uncertainty * evidence.regression_std
        score = evidence.score - policy.uncertainty * evidence.score_std
    else:
        probability, regression, score = evidence.probability, evidence.regression, evidence.score
    valid = case.valid.copy()
    valid &= np.isfinite(score) & (case.removed <= policy.max_removal)
    valid &= probability[:, 0] >= policy.safe_probability
    valid &= probability[:, 1] >= 0.50
    valid &= probability[:, 2] >= policy.safe_probability
    valid &= probability[:, 3] >= 0.50
    valid &= probability[:, 4] >= 0.50
    valid &= probability[:, 5] >= policy.joint_probability
    valid &= regression[:, 0] >= -0.001
    valid &= regression[:, 1] >= -0.005
    valid &= regression[:, 2] >= 0.0
    valid &= score >= policy.score_margin
    valid[0] = True
    combined = score + 0.80 * regression[:, 0] + 0.25 * regression[:, 1]
    combined += 0.70 * regression[:, 2] + 0.10 * regression[:, 4]
    combined[0] = 0.0
    return int(np.argmax(np.where(valid, combined, -np.inf)))


def spatial_policy_result(cases, evidence, policy):
    choices = np.asarray([choose(case, evidence[case.case_id], policy) for case in cases])
    values = np.stack([case.targets[index] for case, index in zip(cases, choices)])
    changed = choices != 0
    finite = np.isfinite(values[:, 2])
    joint = changed & (values[:, 0] > 0.0) & finite & (values[:, 2] >= 0.005)
    eligible = (
        not np.any(values[:, 0] < -1e-9) and not np.any(values[:, 1] < -0.005)
        and not np.any(values[changed & finite, 2] < -1e-9)
        and not np.any(values[changed & np.isfinite(values[:, 4]), 4] < -0.020)
    )
    utility = target_utility(values, np.asarray([
        case.removed[index] for case, index in zip(cases, choices)
    ]))
    return choices, values, {
        "eligible": bool(eligible), "changed": int(changed.sum()),
        "joint_improved": int(joint.sum()),
        "false_actions": int(np.count_nonzero(changed & ~joint)),
        "harmed_iou": int(np.count_nonzero(values[:, 0] < 0)),
        "harmed_bay": int(np.count_nonzero(changed & finite & (values[:, 2] < 0))),
        "mean_iou": float(values[:, 0].mean()), "mean_bay": float(np.nanmean(values[:, 2])),
        "mean_utility": float(utility.mean()), "minimum_iou": float(values[:, 0].min()),
    }


def spatial_select_policy(cases, evidence):
    from train_ktc_pairwise_topology_bay_oof import POLICIES
    rows, best = [], None
    for policy in POLICIES:
        _, _, result = spatial_policy_result(cases, evidence, policy)
        rows.append({**asdict(policy), **result})
        key = (
            int(result["eligible"]), int(result["joint_improved"]),
            -int(result["false_actions"]), float(result["mean_utility"]),
            float(result["mean_iou"]), -int(result["changed"]),
        )
        if best is None or key > best[0]:
            best = (key, policy, result)
    if not best[2]["eligible"] or best[2]["joint_improved"] < 1:
        _, _, identity = spatial_policy_result(cases, evidence, IDENTITY_POLICY)
        return IDENTITY_POLICY, identity, rows
    return best[1], best[2], rows


def main() -> None:
    args = parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    pretrained = torch.load(args.pretrained.resolve(), map_location="cpu", weights_only=False)
    synthetic_state = synthetic_spatial_pretrain(args, pretrained, device)
    cases, truths, ids = load_public_cases(args)
    fronts = {case.case_id: candidate_front(case, args.front_size) for case in cases}
    audit_rows = front_audit(cases, fronts)
    write_csv(output / "candidate_front_audit.csv", audit_rows)
    patches = build_spatial_inputs(args, cases, fronts, device)
    levels = sorted({case.level for case in cases})
    pair_evidence = {}
    for fold, (left, right) in enumerate(itertools.combinations(levels, 2), 1):
        training = [case for case in cases if case.level not in (left, right)]
        models, target_mean, target_scale = train_or_load_ensemble(
            f"exclude_{left}_{right}", training, fronts, patches, pretrained, args, device,
            synthetic_state,
        )
        held = [case for case in cases if case.level in (left, right)]
        pair_evidence[(left, right)] = {
            case.case_id: predict_case(
                case, fronts[case.case_id], patches[case.case_id], models,
                pretrained, target_mean, target_scale, device,
                feature_normalization=args.feature_normalization,
            ) for case in held
        }
        print(f"pair {fold:02d}/21 {left}+{right}: train={len(training)}", flush=True)

    baselines = np.stack([case.candidates[0] for case in cases])
    predictions = baselines.copy()
    choices = np.zeros(len(cases), dtype=np.int64)
    policies, calibration_rows = [], []
    for fold, outer in enumerate(levels, 1):
        inner_cases = [case for case in cases if case.level != outer]
        inner_evidence = {}
        for inner in levels:
            if inner == outer:
                continue
            pair = tuple(sorted((outer, inner)))
            for case in cases:
                if case.level == inner:
                    inner_evidence[case.case_id] = pair_evidence[pair][case.case_id]
        policy, inner_result, calibration = spatial_select_policy(inner_cases, inner_evidence)
        calibration_rows.extend({"outer_level": outer, **row} for row in calibration)
        training = [case for case in cases if case.level != outer]
        models, target_mean, target_scale = train_or_load_ensemble(
            f"exclude_{outer}", training, fronts, patches, pretrained, args, device,
            synthetic_state,
        )
        outer_choices = []
        for index, case in enumerate(cases):
            if case.level != outer:
                continue
            evidence = predict_case(
                case, fronts[case.case_id], patches[case.case_id], models,
                pretrained, target_mean, target_scale, device,
                feature_normalization=args.feature_normalization,
            )
            choice = choose(case, evidence, policy)
            choices[index] = choice
            predictions[index] = case.candidates[choice]
            outer_choices.append(int(choice))
        record = {
            "outer_level": outer, **asdict(policy),
            **{f"inner_oof_{key}": value for key, value in inner_result.items()},
            "outer_choices": outer_choices,
        }
        policies.append(record)
        print(f"outer {fold}/7: {record}", flush=True)

    before_iou = foreground_iou_per_case(truths, baselines)
    after_iou = foreground_iou_per_case(truths, predictions)
    before_boundary = boundary_f1_per_case(truths, baselines)
    after_boundary = boundary_f1_per_case(truths, predictions)
    case_rows = []
    for index, case in enumerate(cases):
        before_geometry = case_metrics(truths[index], baselines[index])
        after_geometry = case_metrics(truths[index], predictions[index])
        row = {
            "id": case.case_id, "strict_inward": case.case_id in STRICT_INWARD_IDS,
            "choice": int(choices[index]), "baseline_iou": float(before_iou[index]),
            "final_iou": float(after_iou[index]),
            "delta_iou": float(after_iou[index] - before_iou[index]),
            "baseline_boundary_f1": float(before_boundary[index]),
            "final_boundary_f1": float(after_boundary[index]),
            "delta_boundary_f1": float(after_boundary[index] - before_boundary[index]),
            **topology_checks(baselines[index], predictions[index]),
            **edit_metrics(truths[index], baselines[index], predictions[index]),
        }
        for metric in ("bay_f1", "bay_precision", "bay_depth_score", "bay_direction_score"):
            row[f"baseline_{metric}"] = before_geometry[metric]
            row[f"final_{metric}"] = after_geometry[metric]
            row[f"delta_{metric}"] = float(after_geometry[metric] - before_geometry[metric])
        case_rows.append(row)
    strict = np.asarray([case.case_id in STRICT_INWARD_IDS for case in cases])
    groups = {
        "all": group_summary(
            np.ones(len(cases), bool), truths, baselines, predictions,
            args.bootstrap_repetitions, args.seed,
        ),
        "strict_inward": group_summary(
            strict, truths, baselines, predictions,
            args.bootstrap_repetitions, args.seed + 20,
        ),
        "ordinary": group_summary(
            ~strict, truths, baselines, predictions,
            args.bootstrap_repetitions, args.seed + 40,
        ),
    }
    write_csv(output / "public_case_metrics.csv", case_rows)
    write_csv(output / "nested_calibration.csv", calibration_rows)
    (output / "fold_policies.json").write_text(json.dumps(policies, indent=2), encoding="utf-8")
    np.savez_compressed(
        output / "predictions.npz", ids=ids, truths=truths,
        baseline=baselines, prediction=predictions, choices=choices,
    )
    save_montage(
        output / "strict_inward_spatial_topology.png", truths, baselines,
        predictions, baselines, ids, np.flatnonzero(strict),
    )
    summary = {
        "method": "canonical-patch pairwise physics/topology exterior-bay ranker",
        "status": "complete-level nested outer-OOF evaluation",
        "outer_truth_used_for_training_or_policy_selection": False,
        "strict_inward_ids_used_for_training_or_policy_selection": False,
        "spatial_channels": [
            "linear_eit", "linear_gradient", "pool_background_vote",
            "pool_uncertainty", "pool_signed_class_vote", "baseline_foreground",
            "baseline_signed_class", "proposed_removal", "candidate_foreground",
        ],
        "candidate_constraints": {
            "added_pixels": 0, "removed_background_exterior_connected": True,
            "new_holes_forbidden": True,
            "foreground_and_class_component_counts_preserved": True,
            "identity_fallback": True,
        },
        "groups": groups, "fold_policies": policies,
        "args": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
    }
    (output / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=True), encoding="utf-8"
    )
    print(json.dumps(groups, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
