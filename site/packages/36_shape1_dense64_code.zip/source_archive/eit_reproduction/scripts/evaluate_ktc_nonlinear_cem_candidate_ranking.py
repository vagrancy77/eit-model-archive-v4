"""Audit whether full nonlinear CEM data can rank inward-boundary candidates.

The conductivity contrasts are fitted once for the baseline reconstruction of
each case.  Every shape candidate is then evaluated with exactly the same
contrasts.  This isolates shape evidence from the otherwise serious confound
of allowing every candidate to over-fit its own conductivity amplitudes.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import scipy.io as sio
from PIL import Image
from scipy.optimize import minimize
from scipy.stats import spearmanr

from optimize_ktc_path_conditioned_concavity import CANDIDATE_NAMES, PUBLIC_INWARD_IDS
from train_ktc_concavity_network_v2 import evaluate_real_predictions


STRICT_INWARD_IDS = (
    "level_2/1", "level_2/3", "level_3/2", "level_5/2",
    "level_6/2", "level_6/3", "level_7/1", "level_7/2", "level_7/3",
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--predictions",
        type=Path,
        default=root / "outputs" / "ktc_physics_consistent_concavity_selector_candidate_export_seed20260820" / "predictions.npz",
    )
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--repo-root", type=Path, default=root / "external" / "KTC2023-ABC2")
    parser.add_argument(
        "--ktc-root", type=Path,
        default=root / "datasets" / "ktc2023_full" / "v3" / "evaluation_full" / "EvaluationData_full",
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=root / "outputs" / "ktc_nonlinear_cem_candidate_ranking_seed20260820",
    )
    parser.add_argument("--field-resolution", type=int, default=128)
    parser.add_argument("--maxiter", type=int, default=14)
    return parser.parse_args()


def resize_mask(mask: np.ndarray, size: int) -> np.ndarray:
    return np.asarray(
        Image.fromarray(mask.astype(np.uint8)).resize((size, size), resample=Image.Resampling.NEAREST)
    )


def nodal_class_fields(labels: np.ndarray, interpolation: np.ndarray, size: int) -> tuple[np.ndarray, np.ndarray]:
    resized = resize_mask(labels, size)
    # KTC's image coordinates and FEM coordinates have opposite vertical axes.
    low = np.flipud(resized == 1).reshape(-1).astype(np.float64)
    high = np.flipud(resized == 2).reshape(-1).astype(np.float64)
    return interpolation @ low, interpolation @ high


def forward_delta(
    labels: np.ndarray,
    contrasts: np.ndarray,
    matrices: dict[str, object],
    interpolation: np.ndarray,
    size: int,
) -> np.ndarray:
    low, high = nodal_class_fields(labels, interpolation, size)
    sigma = np.asarray(matrices["sigma0"], dtype=np.float64).reshape(-1).copy()
    sigma += float(contrasts[0]) * low + float(contrasts[1]) * high
    prediction = matrices["forward_solver"].SolveForward(
        sigma[:, None], np.asarray(matrices["contact_impedance"], dtype=np.float64).copy()
    )
    return np.asarray(prediction, dtype=np.float64).reshape(-1) - np.asarray(
        matrices["reference_forward"], dtype=np.float64
    ).reshape(-1)


def relative_residual(prediction: np.ndarray, target: np.ndarray) -> float:
    return float(np.mean(np.square(prediction - target)) / max(np.mean(np.square(target)), 1e-16))


def fit_baseline_contrasts(
    baseline: np.ndarray,
    target: np.ndarray,
    matrices: dict[str, object],
    interpolation: np.ndarray,
    size: int,
    maxiter: int,
) -> tuple[np.ndarray, dict[str, object]]:
    present_low = bool(np.any(baseline == 1))
    present_high = bool(np.any(baseline == 2))
    active = np.asarray([present_low, present_high])
    initial_full = np.asarray([-0.45, 0.55], dtype=np.float64)
    bounds_full = ((-0.75, -0.01), (0.01, 1.60))

    if not np.any(active):
        return np.zeros(2, dtype=np.float64), {"success": True, "evaluations": 0, "relative_mse": 1.0}

    def expand(values: np.ndarray) -> np.ndarray:
        full = np.zeros(2, dtype=np.float64)
        full[active] = values
        return full

    def objective(values: np.ndarray) -> float:
        return relative_residual(
            forward_delta(baseline, expand(values), matrices, interpolation, size), target
        )

    optimization = minimize(
        objective,
        initial_full[active],
        method="Nelder-Mead",
        bounds=[bounds_full[index] for index in np.flatnonzero(active)],
        options={"maxiter": maxiter, "xatol": 2e-3, "fatol": 2e-5},
    )
    contrasts = expand(np.asarray(optimization.x, dtype=np.float64))
    return contrasts, {
        "success": bool(optimization.success),
        "evaluations": int(optimization.nfev),
        "relative_mse": float(optimization.fun),
        "message": str(optimization.message),
    }


def case_iou(truth: np.ndarray, prediction: np.ndarray) -> float:
    foreground_truth = truth != 0
    foreground_prediction = prediction != 0
    union = np.logical_or(foreground_truth, foreground_prediction).sum()
    return float(np.logical_and(foreground_truth, foreground_prediction).sum() / max(1, union))


def evaluate_group(
    group: str,
    ids: np.ndarray,
    truths: np.ndarray,
    baselines: np.ndarray,
    candidates: np.ndarray,
    data_paths: list[Path],
    reference_path: Path,
    solver_module: object,
    field_resolution: int,
    maxiter: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, list[dict[str, object]], list[dict[str, object]]]:
    selected = np.empty_like(baselines)
    selected_indices = np.zeros(len(ids), dtype=np.int64)
    residual_cube = np.empty((candidates.shape[0] + 1, len(ids)), dtype=np.float64)
    rows: list[dict[str, object]] = []
    fit_rows: list[dict[str, object]] = []
    all_shapes = np.concatenate((baselines[None], candidates), axis=0)

    # Geometry, electrodes and the reference are identical within each KTC
    # group.  Reusing this object avoids rebuilding the mesh and Jacobian for
    # every case; only conductivity and measured voltage change below.
    matrices = solver_module.get_solver_matrices(
        str(data_paths[0]), 1, 0.7927, reference_data_path=str(reference_path)
    )
    interpolation = solver_module.calc_dist(
        matrices["coordinates"], x_d=field_resolution, y_d=field_resolution,
        mode="lowpass", sigma=8e-3,
    )
    reference = np.asarray(sio.loadmat(reference_path)["Uelref"], dtype=np.float64).reshape(-1)

    for case_index, (case_id, data_path) in enumerate(zip(ids, data_paths)):
        measured = np.asarray(sio.loadmat(data_path)["Uel"], dtype=np.float64).reshape(-1)
        target = measured - reference
        contrasts, fit = fit_baseline_contrasts(
            baselines[case_index], target, matrices, interpolation, field_resolution, maxiter
        )
        for candidate_index, shape in enumerate(all_shapes[:, case_index]):
            residual_cube[candidate_index, case_index] = relative_residual(
                forward_delta(shape, contrasts, matrices, interpolation, field_resolution), target
            )
        choice = int(np.argmin(residual_cube[:, case_index]))
        selected_indices[case_index] = choice
        selected[case_index] = all_shapes[choice, case_index]
        ious = np.asarray([case_iou(truths[case_index], shape) for shape in all_shapes[:, case_index]])
        correlation = spearmanr(-residual_cube[:, case_index], ious).statistic
        if not np.isfinite(correlation):
            correlation = 0.0
        oracle_choice = int(np.argmax(ious))
        rows.append({
            "group": group, "id": str(case_id), "selected_choice": choice,
            "selected_name": "identity" if choice == 0 else CANDIDATE_NAMES[choice - 1],
            "oracle_choice": oracle_choice,
            "oracle_name": "identity" if oracle_choice == 0 else CANDIDATE_NAMES[oracle_choice - 1],
            "baseline_iou": float(ious[0]), "selected_iou": float(ious[choice]),
            "oracle_iou": float(ious[oracle_choice]),
            "iou_delta": float(ious[choice] - ious[0]),
            "residual_gain": float(1.0 - residual_cube[choice, case_index] / max(residual_cube[0, case_index], 1e-16)),
            "spearman_residual_vs_iou": float(correlation),
            "selected_matches_oracle": bool(choice == oracle_choice),
        })
        fit_rows.append({
            "group": group, "id": str(case_id), "low_contrast": float(contrasts[0]),
            "high_contrast": float(contrasts[1]), **fit,
        })
        print(
            f"{group} {case_index + 1:02d}/{len(ids)} {case_id}: "
            f"choice={choice}, oracle={oracle_choice}, IoU {ious[0]:.4f}->{ious[choice]:.4f}, "
            f"rho={correlation:.3f}", flush=True,
        )
    return selected, selected_indices, residual_cube, rows, fit_rows


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    fields = sorted({key for row in rows for key in row})
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def metric_summary(truths: np.ndarray, ids: np.ndarray, methods: dict[str, np.ndarray]) -> dict[str, object]:
    result: dict[str, object] = {}
    for name, prediction in methods.items():
        summary, _ = evaluate_real_predictions(name, prediction, truths, ids)
        result[name] = summary
    return result


def subset_summary(
    truths: np.ndarray, ids: np.ndarray, methods: dict[str, np.ndarray], selected_ids: tuple[str, ...]
) -> dict[str, object]:
    indices = np.asarray([index for index, case_id in enumerate(ids) if str(case_id) in selected_ids])
    return metric_summary(truths[indices], ids[indices], {name: values[indices] for name, values in methods.items()})


def save_montage(
    path: Path,
    truths: np.ndarray,
    ids: np.ndarray,
    baseline: np.ndarray,
    selected: np.ndarray,
    oracle: np.ndarray,
    choices: np.ndarray,
    only_ids: tuple[str, ...] | None = None,
) -> None:
    indices = [index for index, case_id in enumerate(ids) if only_ids is None or str(case_id) in only_ids]
    figure, axes = plt.subplots(len(indices), 5, figsize=(12.5, max(2.3 * len(indices), 3.0)), squeeze=False)
    for row, index in enumerate(indices):
        removed = np.logical_and(baseline[index] != 0, selected[index] == 0)
        panels = (
            (truths[index], "truth", "viridis", 2),
            (baseline[index], f"baseline\nIoU={case_iou(truths[index], baseline[index]):.3f}", "viridis", 2),
            (selected[index], f"nonlinear CEM choice={choices[index]}\nIoU={case_iou(truths[index], selected[index]):.3f}", "viridis", 2),
            (oracle[index], f"candidate oracle\nIoU={case_iou(truths[index], oracle[index]):.3f}", "viridis", 2),
            (removed, "selected inward removal", "magma", 1),
        )
        for column, (image, title, cmap, vmax) in enumerate(panels):
            axes[row, column].imshow(image, cmap=cmap, vmin=0, vmax=vmax, interpolation="nearest")
            axes[row, column].set_title(title, fontsize=8)
            axes[row, column].set_axis_off()
        axes[row, 0].set_ylabel(str(ids[index]), fontsize=8)
    figure.tight_layout()
    figure.savefig(path, dpi=190)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    predictions = np.load(args.predictions.resolve(), allow_pickle=False)
    base = np.load(args.base_dataset.resolve(), allow_pickle=False)
    repo_root = args.repo_root.resolve()
    ktc_root = args.ktc_root.resolve()

    os.chdir(repo_root)
    sys.path.insert(0, str(repo_root))
    from utils import solver

    public_ids = np.asarray(predictions["real_ids"])
    public_paths = []
    for case_id in public_ids:
        level, sample = str(case_id).split("/")
        public_paths.append(
            ktc_root / "evaluation_datasets" / level.replace("level_", "level") / f"data{sample}.mat"
        )
    public_reference = ktc_root / "evaluation_datasets" / "level1" / "ref.mat"
    public_selected, public_choice, public_residual, public_rows, public_fits = evaluate_group(
        "public", public_ids, base["real_labels"], predictions["real_path"],
        predictions["real_candidates"], public_paths, public_reference, solver,
        args.field_resolution, args.maxiter,
    )

    official_ids = np.asarray(predictions["official_ids"])
    official_paths = [repo_root / "inputs" / f"data{index}.mat" for index in range(1, 5)]
    official_reference = repo_root / "utils" / "reference_files" / "ref.mat"
    official_selected, official_choice, official_residual, official_rows, official_fits = evaluate_group(
        "official", official_ids, predictions["official_truths"], predictions["official_path"],
        predictions["official_candidates"], official_paths, official_reference, solver,
        args.field_resolution, args.maxiter,
    )

    public_oracle = predictions["real_oracle_result"]
    official_oracle = predictions["official_oracle_result"]
    public_methods = {
        "baseline": predictions["real_path"], "nonlinear_cem_selector": public_selected,
        "candidate_oracle": public_oracle,
    }
    official_methods = {
        "baseline": predictions["official_path"], "nonlinear_cem_selector": official_selected,
        "candidate_oracle": official_oracle,
    }
    summary = {
        "method": "full nonlinear CEM ranking with per-case baseline-fitted shared contrasts",
        "candidate_names": ["identity", *CANDIDATE_NAMES],
        "public_21": metric_summary(base["real_labels"], public_ids, public_methods),
        "public_strict_inward": subset_summary(base["real_labels"], public_ids, public_methods, STRICT_INWARD_IDS),
        "official_four": metric_summary(predictions["official_truths"], official_ids, official_methods),
        "ranking": {
            "public_mean_spearman": float(np.mean([row["spearman_residual_vs_iou"] for row in public_rows])),
            "public_oracle_match_rate": float(np.mean([row["selected_matches_oracle"] for row in public_rows])),
            "public_changed_cases": int(np.count_nonzero(public_choice)),
            "official_mean_spearman": float(np.mean([row["spearman_residual_vs_iou"] for row in official_rows])),
            "official_oracle_match_rate": float(np.mean([row["selected_matches_oracle"] for row in official_rows])),
            "official_changed_cases": int(np.count_nonzero(official_choice)),
        },
        "protocol": {
            "field_resolution": args.field_resolution,
            "contrast_fit": "Nelder-Mead on baseline only; candidate shapes reuse identical contrasts",
            "residual": "relative MSE of nonlinear CEM voltage difference",
            "public_labels": "evaluation only",
        },
    }
    write_csv(output_dir / "case_ranking.csv", public_rows + official_rows)
    write_csv(output_dir / "contrast_fits.csv", public_fits + official_fits)
    (output_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    np.savez_compressed(
        output_dir / "results.npz",
        public_ids=public_ids, public_selected=public_selected, public_choice=public_choice,
        public_residual=public_residual, official_ids=official_ids,
        official_selected=official_selected, official_choice=official_choice,
        official_residual=official_residual,
    )
    save_montage(
        output_dir / "public_21_nonlinear_cem_ranking.png", base["real_labels"], public_ids,
        predictions["real_path"], public_selected, public_oracle, public_choice,
    )
    save_montage(
        output_dir / "public_strict_inward_nonlinear_cem_ranking.png", base["real_labels"], public_ids,
        predictions["real_path"], public_selected, public_oracle, public_choice, STRICT_INWARD_IDS,
    )
    save_montage(
        output_dir / "official_four_nonlinear_cem_ranking.png", predictions["official_truths"], official_ids,
        predictions["official_path"], official_selected, official_oracle, official_choice,
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
