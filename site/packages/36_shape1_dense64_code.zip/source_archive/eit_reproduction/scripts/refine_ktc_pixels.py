from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np
import scipy.io as sio
from PIL import Image

os.environ.setdefault("CUDA_VISIBLE_DEVICES", "")

import torch
import torch.nn.functional as F

from experiment_ktc_concavity import class_metrics, ktc_score, save_labels, shape_metrics


VARIANTS = {
    "log_free": {
        "tv_mode": "log",
        "tv_weight": 5e-8,
        "anchor_weight": 0.0,
        "learning_rate": 1e-2,
    },
    "log_anchor_1e6": {
        "tv_mode": "log",
        "tv_weight": 5e-8,
        "anchor_weight": 1e-6,
        "learning_rate": 1e-2,
    },
    "log_anchor_1e5": {
        "tv_mode": "log",
        "tv_weight": 5e-8,
        "anchor_weight": 1e-5,
        "learning_rate": 1e-2,
    },
    "l1_anchor_1e6": {
        "tv_mode": "l1",
        "tv_weight": 5e-8,
        "anchor_weight": 1e-6,
        "learning_rate": 1e-2,
    },
}


def parse_args() -> argparse.Namespace:
    project_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(
        description="Pixel-space physics refinement initialized from a DIP reconstruction."
    )
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=project_root / "external" / "KTC2023-ABC2",
    )
    parser.add_argument(
        "--input-continuous",
        type=Path,
        default=(
            project_root
            / "outputs"
            / "ktc_concavity_nearest_map_750"
            / "very_shallow_dip_continuous.npy"
        ),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=project_root / "outputs" / "ktc_pixel_refinement",
    )
    parser.add_argument("--case", type=int, default=4, choices=(1, 2, 3, 4))
    parser.add_argument("--num-iter", type=int, default=300)
    parser.add_argument("--progress-every", type=int, default=100)
    parser.add_argument(
        "--variants", default=",".join(VARIANTS), help="Comma-separated variant names."
    )
    parser.add_argument("--opening-iterations", type=int, default=0)
    return parser.parse_args()


def load_initial_image(path: Path) -> np.ndarray:
    continuous_256 = np.load(path)
    # The public solver flips its 128x128 image vertically and then resizes it
    # for segmentation.  Undo those two display operations here.
    resized = np.asarray(
        Image.fromarray(continuous_256).resize((128, 128)), dtype=np.float64
    )
    return np.flipud(resized).copy()


def to_display_image(image_128: np.ndarray) -> np.ndarray:
    flipped = np.flipud(image_128)
    return np.asarray(Image.fromarray(flipped).resize((256, 256)), dtype=np.float64)


def write_figure(
    truth: np.ndarray,
    initial_segmented: np.ndarray,
    rows: list[dict[str, object]],
    output_path: Path,
) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    figure, axes = plt.subplots(
        1,
        2 + len(rows),
        figsize=(3.2 * (2 + len(rows)), 3.5),
        constrained_layout=True,
    )
    images = [truth, initial_segmented]
    titles = ["Ground truth", "DIP initialization"]
    for row in rows:
        images.append(
            np.rint(
                np.asarray(Image.open(str(row["image_path"])), dtype=np.float64)
                * 2.0
                / 255.0
            )
        )
        titles.append(
            f"{row['name']}\nIoU={row['class_metrics']['mean_iou']:.3f}, "
            f"notch={row['shape_metrics']['indentation_preservation']:.3f}"
        )
    for axis, image, title in zip(axes, images, titles):
        axis.imshow(image, cmap="gray", vmin=0, vmax=2)
        axis.set_title(title)
        axis.set_axis_off()
    figure.suptitle("Pixel-space EIT residual refinement")
    figure.savefig(output_path, dpi=180)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    repo_root = args.repo_root.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    os.chdir(repo_root)
    sys.path.insert(0, str(repo_root))
    from utils import solver

    names = [name.strip() for name in args.variants.split(",") if name.strip()]
    unknown = sorted(set(names) - set(VARIANTS))
    if unknown:
        raise ValueError(f"unknown variants: {unknown}")

    initial_np = load_initial_image(args.input_continuous.resolve())
    initial = torch.from_numpy(initial_np)[None, None].double()
    mask = torch.from_numpy(solver.get_mask(128)).double()
    matrices = solver.get_solver_matrices(
        str(repo_root / "inputs" / f"data{args.case}.mat"), 1, 0.7927
    )
    jacobian = torch.from_numpy(matrices["J"]).double()
    target = torch.from_numpy(matrices["deltaU"]).double() * 2.0
    interpolation = torch.from_numpy(
        solver.calc_dist(
            matrices["coordinates"], x_d=128, y_d=128, mode="lowpass", sigma=8e-3
        )
    ).double()
    truth = sio.loadmat(
        repo_root / "groundTruths" / f"true{args.case}.mat"
    )["truth"]
    initial_display = to_display_image(initial_np)
    initial_segmented = solver.segment(
        initial_display, opening_iterations=args.opening_iterations
    )
    summary: dict[str, object] = {
        "case": args.case,
        "input_continuous": str(args.input_continuous.resolve()),
        "num_iter": args.num_iter,
        "initial": {
            "class_metrics": class_metrics(truth, initial_segmented),
            "shape_metrics": shape_metrics(truth, initial_segmented),
            "ktc_ssim": ktc_score(truth, initial_segmented),
        },
        "variants": [],
    }

    for name in names:
        parameters = VARIANTS[name]
        pixels = torch.nn.Parameter(initial.clone())
        optimizer = torch.optim.Adam(
            [pixels], lr=float(parameters["learning_rate"])
        )
        loss_history = []
        for iteration in range(args.num_iter):
            optimizer.zero_grad()
            current = mask * pixels
            nodal = interpolation @ current[0, 0].reshape(-1, 1)
            data_loss = F.mse_loss(jacobian @ nodal, target)
            tv_loss = float(parameters["tv_weight"]) * solver.spatial_regularizer(
                current,
                mode=str(parameters["tv_mode"]),
                epsilon=1e-2,
            )
            anchor_loss = float(parameters["anchor_weight"]) * F.mse_loss(
                current, initial
            )
            total_loss = data_loss + tv_loss + anchor_loss
            total_loss.backward()
            optimizer.step()
            values = {
                "total": float(total_loss.detach()),
                "data": float(data_loss.detach()),
                "tv": float(tv_loss.detach()),
                "anchor": float(anchor_loss.detach()),
            }
            loss_history.append(values)
            if args.progress_every and (
                iteration == 0
                or (iteration + 1) % args.progress_every == 0
                or iteration + 1 == args.num_iter
            ):
                print(
                    f"{name} iter {iteration + 1}/{args.num_iter}: "
                    f"total={values['total']:.8f}, data={values['data']:.8f}, "
                    f"tv={values['tv']:.8f}, anchor={values['anchor']:.8f}",
                    flush=True,
                )

        refined_128 = (mask * pixels).detach().cpu().numpy()[0, 0]
        continuous = to_display_image(refined_128)
        np.save(output_dir / f"{name}_continuous.npy", continuous)
        segmented = solver.segment(
            continuous, opening_iterations=args.opening_iterations
        )
        image_path = output_dir / f"{name}.png"
        save_labels(segmented, image_path)
        row = {
            "name": name,
            "parameters": parameters,
            "image_path": str(image_path),
            "class_metrics": class_metrics(truth, segmented),
            "shape_metrics": shape_metrics(truth, segmented),
            "ktc_ssim": ktc_score(truth, segmented),
            "final_losses": loss_history[-1],
        }
        summary["variants"].append(row)
        print(
            f"{name}: mean IoU={row['class_metrics']['mean_iou']:.4f}, "
            f"KTC-SSIM={row['ktc_ssim']:.4f}, "
            f"notch={row['shape_metrics']['indentation_preservation']:.4f}",
            flush=True,
        )

    with (output_dir / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    write_figure(
        truth,
        initial_segmented,
        summary["variants"],
        output_dir / "comparison.png",
    )
    print(f"Saved {output_dir / 'summary.json'}", flush=True)


if __name__ == "__main__":
    main()
