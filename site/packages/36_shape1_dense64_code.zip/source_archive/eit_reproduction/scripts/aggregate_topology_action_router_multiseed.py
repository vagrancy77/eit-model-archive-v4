"""Aggregate validation-calibrated topology action routers across random seeds."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


METHODS = ("direct_base", "topology_residual", "topology_routed")
METRICS = (
    "foreground_iou",
    "foreground_dice",
    "boundary_f1",
    "notch_preservation",
    "bank_retention",
)
DISPLAY_METRICS = ("foreground_iou", "boundary_f1", "notch_preservation")


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", nargs="+", required=True, help="seed=router_directory")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--bootstrap", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260916)
    parser.add_argument(
        "--audit",
        type=Path,
        default=root / "outputs" / "ktc2023_full_audit" / "summary.json",
    )
    return parser.parse_args()


def parse_runs(values: list[str]) -> list[tuple[str, Path]]:
    runs: list[tuple[str, Path]] = []
    for value in values:
        if "=" not in value:
            raise ValueError(f"run must be seed=directory, got {value!r}")
        seed, raw_path = value.split("=", 1)
        path = Path(raw_path).resolve()
        for filename in ("action_router_summary.json", "action_router_case_metrics.csv"):
            if not (path / filename).is_file():
                raise FileNotFoundError(path / filename)
        runs.append((seed, path))
    if len(runs) < 2:
        raise ValueError("at least two runs are required")
    if len({seed for seed, _ in runs}) != len(runs):
        raise ValueError("seed labels must be unique")
    return runs


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def truthy(value: str) -> bool:
    normalized = value.strip().lower()
    if normalized in {"true", "yes"}:
        return True
    if normalized in {"false", "no", ""}:
        return False
    return float(normalized) > 0.5


def build_groups(rows: list[dict[str, str]], strict_ids: set[str]) -> dict[str, list[str]]:
    reference = [row for row in rows if row["method"] == "direct_base"]
    groups: dict[str, list[str]] = {}
    for partition in ("base", "biological", "stress"):
        selected = [row for row in reference if row["group"] == partition]
        groups[f"{partition}_all"] = sorted(row["id"] for row in selected)
        groups[f"{partition}_concave"] = sorted(
            row["id"] for row in selected if truthy(row["has_cutout"])
        )
        groups[f"{partition}_ordinary"] = sorted(
            row["id"] for row in selected if not truthy(row["has_cutout"])
        )
    public_ids = sorted(row["id"] for row in reference if row["group"] == "public_ktc")
    groups["public_ktc_all"] = public_ids
    groups["public_ktc_nonconvex"] = sorted(set(public_ids) & strict_ids)
    groups["public_ktc_ordinary"] = sorted(set(public_ids) - strict_ids)
    return {name: ids for name, ids in groups.items() if ids}


def lookup(rows: list[dict[str, str]]) -> dict[tuple[str, str], dict[str, str]]:
    selected = [row for row in rows if row["method"] in METHODS]
    result = {(row["id"], row["method"]): row for row in selected}
    if len(result) != len(selected):
        raise ValueError("duplicate case/method rows found")
    return result


def matrix(
    lookups: list[dict[tuple[str, str], dict[str, str]]],
    ids: list[str],
    method: str,
    metric: str,
) -> np.ndarray:
    values = np.full((len(lookups), len(ids)), np.nan, dtype=np.float64)
    for seed_index, table in enumerate(lookups):
        for case_index, case_id in enumerate(ids):
            raw = table[(case_id, method)].get(metric, "")
            if raw not in (None, "", "nan", "NaN"):
                values[seed_index, case_index] = float(raw)
    return values


def hierarchical_bootstrap(
    differences: np.ndarray, repetitions: int, rng: np.random.Generator
) -> dict[str, object] | None:
    finite_columns = np.isfinite(differences).all(axis=0)
    differences = differences[:, finite_columns]
    if not differences.size:
        return None
    seed_count, case_count = differences.shape
    draws = np.empty(repetitions, dtype=np.float64)
    for start in range(0, repetitions, 1000):
        stop = min(start + 1000, repetitions)
        count = stop - start
        seed_draws = rng.integers(seed_count, size=(count, seed_count))
        case_draws = rng.integers(case_count, size=(count, case_count))
        draws[start:stop] = differences[seed_draws[:, :, None], case_draws[:, None, :]].mean(
            axis=(1, 2)
        )
    per_seed = differences.mean(axis=1)
    return {
        "seed_count": seed_count,
        "case_count": case_count,
        "mean_difference": float(differences.mean()),
        "ci95_low": float(np.percentile(draws, 2.5)),
        "ci95_high": float(np.percentile(draws, 97.5)),
        "probability_positive": float(np.mean(draws > 0)),
        "per_seed_mean_differences": [float(value) for value in per_seed],
        "between_seed_sd": float(np.std(per_seed, ddof=1)),
    }


def tail_summary(differences: np.ndarray) -> dict[str, object]:
    finite = differences[np.isfinite(differences)]
    if not finite.size:
        return {}
    per_seed: list[dict[str, float]] = []
    for row in differences:
        valid = row[np.isfinite(row)]
        per_seed.append(
            {
                "mean": float(valid.mean()),
                "minimum": float(valid.min()),
                "fraction_below_minus_0_01": float(np.mean(valid < -0.01)),
            }
        )
    return {
        "mean": float(finite.mean()),
        "median": float(np.median(finite)),
        "q05": float(np.percentile(finite, 5)),
        "q01": float(np.percentile(finite, 1)),
        "minimum": float(finite.min()),
        "fraction_below_minus_0_01": float(np.mean(finite < -0.01)),
        "fraction_below_minus_0_02": float(np.mean(finite < -0.02)),
        "per_seed": per_seed,
    }


def summarize_group(
    lookups: list[dict[tuple[str, str], dict[str, str]]],
    ids: list[str],
    repetitions: int,
    rng: np.random.Generator,
) -> dict[str, object]:
    matrices = {
        (method, metric): matrix(lookups, ids, method, metric)
        for method in METHODS
        for metric in METRICS
    }
    means: dict[str, dict[str, object]] = {}
    for method in METHODS:
        means[method] = {}
        for metric in METRICS:
            values = matrices[(method, metric)]
            if not np.isfinite(values).any():
                continue
            per_seed = [float(np.nanmean(row)) for row in values]
            means[method][metric] = {
                "pooled_mean": float(np.nanmean(values)),
                "per_seed_means": per_seed,
                "between_seed_sd": float(np.std(per_seed, ddof=1)),
            }
    comparisons: dict[str, object] = {}
    for method in ("topology_residual", "topology_routed"):
        metric_results: dict[str, object] = {}
        for metric in METRICS:
            result = hierarchical_bootstrap(
                matrices[(method, metric)] - matrices[("direct_base", metric)], repetitions, rng
            )
            if result is not None:
                metric_results[metric] = result
        comparisons[f"{method}_minus_direct_base"] = {
            "metrics": metric_results,
            "iou_tail_risk": tail_summary(
                matrices[(method, "foreground_iou")] - matrices[("direct_base", "foreground_iou")]
            ),
        }
    return {"case_count": len(ids), "method_statistics": means, "comparisons": comparisons}


def write_paper_table(path: Path, groups: dict[str, dict[str, object]]) -> None:
    selected = (
        "biological_concave",
        "stress_concave",
        "public_ktc_nonconvex",
        "biological_ordinary",
        "public_ktc_ordinary",
    )
    rows: list[dict[str, object]] = []
    for group_name in selected:
        if group_name not in groups:
            continue
        group = groups[group_name]
        for method in ("topology_residual", "topology_routed"):
            comparison = group["comparisons"][f"{method}_minus_direct_base"]
            for metric in DISPLAY_METRICS:
                if metric not in comparison["metrics"]:
                    continue
                value = comparison["metrics"][metric]
                rows.append(
                    {
                        "group": group_name,
                        "cases": group["case_count"],
                        "method": method,
                        "metric": metric,
                        "mean_delta": value["mean_difference"],
                        "ci95_low": value["ci95_low"],
                        "ci95_high": value["ci95_high"],
                        "bootstrap_probability_positive": value["probability_positive"],
                    }
                )
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def plot_concavity_effects(path: Path, groups: dict[str, dict[str, object]]) -> None:
    selected = ("biological_concave", "stress_concave", "public_ktc_nonconvex")
    figure, axes = plt.subplots(len(selected), 2, figsize=(12.8, 9.2), squeeze=False)
    colors = {"topology_residual": "#1f77b4", "topology_routed": "#1b8a5a"}
    for row_index, group_name in enumerate(selected):
        for column, method in enumerate(("topology_residual", "topology_routed")):
            axis = axes[row_index, column]
            comparison = groups[group_name]["comparisons"][f"{method}_minus_direct_base"]["metrics"]
            values = np.asarray([comparison[metric]["mean_difference"] for metric in DISPLAY_METRICS])
            low = np.asarray([comparison[metric]["ci95_low"] for metric in DISPLAY_METRICS])
            high = np.asarray([comparison[metric]["ci95_high"] for metric in DISPLAY_METRICS])
            positions = np.arange(len(DISPLAY_METRICS))
            axis.bar(positions, values, color=colors[method], alpha=0.92)
            axis.errorbar(
                positions, values, yerr=(values - low, high - values), fmt="none",
                color="#202020", capsize=4,
            )
            axis.axhline(0.0, color="#202020", linewidth=0.9)
            axis.set_xticks(positions, ("IoU", "Boundary F1", "Notch"))
            axis.set_title(f"{group_name.replace('_', ' ')}\n{method.replace('_', ' ')} - direct")
            axis.grid(axis="y", alpha=0.2)
    figure.suptitle("Four-seed concavity effects with paired hierarchical 95% bootstrap CI")
    figure.tight_layout()
    figure.savefig(path, dpi=240)
    plt.close(figure)


def plot_ordinary_tail(
    path: Path,
    groups: dict[str, dict[str, object]],
    lookups: list[dict[tuple[str, str], dict[str, str]]],
    group_ids: dict[str, list[str]],
) -> None:
    selected = ("biological_ordinary", "public_ktc_ordinary")
    figure, axes = plt.subplots(1, 2, figsize=(12.5, 4.8), squeeze=False)
    colors = ("#1f77b4", "#1b8a5a")
    for axis, group_name in zip(axes[0], selected):
        ids = group_ids[group_name]
        direct = matrix(lookups, ids, "direct_base", "foreground_iou")
        distributions = []
        labels = []
        for method in ("topology_residual", "topology_routed"):
            candidate = matrix(lookups, ids, method, "foreground_iou")
            distributions.append((candidate - direct).reshape(-1))
            labels.append(method.replace("topology_", ""))
        boxes = axis.boxplot(distributions, labels=labels, patch_artist=True, showfliers=True)
        for patch, color in zip(boxes["boxes"], colors):
            patch.set_facecolor(color)
            patch.set_alpha(0.75)
        axis.axhline(0.0, color="#202020", linewidth=0.9)
        axis.axhline(-0.01, color="#b9413e", linewidth=1.0, linestyle="--", label="-0.01")
        raw_tail = groups[group_name]["comparisons"]["topology_residual_minus_direct_base"]["iou_tail_risk"]
        route_tail = groups[group_name]["comparisons"]["topology_routed_minus_direct_base"]["iou_tail_risk"]
        axis.set_title(
            f"{group_name.replace('_', ' ')}\n"
            f"raw < -0.01: {raw_tail['fraction_below_minus_0_01']:.1%}; "
            f"routed: {route_tail['fraction_below_minus_0_01']:.1%}"
        )
        axis.set_ylabel("IoU difference from direct trunk")
        axis.grid(axis="y", alpha=0.2)
    axes[0, 1].legend(frameon=False)
    figure.suptitle("Ordinary-case paired tail-risk audit across four seeds")
    figure.tight_layout()
    figure.savefig(path, dpi=240)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    runs = parse_runs(args.runs)
    rows_per_seed = [read_rows(path / "action_router_case_metrics.csv") for _, path in runs]
    summaries = [
        json.loads((path / "action_router_summary.json").read_text(encoding="utf-8"))
        for _, path in runs
    ]
    audit = json.loads(args.audit.resolve().read_text(encoding="utf-8"))
    strict_ids = {str(value) for value in audit["nonconvex_ids"]}
    groups_spec = build_groups(rows_per_seed[0], strict_ids)
    lookups = [lookup(rows) for rows in rows_per_seed]
    rng = np.random.default_rng(args.seed)
    groups = {
        name: summarize_group(lookups, ids, args.bootstrap, rng)
        for name, ids in groups_spec.items()
    }
    result = {
        "seeds": [seed for seed, _ in runs],
        "runs": {seed: str(path) for seed, path in runs},
        "selected_validation_thresholds": {
            seed: float(summary["threshold"])
            for (seed, _), summary in zip(runs, summaries)
        },
        "methods": list(METHODS),
        "metrics": list(METRICS),
        "groups": groups,
        "bootstrap_repetitions": args.bootstrap,
        "bootstrap_design": "paired hierarchical resampling of random seeds and fixed test cases",
        "selection_policy": "each route threshold selected on synthetic validation only",
        "synthetic_test_or_public_truth_used_for_threshold_selection": False,
        "public_ordinary_grouping": "audit IDs applied only after all predictions and thresholds were frozen",
    }
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "action_router_multiseed_summary.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    write_paper_table(output_dir / "action_router_paper_table.csv", groups)
    plot_concavity_effects(output_dir / "action_router_concavity_effects.png", groups)
    plot_ordinary_tail(
        output_dir / "action_router_ordinary_tail.png", groups, lookups, groups_spec
    )
    print(
        json.dumps(
            {
                "thresholds": result["selected_validation_thresholds"],
                "groups": {name: value["case_count"] for name, value in groups.items()},
                "output_dir": str(output_dir),
            },
            indent=2,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
