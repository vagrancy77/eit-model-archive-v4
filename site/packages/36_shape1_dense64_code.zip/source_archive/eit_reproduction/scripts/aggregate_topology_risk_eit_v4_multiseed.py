"""Aggregate v4 topology-risk EIT runs without using public truth for selection."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


METHODS = ("direct_base", "topology_residual", "topology_safe")
METRICS = (
    "foreground_iou",
    "foreground_dice",
    "boundary_f1",
    "notch_preservation",
    "bank_retention",
    "spurious_hole_fraction",
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", nargs="+", required=True, help="seed=final_evaluation_directory")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--bootstrap", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260915)
    parser.add_argument(
        "--audit",
        type=Path,
        default=root / "outputs" / "ktc2023_full_audit" / "summary.json",
    )
    return parser.parse_args()


def parse_runs(values: list[str]) -> list[tuple[str, Path]]:
    runs: list[tuple[str, Path]] = []
    for value in values:
        if "=" not in value:
            raise ValueError(f"run must be seed=directory, got {value!r}")
        seed, raw_path = value.split("=", 1)
        path = Path(raw_path).resolve()
        for filename in ("synthetic_case_metrics.csv", "public_ktc_case_metrics.csv"):
            if not (path / filename).is_file():
                raise FileNotFoundError(path / filename)
        runs.append((seed, path))
    if len(runs) < 2:
        raise ValueError("at least two runs are required")
    if len({seed for seed, _ in runs}) != len(runs):
        raise ValueError("seed labels must be unique")
    return runs


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def truthy(value: str) -> bool:
    return value.strip().lower() in {"1", "true", "yes"}


def build_groups(
    synthetic: list[dict[str, str]], public: list[dict[str, str]], strict_ids: set[str]
) -> dict[str, tuple[str, list[str]]]:
    reference = [row for row in synthetic if row["method"] == "direct_base"]
    groups: dict[str, tuple[str, list[str]]] = {}
    for partition in sorted({row["group"] for row in reference}):
        rows = [row for row in reference if row["group"] == partition]
        groups[f"{partition}_all"] = ("synthetic", sorted(row["id"] for row in rows))
        groups[f"{partition}_concave"] = (
            "synthetic",
            sorted(row["id"] for row in rows if truthy(row["has_notch"])),
        )
        groups[f"{partition}_ordinary"] = (
            "synthetic",
            sorted(row["id"] for row in rows if not truthy(row["has_notch"])),
        )
    public_ids = sorted(row["id"] for row in public if row["method"] == "direct_base")
    groups["public_ktc_all"] = ("public", public_ids)
    groups["public_ktc_nonconvex"] = ("public", sorted(set(public_ids) & strict_ids))
    groups["public_ktc_ordinary"] = ("public", sorted(set(public_ids) - strict_ids))
    return {name: value for name, value in groups.items() if value[1]}


def lookup(rows: list[dict[str, str]]) -> dict[tuple[str, str], dict[str, str]]:
    result = {(row["id"], row["method"]): row for row in rows if row["method"] in METHODS}
    if len(result) != len([row for row in rows if row["method"] in METHODS]):
        raise ValueError("duplicate case/method rows found")
    return result


def matrix(
    lookups: list[dict[tuple[str, str], dict[str, str]]],
    ids: list[str],
    method: str,
    metric: str,
) -> np.ndarray:
    values = np.full((len(lookups), len(ids)), np.nan, dtype=np.float64)
    for seed_index, table in enumerate(lookups):
        for case_index, case_id in enumerate(ids):
            row = table[(case_id, method)]
            raw = row.get(metric, "")
            if raw not in (None, "", "nan", "NaN"):
                values[seed_index, case_index] = float(raw)
    return values


def hierarchical_bootstrap(
    differences: np.ndarray, repetitions: int, rng: np.random.Generator
) -> dict[str, object] | None:
    finite = np.isfinite(differences).all(axis=0)
    differences = differences[:, finite]
    if differences.size == 0:
        return None
    seed_count, case_count = differences.shape
    draws = np.empty(repetitions, dtype=np.float64)
    chunk = 1000
    for start in range(0, repetitions, chunk):
        stop = min(start + chunk, repetitions)
        count = stop - start
        seed_draws = rng.integers(seed_count, size=(count, seed_count))
        case_draws = rng.integers(case_count, size=(count, case_count))
        draws[start:stop] = differences[seed_draws[:, :, None], case_draws[:, None, :]].mean(
            axis=(1, 2)
        )
    per_seed = differences.mean(axis=1)
    return {
        "seed_count": seed_count,
        "case_count": case_count,
        "mean_difference": float(differences.mean()),
        "ci95_low": float(np.percentile(draws, 2.5)),
        "ci95_high": float(np.percentile(draws, 97.5)),
        "probability_positive": float(np.mean(draws > 0)),
        "per_seed_mean_differences": [float(value) for value in per_seed],
        "between_seed_sd": float(np.std(per_seed, ddof=1)) if seed_count > 1 else 0.0,
    }


def tail_summary(differences: np.ndarray) -> dict[str, object]:
    finite = differences[np.isfinite(differences)]
    if finite.size == 0:
        return {}
    per_seed = []
    for row in differences:
        valid = row[np.isfinite(row)]
        per_seed.append(
            {
                "mean": float(valid.mean()),
                "minimum": float(valid.min()),
                "fraction_below_minus_0_01": float(np.mean(valid < -0.01)),
            }
        )
    return {
        "mean": float(finite.mean()),
        "median": float(np.median(finite)),
        "q05": float(np.percentile(finite, 5)),
        "q01": float(np.percentile(finite, 1)),
        "minimum": float(finite.min()),
        "fraction_below_minus_0_01": float(np.mean(finite < -0.01)),
        "fraction_below_minus_0_02": float(np.mean(finite < -0.02)),
        "fraction_below_minus_0_05": float(np.mean(finite < -0.05)),
        "per_seed": per_seed,
    }


def summarize_group(
    lookups: list[dict[tuple[str, str], dict[str, str]]],
    ids: list[str],
    repetitions: int,
    rng: np.random.Generator,
) -> dict[str, object]:
    matrices: dict[tuple[str, str], np.ndarray] = {}
    means: dict[str, dict[str, object]] = {}
    for method in METHODS:
        means[method] = {}
        for metric in METRICS:
            values = matrix(lookups, ids, method, metric)
            matrices[(method, metric)] = values
            if np.isfinite(values).any():
                per_seed = np.asarray(
                    [np.nanmean(row) if np.isfinite(row).any() else np.nan for row in values]
                )
                means[method][metric] = {
                    "pooled_mean": float(np.nanmean(values)),
                    "per_seed_means": [float(value) for value in per_seed],
                    "between_seed_sd": float(np.nanstd(per_seed, ddof=1)),
                }
    comparisons: dict[str, object] = {}
    for method in ("topology_residual", "topology_safe"):
        metric_results: dict[str, object] = {}
        for metric in METRICS:
            result = hierarchical_bootstrap(
                matrices[(method, metric)] - matrices[("direct_base", metric)], repetitions, rng
            )
            if result is not None:
                metric_results[metric] = result
        iou_difference = matrices[(method, "foreground_iou")] - matrices[("direct_base", "foreground_iou")]
        comparisons[f"{method}_minus_direct_base"] = {
            "metrics": metric_results,
            "iou_tail_risk": tail_summary(iou_difference),
        }
    return {"case_count": len(ids), "method_statistics": means, "comparisons": comparisons}


def plot_effects(path: Path, groups: dict[str, dict[str, object]]) -> None:
    preferred = ("biological_concave", "stress_concave", "public_ktc_nonconvex")
    selected = [name for name in preferred if name in groups]
    metrics = ("foreground_iou", "boundary_f1", "notch_preservation", "spurious_hole_fraction")
    figure, axes = plt.subplots(len(selected), 2, figsize=(13.2, 3.3 * len(selected)), squeeze=False)
    colors = {"topology_residual": "#2377b4", "topology_safe": "#d27920"}
    for row_index, group_name in enumerate(selected):
        group = groups[group_name]
        for column, method in enumerate(("topology_residual", "topology_safe")):
            axis = axes[row_index, column]
            comparison = group["comparisons"][f"{method}_minus_direct_base"]["metrics"]
            available = [metric for metric in metrics if metric in comparison]
            values = np.asarray([comparison[metric]["mean_difference"] for metric in available])
            low = np.asarray([comparison[metric]["ci95_low"] for metric in available])
            high = np.asarray([comparison[metric]["ci95_high"] for metric in available])
            x = np.arange(len(available))
            axis.bar(x, values, color=colors[method], alpha=0.9)
            axis.errorbar(x, values, yerr=(values - low, high - values), fmt="none", color="#222222", capsize=4)
            axis.axhline(0.0, color="#222222", linewidth=0.9)
            axis.set_xticks(x, [name.replace("_", "\n") for name in available])
            axis.set_title(f"{group_name}: {method} - direct")
            axis.grid(axis="y", alpha=0.2)
    figure.suptitle("Four-seed paired hierarchical bootstrap effects")
    figure.tight_layout()
    figure.savefig(path, dpi=220)
    plt.close(figure)


def plot_ordinary_tail(path: Path, groups: dict[str, dict[str, object]]) -> None:
    selected = [name for name in ("biological_ordinary", "public_ktc_ordinary") if name in groups]
    figure, axes = plt.subplots(1, len(selected), figsize=(6.2 * len(selected), 4.4), squeeze=False)
    for axis, group_name in zip(axes[0], selected):
        labels, means, minima, failure = [], [], [], []
        for method in ("topology_residual", "topology_safe"):
            tail = groups[group_name]["comparisons"][f"{method}_minus_direct_base"]["iou_tail_risk"]
            labels.append(method.replace("topology_", ""))
            means.append(tail["mean"])
            minima.append(tail["minimum"])
            failure.append(tail["fraction_below_minus_0_01"])
        x = np.arange(2)
        width = 0.25
        axis.bar(x - width, means, width, label="mean IoU delta", color="#2377b4")
        axis.bar(x, minima, width, label="worst IoU delta", color="#b9413e")
        axis.bar(x + width, failure, width, label="fraction delta < -0.01", color="#d8a22e")
        axis.axhline(0.0, color="#222222", linewidth=0.9)
        axis.set_xticks(x, labels)
        axis.set_title(group_name)
        axis.grid(axis="y", alpha=0.2)
    axes[0, -1].legend(frameon=False)
    figure.suptitle("Ordinary-case tail-risk audit across all seeds and cases")
    figure.tight_layout()
    figure.savefig(path, dpi=220)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    runs = parse_runs(args.runs)
    synthetic_rows = [read_rows(path / "synthetic_case_metrics.csv") for _, path in runs]
    public_rows = [read_rows(path / "public_ktc_case_metrics.csv") for _, path in runs]
    audit = json.loads(args.audit.resolve().read_text(encoding="utf-8"))
    strict_ids = {str(value) for value in audit["nonconvex_ids"]}
    groups_spec = build_groups(synthetic_rows[0], public_rows[0], strict_ids)
    synthetic_lookups = [lookup(rows) for rows in synthetic_rows]
    public_lookups = [lookup(rows) for rows in public_rows]

    rng = np.random.default_rng(args.seed)
    groups: dict[str, dict[str, object]] = {}
    for name, (source, ids) in groups_spec.items():
        tables = synthetic_lookups if source == "synthetic" else public_lookups
        groups[name] = summarize_group(tables, ids, args.bootstrap, rng)

    result = {
        "seeds": [seed for seed, _ in runs],
        "runs": {seed: str(path) for seed, path in runs},
        "methods": list(METHODS),
        "metrics": list(METRICS),
        "groups": groups,
        "bootstrap_repetitions": args.bootstrap,
        "bootstrap_design": "paired hierarchical resampling of seeds and fixed test cases",
        "selection_policy": "checkpoints and topology-safe resolver fixed without synthetic-test or public-KTC truth",
        "public_truth_used_for_training_calibration_or_checkpoint_selection": False,
    }
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "multiseed_summary.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    plot_effects(output_dir / "multiseed_concavity_effects.png", groups)
    plot_ordinary_tail(output_dir / "multiseed_ordinary_tail_risk.png", groups)
    print(json.dumps({"seeds": result["seeds"], "groups": list(groups)}, indent=2), flush=True)


if __name__ == "__main__":
    main()
