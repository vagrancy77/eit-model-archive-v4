"""Measurement-consistent implicit level-set refinement for non-convex EIT.

The frozen neural ensemble supplies lesion topology, class identity, and a
stable initialization.  A per-case signed-distance correction may move only
near the initialized boundary.  Its direction is determined by the KTC voltage
residual through the public Jacobian, while positive and negative conductivity
contrasts are fitted jointly.  Hyperparameters are selected on synthetic
validation data before the untouched synthetic test or KTC evaluation labels
are accessed.
"""
from __future__ import annotations

import argparse
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import distance_transform_edt
from torch.utils.data import DataLoader, TensorDataset

from train_ktc_concavity_network import (
    InputAdapter,
    aggregate_rows,
    confusion_metrics,
    save_focus_montage,
    save_real_montage,
    write_rows,
)
from train_ktc_concavity_network_v2 import evaluate_real_predictions, set_seed
from train_ktc_highres_refiner import (
    load_coarse_ensemble,
    load_dip_four_case_predictions,
    load_official_four_case_truths,
    save_official_four_case_comparison,
)


@dataclass(frozen=True)
class LevelSetConfig:
    name: str
    band_pixels: float
    anchor_weight: float
    area_weight: float
    displacement_weight: float
    smoothness_weight: float
    eikonal_weight: float


CONFIGS = (
    LevelSetConfig("guarded", 6.0, 2.00, 2.00, 0.0120, 0.050, 0.030),
    LevelSetConfig("balanced", 10.0, 0.80, 0.80, 0.0040, 0.020, 0.020),
    LevelSetConfig("flexible", 14.0, 0.25, 0.30, 0.0015, 0.008, 0.012),
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--coarse-checkpoint", nargs="+", type=Path, required=True)
    parser.add_argument("--coarse-weights", nargs="+", type=float)
    parser.add_argument("--output-dir", type=Path, default=root / "outputs" / "ktc_implicit_levelset")
    parser.add_argument("--official-repo", type=Path, default=root / "external" / "KTC2023-ABC2")
    parser.add_argument("--steps", type=int, default=70)
    parser.add_argument("--learning-rate", type=float, default=0.075)
    parser.add_argument("--batch-size", type=int, default=20)
    parser.add_argument(
        "--validation-limit",
        type=int,
        default=96,
        help="Use the most concave N validation cases for a pilot; 0 uses all validation cases.",
    )
    parser.add_argument("--seed", type=int, default=20260819)
    parser.add_argument("--progress-every", type=int, default=20)
    return parser.parse_args()


def hard_signed_distance(labels: np.ndarray, fov: np.ndarray) -> np.ndarray:
    fields = np.empty(labels.shape, dtype=np.float32)
    for index, sample in enumerate(labels):
        foreground = sample != 0
        field = distance_transform_edt(foreground) - distance_transform_edt(~foreground)
        field[~fov] = -20.0
        fields[index] = np.clip(field, -20.0, 20.0)
    return fields


@torch.no_grad()
def coarse_probabilities(
    coarse: torch.nn.Module,
    adapter: InputAdapter,
    images: np.ndarray,
    voltages: np.ndarray,
    device: torch.device,
    batch_size: int,
) -> np.ndarray:
    result: list[np.ndarray] = []
    coarse.eval()
    for start in range(0, len(images), batch_size):
        image = torch.from_numpy(images[start : start + batch_size, None].astype(np.float32)).to(device)
        voltage = torch.from_numpy(voltages[start : start + batch_size].astype(np.float32)).to(device)
        logits = coarse(adapter(image), voltage)["logits"]
        result.append(torch.softmax(logits, dim=1).cpu().numpy())
    return np.concatenate(result)


def inverse_bounded_amplitude(value: float, low: float, high: float) -> float:
    fraction = min(max((value - low) / (high - low), 1e-4), 1.0 - 1e-4)
    return math.log(fraction / (1.0 - fraction))


def gradients(image: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    return image[:, :, 1:, :] - image[:, :, :-1, :], image[:, :, :, 1:] - image[:, :, :, :-1]


def refine_batch(
    initial_probability: torch.Tensor,
    target_voltage: torch.Tensor,
    signed_distance: torch.Tensor,
    fov: torch.Tensor,
    jacobian: torch.Tensor,
    node_to_raw_pixel: torch.Tensor,
    config: LevelSetConfig,
    steps: int,
    learning_rate: float,
    progress_every: int,
    label: str,
) -> tuple[torch.Tensor, dict[str, float]]:
    device = initial_probability.device
    batch, _, height, width = initial_probability.shape
    foreground_initial = initial_probability[:, 1:].sum(dim=1, keepdim=True).clamp(1e-5, 1.0 - 1e-5)
    class_two_fraction = (
        initial_probability[:, 2:3] / initial_probability[:, 1:].sum(dim=1, keepdim=True).clamp_min(1e-5)
    ).detach()
    signed_distance = signed_distance[:, None]
    boundary_gate = torch.exp(-torch.pow(signed_distance.abs() / config.band_pixels, 4.0)) * fov
    stable_weight = (0.15 + 0.85 * (1.0 - boundary_gate)).detach()

    low_displacement = torch.nn.Parameter(torch.zeros((batch, 1, height // 2, width // 2), device=device))
    high_displacement = torch.nn.Parameter(torch.zeros((batch, 1, height, width), device=device))
    negative_raw = torch.nn.Parameter(
        torch.full((batch, 1, 1, 1), inverse_bounded_amplitude(0.55, 0.05, 0.95), device=device)
    )
    positive_raw = torch.nn.Parameter(
        torch.full((batch, 1, 1, 1), inverse_bounded_amplitude(0.68, 0.05, 1.20), device=device)
    )
    optimizer = torch.optim.Adam(
        (low_displacement, high_displacement, negative_raw, positive_raw), lr=learning_rate
    )
    voltage_rms = torch.sqrt(target_voltage.square().mean(dim=1, keepdim=True) + 1e-10)
    initial_area = (foreground_initial * fov).sum(dim=(1, 2, 3)).clamp_min(1.0)
    final_pieces: dict[str, float] = {}

    for iteration in range(steps):
        optimizer.zero_grad(set_to_none=True)
        low = F.interpolate(low_displacement, size=(height, width), mode="bicubic", align_corners=False)
        displacement = boundary_gate * (low + 0.35 * high_displacement)
        phi = fov * (signed_distance + displacement) + (1.0 - fov) * -20.0
        foreground = torch.sigmoid(phi / 0.72) * fov
        class_one = foreground * (1.0 - class_two_fraction)
        class_two = foreground * class_two_fraction
        negative_amplitude = 0.05 + 0.90 * torch.sigmoid(negative_raw)
        positive_amplitude = 0.05 + 1.15 * torch.sigmoid(positive_raw)
        conductivity = -negative_amplitude * class_one + positive_amplitude * class_two

        raw_pixels = torch.flip(conductivity[:, 0], dims=(1,)).flatten(1)
        node_conductivity = raw_pixels[:, node_to_raw_pixel]
        predicted_voltage = 2.0 * (node_conductivity @ jacobian.T)
        data = torch.mean(torch.square((predicted_voltage - target_voltage) / voltage_rms))
        anchor = torch.mean(stable_weight * torch.square(foreground - foreground_initial))
        current_area = (foreground * fov).sum(dim=(1, 2, 3))
        area = torch.mean(torch.square((current_area - initial_area) / initial_area))
        displacement_penalty = torch.mean(torch.square(displacement) * boundary_gate)
        disp_dy, disp_dx = gradients(displacement)
        smoothness = disp_dy.square().mean() + disp_dx.square().mean()
        phi_dy, phi_dx = gradients(phi)
        grad_norm = torch.sqrt(phi_dy[:, :, :, :-1].square() + phi_dx[:, :, :-1, :].square() + 1e-6)
        boundary_weight = torch.exp(-torch.square(phi[:, :, :-1, :-1] / 2.0))
        eikonal = (boundary_weight * torch.square(grad_norm - 1.0)).sum() / boundary_weight.sum().clamp_min(1.0)
        total = (
            data
            + config.anchor_weight * anchor
            + config.area_weight * area
            + config.displacement_weight * displacement_penalty
            + config.smoothness_weight * smoothness
            + config.eikonal_weight * eikonal
        )
        total.backward()
        torch.nn.utils.clip_grad_norm_(
            (low_displacement, high_displacement, negative_raw, positive_raw), 10.0
        )
        optimizer.step()
        final_pieces = {
            "total": float(total.detach()),
            "data": float(data.detach()),
            "anchor": float(anchor.detach()),
            "area": float(area.detach()),
            "displacement": float(displacement_penalty.detach()),
            "smoothness": float(smoothness.detach()),
            "eikonal": float(eikonal.detach()),
            "negative_amplitude": float(negative_amplitude.mean().detach()),
            "positive_amplitude": float(positive_amplitude.mean().detach()),
        }
        if progress_every and (
            iteration == 0 or (iteration + 1) % progress_every == 0 or iteration + 1 == steps
        ):
            print(
                f"{label} step {iteration + 1}/{steps}: total={final_pieces['total']:.4f}, "
                f"data={final_pieces['data']:.4f}, anchor={final_pieces['anchor']:.5f}, "
                f"disp={final_pieces['displacement']:.3f}",
                flush=True,
            )

    with torch.no_grad():
        low = F.interpolate(low_displacement, size=(height, width), mode="bicubic", align_corners=False)
        displacement = boundary_gate * (low + 0.35 * high_displacement)
        phi = fov * (signed_distance + displacement) + (1.0 - fov) * -20.0
        foreground = phi > 0.0
        class_two = class_two_fraction >= 0.5
        prediction = torch.zeros((batch, height, width), dtype=torch.long, device=device)
        prediction[foreground[:, 0] & ~class_two[:, 0]] = 1
        prediction[foreground[:, 0] & class_two[:, 0]] = 2
    return prediction, final_pieces


def refine_arrays(
    probabilities: np.ndarray,
    voltages: np.ndarray,
    fov: np.ndarray,
    jacobian: np.ndarray,
    node_to_raw_pixel: np.ndarray,
    config: LevelSetConfig,
    args: argparse.Namespace,
    device: torch.device,
    label: str,
) -> tuple[np.ndarray, list[dict[str, float]]]:
    initial_labels = probabilities.argmax(axis=1).astype(np.uint8)
    signed_distance = hard_signed_distance(initial_labels, fov)
    dataset = TensorDataset(
        torch.from_numpy(probabilities.astype(np.float32)),
        torch.from_numpy(voltages.astype(np.float32)),
        torch.from_numpy(signed_distance),
    )
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False)
    fov_tensor = torch.from_numpy(fov.astype(np.float32))[None, None].to(device)
    jacobian_tensor = torch.from_numpy(jacobian.astype(np.float32)).to(device)
    node_map_tensor = torch.from_numpy(node_to_raw_pixel.astype(np.int64)).to(device)
    predictions: list[np.ndarray] = []
    losses: list[dict[str, float]] = []
    for batch_index, (probability, voltage, sdf) in enumerate(loader):
        prediction, pieces = refine_batch(
            probability.to(device),
            voltage.to(device),
            sdf.to(device),
            fov_tensor,
            jacobian_tensor,
            node_map_tensor,
            config,
            args.steps,
            args.learning_rate,
            args.progress_every,
            f"{label} batch {batch_index + 1}/{len(loader)}",
        )
        predictions.append(prediction.cpu().numpy().astype(np.uint8))
        losses.append(pieces)
    return np.concatenate(predictions), losses


def evaluate_synthetic(
    truths: np.ndarray,
    predictions: np.ndarray,
    indentations: np.ndarray,
) -> tuple[dict[str, float], list[dict[str, float]]]:
    rows = [
        confusion_metrics(truth, prediction, indentation)
        for truth, prediction, indentation in zip(truths, predictions, indentations)
    ]
    return aggregate_rows(rows), rows


def selection_score(metrics: dict[str, float]) -> float:
    return (
        0.45 * metrics["foreground_iou"]
        + 0.25 * metrics["boundary_f1"]
        + 0.30 * metrics["concavity_score"]
    )


def save_synthetic_montage(
    path: Path,
    truths: np.ndarray,
    coarse: np.ndarray,
    refined: np.ndarray,
    indentations: np.ndarray,
    title: str,
) -> None:
    indices = np.argsort(indentations.reshape(len(indentations), -1).sum(axis=1))[::-1][:8]
    figure, axes = plt.subplots(len(indices), 3, figsize=(7.5, 2.3 * len(indices)), squeeze=False)
    for row, index in enumerate(indices):
        for column, (image, name) in enumerate(
            ((truths[index], "truth"), (coarse[index], "coarse fusion"), (refined[index], "physics level set"))
        ):
            axes[row, column].imshow(image, cmap="gray", vmin=0, vmax=2, interpolation="nearest")
            axes[row, column].set_title(name)
            axes[row, column].set_axis_off()
    figure.suptitle(title)
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def upsample_labels(probabilities: np.ndarray, labels64: np.ndarray, size: int = 256) -> np.ndarray:
    probability = torch.from_numpy(probabilities.astype(np.float32))
    fraction_two = probability[:, 2:3] / probability[:, 1:].sum(dim=1, keepdim=True).clamp_min(1e-5)
    foreground = torch.from_numpy((labels64 != 0).astype(np.float32))[:, None]
    foreground = F.interpolate(foreground, size=(size, size), mode="nearest")[:, 0] > 0.5
    class_two = F.interpolate(fraction_two, size=(size, size), mode="bilinear", align_corners=False)[:, 0] >= 0.5
    result = torch.zeros((len(labels64), size, size), dtype=torch.uint8)
    result[foreground & ~class_two] = 1
    result[foreground & class_two] = 2
    return result.numpy()


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    archive = np.load(args.dataset.resolve(), allow_pickle=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    coarse, coarse_states, coarse_weights = load_coarse_ensemble(
        args.coarse_checkpoint, args.coarse_weights, device
    )
    adapter = InputAdapter(archive["fov_mask"]).to(device)
    validation_indices = np.asarray(archive["validation_indices"], dtype=np.int64)
    if args.validation_limit > 0 and args.validation_limit < validation_indices.size:
        indentation_sizes = archive["indentation_masks"][validation_indices].reshape(len(validation_indices), -1).sum(axis=1)
        validation_indices = validation_indices[np.argsort(indentation_sizes)[::-1][: args.validation_limit]]

    validation_probabilities = coarse_probabilities(
        coarse,
        adapter,
        archive["linear_images"][validation_indices],
        archive["voltages"][validation_indices],
        device,
        args.batch_size,
    )
    validation_coarse = validation_probabilities.argmax(axis=1).astype(np.uint8)
    validation_truth = archive["labels"][validation_indices]
    validation_indent = archive["indentation_masks"][validation_indices]
    coarse_validation_metrics, _ = evaluate_synthetic(
        validation_truth, validation_coarse, validation_indent
    )
    candidate_records: list[dict[str, object]] = []
    candidate_predictions: dict[str, np.ndarray] = {}
    for config in CONFIGS:
        predictions, losses = refine_arrays(
            validation_probabilities,
            archive["voltages"][validation_indices],
            archive["fov_mask"].astype(bool),
            archive["jacobian"],
            archive["node_to_raw_pixel"],
            config,
            args,
            device,
            f"validation/{config.name}",
        )
        metrics, _ = evaluate_synthetic(validation_truth, predictions, validation_indent)
        eligible = (
            metrics["foreground_iou"] >= coarse_validation_metrics["foreground_iou"] - 0.005
            and metrics["boundary_f1"] >= coarse_validation_metrics["boundary_f1"] - 0.010
        )
        record = {
            "config": asdict(config),
            "metrics": metrics,
            "eligible": bool(eligible),
            "selection_score": selection_score(metrics) if eligible else -math.inf,
            "mean_final_losses": {
                key: float(np.mean([row[key] for row in losses])) for key in losses[0]
            },
        }
        candidate_records.append(record)
        candidate_predictions[config.name] = predictions
        print(f"validation candidate {config.name}: {metrics}; eligible={eligible}", flush=True)

    eligible_records = [record for record in candidate_records if bool(record["eligible"])]
    if eligible_records:
        selected_record = max(eligible_records, key=lambda record: float(record["selection_score"]))
        selected_config = next(config for config in CONFIGS if config.name == selected_record["config"]["name"])
        selected_validation = candidate_predictions[selected_config.name]
    else:
        selected_record = {
            "config": {"name": "identity"},
            "metrics": coarse_validation_metrics,
            "eligible": True,
            "selection_score": selection_score(coarse_validation_metrics),
        }
        selected_config = None
        selected_validation = validation_coarse
    selection = {
        "coarse_metrics": coarse_validation_metrics,
        "candidates": candidate_records,
        "selected": selected_record,
        "validation_indices": validation_indices.tolist(),
        "evaluation_truth_accessed": False,
    }
    (output_dir / "validation_selection.json").write_text(json.dumps(selection, indent=2), encoding="utf-8")
    save_synthetic_montage(
        output_dir / "validation_most_concave.png",
        validation_truth,
        validation_coarse,
        selected_validation,
        validation_indent,
        "Synthetic validation: non-convex boundary selection",
    )

    test_indices = np.asarray(archive["test_indices"], dtype=np.int64)
    test_probabilities = coarse_probabilities(
        coarse,
        adapter,
        archive["linear_images"][test_indices],
        archive["voltages"][test_indices],
        device,
        args.batch_size,
    )
    test_coarse = test_probabilities.argmax(axis=1).astype(np.uint8)
    if selected_config is None:
        test_refined = test_coarse.copy()
        test_losses: list[dict[str, float]] = []
    else:
        test_refined, test_losses = refine_arrays(
            test_probabilities,
            archive["voltages"][test_indices],
            archive["fov_mask"].astype(bool),
            archive["jacobian"],
            archive["node_to_raw_pixel"],
            selected_config,
            args,
            device,
            "synthetic-test",
        )
    test_truth = archive["labels"][test_indices]
    test_indent = archive["indentation_masks"][test_indices]
    test_coarse_metrics, _ = evaluate_synthetic(test_truth, test_coarse, test_indent)
    test_refined_metrics, _ = evaluate_synthetic(test_truth, test_refined, test_indent)
    save_synthetic_montage(
        output_dir / "synthetic_test_most_concave.png",
        test_truth,
        test_coarse,
        test_refined,
        test_indent,
        "Untouched synthetic test: non-convex boundary refinement",
    )

    # KTC evaluation truths are first accessed below, after selection and the
    # untouched synthetic test have been completed.
    real_probabilities = coarse_probabilities(
        coarse,
        adapter,
        archive["real_linear_images"],
        archive["real_voltages"],
        device,
        args.batch_size,
    )
    real_coarse64 = real_probabilities.argmax(axis=1).astype(np.uint8)
    if selected_config is None:
        real_refined64 = real_coarse64.copy()
        real_losses: list[dict[str, float]] = []
    else:
        real_refined64, real_losses = refine_arrays(
            real_probabilities,
            archive["real_voltages"],
            archive["fov_mask"].astype(bool),
            archive["jacobian"],
            archive["node_to_raw_pixel"],
            selected_config,
            args,
            device,
            "ktc-evaluation",
        )
    real_coarse = upsample_labels(real_probabilities, real_coarse64)
    real_refined = upsample_labels(real_probabilities, real_refined64)
    real_truth = archive["real_labels"]
    real_ids = archive["real_ids"]
    real_predictions = {"coarse_fusion": real_coarse, "physics_levelset": real_refined}
    real_summary: dict[str, dict[str, float]] = {}
    real_rows: list[dict[str, object]] = []
    for name, prediction in real_predictions.items():
        real_summary[name], rows = evaluate_real_predictions(name, prediction, real_truth, real_ids)
        real_rows.extend(rows)
    write_rows(output_dir / "real_case_metrics.csv", real_rows)
    save_real_montage(output_dir / "real_all_21_comparison.png", real_truth, real_ids, real_predictions, real_rows)
    save_focus_montage(output_dir / "real_most_concave_comparison.png", real_truth, real_ids, real_predictions, real_rows)

    calibration_probabilities = coarse_probabilities(
        coarse,
        adapter,
        archive["calibration_linear_images"],
        archive["calibration_voltages"],
        device,
        args.batch_size,
    )
    calibration_coarse64 = calibration_probabilities.argmax(axis=1).astype(np.uint8)
    if selected_config is None:
        calibration_refined64 = calibration_coarse64.copy()
    else:
        calibration_refined64, _ = refine_arrays(
            calibration_probabilities,
            archive["calibration_voltages"],
            archive["fov_mask"].astype(bool),
            archive["jacobian"],
            archive["node_to_raw_pixel"],
            selected_config,
            args,
            device,
            "official-four",
        )
    calibration_coarse = upsample_labels(calibration_probabilities, calibration_coarse64)
    calibration_refined = upsample_labels(calibration_probabilities, calibration_refined64)
    official_truth, official_ids = load_official_four_case_truths(args.official_repo.resolve())
    official_predictions = {
        "DIP+TV": load_dip_four_case_predictions(Path(__file__).resolve().parents[1]),
        "coarse_fusion": calibration_coarse,
        "physics_levelset": calibration_refined,
    }
    official_summary: dict[str, dict[str, float]] = {}
    official_rows: list[dict[str, object]] = []
    for name, prediction in official_predictions.items():
        official_summary[name], rows = evaluate_real_predictions(name, prediction, official_truth, official_ids)
        official_rows.extend(rows)
    write_rows(output_dir / "official_four_case_metrics.csv", official_rows)
    save_official_four_case_comparison(
        output_dir / "official_four_case_comparison.png",
        official_truth,
        official_ids,
        official_predictions,
        official_rows,
    )

    result = {
        "method": "frozen neural topology/class initialization plus measurement-consistent implicit level set",
        "dataset": str(args.dataset.resolve()),
        "coarse_checkpoints": [str(path.resolve()) for path in args.coarse_checkpoint],
        "coarse_weights": coarse_weights,
        "coarse_epochs": [int(state.get("epoch", -1)) for state in coarse_states],
        "device": str(device),
        "seed": args.seed,
        "validation_selection": selection,
        "synthetic_untouched_test": {
            "coarse_fusion": test_coarse_metrics,
            "physics_levelset": test_refined_metrics,
        },
        "real_evaluation": real_summary,
        "official_four_calibration_cases": official_summary,
        "official_four_are_training_calibration_not_independent_test": True,
        "evaluation_truth_used_for_training_or_selection": False,
        "linearized_physics_pilot": True,
        "next_stage_if_successful": "replace the fixed Jacobian residual with nonlinear CEM shape derivatives",
        "args": vars(args) | {
            "dataset": str(args.dataset),
            "coarse_checkpoint": [str(path) for path in args.coarse_checkpoint],
            "output_dir": str(args.output_dir),
            "official_repo": str(args.official_repo),
        },
    }
    (output_dir / "summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    np.savez_compressed(
        output_dir / "predictions.npz",
        real_ids=real_ids,
        real_truth=real_truth,
        real_coarse=real_coarse,
        real_refined=real_refined,
        test_indices=test_indices,
        test_truth=test_truth,
        test_coarse=test_coarse,
        test_refined=test_refined,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
