"""Finalize a leakage-free reliability-gated topology-aware EIT experiment.

The two reconstruction networks are frozen. A small case-wise reliability
model is fitted only on synthetic validation predictions. Public KTC labels
and the independent synthetic test sets are opened only after the policy is
frozen.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from scipy import ndimage as ndi
from sklearn.ensemble import ExtraTreesRegressor, RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.model_selection import KFold, cross_val_predict
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

import train_ktc_concavity_network as net
from audit_ktc_instance_bay_topology import case_metrics as bay_metrics


STRICT_IDS = {
    "level_2/1", "level_2/3", "level_3/2", "level_5/2", "level_6/2",
    "level_6/3", "level_7/1", "level_7/2", "level_7/3",
}
FEATURE_NAMES = (
    "shape_fg", "vanilla_fg", "fg_delta", "hard_disagreement",
    "shape_indent", "vanilla_indent", "indent_delta",
    "shape_entropy", "vanilla_entropy", "entropy_delta",
    "shape_confidence", "vanilla_confidence", "confidence_delta",
    "shape_fg_probability", "vanilla_fg_probability", "fg_probability_delta",
    "sdf_abs_mean", "sdf_positive_fraction", "sdf_q90",
    "delta_abs_mean", "delta_q90", "physics_log_residual",
    "input_abs_mean", "input_abs_q90", "input_gradient",
    "shape_components", "vanilla_components", "shape_holes", "vanilla_holes",
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--checkpoint-dir", type=Path, default=root / "outputs" / "ktc_shape_network_v1")
    parser.add_argument("--output-dir", type=Path, default=root / "outputs" / "ktc_topology_selective_final_cpu")
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--ood-samples", type=int, default=420)
    parser.add_argument("--bootstrap", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260821)
    return parser.parse_args()


def infer(model, adapter, images: np.ndarray, device: torch.device, batch_size: int):
    model.eval()
    output: dict[str, list[np.ndarray]] = {}
    with torch.no_grad():
        for start in range(0, len(images), batch_size):
            x = torch.from_numpy(images[start:start + batch_size, None].astype(np.float32)).to(device)
            current = model(adapter(x))
            for key, value in current.items():
                output.setdefault(key, []).append(value.cpu().numpy())
    return {key: np.concatenate(value) for key, value in output.items()}


def hard_predictions(outputs: dict[str, np.ndarray]) -> np.ndarray:
    return outputs["logits"].argmax(axis=1).astype(np.uint8)


def probabilities(logits: np.ndarray) -> np.ndarray:
    shifted = logits - logits.max(axis=1, keepdims=True)
    exp = np.exp(shifted)
    return exp / exp.sum(axis=1, keepdims=True)


def topology_counts(labels: np.ndarray) -> tuple[float, float]:
    foreground = labels != 0
    _, components = ndi.label(foreground, structure=np.ones((3, 3), dtype=np.uint8))
    holes_mask = ndi.binary_fill_holes(foreground) & ~foreground
    _, holes = ndi.label(holes_mask, structure=np.ones((3, 3), dtype=np.uint8))
    return float(components), float(holes)


def physics_residual(delta: np.ndarray, voltages: np.ndarray, archive) -> np.ndarray:
    raw = np.flip(delta[:, 0], axis=1).reshape(len(delta), -1)
    nodes = raw[:, archive["node_to_raw_pixel"]]
    predicted = 2.0 * (nodes @ archive["jacobian"].T)
    rms = np.sqrt(np.mean(voltages * voltages, axis=1)).clip(1e-8)
    return np.log1p(np.mean(((predicted - voltages) / rms[:, None]) ** 2, axis=1))


def feature_matrix(
    images: np.ndarray,
    voltages: np.ndarray,
    vanilla_outputs: dict[str, np.ndarray],
    shape_outputs: dict[str, np.ndarray],
    archive,
) -> np.ndarray:
    vp, sp = hard_predictions(vanilla_outputs), hard_predictions(shape_outputs)
    vprob, sprob = probabilities(vanilla_outputs["logits"]), probabilities(shape_outputs["logits"])
    ventropy = -np.sum(vprob * np.log(vprob.clip(1e-8)), axis=1).mean(axis=(1, 2))
    sentropy = -np.sum(sprob * np.log(sprob.clip(1e-8)), axis=1).mean(axis=(1, 2))
    vconf, sconf = vprob.max(axis=1).mean(axis=(1, 2)), sprob.max(axis=1).mean(axis=(1, 2))
    vfgp, sfgp = vprob[:, 1:].sum(axis=1).mean(axis=(1, 2)), sprob[:, 1:].sum(axis=1).mean(axis=(1, 2))
    vfg, sfg = (vp != 0).mean(axis=(1, 2)), (sp != 0).mean(axis=(1, 2))
    vindent = np.asarray([net.indentation_mask(x).mean() for x in vp])
    sindent = np.asarray([net.indentation_mask(x).mean() for x in sp])
    sdf = shape_outputs["sdf"][:, 0]
    delta = shape_outputs["delta"]
    selected = images[:, archive["fov_mask"].astype(bool)]
    center = np.median(selected, axis=1)
    centered = images - center[:, None, None]
    scale = np.quantile(np.abs(centered[:, archive["fov_mask"].astype(bool)]), 0.985, axis=1).clip(1e-6)
    normalized = np.clip(centered / scale[:, None, None], -3.0, 3.0)
    gradient = np.mean(np.abs(np.diff(normalized, axis=1)), axis=(1, 2)) + np.mean(
        np.abs(np.diff(normalized, axis=2)), axis=(1, 2)
    )
    shape_topology = np.asarray([topology_counts(x) for x in sp])
    vanilla_topology = np.asarray([topology_counts(x) for x in vp])
    values = np.column_stack((
        sfg, vfg, sfg - vfg, (sp != vp).mean(axis=(1, 2)),
        sindent, vindent, sindent - vindent,
        sentropy, ventropy, sentropy - ventropy,
        sconf, vconf, sconf - vconf,
        sfgp, vfgp, sfgp - vfgp,
        np.abs(sdf).mean(axis=(1, 2)), (sdf > 0).mean(axis=(1, 2)),
        np.quantile(np.abs(sdf).reshape(len(sdf), -1), 0.90, axis=1),
        np.abs(delta[:, 0]).mean(axis=(1, 2)),
        np.quantile(np.abs(delta[:, 0]).reshape(len(delta), -1), 0.90, axis=1),
        physics_residual(delta, voltages, archive),
        np.abs(normalized).mean(axis=(1, 2)),
        np.quantile(np.abs(normalized).reshape(len(normalized), -1), 0.90, axis=1), gradient,
        shape_topology[:, 0], vanilla_topology[:, 0], shape_topology[:, 1], vanilla_topology[:, 1],
    )).astype(np.float32)
    if values.shape[1] != len(FEATURE_NAMES):
        raise RuntimeError("feature definition mismatch")
    return values


def resize_predictions(predictions: np.ndarray, size: int = 256) -> np.ndarray:
    if predictions.shape[-1] == size:
        return predictions
    return np.stack([
        np.asarray(Image.fromarray(x).resize((size, size), Image.Resampling.NEAREST), dtype=np.uint8)
        for x in predictions
    ])


def per_case_metrics(truths: np.ndarray, predictions: np.ndarray, indentations: np.ndarray | None = None):
    rows = []
    for index, (truth, prediction) in enumerate(zip(truths, predictions)):
        indentation = net.indentation_mask(truth) if indentations is None else indentations[index].astype(bool)
        row = net.confusion_metrics(truth, prediction, indentation)
        row["ktc_ssim"] = net.ktc_score(truth, prediction)
        rows.append(row)
    return rows


def materially_concave(truths: np.ndarray, indentations: np.ndarray) -> np.ndarray:
    notch = indentations.reshape(len(indentations), -1).sum(axis=1)
    foreground = (truths != 0).reshape(len(truths), -1).sum(axis=1).clip(1)
    return (notch >= 8) & (notch / foreground >= 0.03)


def utility(rows: list[dict[str, float]], concave: np.ndarray) -> np.ndarray:
    output = np.empty(len(rows), dtype=np.float64)
    for index, row in enumerate(rows):
        notch = float(row["notch_preservation"]) if np.isfinite(row["notch_preservation"]) else 0.0
        if concave[index]:
            output[index] = 0.55 * row["foreground_iou"] + 0.20 * row["boundary_f1"] + 0.25 * notch
        else:
            output[index] = 0.75 * row["foreground_iou"] + 0.25 * row["boundary_f1"]
    return output


def candidate_models(seed: int):
    return {
        "ridge_1": make_pipeline(StandardScaler(), Ridge(alpha=1.0)),
        "ridge_10": make_pipeline(StandardScaler(), Ridge(alpha=10.0)),
        "extra_trees": ExtraTreesRegressor(
            n_estimators=300, min_samples_leaf=10, max_features=0.75, random_state=seed, n_jobs=-1
        ),
        "random_forest": RandomForestRegressor(
            n_estimators=300, min_samples_leaf=10, max_features=0.75, random_state=seed, n_jobs=-1
        ),
    }


def policy_row(
    name: str,
    threshold: float,
    score: np.ndarray,
    vanilla_rows: list[dict[str, float]],
    shape_rows: list[dict[str, float]],
    concave: np.ndarray,
) -> dict[str, float | str | int | bool]:
    use = score >= threshold
    diou = np.asarray([s["foreground_iou"] - v["foreground_iou"] for s, v in zip(shape_rows, vanilla_rows)])
    dboundary = np.asarray([s["boundary_f1"] - v["boundary_f1"] for s, v in zip(shape_rows, vanilla_rows)])
    dnotch = np.asarray([
        (s["notch_preservation"] - v["notch_preservation"])
        if np.isfinite(s["notch_preservation"]) and np.isfinite(v["notch_preservation"]) else 0.0
        for s, v in zip(shape_rows, vanilla_rows)
    ])
    ordinary = ~concave
    ordinary_selected = ordinary & use
    ordinary_harmed = ordinary_selected & (diou < -0.01)
    ccount, ocount = max(1, int(concave.sum())), max(1, int(ordinary.sum()))
    row = {
        "model": name,
        "threshold": float(threshold),
        "selected": int(use.sum()),
        "concave_selected": int(np.sum(use & concave)),
        "ordinary_selected": int(ordinary_selected.sum()),
        "concave_iou_gain": float(np.sum(diou * use * concave) / ccount),
        "concave_boundary_gain": float(np.sum(dboundary * use * concave) / ccount),
        "concave_notch_gain": float(np.sum(dnotch * use * concave) / ccount),
        "ordinary_iou_gain": float(np.sum(diou * use * ordinary) / ocount),
        "ordinary_boundary_gain": float(np.sum(dboundary * use * ordinary) / ocount),
        "ordinary_harmed": int(ordinary_harmed.sum()),
        "ordinary_harmed_rate": float(ordinary_harmed.sum() / ocount),
    }
    row["eligible"] = bool(
        row["ordinary_iou_gain"] >= -0.001
        and row["ordinary_boundary_gain"] >= -0.002
        and row["ordinary_harmed_rate"] <= 0.025
        and row["concave_iou_gain"] >= -0.001
        and row["concave_notch_gain"] >= 0.0
    )
    row["objective"] = float(
        0.50 * row["concave_iou_gain"]
        + 0.20 * row["concave_boundary_gain"]
        + 0.30 * row["concave_notch_gain"]
        + 0.15 * row["ordinary_iou_gain"]
        - 0.20 * row["ordinary_harmed_rate"]
    )
    return row


def fit_gate(
    features: np.ndarray,
    vanilla_rows: list[dict[str, float]],
    shape_rows: list[dict[str, float]],
    concave: np.ndarray,
    seed: int,
):
    target = utility(shape_rows, concave) - utility(vanilla_rows, concave)
    folds = KFold(n_splits=5, shuffle=True, random_state=seed)
    grids = []
    best = None
    best_oof = None
    for name, model in candidate_models(seed).items():
        oof = cross_val_predict(model, features, target, cv=folds, n_jobs=1)
        thresholds = np.unique(np.r_[np.quantile(oof, np.linspace(0.0, 1.0, 101)), np.inf])
        for threshold in thresholds:
            row = policy_row(name, float(threshold), oof, vanilla_rows, shape_rows, concave)
            grids.append(row)
            if row["eligible"] and (best is None or row["objective"] > best["objective"]):
                best, best_oof = row, oof
    if best is None:
        best = policy_row("identity", float("inf"), np.zeros(len(features)), vanilla_rows, shape_rows, concave)
        best_oof = np.zeros(len(features))
    models = candidate_models(seed)
    fitted = models[best["model"]] if best["model"] != "identity" else models["ridge_10"]
    fitted.fit(features, target)
    return fitted, best, grids, target, best_oof


def aggregate(rows: list[dict[str, float]], mask: np.ndarray | None = None) -> dict[str, float]:
    if mask is None:
        selected = rows
    else:
        selected = [row for row, keep in zip(rows, mask) if keep]
    keys = ("foreground_iou", "foreground_dice", "boundary_f1", "notch_preservation", "concavity_score", "ktc_ssim")
    return {"cases": len(selected), **{
        key: float(np.nanmean([row[key] for row in selected])) for key in keys
    }}


def evaluate_split(
    truths: np.ndarray,
    vanilla: np.ndarray,
    shape: np.ndarray,
    use: np.ndarray,
    concave: np.ndarray,
) -> tuple[dict, list[dict], np.ndarray]:
    final = np.where(use[:, None, None], shape, vanilla)
    method_predictions = {"vanilla": vanilla, "shape": shape, "selective": final}
    all_rows = []
    summary = {}
    for method, prediction in method_predictions.items():
        rows = per_case_metrics(truths, prediction)
        summary[method] = {
            "all": aggregate(rows),
            "concave": aggregate(rows, concave),
            "ordinary": aggregate(rows, ~concave),
        }
        all_rows.extend({"index": index, "method": method, **row} for index, row in enumerate(rows))
    base_rows = per_case_metrics(truths, vanilla)
    final_rows = per_case_metrics(truths, final)
    summary["ordinary_harmed_iou_gt_0.01"] = int(sum(
        final_rows[i]["foreground_iou"] < base_rows[i]["foreground_iou"] - 0.01
        for i in np.flatnonzero(~concave)
    ))
    return summary, all_rows, final


def bootstrap(
    baseline_rows: list[dict[str, float]],
    final_rows: list[dict[str, float]],
    mask: np.ndarray,
    repetitions: int,
    seed: int,
) -> dict[str, dict[str, float]]:
    rng = np.random.default_rng(seed)
    output = {}
    for metric in ("foreground_iou", "boundary_f1", "notch_preservation", "concavity_score", "ktc_ssim"):
        difference = np.asarray([
            final_rows[i][metric] - baseline_rows[i][metric] for i in np.flatnonzero(mask)
        ], dtype=np.float64)
        difference = difference[np.isfinite(difference)]
        if not len(difference):
            continue
        sampled = difference[rng.integers(0, len(difference), size=(repetitions, len(difference)))].mean(axis=1)
        output[metric] = {
            "cases": int(len(difference)), "mean_difference": float(difference.mean()),
            "ci95_low": float(np.quantile(sampled, 0.025)),
            "ci95_high": float(np.quantile(sampled, 0.975)),
            "probability_positive": float(np.mean(sampled > 0.0)),
        }
    return output


def biological_mask(x: np.ndarray, y: np.ndarray, rng: np.random.Generator, concave: bool) -> np.ndarray:
    sx, sy = rng.uniform(0.17, 0.33), rng.uniform(0.14, 0.29)
    limit = max(0.08, 0.77 - max(sx, sy))
    radius = limit * math.sqrt(float(rng.uniform()))
    center_angle = rng.uniform(-math.pi, math.pi)
    cx, cy = radius * math.cos(center_angle), radius * math.sin(center_angle)
    angle = rng.uniform(-math.pi, math.pi)
    cosine, sine = math.cos(angle), math.sin(angle)
    lx = cosine * (x - cx) + sine * (y - cy)
    ly = -sine * (x - cx) + cosine * (y - cy)
    theta = np.arctan2(ly / sy, lx / sx)
    radial = np.hypot(lx / sx, ly / sy)
    phase = rng.uniform(-math.pi, math.pi)
    boundary = 1.0 + rng.uniform(0.015, 0.07) * np.cos(2 * theta + phase)
    boundary += rng.uniform(0.01, 0.05) * np.cos(3 * theta - 0.6 * phase)
    mask = radial <= boundary
    if concave:
        side = rng.choice((-1.0, 1.0))
        bite_center = side * rng.uniform(0.78, 1.02)
        bite_width = rng.uniform(0.30, 0.52)
        bite_height = rng.uniform(0.25, 0.48)
        bite = ((lx / sx - bite_center) / bite_width) ** 2 + (ly / sy / bite_height) ** 2 <= 1.0
        mask &= ~bite
    return mask


def generate_biological_ood(archive, samples: int, seed: int):
    rng = np.random.default_rng(seed)
    coordinates = np.linspace(-1.0, 1.0, 64, dtype=np.float32)
    x, y = np.meshgrid(coordinates, coordinates)
    fov = archive["fov_mask"].astype(bool)
    labels = np.zeros((samples, 64, 64), dtype=np.uint8)
    delta = np.zeros((samples, 64, 64), dtype=np.float32)
    intended = np.zeros(samples, dtype=bool)
    for index in range(samples):
        intended[index] = index % 2 == 0
        count = 1 if rng.random() < 0.72 else 2
        for object_index in range(count):
            is_concave = bool(intended[index] and object_index == 0)
            mask = biological_mask(x, y, rng, is_concave) & fov
            class_id = 1 if rng.random() < 0.55 else 2
            contrast = -rng.uniform(0.25, 0.85) if class_id == 1 else rng.uniform(0.25, 1.0)
            labels[index][mask] = class_id
            delta[index][mask] = contrast
    indent = np.stack([net.indentation_mask(value) for value in labels]).astype(np.uint8)
    concave = materially_concave(labels, indent)
    raw = np.flip(delta, axis=1).reshape(samples, -1)
    nodes = raw[:, archive["node_to_raw_pixel"]]
    clean = 2.0 * (nodes @ archive["jacobian"].T)
    voltages = clean.astype(np.float32)
    for index in range(samples):
        snr = rng.uniform(26.0, 55.0)
        rms = np.sqrt(np.mean(clean[index] ** 2))
        voltages[index] *= rng.uniform(0.90, 1.10)
        voltages[index] += rng.normal(0.0, rms / (10 ** (snr / 20.0)) + 1e-9, voltages.shape[1])
    linear_nodes = voltages @ archive["reconstruction_operator"].T
    raw_linear = linear_nodes[:, archive["raw_pixel_to_node"]].reshape(samples, 64, 64)
    images = np.flip(raw_linear, axis=1).astype(np.float32)
    return labels, delta, indent, concave, voltages, images


def write_csv(path: Path, rows: list[dict]) -> None:
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def plot_real(
    path: Path, ids: np.ndarray, truths: np.ndarray, images: np.ndarray,
    vanilla: np.ndarray, shape: np.ndarray, final: np.ndarray, use: np.ndarray,
) -> None:
    indices = np.asarray([i for i, case_id in enumerate(ids) if str(case_id) in STRICT_IDS])
    figure, axes = plt.subplots(len(indices), 5, figsize=(12.5, 2.45 * len(indices)), squeeze=False)
    for row_index, index in enumerate(indices):
        scale = max(float(np.quantile(np.abs(images[index]), 0.99)), 1e-6)
        panels = (truths[index], images[index], vanilla[index], shape[index], final[index])
        titles = ("Truth", "Linear EIT", "Vanilla", "Topology-aware", "Selective final")
        for column, (panel, title) in enumerate(zip(panels, titles)):
            if column == 1:
                axes[row_index, column].imshow(panel, cmap="coolwarm", vmin=-scale, vmax=scale)
            else:
                axes[row_index, column].imshow(panel, cmap="viridis", vmin=0, vmax=2)
            if row_index == 0:
                axes[row_index, column].set_title(title, fontsize=10)
            axes[row_index, column].set_axis_off()
        base = net.confusion_metrics(truths[index], vanilla[index], net.indentation_mask(truths[index]))
        end = net.confusion_metrics(truths[index], final[index], net.indentation_mask(truths[index]))
        axes[row_index, 0].set_ylabel(
            f"{ids[index]}\nIoU {base['foreground_iou']:.3f}->{end['foreground_iou']:.3f}\n"
            f"gate={'shape' if use[index] else 'vanilla'}", fontsize=9
        )
    figure.suptitle("Strict inward KTC cases: frozen reliability-gated topology-aware EIT", fontsize=14)
    figure.tight_layout()
    figure.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(figure)


def plot_ood(
    path: Path, truths: np.ndarray, images: np.ndarray, vanilla: np.ndarray,
    shape: np.ndarray, final: np.ndarray, use: np.ndarray, concave: np.ndarray,
) -> None:
    selected = np.r_[np.flatnonzero(concave)[:8], np.flatnonzero(~concave)[:4]]
    figure, axes = plt.subplots(len(selected), 5, figsize=(12.5, 2.4 * len(selected)), squeeze=False)
    for row_index, index in enumerate(selected):
        scale = max(float(np.quantile(np.abs(images[index]), 0.99)), 1e-6)
        panels = (truths[index], images[index], vanilla[index], shape[index], final[index])
        for column, panel in enumerate(panels):
            if column == 1:
                axes[row_index, column].imshow(panel, cmap="coolwarm", vmin=-scale, vmax=scale)
            else:
                axes[row_index, column].imshow(panel, cmap="viridis", vmin=0, vmax=2)
            axes[row_index, column].set_axis_off()
        if row_index == 0:
            for column, title in enumerate(("Truth", "Linear EIT", "Vanilla", "Topology-aware", "Selective final")):
                axes[row_index, column].set_title(title, fontsize=10)
        axes[row_index, 0].set_ylabel(
            f"OOD {index}\n{'concave' if concave[index] else 'ordinary'}\n"
            f"gate={'shape' if use[index] else 'vanilla'}", fontsize=9
        )
    figure.suptitle("Independent smooth cell-like lesions (no stars or crosses)", fontsize=14)
    figure.tight_layout()
    figure.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    args = parse_args()
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    archive = np.load(args.dataset.resolve(), allow_pickle=False)
    device = torch.device("cpu")
    adapter = net.InputAdapter(archive["fov_mask"]).to(device)
    vanilla = net.ConcavityUNet(32, False).to(device)
    shape = net.ConcavityUNet(32, True).to(device)
    vanilla.load_state_dict(torch.load(args.checkpoint_dir / "vanilla_best.pt", map_location=device, weights_only=False)["model"])
    shape.load_state_dict(torch.load(args.checkpoint_dir / "shape_best.pt", map_location=device, weights_only=False)["model"])

    validation = archive["validation_indices"]
    print(f"inference: synthetic validation ({len(validation)})", flush=True)
    val_vout = infer(vanilla, adapter, archive["linear_images"][validation], device, args.batch_size)
    val_sout = infer(shape, adapter, archive["linear_images"][validation], device, args.batch_size)
    val_vp, val_sp = hard_predictions(val_vout), hard_predictions(val_sout)
    val_features = feature_matrix(
        archive["linear_images"][validation], archive["voltages"][validation], val_vout, val_sout, archive
    )
    val_truths = archive["labels"][validation]
    val_indent = archive["indentation_masks"][validation]
    val_concave = materially_concave(val_truths, val_indent)
    val_vrows = per_case_metrics(val_truths, val_vp, val_indent)
    val_srows = per_case_metrics(val_truths, val_sp, val_indent)
    gate, policy, grid, target, oof = fit_gate(val_features, val_vrows, val_srows, val_concave, args.seed)
    write_csv(output / "validation_policy_grid.csv", grid)
    np.savez_compressed(
        output / "validation_gate_data.npz", features=val_features, feature_names=np.asarray(FEATURE_NAMES),
        target=target, oof=oof, concave=val_concave,
    )
    threshold = float(policy["threshold"])
    print(f"frozen policy: {policy}", flush=True)

    test = archive["test_indices"]
    print(f"inference: untouched synthetic test ({len(test)})", flush=True)
    test_vout = infer(vanilla, adapter, archive["linear_images"][test], device, args.batch_size)
    test_sout = infer(shape, adapter, archive["linear_images"][test], device, args.batch_size)
    test_features = feature_matrix(
        archive["linear_images"][test], archive["voltages"][test], test_vout, test_sout, archive
    )
    test_score = gate.predict(test_features)
    test_use = test_score >= threshold
    test_truths = archive["labels"][test]
    test_concave = materially_concave(test_truths, archive["indentation_masks"][test])
    test_summary, test_rows, test_final = evaluate_split(
        test_truths, hard_predictions(test_vout), hard_predictions(test_sout), test_use, test_concave
    )

    print(f"generating and evaluating smooth biological OOD ({args.ood_samples})", flush=True)
    ood_truths, _, ood_indent, ood_concave, ood_voltages, ood_images = generate_biological_ood(
        archive, args.ood_samples, args.seed + 101
    )
    ood_vout = infer(vanilla, adapter, ood_images, device, args.batch_size)
    ood_sout = infer(shape, adapter, ood_images, device, args.batch_size)
    ood_features = feature_matrix(ood_images, ood_voltages, ood_vout, ood_sout, archive)
    ood_score = gate.predict(ood_features)
    ood_use = ood_score >= threshold
    ood_vp, ood_sp = hard_predictions(ood_vout), hard_predictions(ood_sout)
    ood_summary, ood_rows, ood_final = evaluate_split(
        ood_truths, ood_vp, ood_sp, ood_use, ood_concave
    )

    print("inference: untouched KTC public evaluation (21)", flush=True)
    real_vout = infer(vanilla, adapter, archive["real_linear_images"], device, args.batch_size)
    real_sout = infer(shape, adapter, archive["real_linear_images"], device, args.batch_size)
    real_features = feature_matrix(
        archive["real_linear_images"], archive["real_voltages"], real_vout, real_sout, archive
    )
    real_score = gate.predict(real_features)
    real_use = real_score >= threshold
    real_vp = resize_predictions(hard_predictions(real_vout))
    real_sp = resize_predictions(hard_predictions(real_sout))
    real_truths = archive["real_labels"]
    real_ids = np.asarray(archive["real_ids"])
    strict = np.asarray([str(case_id) in STRICT_IDS for case_id in real_ids])
    real_summary, _, real_final = evaluate_split(real_truths, real_vp, real_sp, real_use, strict)
    real_vrows = per_case_metrics(real_truths, real_vp)
    real_srows = per_case_metrics(real_truths, real_sp)
    real_frows = per_case_metrics(real_truths, real_final)
    real_case_rows = []
    for index, case_id in enumerate(real_ids):
        for method, rows in (("vanilla", real_vrows), ("shape", real_srows), ("selective", real_frows)):
            row = {
                "id": str(case_id), "method": method, "strict_inward": bool(strict[index]),
                "gate_score": float(real_score[index]), "gate_selected_shape": bool(real_use[index]), **rows[index],
                **{f"bay_{key}": value for key, value in bay_metrics(real_truths[index],
                    {"vanilla": real_vp, "shape": real_sp, "selective": real_final}[method][index]).items()},
            }
            real_case_rows.append(row)
    write_csv(output / "real_case_metrics.csv", real_case_rows)

    real_bootstrap = {
        "strict_inward": bootstrap(real_vrows, real_frows, strict, args.bootstrap, args.seed + 1),
        "ordinary": bootstrap(real_vrows, real_frows, ~strict, args.bootstrap, args.seed + 2),
    }
    ood_vrows = per_case_metrics(ood_truths, ood_vp, ood_indent)
    ood_frows = per_case_metrics(ood_truths, ood_final, ood_indent)
    ood_bootstrap = {
        "concave": bootstrap(ood_vrows, ood_frows, ood_concave, args.bootstrap, args.seed + 3),
        "ordinary": bootstrap(ood_vrows, ood_frows, ~ood_concave, args.bootstrap, args.seed + 4),
    }
    plot_real(
        output / "ktc_strict_inward_comparison.png", real_ids, real_truths,
        archive["real_linear_images"], real_vp, real_sp, real_final, real_use,
    )
    plot_ood(
        output / "biological_ood_comparison.png", ood_truths, ood_images,
        ood_vp, ood_sp, ood_final, ood_use, ood_concave,
    )
    np.savez_compressed(
        output / "final_predictions.npz", real_ids=real_ids, real_truths=real_truths,
        real_vanilla=real_vp, real_shape=real_sp, real_final=real_final,
        real_gate_score=real_score, real_gate_use=real_use,
        ood_truths=ood_truths, ood_vanilla=ood_vp, ood_shape=ood_sp,
        ood_final=ood_final, ood_concave=ood_concave, ood_gate_use=ood_use,
    )
    result = {
        "method": "validation-fitted reliability-gated topology-aware EIT",
        "device": str(device), "seed": args.seed,
        "policy": policy,
        "selection_data": "synthetic validation only; five-fold out-of-fold predictions",
        "public_truth_used_for_policy": False,
        "synthetic_test": test_summary,
        "synthetic_test_selection": {
            "selected": int(test_use.sum()), "concave_selected": int(np.sum(test_use & test_concave)),
            "ordinary_selected": int(np.sum(test_use & ~test_concave)),
        },
        "biological_ood": ood_summary,
        "biological_ood_selection": {
            "samples": int(args.ood_samples), "materially_concave": int(ood_concave.sum()),
            "selected": int(ood_use.sum()), "concave_selected": int(np.sum(ood_use & ood_concave)),
            "ordinary_selected": int(np.sum(ood_use & ~ood_concave)),
        },
        "biological_ood_bootstrap": ood_bootstrap,
        "ktc_public": real_summary,
        "ktc_public_selection": {
            "selected": int(real_use.sum()), "strict_selected": int(np.sum(real_use & strict)),
            "ordinary_selected": int(np.sum(real_use & ~strict)),
            "selected_ids": [str(value) for value in real_ids[real_use]],
        },
        "ktc_public_bootstrap": real_bootstrap,
        "ordinary_protection": {
            "validation_mean_iou_tolerance": -0.001,
            "validation_mean_boundary_tolerance": -0.002,
            "validation_harmed_iou_gt_0.01_rate_limit": 0.025,
        },
    }
    (output / "summary.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
