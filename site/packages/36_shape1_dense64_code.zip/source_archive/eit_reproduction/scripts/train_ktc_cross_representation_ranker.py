"""Train a listwise, harm-aware selector over heterogeneous EIT candidates.

The selector sees every candidate jointly.  A shared candidate encoder scores
geometry edits against the linear EIT image and measured voltage, while a
second head estimates whether accepting a candidate would harm the conservative
fusion baseline.  All acceptance thresholds are frozen on synthetic
validation data before untouched synthetic tests and public KTC evaluation.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import random
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy import ndimage as ndi
from scipy.stats import spearmanr
from torch.utils.data import DataLoader, Dataset, WeightedRandomSampler

from prepare_ktc_deep_concavity_stress import FAMILIES
from train_ktc_concavity_network import InputAdapter, aggregate_rows, confusion_metrics
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_implicit_boolean_network import standard_metrics, stress_metrics


STRICT_INWARD_IDS = (
    "level_2/1", "level_2/3", "level_3/2", "level_5/2",
    "level_6/2", "level_6/3", "level_7/1", "level_7/2", "level_7/3",
)
UTILITY_SCALE = 40.0


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    parser.add_argument(
        "--pool-dir", type=Path,
        default=root / "outputs" / "ktc_cross_representation_pool_seed20260820",
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=root / "outputs" / "ktc_cross_representation_ranker_seed20260820",
    )
    parser.add_argument("--epochs", type=int, default=90)
    parser.add_argument("--patience", type=int, default=16)
    parser.add_argument("--batch-size", type=int, default=24)
    parser.add_argument("--learning-rate", type=float, default=1.2e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--stress-sampling-weight", type=float, default=3.0)
    parser.add_argument("--base-iou-tolerance", type=float, default=0.003)
    parser.add_argument("--base-boundary-tolerance", type=float, default=0.004)
    parser.add_argument("--stress-iou-tolerance", type=float, default=0.006)
    parser.add_argument("--stress-bank-tolerance", type=float, default=0.012)
    parser.add_argument("--seed", type=int, default=20260820)
    parser.add_argument("--pretrained", type=Path, default=None)
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def normalized_images(images: np.ndarray, fov: np.ndarray) -> np.ndarray:
    selected = images[:, fov]
    center = np.median(selected, axis=1, keepdims=True)
    centered = images - center[:, :, None]
    scale = np.quantile(np.abs(centered[:, fov]), 0.985, axis=1).clip(1e-6)
    return np.clip(centered / scale[:, None, None], -3.0, 3.0).astype(np.float32)


def normalized_voltages(voltages: np.ndarray) -> np.ndarray:
    center = np.median(voltages, axis=1, keepdims=True)
    centered = voltages - center
    scale = np.quantile(np.abs(centered), 0.985, axis=1, keepdims=True).clip(1e-6)
    return np.clip(centered / scale, -4.0, 4.0).astype(np.float32)


def image_gradient(image: np.ndarray) -> np.ndarray:
    dy = ndi.sobel(image, axis=0)
    dx = ndi.sobel(image, axis=1)
    return np.hypot(dx, dy)


def mask_boundary(mask: np.ndarray) -> np.ndarray:
    return ndi.binary_dilation(mask, iterations=1) ^ ndi.binary_erosion(mask, iterations=1)


def candidate_descriptors(
    images: np.ndarray,
    candidates: np.ndarray,
    fov: np.ndarray,
) -> np.ndarray:
    """Geometry and local EIT evidence for each candidate, without truth."""
    count = candidates.shape[1]
    candidate_count = candidates.shape[0]
    result = np.zeros((count, candidate_count, 24), dtype=np.float32)
    normalized = normalized_images(images, fov)
    structure = np.ones((3, 3), dtype=np.uint8)
    yy, xx = np.mgrid[:fov.shape[0], :fov.shape[1]]
    fov_area = max(1, int(fov.sum()))
    for sample in range(count):
        baseline = candidates[0, sample]
        baseline_fg = baseline != 0
        gradient = image_gradient(normalized[sample])
        gradient_scale = max(float(np.quantile(gradient[fov], 0.95)), 1e-6)
        gradient = np.clip(gradient / gradient_scale, 0.0, 3.0)
        for candidate_index in range(candidate_count):
            candidate = candidates[candidate_index, sample]
            foreground = candidate != 0
            removed = baseline_fg & ~foreground
            added = foreground & ~baseline_fg
            boundary = mask_boundary(foreground) & fov
            components, component_count = ndi.label(foreground, structure=structure)
            holes = ndi.binary_fill_holes(foreground) & ~foreground
            foreground_values = normalized[sample][foreground & fov]
            class_one_values = normalized[sample][candidate == 1]
            class_two_values = normalized[sample][candidate == 2]
            removed_values = normalized[sample][removed]
            added_values = normalized[sample][added]
            area = max(1, int(foreground.sum()))
            result[sample, candidate_index] = (
                foreground.sum() / fov_area,
                np.count_nonzero(candidate == 1) / fov_area,
                np.count_nonzero(candidate == 2) / fov_area,
                np.logical_xor(foreground, baseline_fg).sum() / fov_area,
                removed.sum() / fov_area,
                added.sum() / fov_area,
                boundary.sum() / fov_area,
                holes.sum() / fov_area,
                min(component_count, 8) / 8.0,
                np.mean(xx[foreground]) / max(1, fov.shape[1] - 1) if foreground.any() else 0.5,
                np.mean(yy[foreground]) / max(1, fov.shape[0] - 1) if foreground.any() else 0.5,
                math.sqrt(area / math.pi) / max(fov.shape),
                float(np.mean(np.abs(foreground_values))) if foreground_values.size else 0.0,
                float(np.mean(-class_one_values)) if class_one_values.size else 0.0,
                float(np.mean(class_two_values)) if class_two_values.size else 0.0,
                float(np.mean(removed_values)) if removed_values.size else 0.0,
                float(np.mean(np.abs(removed_values))) if removed_values.size else 0.0,
                float(np.mean(added_values)) if added_values.size else 0.0,
                float(np.mean(np.abs(added_values))) if added_values.size else 0.0,
                float(np.mean(gradient[boundary])) if boundary.any() else 0.0,
                float(np.quantile(gradient[boundary], 0.80)) if boundary.any() else 0.0,
                float(np.mean(gradient[removed])) if removed.any() else 0.0,
                float(np.mean(gradient[added])) if added.any() else 0.0,
                float(np.mean(components[foreground] > 0)) if foreground.any() else 0.0,
            )
    return result


def depth_weights(cutouts: np.ndarray) -> np.ndarray:
    result = np.empty(cutouts.shape, dtype=np.float32)
    for index, cutout in enumerate(cutouts):
        distance = ndi.distance_transform_edt(cutout != 0)
        result[index] = distance / max(float(distance.max()), 1.0)
    return result


def utility_rows(
    truths: np.ndarray,
    candidates: np.ndarray,
    cutouts: np.ndarray,
    depths: np.ndarray,
    families: np.ndarray,
) -> tuple[np.ndarray, list[list[dict[str, float]]]]:
    utilities = np.empty((len(truths), len(candidates)), dtype=np.float32)
    all_rows: list[list[dict[str, float]]] = []
    for candidate_index, prediction in enumerate(candidates):
        _, _, rows = stress_metrics(truths, prediction, cutouts, depths, families)
        all_rows.append(rows)
        for sample, row in enumerate(rows):
            # Rank reconstruction fidelity first.  The V1 utility assigned
            # 35% to topology proxies and taught the network to propose the
            # most aggressive cutout almost everywhere.  Topology remains a
            # validation-policy objective, but it cannot compensate for a
            # poor region or boundary reconstruction during ranker training.
            utilities[sample, candidate_index] = (
                0.80 * row["foreground_iou"] + 0.20 * row["boundary_f1"]
            )
    return utilities, all_rows


@dataclass
class SplitArrays:
    name: str
    source: str
    indices: np.ndarray
    images: np.ndarray
    voltages: np.ndarray
    candidates: np.ndarray
    descriptors: np.ndarray
    utilities: np.ndarray


def load_pool(path: Path) -> tuple[list[str], np.ndarray, np.ndarray]:
    archive = np.load(path, allow_pickle=False)
    return (
        [str(value) for value in archive["candidate_names"]],
        np.asarray(archive["indices"], dtype=np.int64),
        np.asarray(archive["candidates"], dtype=np.uint8),
    )


def prepare_split(
    name: str,
    source: str,
    dataset: np.lib.npyio.NpzFile,
    pool_dir: Path,
    fov: np.ndarray,
) -> tuple[list[str], SplitArrays]:
    names, indices, candidates = load_pool(pool_dir / f"{name}.npz")
    images = np.asarray(dataset["linear_images"][indices], dtype=np.float32)
    voltages = np.asarray(dataset["voltages"][indices], dtype=np.float32)
    descriptors = candidate_descriptors(images, candidates, fov)
    truths = np.asarray(dataset["labels"][indices], dtype=np.uint8)
    if source == "stress":
        cutouts = np.asarray(dataset["cutout_masks"][indices], dtype=np.uint8)
        depths = np.asarray(dataset["cutout_depth_weights"][indices], dtype=np.float32)
        families = np.asarray(dataset["family_codes"][indices], dtype=np.int16)
    else:
        cutouts = np.asarray(dataset["indentation_masks"][indices], dtype=np.uint8)
        depths = depth_weights(cutouts)
        families = np.full(len(indices), -1, dtype=np.int16)
    utilities, _ = utility_rows(truths, candidates, cutouts, depths, families)
    return names, SplitArrays(name, source, indices, images, voltages, candidates, descriptors, utilities)


class RankDataset(Dataset):
    def __init__(self, arrays: SplitArrays | list[SplitArrays]) -> None:
        self.arrays = arrays if isinstance(arrays, list) else [arrays]
        self.lookup: list[tuple[int, int]] = []
        for source_index, source in enumerate(self.arrays):
            self.lookup.extend((source_index, item) for item in range(len(source.indices)))

    def __len__(self) -> int:
        return len(self.lookup)

    def __getitem__(self, index: int) -> dict[str, torch.Tensor]:
        source_index, item = self.lookup[index]
        source = self.arrays[source_index]
        return {
            "image": torch.from_numpy(source.images[item][None]),
            "voltage": torch.from_numpy(source.voltages[item]),
            "candidates": torch.from_numpy(source.candidates[:, item].astype(np.int64)),
            "descriptors": torch.from_numpy(source.descriptors[item]),
            "utilities": torch.from_numpy(source.utilities[item]),
            "source": torch.tensor(1 if source.source == "stress" else 0, dtype=torch.int64),
        }


class ConvBranch(nn.Module):
    def __init__(self, input_channels: int, output_channels: int) -> None:
        super().__init__()
        self.network = nn.Sequential(
            nn.Conv2d(input_channels, 20, 5, stride=2, padding=2, bias=False),
            nn.GroupNorm(4, 20), nn.SiLU(),
            nn.Conv2d(20, 40, 3, stride=2, padding=1, bias=False),
            nn.GroupNorm(8, 40), nn.SiLU(),
            nn.Conv2d(40, 64, 3, stride=2, padding=1, bias=False),
            nn.GroupNorm(8, 64), nn.SiLU(),
            nn.Conv2d(64, output_channels, 3, stride=2, padding=1, bias=False),
            nn.GroupNorm(8, output_channels), nn.SiLU(),
            nn.AdaptiveAvgPool2d(1), nn.Flatten(),
        )

    def forward(self, value: torch.Tensor) -> torch.Tensor:
        return self.network(value)


class CrossRepresentationRanker(nn.Module):
    def __init__(self, candidate_count: int, descriptor_count: int) -> None:
        super().__init__()
        self.candidate_count = candidate_count
        self.image_branch = ConvBranch(1, 64)
        self.voltage_branch = ConvBranch(1, 96)
        self.candidate_branch = ConvBranch(8, 80)
        self.descriptor_branch = nn.Sequential(
            nn.Linear(descriptor_count, 64), nn.LayerNorm(64), nn.SiLU(),
            nn.Linear(64, 48), nn.SiLU(),
        )
        self.global_fusion = nn.Sequential(
            nn.Linear(160, 128), nn.LayerNorm(128), nn.SiLU(), nn.Dropout(0.12),
        )
        self.shared = nn.Sequential(
            nn.Linear(256, 128), nn.LayerNorm(128), nn.SiLU(), nn.Dropout(0.15),
            nn.Linear(128, 64), nn.SiLU(),
        )
        self.score_head = nn.Linear(64, 1)
        self.harm_head = nn.Linear(64, 1)

    @staticmethod
    def normalize_image(image: torch.Tensor) -> torch.Tensor:
        flat = image.flatten(1)
        center = flat.median(dim=1, keepdim=True).values
        centered = flat - center
        scale = torch.quantile(centered.abs(), 0.985, dim=1, keepdim=True).clamp_min(1e-6)
        return (torch.clamp(centered / scale, -3.0, 3.0) / 3.0).reshape_as(image)

    @staticmethod
    def voltage_table(voltage: torch.Tensor) -> torch.Tensor:
        centered = voltage - voltage.median(dim=1, keepdim=True).values
        scale = torch.quantile(centered.abs(), 0.985, dim=1, keepdim=True).clamp_min(1e-6)
        return (torch.clamp(centered / scale, -4.0, 4.0) / 4.0).reshape(-1, 1, 76, 31)

    @staticmethod
    def boundaries(foreground: torch.Tensor) -> torch.Tensor:
        dilation = F.max_pool2d(foreground, 3, stride=1, padding=1)
        erosion = 1.0 - F.max_pool2d(1.0 - foreground, 3, stride=1, padding=1)
        return (dilation - erosion).clamp(0.0, 1.0)

    def forward(
        self,
        image: torch.Tensor,
        voltage: torch.Tensor,
        candidates: torch.Tensor,
        descriptors: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        batch, candidate_count, height, width = candidates.shape
        normalized = self.normalize_image(image)
        global_context = self.global_fusion(torch.cat((
            self.image_branch(normalized), self.voltage_branch(self.voltage_table(voltage))
        ), dim=1))
        foreground = (candidates != 0).float()
        class_one = (candidates == 1).float()
        class_two = (candidates == 2).float()
        baseline = foreground[:, :1].expand(-1, candidate_count, -1, -1)
        removed = baseline * (1.0 - foreground)
        added = foreground * (1.0 - baseline)
        boundary = self.boundaries(foreground.reshape(-1, 1, height, width)).reshape(
            batch, candidate_count, height, width
        )
        repeated_image = normalized[:, None].expand(-1, candidate_count, -1, -1, -1)[:, :, 0]
        channels = torch.stack((
            repeated_image, foreground, class_one, class_two, baseline, removed, added, boundary
        ), dim=2).reshape(-1, 8, height, width)
        candidate_embedding = self.candidate_branch(channels).reshape(batch, candidate_count, -1)
        descriptor_embedding = self.descriptor_branch(descriptors)
        global_repeated = global_context[:, None].expand(-1, candidate_count, -1)
        shared = self.shared(torch.cat((
            global_repeated, candidate_embedding, descriptor_embedding
        ), dim=2))
        raw_scores = self.score_head(shared)[:, :, 0]
        scores = raw_scores - raw_scores[:, :1]
        harm_logits = self.harm_head(shared)[:, :, 0]
        return scores, harm_logits


@torch.no_grad()
def infer(
    model: CrossRepresentationRanker,
    arrays: SplitArrays,
    descriptor_mean: np.ndarray,
    descriptor_std: np.ndarray,
    device: torch.device,
    batch_size: int,
) -> tuple[np.ndarray, np.ndarray]:
    standardized = SplitArrays(
        arrays.name, arrays.source, arrays.indices, arrays.images, arrays.voltages,
        arrays.candidates,
        ((arrays.descriptors - descriptor_mean) / descriptor_std).astype(np.float32),
        arrays.utilities,
    )
    loader = DataLoader(RankDataset(standardized), batch_size=batch_size, shuffle=False)
    scores: list[np.ndarray] = []
    harms: list[np.ndarray] = []
    model.eval()
    for batch in loader:
        score, harm = model(
            batch["image"].to(device), batch["voltage"].to(device),
            batch["candidates"].to(device), batch["descriptors"].to(device),
        )
        scores.append(score.cpu().numpy())
        harms.append(torch.sigmoid(harm).cpu().numpy())
    return np.concatenate(scores), np.concatenate(harms)


def train_ranker(
    train_splits: list[SplitArrays],
    validation_splits: list[SplitArrays],
    descriptor_mean: np.ndarray,
    descriptor_std: np.ndarray,
    candidate_count: int,
    device: torch.device,
    args: argparse.Namespace,
    output_dir: Path,
) -> tuple[CrossRepresentationRanker, list[dict[str, float]]]:
    standardized_train = [
        SplitArrays(
            source.name, source.source, source.indices, source.images, source.voltages,
            source.candidates, ((source.descriptors - descriptor_mean) / descriptor_std).astype(np.float32),
            source.utilities,
        )
        for source in train_splits
    ]
    dataset = RankDataset(standardized_train)
    weights = np.concatenate([
        np.full(len(source.indices), args.stress_sampling_weight if source.source == "stress" else 1.0)
        for source in standardized_train
    ])
    generator = torch.Generator().manual_seed(args.seed)
    sampler = WeightedRandomSampler(weights, num_samples=len(weights), replacement=True, generator=generator)
    loader = DataLoader(
        dataset, batch_size=args.batch_size, sampler=sampler,
        pin_memory=device.type == "cuda", drop_last=False,
    )
    model = CrossRepresentationRanker(candidate_count, train_splits[0].descriptors.shape[-1]).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    checkpoint = output_dir / "ranker_best.pt"
    history: list[dict[str, float]] = []
    best_regret = math.inf
    stale = 0
    for epoch in range(1, args.epochs + 1):
        model.train()
        losses: list[float] = []
        for batch in loader:
            image = batch["image"].to(device, non_blocking=True)
            voltage = batch["voltage"].to(device, non_blocking=True)
            candidates = batch["candidates"].to(device, non_blocking=True)
            descriptors = batch["descriptors"].to(device, non_blocking=True)
            utility = batch["utilities"].to(device, non_blocking=True)
            target_gain = UTILITY_SCALE * (utility - utility[:, :1])
            target_distribution = torch.softmax((utility - utility.max(dim=1, keepdim=True).values) / 0.025, dim=1)
            harmful = (utility < utility[:, :1] - 0.006).float()
            optimizer.zero_grad(set_to_none=True)
            with torch.amp.autocast("cuda", enabled=device.type == "cuda"):
                scores, harm_logits = model(image, voltage, candidates, descriptors)
                gain = F.smooth_l1_loss(scores[:, 1:], target_gain[:, 1:], beta=0.20)
                predicted_pairwise = scores[:, :, None] - scores[:, None, :]
                target_pairwise = target_gain[:, :, None] - target_gain[:, None, :]
                pairwise = F.smooth_l1_loss(predicted_pairwise, target_pairwise, beta=0.25)
                preference = F.binary_cross_entropy_with_logits(
                    scores[:, 1:], (target_gain[:, 1:] > 0.0).float()
                )
                listwise = -(target_distribution * F.log_softmax(scores, dim=1)).sum(dim=1).mean()
                harm = F.binary_cross_entropy_with_logits(harm_logits[:, 1:], harmful[:, 1:])
                baseline_anchor = scores[:, 0].square().mean()
                loss = (
                    gain + 0.30 * pairwise + 0.20 * preference
                    + 0.10 * listwise + 0.30 * harm + 0.02 * baseline_anchor
                )
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            scaler.step(optimizer)
            scaler.update()
            losses.append(float(loss.detach()))
        scheduler.step()

        validation_regrets = []
        validation_accuracy = []
        for source in validation_splits:
            scores, _ = infer(model, source, descriptor_mean, descriptor_std, device, args.batch_size)
            choice = scores.argmax(axis=1)
            chosen = source.utilities[np.arange(len(choice)), choice]
            validation_regrets.append(source.utilities.max(axis=1) - chosen)
            validation_accuracy.append(choice == source.utilities.argmax(axis=1))
        regret = float(np.mean(np.concatenate(validation_regrets)))
        accuracy = float(np.mean(np.concatenate(validation_accuracy)))
        record = {
            "epoch": float(epoch), "train_loss": float(np.mean(losses)),
            "validation_mean_regret": regret, "validation_oracle_accuracy": accuracy,
            "learning_rate": float(optimizer.param_groups[0]["lr"]),
        }
        history.append(record)
        if epoch == 1 or epoch % 5 == 0:
            print(
                f"epoch {epoch:03d}: loss={record['train_loss']:.4f} regret={regret:.5f} "
                f"oracle_acc={accuracy:.3f}", flush=True,
            )
        if regret < best_regret - 1e-5:
            best_regret = regret
            stale = 0
            torch.save({
                "model": model.state_dict(), "candidate_count": candidate_count,
                "descriptor_count": train_splits[0].descriptors.shape[-1],
                "epoch": epoch, "validation_mean_regret": regret,
            }, checkpoint)
        else:
            stale += 1
            if stale >= args.patience:
                print(f"early stopping at epoch {epoch}", flush=True)
                break
    state = torch.load(checkpoint, map_location=device, weights_only=False)
    model.load_state_dict(state["model"])
    model.eval()
    (output_dir / "training_history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    return model, history


def gather(candidates: np.ndarray, selected: np.ndarray) -> np.ndarray:
    return candidates[selected, np.arange(len(selected))]


def apply_policy(scores: np.ndarray, harms: np.ndarray, score_threshold: float, harm_threshold: float) -> np.ndarray:
    proposed = scores[:, 1:].argmax(axis=1) + 1
    gain = scores[np.arange(len(scores)), proposed]
    risk = harms[np.arange(len(harms)), proposed]
    return np.where((gain >= score_threshold) & (risk <= harm_threshold), proposed, 0).astype(np.int64)


def metric_for_split(
    source: SplitArrays,
    dataset: np.lib.npyio.NpzFile,
    prediction: np.ndarray,
) -> dict[str, float]:
    truths = dataset["labels"][source.indices]
    if source.source == "stress":
        summary, _, _ = stress_metrics(
            truths, prediction, dataset["cutout_masks"][source.indices],
            dataset["cutout_depth_weights"][source.indices], dataset["family_codes"][source.indices],
        )
        return summary
    return standard_metrics(truths, prediction, dataset["indentation_masks"][source.indices])


def calibrate_policy(
    base: SplitArrays,
    stress: SplitArrays,
    base_dataset: np.lib.npyio.NpzFile,
    stress_dataset: np.lib.npyio.NpzFile,
    base_scores: np.ndarray,
    base_harms: np.ndarray,
    stress_scores: np.ndarray,
    stress_harms: np.ndarray,
    args: argparse.Namespace,
) -> tuple[dict[str, object], list[dict[str, object]]]:
    base_reference = metric_for_split(base, base_dataset, base.candidates[0])
    stress_reference = metric_for_split(stress, stress_dataset, stress.candidates[0])
    rows: list[dict[str, object]] = []
    for score_threshold in (-0.25, 0.0, 0.10, 0.20, 0.35, 0.50, 0.75, 1.0, 1.5, 2.0, 3.0, 99.0):
        for harm_threshold in (0.20, 0.30, 0.40, 0.50, 0.60, 0.75, 1.0):
            base_selected = apply_policy(base_scores, base_harms, score_threshold, harm_threshold)
            stress_selected = apply_policy(stress_scores, stress_harms, score_threshold, harm_threshold)
            base_metric = metric_for_split(base, base_dataset, gather(base.candidates, base_selected))
            stress_metric = metric_for_split(stress, stress_dataset, gather(stress.candidates, stress_selected))
            eligible = (
                base_metric["foreground_iou"] >= base_reference["foreground_iou"] - args.base_iou_tolerance
                and base_metric["boundary_f1"] >= base_reference["boundary_f1"] - args.base_boundary_tolerance
                and stress_metric["foreground_iou"] >= stress_reference["foreground_iou"] - args.stress_iou_tolerance
                and stress_metric["bank_retention"] >= stress_reference["bank_retention"] - args.stress_bank_tolerance
            )
            rows.append({
                "score_threshold": score_threshold, "harm_threshold": harm_threshold,
                "eligible": bool(eligible),
                "base_iou": base_metric["foreground_iou"],
                "base_boundary_f1": base_metric["boundary_f1"],
                "stress_iou": stress_metric["foreground_iou"],
                "stress_boundary_f1": stress_metric["boundary_f1"],
                "stress_open_deep": stress_metric["open_deep_cutout_recovery"],
                "stress_bank": stress_metric["bank_retention"],
                "stress_topology_joint": stress_metric["topology_structural_joint"],
                "base_change_rate": float(np.mean(base_selected != 0)),
                "stress_change_rate": float(np.mean(stress_selected != 0)),
            })
    eligible = [row for row in rows if row["eligible"]]
    if eligible:
        selected = max(eligible, key=lambda row: (
            float(row["stress_topology_joint"]), float(row["stress_open_deep"]),
            float(row["base_iou"]), -float(row["base_change_rate"]),
        ))
    else:
        selected = next(row for row in rows if row["score_threshold"] == 99.0 and row["harm_threshold"] == 1.0)
    return selected, rows


def foreground_iou_per_case(truths: np.ndarray, predictions: np.ndarray) -> np.ndarray:
    truth = truths != 0
    prediction = predictions != 0
    intersection = np.logical_and(truth, prediction).sum(axis=(1, 2))
    union = np.logical_or(truth, prediction).sum(axis=(1, 2))
    return intersection / np.maximum(union, 1)


def paired_bootstrap(
    truths: np.ndarray,
    baseline: np.ndarray,
    selected: np.ndarray,
    repetitions: int,
    seed: int,
) -> dict[str, float]:
    before = foreground_iou_per_case(truths, baseline)
    after = foreground_iou_per_case(truths, selected)
    difference = after - before
    rng = np.random.default_rng(seed)
    draws = difference[rng.integers(0, len(difference), size=(repetitions, len(difference)))].mean(axis=1)
    return {
        "mean_iou_difference": float(difference.mean()),
        "ci95_low": float(np.quantile(draws, 0.025)),
        "ci95_high": float(np.quantile(draws, 0.975)),
        "probability_positive": float(np.mean(draws > 0)),
    }


def confidence_analysis(
    scores: np.ndarray,
    harms: np.ndarray,
    utilities: np.ndarray,
    selected: np.ndarray,
) -> dict[str, object]:
    proposed = scores[:, 1:].argmax(axis=1) + 1
    predicted_gain = scores[np.arange(len(scores)), proposed]
    predicted_harm = harms[np.arange(len(scores)), proposed]
    actual_gain = utilities[np.arange(len(scores)), proposed] - utilities[:, 0]
    correlation = spearmanr(predicted_gain, actual_gain).statistic
    harm_target = actual_gain < -0.006
    bins = []
    for left, right in zip(np.linspace(0.0, 1.0, 6)[:-1], np.linspace(0.0, 1.0, 6)[1:]):
        mask = (predicted_harm >= left) & (predicted_harm < right if right < 1.0 else predicted_harm <= right)
        bins.append({
            "left": float(left), "right": float(right), "count": int(mask.sum()),
            "predicted_harm": float(predicted_harm[mask].mean()) if mask.any() else math.nan,
            "observed_harm": float(harm_target[mask].mean()) if mask.any() else math.nan,
        })
    return {
        "predicted_gain_actual_gain_spearman": float(correlation) if np.isfinite(correlation) else math.nan,
        "proposed_harm_rate": float(harm_target.mean()),
        "accepted_rate": float(np.mean(selected != 0)),
        "harm_calibration_bins": bins,
    }


def save_public_montage(
    path: Path,
    truths: np.ndarray,
    ids: np.ndarray,
    candidates: np.ndarray,
    selected: np.ndarray,
    names: list[str],
) -> None:
    focus = [index for index, case_id in enumerate(ids) if str(case_id) in STRICT_INWARD_IDS]
    oracle_choice = np.argmax(np.stack([foreground_iou_per_case(truths, value) for value in candidates]), axis=0)
    figure, axes = plt.subplots(len(focus), 5, figsize=(13.5, 2.7 * len(focus)), squeeze=False)
    for row, index in enumerate(focus):
        baseline = candidates[0, index]
        chosen = candidates[int(selected[index]), index]
        oracle = candidates[int(oracle_choice[index]), index]
        before = foreground_iou_per_case(truths[index:index + 1], baseline[None])[0]
        after = foreground_iou_per_case(truths[index:index + 1], chosen[None])[0]
        panels = (
            (truths[index], "truth", "viridis", 2),
            (baseline, f"baseline IoU={before:.3f}", "viridis", 2),
            (chosen, f"ranker IoU={after:.3f}\n{names[int(selected[index])]}", "viridis", 2),
            (oracle, f"oracle\n{names[int(oracle_choice[index])]}", "viridis", 2),
            ((baseline != 0) & (chosen == 0), "ranker inward removal", "magma", 1),
        )
        for column, (image, title, cmap, vmax) in enumerate(panels):
            axes[row, column].imshow(image, cmap=cmap, vmin=0, vmax=vmax, interpolation="nearest")
            axes[row, column].set_title(title, fontsize=8)
            axes[row, column].set_axis_off()
        axes[row, 0].set_ylabel(str(ids[index]), fontsize=8)
    figure.subplots_adjust(left=0.04, right=0.995, bottom=0.02, top=0.97, hspace=0.32, wspace=0.08)
    figure.savefig(path, dpi=190)
    plt.close(figure)


def save_stress_montage(
    path: Path,
    truths: np.ndarray,
    cutouts: np.ndarray,
    families: np.ndarray,
    candidates: np.ndarray,
    selected: np.ndarray,
    names: list[str],
) -> None:
    focus = []
    for code in range(len(FAMILIES)):
        options = np.flatnonzero(families == code)
        focus.append(int(options[np.argmax(cutouts[options].sum(axis=(1, 2)))]))
    oracle_choice = np.argmax(np.stack([foreground_iou_per_case(truths, value) for value in candidates]), axis=0)
    figure, axes = plt.subplots(len(focus), 5, figsize=(13.5, 2.7 * len(focus)), squeeze=False)
    for row, index in enumerate(focus):
        baseline = candidates[0, index]
        chosen = candidates[int(selected[index]), index]
        oracle = candidates[int(oracle_choice[index]), index]
        panels = (
            (truths[index], f"{FAMILIES[int(families[index])]} truth", "viridis", 2),
            (baseline, "fusion baseline", "viridis", 2),
            (chosen, f"ranker\n{names[int(selected[index])]}", "viridis", 2),
            (oracle, f"oracle\n{names[int(oracle_choice[index])]}", "viridis", 2),
            ((baseline != 0) & (chosen == 0), "ranker inward removal", "magma", 1),
        )
        for column, (image, title, cmap, vmax) in enumerate(panels):
            axes[row, column].imshow(image, cmap=cmap, vmin=0, vmax=vmax, interpolation="nearest")
            axes[row, column].set_title(title, fontsize=8)
            axes[row, column].set_axis_off()
    figure.subplots_adjust(left=0.02, right=0.995, bottom=0.02, top=0.97, hspace=0.28, wspace=0.08)
    figure.savefig(path, dpi=190)
    plt.close(figure)


def write_selection(
    path: Path,
    ids: np.ndarray,
    names: list[str],
    scores: np.ndarray,
    harms: np.ndarray,
    selected: np.ndarray,
    utilities: np.ndarray | None = None,
) -> None:
    rows = []
    for index in range(len(selected)):
        proposed = int(scores[index, 1:].argmax() + 1)
        row = {
            "id": str(ids[index]), "proposed_index": proposed, "proposed": names[proposed],
            "selected_index": int(selected[index]), "selected": names[int(selected[index])],
            "predicted_gain": float(scores[index, proposed]),
            "predicted_harm": float(harms[index, proposed]),
        }
        if utilities is not None:
            row["actual_utility_gain"] = float(utilities[index, int(selected[index])] - utilities[index, 0])
        rows.append(row)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    pool_dir = args.pool_dir.resolve()
    base = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    fov = np.asarray(base["fov_mask"], dtype=bool)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    prepared: dict[str, SplitArrays] = {}
    candidate_names: list[str] | None = None
    for name, source, dataset in (
        ("base_train", "base", base), ("base_validation", "base", base), ("base_test", "base", base),
        ("stress_train", "stress", stress), ("stress_validation", "stress", stress),
        ("stress_test", "stress", stress),
    ):
        print(f"preparing {name}", flush=True)
        names, arrays = prepare_split(name, source, dataset, pool_dir, fov)
        if candidate_names is None:
            candidate_names = names
        elif names != candidate_names:
            raise RuntimeError(f"candidate names differ in {name}")
        prepared[name] = arrays
    assert candidate_names is not None

    train_descriptors = np.concatenate((
        prepared["base_train"].descriptors.reshape(-1, prepared["base_train"].descriptors.shape[-1]),
        prepared["stress_train"].descriptors.reshape(-1, prepared["stress_train"].descriptors.shape[-1]),
    ))
    descriptor_mean = train_descriptors.mean(axis=0).astype(np.float32)
    descriptor_std = train_descriptors.std(axis=0).clip(1e-5).astype(np.float32)
    np.savez_compressed(output_dir / "descriptor_normalization.npz", mean=descriptor_mean, std=descriptor_std)

    if args.pretrained is None:
        model, history = train_ranker(
            [prepared["base_train"], prepared["stress_train"]],
            [prepared["base_validation"], prepared["stress_validation"]],
            descriptor_mean, descriptor_std, len(candidate_names), device, args, output_dir,
        )
        checkpoint = output_dir / "ranker_best.pt"
    else:
        checkpoint = args.pretrained.resolve()
        state = torch.load(checkpoint, map_location=device, weights_only=False)
        model = CrossRepresentationRanker(int(state["candidate_count"]), int(state["descriptor_count"])).to(device)
        model.load_state_dict(state["model"])
        model.eval()
        history = []

    validation_outputs = {}
    for name in ("base_validation", "stress_validation"):
        validation_outputs[name] = infer(
            model, prepared[name], descriptor_mean, descriptor_std, device, args.batch_size
        )
    policy, policy_rows = calibrate_policy(
        prepared["base_validation"], prepared["stress_validation"], base, stress,
        *validation_outputs["base_validation"], *validation_outputs["stress_validation"], args,
    )
    with (output_dir / "validation_policy_grid.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(policy_rows[0]))
        writer.writeheader(); writer.writerows(policy_rows)
    print(f"frozen validation policy={policy}", flush=True)
    score_threshold = float(policy["score_threshold"])
    harm_threshold = float(policy["harm_threshold"])

    test_results: dict[str, dict[str, object]] = {}
    saved_outputs: dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]] = {}
    for name, dataset in (("base_test", base), ("stress_test", stress)):
        arrays = prepared[name]
        scores, harms = infer(model, arrays, descriptor_mean, descriptor_std, device, args.batch_size)
        selected = apply_policy(scores, harms, score_threshold, harm_threshold)
        prediction = gather(arrays.candidates, selected)
        oracle = gather(arrays.candidates, arrays.utilities.argmax(axis=1))
        truths = dataset["labels"][arrays.indices]
        test_results[name] = {
            "baseline": metric_for_split(arrays, dataset, arrays.candidates[0]),
            "ranker": metric_for_split(arrays, dataset, prediction),
            "oracle": metric_for_split(arrays, dataset, oracle),
            "changed_cases": int(np.count_nonzero(selected)),
            "harm_cases": int(np.count_nonzero(
                foreground_iou_per_case(truths, prediction) < foreground_iou_per_case(truths, arrays.candidates[0]) - 1e-8
            )),
            "bootstrap_iou": paired_bootstrap(truths, arrays.candidates[0], prediction, 10000, args.seed),
            "confidence": confidence_analysis(scores, harms, arrays.utilities, selected),
        }
        saved_outputs[name] = (scores, harms, selected)
        write_selection(
            output_dir / f"{name}_selection.csv", arrays.indices, candidate_names,
            scores, harms, selected, arrays.utilities,
        )

    public_names, public_indices, public_candidates = load_pool(pool_dir / "public_21.npz")
    if public_names != candidate_names:
        raise RuntimeError("public candidate names differ")
    public_candidates64 = F.interpolate(
        torch.from_numpy(public_candidates.astype(np.float32)), size=(64, 64), mode="nearest"
    ).numpy().astype(np.uint8)
    public_images = np.asarray(base["real_linear_images"], dtype=np.float32)
    public_voltages = np.asarray(base["real_voltages"], dtype=np.float32)
    public_descriptors = candidate_descriptors(public_images, public_candidates64, fov)
    public_arrays = SplitArrays(
        "public_21", "public", public_indices, public_images, public_voltages,
        public_candidates64, public_descriptors,
        np.zeros((len(public_indices), len(candidate_names)), dtype=np.float32),
    )
    public_scores, public_harms = infer(
        model, public_arrays, descriptor_mean, descriptor_std, device, args.batch_size
    )
    public_selected = apply_policy(public_scores, public_harms, score_threshold, harm_threshold)
    public_prediction = gather(public_candidates, public_selected)
    public_truth = np.asarray(base["real_labels"], dtype=np.uint8)
    public_ids = np.asarray(base["real_ids"])
    public_utilities, _ = utility_rows(
        public_truth, public_candidates,
        np.stack([ndi.binary_fill_holes(value != 0) & (value == 0) for value in public_truth]).astype(np.uint8),
        np.zeros_like(public_truth, dtype=np.float32), np.full(len(public_truth), -1, dtype=np.int16),
    )
    # Public utility is diagnostic only and never affects the frozen policy.
    public_oracle_choice = np.argmax(np.stack([
        foreground_iou_per_case(public_truth, candidate) for candidate in public_candidates
    ]), axis=0)
    public_oracle = gather(public_candidates, public_oracle_choice)
    public_summary = {}
    for method, prediction in (
        ("fusion_baseline", public_candidates[0]),
        ("listwise_ranker", public_prediction),
        ("small_pool_oracle", public_oracle),
    ):
        public_summary[method], _ = evaluate_real_predictions(method, prediction, public_truth, public_ids)
    public_iou = {
        "baseline": foreground_iou_per_case(public_truth, public_candidates[0]),
        "ranker": foreground_iou_per_case(public_truth, public_prediction),
        "oracle": foreground_iou_per_case(public_truth, public_oracle),
    }
    strict = np.asarray([str(case_id) in STRICT_INWARD_IDS for case_id in public_ids])
    public_groups = {
        group: {
            method: float(values[mask].mean()) for method, values in public_iou.items()
        }
        for group, mask in (("strict_inward", strict), ("ordinary", ~strict), ("all", np.ones(len(strict), dtype=bool)))
    }
    public_groups["all"].update(
        changed_cases=int(np.count_nonzero(public_selected)),
        harm_cases=int(np.count_nonzero(public_iou["ranker"] < public_iou["baseline"] - 1e-8)),
    )
    write_selection(
        output_dir / "public_21_selection.csv", public_ids, candidate_names,
        public_scores, public_harms, public_selected, public_utilities,
    )
    save_public_montage(
        output_dir / "public_strict_inward_ranker.png", public_truth, public_ids,
        public_candidates, public_selected, candidate_names,
    )
    stress_arrays = prepared["stress_test"]
    stress_scores, stress_harms, stress_selected = saved_outputs["stress_test"]
    save_stress_montage(
        output_dir / "stress_family_ranker.png",
        stress["labels"][stress_arrays.indices], stress["cutout_masks"][stress_arrays.indices],
        stress["family_codes"][stress_arrays.indices], stress_arrays.candidates,
        stress_selected, candidate_names,
    )
    np.savez_compressed(
        output_dir / "predictions.npz",
        candidate_names=np.asarray(candidate_names),
        base_test_indices=prepared["base_test"].indices,
        base_selected=saved_outputs["base_test"][2],
        base_prediction=gather(prepared["base_test"].candidates, saved_outputs["base_test"][2]),
        stress_test_indices=prepared["stress_test"].indices,
        stress_selected=stress_selected,
        stress_prediction=gather(stress_arrays.candidates, stress_selected),
        public_ids=public_ids, public_selected=public_selected, public_prediction=public_prediction,
        public_scores=public_scores, public_harms=public_harms,
    )
    result = {
        "method": "shared candidate encoder with listwise utility ranking and harm-aware abstention",
        "candidate_names": candidate_names,
        "candidate_count": len(candidate_names),
        "frozen_validation_policy": policy,
        "synthetic_untouched_test": test_results,
        "public_21": {"metrics": public_summary, "foreground_iou_groups": public_groups},
        "data_policy": "ranker training uses synthetic train only; policy uses synthetic validation only; test/public truth is evaluation-only",
        "evaluation_truth_used_for_training_or_selection": False,
        "checkpoint": str(checkpoint),
        "checkpoint_epoch": int(torch.load(checkpoint, map_location="cpu", weights_only=False)["epoch"]),
        "seed": args.seed, "device": str(device),
    }
    (output_dir / "summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
