$ErrorActionPreference = "Stop"

$python = "E:\Anaconda\envs\myenv\python.exe"
$root = "E:\Codex"
$script = Join-Path $root "eit_reproduction\scripts\train_local_topology_corrector_v6.py"

$runs = @(
    @{
        Seed = 20260911
        Checkpoint = "topology_risk_eit_v4_full\topology_residual_v4_best.pt"
        Router = "topology_risk_eit_v4_router_seed_20260911\action_router_summary.json"
    },
    @{
        Seed = 20260912
        Checkpoint = "topology_risk_eit_v4_seed_20260912\topology_residual_v4_best.pt"
        Router = "topology_risk_eit_v4_router_seed_20260912\action_router_summary.json"
    },
    @{
        Seed = 20260913
        Checkpoint = "topology_risk_eit_v4_seed_20260913\topology_residual_v4_best.pt"
        Router = "topology_risk_eit_v4_router_seed_20260913\action_router_summary.json"
    },
    @{
        Seed = 20260914
        Checkpoint = "topology_risk_eit_v4_seed_20260914\topology_residual_v4_best.pt"
        Router = "topology_risk_eit_v4_router_seed_20260914\action_router_summary.json"
    }
)

Set-Location $root
foreach ($run in $runs) {
    $output = Join-Path $root ("topology_local_eit_v6_seed_" + $run.Seed)
    Write-Host ("Starting v6 seed " + $run.Seed + " -> " + $output)
    & $python $script `
        --checkpoint (Join-Path $root $run.Checkpoint) `
        --anchor-router (Join-Path $root $run.Router) `
        --output-dir $output `
        --seed $run.Seed `
        --device cuda `
        --epochs 54 `
        --patience 12 `
        --batch-size 28 `
        --base-channels 24 `
        --gate-epochs 260 `
        --gate-patience 36 `
        --progress-every 2
    if ($LASTEXITCODE -ne 0) {
        throw "v6 seed $($run.Seed) failed with exit code $LASTEXITCODE"
    }
}

$aggregate = Join-Path $root "eit_reproduction\scripts\aggregate_local_topology_v6_multiseed.py"
$outputFinal = Join-Path $root "topology_local_eit_v6_multiseed_final"
& $python $aggregate `
    --runs `
        (Join-Path $root "topology_local_eit_v6_seed_20260911") `
        (Join-Path $root "topology_local_eit_v6_seed_20260912") `
        (Join-Path $root "topology_local_eit_v6_seed_20260913") `
        (Join-Path $root "topology_local_eit_v6_seed_20260914") `
    --output-dir $outputFinal `
    --bootstrap 10000 `
    --seed 20261021
if ($LASTEXITCODE -ne 0) {
    throw "v6 multiseed aggregation failed with exit code $LASTEXITCODE"
}

Write-Host "v6 multiseed workflow completed: $outputFinal"
