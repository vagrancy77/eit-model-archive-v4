"""Build paper-ready summaries for the frozen topology-safe EIT evaluation."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


METRICS = (
    ("foreground_iou", "Foreground IoU"),
    ("boundary_f1", "Boundary F1"),
    ("notch_preservation", "Notch preservation"),
    ("concavity_score", "Concavity score"),
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--result-dir",
        type=Path,
        default=Path(r"E:\Codex\ktc_topology_safe_final_cpu"),
    )
    return parser.parse_args()


def paired_table(frame: pd.DataFrame, keys: list[str]) -> pd.DataFrame:
    values = [name for name, _ in METRICS]
    return frame.pivot(index=keys, columns="method", values=values).sort_index()


def delta_ci(summary: dict, group: str, metric: str) -> tuple[float, float, float]:
    row = summary[group][metric]
    return (
        100.0 * row["mean_difference"],
        100.0 * row["ci95_low"],
        100.0 * row["ci95_high"],
    )


def plot_delta_panel(axis, bootstrap: dict, group: str, title: str) -> None:
    estimates = [delta_ci(bootstrap, group, name) for name, _ in METRICS]
    means = np.asarray([item[0] for item in estimates])
    lows = np.asarray([item[1] for item in estimates])
    highs = np.asarray([item[2] for item in estimates])
    positions = np.arange(len(METRICS))
    colors = ["#18794e" if value >= 0 else "#b42318" for value in means]
    axis.axvline(0, color="#505050", linewidth=1.0, zorder=0)
    axis.errorbar(
        means,
        positions,
        xerr=np.vstack((means - lows, highs - means)),
        fmt="none",
        ecolor="#383838",
        elinewidth=1.4,
        capsize=3,
        zorder=2,
    )
    axis.scatter(means, positions, c=colors, s=52, edgecolor="white", linewidth=0.7, zorder=3)
    for position, mean in zip(positions, means):
        offset = 4 if mean >= 0 else -4
        axis.annotate(
            f"{mean:+.3f}",
            (mean, position),
            xytext=(offset, -12),
            textcoords="offset points",
            ha="left" if mean >= 0 else "right",
            va="center",
            fontsize=8,
        )
    axis.set_yticks(positions, [label for _, label in METRICS])
    axis.invert_yaxis()
    axis.set_xlabel("Final minus vanilla (percentage points), paired 95% CI")
    axis.set_title(title, loc="left", fontweight="bold")
    axis.grid(axis="x", color="#dedede", linewidth=0.7)


def plot_expert_tradeoff(axis, summary: dict) -> None:
    methods = ("vanilla", "shape_aware", "topology_safe")
    labels = ("Vanilla", "Shape expert", "Final safe fusion")
    colors = ("#4c78a8", "#f28e2b", "#18794e")
    base = summary["vanilla"]["concave"]
    positions = np.arange(len(METRICS))
    width = 0.24
    for offset, method, label, color in zip((-width, 0, width), methods, labels, colors):
        values = [
            100.0 * (summary[method]["concave"][name] - base[name])
            for name, _ in METRICS
        ]
        axis.bar(positions + offset, values, width=width, label=label, color=color)
    axis.axhline(0, color="#505050", linewidth=1.0)
    axis.set_xticks(positions, [label.replace(" ", "\n") for _, label in METRICS])
    axis.set_ylabel("Change from vanilla (percentage points)")
    axis.set_title("C. KTC inward cases: expert gain versus safety trade-off", loc="left", fontweight="bold")
    axis.legend(frameon=False, ncols=3, fontsize=8, loc="upper center")
    axis.grid(axis="y", color="#dedede", linewidth=0.7)


def plot_safety(axis, summary: dict, biological: pd.DataFrame, ktc: pd.DataFrame) -> None:
    bio = paired_table(biological, ["seed", "index", "concave"])
    real = paired_table(ktc, ["id", "strict_inward"])
    bio_ordinary = ~np.asarray(bio.index.get_level_values("concave"), dtype=bool)
    real_ordinary = ~np.asarray(real.index.get_level_values("strict_inward"), dtype=bool)
    bio_harm = (
        bio[("foreground_iou", "topology_safe")]
        < bio[("foreground_iou", "vanilla")] - 0.01
    ) & bio_ordinary
    real_harm = (
        real[("foreground_iou", "topology_safe")]
        < real[("foreground_iou", "vanilla")] - 0.01
    ) & real_ordinary
    labels = (
        "Cell-like ordinary\nIoU loss > 0.01",
        "KTC ordinary\nIoU loss > 0.01",
        "Cell-like\ntopology changes",
        "KTC\ntopology changes",
    )
    numerators = np.asarray([
        int(bio_harm.sum()),
        int(real_harm.sum()),
        summary["biological_ood"]["topology_violations"],
        summary["ktc_public_benchmark"]["topology_violations"],
    ])
    denominators = np.asarray([
        int(bio_ordinary.sum()),
        int(real_ordinary.sum()),
        len(bio),
        len(real),
    ])
    rates = 100.0 * numerators / denominators
    positions = np.arange(len(labels))
    colors = ["#f28e2b" if value else "#18794e" for value in numerators]
    axis.bar(positions, rates, color=colors, width=0.62)
    for position, rate, numerator, denominator in zip(positions, rates, numerators, denominators):
        axis.text(position, rate + 0.03, f"{numerator}/{denominator}", ha="center", va="bottom", fontsize=9)
    axis.set_xticks(positions, labels)
    axis.set_ylabel("Cases (%)")
    axis.set_ylim(0, max(0.6, float(rates.max()) * 1.35))
    axis.set_title("D. Ordinary-case and topology safety audit", loc="left", fontweight="bold")
    axis.grid(axis="y", color="#dedede", linewidth=0.7)


def write_case_lists(output: Path, biological: pd.DataFrame) -> tuple[int, int]:
    table = paired_table(biological, ["seed", "index", "concave"])
    result = pd.DataFrame(index=table.index)
    for metric, _ in METRICS:
        result[f"{metric}_vanilla"] = table[(metric, "vanilla")]
        result[f"{metric}_final"] = table[(metric, "topology_safe")]
        result[f"{metric}_gain"] = result[f"{metric}_final"] - result[f"{metric}_vanilla"]
    improved = result[
        result.index.get_level_values("concave")
        & (result["notch_preservation_gain"] > 1e-12)
    ].sort_values("notch_preservation_gain", ascending=False)
    harmed = result[
        ~result.index.get_level_values("concave")
        & (result["foreground_iou_gain"] < -0.01)
    ].sort_values("foreground_iou_gain")
    improved.to_csv(output / "biological_concave_notch_improved_cases.csv")
    harmed.to_csv(output / "biological_ordinary_harmed_cases.csv")
    return len(improved), len(harmed)


def main() -> None:
    args = parse_args()
    output = args.result_dir.resolve()
    summary = json.loads((output / "summary.json").read_text(encoding="utf-8"))
    biological = pd.read_csv(output / "biological_case_metrics.csv")
    ktc = pd.read_csv(output / "ktc_case_metrics.csv")
    improved, harmed = write_case_lists(output, biological)

    figure, axes = plt.subplots(2, 2, figsize=(14.2, 9.0))
    plot_delta_panel(
        axes[0, 0],
        summary["biological_ood_bootstrap"],
        "concave",
        "A. Unseen cell-like inward cases (n=566)",
    )
    plot_delta_panel(
        axes[0, 1],
        summary["ktc_public_bootstrap"],
        "strict_inward",
        "B. KTC public strict inward cases (n=9)",
    )
    plot_expert_tradeoff(axes[1, 0], summary["ktc_public_benchmark"])
    plot_safety(axes[1, 1], summary, biological, ktc)
    figure.suptitle(
        "Topology-safe inward-boundary EIT: frozen final evaluation",
        fontsize=17,
        fontweight="bold",
        y=0.995,
    )
    figure.text(
        0.5,
        0.006,
        "Positive values favor final fusion. KTC is a public benchmark, not a fully untouched test after prior exploratory analysis.",
        ha="center",
        fontsize=9,
        color="#505050",
    )
    figure.tight_layout(rect=(0, 0.025, 1, 0.97), h_pad=2.2, w_pad=2.2)
    figure.savefig(output / "paper_metrics_summary.png", dpi=220, bbox_inches="tight")
    figure.savefig(output / "paper_metrics_summary.pdf", bbox_inches="tight")
    plt.close(figure)
    print(f"wrote paper summary; improved inward cases={improved}, harmed ordinary cases={harmed}")


if __name__ == "__main__":
    main()
