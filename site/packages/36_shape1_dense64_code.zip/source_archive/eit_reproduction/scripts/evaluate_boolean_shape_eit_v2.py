"""Strict paired evaluation for the independently trained Boolean Shape EIT v2.

The script combines frozen prediction archives only after model selection.  It
checks that every synthetic truth is byte-identical across experiments, then
compares the new network with the previously frozen vanilla, shape-aware, and
reliability-protected models.  Public KTC labels are evaluation-only.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import binary_dilation, binary_erosion

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from pytorch_eit.boolean_shape_net import BooleanShapeNet


GROUPS = {
    "base": "legacy_test",
    "biological": "biological_held_out_test",
    "stress": "deep_concavity_stress_test",
}
METHODS = ("vanilla", "shape_aware", "protected", "boolean_v2")
DISPLAY_NAMES = {
    "vanilla": "Vanilla U-Net",
    "shape_aware": "Prior shape-aware",
    "protected": "Prior protected",
    "boolean_v2": "Boolean Shape v2",
}
METRICS = (
    "foreground_iou",
    "foreground_dice",
    "boundary_f1",
    "notch_preservation",
    "bank_retention",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--checkpoint", type=Path,
        default=Path(r"E:\Codex\boolean_shape_eit_v2_full\boolean_shape_v2_best.pt"),
    )
    parser.add_argument(
        "--new-predictions", type=Path,
        default=Path(r"E:\Codex\boolean_shape_eit_v2_full\test_predictions.npz"),
    )
    parser.add_argument(
        "--prior-synthetic", type=Path,
        default=ROOT / "outputs" / "ktc_concavity_v3_biological" / "seed_20260831"
        / "evaluation" / "synthetic_predictions.npz",
    )
    parser.add_argument(
        "--prior-real", type=Path,
        default=ROOT / "outputs" / "ktc_concavity_v3_biological" / "seed_20260831"
        / "evaluation" / "real_predictions.npz",
    )
    parser.add_argument(
        "--joint-dataset", type=Path,
        default=ROOT / "datasets" / "ktc_joint_concavity_v1.npz",
    )
    parser.add_argument(
        "--audit", type=Path,
        default=ROOT / "outputs" / "ktc2023_full_audit" / "summary.json",
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=Path(r"E:\Codex\boolean_shape_eit_v2_final"),
    )
    parser.add_argument("--batch-size", type=int, default=24)
    parser.add_argument("--bootstrap", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=20260831)
    return parser.parse_args()


def indentation_mask(labels: np.ndarray) -> np.ndarray:
    """Instance-wise convex-hull indentation proxy used for public KTC labels."""
    from scipy.ndimage import label as connected_components
    from scipy.spatial import ConvexHull, QhullError
    from matplotlib.path import Path as MplPath

    foreground = labels != 0
    components, count = connected_components(foreground)
    result = np.zeros_like(foreground)
    yy, xx = np.indices(foreground.shape)
    points = np.column_stack((xx.ravel(), yy.ravel()))
    for component in range(1, count + 1):
        mask = components == component
        coords = np.argwhere(mask)
        if len(coords) < 3:
            continue
        xy = np.column_stack((coords[:, 1], coords[:, 0]))
        try:
            hull = ConvexHull(xy)
        except QhullError:
            continue
        polygon = MplPath(xy[hull.vertices])
        filled = polygon.contains_points(points, radius=1e-6).reshape(mask.shape)
        result |= filled & ~mask
    return result


def case_metrics(truth: np.ndarray, prediction: np.ndarray, notch: np.ndarray) -> dict[str, float]:
    truth_fg = truth != 0
    pred_fg = prediction != 0
    intersection = np.logical_and(truth_fg, pred_fg).sum()
    union = np.logical_or(truth_fg, pred_fg).sum()
    truth_edge = np.logical_xor(truth_fg, binary_erosion(truth_fg))
    pred_edge = np.logical_xor(pred_fg, binary_erosion(pred_fg))
    tolerance = np.ones((3, 3), dtype=bool)
    precision = (
        (pred_edge & binary_dilation(truth_edge, structure=tolerance)).sum()
        / max(1, pred_edge.sum())
    )
    recall = (
        (truth_edge & binary_dilation(pred_edge, structure=tolerance)).sum()
        / max(1, truth_edge.sum())
    )
    return {
        "foreground_iou": float(intersection / max(1, union)),
        "foreground_dice": float(2 * intersection / max(1, truth_fg.sum() + pred_fg.sum())),
        "boundary_f1": float(2 * precision * recall / max(1e-9, precision + recall)),
        "notch_preservation": float((~pred_fg[notch]).mean()) if notch.any() else float("nan"),
        "bank_retention": float(pred_fg[truth_fg].mean()) if truth_fg.any() else float("nan"),
    }


def evaluate_cases(
    ids: np.ndarray,
    truths: np.ndarray,
    notches: np.ndarray,
    predictions: dict[str, np.ndarray],
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for index, case_id in enumerate(ids):
        has_notch = bool(notches[index].any())
        for method, values in predictions.items():
            rows.append(
                {
                    "id": str(case_id),
                    "method": method,
                    "has_notch": has_notch,
                    "notch_pixels": int(notches[index].sum()),
                    **case_metrics(truths[index], values[index], notches[index]),
                }
            )
    return rows


def aggregate(rows: list[dict[str, object]], methods: tuple[str, ...] = METHODS) -> dict[str, object]:
    result: dict[str, object] = {}
    for method in methods:
        selected = [row for row in rows if row["method"] == method]
        summary: dict[str, float] = {"cases": float(len(selected))}
        for metric in METRICS:
            values = np.asarray([row[metric] for row in selected], dtype=float)
            summary[metric] = float(np.nanmean(values)) if np.isfinite(values).any() else float("nan")
        result[method] = summary
    return result


def paired_bootstrap(
    rows: list[dict[str, object]], candidate: str, reference: str, repetitions: int, seed: int
) -> dict[str, object]:
    candidate_rows = {str(row["id"]): row for row in rows if row["method"] == candidate}
    reference_rows = {str(row["id"]): row for row in rows if row["method"] == reference}
    ids = sorted(candidate_rows.keys() & reference_rows.keys())
    rng = np.random.default_rng(seed)
    result: dict[str, object] = {"cases": len(ids)}
    for metric in METRICS:
        difference = np.asarray(
            [float(candidate_rows[key][metric]) - float(reference_rows[key][metric]) for key in ids]
        )
        difference = difference[np.isfinite(difference)]
        if difference.size == 0:
            continue
        sampled = rng.integers(0, difference.size, size=(repetitions, difference.size))
        means = difference[sampled].mean(axis=1)
        result[metric] = {
            "mean_difference": float(difference.mean()),
            "ci95_low": float(np.percentile(means, 2.5)),
            "ci95_high": float(np.percentile(means, 97.5)),
            "probability_positive": float((means > 0).mean()),
        }
    return result


@torch.no_grad()
def infer_public(
    checkpoint: Path,
    fov: np.ndarray,
    images: np.ndarray,
    voltages: np.ndarray,
    batch_size: int,
) -> np.ndarray:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    state = torch.load(checkpoint, map_location=device, weights_only=False)
    model = BooleanShapeNet(
        fov,
        base=int(state["base_channels"]),
        temperature=float(state.get("temperature", 0.42)),
    ).to(device)
    model.load_state_dict(state["model"])
    model.eval()
    predictions: list[np.ndarray] = []
    for start in range(0, len(images), batch_size):
        image = torch.from_numpy(images[start : start + batch_size, None].astype(np.float32)).to(device)
        voltage = torch.from_numpy(voltages[start : start + batch_size].astype(np.float32)).to(device)
        probability = model(image, voltage)["probabilities"]
        enlarged = F.interpolate(probability, size=(256, 256), mode="bilinear", align_corners=False)
        predictions.append(enlarged.argmax(dim=1).cpu().numpy())
    return np.concatenate(predictions)


def save_rows(path: Path, rows: list[dict[str, object]]) -> None:
    fields = list(rows[0])
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def select_cases(notches: np.ndarray, ordinary: int = 2, concave: int = 4) -> np.ndarray:
    pixels = notches.reshape(len(notches), -1).sum(axis=1)
    ordinary_ids = np.flatnonzero(pixels == 0)[:ordinary]
    concave_ids = np.argsort(pixels)[-concave:][::-1]
    return np.concatenate((concave_ids, ordinary_ids)).astype(int)


def save_comparison(
    path: Path,
    title: str,
    ids: np.ndarray,
    truths: np.ndarray,
    inputs: np.ndarray,
    notches: np.ndarray,
    predictions: dict[str, np.ndarray],
    selected: np.ndarray,
) -> None:
    columns = ("truth", "linear EIT", *METHODS)
    figure, axes = plt.subplots(len(selected), len(columns), figsize=(13.2, 2.15 * len(selected)), squeeze=False)
    for row, index in enumerate(selected):
        linear = inputs[index]
        scale = max(float(np.percentile(np.abs(linear), 99)), 1e-6)
        panels = [
            (truths[index], "viridis", 0, 2),
            (linear, "coolwarm", -scale, scale),
            *[(predictions[method][index], "viridis", 0, 2) for method in METHODS],
        ]
        for column, (panel, cmap, vmin, vmax) in enumerate(panels):
            axes[row, column].imshow(panel, cmap=cmap, vmin=vmin, vmax=vmax)
            axes[row, column].set_axis_off()
            if row == 0:
                label = DISPLAY_NAMES.get(columns[column], columns[column])
                axes[row, column].set_title(label, fontsize=9)
        axes[row, 0].set_ylabel(
            f"{ids[index]}\nnotch={int(notches[index].sum())}", fontsize=8
        )
    figure.suptitle(title, fontsize=14)
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def save_metric_figure(path: Path, summaries: dict[str, dict[str, object]]) -> None:
    groups = ("biological_concave", "biological_ordinary", "stress", "public_nonconvex")
    metrics = ("foreground_iou", "notch_preservation", "bank_retention")
    figure, axes = plt.subplots(1, len(metrics), figsize=(14.0, 4.2))
    x = np.arange(len(groups))
    width = 0.19
    for method_index, method in enumerate(METHODS):
        for axis, metric in zip(axes, metrics):
            values = [float(summaries[group][method][metric]) for group in groups]
            axis.bar(x + (method_index - 1.5) * width, values, width, label=DISPLAY_NAMES[method])
    labels = ("biological\nconcave", "biological\nordinary", "deep stress", "public KTC\nnonconvex")
    for axis, metric in zip(axes, metrics):
        axis.set_title(metric.replace("_", " "))
        axis.set_xticks(x, labels)
        axis.set_ylim(0.0, 1.0)
        axis.grid(axis="y", alpha=0.25)
    axes[0].legend(fontsize=7, loc="lower left")
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    new = np.load(args.new_predictions.resolve())
    prior = np.load(args.prior_synthetic.resolve())
    synthetic_rows: list[dict[str, object]] = []
    summaries: dict[str, dict[str, object]] = {}
    comparisons: dict[str, object] = {}

    for group, prefix in GROUPS.items():
        truth = new[f"{group}_truth"]
        if not np.array_equal(truth, prior[f"{prefix}_truth"]):
            raise ValueError(f"{group} truth differs between the frozen experiments")
        ids = prior[f"{prefix}_ids"]
        notch = new[f"{group}_cutout"].astype(bool)
        predictions = {
            "vanilla": prior[f"{prefix}_vanilla"],
            "shape_aware": prior[f"{prefix}_candidate"],
            "protected": prior[f"{prefix}_protected"],
            "boolean_v2": new[f"{group}_prediction"],
        }
        rows = evaluate_cases(ids, truth, notch, predictions)
        for row in rows:
            row["group"] = group
        synthetic_rows.extend(rows)
        concave_rows = [row for row in rows if bool(row["has_notch"])]
        ordinary_rows = [row for row in rows if not bool(row["has_notch"])]
        summaries[group] = aggregate(rows)
        if concave_rows:
            summaries[f"{group}_concave"] = aggregate(concave_rows)
        if ordinary_rows:
            summaries[f"{group}_ordinary"] = aggregate(ordinary_rows)
        comparisons[group] = {
            baseline: paired_bootstrap(
                rows, "boolean_v2", baseline, args.bootstrap, args.seed + 100 * len(comparisons)
            )
            for baseline in METHODS[:-1]
        }
        save_comparison(
            output / f"{group}_comparison.png",
            f"Independent {group} test",
            ids,
            truth,
            new[f"{group}_image"],
            notch,
            predictions,
            select_cases(notch),
        )

    joint = np.load(args.joint_dataset.resolve(), allow_pickle=False)
    prior_real = np.load(args.prior_real.resolve())
    real_truth = prior_real["truth"]
    real_ids = prior_real["ids"]
    boolean_real = infer_public(
        args.checkpoint.resolve(),
        np.asarray(joint["fov_mask"], dtype=np.uint8),
        np.asarray(joint["real_linear_images"], dtype=np.float32),
        np.asarray(joint["real_voltages"], dtype=np.float32),
        args.batch_size,
    )
    real_notch = np.stack([indentation_mask(labels) for labels in real_truth])
    real_predictions = {
        "vanilla": prior_real["vanilla"],
        "shape_aware": prior_real["candidate"],
        "protected": prior_real["protected"],
        "boolean_v2": boolean_real,
    }
    real_rows = evaluate_cases(real_ids, real_truth, real_notch, real_predictions)
    for row in real_rows:
        row["group"] = "public_ktc"
    audit = json.loads(args.audit.resolve().read_text(encoding="utf-8"))
    nonconvex_ids = set(map(str, audit["nonconvex_ids"]))
    nonconvex_rows = [row for row in real_rows if str(row["id"]) in nonconvex_ids]
    ordinary_rows = [row for row in real_rows if str(row["id"]) not in nonconvex_ids]
    summaries["public_all"] = aggregate(real_rows)
    summaries["public_nonconvex"] = aggregate(nonconvex_rows)
    summaries["public_ordinary"] = aggregate(ordinary_rows)
    comparisons["public_nonconvex"] = {
        baseline: paired_bootstrap(
            nonconvex_rows, "boolean_v2", baseline, args.bootstrap, args.seed + 701
        )
        for baseline in METHODS[:-1]
    }
    strict_indices = np.asarray(
        [index for index, value in enumerate(real_ids) if str(value) in nonconvex_ids], dtype=int
    )
    strict_order = strict_indices[
        np.argsort(real_notch[strict_indices].reshape(len(strict_indices), -1).sum(axis=1))[::-1]
    ][:8]
    save_comparison(
        output / "public_ktc_nonconvex_comparison.png",
        "Public KTC2023 audited non-convex cases",
        real_ids,
        real_truth,
        np.asarray(joint["real_linear_images"]),
        real_notch,
        real_predictions,
        strict_order,
    )
    save_rows(output / "synthetic_case_metrics.csv", synthetic_rows)
    save_rows(output / "public_ktc_case_metrics.csv", real_rows)
    np.savez_compressed(
        output / "public_ktc_predictions.npz",
        ids=real_ids,
        truth=real_truth,
        notch=real_notch.astype(np.uint8),
        **real_predictions,
    )
    save_metric_figure(output / "unified_metric_comparison.png", summaries)
    result = {
        "method": "independently trained physics- and topology-aware Boolean Shape EIT v2",
        "checkpoint": str(args.checkpoint.resolve()),
        "synthetic_truths_byte_identical_across_experiments": True,
        "public_ktc_truth_used_for_training_or_model_selection": False,
        "summaries": summaries,
        "paired_bootstrap_boolean_v2_minus_baseline": comparisons,
    }
    (output / "comparison_summary.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
