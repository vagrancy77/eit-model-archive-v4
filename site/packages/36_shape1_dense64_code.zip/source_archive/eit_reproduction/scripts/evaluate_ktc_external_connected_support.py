"""Validation-selected support minus externally connected cutout reconstruction.

This evaluator tests a topology-aware composition motivated by level-set and
Boolean-shape reconstruction: the network predicts an outer support, an
inward cutout, and a mouth/contact field.  Only cutout components containing a
high-confidence mouth are removed from the support.  The untouched synthetic
test split and KTC labels are used only after validation selection.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from types import SimpleNamespace

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import label as connected_components

from train_ktc_concavity_network import InputAdapter, save_focus_montage, save_real_montage, write_rows
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_highres_refiner import (
    load_coarse_ensemble,
    load_dip_four_case_predictions,
    load_official_four_case_truths,
    save_official_four_case_comparison,
)
from train_ktc_implicit_boolean_network import (
    FAMILIES,
    ImplicitBooleanNet,
    prepare_structural_arrays,
    standard_metrics,
    stress_metrics,
)
from calibrate_ktc_implicit_boolean import collect_raw_fields, predict_from_fields
from select_ktc_mouth_gating import collect_entrance_fields

STRUCTURE = np.ones((3, 3), dtype=np.uint8)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    parser.add_argument("--entrance-checkpoint", type=Path, required=True)
    parser.add_argument("--coarse-checkpoint", nargs="+", type=Path, default=[
        root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "boundary_best.pt",
        root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "indent_best.pt",
        root / "outputs" / "ktc_concavity_voltage_seed20260819" / "voltage_best.pt",
    ])
    parser.add_argument("--coarse-weights", nargs="+", type=float, default=[0.30, 0.40, 0.30])
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--batch-size", type=int, default=24)
    parser.add_argument(
        "--grid-profile",
        choices=("fast", "full"),
        default="fast",
        help="Fast validation search around the previous optimum; full reproduces the exhaustive grid.",
    )
    parser.add_argument(
        "--predicted-foreground-guard",
        action="store_true",
        help="Only remove cutout pixels that the original class prediction labels as background.",
    )
    return parser.parse_args()


def load_model(path: Path, device: torch.device) -> ImplicitBooleanNet:
    state = torch.load(path.resolve(), map_location=device, weights_only=False)
    model = ImplicitBooleanNet(int(state["base_channels"])).to(device)
    model.load_state_dict(state["model"], strict=False)
    model.use_external_connectivity = bool(state.get("external_connectivity", False))
    model.connectivity_steps = int(state.get("connectivity_steps", 28))
    model.eval()
    return model


def _class_fill(mask: np.ndarray, prediction: np.ndarray) -> np.ndarray:
    """Assign newly recovered support pixels to the nearest predicted class."""
    result = prediction.copy()
    missing = (mask != 0) & (result == 0)
    if not missing.any():
        return result.astype(np.uint8)
    class_one = result == 1
    class_two = result == 2
    if not class_one.any() and not class_two.any():
        result[missing] = 1
        return result.astype(np.uint8)
    from scipy.ndimage import distance_transform_edt

    d1 = distance_transform_edt(~class_one) if class_one.any() else np.full(mask.shape, np.inf)
    d2 = distance_transform_edt(~class_two) if class_two.any() else np.full(mask.shape, np.inf)
    result[missing & (d1 <= d2)] = 1
    result[missing & (d2 < d1)] = 2
    return result.astype(np.uint8)


def connected_cutout(
    support: np.ndarray,
    cutout: np.ndarray,
    mouth: np.ndarray,
    support_threshold: float,
    cutout_threshold: float,
    mouth_threshold: float,
    min_component: int,
) -> tuple[np.ndarray, np.ndarray]:
    """Return support mask and the cutout components touched by mouth."""
    support_mask = support >= support_threshold
    cutout_mask = cutout >= cutout_threshold
    mouth_mask = mouth >= mouth_threshold
    components, count = connected_components(cutout_mask.astype(np.uint8), structure=STRUCTURE)
    selected = np.zeros_like(cutout_mask, dtype=bool)
    for component in range(1, count + 1):
        pixels = components == component
        if int(pixels.sum()) >= min_component and np.any(mouth_mask & pixels):
            selected |= pixels
    return support_mask, selected


def compose(
    prediction: np.ndarray,
    support: np.ndarray,
    cutout: np.ndarray,
    mouth: np.ndarray,
    support_threshold: float,
    cutout_threshold: float,
    mouth_threshold: float,
    min_component: int,
    gate_area: float,
    bank: np.ndarray | None = None,
    bank_threshold: float = 1.1,
    predicted_foreground_guard: bool = False,
) -> tuple[np.ndarray, np.ndarray]:
    result = np.zeros_like(prediction, dtype=np.uint8)
    selected = np.zeros(len(prediction), dtype=bool)
    for index in range(len(prediction)):
        support_mask, external_cutout = connected_cutout(
            support[index], cutout[index], mouth[index], support_threshold,
            cutout_threshold, mouth_threshold, min_component,
        )
        # A mouth must remove a non-trivial cutout fraction; otherwise use the
        # original neural prediction to avoid changing ordinary lesions.
        selected[index] = bool(external_cutout.sum() >= gate_area * max(1, support_mask.sum()))
        if selected[index]:
            removable = external_cutout.copy()
            # Preserve pixels identified by the explicit bank head. A value
            # above one disables this protection for the unprotected ablation.
            if bank is not None:
                removable &= bank[index] < bank_threshold
            if predicted_foreground_guard:
                # The Boolean cutout head can extend across a weakly predicted
                # lesion bank. Keep those pixels unless the original decoder
                # also classified them as background.
                removable &= prediction[index] == 0
            result[index] = _class_fill(support_mask & ~removable, prediction[index])
        else:
            result[index] = prediction[index]
    return result, selected


def resize_fields(fields: dict[str, np.ndarray], size: int = 256) -> dict[str, np.ndarray]:
    """Match the 256x256 raster used by the public KTC real labels."""
    result: dict[str, np.ndarray] = {}
    for key, value in fields.items():
        tensor = torch.from_numpy(value)
        if value.ndim == 3 and value.shape[-1] != size:
            mode = "nearest" if key in {"prediction", "logits"} else "bilinear"
            tensor = F.interpolate(tensor[:, None].float(), size=(size, size), mode=mode, align_corners=False if mode != "nearest" else None)
            result[key] = tensor[:, 0].numpy().astype(value.dtype)
        elif value.ndim == 4 and value.shape[-1] != size:
            tensor = F.interpolate(tensor.float(), size=(size, size), mode="bilinear", align_corners=False)
            result[key] = tensor.numpy().astype(value.dtype)
        else:
            result[key] = value
    return result


def resize_labels(labels: np.ndarray, size: int = 256) -> np.ndarray:
    tensor = torch.from_numpy(labels[:, None].astype(np.float32))
    return F.interpolate(tensor, size=(size, size), mode="nearest")[:, 0].numpy().astype(np.uint8)


def save_montage(path: Path, truth: np.ndarray, prediction: np.ndarray, support: np.ndarray, cutout: np.ndarray, selected: np.ndarray, title: str) -> None:
    indices = list(range(min(16, len(truth))))
    figure, axes = plt.subplots(len(indices), 5, figsize=(12, 2.3 * len(indices)), squeeze=False)
    for row, index in enumerate(indices):
        gate_image = np.full_like(truth[index], int(selected[index]), dtype=np.uint8)
        images = ((truth[index], "truth"), (prediction[index], "external connected"), (support[index] >= 0.5, "support"), (cutout[index] >= 0.5, "cutout"), (gate_image, "gate"))
        for column, (image, name) in enumerate(images):
            axes[row, column].imshow(image, cmap="viridis", vmin=0, vmax=2, interpolation="nearest")
            axes[row, column].set_title(name); axes[row, column].set_axis_off()
    figure.suptitle(title); figure.tight_layout(); figure.savefig(path, dpi=180); plt.close(figure)


def main() -> None:
    args = parse_args(); out = args.output_dir.resolve(); out.mkdir(parents=True, exist_ok=True)
    ba = np.load(args.base_dataset.resolve(), allow_pickle=False); sa = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    base = SimpleNamespace(images=np.asarray(ba["linear_images"], dtype=np.float32), voltages=np.asarray(ba["voltages"], dtype=np.float32), labels=np.asarray(ba["labels"], dtype=np.uint8), indentation=np.asarray(ba["indentation_masks"], dtype=np.uint8))
    stress = prepare_structural_arrays(sa, "stress")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    coarse, _, weights = load_coarse_ensemble(args.coarse_checkpoint, args.coarse_weights, device)
    adapter = InputAdapter(ba["fov_mask"]).to(device)
    model = load_model(args.entrance_checkpoint, device)

    def infer(images: np.ndarray, voltages: np.ndarray) -> dict[str, np.ndarray]:
        fields = collect_entrance_fields(images, voltages, coarse, model, adapter, device, args.batch_size)
        return fields

    def evaluate_grid() -> tuple[dict[str, float], list[dict[str, float]]]:
        bv = np.asarray(ba["validation_indices"], dtype=np.int64); sv = np.asarray(sa["validation_indices"], dtype=np.int64)
        bf = infer(base.images[bv], base.voltages[bv]); sf = infer(stress.images[sv], stress.voltages[sv])
        rows: list[dict[str, float]] = []; best = None
        if args.grid_profile == "full":
            supports, cutouts, mouths = (0.35, 0.50, 0.65), (0.35, 0.50, 0.65), (0.35, 0.50, 0.65, 0.80)
            minimums, gates, bank_thresholds = (1, 5, 15), (0.002, 0.005, 0.010, 0.020), (0.35, 0.50, 0.65, 0.80, 0.95, 1.10)
        else:
            # The previous run selected (0.65, 0.35, 0.35, 15, 0.002).
            # Search its neighborhood plus a no-protection control.
            supports, cutouts, mouths = (0.65,), (0.35, 0.50), (0.35, 0.50)
            minimums, gates, bank_thresholds = (15,), (0.002, 0.010), (0.35, 0.50, 0.65, 0.80, 0.95, 1.10)
        for st in supports:
            for ct in cutouts:
                for mt in mouths:
                    for minimum in minimums:
                        for gate in gates:
                            for bank_threshold in bank_thresholds:
                                bp, bsel = compose(bf["prediction"], bf["support"], bf["cutout"], bf["mouth"], st, ct, mt, minimum, gate, bf["bank"], bank_threshold, args.predicted_foreground_guard)
                                sp, ssel = compose(sf["prediction"], sf["support"], sf["cutout"], sf["mouth"], st, ct, mt, minimum, gate, sf["bank"], bank_threshold, args.predicted_foreground_guard)
                                bm = standard_metrics(base.labels[bv], bp, base.indentation[bv])
                                sm, fam, _ = stress_metrics(stress.labels[sv], sp, stress.cutout[sv], stress.cutout_depth[sv], stress.family_codes[sv])
                                row = {"support_threshold": st, "cutout_threshold": ct, "mouth_threshold": mt, "min_component": minimum, "gate_area": gate, "bank_threshold": bank_threshold, "base_iou": bm["foreground_iou"], "base_boundary": bm["boundary_f1"], "stress_iou": sm["foreground_iou"], "stress_boundary": sm["boundary_f1"], "stress_open_deep": sm["open_deep_cutout_recovery"], "stress_bank": sm["bank_retention"], "stress_joint": sm["topology_structural_joint"], "deep_c_open": fam["deep_c"]["open_deep_cutout_recovery"], "deep_c_bank": fam["deep_c"]["bank_retention"], "base_selected": float(bsel.mean()), "stress_selected": float(ssel.mean())}
                                rows.append(row)
                                # Keep ordinary/base reconstruction stable while
                                # prioritizing external deep-cutout topology.
                                eligible = row["base_iou"] >= 0.584 - 0.008 and row["stress_iou"] >= 0.589 - 0.012 and row["stress_bank"] >= 0.658 - 0.045
                                key = (row["stress_joint"], row["deep_c_open"], row["stress_open_deep"], -row["stress_selected"])
                                if eligible and (best is None or key > best["_key"]): best = {**row, "_key": key}
        if best is None: best = max(rows, key=lambda r: (r["stress_joint"], r["deep_c_open"]))
        best.pop("_key", None)
        return best, rows

    selected, grid = evaluate_grid()
    with (out / "validation_grid.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(grid[0])); writer.writeheader(); writer.writerows(grid)

    def run(name: str, bidx: np.ndarray, sidx: np.ndarray):
        bf = infer(base.images[bidx], base.voltages[bidx]); sf = infer(stress.images[sidx], stress.voltages[sidx])
        bp, bsel = compose(bf["prediction"], bf["support"], bf["cutout"], bf["mouth"], selected["support_threshold"], selected["cutout_threshold"], selected["mouth_threshold"], int(selected["min_component"]), selected["gate_area"], bf["bank"], selected["bank_threshold"], args.predicted_foreground_guard)
        sp, ssel = compose(sf["prediction"], sf["support"], sf["cutout"], sf["mouth"], selected["support_threshold"], selected["cutout_threshold"], selected["mouth_threshold"], int(selected["min_component"]), selected["gate_area"], sf["bank"], selected["bank_threshold"], args.predicted_foreground_guard)
        bm = standard_metrics(base.labels[bidx], bp, base.indentation[bidx]); sm, fam, rows = stress_metrics(stress.labels[sidx], sp, stress.cutout[sidx], stress.cutout_depth[sidx], stress.family_codes[sidx])
        save_montage(out / f"{name}_external_connected_montage.png", stress.labels[sidx], sp, sf["support"], sf["cutout"], ssel, f"{name}: externally connected cutout")
        return {"base": bm, "stress": {"summary": sm, "by_family": fam, "rows": rows}, "base_selected_fraction": float(bsel.mean()), "stress_selected_fraction": float(ssel.mean())}, (bp, sp)

    bt = np.asarray(ba["test_indices"], dtype=np.int64); st = np.asarray(sa["test_indices"], dtype=np.int64)
    test, preds = run("test", bt, st)
    calibration_images = np.asarray(ba["calibration_linear_images"], dtype=np.float32)
    calibration_voltages = np.asarray(ba["calibration_voltages"], dtype=np.float32)
    cf = infer(calibration_images, calibration_voltages)
    cp, csel = compose(cf["prediction"], cf["support"], cf["cutout"], cf["mouth"], selected["support_threshold"], selected["cutout_threshold"], selected["mouth_threshold"], int(selected["min_component"]), selected["gate_area"], cf["bank"], selected["bank_threshold"], args.predicted_foreground_guard)
    official_truth, official_ids = load_official_four_case_truths(Path(__file__).resolve().parents[1] / "external" / "KTC2023-ABC2")
    official_predictions = {
        "DIP_TV": load_dip_four_case_predictions(Path(__file__).resolve().parents[1]),
        "external_connected": resize_labels(cp),
    }
    official_summary: dict[str, dict[str, float]] = {}; official_rows: list[dict[str, object]] = []
    for method, prediction in official_predictions.items():
        method_summary, method_rows = evaluate_real_predictions(method, prediction, official_truth, official_ids)
        official_summary[method] = method_summary; official_rows.extend(method_rows)
    write_rows(out / "official_four_case_metrics.csv", official_rows)
    save_official_four_case_comparison(out / "official_four_case_comparison.png", official_truth, official_ids, official_predictions, official_rows)

    real_images = np.asarray(ba["real_linear_images"], dtype=np.float32); real_voltages = np.asarray(ba["real_voltages"], dtype=np.float32); rf = resize_fields(infer(real_images, real_voltages))
    rp, rsel = compose(rf["prediction"], rf["support"], rf["cutout"], rf["mouth"], selected["support_threshold"], selected["cutout_threshold"], selected["mouth_threshold"], int(selected["min_component"]), selected["gate_area"], rf["bank"], selected["bank_threshold"], args.predicted_foreground_guard)
    truth = np.asarray(ba["real_labels"]); ids = np.asarray(ba["real_ids"]); real_summary, rows = evaluate_real_predictions("external_connected", rp, truth, ids)
    write_rows(out / "real_case_metrics.csv", rows); save_real_montage(out / "real_all_21_comparison.png", truth, ids, {"external_connected": rp}, rows); save_focus_montage(out / "real_most_concave_comparison.png", truth, ids, {"external_connected": rp}, rows)
    np.savez_compressed(out / "predictions.npz", base_test_indices=bt, stress_test_indices=st, base_external=preds[0], stress_external=preds[1], real_external=rp, real_selected=rsel)
    result = {"method": "support minus mouth-connected cutout", "selected_parameters": selected, "test": test, "official_four_calibration_cases": official_summary, "official_four_selected": csel.tolist(), "real_evaluation": {"external_connected": real_summary}, "real_selected_fraction": float(rsel.mean()), "evaluation_truth_used_for_training_or_selection": False, "entrance_checkpoint": str(args.entrance_checkpoint.resolve()), "coarse_weights": weights}
    (out / "summary.json").write_text(json.dumps(result, indent=2), encoding="utf-8"); print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__": main()
