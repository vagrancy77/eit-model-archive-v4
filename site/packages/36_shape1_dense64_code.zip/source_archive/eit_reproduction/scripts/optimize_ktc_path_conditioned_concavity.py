"""Path-conditioned local graph-cut optimization for inward EIT boundaries.

This experiment is deliberately independent of the DeepEIT decoder.  A stable
three-class reconstruction supplies the outer support and material polarity;
an accepted topology path supplies a background seed.  Only a small corridor
around that seed is optimized.  Learned cutout evidence favours background,
learned bank evidence protects the two lesion sides, and a Potts term keeps the
new boundary continuous.  Candidate width/energy settings are selected with
synthetic validation labels and cross-validated EIT measurement residuals.

Synthetic test labels and public KTC2023 labels are accessed only after all
graph-cut and physics-gate parameters have been frozen.
"""
from __future__ import annotations

import argparse
import csv
import heapq
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from scipy import ndimage as ndi
from scipy.ndimage import zoom
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import breadth_first_order, maximum_flow
from torch.utils.data import DataLoader

from evaluate_ktc_bank_guarded_wide_cutout import (
    CORE_FAMILY_CODES,
    PUBLIC_INWARD_BAY_IDS,
    core_metrics,
    infer_path_prediction,
    load_action_model,
    load_competitive_model,
)
from evaluate_ktc_candidate_opening_hybrid import infer_pair
from fuse_ktc_joint_shape_models import blend, load_model
from physics_gate_ktc_cutouts import (
    candidate_geometry_risks,
    candidate_physics,
    choose_indices,
    gather_candidates,
)
from prepare_ktc_deep_concavity_stress import FAMILIES
from train_ktc_candidate_opening_refiner import paired_bootstrap
from train_ktc_competitive_boolean_network import collect_fields, infer_real_fields
from train_ktc_concavity_network import InputAdapter, aggregate_rows
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_highres_refiner import load_coarse_ensemble
from train_ktc_implicit_boolean_network import (
    StructuralDataset,
    prepare_structural_arrays,
    standard_metrics,
    stress_metrics,
)


CAPACITY_SCALE = 1000.0
HARD_CAPACITY = 1_000_000
PUBLIC_INWARD_IDS = (
    "level_2/1", "level_2/3", "level_3/2", "level_5/2", "level_6/2",
    "level_6/3", "level_7/1", "level_7/2", "level_7/3",
)


@dataclass(frozen=True)
class GraphCutSpec:
    name: str
    radius: int
    cutout_bias: float
    bank_weight: float
    smoothness: float
    hard_bank: float


GRAPH_SPECS = (
    GraphCutSpec("gc_r2", 2, -0.20, 1.25, 0.16, 0.92),
    GraphCutSpec("gc_r3", 3, -0.05, 1.25, 0.20, 0.90),
    GraphCutSpec("gc_r4", 4, 0.10, 1.15, 0.24, 0.88),
    GraphCutSpec("gc_r5", 5, 0.20, 1.10, 0.30, 0.86),
    GraphCutSpec("gc_r6", 6, 0.30, 1.05, 0.36, 0.84),
)
CANDIDATE_NAMES = tuple(
    [f"accepted_{spec.name}" for spec in GRAPH_SPECS]
    + [f"geodesic_{spec.name}" for spec in GRAPH_SPECS]
    + [f"peak_{spec.name}" for spec in GRAPH_SPECS]
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    parser.add_argument(
        "--competitive-checkpoint", type=Path,
        default=root / "outputs" / "ktc_competitive_boolean_v2_seed20260820" / "competitive_boolean_best.pt",
    )
    parser.add_argument(
        "--coarse-checkpoint", nargs="+", type=Path,
        default=[
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "boundary_best.pt",
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "indent_best.pt",
            root / "outputs" / "ktc_concavity_voltage_seed20260819" / "voltage_best.pt",
        ],
    )
    parser.add_argument("--coarse-weights", nargs="+", type=float, default=[0.30, 0.40, 0.30])
    parser.add_argument("--action-checkpoint", type=Path, default=Path("E:/Codex/ktc_candidate_opening_seed20260820/best.pt"))
    parser.add_argument("--path-summary", type=Path, default=Path("E:/Codex/ktc_candidate_hybrid_seed20260820/summary.json"))
    parser.add_argument("--conservative", type=Path, default=Path("E:/Codex/ktc_joint_shape_pretrained_seed20260820/best.pt"))
    parser.add_argument("--aggressive", type=Path, default=Path("E:/Codex/ktc_joint_shape_network_seed20260820/best.pt"))
    parser.add_argument(
        "--output-dir", type=Path,
        default=root / "outputs" / "ktc_path_conditioned_graphcut_seed20260820",
    )
    parser.add_argument("--batch-size", type=int, default=48)
    parser.add_argument("--bootstrap-samples", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260820)
    return parser.parse_args()


def _logit(values: np.ndarray) -> np.ndarray:
    clipped = np.clip(values.astype(np.float64), 1e-4, 1.0 - 1e-4)
    return np.log(clipped) - np.log1p(-clipped)


def removal_probability(
    cutout_probability: np.ndarray,
    bank_probability: np.ndarray,
    spec: GraphCutSpec,
) -> np.ndarray:
    logits = _logit(cutout_probability) - spec.bank_weight * _logit(bank_probability) + spec.cutout_bias
    return 1.0 / (1.0 + np.exp(-np.clip(logits, -18.0, 18.0)))


def local_graph_cut(
    raw: np.ndarray,
    path_prediction: np.ndarray,
    cutout_probability: np.ndarray,
    bank_probability: np.ndarray,
    spec: GraphCutSpec,
) -> tuple[np.ndarray, np.ndarray]:
    """Optimize removal only in a path-centred corridor.

    Source-side nodes mean foreground/keep and sink-side nodes mean
    background/remove.  The previously accepted connector is a hard background
    seed.  Pixels outside the corridor are fixed foreground through boundary
    pairwise costs rather than being included as free graph nodes.
    """
    raw_foreground = raw != 0
    path_seed = raw_foreground & (path_prediction == 0)
    if not np.any(path_seed):
        return path_prediction.copy(), np.zeros_like(raw_foreground)

    structure = ndi.generate_binary_structure(2, 2)
    corridor = ndi.binary_dilation(path_seed, structure=structure, iterations=spec.radius) & raw_foreground
    coordinates = np.argwhere(corridor)
    if coordinates.size == 0:
        return path_prediction.copy(), np.zeros_like(raw_foreground)
    height, width = raw.shape
    node_map = np.full((height, width), -1, dtype=np.int32)
    node_map[corridor] = np.arange(len(coordinates), dtype=np.int32)
    source = len(coordinates)
    sink = source + 1

    q = removal_probability(cutout_probability, bank_probability, spec)
    d_remove = -np.log(np.clip(q[corridor], 1e-7, 1.0))
    d_keep = -np.log(np.clip(1.0 - q[corridor], 1e-7, 1.0))
    seed_values = path_seed[corridor]
    hard_bank_values = (bank_probability[corridor] >= spec.hard_bank) & ~seed_values
    d_remove[hard_bank_values] = HARD_CAPACITY / CAPACITY_SCALE
    d_keep[seed_values] = HARD_CAPACITY / CAPACITY_SCALE
    d_remove[seed_values] = 0.0

    rows: list[int] = []
    columns: list[int] = []
    capacities: list[int] = []

    def add_edge(row: int, column: int, capacity: float) -> None:
        value = max(0, int(round(capacity * CAPACITY_SCALE)))
        if value:
            rows.append(row)
            columns.append(column)
            capacities.append(value)

    for node, (row, column) in enumerate(coordinates):
        add_edge(source, node, float(d_remove[node]))
        add_edge(node, sink, float(d_keep[node]))
        for dr, dc in ((1, 0), (0, 1)):
            rr, cc = int(row + dr), int(column + dc)
            if rr >= height or cc >= width:
                continue
            neighbour = int(node_map[rr, cc])
            edge_weight = spec.smoothness * (
                0.35 + math.exp(-3.0 * abs(float(q[row, column] - q[rr, cc])))
            )
            if neighbour >= 0:
                add_edge(node, neighbour, edge_weight)
                add_edge(neighbour, node, edge_weight)
            elif raw_foreground[rr, cc]:
                add_edge(source, node, edge_weight)
        # The two negative directions are needed only for fixed corridor boundaries.
        for dr, dc in ((-1, 0), (0, -1)):
            rr, cc = int(row + dr), int(column + dc)
            if rr >= 0 and cc >= 0 and node_map[rr, cc] < 0 and raw_foreground[rr, cc]:
                edge_weight = spec.smoothness * (
                    0.35 + math.exp(-3.0 * abs(float(q[row, column] - q[rr, cc])))
                )
                add_edge(source, node, edge_weight)

    capacity = coo_matrix(
        (np.asarray(capacities, dtype=np.int64), (rows, columns)),
        shape=(sink + 1, sink + 1),
        dtype=np.int64,
    ).tocsr()
    flow = maximum_flow(capacity, source, sink).flow
    residual = capacity - flow
    reachable = breadth_first_order(
        (residual > 0).astype(np.int8), source, directed=True, return_predecessors=False
    )
    source_side = np.zeros(sink + 1, dtype=bool)
    source_side[np.asarray(reachable, dtype=np.int64)] = True
    removed = np.zeros_like(raw_foreground)
    removed[corridor] = ~source_side[:source]
    removed |= path_seed
    output = path_prediction.copy()
    output[removed] = 0
    return output, removed


def shortest_foreground_path(
    foreground: np.ndarray,
    starts: np.ndarray,
    goals: np.ndarray,
    pixel_cost: np.ndarray,
) -> np.ndarray | None:
    height, width = foreground.shape
    distance = np.full((height, width), np.inf, dtype=np.float64)
    predecessor = np.full((height, width, 2), -1, dtype=np.int16)
    queue: list[tuple[float, int, int]] = []
    for row, column in np.argwhere(starts):
        distance[row, column] = float(pixel_cost[row, column])
        heapq.heappush(queue, (float(distance[row, column]), int(row), int(column)))
    end: tuple[int, int] | None = None
    while queue:
        current_distance, row, column = heapq.heappop(queue)
        if current_distance != distance[row, column]:
            continue
        if goals[row, column]:
            end = (row, column)
            break
        for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            rr, cc = row + dr, column + dc
            if rr < 0 or rr >= height or cc < 0 or cc >= width or not foreground[rr, cc]:
                continue
            proposal = current_distance + 0.5 * float(pixel_cost[row, column] + pixel_cost[rr, cc])
            if proposal < distance[rr, cc]:
                distance[rr, cc] = proposal
                predecessor[rr, cc] = (row, column)
                heapq.heappush(queue, (proposal, rr, cc))
    if end is None:
        return None
    seed = np.zeros_like(foreground)
    current = end
    while current[0] >= 0:
        seed[current] = True
        previous = predecessor[current]
        current = (int(previous[0]), int(previous[1]))
    return seed


def geodesic_cavity_seed(
    raw: np.ndarray,
    cutout_probability: np.ndarray,
    bank_probability: np.ndarray,
    spec: GraphCutSpec,
) -> np.ndarray | None:
    """Find a low-cost connector from the largest closed cavity to outside."""
    foreground = raw != 0
    components, count = ndi.label(~foreground, structure=np.ones((3, 3), dtype=np.uint8))
    border_ids = np.unique(
        np.concatenate((components[0], components[-1], components[:, 0], components[:, -1]))
    )
    cavities = [components == component for component in range(1, count + 1) if component not in border_ids]
    if not cavities:
        return None
    cavity = max(cavities, key=lambda mask: int(mask.sum()))
    outside = np.isin(components, border_ids) & ~foreground
    starts = ndi.binary_dilation(cavity, structure=np.ones((3, 3), dtype=bool)) & foreground
    goals = ndi.binary_dilation(outside, structure=np.ones((3, 3), dtype=bool)) & foreground
    if not np.any(starts) or not np.any(goals):
        return None
    q = removal_probability(cutout_probability, bank_probability, spec)
    pixel_cost = 0.15 + 2.0 * (1.0 - q) + 2.5 * bank_probability
    return shortest_foreground_path(foreground, starts, goals, pixel_cost)


def geodesic_peak_seed(
    raw: np.ndarray,
    cutout_probability: np.ndarray,
    bank_probability: np.ndarray,
    spec: GraphCutSpec,
) -> np.ndarray | None:
    """Initialize an inward path when the current result has no closed cavity.

    The target is the strongest cutout-like interior point after a shallow
    depth weighting.  This permits a concavity to be created in a solid coarse
    inclusion, which is essential for public cases where EIT smooths a notch
    into a convex blob.
    """
    foreground = raw != 0
    components, _ = ndi.label(~foreground, structure=np.ones((3, 3), dtype=np.uint8))
    border_ids = np.unique(
        np.concatenate((components[0], components[-1], components[:, 0], components[:, -1]))
    )
    outside = np.isin(components, border_ids) & ~foreground
    goals = ndi.binary_dilation(outside, structure=np.ones((3, 3), dtype=bool)) & foreground
    if not np.any(goals) or not np.any(foreground):
        return None
    q = removal_probability(cutout_probability, bank_probability, spec)
    depth = ndi.distance_transform_edt(foreground)
    score = q * np.minimum(depth / 4.0, 1.0)
    score[~foreground] = -1.0
    score[depth < 1.5] = -1.0
    target = np.unravel_index(int(np.argmax(score)), score.shape)
    if float(score[target]) < 0.35:
        return None
    starts = np.zeros_like(foreground)
    starts[target] = True
    pixel_cost = 0.15 + 2.0 * (1.0 - q) + 2.5 * bank_probability
    return shortest_foreground_path(foreground, starts, goals, pixel_cost)


def graph_cut_candidates(
    raw: np.ndarray,
    path_prediction: np.ndarray,
    fields: dict[str, np.ndarray],
    specs: tuple[GraphCutSpec, ...] = GRAPH_SPECS,
) -> tuple[np.ndarray, np.ndarray]:
    candidate_count = 3 * len(specs)
    candidates = np.empty((candidate_count, len(raw), *raw.shape[1:]), dtype=np.uint8)
    removed = np.zeros((candidate_count, len(raw), *raw.shape[1:]), dtype=bool)
    for spec_index, spec in enumerate(specs):
        for sample_index in range(len(raw)):
            candidate, cut = local_graph_cut(
                raw[sample_index], path_prediction[sample_index],
                fields["cutout_proposal"][sample_index, 0], fields["bank"][sample_index, 0], spec,
            )
            candidates[spec_index, sample_index] = candidate
            removed[spec_index, sample_index] = cut
            geodesic_seed = geodesic_cavity_seed(
                raw[sample_index], fields["cutout_proposal"][sample_index, 0],
                fields["bank"][sample_index, 0], spec,
            )
            geodesic_index = len(specs) + spec_index
            if geodesic_seed is None:
                candidates[geodesic_index, sample_index] = path_prediction[sample_index]
            else:
                alternative_path = raw[sample_index].copy()
                alternative_path[geodesic_seed] = 0
                candidate, cut = local_graph_cut(
                    raw[sample_index], alternative_path,
                    fields["cutout_proposal"][sample_index, 0], fields["bank"][sample_index, 0], spec,
                )
                candidates[geodesic_index, sample_index] = candidate
                removed[geodesic_index, sample_index] = cut
            peak_seed = geodesic_peak_seed(
                raw[sample_index], fields["cutout_proposal"][sample_index, 0],
                fields["bank"][sample_index, 0], spec,
            )
            peak_index = 2 * len(specs) + spec_index
            if peak_seed is None:
                candidates[peak_index, sample_index] = path_prediction[sample_index]
                continue
            peak_path = raw[sample_index].copy()
            peak_path[peak_seed] = 0
            candidate, cut = local_graph_cut(
                raw[sample_index], peak_path,
                fields["cutout_proposal"][sample_index, 0], fields["bank"][sample_index, 0], spec,
            )
            candidates[peak_index, sample_index] = candidate
            removed[peak_index, sample_index] = cut
    return candidates, removed


def infer_split(
    archive: np.lib.npyio.NpzFile,
    arrays: object,
    indices: np.ndarray,
    conservative_model: torch.nn.Module,
    aggressive_model: torch.nn.Module,
    action_model: torch.nn.Module,
    feature_mean: np.ndarray,
    feature_scale: np.ndarray,
    coarse: torch.nn.Module,
    competitive_model: torch.nn.Module,
    adapter: InputAdapter,
    device: torch.device,
    batch_size: int,
    path_parameters: dict[str, object],
    source: int,
) -> tuple[np.ndarray, np.ndarray, dict[str, np.ndarray], list[dict[str, object]]]:
    conservative, aggressive = infer_pair(
        conservative_model, aggressive_model, adapter,
        archive["linear_images"][indices], archive["voltages"][indices], device, batch_size,
    )
    raw = blend(conservative, aggressive, 0.5)
    path, accepted = infer_path_prediction(
        action_model, feature_mean, feature_scale, archive["linear_images"][indices], raw,
        conservative, aggressive, device, float(path_parameters["threshold"]),
        float(path_parameters["width_bonus"]), bool(path_parameters["fallback_path"]),
    )
    loader = DataLoader(StructuralDataset(arrays, indices, source), batch_size=batch_size, shuffle=False)
    fields = collect_fields(coarse, competitive_model, adapter, loader, device)
    return raw, path, fields, accepted


def evaluate_base(
    archive: np.lib.npyio.NpzFile, indices: np.ndarray, prediction: np.ndarray
) -> dict[str, float]:
    return standard_metrics(archive["labels"][indices], prediction, archive["indentation_masks"][indices])


def tune_physics_gate(
    base: np.lib.npyio.NpzFile,
    stress: np.lib.npyio.NpzFile,
    base_indices: np.ndarray,
    stress_indices: np.ndarray,
    base_path: np.ndarray,
    stress_path: np.ndarray,
    base_candidates: np.ndarray,
    stress_candidates: np.ndarray,
) -> tuple[dict[str, object], list[dict[str, object]]]:
    print("computing validation measurement residuals", flush=True)
    base_residuals, base_changes, base_folds = candidate_physics(
        base_path, base_candidates, base["voltages"][base_indices], base, return_folds=True
    )
    stress_residuals, stress_changes, stress_folds = candidate_physics(
        stress_path, stress_candidates, stress["voltages"][stress_indices], stress, return_folds=True
    )
    base_removal, base_holes = candidate_geometry_risks(base_path, base_candidates)
    stress_removal, stress_holes = candidate_geometry_risks(stress_path, stress_candidates)
    base_reference = evaluate_base(base, base_indices, base_path)
    stress_reference, _ = core_metrics(stress, stress_indices, stress_path)
    rows: list[dict[str, object]] = []
    for penalty in (0.0, 0.03, 0.10, 0.30, 1.0):
        for min_gain in (0.0, 0.0001, 0.0003, 0.001, 0.003):
            for max_removal in (0.08, 0.12, 0.16, 0.20):
                for agreement in (0.50, 0.75, 1.00):
                    base_selected = choose_indices(
                        base_residuals, base_changes, penalty, min_gain,
                        base_removal, base_holes, max_removal, base_folds, agreement,
                    )
                    stress_selected = choose_indices(
                        stress_residuals, stress_changes, penalty, min_gain,
                        stress_removal, stress_holes, max_removal, stress_folds, agreement,
                    )
                    base_prediction = gather_candidates(base_path, base_candidates, base_selected)
                    stress_prediction = gather_candidates(stress_path, stress_candidates, stress_selected)
                    base_metric = evaluate_base(base, base_indices, base_prediction)
                    stress_metric, _ = core_metrics(stress, stress_indices, stress_prediction)
                    eligible = (
                        base_metric["foreground_iou"] >= base_reference["foreground_iou"] - 0.004
                        and stress_metric["foreground_iou"] >= stress_reference["foreground_iou"] - 0.006
                        and stress_metric["bank_retention"] >= stress_reference["bank_retention"] - 0.008
                    )
                    score = (
                        0.08 * base_metric["foreground_iou"]
                        + 0.12 * stress_metric["foreground_iou"]
                        + 0.34 * stress_metric["open_deep_cutout_recovery"]
                        + 0.18 * stress_metric["bank_retention"]
                        + 0.28 * stress_metric["topology_structural_joint"]
                    )
                    rows.append({
                        "penalty": penalty, "min_gain": min_gain,
                        "max_component_removal": max_removal, "min_fold_agreement": agreement,
                        "eligible": bool(eligible), "score": float(score),
                        "base": base_metric, "stress_core": stress_metric,
                        "base_changed_cases": int(np.count_nonzero(base_selected)),
                        "stress_changed_cases": int(np.count_nonzero(stress_selected)),
                    })
    eligible_rows = [row for row in rows if row["eligible"]]
    if not eligible_rows:
        selected = {
            "penalty": 0.0,
            "min_gain": float("inf"),
            "max_component_removal": 0.0,
            "min_fold_agreement": 1.0,
            "eligible": False,
            "safe_fallback": True,
            "score": float("-inf"),
            "base": base_reference,
            "stress_core": stress_reference,
            "base_changed_cases": 0,
            "stress_changed_cases": 0,
        }
    else:
        selected = max(eligible_rows, key=lambda row: float(row["score"]))
        selected["safe_fallback"] = False
    return selected, rows


def select_with_gate(
    archive: np.lib.npyio.NpzFile,
    voltages: np.ndarray,
    baseline: np.ndarray,
    candidates: np.ndarray,
    gate: dict[str, object],
) -> tuple[np.ndarray, np.ndarray, dict[str, np.ndarray]]:
    residuals, changes, folds = candidate_physics(baseline, candidates, voltages, archive, return_folds=True)
    removal, holes = candidate_geometry_risks(baseline, candidates)
    if bool(gate.get("safe_fallback", False)):
        selected = np.zeros(len(baseline), dtype=np.int64)
    else:
        selected = choose_indices(
            residuals, changes, float(gate["penalty"]), float(gate["min_gain"]),
            removal, holes, float(gate["max_component_removal"]), folds,
            float(gate["min_fold_agreement"]),
        )
    return gather_candidates(baseline, candidates, selected), selected, {
        "residuals": residuals, "changes": changes, "fold_residuals": folds,
        "component_removal": removal, "new_hole_pixels": holes,
    }


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    keys = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def save_stress_montage(
    path: Path,
    stress: np.lib.npyio.NpzFile,
    indices: np.ndarray,
    raw: np.ndarray,
    guarded: np.ndarray,
    graphcut: np.ndarray,
    selected: np.ndarray,
) -> None:
    family_codes = stress["family_codes"][indices]
    focus: list[int] = []
    for code in CORE_FAMILY_CODES:
        family = np.flatnonzero(family_codes == code)
        score = stress["cutout_depth_weights"][indices][family].sum(axis=(1, 2))
        focus.append(int(family[int(np.argmax(score))]))
    figure, axes = plt.subplots(len(focus), 5, figsize=(12.6, 2.32 * len(focus)), squeeze=False)
    for row, index in enumerate(focus):
        change = (guarded[index] != graphcut[index]).astype(np.uint8)
        items = (
            (stress["labels"][indices][index], "truth", "viridis", 0, 2),
            (raw[index], "stable raw", "viridis", 0, 2),
            (guarded[index], "guarded path", "viridis", 0, 2),
            (graphcut[index], f"local graph cut\nchoice={selected[index]}", "viridis", 0, 2),
            (change, "newly removed", "magma", 0, 1),
        )
        for column, (image, title, cmap, vmin, vmax) in enumerate(items):
            axes[row, column].imshow(image, cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest")
            axes[row, column].set_axis_off()
            if row == 0:
                axes[row, column].set_title(title, fontsize=9)
        axes[row, 0].set_ylabel(FAMILIES[int(family_codes[index])], fontsize=9)
    figure.suptitle("Path-conditioned local graph cut for inward EIT boundaries")
    figure.tight_layout()
    figure.savefig(path, dpi=190)
    plt.close(figure)


def save_public_montage(
    path: Path,
    truths: np.ndarray,
    ids: np.ndarray,
    raw: np.ndarray,
    guarded: np.ndarray,
    graphcut: np.ndarray,
    selected: np.ndarray,
) -> None:
    focus = [index for index, case_id in enumerate(ids) if str(case_id) in PUBLIC_INWARD_IDS]
    figure, axes = plt.subplots(len(focus), 5, figsize=(12.6, 2.35 * len(focus)), squeeze=False)
    for row, index in enumerate(focus):
        change = (guarded[index] != graphcut[index]).astype(np.uint8)
        items = (
            (truths[index], "truth", "viridis", 0, 2),
            (raw[index], "stable raw", "viridis", 0, 2),
            (guarded[index], "guarded path", "viridis", 0, 2),
            (graphcut[index], f"local graph cut\nchoice={selected[index]}", "viridis", 0, 2),
            (change, "newly removed", "magma", 0, 1),
        )
        for column, (image, title, cmap, vmin, vmax) in enumerate(items):
            axes[row, column].imshow(image, cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest")
            axes[row, column].set_axis_off()
            if row == 0:
                axes[row, column].set_title(title, fontsize=9)
        axes[row, 0].set_ylabel(str(ids[index]), fontsize=9)
    figure.suptitle("Public KTC2023 inward-notch cases: frozen synthetic-selected graph cut")
    figure.tight_layout()
    figure.savefig(path, dpi=185)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    base = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    base_arrays = prepare_structural_arrays(base, "base nonlinear CEM")
    stress_arrays = prepare_structural_arrays(stress, "deep-concavity stress")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    adapter = InputAdapter(base["fov_mask"]).to(device)

    conservative_model = load_model(args.conservative, device)
    aggressive_model = load_model(args.aggressive, device)
    action_model, feature_mean, feature_scale = load_action_model(args.action_checkpoint, device)
    path_parameters = json.loads(args.path_summary.resolve().read_text(encoding="utf-8"))["selected"]
    coarse, _, _ = load_coarse_ensemble(args.coarse_checkpoint, args.coarse_weights, device)
    competitive_model = load_competitive_model(args.competitive_checkpoint, device)

    base_validation = np.asarray(base["validation_indices"], dtype=np.int64)
    stress_validation = np.asarray(stress["validation_indices"], dtype=np.int64)
    print("inferring synthetic validation fields", flush=True)
    base_raw, base_path, base_fields, _ = infer_split(
        base, base_arrays, base_validation, conservative_model, aggressive_model,
        action_model, feature_mean, feature_scale, coarse, competitive_model,
        adapter, device, args.batch_size, path_parameters, 0,
    )
    stress_raw, stress_path, stress_fields, _ = infer_split(
        stress, stress_arrays, stress_validation, conservative_model, aggressive_model,
        action_model, feature_mean, feature_scale, coarse, competitive_model,
        adapter, device, args.batch_size, path_parameters, 1,
    )
    base_candidates, _ = graph_cut_candidates(base_raw, base_path, base_fields)
    stress_candidates, _ = graph_cut_candidates(stress_raw, stress_path, stress_fields)
    gate, gate_grid = tune_physics_gate(
        base, stress, base_validation, stress_validation,
        base_path, stress_path, base_candidates, stress_candidates,
    )
    (output_dir / "validation_gate_grid.json").write_text(json.dumps(gate_grid, indent=2), encoding="utf-8")
    print(f"selected graph-cut physics gate: {json.dumps(gate)}", flush=True)

    # Evaluation labels remain untouched until the complete gate is frozen above.
    base_test = np.asarray(base["test_indices"], dtype=np.int64)
    stress_test = np.asarray(stress["test_indices"], dtype=np.int64)
    print("inferring frozen synthetic test fields", flush=True)
    base_raw, base_path, base_fields, accepted_base = infer_split(
        base, base_arrays, base_test, conservative_model, aggressive_model,
        action_model, feature_mean, feature_scale, coarse, competitive_model,
        adapter, device, args.batch_size, path_parameters, 0,
    )
    stress_raw, stress_path, stress_fields, accepted_stress = infer_split(
        stress, stress_arrays, stress_test, conservative_model, aggressive_model,
        action_model, feature_mean, feature_scale, coarse, competitive_model,
        adapter, device, args.batch_size, path_parameters, 1,
    )
    base_candidates, _ = graph_cut_candidates(base_raw, base_path, base_fields)
    stress_candidates, _ = graph_cut_candidates(stress_raw, stress_path, stress_fields)
    base_graphcut, base_selected, base_physics = select_with_gate(
        base, base["voltages"][base_test], base_path, base_candidates, gate
    )
    stress_graphcut, stress_selected, stress_physics = select_with_gate(
        stress, stress["voltages"][stress_test], stress_path, stress_candidates, gate
    )

    base_summary = {
        name: evaluate_base(base, base_test, prediction)
        for name, prediction in (("stable_raw", base_raw), ("guarded_path", base_path), ("local_graphcut", base_graphcut))
    }
    stress_summary: dict[str, dict[str, float]] = {}
    stress_family: dict[str, object] = {}
    core_rows: dict[str, list[dict[str, float]]] = {}
    for name, prediction in (("stable_raw", stress_raw), ("guarded_path", stress_path), ("local_graphcut", stress_graphcut)):
        stress_summary[name], stress_family[name], _ = stress_metrics(
            stress["labels"][stress_test], prediction, stress["cutout_masks"][stress_test],
            stress["cutout_depth_weights"][stress_test], stress["family_codes"][stress_test],
        )
        _, core_rows[name] = core_metrics(stress, stress_test, prediction)
    core_summary = {
        name: core_metrics(stress, stress_test, prediction)[0]
        for name, prediction in (("stable_raw", stress_raw), ("guarded_path", stress_path), ("local_graphcut", stress_graphcut))
    }
    bootstrap = paired_bootstrap(
        core_rows["guarded_path"], core_rows["local_graphcut"], args.bootstrap_samples, args.seed
    )

    print("inferring 21 public KTC2023 cases", flush=True)
    real_conservative, real_aggressive = infer_pair(
        conservative_model, aggressive_model, adapter,
        base["real_linear_images"], base["real_voltages"], device, args.batch_size, 256,
    )
    real_raw = blend(real_conservative, real_aggressive, 0.5)
    real_images = zoom(base["real_linear_images"], (1.0, 4.0, 4.0), order=1)
    real_path, accepted_real = infer_path_prediction(
        action_model, feature_mean, feature_scale, real_images, real_raw,
        real_conservative, real_aggressive, device, float(path_parameters["threshold"]),
        float(path_parameters["width_bonus"]), bool(path_parameters["fallback_path"]), scale=4,
    )
    real_fields = infer_real_fields(
        coarse, competitive_model, adapter, base["real_linear_images"], base["real_voltages"],
        device, args.batch_size,
    )
    real_specs = tuple(
        GraphCutSpec(
            spec.name, spec.radius * 4, spec.cutout_bias,
            spec.bank_weight, spec.smoothness, spec.hard_bank,
        )
        for spec in GRAPH_SPECS
    )
    real_candidates, _ = graph_cut_candidates(real_raw, real_path, real_fields, real_specs)
    # Shape optimization is performed at 256 x 256.  The public Jacobian maps
    # the 64 x 64 raster, so candidate selection uses nearest-neighbour 64 x 64
    # copies and transfers the selected candidate index back to full resolution.
    real_path64 = zoom(real_path, (1.0, 0.25, 0.25), order=0).astype(np.uint8)
    real_candidates64 = zoom(real_candidates, (1.0, 1.0, 0.25, 0.25), order=0).astype(np.uint8)
    _, real_selected, real_physics = select_with_gate(
        base, base["real_voltages"], real_path64, real_candidates64, gate
    )
    real_graphcut = gather_candidates(real_path, real_candidates, real_selected)
    real_summary: dict[str, dict[str, float]] = {}
    real_rows: list[dict[str, object]] = []
    for name, prediction in (("stable_raw", real_raw), ("guarded_path", real_path), ("local_graphcut", real_graphcut)):
        real_summary[name], rows = evaluate_real_predictions(name, prediction, base["real_labels"], base["real_ids"])
        real_rows.extend(rows)
    inward_summary = {
        name: aggregate_rows([
            {key: float(value) for key, value in row.items() if key not in ("id", "method")}
            for row in real_rows if row["method"] == name and str(row["id"]) in PUBLIC_INWARD_IDS
        ])
        for name in ("stable_raw", "guarded_path", "local_graphcut")
    }

    save_stress_montage(
        output_dir / "stress_core_graphcut_comparison.png", stress, stress_test,
        stress_raw, stress_path, stress_graphcut, stress_selected,
    )
    save_public_montage(
        output_dir / "public_inward_graphcut_comparison.png", base["real_labels"], base["real_ids"],
        real_raw, real_path, real_graphcut, real_selected,
    )
    case_rows: list[dict[str, object]] = []
    for position, dataset_index in enumerate(stress_test):
        case_rows.append({
            "dataset_index": int(dataset_index),
            "family": FAMILIES[int(stress["family_codes"][dataset_index])],
            "candidate_choice": int(stress_selected[position]),
            "changed_pixels": int(np.count_nonzero(stress_graphcut[position] != stress_path[position])),
            "physics_ratio": float(
                stress_physics["residuals"][int(stress_selected[position]), position]
                / max(stress_physics["residuals"][0, position], 1e-12)
            ),
        })
    write_csv(output_dir / "stress_case_choices.csv", case_rows)
    write_csv(output_dir / "real_case_metrics.csv", real_rows)
    write_csv(output_dir / "paired_bootstrap_core.csv", bootstrap)
    np.savez_compressed(
        output_dir / "predictions.npz",
        base_test_indices=base_test, base_raw=base_raw, base_path=base_path,
        base_graphcut=base_graphcut, base_selected=base_selected,
        stress_test_indices=stress_test, stress_raw=stress_raw, stress_path=stress_path,
        stress_graphcut=stress_graphcut, stress_selected=stress_selected,
        real_raw=real_raw, real_path=real_path, real_graphcut=real_graphcut,
        real_selected=real_selected,
    )
    result = {
        "method": "path-conditioned local graph cut with bank protection and EIT measurement selection",
        "graph_specs": [asdict(spec) for spec in GRAPH_SPECS],
        "candidate_names": list(CANDIDATE_NAMES),
        "selected_on_synthetic_validation": gate,
        "path_decoder_selected_on_synthetic_validation": path_parameters,
        "test": {
            "base": base_summary,
            "stress_all": stress_summary,
            "stress_core_inward_families": core_summary,
            "stress_by_family": stress_family,
            "paired_bootstrap_guarded_path_to_graphcut": bootstrap,
            "accepted_path_actions": {
                "base": len(accepted_base), "stress": len(accepted_stress), "real": len(accepted_real),
            },
            "physics_selected": {
                "base": int(np.count_nonzero(base_selected)),
                "stress": int(np.count_nonzero(stress_selected)),
                "real": int(np.count_nonzero(real_selected)),
            },
            "real_all_21": real_summary,
            "real_inward_subset": {"ids": list(PUBLIC_INWARD_IDS), "metrics": inward_summary},
        },
        "core_inward_families": [FAMILIES[code] for code in CORE_FAMILY_CODES],
        "excluded_as_primary_targets": [FAMILIES[5], FAMILIES[7]],
        "evaluation_truth_used_for_selection": False,
        "device": str(device),
        "args": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
    }
    (output_dir / "summary.json").write_text(json.dumps(result, indent=2, default=str), encoding="utf-8")
    print(json.dumps({"selected": gate, "test": result["test"]}, indent=2, default=str), flush=True)


if __name__ == "__main__":
    main()
