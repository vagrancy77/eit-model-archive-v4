"""Evaluate the frozen corrected-v6 model on the four KTC2023-ABC2 cases.

This is an inference-only bridge between the original ABC2 ``data1.mat`` to
``data4.mat`` files and the corrected v6 local-topology pipeline.  It uses the
same reference voltage, ridge reconstruction operator, four frozen v4/v6
seeds, and validation-calibrated risk rules already used by the v6 experiment.
No ABC2 truth is used for model, gate, or threshold selection.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import scipy.io as sio
import torch
import torch.nn.functional as F
from PIL import Image
from torch.utils.data import DataLoader


ROOT = Path(__file__).resolve().parents[1]
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import train_local_topology_corrector_v6 as v6
from score_ktc2023_outputs import ktc_score_fft


DEFAULT_REPO = ROOT / "external" / "KTC2023-ABC2"
DEFAULT_BASE = ROOT / "datasets" / "ktc_shape_nonlinear_v1.npz"
DEFAULT_OLD = ROOT / "outputs" / "ktc2023_abc2_final"
DEFAULT_OUTPUT = ROOT / "outputs" / "ktc2023_abc2_v6_final"
DEFAULT_SEEDS = (20260911, 20260912, 20260913, 20260914)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=DEFAULT_REPO)
    parser.add_argument("--base-dataset", type=Path, default=DEFAULT_BASE)
    parser.add_argument("--old-output", type=Path, default=DEFAULT_OLD)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--seeds", nargs="+", type=int, default=list(DEFAULT_SEEDS))
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--device", choices=("auto", "cuda", "cpu"), default="auto")
    return parser.parse_args()


def choose_device(name: str) -> torch.device:
    if name == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    device = torch.device(name)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable")
    return device


def labels_from_png(path: Path) -> np.ndarray:
    image = np.asarray(Image.open(path), dtype=np.float32)
    return np.rint(image * 2.0 / 255.0).astype(np.uint8)


def labels_to_png(labels: np.ndarray, path: Path) -> None:
    image = np.rint(np.asarray(labels, dtype=np.float32) * 255.0 / 2.0)
    Image.fromarray(np.clip(image, 0, 255).astype(np.uint8), mode="L").save(path)


def overlap_metrics(truth: np.ndarray, prediction: np.ndarray) -> dict[str, float]:
    truth = np.asarray(truth, dtype=np.int64)
    prediction = np.asarray(prediction, dtype=np.int64)
    result: dict[str, float] = {"pixel_accuracy": float(np.mean(truth == prediction))}
    ious: list[float] = []
    dices: list[float] = []
    for label in (1, 2):
        target = truth == label
        estimate = prediction == label
        intersection = float(np.logical_and(target, estimate).sum())
        union = float(np.logical_or(target, estimate).sum())
        denominator = float(target.sum() + estimate.sum())
        iou = intersection / union if union else 1.0
        dice = 2.0 * intersection / denominator if denominator else 1.0
        result[f"class{label}_iou"] = iou
        result[f"class{label}_dice"] = dice
        ious.append(iou)
        dices.append(dice)
    result["mean_iou"] = float(np.mean(ious))
    result["mean_dice"] = float(np.mean(dices))
    result["ktc_ssim"] = float(ktc_score_fft(truth, prediction))
    return result


def load_abc2_inputs(
    repo_root: Path, base_archive: np.lib.npyio.NpzFile
) -> tuple[np.ndarray, np.ndarray, np.ndarray, list[str]]:
    """Convert the four official ABC2 measurements to v6's public-input format."""
    reference_path = repo_root / "utils" / "reference_files" / "ref.mat"
    reference = np.asarray(sio.loadmat(reference_path)["Uelref"]).reshape(-1)
    operator = np.asarray(base_archive["reconstruction_operator"], dtype=np.float32)
    raw_pixel_to_node = np.asarray(base_archive["raw_pixel_to_node"], dtype=np.int64)
    voltages: list[np.ndarray] = []
    images: list[np.ndarray] = []
    truths: list[np.ndarray] = []
    ids: list[str] = []
    for number in range(1, 5):
        measured = np.asarray(
            sio.loadmat(repo_root / "inputs" / f"data{number}.mat")["Uel"]
        ).reshape(-1)
        voltage = (2.0 * (measured - reference)).astype(np.float32)
        nodes = voltage @ operator.T
        raw = nodes[raw_pixel_to_node].reshape(64, 64)
        image = np.flip(raw, axis=0).astype(np.float32)
        truth = np.asarray(
            sio.loadmat(repo_root / "groundTruths" / f"true{number}.mat")["truth"],
            dtype=np.uint8,
        )
        voltages.append(voltage)
        images.append(image)
        truths.append(truth)
        ids.append(f"data{number}")
    return np.stack(images), np.stack(voltages), np.stack(truths), ids


def load_corrector(path: Path, device: torch.device) -> v6.LocalTopologyCorrectorV6:
    state = torch.load(path, map_location=device, weights_only=False)
    model = v6.LocalTopologyCorrectorV6(
        input_channels=int(state.get("input_channels", 15)),
        base_channels=int(state.get("base_channels", 24)),
        enforce_connectivity=bool(state.get("enforce_connectivity", True)),
    ).to(device)
    model.load_state_dict(state["model"])
    model.eval()
    return model


def run_seed(
    seed: int,
    images: np.ndarray,
    voltages: np.ndarray,
    truths: np.ndarray,
    base_archive: np.lib.npyio.NpzFile,
    output_dir: Path,
    batch_size: int,
    device: torch.device,
) -> tuple[list[dict[str, Any]], dict[str, np.ndarray]]:
    seed_dir = ROOT.parent / f"topology_local_eit_v6_corrected_seed_{seed}"
    summary_path = seed_dir / "v6_summary.json"
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    checkpoint = Path(summary["checkpoint_v4"])
    if not checkpoint.is_absolute():
        checkpoint = ROOT.parent / checkpoint
    router_path = ROOT.parent / f"topology_risk_eit_v4_router_seed_{seed}" / "action_router_summary.json"
    if not router_path.exists():
        router_path = ROOT.parent / "topology_risk_eit_v4_full" / "action_router_summary.json"
    router = json.loads(router_path.read_text(encoding="utf-8"))
    prepared = v6.data_tools.prepare_arrays(base_archive, "base")
    v4_model, _ = v6.load_v4(checkpoint, prepared.fov_mask, device)
    dataset = v6.PublicInputDataset(images, voltages)
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False, pin_memory=device.type == "cuda")
    cache_dir = output_dir / f"seed_{seed}" / "v4_cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache_path = cache_dir / "abc2_public.npz"
    jacobian = torch.from_numpy(np.asarray(base_archive["jacobian"], dtype=np.float32)).to(device)
    mapping = torch.from_numpy(np.asarray(base_archive["node_to_raw_pixel"], dtype=np.int64)).to(device)
    v6.write_cache(
        cache_path,
        v4_model,
        loader,
        device,
        float(router["threshold"]),
        jacobian,
        mapping,
    )
    del v4_model
    if device.type == "cuda":
        torch.cuda.empty_cache()

    corrector = load_corrector(seed_dir / "local_corrector_v6_best.pt", device)
    gate_state = torch.load(seed_dir / "dual_risk_gate_v6_best.pt", map_location=device, weights_only=False)
    gate = v6.DualRiskQuantileGate(input_features=len(gate_state["feature_names"])).to(device)
    gate.load_state_dict(gate_state["model"])
    gate.eval()
    feature_mean = np.asarray(gate_state["feature_mean"], dtype=np.float32)
    feature_std = np.asarray(gate_state["feature_std"], dtype=np.float32)
    cache = np.load(cache_path, allow_pickle=False)
    anchor_all = np.asarray(cache["anchor_probabilities"], dtype=np.float32)
    maps_all = np.asarray(cache["v4_maps"], dtype=np.float32)
    gate_all = np.asarray(cache["v4_gate"], dtype=np.float32)
    route_all = np.asarray(cache["v4_route_enabled"], dtype=np.float32)
    fov = torch.from_numpy(prepared.fov_mask.astype(np.float32))[None, None].to(device)
    rows: list[dict[str, Any]] = []
    predictions: dict[str, np.ndarray] = {"anchor": [], "candidate": [], "gated": []}
    risk_chunks: list[np.ndarray] = []
    selected_chunks: list[np.ndarray] = []
    for start in range(0, len(images), batch_size):
        stop = min(len(images), start + batch_size)
        anchor = torch.from_numpy(anchor_all[start:stop]).to(device)
        maps = torch.from_numpy(maps_all[start:stop]).to(device)
        image = torch.from_numpy(images[start:stop, None]).to(device)
        output = corrector(v6.build_features(anchor, maps, image, fov), anchor, fov)
        features = v6.extract_gate_features(
            output,
            anchor,
            maps,
            image,
            torch.from_numpy(gate_all[start:stop]).to(device),
            torch.from_numpy(route_all[start:stop]).to(device),
            fov,
        )
        risk = v6.risk_predictions(
            gate, features.detach().cpu().numpy(), feature_mean, feature_std, device
        )
        selected = v6.apply_gate(risk, summary["gate_rule"])
        anchor_pred = F.interpolate(anchor, (256, 256), mode="bilinear", align_corners=False).argmax(1).cpu().numpy().astype(np.uint8)
        candidate_pred = F.interpolate(output["candidate_probabilities"], (256, 256), mode="bilinear", align_corners=False).argmax(1).cpu().numpy().astype(np.uint8)
        gated_pred = np.where(selected[:, None, None], candidate_pred, anchor_pred).astype(np.uint8)
        predictions["anchor"].append(anchor_pred)
        predictions["candidate"].append(candidate_pred)
        predictions["gated"].append(gated_pred)
        risk_chunks.append(risk)
        selected_chunks.append(selected)

    predictions = {key: np.concatenate(value, axis=0) for key, value in predictions.items()}
    risks = np.concatenate(risk_chunks, axis=0)
    selected = np.concatenate(selected_chunks, axis=0)
    for index, case_id in enumerate(("data1", "data2", "data3", "data4")):
        truth = truths[index]
        notch = v6.indentation_mask(truth)
        anchor_topology, candidate_topology = v6.metric_pair(
            truth, notch, predictions["anchor"][index], predictions["candidate"][index]
        )
        gated_topology = candidate_topology if selected[index] else anchor_topology
        metrics = {
            "anchor": {**anchor_topology, **overlap_metrics(truth, predictions["anchor"][index])},
            "candidate": {**candidate_topology, **overlap_metrics(truth, predictions["candidate"][index])},
            "gated": {**gated_topology, **overlap_metrics(truth, predictions["gated"][index])},
        }
        for method, values in metrics.items():
            rows.append(
                {
                    "seed": seed,
                    "case": case_id,
                    "method": method,
                    "gate_selected": int(selected[index]),
                    "predicted_benefit_q20": float(risks[index, 0, 0]),
                    "predicted_iou_loss_q80": float(risks[index, 1, 2]),
                    "predicted_bank_loss_q80": float(risks[index, 2, 2]),
                    **values,
                }
            )
        labels_to_png(predictions["gated"][index], output_dir / f"seed_{seed}_{case_id}_gated.png")
    np.savez_compressed(
        output_dir / f"seed_{seed}_predictions.npz",
        truth=truths,
        anchor=predictions["anchor"],
        candidate=predictions["candidate"],
        gated=predictions["gated"],
        selected=selected,
        risks=risks,
    )
    return rows, predictions


def write_rows(path: Path, rows: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def aggregate_v6_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for row in rows:
        grouped.setdefault((str(row["case"]), str(row["method"])), []).append(row)
    metric_names = (
        "mean_iou",
        "mean_dice",
        "ktc_ssim",
        "pixel_accuracy",
        "foreground_iou",
        "notch_preservation",
        "bank_retention",
    )
    aggregates: list[dict[str, Any]] = []
    for (case, method), values in sorted(grouped.items()):
        item: dict[str, Any] = {"case": case, "method": method, "seeds": len(values)}
        for metric in metric_names:
            numeric = np.asarray([float(value[metric]) for value in values], dtype=np.float64)
            item[f"{metric}_mean"] = float(numeric.mean())
            item[f"{metric}_std"] = float(numeric.std())
        item["gate_selected_fraction"] = float(
            np.mean([int(value["gate_selected"]) for value in values])
        )
        aggregates.append(item)
    return aggregates


def write_montage(
    path: Path,
    repo_root: Path,
    old_output: Path,
    old_case_dirs: dict[str, Path],
    truths: np.ndarray,
    predictions: dict[str, np.ndarray],
) -> None:
    titles = ("Truth", "Old DIP+TV", "v6 anchor", "v6 candidate", "v6 gated")
    figure, axes = plt.subplots(4, 5, figsize=(16, 13), squeeze=False)
    for index in range(4):
        case_id = f"data{index + 1}"
        old_path = old_output / f"{case_id}.png"
        if not old_path.exists():
            old_path = old_case_dirs[case_id] / f"{case_id}.png"
        if not old_path.exists():
            # The bundled author image is still useful as a visual fallback,
            # but metrics below always use the reproduced local runs.
            old_path = repo_root / "outputs" / f"{case_id}.png"
        old = labels_from_png(old_path)
        images = (truths[index], old, predictions["anchor"][index], predictions["candidate"][index], predictions["gated"][index])
        for column, image in enumerate(images):
            axes[index, column].imshow(image, cmap="viridis", vmin=0, vmax=2, interpolation="nearest")
            axes[index, column].set_axis_off()
            if index == 0:
                axes[index, column].set_title(titles[column])
        axes[index, 0].set_ylabel(f"data{index + 1}", fontsize=12)
    figure.suptitle("KTC2023-ABC2: old DIP+TV versus corrected v6 (representative seed)", fontsize=15)
    figure.tight_layout(rect=(0, 0, 1, 0.97))
    figure.savefig(path, dpi=220)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    device = choose_device(args.device)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    base_archive = np.load(args.base_dataset.resolve(), allow_pickle=False)
    images, voltages, truths, ids = load_abc2_inputs(args.repo_root.resolve(), base_archive)
    all_rows: list[dict[str, Any]] = []
    per_seed_predictions: dict[int, dict[str, np.ndarray]] = {}
    print(f"device={device}; cases={ids}; seeds={args.seeds}", flush=True)
    for seed in args.seeds:
        print(f"evaluating corrected v6 seed {seed}", flush=True)
        rows, predictions = run_seed(
            seed, images, voltages, truths, base_archive, output_dir, args.batch_size, device
        )
        all_rows.extend(rows)
        per_seed_predictions[seed] = predictions
    write_rows(output_dir / "v6_abc2_case_metrics.csv", all_rows)

    old_summary = json.loads((args.old_output / "final_summary.json").read_text(encoding="utf-8"))
    old_ssim = old_summary.get("reproduced_ktc_ssim", [])
    old_rows: list[dict[str, Any]] = []
    for index, case in enumerate(old_summary["cases"]):
        old_rows.append(
            {
                "case": Path(case["input"]).stem,
                "method": "old_reproduced_DIP_TV",
                **case["reproduced_metrics"],
                "ktc_ssim": float(old_ssim[index]) if index < len(old_ssim) else None,
            }
        )
    old_case_dirs = {
        "data1": args.old_output.parent / "ktc2023_abc2_3000_data1",
        "data2": args.old_output.parent / "ktc2023_abc2_3000_data2_seed1235",
        "data3": args.old_output.parent / "ktc2023_abc2_3000_data3_data4",
        "data4": args.old_output.parent / "ktc2023_abc2_3000_data3_data4",
    }
    representatives = per_seed_predictions[args.seeds[0]]
    write_montage(
        output_dir / "v6_abc2_comparison.png",
        args.repo_root.resolve(),
        args.old_output.resolve(),
        old_case_dirs,
        truths,
        representatives,
    )
    summary: dict[str, Any] = {
        "method": "corrected v6 frozen inference on original KTC2023-ABC2 four cases",
        "device": str(device),
        "seeds": args.seeds,
        "data": [str(args.repo_root.resolve() / "inputs" / f"data{i}.mat") for i in range(1, 5)],
        "truth": [str(args.repo_root.resolve() / "groundTruths" / f"true{i}.mat") for i in range(1, 5)],
        "old_reproduction": old_rows,
        "v6_case_rows": all_rows,
        "v6_case_aggregates": aggregate_v6_rows(all_rows),
        "representative_seed_for_figure": args.seeds[0],
    }
    (output_dir / "v6_abc2_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps({"output_dir": str(output_dir), "rows": len(all_rows)}, indent=2), flush=True)


if __name__ == "__main__":
    main()
