"""Evaluate frozen topology EIT models under synchronized measurement perturbations.

Every perturbed voltage vector is passed through the archived reconstruction
operator before inference, so the voltage and linear-image inputs remain
physically synchronized.  No perturbed result is used for model or router
selection.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
import zlib
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import evaluate_topology_residual_eit_v3 as evaluator
import train_topology_residual_eit_v3 as trainer
from pytorch_eit.topology_residual_net import TopologyResidualEITNet


CONDITIONS = (
    "native",
    "snr_40db",
    "snr_30db",
    "snr_20db",
    "gain_0p9",
    "gain_1p1",
    "dropout_0p05",
    "dropout_0p10",
)
METHODS = ("direct_base", "topology_residual", "topology_routed")
METRICS = (
    "foreground_iou",
    "foreground_dice",
    "boundary_f1",
    "notch_preservation",
    "bank_retention",
)


@dataclass
class Group:
    name: str
    ids: np.ndarray
    truth: np.ndarray
    cutout: np.ndarray
    voltage: np.ndarray
    native_image: np.ndarray
    fov: np.ndarray
    reconstruction_operator: np.ndarray
    raw_pixel_to_node: np.ndarray
    audited_concave: np.ndarray | None = None


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", nargs="+", required=True, help="seed=checkpoint")
    parser.add_argument("--routers", nargs="+", required=True, help="seed=router_directory_or_json")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--base-dataset", type=Path, default=ROOT / "datasets" / "ktc_shape_nonlinear_v1.npz"
    )
    parser.add_argument(
        "--biological-dataset", type=Path,
        default=ROOT / "datasets" / "ktc_biological_concavity_v1.npz",
    )
    parser.add_argument(
        "--stress-dataset", type=Path,
        default=ROOT / "datasets" / "ktc_deep_concavity_stress_v1.npz",
    )
    parser.add_argument(
        "--audit", type=Path,
        default=ROOT / "outputs" / "ktc2023_full_audit" / "summary.json",
    )
    parser.add_argument("--batch-size", type=int, default=28)
    parser.add_argument("--bootstrap", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260917)
    parser.add_argument("--device", choices=("auto", "cuda", "cpu"), default="auto")
    parser.add_argument("--max-cases", type=int, default=0, help="smoke-test cap per group")
    return parser.parse_args()


def parse_keyed(values: list[str]) -> dict[str, Path]:
    result: dict[str, Path] = {}
    for value in values:
        if "=" not in value:
            raise ValueError(f"expected seed=path, got {value!r}")
        key, raw_path = value.split("=", 1)
        if key in result:
            raise ValueError(f"duplicate seed {key}")
        result[key] = Path(raw_path).resolve()
    return result


def router_json(path: Path) -> Path:
    return path / "action_router_summary.json" if path.is_dir() else path


def load_groups(args: argparse.Namespace) -> dict[str, Group]:
    archives = {
        "base": np.load(args.base_dataset.resolve(), allow_pickle=False),
        "biological": np.load(args.biological_dataset.resolve(), allow_pickle=False),
        "stress": np.load(args.stress_dataset.resolve(), allow_pickle=False),
    }
    groups: dict[str, Group] = {}
    for name, archive in archives.items():
        indices = np.asarray(archive["test_indices"], dtype=np.int64)
        if args.max_cases > 0:
            indices = indices[: args.max_cases]
        labels = np.asarray(archive["labels"][indices], dtype=np.uint8)
        cutout_key = "cutout_masks" if "cutout_masks" in archive.files else "indentation_masks"
        groups[name] = Group(
            name=name,
            ids=np.asarray([f"{name}/{value}" for value in indices]),
            truth=labels,
            cutout=np.asarray(archive[cutout_key][indices], dtype=np.uint8),
            voltage=np.asarray(archive["voltages"][indices], dtype=np.float32),
            native_image=np.asarray(archive["linear_images"][indices], dtype=np.float32),
            fov=np.asarray(archive["fov_mask"], dtype=np.uint8),
            reconstruction_operator=np.asarray(archive["reconstruction_operator"], dtype=np.float32),
            raw_pixel_to_node=np.asarray(archive["raw_pixel_to_node"], dtype=np.int64),
        )

    base = archives["base"]
    public_truth = np.asarray(base["real_labels"], dtype=np.uint8)
    public_ids = np.asarray(base["real_ids"])
    if args.max_cases > 0:
        public_truth = public_truth[: args.max_cases]
        public_ids = public_ids[: args.max_cases]
    public_cutout = np.stack([evaluator.indentation_mask(value) for value in public_truth]).astype(np.uint8)
    audit = json.loads(args.audit.resolve().read_text(encoding="utf-8"))
    strict_ids = {str(value) for value in audit["nonconvex_ids"]}
    groups["public_ktc"] = Group(
        name="public_ktc",
        ids=public_ids,
        truth=public_truth,
        cutout=public_cutout,
        voltage=np.asarray(base["real_voltages"][: len(public_ids)], dtype=np.float32),
        native_image=np.asarray(base["real_linear_images"][: len(public_ids)], dtype=np.float32),
        fov=np.asarray(base["fov_mask"], dtype=np.uint8),
        reconstruction_operator=np.asarray(base["reconstruction_operator"], dtype=np.float32),
        raw_pixel_to_node=np.asarray(base["raw_pixel_to_node"], dtype=np.int64),
        audited_concave=np.asarray([str(value) in strict_ids for value in public_ids]),
    )
    return groups


def perturbations(group: Group, seed: int) -> dict[str, np.ndarray]:
    voltage = group.voltage
    rng = np.random.default_rng(seed + zlib.crc32(group.name.encode("utf-8")))
    standard_noise = rng.normal(size=voltage.shape).astype(np.float32)
    rms = np.sqrt(np.mean(voltage.astype(np.float64) ** 2, axis=1, keepdims=True)).astype(np.float32)
    scores = rng.random(size=voltage.shape)
    result = {"native": voltage.copy()}
    for snr in (40, 30, 20):
        result[f"snr_{snr}db"] = voltage + standard_noise * (rms / (10.0 ** (snr / 20.0)) + 1e-9)
    result["gain_0p9"] = 0.9 * voltage
    result["gain_1p1"] = 1.1 * voltage
    result["dropout_0p05"] = voltage * (scores >= 0.05)
    result["dropout_0p10"] = voltage * (scores >= 0.10)
    return {key: np.asarray(value, dtype=np.float32) for key, value in result.items()}


@torch.no_grad()
def reconstruct_images(
    voltage: np.ndarray,
    operator: np.ndarray,
    raw_pixel_to_node: np.ndarray,
    device: torch.device,
    batch_size: int = 512,
) -> np.ndarray:
    reconstruction = torch.from_numpy(operator).to(device)
    mapping = torch.from_numpy(raw_pixel_to_node).long().to(device)
    saved: list[np.ndarray] = []
    for start in range(0, len(voltage), batch_size):
        measured = torch.from_numpy(voltage[start : start + batch_size]).to(device)
        nodes = measured @ reconstruction.T
        raw = nodes[:, mapping].reshape(-1, 64, 64)
        saved.append(torch.flip(raw, dims=(1,)).cpu().numpy())
    return np.concatenate(saved).astype(np.float32)


def prepare_conditions(
    groups: dict[str, Group], device: torch.device, seed: int
) -> dict[str, dict[str, tuple[np.ndarray, np.ndarray]]]:
    result: dict[str, dict[str, tuple[np.ndarray, np.ndarray]]] = {}
    for name, group in groups.items():
        result[name] = {}
        for condition, voltage in perturbations(group, seed).items():
            image = (
                group.native_image.copy()
                if condition == "native"
                else reconstruct_images(
                    voltage, group.reconstruction_operator, group.raw_pixel_to_node, device
                )
            )
            result[name][condition] = (voltage, image)
    return result


def load_model(checkpoint: Path, fov: np.ndarray, device: torch.device) -> TopologyResidualEITNet:
    state = torch.load(checkpoint, map_location=device, weights_only=False)
    model = TopologyResidualEITNet(
        fov,
        base=int(state["base_channels"]),
        propagation_steps=int(state.get("propagation_steps", 14)),
        risk_aware=bool(state.get("risk_aware", False)),
    ).to(device)
    model.load_state_dict(state["model"])
    model.eval()
    return model


@torch.no_grad()
def infer(
    model: TopologyResidualEITNet,
    image: np.ndarray,
    voltage: np.ndarray,
    output_size: tuple[int, int],
    batch_size: int,
    device: torch.device,
) -> dict[str, np.ndarray]:
    saved: dict[str, list[np.ndarray]] = {
        "direct_base": [], "topology_residual": [], "case_gate": []
    }
    for start in range(0, len(image), batch_size):
        x = torch.from_numpy(image[start : start + batch_size, None]).to(device)
        v = torch.from_numpy(voltage[start : start + batch_size]).to(device)
        output = model(x, v)
        base = output["base_probabilities"]
        topology = output["probabilities"]
        if base.shape[-2:] != output_size:
            base = F.interpolate(base, output_size, mode="bilinear", align_corners=False)
            topology = F.interpolate(topology, output_size, mode="bilinear", align_corners=False)
        saved["direct_base"].append(base.argmax(dim=1).cpu().numpy().astype(np.uint8))
        saved["topology_residual"].append(
            topology.argmax(dim=1).cpu().numpy().astype(np.uint8)
        )
        saved["case_gate"].append(output["case_gate"][:, 0, 0, 0].cpu().numpy())
    return {key: np.concatenate(value) for key, value in saved.items()}


def append_case_rows(
    rows: list[dict[str, object]],
    seed: str,
    condition: str,
    group: Group,
    outputs: dict[str, np.ndarray],
    threshold: float,
) -> None:
    routed = np.where(
        outputs["case_gate"][:, None, None] >= threshold,
        outputs["topology_residual"],
        outputs["direct_base"],
    )
    predictions = {
        "direct_base": outputs["direct_base"],
        "topology_residual": outputs["topology_residual"],
        "topology_routed": routed,
    }
    for index, case_id in enumerate(group.ids):
        audited = (
            bool(group.audited_concave[index])
            if group.audited_concave is not None
            else bool(group.cutout[index].any())
        )
        for method, values in predictions.items():
            rows.append(
                {
                    "seed": seed,
                    "condition": condition,
                    "group": group.name,
                    "id": str(case_id),
                    "audited_concave": audited,
                    "method": method,
                    "case_gate": float(outputs["case_gate"][index]),
                    **trainer.case_metrics(group.truth[index], values[index], group.cutout[index]),
                }
            )


def hierarchical_bootstrap(
    differences: np.ndarray, repetitions: int, rng: np.random.Generator
) -> dict[str, object] | None:
    finite = np.isfinite(differences).all(axis=0)
    differences = differences[:, finite]
    if not differences.size:
        return None
    seed_count, case_count = differences.shape
    draws = np.empty(repetitions, dtype=np.float64)
    for start in range(0, repetitions, 1000):
        stop = min(start + 1000, repetitions)
        count = stop - start
        seed_draws = rng.integers(seed_count, size=(count, seed_count))
        case_draws = rng.integers(case_count, size=(count, case_count))
        draws[start:stop] = differences[seed_draws[:, :, None], case_draws[:, None, :]].mean(
            axis=(1, 2)
        )
    return {
        "seed_count": seed_count,
        "case_count": case_count,
        "mean_difference": float(differences.mean()),
        "ci95_low": float(np.percentile(draws, 2.5)),
        "ci95_high": float(np.percentile(draws, 97.5)),
        "probability_positive": float(np.mean(draws > 0)),
        "per_seed_mean_differences": [float(value) for value in differences.mean(axis=1)],
    }


def row_lookup(rows: list[dict[str, object]]) -> dict[tuple[str, str, str, str, str], dict[str, object]]:
    return {
        (str(row["seed"]), str(row["condition"]), str(row["group"]), str(row["id"]), str(row["method"])): row
        for row in rows
    }


def summarize(
    rows: list[dict[str, object]], repetitions: int, seed: int
) -> dict[str, object]:
    seeds = sorted({str(row["seed"]) for row in rows})
    table = row_lookup(rows)
    rng = np.random.default_rng(seed)
    group_specs: dict[str, tuple[str, list[str]]] = {}
    reference = [
        row for row in rows
        if row["seed"] == seeds[0] and row["condition"] == "native" and row["method"] == "direct_base"
    ]
    for group in sorted({str(row["group"]) for row in reference}):
        selected = [row for row in reference if row["group"] == group]
        group_specs[f"{group}_all"] = (group, sorted(str(row["id"]) for row in selected))
        group_specs[f"{group}_concave"] = (
            group, sorted(str(row["id"]) for row in selected if bool(row["audited_concave"])),
        )
        group_specs[f"{group}_ordinary"] = (
            group, sorted(str(row["id"]) for row in selected if not bool(row["audited_concave"])),
        )
    group_specs = {key: value for key, value in group_specs.items() if value[1]}

    result: dict[str, object] = {}
    for group_name, (source, ids) in group_specs.items():
        condition_results: dict[str, object] = {}
        for condition in CONDITIONS:
            method_stats: dict[str, object] = {}
            matrices: dict[tuple[str, str], np.ndarray] = {}
            for method in METHODS:
                method_stats[method] = {}
                for metric in METRICS:
                    values = np.full((len(seeds), len(ids)), np.nan)
                    for si, model_seed in enumerate(seeds):
                        for ci, case_id in enumerate(ids):
                            raw = table[(model_seed, condition, source, case_id, method)][metric]
                            values[si, ci] = float(raw)
                    matrices[(method, metric)] = values
                    if np.isfinite(values).any():
                        method_stats[method][metric] = {
                            "pooled_mean": float(np.nanmean(values)),
                            "per_seed_means": [float(np.nanmean(value)) for value in values],
                        }
            comparisons: dict[str, object] = {}
            for method in ("topology_residual", "topology_routed"):
                comparisons[f"{method}_minus_direct_base"] = {
                    metric: value
                    for metric in METRICS
                    if (
                        value := hierarchical_bootstrap(
                            matrices[(method, metric)] - matrices[("direct_base", metric)],
                            repetitions,
                            rng,
                        )
                    ) is not None
                }
            degradation: dict[str, object] = {}
            if condition != "native":
                for method in METHODS:
                    degradation[method] = {}
                    for metric in METRICS:
                        native = np.full((len(seeds), len(ids)), np.nan)
                        for si, model_seed in enumerate(seeds):
                            for ci, case_id in enumerate(ids):
                                native[si, ci] = float(
                                    table[(model_seed, "native", source, case_id, method)][metric]
                                )
                        value = hierarchical_bootstrap(
                            matrices[(method, metric)] - native, repetitions, rng
                        )
                        if value is not None:
                            degradation[method][metric] = value
            condition_results[condition] = {
                "method_statistics": method_stats,
                "comparisons": comparisons,
                "degradation_from_native": degradation,
            }
        result[group_name] = {"case_count": len(ids), "conditions": condition_results}
    return result


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def write_table(path: Path, groups: dict[str, object]) -> None:
    selected_groups = (
        "biological_concave", "biological_ordinary", "stress_concave",
        "public_ktc_concave", "public_ktc_ordinary",
    )
    rows: list[dict[str, object]] = []
    for group_name in selected_groups:
        if group_name not in groups:
            continue
        group = groups[group_name]
        for condition in CONDITIONS:
            data = group["conditions"][condition]
            for method in METHODS:
                statistics = data["method_statistics"][method]
                rows.append(
                    {
                        "group": group_name,
                        "cases": group["case_count"],
                        "condition": condition,
                        "method": method,
                        "foreground_iou": statistics["foreground_iou"]["pooled_mean"],
                        "boundary_f1": statistics["boundary_f1"]["pooled_mean"],
                        "notch_preservation": statistics.get("notch_preservation", {}).get("pooled_mean", ""),
                    }
                )
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def plot_robustness(path: Path, groups: dict[str, object]) -> None:
    selected = ("biological_concave", "stress_concave", "public_ktc_concave")
    labels = ("native", "40 dB", "30 dB", "20 dB", "gain .9", "gain 1.1", "drop 5%", "drop 10%")
    colors = {"direct_base": "#4a4a4a", "topology_routed": "#16865b"}
    figure, axes = plt.subplots(3, 2, figsize=(14.2, 10.0), squeeze=False)
    for row_index, group_name in enumerate(selected):
        group = groups[group_name]
        for column, metric in enumerate(("foreground_iou", "notch_preservation")):
            axis = axes[row_index, column]
            for method in ("direct_base", "topology_routed"):
                values = [
                    group["conditions"][condition]["method_statistics"][method][metric]["pooled_mean"]
                    for condition in CONDITIONS
                ]
                axis.plot(range(len(CONDITIONS)), values, marker="o", linewidth=2, color=colors[method], label=method)
            axis.set_xticks(range(len(CONDITIONS)), labels, rotation=30, ha="right")
            axis.set_title(f"{group_name.replace('_', ' ')}: {metric.replace('_', ' ')}")
            axis.grid(alpha=0.25)
    axes[0, 1].legend(frameon=False)
    figure.suptitle("Frozen four-seed models under synchronized measurement perturbations")
    figure.tight_layout()
    figure.savefig(path, dpi=240)
    plt.close(figure)


def plot_degradation(path: Path, groups: dict[str, object]) -> None:
    selected = (
        "biological_concave", "biological_ordinary", "stress_concave",
        "public_ktc_concave", "public_ktc_ordinary",
    )
    perturbations_only = CONDITIONS[1:]
    matrix = np.asarray([
        [
            groups[group]["conditions"][condition]["degradation_from_native"]
            ["topology_routed"]["foreground_iou"]["mean_difference"]
            for condition in perturbations_only
        ]
        for group in selected
    ])
    limit = max(0.005, float(np.max(np.abs(matrix))))
    figure, axis = plt.subplots(figsize=(11.0, 5.0))
    image = axis.imshow(matrix, cmap="coolwarm", vmin=-limit, vmax=limit, aspect="auto")
    axis.set_xticks(range(len(perturbations_only)), [value.replace("_", " ") for value in perturbations_only], rotation=30, ha="right")
    axis.set_yticks(range(len(selected)), [value.replace("_", " ") for value in selected])
    for row in range(matrix.shape[0]):
        for column in range(matrix.shape[1]):
            axis.text(column, row, f"{matrix[row, column]:+.3f}", ha="center", va="center", fontsize=8)
    figure.colorbar(image, ax=axis, label="routed IoU change from native")
    axis.set_title("Measurement-perturbation degradation (four-seed pooled mean)")
    figure.tight_layout()
    figure.savefig(path, dpi=240)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    checkpoints = parse_keyed(args.runs)
    router_paths = parse_keyed(args.routers)
    if checkpoints.keys() != router_paths.keys():
        raise ValueError("checkpoint and router seed labels must match")
    for path in checkpoints.values():
        if not path.is_file():
            raise FileNotFoundError(path)
    thresholds: dict[str, float] = {}
    for seed, path in router_paths.items():
        summary_path = router_json(path)
        if not summary_path.is_file():
            raise FileNotFoundError(summary_path)
        thresholds[seed] = float(json.loads(summary_path.read_text(encoding="utf-8"))["threshold"])

    device = torch.device(
        "cuda" if args.device == "auto" and torch.cuda.is_available() else
        "cpu" if args.device == "auto" else args.device
    )
    groups = load_groups(args)
    prepared = prepare_conditions(groups, device, args.seed)
    rows: list[dict[str, object]] = []
    example_predictions: dict[tuple[str, str], dict[str, np.ndarray]] = {}
    first_seed = next(iter(checkpoints))
    for model_seed, checkpoint in checkpoints.items():
        model = load_model(checkpoint, groups["base"].fov, device)
        print(f"seed={model_seed}; checkpoint={checkpoint.name}", flush=True)
        for group_name, group in groups.items():
            for condition in CONDITIONS:
                voltage, image = prepared[group_name][condition]
                outputs = infer(
                    model, image, voltage, tuple(group.truth.shape[-2:]), args.batch_size, device
                )
                append_case_rows(rows, model_seed, condition, group, outputs, thresholds[model_seed])
                if model_seed == first_seed and condition in {"native", "snr_20db", "dropout_0p10"}:
                    example_predictions[(group_name, condition)] = outputs
            print(f"  completed {group_name}", flush=True)
        del model
        if device.type == "cuda":
            torch.cuda.empty_cache()

    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    write_rows(output_dir / "measurement_robustness_case_metrics.csv", rows)
    group_summary = summarize(rows, args.bootstrap, args.seed + 1)
    result = {
        "seeds": list(checkpoints),
        "checkpoints": {seed: str(path) for seed, path in checkpoints.items()},
        "router_thresholds_fixed_from_clean_synthetic_validation": thresholds,
        "conditions": list(CONDITIONS),
        "protocol": {
            "noise": "zero-mean Gaussian noise added to each native test voltage at stated added SNR",
            "gain": "scalar gain applied to the complete native test voltage vector",
            "dropout": "nested independent element-wise random measurement masks",
            "linear_image": "recomputed from every perturbed voltage using the frozen reconstruction operator",
            "model_or_threshold_selection_on_perturbed_or_public_truth": False,
        },
        "groups": group_summary,
        "bootstrap_repetitions": args.bootstrap,
        "bootstrap_design": "paired hierarchical resampling of model seeds and fixed cases",
    }
    (output_dir / "measurement_robustness_summary.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    write_table(output_dir / "measurement_robustness_paper_table.csv", group_summary)
    plot_robustness(output_dir / "measurement_robustness_curves.png", group_summary)
    plot_degradation(output_dir / "measurement_robustness_degradation.png", group_summary)
    print(json.dumps({"output_dir": str(output_dir), "rows": len(rows)}, indent=2), flush=True)


if __name__ == "__main__":
    main()
