"""Generate an independent nonlinear-CEM stress set for non-convex EIT.

The shapes in this file are deliberately parameterized by geometric failure
modes rather than by the four KTC demonstration phantoms.  Every sample stores
the outer support and the true inward cutout in addition to the conductivity
labels.  This makes it possible to distinguish genuine bay/cavity recovery
from the trivial strategy of shrinking the whole inclusion.
"""
from __future__ import annotations

import argparse
import json
import os
import random
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import distance_transform_edt

from prepare_ktc_shape_dataset import (
    convex_hull_mask,
    instance_indentation_mask,
    rotate,
    signed_distance,
)


FAMILIES = (
    "deep_c",
    "deep_u",
    "keyhole_bay",
    "crescent",
    "heart_notch",
    "sharp_star",
    "reentrant_v",
    "multi_object_gap",
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--samples", type=int, default=1600)
    parser.add_argument("--resolution", type=int, default=64)
    parser.add_argument("--seed", type=int, default=20260829)
    parser.add_argument("--forward-mode", choices=("nonlinear", "linear"), default="nonlinear")
    parser.add_argument("--voltage-scale", type=float, default=2.0)
    parser.add_argument("--ridge", type=float, default=3e-3)
    parser.add_argument("--contact-jitter", type=float, default=0.18)
    parser.add_argument(
        "--repo-root", type=Path, default=root / "external" / "KTC2023-ABC2"
    )
    parser.add_argument(
        "--ktc-root",
        type=Path,
        default=(
            root
            / "datasets"
            / "ktc2023_full"
            / "v3"
            / "evaluation_full"
            / "EvaluationData_full"
        ),
    )
    parser.add_argument(
        "--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz"
    )
    parser.add_argument(
        "--output", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz"
    )
    return parser.parse_args()


def local_frame(
    x: np.ndarray, y: np.ndarray, rng: np.random.Generator
) -> tuple[np.ndarray, np.ndarray, float, float]:
    sx = float(rng.uniform(0.22, 0.39))
    sy = float(rng.uniform(0.20, 0.37))
    limit = max(0.08, 0.76 - max(sx, sy))
    radius = limit * np.sqrt(float(rng.uniform()))
    direction = float(rng.uniform(-np.pi, np.pi))
    cx, cy = radius * np.cos(direction), radius * np.sin(direction)
    lx, ly = rotate(x - cx, y - cy, float(rng.uniform(-np.pi, np.pi)))
    return lx, ly, sx, sy


def shape_with_support(
    family: str,
    x: np.ndarray,
    y: np.ndarray,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray, dict[str, float]]:
    lx, ly, sx, sy = local_frame(x, y, rng)
    ellipse = (lx / sx) ** 2 + (ly / sy) ** 2 <= 1.0

    if family == "deep_c":
        support = ellipse
        wall = float(rng.uniform(0.16, 0.30))
        inner = (lx / (sx * (1.0 - wall))) ** 2 + (ly / (sy * (1.0 - wall))) ** 2 <= 1.0
        mouth = float(rng.uniform(0.12, 0.30))
        opening = (lx > 0.0) & (np.abs(ly) < sy * mouth)
        foreground = support & ~(inner | opening)
        meta = {"neck_fraction": mouth, "depth_fraction": 1.0 - wall}
    elif family == "deep_u":
        support = (np.abs(lx) <= sx) & (np.abs(ly) <= sy)
        wall = float(rng.uniform(0.16, 0.30))
        half_width = sx * float(rng.uniform(0.34, 0.63))
        floor = -sy * float(rng.uniform(0.72, 0.92))
        cavity = (np.abs(lx) < half_width) & (ly > floor)
        foreground = support & ~cavity
        meta = {"neck_fraction": half_width / sx, "depth_fraction": (sy - floor) / (2.0 * sy)}
    elif family == "keyhole_bay":
        support = ellipse
        chamber_x = sx * float(rng.uniform(-0.18, 0.10))
        chamber_r = min(sx, sy) * float(rng.uniform(0.25, 0.43))
        chamber = (lx - chamber_x) ** 2 + ly**2 <= chamber_r**2
        half_neck = sy * float(rng.uniform(0.06, 0.14))
        corridor = (lx >= chamber_x) & (lx <= sx * 1.08) & (np.abs(ly) <= half_neck)
        foreground = support & ~(chamber | corridor)
        meta = {"neck_fraction": half_neck / sy, "depth_fraction": (sx - chamber_x) / (2.0 * sx)}
    elif family == "crescent":
        support = ellipse
        shift = sx * float(rng.uniform(0.30, 0.58))
        inner = ((lx - shift) / (sx * float(rng.uniform(0.72, 0.90)))) ** 2 + (
            ly / (sy * float(rng.uniform(0.78, 0.94)))
        ) ** 2 <= 1.0
        foreground = support & ~inner
        meta = {"neck_fraction": 0.45, "depth_fraction": shift / sx}
    elif family == "heart_notch":
        hx = lx / sx
        hy = (ly + 0.13 * sy) / sy
        foreground = (hx * hx + hy * hy - 0.72) ** 3 - hx * hx * hy**3 <= 0.0
        foreground &= ellipse
        support = convex_hull_mask(foreground)
        meta = {"neck_fraction": 0.28, "depth_fraction": 0.42}
    elif family == "sharp_star":
        theta = np.arctan2(ly, lx)
        radius = np.hypot(lx / sx, ly / sy)
        points = int(rng.integers(5, 9))
        depth = float(rng.uniform(0.30, 0.48))
        foreground = radius <= 0.68 + depth * np.cos(points * theta)
        support = convex_hull_mask(foreground)
        meta = {"neck_fraction": 1.0 / points, "depth_fraction": depth}
    elif family == "reentrant_v":
        support = (np.abs(lx) <= sx) & (np.abs(ly) <= sy)
        depth = sy * float(rng.uniform(0.52, 0.90))
        half_mouth = sx * float(rng.uniform(0.20, 0.48))
        # A triangular bay whose apex points into the object.
        normalized_y = np.clip((sy - ly) / max(depth, 1e-6), 0.0, 1.0)
        bay = (ly >= sy - depth) & (ly <= sy) & (np.abs(lx) <= half_mouth * normalized_y)
        foreground = support & ~bay
        meta = {"neck_fraction": half_mouth / sx, "depth_fraction": depth / (2.0 * sy)}
    elif family == "multi_object_gap":
        # Here the important background region is the narrow gap between two
        # inclusions, not a convex-hull indentation of a single component.
        gap = min(sx, sy) * float(rng.uniform(0.06, 0.18))
        radius_x = sx * float(rng.uniform(0.42, 0.55))
        radius_y = sy * float(rng.uniform(0.62, 0.88))
        offset = radius_x + gap / 2.0
        left = ((lx + offset) / radius_x) ** 2 + (ly / radius_y) ** 2 <= 1.0
        right = ((lx - offset) / radius_x) ** 2 + (ly / radius_y) ** 2 <= 1.0
        foreground = left | right
        bridge = (np.abs(lx) <= gap / 2.0) & (np.abs(ly) <= radius_y * 0.82)
        support = foreground | bridge
        meta = {"neck_fraction": gap / (2.0 * sx), "depth_fraction": 0.5}
    else:
        raise ValueError(f"unknown family: {family}")

    return foreground, support, meta


def generate_geometry(samples: int, resolution: int, seed: int) -> dict[str, np.ndarray]:
    rng = np.random.default_rng(seed)
    coordinates = np.linspace(-1.0, 1.0, resolution, dtype=np.float32)
    x, y = np.meshgrid(coordinates, coordinates)
    fov = x * x + y * y <= 0.98**2
    labels = np.zeros((samples, resolution, resolution), dtype=np.uint8)
    delta = np.zeros((samples, resolution, resolution), dtype=np.float32)
    support_masks = np.zeros_like(labels)
    cutout_masks = np.zeros_like(labels)
    indentation_masks = np.zeros_like(labels)
    signed_distances = np.zeros_like(delta)
    support_sdf = np.zeros_like(delta)
    cutout_sdf = np.zeros_like(delta)
    cutout_depth = np.zeros_like(delta)
    family_codes = np.zeros(samples, dtype=np.int16)
    neck_fractions = np.zeros(samples, dtype=np.float32)
    depth_fractions = np.zeros(samples, dtype=np.float32)

    for index in range(samples):
        family_code = index % len(FAMILIES)
        family = FAMILIES[family_code]
        foreground, support, meta = shape_with_support(family, x, y, rng)
        foreground = foreground & fov
        support = support & fov
        if foreground.sum() < 20:
            foreground, support, meta = shape_with_support(family, x, y, rng)
            foreground = foreground & fov
            support = support & fov
        class_id = 1 if rng.uniform() < 0.56 else 2
        contrast = -float(rng.uniform(0.24, 0.88)) if class_id == 1 else float(rng.uniform(0.24, 1.05))
        label = np.zeros((resolution, resolution), dtype=np.uint8)
        label[foreground] = class_id
        conductivity = np.zeros((resolution, resolution), dtype=np.float32)
        conductivity[foreground] = contrast
        cutout = support & ~foreground
        indentation = instance_indentation_mask(label)
        # Preserve the explicit generated cavity even when a narrow mouth or
        # discretization makes the convex-hull proxy incomplete.
        indentation |= cutout
        depth = distance_transform_edt(cutout)
        if depth.max() > 0:
            depth /= depth.max()

        labels[index] = label
        delta[index] = conductivity
        support_masks[index] = support
        cutout_masks[index] = cutout
        indentation_masks[index] = indentation
        signed_distances[index] = signed_distance(label)
        support_label = support.astype(np.uint8)
        cutout_label = cutout.astype(np.uint8)
        support_sdf[index] = signed_distance(support_label)
        cutout_sdf[index] = signed_distance(cutout_label)
        cutout_depth[index] = depth.astype(np.float32)
        family_codes[index] = family_code
        neck_fractions[index] = float(meta["neck_fraction"])
        depth_fractions[index] = float(meta["depth_fraction"])
    return {
        "labels": labels,
        "delta": delta,
        "support_masks": support_masks,
        "cutout_masks": cutout_masks,
        "indentation_masks": indentation_masks,
        "signed_distance": signed_distances,
        "support_signed_distance": support_sdf,
        "cutout_signed_distance": cutout_sdf,
        "cutout_depth_weights": cutout_depth,
        "family_codes": family_codes,
        "neck_fractions": neck_fractions,
        "depth_fractions": depth_fractions,
        "fov_mask": fov.astype(np.uint8),
    }


def save_preview(path: Path, data: dict[str, np.ndarray], linear: np.ndarray) -> None:
    indices = [next(i for i, code in enumerate(data["family_codes"]) if code == family) for family in range(len(FAMILIES))]
    figure, axes = plt.subplots(len(indices), 4, figsize=(10.0, 2.25 * len(indices)), squeeze=False)
    for row, index in enumerate(indices):
        images = (
            (data["labels"][index], "truth"),
            (data["support_masks"][index], "outer support"),
            (data["cutout_masks"][index], "true inward background"),
            (linear[index], "ridge backprojection"),
        )
        for column, (image, title) in enumerate(images):
            axes[row, column].imshow(image, cmap="viridis", interpolation="nearest")
            axes[row, column].set_title(title if column else FAMILIES[int(data["family_codes"][index])])
            axes[row, column].set_axis_off()
    figure.suptitle("Independent deep-concavity nonlinear-CEM stress set")
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    if args.samples < 80:
        raise ValueError("at least 80 samples are required to cover all stress families")
    random.seed(args.seed)
    np.random.seed(args.seed)
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    geometry = generate_geometry(args.samples, args.resolution, args.seed)

    base = np.load(args.base_dataset.resolve(), allow_pickle=False)
    jacobian = np.asarray(base["jacobian"], dtype=np.float32)
    node_to_raw_pixel = np.asarray(base["node_to_raw_pixel"], dtype=np.int64)
    raw_pixel_to_node = np.asarray(base["raw_pixel_to_node"], dtype=np.int64)
    reconstruction_operator = np.asarray(base["reconstruction_operator"], dtype=np.float32)
    raw_delta = np.flip(geometry["delta"], axis=1).reshape(args.samples, -1)
    node_delta = raw_delta[:, node_to_raw_pixel]

    if args.forward_mode == "linear":
        clean_voltage = args.voltage_scale * (node_delta @ jacobian.T)
        contact_scales = np.ones(args.samples, dtype=np.float32)
    else:
        repo_root = args.repo_root.resolve()
        ktc_root = args.ktc_root.resolve()
        old_cwd = Path.cwd()
        os.chdir(repo_root)
        sys.path.insert(0, str(repo_root))
        try:
            from utils import solver

            matrices = solver.get_solver_matrices(
                str(ktc_root / "evaluation_datasets" / "level1" / "data1.mat"),
                1,
                0.7927,
                reference_data_path=str(ktc_root / "evaluation_datasets" / "level1" / "ref.mat"),
            )
            forward = matrices["forward_solver"]
            sigma0 = np.asarray(matrices["sigma0"], dtype=np.float64)
            z0 = np.asarray(matrices["contact_impedance"], dtype=np.float64)
            clean_voltage = np.empty((args.samples, jacobian.shape[0]), dtype=np.float32)
            contact_scales = np.empty(args.samples, dtype=np.float32)
            rng = np.random.default_rng(args.seed + 11)
            for index in range(args.samples):
                scale = float(np.exp(rng.normal(0.0, args.contact_jitter)))
                z = z0 * scale
                reference = np.asarray(forward.SolveForward(sigma0.copy(), z.copy())).reshape(-1)
                sigma = sigma0 + node_delta[index, :, None].astype(np.float64)
                measured = np.asarray(forward.SolveForward(sigma, z.copy())).reshape(-1)
                clean_voltage[index] = (args.voltage_scale * (measured - reference)).astype(np.float32)
                contact_scales[index] = scale
                if (index + 1) % 25 == 0 or index + 1 == args.samples:
                    print(f"nonlinear stress forward solves {index + 1}/{args.samples}", flush=True)
        finally:
            os.chdir(old_cwd)

    rng = np.random.default_rng(args.seed + 23)
    voltages = clean_voltage.copy()
    snr_db = rng.uniform(24.0, 58.0, size=args.samples).astype(np.float32)
    gain = rng.uniform(0.88, 1.12, size=args.samples).astype(np.float32)
    for index in range(args.samples):
        rms = float(np.sqrt(np.mean(clean_voltage[index] ** 2)))
        noise_rms = rms / (10.0 ** (float(snr_db[index]) / 20.0))
        voltages[index] = gain[index] * clean_voltage[index]
        voltages[index] += rng.normal(0.0, noise_rms + 1e-9, size=voltages.shape[1])

    linear_nodes = voltages @ reconstruction_operator.T
    raw_linear = linear_nodes[:, raw_pixel_to_node].reshape(args.samples, args.resolution, args.resolution)
    linear_images = np.flip(raw_linear, axis=1).astype(np.float32)
    order = rng.permutation(args.samples)
    train_end = int(round(0.65 * args.samples))
    validation_end = int(round(0.80 * args.samples))
    train_indices = np.sort(order[:train_end])
    validation_indices = np.sort(order[train_end:validation_end])
    test_indices = np.sort(order[validation_end:])
    np.savez_compressed(
        output,
        **geometry,
        voltages=voltages.astype(np.float32),
        clean_voltages=clean_voltage.astype(np.float32),
        linear_images=linear_images,
        train_indices=train_indices,
        validation_indices=validation_indices,
        test_indices=test_indices,
        jacobian=jacobian,
        reconstruction_operator=reconstruction_operator,
        node_to_raw_pixel=node_to_raw_pixel,
        raw_pixel_to_node=raw_pixel_to_node,
        node_coordinates=base["node_coordinates"],
        snr_db=snr_db,
        voltage_gain=gain,
        contact_impedance_scale=contact_scales,
    )
    save_preview(output.with_name(output.stem + "_preview.png"), geometry, linear_images)
    summary = {
        "output": str(output),
        "samples": args.samples,
        "resolution": args.resolution,
        "families": list(FAMILIES),
        "splits": {
            "train": int(train_indices.size),
            "validation": int(validation_indices.size),
            "test": int(test_indices.size),
        },
        "forward_mode": args.forward_mode,
        "contact_jitter_log_std": args.contact_jitter,
        "snr_db_range": [float(snr_db.min()), float(snr_db.max())],
        "seed": args.seed,
    }
    output.with_suffix(".json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
