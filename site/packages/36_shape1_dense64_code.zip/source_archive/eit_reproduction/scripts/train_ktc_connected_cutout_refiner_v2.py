"""Train a pixelwise connected-cutout refiner for concave EIT targets.

The coarse EIT networks frequently recover the interior background of a deep
bay but leave a thin foreground bridge at its mouth.  The candidate-action
baseline can open that bridge, although its fixed-width corridors cannot
recover a curved or tapered indentation.  This refiner predicts the complete
local background correction field for each closed cavity.  At inference the
field is projected onto a connected set containing the cavity and its minimum
geodesic path to the exterior.

Synthetic train/validation labels are used for fitting and decoder selection.
The independent stress test, all 21 public KTC2023 labels, and the four ABC2
calibration truths are accessed only after the checkpoint and decoder policy
have been frozen.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy.ndimage import (
    binary_dilation,
    binary_erosion,
    distance_transform_edt,
    label as connected_components,
)
from torch.utils.data import DataLoader, Dataset

from fuse_ktc_joint_shape_models import blend, infer_probability, load_model
from prepare_ktc_deep_concavity_stress import FAMILIES
from train_ktc_candidate_opening_refiner import (
    Candidate,
    find_candidates,
    normalized_image,
    paired_bootstrap,
    save_grid,
    set_seed,
    synthetic_negative,
    synthetic_positive,
)
from train_ktc_concavity_network import InputAdapter
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_highres_refiner import (
    load_dip_four_case_predictions,
    load_official_four_case_truths,
)
from train_ktc_implicit_boolean_network import standard_metrics, stress_metrics


CHANNEL_COUNT = 14
FEATURE_COUNT = 14
MAX_DOMAIN_RADIUS = 8


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    parser.add_argument("--conservative", type=Path, default=Path("E:/Codex/ktc_joint_shape_pretrained_seed20260820/best.pt"))
    parser.add_argument("--aggressive", type=Path, default=Path("E:/Codex/ktc_joint_shape_network_seed20260820/best.pt"))
    parser.add_argument("--output-dir", type=Path, default=Path("E:/Codex/ktc_connected_cutout_refiner_v2_seed20260820"))
    parser.add_argument("--epochs", type=int, default=34)
    parser.add_argument("--batch-size", type=int, default=28)
    parser.add_argument("--inference-batch-size", type=int, default=48)
    parser.add_argument("--learning-rate", type=float, default=1.6e-3)
    parser.add_argument("--weight-decay", type=float, default=2e-4)
    parser.add_argument("--patience", type=int, default=9)
    parser.add_argument("--seed", type=int, default=20260820)
    return parser.parse_args()


def infer_pair(
    conservative_model: nn.Module,
    aggressive_model: nn.Module,
    adapter: InputAdapter,
    images: np.ndarray,
    voltages: np.ndarray,
    device: torch.device,
    batch_size: int,
    size: int = 64,
) -> tuple[np.ndarray, np.ndarray]:
    conservative = infer_probability(conservative_model, adapter, images, voltages, device, batch_size, size)
    aggressive = infer_probability(aggressive_model, adapter, images, voltages, device, batch_size, size)
    return conservative, aggressive


def candidate_arrays(
    image: np.ndarray,
    labels: np.ndarray,
    conservative: np.ndarray,
    aggressive: np.ndarray,
    candidate: Candidate,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    foreground = labels != 0
    seed = candidate.cavity | candidate.path
    seed_distance = distance_transform_edt(~seed)
    domain = (seed_distance <= MAX_DOMAIN_RADIUS) & foreground
    edge = binary_dilation(foreground) ^ binary_erosion(foreground)
    conservative_fg = conservative[1:].sum(axis=0)
    aggressive_fg = aggressive[1:].sum(axis=0)
    scale = max(1.0, float(max(labels.shape)))
    distance_channel = np.clip(seed_distance / MAX_DOMAIN_RADIUS, 0.0, 1.0)
    channels = np.stack((
        normalized_image(image),
        foreground.astype(np.float32),
        conservative[0],
        aggressive[0],
        conservative_fg,
        aggressive_fg,
        np.abs(conservative_fg - aggressive_fg),
        candidate.cavity.astype(np.float32),
        candidate.path.astype(np.float32),
        candidate.exterior.astype(np.float32),
        edge.astype(np.float32),
        domain.astype(np.float32),
        distance_channel.astype(np.float32),
        (aggressive[0] - conservative[0]).astype(np.float32),
    )).astype(np.float16)

    path = candidate.path
    cavity_coordinates = np.argwhere(candidate.cavity)
    cavity_center = cavity_coordinates.mean(axis=0)
    path_cons = conservative[0, path]
    path_aggr = aggressive[0, path]
    domain_aggr = aggressive[0, domain]
    features = np.asarray((
        candidate.cavity.sum() / labels.size,
        candidate.cavity.sum() / max(1, foreground.sum()),
        path.sum() / scale,
        domain.sum() / labels.size,
        float(path_cons.mean()),
        float(path_cons.min()),
        float(path_aggr.mean()),
        float(path_aggr.min()),
        float(domain_aggr.mean()),
        float(domain_aggr.max()),
        float(np.abs(path_cons - path_aggr).mean()),
        min(cavity_center[0], cavity_center[1], labels.shape[0] - 1 - cavity_center[0], labels.shape[1] - 1 - cavity_center[1]) / scale,
        foreground.sum() / labels.size,
        float(edge[domain].mean()),
    ), dtype=np.float32)
    return channels, features, domain.astype(np.uint8), seed_distance.astype(np.float16)


@dataclass
class PixelExamples:
    channels: list[np.ndarray]
    features: list[np.ndarray]
    target: list[np.ndarray]
    domain: list[np.ndarray]
    kind: list[str]

    @classmethod
    def empty(cls) -> "PixelExamples":
        return cls([], [], [], [], [])

    def add(
        self,
        image: np.ndarray,
        labels: np.ndarray,
        conservative: np.ndarray,
        aggressive: np.ndarray,
        candidate: Candidate,
        truth: np.ndarray,
        kind: str,
    ) -> None:
        channels, features, domain, _ = candidate_arrays(image, labels, conservative, aggressive, candidate)
        foreground = labels != 0
        correction = foreground & (truth == 0) & domain.astype(bool)
        self.channels.append(channels)
        self.features.append(features)
        self.target.append(correction.astype(np.uint8))
        self.domain.append(domain)
        self.kind.append(kind)

    def arrays(self) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        targets = np.stack(self.target).astype(np.uint8)
        return (
            np.stack(self.channels),
            np.stack(self.features).astype(np.float32),
            targets,
            np.stack(self.domain).astype(np.uint8),
            (targets.reshape(len(targets), -1).sum(axis=1) > 0).astype(np.float32),
        )


def add_largest_candidate(
    examples: PixelExamples,
    image: np.ndarray,
    corrupted: np.ndarray,
    conservative: np.ndarray,
    aggressive: np.ndarray,
    truth: np.ndarray,
    kind: str,
    max_length: int,
) -> bool:
    candidates = find_candidates(corrupted, conservative, aggressive, max_length, 0.0, 3)
    if not candidates:
        return False
    candidates.sort(key=lambda item: int(item.cavity.sum()), reverse=True)
    examples.add(image, corrupted, conservative, aggressive, candidates[0], truth, kind)
    return True


def build_examples(
    base: np.lib.npyio.NpzFile,
    stress: np.lib.npyio.NpzFile,
    base_indices: np.ndarray,
    stress_indices: np.ndarray,
    base_conservative: np.ndarray,
    base_aggressive: np.ndarray,
    stress_conservative: np.ndarray,
    stress_aggressive: np.ndarray,
    seed: int,
) -> PixelExamples:
    rng = np.random.default_rng(seed)
    examples = PixelExamples.empty()
    for local, index in enumerate(stress_indices):
        positive = synthetic_positive(
            stress["labels"][index], stress["support_masks"][index], stress["cutout_masks"][index],
            stress_conservative[local], stress_aggressive[local], rng,
        )
        if positive is not None:
            add_largest_candidate(examples, stress["linear_images"][index], *positive, stress["labels"][index], "sealed_true_cutout", 12)
        negative = synthetic_negative(stress["labels"][index], stress_conservative[local], stress_aggressive[local], rng)
        if negative is not None:
            add_largest_candidate(examples, stress["linear_images"][index], *negative, stress["labels"][index], "false_hole_stress", 14)
        raw = blend(stress_conservative[local:local + 1], stress_aggressive[local:local + 1], 0.5)[0]
        for candidate in find_candidates(raw, stress_conservative[local], stress_aggressive[local], 6, 0.10, 3):
            examples.add(stress["linear_images"][index], raw, stress_conservative[local], stress_aggressive[local], candidate, stress["labels"][index], "natural_stress")
        if (local + 1) % 100 == 0 or local + 1 == len(stress_indices):
            print(f"  stress pixel augmentation {local + 1}/{len(stress_indices)}", flush=True)

    order = rng.permutation(len(base_indices))
    positive_budget = min(len(base_indices), max(300, 2 * len(stress_indices)))
    negative_budget = min(len(base_indices), max(400, 2 * len(stress_indices)))
    for position, local in enumerate(order):
        index = int(base_indices[local])
        if position < positive_budget:
            foreground = base["labels"][index] != 0
            support = foreground | (base["indentation_masks"][index] != 0)
            cutout = support & ~foreground
            positive = synthetic_positive(base["labels"][index], support, cutout, base_conservative[local], base_aggressive[local], rng)
            if positive is not None:
                add_largest_candidate(examples, base["linear_images"][index], *positive, base["labels"][index], "sealed_base_indent", 12)
        if position < negative_budget:
            negative = synthetic_negative(base["labels"][index], base_conservative[local], base_aggressive[local], rng)
            if negative is not None:
                add_largest_candidate(examples, base["linear_images"][index], *negative, base["labels"][index], "false_hole_base", 14)
        raw = blend(base_conservative[local:local + 1], base_aggressive[local:local + 1], 0.5)[0]
        for candidate in find_candidates(raw, base_conservative[local], base_aggressive[local], 6, 0.10, 3):
            examples.add(base["linear_images"][index], raw, base_conservative[local], base_aggressive[local], candidate, base["labels"][index], "natural_base")
        if (position + 1) % 100 == 0 or position + 1 == len(order):
            print(f"  base pixel augmentation {position + 1}/{len(order)}", flush=True)
    return examples


class PixelDataset(Dataset):
    def __init__(
        self,
        channels: np.ndarray,
        features: np.ndarray,
        target: np.ndarray,
        domain: np.ndarray,
        accept: np.ndarray,
    ) -> None:
        self.channels = torch.from_numpy(channels)
        self.features = torch.from_numpy(features)
        self.target = torch.from_numpy(target)
        self.domain = torch.from_numpy(domain)
        self.accept = torch.from_numpy(accept)

    def __len__(self) -> int:
        return len(self.accept)

    def __getitem__(self, index: int):
        return self.channels[index], self.features[index], self.target[index], self.domain[index], self.accept[index]


class ResidualBlock(nn.Module):
    def __init__(self, channels: int) -> None:
        super().__init__()
        groups = max(4, min(12, channels // 4))
        while channels % groups:
            groups -= 1
        self.layers = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1, bias=False),
            nn.GroupNorm(groups, channels),
            nn.SiLU(),
            nn.Conv2d(channels, channels, 3, padding=1, bias=False),
            nn.GroupNorm(groups, channels),
        )

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        return F.silu(inputs + self.layers(inputs))


class ConnectedCutoutNet(nn.Module):
    def __init__(self, base: int = 24) -> None:
        super().__init__()
        self.stem = nn.Sequential(nn.Conv2d(CHANNEL_COUNT, base, 3, padding=1, bias=False), nn.GroupNorm(6, base), nn.SiLU(), ResidualBlock(base))
        self.down1 = nn.Sequential(nn.Conv2d(base, base * 2, 3, stride=2, padding=1, bias=False), nn.GroupNorm(8, base * 2), nn.SiLU(), ResidualBlock(base * 2))
        self.down2 = nn.Sequential(nn.Conv2d(base * 2, base * 4, 3, stride=2, padding=1, bias=False), nn.GroupNorm(12, base * 4), nn.SiLU(), ResidualBlock(base * 4))
        self.middle = nn.Sequential(nn.Conv2d(base * 4, base * 6, 3, stride=2, padding=1, bias=False), nn.GroupNorm(12, base * 6), nn.SiLU(), ResidualBlock(base * 6))
        self.up2 = nn.Sequential(nn.Conv2d(base * 10, base * 4, 3, padding=1, bias=False), nn.GroupNorm(12, base * 4), nn.SiLU(), ResidualBlock(base * 4))
        self.up1 = nn.Sequential(nn.Conv2d(base * 6, base * 2, 3, padding=1, bias=False), nn.GroupNorm(8, base * 2), nn.SiLU(), ResidualBlock(base * 2))
        self.up0 = nn.Sequential(nn.Conv2d(base * 3, base, 3, padding=1, bias=False), nn.GroupNorm(6, base), nn.SiLU(), ResidualBlock(base))
        self.correction = nn.Conv2d(base, 1, 1)
        self.accept = nn.Sequential(
            nn.Linear(base * 6 + FEATURE_COUNT, 96), nn.SiLU(), nn.Dropout(0.12), nn.Linear(96, 1)
        )

    def forward(self, image: torch.Tensor, features: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        fine = self.stem(image)
        half = self.down1(fine)
        quarter = self.down2(half)
        middle = self.middle(quarter)
        up = F.interpolate(middle, size=quarter.shape[-2:], mode="bilinear", align_corners=False)
        up = self.up2(torch.cat((up, quarter), dim=1))
        up = F.interpolate(up, size=half.shape[-2:], mode="bilinear", align_corners=False)
        up = self.up1(torch.cat((up, half), dim=1))
        up = F.interpolate(up, size=fine.shape[-2:], mode="bilinear", align_corners=False)
        up = self.up0(torch.cat((up, fine), dim=1))
        pooled = F.adaptive_avg_pool2d(middle, 1).flatten(1)
        return self.correction(up).squeeze(1), self.accept(torch.cat((pooled, features), dim=1)).squeeze(1)


def pixel_loss(
    correction_logit: torch.Tensor,
    accept_logit: torch.Tensor,
    target: torch.Tensor,
    domain: torch.Tensor,
    accept: torch.Tensor,
    accept_positive_weight: torch.Tensor,
) -> tuple[torch.Tensor, dict[str, float]]:
    target = target.float()
    domain = domain.float()
    raw = F.binary_cross_entropy_with_logits(correction_logit.float(), target, reduction="none") * domain
    positive = target
    negative = domain * (1.0 - target)
    positive_loss = (raw * positive).sum((1, 2)) / positive.sum((1, 2)).clamp_min(1.0)
    negative_loss = (raw * negative).sum((1, 2)) / negative.sum((1, 2)).clamp_min(1.0)
    has_positive = positive.sum((1, 2)) > 0
    region = torch.where(has_positive, 0.5 * (positive_loss + negative_loss), negative_loss).mean()

    probability = torch.sigmoid(correction_logit.float()) * domain
    intersection = (probability * target).sum((1, 2))
    dice_case = 1.0 - (2.0 * intersection + 1.0) / (probability.sum((1, 2)) + target.sum((1, 2)) + 1.0)
    dice = dice_case[has_positive].mean() if has_positive.any() else probability.sum() * 0.0
    pred_dy = probability[:, 1:] - probability[:, :-1]
    pred_dx = probability[:, :, 1:] - probability[:, :, :-1]
    true_dy = target[:, 1:] - target[:, :-1]
    true_dx = target[:, :, 1:] - target[:, :, :-1]
    boundary = F.l1_loss(pred_dy, true_dy) + F.l1_loss(pred_dx, true_dx)
    accept_loss = F.binary_cross_entropy_with_logits(accept_logit.float(), accept.float(), pos_weight=accept_positive_weight)
    total = region + 0.65 * dice + 0.18 * boundary + 0.42 * accept_loss
    return total, {
        "region": float(region.detach()), "dice": float(dice.detach()),
        "boundary": float(boundary.detach()), "accept": float(accept_loss.detach()),
    }


def inference_records(
    images: np.ndarray,
    raw: np.ndarray,
    conservative: np.ndarray,
    aggressive: np.ndarray,
) -> list[dict[str, object]]:
    records: list[dict[str, object]] = []
    for sample in range(len(raw)):
        candidates = find_candidates(raw[sample], conservative[sample], aggressive[sample], 6, 0.10, 3)
        for candidate_id, candidate in enumerate(candidates):
            channels, features, domain, seed_distance = candidate_arrays(
                images[sample], raw[sample], conservative[sample], aggressive[sample], candidate
            )
            records.append({
                "sample": sample,
                "candidate": candidate_id,
                "candidate_object": candidate,
                "channels": channels,
                "features": features,
                "domain": domain,
                "seed_distance": seed_distance,
            })
    return records


@torch.no_grad()
def score_records(
    model: ConnectedCutoutNet,
    records: list[dict[str, object]],
    feature_mean: np.ndarray,
    feature_scale: np.ndarray,
    device: torch.device,
    batch_size: int = 48,
) -> None:
    if not records:
        return
    model.eval()
    for start in range(0, len(records), batch_size):
        batch = records[start:start + batch_size]
        channels = torch.from_numpy(np.stack([row["channels"] for row in batch])).float().to(device)
        features_array = np.stack([row["features"] for row in batch]).astype(np.float32)
        features_array = (features_array - feature_mean) / feature_scale
        features = torch.from_numpy(features_array).to(device)
        correction, accept = model(channels, features)
        probability = torch.sigmoid(correction).cpu().numpy()
        confidence = torch.sigmoid(accept).cpu().numpy()
        for row, field, value in zip(batch, probability, confidence):
            row["probability"] = field.astype(np.float16)
            row["accept_probability"] = float(value)


def connected_removal(
    raw_sample: np.ndarray,
    record: dict[str, object],
    pixel_threshold: float,
    radius: int,
    fallback_path: bool,
    accepted: bool,
) -> np.ndarray:
    candidate: Candidate = record["candidate_object"]
    foreground = raw_sample != 0
    if not accepted:
        return (candidate.path & foreground) if fallback_path else np.zeros_like(foreground)
    learned = (
        (np.asarray(record["probability"], dtype=np.float32) >= pixel_threshold)
        & (np.asarray(record["seed_distance"], dtype=np.float32) <= radius)
        & np.asarray(record["domain"], dtype=bool)
        & foreground
    )
    proposal = candidate.cavity | candidate.path | learned
    components, _ = connected_components(proposal, structure=np.ones((3, 3), dtype=np.uint8))
    cavity_ids = np.unique(components[candidate.cavity])
    cavity_ids = cavity_ids[cavity_ids != 0]
    connected = np.isin(components, cavity_ids)
    removal = connected & foreground
    if fallback_path:
        removal |= candidate.path & foreground
    return removal


def decode(
    raw: np.ndarray,
    records: list[dict[str, object]],
    accept_threshold: float,
    pixel_threshold: float,
    radius: int,
    fallback_path: bool,
) -> tuple[np.ndarray, list[dict[str, object]]]:
    output = raw.copy()
    accepted_rows: list[dict[str, object]] = []
    for record in records:
        sample = int(record["sample"])
        accepted = float(record["accept_probability"]) >= accept_threshold
        removal = connected_removal(output[sample], record, pixel_threshold, radius, fallback_path, accepted)
        if removal.any():
            output[sample][removal] = 0
            accepted_rows.append({
                "sample": sample,
                "candidate": int(record["candidate"]),
                "accept_probability": float(record["accept_probability"]),
                "accepted_field": bool(accepted),
                "removed_pixels": int(removal.sum()),
            })
    return output, accepted_rows


def choose_decoder(
    base_raw: np.ndarray,
    stress_raw: np.ndarray,
    base_records: list[dict[str, object]],
    stress_records: list[dict[str, object]],
    base_truth: np.ndarray,
    base_indent: np.ndarray,
    stress_truth: np.ndarray,
    stress_cutout: np.ndarray,
    stress_depth: np.ndarray,
    stress_family: np.ndarray,
) -> tuple[dict[str, object], list[dict[str, object]]]:
    base_reference = standard_metrics(base_truth, base_raw, base_indent)
    stress_reference, _, _ = stress_metrics(stress_truth, stress_raw, stress_cutout, stress_depth, stress_family)
    rows: list[dict[str, object]] = []
    # Thresholds above one provide an explicit unchanged anchor.  Early in
    # training the classifier can rank candidates correctly while its sigmoid
    # values remain over-confident; the high-threshold part of the grid lets
    # calibration improve without making checkpoint creation depend on it.
    for fallback_path in (False, True):
        for accept_threshold in (0.20, 0.40, 0.60, 0.75, 0.90, 1.01):
            for pixel_threshold in (0.35, 0.50, 0.65, 0.80):
                for radius in (1, 2, 4, 6, 8):
                    base_prediction, base_actions = decode(base_raw, base_records, accept_threshold, pixel_threshold, radius, fallback_path)
                    stress_prediction, stress_actions = decode(stress_raw, stress_records, accept_threshold, pixel_threshold, radius, fallback_path)
                    base_metric = standard_metrics(base_truth, base_prediction, base_indent)
                    stress_metric, _, _ = stress_metrics(stress_truth, stress_prediction, stress_cutout, stress_depth, stress_family)
                    eligible = (
                        base_metric["foreground_iou"] >= base_reference["foreground_iou"] - 0.007
                        and stress_metric["foreground_iou"] >= stress_reference["foreground_iou"] - 0.009
                        and stress_metric["bank_retention"] >= stress_reference["bank_retention"] - 0.022
                    )
                    score = (
                        0.10 * base_metric["foreground_iou"]
                        + 0.15 * stress_metric["foreground_iou"]
                        + 0.40 * stress_metric["open_deep_cutout_recovery"]
                        + 0.15 * stress_metric["bank_retention"]
                        + 0.20 * stress_metric["topology_structural_joint"]
                    )
                    rows.append({
                        "fallback_path": fallback_path,
                        "accept_threshold": accept_threshold,
                        "pixel_threshold": pixel_threshold,
                        "radius": radius,
                        "eligible": bool(eligible),
                        "score": float(score),
                        "base_actions": len(base_actions),
                        "stress_actions": len(stress_actions),
                        "base": base_metric,
                        "stress": stress_metric,
                    })
    eligible_rows = [row for row in rows if row["eligible"]]
    return max(eligible_rows or rows, key=lambda row: float(row["score"])), rows


def train_model(
    train_examples: PixelExamples,
    validation_examples: PixelExamples,
    validation_context: dict[str, object],
    args: argparse.Namespace,
    device: torch.device,
) -> tuple[ConnectedCutoutNet, dict[str, object], np.ndarray, np.ndarray, list[dict[str, object]]]:
    train_arrays = train_examples.arrays()
    validation_arrays = validation_examples.arrays()
    feature_mean = train_arrays[1].mean(axis=0)
    feature_scale = train_arrays[1].std(axis=0)
    feature_scale[feature_scale < 1e-5] = 1.0
    train_features = (train_arrays[1] - feature_mean) / feature_scale
    validation_features = (validation_arrays[1] - feature_mean) / feature_scale
    train_loader = DataLoader(
        PixelDataset(train_arrays[0], train_features, train_arrays[2], train_arrays[3], train_arrays[4]),
        batch_size=args.batch_size, shuffle=True, num_workers=0, pin_memory=torch.cuda.is_available(),
    )
    validation_loader = DataLoader(
        PixelDataset(validation_arrays[0], validation_features, validation_arrays[2], validation_arrays[3], validation_arrays[4]),
        batch_size=args.batch_size * 2, shuffle=False, num_workers=0,
    )
    positives = max(1.0, float(train_arrays[4].sum()))
    negatives = max(1.0, float(len(train_arrays[4]) - positives))
    accept_positive_weight = torch.tensor(negatives / positives, device=device)
    model = ConnectedCutoutNet().to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    checkpoint = args.output_dir.resolve() / "best.pt"
    best_score = -math.inf
    best_pixel_dice = -math.inf
    stale = 0
    history: list[dict[str, object]] = []

    for epoch in range(1, args.epochs + 1):
        model.train()
        totals: list[float] = []
        for channels, features, target, domain, accept in train_loader:
            channels = channels.float().to(device, non_blocking=True)
            features = features.to(device, non_blocking=True)
            target = target.to(device, non_blocking=True)
            domain = domain.to(device, non_blocking=True)
            accept = accept.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            correction_logit, accept_logit = model(channels, features)
            loss, _ = pixel_loss(correction_logit, accept_logit, target, domain, accept, accept_positive_weight)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            totals.append(float(loss.detach()))
        scheduler.step()

        model.eval()
        accept_correct: list[float] = []
        pixel_dice: list[float] = []
        with torch.no_grad():
            for channels, features, target, domain, accept in validation_loader:
                correction_logit, accept_logit = model(channels.float().to(device), features.to(device))
                predicted_accept = torch.sigmoid(accept_logit).cpu() >= 0.5
                accept_correct.extend((predicted_accept == (accept >= 0.5)).float().numpy().tolist())
                probability = torch.sigmoid(correction_logit).cpu() * domain.float()
                target_float = target.float()
                intersection = (probability * target_float).sum((1, 2))
                dice = (2.0 * intersection + 1.0) / (probability.sum((1, 2)) + target_float.sum((1, 2)) + 1.0)
                positive = target_float.sum((1, 2)) > 0
                pixel_dice.extend(dice[positive].numpy().tolist())

        score_records(model, validation_context["base_records"], feature_mean, feature_scale, device)
        score_records(model, validation_context["stress_records"], feature_mean, feature_scale, device)
        selected, decoder_rows = choose_decoder(
            validation_context["base_raw"], validation_context["stress_raw"],
            validation_context["base_records"], validation_context["stress_records"],
            validation_context["base_truth"], validation_context["base_indent"],
            validation_context["stress_truth"], validation_context["stress_cutout"],
            validation_context["stress_depth"], validation_context["stress_family"],
        )
        row = {
            "epoch": epoch,
            "train_loss": float(np.mean(totals)),
            "validation_accept_accuracy": float(np.mean(accept_correct)),
            "validation_positive_pixel_dice": float(np.mean(pixel_dice)) if pixel_dice else 0.0,
            "selection": selected,
        }
        history.append(row)
        print(
            f"epoch {epoch:02d}: loss={row['train_loss']:.4f} accept={row['validation_accept_accuracy']:.3f} "
            f"pixel_dice={row['validation_positive_pixel_dice']:.3f} "
            f"path={selected['fallback_path']} a={selected['accept_threshold']:.2f} p={selected['pixel_threshold']:.2f} r={selected['radius']} "
            f"iou={selected['stress']['foreground_iou']:.4f} open={selected['stress']['open_deep_cutout_recovery']:.4f} "
            f"bank={selected['stress']['bank_retention']:.4f} eligible={selected['eligible']}",
            flush=True,
        )
        score = float(selected["score"]) if selected["eligible"] else -math.inf
        validation_pixel_dice = float(row["validation_positive_pixel_dice"])
        improved = score > best_score + 1e-5
        tied_but_better_field = abs(score - best_score) <= 1e-5 and validation_pixel_dice > best_pixel_dice + 1e-4
        if improved or tied_but_better_field:
            best_score = score
            best_pixel_dice = validation_pixel_dice
            stale = 0
            torch.save({
                "model": model.state_dict(), "feature_mean": feature_mean, "feature_scale": feature_scale,
                "selection": selected, "epoch": epoch, "seed": args.seed,
            }, checkpoint)
            (args.output_dir.resolve() / "best_validation_grid.json").write_text(json.dumps(decoder_rows, indent=2), encoding="utf-8")
        else:
            stale += 1
        if epoch >= 12 and stale >= args.patience and checkpoint.exists():
            print(f"early stopping after epoch {epoch}", flush=True)
            break

    if not checkpoint.exists():
        raise RuntimeError("No connected-cutout checkpoint satisfied validation preservation constraints")
    state = torch.load(checkpoint, map_location=device, weights_only=False)
    model.load_state_dict(state["model"])
    (args.output_dir.resolve() / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    return model, state["selection"], state["feature_mean"], state["feature_scale"], history


def apply_policy(
    raw: np.ndarray,
    records: list[dict[str, object]],
    selected: dict[str, object],
) -> tuple[np.ndarray, list[dict[str, object]]]:
    return decode(
        raw, records,
        float(selected["accept_threshold"]),
        float(selected["pixel_threshold"]),
        int(selected["radius"]),
        bool(selected["fallback_path"]),
    )


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    base = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    adapter = InputAdapter(base["fov_mask"]).to(device)
    conservative_model = load_model(args.conservative, device)
    aggressive_model = load_model(args.aggressive, device)
    print(f"device={device}; building connected-cutout examples", flush=True)

    rng = np.random.default_rng(args.seed + 17)
    all_base_train = np.asarray(base["train_indices"])
    base_train = np.sort(rng.choice(all_base_train, size=min(700, len(all_base_train)), replace=False))
    stress_train = np.asarray(stress["train_indices"])
    base_validation = np.asarray(base["validation_indices"])
    stress_validation = np.asarray(stress["validation_indices"])

    btc, bta = infer_pair(conservative_model, aggressive_model, adapter, base["linear_images"][base_train], base["voltages"][base_train], device, args.inference_batch_size)
    stc, sta = infer_pair(conservative_model, aggressive_model, adapter, stress["linear_images"][stress_train], stress["voltages"][stress_train], device, args.inference_batch_size)
    train_examples = build_examples(base, stress, base_train, stress_train, btc, bta, stc, sta, args.seed + 1)
    bvc, bva = infer_pair(conservative_model, aggressive_model, adapter, base["linear_images"][base_validation], base["voltages"][base_validation], device, args.inference_batch_size)
    svc, sva = infer_pair(conservative_model, aggressive_model, adapter, stress["linear_images"][stress_validation], stress["voltages"][stress_validation], device, args.inference_batch_size)
    validation_examples = build_examples(base, stress, base_validation, stress_validation, bvc, bva, svc, sva, args.seed + 2)
    train_counts = {kind: train_examples.kind.count(kind) for kind in sorted(set(train_examples.kind))}
    validation_counts = {kind: validation_examples.kind.count(kind) for kind in sorted(set(validation_examples.kind))}
    train_positive = int(sum(mask.any() for mask in train_examples.target))
    validation_positive = int(sum(mask.any() for mask in validation_examples.target))
    print(f"train candidates={len(train_examples.kind)} positive={train_positive} kinds={train_counts}", flush=True)
    print(f"validation candidates={len(validation_examples.kind)} positive={validation_positive} kinds={validation_counts}", flush=True)

    base_validation_raw = blend(bvc, bva, 0.5)
    stress_validation_raw = blend(svc, sva, 0.5)
    validation_context = {
        "base_records": inference_records(base["linear_images"][base_validation], base_validation_raw, bvc, bva),
        "stress_records": inference_records(stress["linear_images"][stress_validation], stress_validation_raw, svc, sva),
        "base_raw": base_validation_raw,
        "stress_raw": stress_validation_raw,
        "base_truth": base["labels"][base_validation],
        "base_indent": base["indentation_masks"][base_validation],
        "stress_truth": stress["labels"][stress_validation],
        "stress_cutout": stress["cutout_masks"][stress_validation],
        "stress_depth": stress["cutout_depth_weights"][stress_validation],
        "stress_family": stress["family_codes"][stress_validation],
    }
    model, selected, feature_mean, feature_scale, history = train_model(
        train_examples, validation_examples, validation_context, args, device
    )
    print(json.dumps(selected, indent=2), flush=True)

    # Independent nonlinear-CEM synthetic tests.
    base_test = np.asarray(base["test_indices"])
    stress_test = np.asarray(stress["test_indices"])
    btc, bta = infer_pair(conservative_model, aggressive_model, adapter, base["linear_images"][base_test], base["voltages"][base_test], device, args.inference_batch_size)
    stc, sta = infer_pair(conservative_model, aggressive_model, adapter, stress["linear_images"][stress_test], stress["voltages"][stress_test], device, args.inference_batch_size)
    base_raw = blend(btc, bta, 0.5)
    stress_raw = blend(stc, sta, 0.5)
    base_records = inference_records(base["linear_images"][base_test], base_raw, btc, bta)
    stress_records = inference_records(stress["linear_images"][stress_test], stress_raw, stc, sta)
    score_records(model, base_records, feature_mean, feature_scale, device)
    score_records(model, stress_records, feature_mean, feature_scale, device)
    base_prediction, accepted_base = apply_policy(base_raw, base_records, selected)
    stress_prediction, accepted_stress = apply_policy(stress_raw, stress_records, selected)
    base_metric = standard_metrics(base["labels"][base_test], base_prediction, base["indentation_masks"][base_test])
    stress_raw_metric, _, stress_raw_rows = stress_metrics(
        stress["labels"][stress_test], stress_raw, stress["cutout_masks"][stress_test],
        stress["cutout_depth_weights"][stress_test], stress["family_codes"][stress_test],
    )
    stress_metric, stress_family, stress_rows = stress_metrics(
        stress["labels"][stress_test], stress_prediction, stress["cutout_masks"][stress_test],
        stress["cutout_depth_weights"][stress_test], stress["family_codes"][stress_test],
    )
    bootstrap = paired_bootstrap(stress_raw_rows, stress_rows, 10000, args.seed)

    # Public KTC2023: detect and refine at the trained 64 x 64 scale, then
    # project only the learned removal field onto the native 256 x 256 result.
    rc64, ra64 = infer_pair(conservative_model, aggressive_model, adapter, base["real_linear_images"], base["real_voltages"], device, args.inference_batch_size, 64)
    real_raw64 = blend(rc64, ra64, 0.5)
    real_records = inference_records(base["real_linear_images"], real_raw64, rc64, ra64)
    score_records(model, real_records, feature_mean, feature_scale, device)
    real_prediction64, accepted_real = apply_policy(real_raw64, real_records, selected)
    rc256, ra256 = infer_pair(conservative_model, aggressive_model, adapter, base["real_linear_images"], base["real_voltages"], device, args.inference_batch_size, 256)
    real_raw = blend(rc256, ra256, 0.5)
    real_prediction = real_raw.copy()
    real_removal = np.repeat(np.repeat(real_raw64 != real_prediction64, 4, axis=1), 4, axis=2)
    real_prediction[real_removal] = 0
    real_raw_metric, _ = evaluate_real_predictions("raw_fusion", real_raw, base["real_labels"], base["real_ids"])
    real_metric, real_rows = evaluate_real_predictions("connected_cutout_v2", real_prediction, base["real_labels"], base["real_ids"])

    # The four original ABC2 examples remain calibration-only diagnostics.
    cc, ca = infer_pair(conservative_model, aggressive_model, adapter, base["calibration_linear_images"], base["calibration_voltages"], device, args.inference_batch_size)
    calibration_raw = blend(cc, ca, 0.5)
    calibration_records = inference_records(base["calibration_linear_images"], calibration_raw, cc, ca)
    score_records(model, calibration_records, feature_mean, feature_scale, device)
    calibration_prediction, accepted_calibration = apply_policy(calibration_raw, calibration_records, selected)
    official_truth, official_ids = load_official_four_case_truths(Path(__file__).resolve().parents[1] / "external" / "KTC2023-ABC2")
    official_raw = np.repeat(np.repeat(calibration_raw, 4, axis=1), 4, axis=2)
    official_prediction = np.repeat(np.repeat(calibration_prediction, 4, axis=1), 4, axis=2)
    official_summary: dict[str, dict[str, float]] = {}
    official_rows: list[dict[str, object]] = []
    for name, prediction in (
        ("DIP_TV", load_dip_four_case_predictions(Path(__file__).resolve().parents[1])),
        ("raw_fusion", official_raw),
        ("connected_cutout_v2", official_prediction),
    ):
        official_summary[name], rows = evaluate_real_predictions(name, prediction, official_truth, official_ids)
        official_rows.extend(rows)

    changed = np.flatnonzero(np.any(stress_raw != stress_prediction, axis=(1, 2)))
    if len(changed):
        gains = np.asarray([
            stress_rows[index]["topology_structural_joint"] - stress_raw_rows[index]["topology_structural_joint"]
            for index in changed
        ])
        focus = changed[np.argsort(gains)[::-1][:min(24, len(changed))]]
        save_grid(
            output_dir / "stress_changed_cases.png", stress["labels"][stress_test], stress_raw, stress_prediction,
            [FAMILIES[int(stress["family_codes"][stress_test][index])] for index in focus], focus,
        )
    family_focus = []
    for code in range(len(FAMILIES)):
        candidates = np.flatnonzero(stress["family_codes"][stress_test] == code)
        family_focus.append(int(candidates[np.argmax(stress["cutout_depth_weights"][stress_test][candidates].sum(axis=(1, 2)))]))
    save_grid(
        output_dir / "stress_family_cases.png", stress["labels"][stress_test], stress_raw, stress_prediction,
        list(FAMILIES), np.asarray(family_focus),
    )
    real_changed = np.flatnonzero(np.any(real_raw != real_prediction, axis=(1, 2)))
    if len(real_changed):
        save_grid(
            output_dir / "real_changed_cases.png", base["real_labels"], real_raw, real_prediction,
            [str(base["real_ids"][index]) for index in real_changed], real_changed,
        )
    save_grid(
        output_dir / "official_four_cases.png", official_truth, official_raw, official_prediction,
        [str(item) for item in official_ids], np.arange(4),
    )

    np.savez_compressed(
        output_dir / "predictions.npz",
        base=base_prediction, stress=stress_prediction, stress_raw=stress_raw,
        real=real_prediction, real_raw=real_raw,
        calibration=official_prediction, calibration_raw=official_raw,
    )
    with (output_dir / "stress_bootstrap.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(bootstrap[0]))
        writer.writeheader()
        writer.writerows(bootstrap)
    with (output_dir / "official_four_metrics.csv").open("w", newline="", encoding="utf-8") as handle:
        fields = sorted({key for row in official_rows for key in row})
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(official_rows)

    result = {
        "method": "pixelwise connected-cutout refiner with geodesic topology projection",
        "literature_basis": [
            "explicit geometry/topology variables from level-set and Boolean EIT reconstruction",
            "spatially adaptive edge evidence from variational EIT reconstruction",
            "local topology-error refinement rather than Betti-number supervision alone",
        ],
        "data_policy": "training and decoder selection use synthetic train/validation only; stress test, 21 KTC labels, and ABC2 truths are held out",
        "training_examples": {"candidates": len(train_examples.kind), "positive": train_positive, "kinds": train_counts},
        "validation_examples": {"candidates": len(validation_examples.kind), "positive": validation_positive, "kinds": validation_counts},
        "selected": selected,
        "checkpoint_epoch": int(torch.load(output_dir / "best.pt", map_location="cpu", weights_only=False)["epoch"]),
        "test": {
            "base_actions": len(accepted_base), "stress_actions": len(accepted_stress),
            "real_actions": len(accepted_real), "calibration_actions": len(accepted_calibration),
            "base": base_metric,
            "stress_raw": stress_raw_metric,
            "stress_connected_cutout_v2": stress_metric,
            "stress_by_family": stress_family,
            "bootstrap": bootstrap,
            "real_raw": real_raw_metric,
            "real_connected_cutout_v2": real_metric,
            "real_cases": real_rows,
            "official_four": official_summary,
            "accepted_base": accepted_base,
            "accepted_stress": accepted_stress,
            "accepted_real": accepted_real,
            "accepted_calibration": accepted_calibration,
        },
    }
    (output_dir / "summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result["test"], ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
