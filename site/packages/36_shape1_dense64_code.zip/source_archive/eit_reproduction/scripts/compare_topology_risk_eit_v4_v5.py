"""Paired four-seed comparison of the final routed v4 and v5 EIT models."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from aggregate_topology_action_router_multiseed import (
    METRICS,
    build_groups,
    hierarchical_bootstrap,
    lookup,
    matrix,
    parse_runs,
    read_rows,
    tail_summary,
)


DISPLAY_GROUPS = (
    "biological_concave",
    "stress_concave",
    "public_ktc_nonconvex",
    "biological_ordinary",
)
DISPLAY_METRICS = (
    "foreground_iou",
    "boundary_f1",
    "notch_preservation",
    "bank_retention",
)
DISPLAY_LABELS = {
    "foreground_iou": "IoU",
    "boundary_f1": "Boundary F1",
    "notch_preservation": "Notch",
    "bank_retention": "Bank retention",
}


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--v4-runs", nargs="+", required=True, help="seed=router_directory")
    parser.add_argument("--v5-runs", nargs="+", required=True, help="seed=router_directory")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--bootstrap", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260927)
    parser.add_argument(
        "--audit",
        type=Path,
        default=root / "outputs" / "ktc2023_full_audit" / "summary.json",
    )
    return parser.parse_args()


def paired_runs(
    v4_values: list[str], v5_values: list[str]
) -> tuple[list[str], list[Path], list[Path]]:
    v4 = dict(parse_runs(v4_values))
    v5 = dict(parse_runs(v5_values))
    if set(v4) != set(v5):
        raise ValueError(f"v4/v5 seed mismatch: {sorted(v4)} != {sorted(v5)}")
    seeds = sorted(v4)
    return seeds, [v4[seed] for seed in seeds], [v5[seed] for seed in seeds]


def method_statistics(values: np.ndarray) -> dict[str, object]:
    per_seed = [float(np.nanmean(row)) for row in values]
    return {
        "pooled_mean": float(np.nanmean(values)),
        "per_seed_means": per_seed,
        "between_seed_sd": float(np.std(per_seed, ddof=1)),
    }


def summarize_group(
    v4_lookups: list[dict[tuple[str, str], dict[str, str]]],
    v5_lookups: list[dict[tuple[str, str], dict[str, str]]],
    ids: list[str],
    repetitions: int,
    rng: np.random.Generator,
) -> dict[str, object]:
    methods: dict[str, dict[str, object]] = {"v4_routed": {}, "v5_routed": {}}
    comparisons: dict[str, object] = {}
    iou_difference: np.ndarray | None = None
    for metric in METRICS:
        v4 = matrix(v4_lookups, ids, "topology_routed", metric)
        v5 = matrix(v5_lookups, ids, "topology_routed", metric)
        if not np.isfinite(v4).any() or not np.isfinite(v5).any():
            continue
        if not np.array_equal(np.isfinite(v4), np.isfinite(v5)):
            raise ValueError(f"finite-value mismatch for {metric}")
        methods["v4_routed"][metric] = method_statistics(v4)
        methods["v5_routed"][metric] = method_statistics(v5)
        comparison = hierarchical_bootstrap(v5 - v4, repetitions, rng)
        if comparison is not None:
            comparisons[metric] = comparison
        if metric == "foreground_iou":
            iou_difference = v5 - v4
    return {
        "case_count": len(ids),
        "method_statistics": methods,
        "v5_minus_v4": {
            "metrics": comparisons,
            "iou_tail_risk": tail_summary(iou_difference)
            if iou_difference is not None
            else {},
        },
    }


def write_table(path: Path, groups: dict[str, dict[str, object]]) -> None:
    rows: list[dict[str, object]] = []
    for group_name in DISPLAY_GROUPS:
        group = groups[group_name]
        for metric in DISPLAY_METRICS:
            value = group["v5_minus_v4"]["metrics"].get(metric)
            if value is None:
                continue
            rows.append(
                {
                    "group": group_name,
                    "cases": group["case_count"],
                    "metric": metric,
                    "v5_minus_v4": value["mean_difference"],
                    "ci95_low": value["ci95_low"],
                    "ci95_high": value["ci95_high"],
                    "bootstrap_probability_positive": value["probability_positive"],
                }
            )
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def plot_comparison(path: Path, groups: dict[str, dict[str, object]]) -> None:
    figure, axes = plt.subplots(2, 2, figsize=(12.0, 8.0), squeeze=False)
    colors = {
        "foreground_iou": "#2f6f9f",
        "boundary_f1": "#5f8f3d",
        "notch_preservation": "#c26d2d",
        "bank_retention": "#8b5fa8",
    }
    for axis, group_name in zip(axes.flat, DISPLAY_GROUPS):
        comparisons = groups[group_name]["v5_minus_v4"]["metrics"]
        metrics = [metric for metric in DISPLAY_METRICS if metric in comparisons]
        positions = np.arange(len(metrics))
        for position, metric in zip(positions, metrics):
            value = comparisons[metric]
            mean = value["mean_difference"]
            axis.errorbar(
                mean,
                position,
                xerr=[[mean - value["ci95_low"]], [value["ci95_high"] - mean]],
                fmt="o",
                color=colors[metric],
                markersize=7,
                capsize=4,
                linewidth=2,
            )
        axis.axvline(0.0, color="#222222", linewidth=1.0)
        axis.set_yticks(positions, [DISPLAY_LABELS[metric] for metric in metrics])
        axis.set_xlabel("Paired mean difference (v5 - v4)")
        axis.set_title(group_name.replace("_", " "))
        axis.grid(axis="x", alpha=0.22)
        axis.invert_yaxis()
    figure.suptitle("Final routed model: v5 versus v4 across four matched random seeds")
    figure.tight_layout()
    figure.savefig(path, dpi=240)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    seeds, v4_paths, v5_paths = paired_runs(args.v4_runs, args.v5_runs)
    v4_rows = [read_rows(path / "action_router_case_metrics.csv") for path in v4_paths]
    v5_rows = [read_rows(path / "action_router_case_metrics.csv") for path in v5_paths]
    audit = json.loads(args.audit.resolve().read_text(encoding="utf-8"))
    strict_ids = {str(value) for value in audit["nonconvex_ids"]}
    v4_groups = build_groups(v4_rows[0], strict_ids)
    v5_groups = build_groups(v5_rows[0], strict_ids)
    if v4_groups != v5_groups:
        raise ValueError("v4/v5 case groups are not identical")
    v4_lookups = [lookup(rows) for rows in v4_rows]
    v5_lookups = [lookup(rows) for rows in v5_rows]
    rng = np.random.default_rng(args.seed)
    groups = {
        name: summarize_group(
            v4_lookups, v5_lookups, ids, args.bootstrap, rng
        )
        for name, ids in v4_groups.items()
    }
    result = {
        "seeds": seeds,
        "v4_runs": {seed: str(path) for seed, path in zip(seeds, v4_paths)},
        "v5_runs": {seed: str(path) for seed, path in zip(seeds, v5_paths)},
        "groups": groups,
        "bootstrap_repetitions": args.bootstrap,
        "bootstrap_design": "paired hierarchical resampling of matched seeds and cases",
        "comparison": "v5 topology_routed minus v4 topology_routed",
        "public_truth_used_for_training_or_threshold_selection": False,
    }
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "v4_v5_paired_summary.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    write_table(output_dir / "v4_v5_paired_table.csv", groups)
    plot_comparison(output_dir / "v4_v5_paired_effects.png", groups)
    print(
        json.dumps(
            {
                "seeds": seeds,
                "groups": {name: value["case_count"] for name, value in groups.items()},
                "output_dir": str(output_dir),
            },
            indent=2,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
