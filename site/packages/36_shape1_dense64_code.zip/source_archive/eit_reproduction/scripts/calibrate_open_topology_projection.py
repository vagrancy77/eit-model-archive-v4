"""Calibrate a truth-blind open-mouth projection on synthetic validation only.

The learned network already predicts an exterior-connected soft cutout and a
mouth map.  Discrete argmax can nevertheless close a one-pixel bridge.  This
script calibrates how strongly those two probabilities modify the direct trunk
without accessing synthetic test or public KTC labels.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
from scipy.ndimage import binary_fill_holes
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import train_boolean_shape_eit_v2 as data_tools
import train_topology_residual_eit_v3 as trainer
from pytorch_eit.topology_residual_net import TopologyResidualEITNet


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--checkpoint", type=Path,
        default=Path(r"E:\Codex\topology_residual_eit_v3_full\topology_residual_v3_best.pt"),
    )
    parser.add_argument(
        "--base-dataset", type=Path, default=ROOT / "datasets" / "ktc_shape_nonlinear_v1.npz"
    )
    parser.add_argument(
        "--biological-dataset", type=Path,
        default=ROOT / "datasets" / "ktc_biological_concavity_v1.npz",
    )
    parser.add_argument(
        "--stress-dataset", type=Path,
        default=ROOT / "datasets" / "ktc_deep_concavity_stress_v1.npz",
    )
    parser.add_argument(
        "--output", type=Path,
        default=Path(r"E:\Codex\topology_residual_eit_v3_full\open_projection.json"),
    )
    parser.add_argument("--batch-size", type=int, default=24)
    parser.add_argument("--device", choices=("auto", "cuda", "cpu"), default="auto")
    return parser.parse_args()


@torch.no_grad()
def infer(
    model: TopologyResidualEITNet,
    loader: DataLoader,
    device: torch.device,
) -> dict[str, np.ndarray]:
    model.eval()
    saved: dict[str, list[np.ndarray]] = {
        key: [] for key in ("base", "effective", "mouth", "gate", "truth", "cutout")
    }
    for batch in loader:
        output = model(batch["image"].to(device), batch["voltage"].to(device))
        saved["base"].append(output["base_probabilities"].cpu().numpy())
        saved["effective"].append(output["effective_cutout_probability"][:, 0].cpu().numpy())
        saved["mouth"].append(output["mouth_probability"][:, 0].cpu().numpy())
        saved["gate"].append(output["case_gate"][:, 0, 0, 0].cpu().numpy())
        saved["truth"].append(batch["labels"].numpy())
        saved["cutout"].append(batch["cutout"][:, 0].numpy())
    return {key: np.concatenate(values) for key, values in saved.items()}


def project(
    arrays: dict[str, np.ndarray],
    gamma: float,
    mouth_weight: float,
    gate_threshold: float,
) -> np.ndarray:
    base = arrays["base"]
    base_foreground = base[:, 1:].sum(axis=1)
    cutout = np.maximum(
        arrays["effective"],
        mouth_weight * arrays["mouth"] * arrays["gate"][:, None, None],
    )
    factor = np.maximum(1.0 - cutout, 1e-5) ** gamma
    enabled = arrays["gate"][:, None, None] >= gate_threshold
    foreground = np.where(enabled, base_foreground * factor, base_foreground)
    conditional = base[:, 1:] / np.maximum(base_foreground[:, None], 1e-6)
    probabilities = np.concatenate(
        ((1.0 - foreground)[:, None], foreground[:, None] * conditional), axis=1
    )
    return probabilities.argmax(axis=1).astype(np.uint8)


def split_metrics(
    truth: np.ndarray,
    prediction: np.ndarray,
    cutout: np.ndarray,
) -> dict[str, dict[str, float]]:
    rows = [trainer.case_metrics(t, p, c) for t, p, c in zip(truth, prediction, cutout)]
    concave = [row for row in rows if row["has_cutout"] > 0.5]
    ordinary = [row for row in rows if row["has_cutout"] <= 0.5]
    return {
        "all": trainer.aggregate(rows),
        "concave": trainer.aggregate(concave) if concave else {"cases": 0.0},
        "ordinary": trainer.aggregate(ordinary) if ordinary else {"cases": 0.0},
    }


def spurious_hole_fraction(
    truth: np.ndarray,
    prediction: np.ndarray,
    selected: np.ndarray | None = None,
) -> float:
    indices = np.arange(len(truth)) if selected is None else np.flatnonzero(selected)
    values: list[float] = []
    for index in indices:
        truth_foreground = truth[index] != 0
        predicted_foreground = prediction[index] != 0
        predicted_holes = binary_fill_holes(predicted_foreground) & ~predicted_foreground
        truth_holes = binary_fill_holes(truth_foreground) & ~truth_foreground
        values.append(float((predicted_holes & ~truth_holes).sum() / max(1, truth_foreground.sum())))
    return float(np.mean(values)) if values else 0.0


def summarize_config(
    groups: dict[str, dict[str, np.ndarray]],
    direct_metrics: dict[str, dict[str, dict[str, float]]],
    gamma: float,
    mouth_weight: float,
    gate_threshold: float,
) -> dict[str, object]:
    metrics: dict[str, dict[str, dict[str, dict[str, float]]]] = {}
    predictions: dict[str, np.ndarray] = {}
    for name, arrays in groups.items():
        prediction = project(arrays, gamma, mouth_weight, gate_threshold)
        predictions[name] = prediction
        metrics[name] = {
            "final": split_metrics(arrays["truth"], prediction, arrays["cutout"]),
            "direct_base": direct_metrics[name],
        }
    raw_score = trainer.selection_score(metrics)
    biological_ordinary = groups["biological"]["cutout"].reshape(
        len(groups["biological"]["cutout"]), -1
    ).sum(axis=1) == 0
    biological_holes = spurious_hole_fraction(
        groups["biological"]["truth"], predictions["biological"], biological_ordinary
    )
    stress_holes = spurious_hole_fraction(groups["stress"]["truth"], predictions["stress"])
    # This objective is fixed before any new independent or public evaluation:
    # ordinary false holes are expensive, while closed stress rings receive a
    # smaller but explicit penalty in addition to the original validation score.
    objective = raw_score - 0.75 * biological_holes - 0.25 * stress_holes
    return {
        "gamma": gamma,
        "mouth_weight": mouth_weight,
        "gate_threshold": gate_threshold,
        "objective": float(objective),
        "raw_selection_score": float(raw_score),
        "biological_ordinary_spurious_hole_fraction": biological_holes,
        "stress_spurious_hole_fraction": stress_holes,
        "metrics": metrics,
    }


def main() -> None:
    args = parse_args()
    device = torch.device(
        "cuda" if args.device == "auto" and torch.cuda.is_available() else
        "cpu" if args.device == "auto" else args.device
    )
    archives = {
        "base": np.load(args.base_dataset.resolve(), allow_pickle=False),
        "biological": np.load(args.biological_dataset.resolve(), allow_pickle=False),
        "stress": np.load(args.stress_dataset.resolve(), allow_pickle=False),
    }
    prepared = {name: data_tools.prepare_arrays(archive, name) for name, archive in archives.items()}
    state = torch.load(args.checkpoint.resolve(), map_location=device, weights_only=False)
    model = TopologyResidualEITNet(
        prepared["base"].fov_mask,
        base=int(state["base_channels"]),
        propagation_steps=int(state.get("propagation_steps", 14)),
        risk_aware=bool(state.get("risk_aware", False)),
    ).to(device)
    model.load_state_dict(state["model"])
    groups: dict[str, dict[str, np.ndarray]] = {}
    direct_metrics: dict[str, dict[str, dict[str, float]]] = {}
    for source, name in enumerate(("base", "biological", "stress")):
        dataset = trainer.DirectStructuralDataset(
            prepared[name], archives[name], archives[name]["validation_indices"], source
        )
        loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False)
        groups[name] = infer(model, loader, device)
        direct_prediction = groups[name]["base"].argmax(axis=1)
        direct_metrics[name] = split_metrics(
            groups[name]["truth"], direct_prediction, groups[name]["cutout"]
        )

    candidates: list[dict[str, object]] = []
    for gamma in (0.70, 0.90, 1.10, 1.30, 1.55, 1.85):
        for mouth_weight in (0.0, 0.35, 0.55, 0.75, 0.95):
            for gate_threshold in (0.0, 0.45, 0.55, 0.65, 0.75, 0.85):
                candidates.append(
                    summarize_config(
                        groups, direct_metrics, gamma, mouth_weight, gate_threshold
                    )
                )
    candidates.sort(key=lambda row: float(row["objective"]), reverse=True)
    result = {
        "selection_data": "synthetic validation only",
        "synthetic_test_or_public_truth_used": False,
        "objective": (
            "original validation selection score - 0.75 * biological ordinary spurious holes "
            "- 0.25 * stress spurious holes"
        ),
        "best": candidates[0],
        "top_10": candidates[:10],
    }
    args.output.resolve().write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
