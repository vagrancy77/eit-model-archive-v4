from __future__ import annotations

import argparse
import json
import os
import random
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import scipy.io as sio
from PIL import Image
from scipy import ndimage


def parse_args() -> argparse.Namespace:
    project_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(
        description=(
            "Minimal validation of hard, soft, and reliability-weighted "
            "ultrasound geometric priors for KTC DIP+TV EIT."
        )
    )
    parser.add_argument("--repo-root", type=Path, default=project_root / "external" / "KTC2023-ABC2")
    parser.add_argument("--input", type=Path, default=None, help="Defaults to inputs/data1.mat.")
    parser.add_argument("--truth", type=Path, default=None, help="Defaults to groundTruths/true1.mat.")
    parser.add_argument("--output-dir", type=Path, default=project_root / "outputs" / "us_prior_robustness_pilot")
    parser.add_argument("--num-iter", type=int, default=250)
    parser.add_argument("--seed", type=int, default=20260802)
    parser.add_argument("--geo-lambda", type=float, default=2e-2)
    parser.add_argument("--reliability-reg", type=float, default=5e-4)
    parser.add_argument("--registration-reg", type=float, default=5e-4)
    parser.add_argument(
        "--methods",
        nargs="+",
        default=None,
        help="Optional subset of method names to run; defaults to all methods.",
    )
    parser.add_argument(
        "--scenarios",
        nargs="+",
        default=None,
        help="Optional subset of scenario names to run; defaults to all scenarios.",
    )
    parser.add_argument("--progress-every", type=int, default=0)
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch

        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except Exception:
        pass


def make_disk(shape: tuple[int, int], center: tuple[int, int], radius: int) -> np.ndarray:
    yy, xx = np.ogrid[: shape[0], : shape[1]]
    return ((yy - center[0]) ** 2 + (xx - center[1]) ** 2 <= radius**2).astype(np.float64)


def build_scenarios(mask: np.ndarray, oracle_quality: bool = True) -> dict[str, dict[str, np.ndarray]]:
    """Construct controlled ultrasound errors at 256 x 256 resolution."""
    clean = mask.astype(np.float64)
    shifted = ndimage.shift(clean, shift=(0, 10), order=0, mode="constant", cval=0.0)
    rotated = ndimage.rotate(clean, angle=10.0, reshape=False, order=0, mode="constant", cval=0.0)
    blurred = ndimage.gaussian_filter(clean, sigma=4.0)
    blurred /= max(float(blurred.max()), 1e-12)
    false_positive = np.maximum(clean, make_disk(clean.shape, (65, 195), 24))

    scenarios: dict[str, dict[str, np.ndarray]] = {}
    for name, prior in (
        ("clean", clean),
        ("shift10px", shifted),
        ("rotate10deg", rotated),
        ("blur_sigma4", blurred),
        ("false_positive", false_positive),
    ):
        # Confidence is deliberately lower at soft/uncertain boundaries. For
        # registration and false-positive stress tests, the synthetic error
        # region receives a lower initial confidence, representing an image-
        # quality or registration-estimation module's output.
        boundary_confidence = np.clip(2.0 * np.abs(prior - 0.5), 0.0, 1.0)
        boundary_confidence = ndimage.gaussian_filter(boundary_confidence, sigma=1.0)
        reliability = np.clip(boundary_confidence, 0.05, 0.95)
        if oracle_quality:
            if name == "shift10px":
                reliability *= 0.35
            elif name == "rotate10deg":
                reliability *= 0.45
            elif name == "false_positive":
                reliability[make_disk(clean.shape, (65, 195), 32) > 0] *= 0.25
        scenarios[name] = {
            "mask": np.clip(prior, 0.0, 1.0),
            "hard_mask": (prior >= 0.5).astype(np.float64),
            "reliability": np.clip(reliability, 0.05, 0.95),
        }
    return scenarios


def save_label_png(labels: np.ndarray, path: Path) -> None:
    Image.fromarray(np.clip(labels * 127.5, 0, 255).astype(np.uint8)).save(path)


def metrics(truth: np.ndarray, reconstruction: np.ndarray) -> dict[str, float]:
    truth = np.asarray(truth, dtype=np.int64)
    reconstruction = np.asarray(reconstruction, dtype=np.int64)
    output: dict[str, float] = {"pixel_accuracy": float(np.mean(truth == reconstruction))}
    ious = []
    dices = []
    for label in (1, 2):
        t = truth == label
        r = reconstruction == label
        intersection = float(np.logical_and(t, r).sum())
        union = float(np.logical_or(t, r).sum())
        denom = float(t.sum() + r.sum())
        iou = intersection / union if union else 1.0
        dice = 2 * intersection / denom if denom else 1.0
        output[f"class{label}_iou"] = iou
        output[f"class{label}_dice"] = dice
        ious.append(iou)
        dices.append(dice)
    output["mean_iou"] = float(np.mean(ious))
    output["mean_dice"] = float(np.mean(dices))
    output["support_iou"] = float(
        np.logical_and(truth > 0, reconstruction > 0).sum()
        / max(float(np.logical_or(truth > 0, reconstruction > 0).sum()), 1.0)
    )
    output["false_positive_support_fraction"] = float(
        np.logical_and(truth == 0, reconstruction > 0).sum() / max(float((reconstruction > 0).sum()), 1.0)
    )
    return output


def main() -> None:
    args = parse_args()
    repo_root = args.repo_root.resolve()
    input_path = (args.input or (repo_root / "inputs" / "data1.mat")).resolve()
    truth_path = (args.truth or (repo_root / "groundTruths" / "true1.mat")).resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    os.chdir(repo_root)
    sys.path.insert(0, str(repo_root))
    from utils import process, solver

    truth = np.asarray(sio.loadmat(truth_path)["truth"], dtype=np.int64)
    true_mask = (truth > 0).astype(np.float64)
    scenarios = build_scenarios(true_mask)
    if args.scenarios:
        scenarios = {name: scenarios[name] for name in args.scenarios}

    # Baseline is independent of the ultrasound scenario and is run once.
    set_seed(args.seed)
    baseline, baseline_details = solver.solve(
        str(input_path), 1, num_iter_override=args.num_iter,
        progress_every=args.progress_every, return_details=True,
    )
    save_label_png(baseline, output_dir / "baseline_no_prior.png")
    rows: list[dict[str, object]] = []
    rows.append({
        "scenario": "all",
        "method": "no_prior_baseline",
        "seed": args.seed,
        "metrics": metrics(truth, baseline),
        "final_total_loss": baseline_details["final_total_loss"],
    })

    # Each prior condition uses a deterministic but distinct seed.
    method_specs = (
        ("hard_mask", "hard", True, False, False),
        ("soft_mask", "soft", False, False, False),
        ("reliability_weighted_fixed", "reliability_fixed", False, False, False),
        ("reliability_weighted_learned", "reliability", False, True, False),
        ("reliability_registration_learned", "registration", False, True, True),
        ("registration_fallback_learned", "registration_fallback", False, True, True),
    )
    if args.methods:
        method_specs = tuple(spec for spec in method_specs if spec[0] in args.methods)
    for scenario_index, (scenario_name, scenario) in enumerate(scenarios.items(), start=1):
        np.savez_compressed(
            output_dir / f"prior_{scenario_name}.npz",
            mask=scenario["mask"],
            hard_mask=scenario["hard_mask"],
            reliability=scenario["reliability"],
        )
        for method_index, (method_name, mode, hard_prior, learn_reliability, learn_registration) in enumerate(method_specs, start=1):
            run_seed = args.seed + scenario_index * 100 + method_index
            set_seed(run_seed)
            if mode == "hard":
                # solver.py flips the reconstructed image vertically before
                # returning it; priors must be transformed into that same
                # internal coordinate system.
                prior_mask = np.flipud(scenario["hard_mask"]).copy()
                reliability = None
                geo_lambda = 0.0
            elif mode == "soft":
                prior_mask = np.flipud(scenario["mask"]).copy()
                reliability = np.ones_like(prior_mask, dtype=np.float64)
                geo_lambda = args.geo_lambda
            elif mode == "reliability_fixed":
                prior_mask = np.flipud(scenario["mask"]).copy()
                reliability = np.flipud(scenario["reliability"]).copy()
                geo_lambda = args.geo_lambda
            elif mode == "registration":
                prior_mask = np.flipud(scenario["mask"]).copy()
                reliability = np.flipud(scenario["reliability"]).copy()
                geo_lambda = args.geo_lambda
            elif mode == "registration_fallback":
                prior_mask = np.flipud(scenario["mask"]).copy()
                reliability = np.flipud(scenario["reliability"]).copy()
                # The fallback gate itself is the geometric prior; adding a
                # second outside-support penalty would double-count it and
                # suppress the EIT branch.
                geo_lambda = 0.0
            else:
                prior_mask = np.flipud(scenario["mask"]).copy()
                reliability = np.flipud(scenario["reliability"]).copy()
                geo_lambda = args.geo_lambda
            reconstruction, details = solver.solve(
                str(input_path), 1, num_iter_override=args.num_iter,
                progress_every=args.progress_every, return_details=True,
                prior_mask=prior_mask, prior_reliability=reliability,
                geo_lambda=geo_lambda, hard_prior=hard_prior,
                learn_reliability=learn_reliability,
                reliability_reg=args.reliability_reg if learn_reliability else 0.0,
                learn_registration=learn_registration,
                registration_reg=args.registration_reg if learn_registration else 0.0,
                reliability_fallback=(mode == "registration_fallback"),
            )
            save_label_png(reconstruction, output_dir / f"{scenario_name}_{method_name}.png")
            if details.get("final_reliability") is not None:
                np.save(output_dir / f"{scenario_name}_{method_name}_final_reliability.npy", details["final_reliability"])
            if details.get("final_registration_raw") is not None:
                np.save(output_dir / f"{scenario_name}_{method_name}_final_registration_raw.npy", details["final_registration_raw"])
            np.save(output_dir / f"loss_{scenario_name}_{method_name}.npy", np.asarray(details["loss_history"]))
            rows.append({
                "scenario": scenario_name,
                "method": method_name,
                "seed": run_seed,
                "metrics": metrics(truth, reconstruction),
                "final_total_loss": details["final_total_loss"],
            })

    (output_dir / "summary.json").write_text(json.dumps({
        "experiment": "hard_vs_soft_vs_reliability_weighted_ultrasound_prior",
        "input": str(input_path),
        "truth": str(truth_path),
        "num_iter": args.num_iter,
        "geo_lambda": args.geo_lambda,
        "reliability_reg": args.reliability_reg,
        "registration_reg": args.registration_reg,
        "scenarios": list(scenarios),
        "rows": rows,
    }, ensure_ascii=False, indent=2), encoding="utf-8")

    # One visual summary per scenario: prior, truth, baseline, hard, soft,
    # fixed reliability, and learned reliability.
    plot_methods = [spec[0] for spec in method_specs]
    n_columns = 3 + len(plot_methods)
    figure, axes = plt.subplots(
        len(scenarios), n_columns,
        figsize=(3.5 * n_columns, 3.4 * len(scenarios)),
        squeeze=False,
        constrained_layout=True,
    )
    for row_index, scenario_name in enumerate(scenarios):
        scenario = scenarios[scenario_name]
        axes[row_index, 0].imshow(scenario["mask"], cmap="gray", vmin=0, vmax=1)
        axes[row_index, 0].set_title(f"{scenario_name}: US prior")
        axes[row_index, 1].imshow(truth, cmap="gray", vmin=0, vmax=2)
        axes[row_index, 1].set_title("Ground truth")
        axes[row_index, 2].imshow(np.asarray(Image.open(output_dir / "baseline_no_prior.png")), cmap="gray", vmin=0, vmax=255)
        axes[row_index, 2].set_title("No prior")
        for col, method_name in enumerate(plot_methods, start=3):
            image = np.asarray(Image.open(output_dir / f"{scenario_name}_{method_name}.png"))
            axes[row_index, col].imshow(image, cmap="gray", vmin=0, vmax=255)
            axes[row_index, col].set_title(method_name.replace("_", " "))
        for col in range(n_columns):
            axes[row_index, col].set_axis_off()
    figure.suptitle("Ultrasound-prior robustness pilot on KTC data1", fontsize=15)
    figure.savefig(output_dir / "comparison.png", dpi=220)
    plt.close(figure)
    print(f"Saved {output_dir / 'summary.json'}")
    print(f"Saved {output_dir / 'comparison.png'}")


if __name__ == "__main__":
    main()
