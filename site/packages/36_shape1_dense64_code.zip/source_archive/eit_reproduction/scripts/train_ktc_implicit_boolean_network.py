"""Train a multiresolution implicit-Boolean network for non-convex EIT.

The foreground is represented as

    inclusion = outer_support AND NOT inward_background.

Both terms are continuous implicit fields assembled from 4x4, 16x16 and
64x64 coefficient maps.  Bicubic interpolation of the coarse maps plays the
same role as a tensor-product spline basis, while the finest residual keeps
sharp re-entrant corners.  Unlike the earlier carve-only experiment, the
model may move the outer boundary, add missing lesion banks, and create deep
cutouts.  A symmetric bank/cutout loss prevents an apparent concavity gain by
shrinking the complete inclusion.
"""
from __future__ import annotations

import argparse
import json
import math
import random
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy.ndimage import distance_transform_edt, label as connected_components
from torch.utils.data import ConcatDataset, DataLoader, Dataset

from prepare_ktc_deep_concavity_stress import FAMILIES
from prepare_ktc_shape_dataset import signed_distance
from train_ktc_concavity_network import (
    DecoderStage,
    InputAdapter,
    PhysicsOperator,
    ResidualBlock,
    aggregate_rows,
    confusion_metrics,
    indentation_mask,
    save_focus_montage,
    save_real_montage,
    soft_dice_loss,
    write_rows,
)
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_highres_refiner import FrozenCoarseEnsemble, load_coarse_ensemble


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument(
        "--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz"
    )
    parser.add_argument(
        "--coarse-checkpoint",
        nargs="+",
        type=Path,
        default=[
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "boundary_best.pt",
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "indent_best.pt",
            root / "outputs" / "ktc_concavity_voltage_seed20260819" / "voltage_best.pt",
        ],
    )
    parser.add_argument("--coarse-weights", nargs="+", type=float, default=[0.30, 0.40, 0.30])
    parser.add_argument(
        "--output-dir", type=Path, default=root / "outputs" / "ktc_implicit_boolean_v1"
    )
    parser.add_argument("--epochs", type=int, default=54)
    parser.add_argument("--patience", type=int, default=12)
    parser.add_argument("--batch-size", type=int, default=20)
    parser.add_argument("--base-channels", type=int, default=24)
    parser.add_argument("--learning-rate", type=float, default=1.5e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--seed", type=int, default=20260829)
    parser.add_argument("--support-weight", type=float, default=0.32)
    parser.add_argument("--cutout-weight", type=float, default=0.52)
    parser.add_argument("--field-weight", type=float, default=0.30)
    parser.add_argument("--boundary-weight", type=float, default=0.36)
    parser.add_argument("--bank-weight", type=float, default=0.34)
    parser.add_argument(
        "--bank-field-weight",
        type=float,
        default=0.24,
        help="Supervise an explicit foreground-bank confidence field around inward cutouts.",
    )
    parser.add_argument(
        "--freeze-backbone",
        action="store_true",
        help="Freeze the existing reconstruction and train only the explicit bank head.",
    )
    parser.add_argument("--deep-cutout-weight", type=float, default=0.42)
    parser.add_argument(
        "--mouth-weight",
        type=float,
        default=0.0,
        help="Penalty for closing the cutout entrance where inward background meets the exterior.",
    )
    parser.add_argument(
        "--mouth-contact-weight",
        type=float,
        default=0.0,
        help="Penalty for foreground probability specifically at the true support/cutout contact.",
    )
    parser.add_argument(
        "--mouth-cutout-weight",
        type=float,
        default=0.0,
        help="Penalty for low cutout probability at the true support/cutout contact.",
    )
    parser.add_argument(
        "--mouth-field-weight",
        type=float,
        default=0.0,
        help="Explicit contact-field supervision for the stress split.",
    )
    parser.add_argument(
        "--external-connectivity",
        action="store_true",
        help="Decode foreground as support minus a differentiably mouth-connected cutout.",
    )
    parser.add_argument(
        "--connectivity-steps",
        type=int,
        default=28,
        help="Soft flood-fill iterations used by the external-connectivity decoder.",
    )
    parser.add_argument("--containment-weight", type=float, default=0.08)
    parser.add_argument("--conductivity-weight", type=float, default=0.18)
    parser.add_argument("--physics-weight", type=float, default=1.5e-4)
    parser.add_argument(
        "--topology-weight",
        type=float,
        default=0.0,
        help="Soft clDice weight for the inward-background skeleton.",
    )
    parser.add_argument("--topology-iterations", type=int, default=10)
    parser.add_argument(
        "--selection-profile",
        choices=("balanced", "topology"),
        default="balanced",
        help="Topology selection prioritizes open deep cutouts without dropping bank retention.",
    )
    parser.add_argument(
        "--initial-checkpoint",
        type=Path,
        default=None,
        help="Optional compatible implicit-Boolean checkpoint used for topology fine-tuning.",
    )
    parser.add_argument("--progress-every", type=int, default=1)
    parser.add_argument(
        "--stress-repeat",
        type=int,
        default=1,
        help="Repeat the independent non-convex stress split in the training mixture.",
    )
    parser.add_argument(
        "--min-selection-bank",
        type=float,
        default=0.0,
        help="Only validation checkpoints at or above this stress bank retention can be selected.",
    )
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


@dataclass
class StructuralArrays:
    images: np.ndarray
    voltages: np.ndarray
    clean_voltages: np.ndarray
    labels: np.ndarray
    delta: np.ndarray
    support: np.ndarray
    cutout: np.ndarray
    support_sdf: np.ndarray
    cutout_sdf: np.ndarray
    cutout_depth: np.ndarray
    indentation: np.ndarray
    family_codes: np.ndarray


def prepare_structural_arrays(archive: np.lib.npyio.NpzFile, name: str) -> StructuralArrays:
    labels = np.asarray(archive["labels"], dtype=np.uint8)
    indentation = np.asarray(archive["indentation_masks"], dtype=np.uint8)
    if "support_masks" in archive.files:
        support = np.asarray(archive["support_masks"], dtype=np.uint8)
        cutout = np.asarray(archive["cutout_masks"], dtype=np.uint8)
        support_sdf = np.asarray(archive["support_signed_distance"], dtype=np.float32)
        cutout_sdf = np.asarray(archive["cutout_signed_distance"], dtype=np.float32)
        cutout_depth = np.asarray(archive["cutout_depth_weights"], dtype=np.float32)
        family_codes = np.asarray(archive["family_codes"], dtype=np.int16)
    else:
        foreground = labels != 0
        support = np.logical_or(foreground, indentation != 0).astype(np.uint8)
        cutout = indentation.copy()
        support_sdf = np.empty(labels.shape, dtype=np.float32)
        cutout_sdf = np.empty(labels.shape, dtype=np.float32)
        cutout_depth = np.empty(labels.shape, dtype=np.float32)
        print(f"precomputing implicit targets for {name}: {len(labels)} samples", flush=True)
        for index in range(len(labels)):
            support_sdf[index] = signed_distance(support[index])
            cutout_sdf[index] = signed_distance(cutout[index])
            depth = distance_transform_edt(cutout[index] != 0)
            cutout_depth[index] = depth / max(float(depth.max()), 1.0)
        family_codes = np.full(len(labels), -1, dtype=np.int16)
    return StructuralArrays(
        images=np.asarray(archive["linear_images"], dtype=np.float32),
        voltages=np.asarray(archive["voltages"], dtype=np.float32),
        clean_voltages=np.asarray(archive["clean_voltages"], dtype=np.float32),
        labels=labels,
        delta=np.asarray(archive["delta"], dtype=np.float32),
        support=support,
        cutout=cutout,
        support_sdf=support_sdf,
        cutout_sdf=cutout_sdf,
        cutout_depth=cutout_depth,
        indentation=indentation,
        family_codes=family_codes,
    )


class StructuralDataset(Dataset):
    def __init__(self, arrays: StructuralArrays, indices: np.ndarray, source: int) -> None:
        self.arrays = arrays
        self.indices = np.asarray(indices, dtype=np.int64)
        self.source = source

    def __len__(self) -> int:
        return int(self.indices.size)

    def __getitem__(self, item: int) -> dict[str, torch.Tensor]:
        index = int(self.indices[item])
        a = self.arrays
        return {
            "image": torch.from_numpy(a.images[index][None]),
            "voltage": torch.from_numpy(a.voltages[index]),
            "clean_voltage": torch.from_numpy(a.clean_voltages[index]),
            "labels": torch.from_numpy(a.labels[index].astype(np.int64)),
            "delta": torch.from_numpy(a.delta[index][None]),
            "support": torch.from_numpy(a.support[index].astype(np.float32)[None]),
            "cutout": torch.from_numpy(a.cutout[index].astype(np.float32)[None]),
            "support_sdf": torch.from_numpy(a.support_sdf[index][None]),
            "cutout_sdf": torch.from_numpy(a.cutout_sdf[index][None]),
            "cutout_depth": torch.from_numpy(a.cutout_depth[index][None]),
            "indent": torch.from_numpy(a.indentation[index].astype(np.float32)[None]),
            "family": torch.tensor(int(a.family_codes[index]), dtype=torch.int64),
            "index": torch.tensor(index, dtype=torch.int64),
            "source": torch.tensor(self.source, dtype=torch.int64),
        }


class VoltageEncoder(nn.Module):
    def __init__(self, base: int) -> None:
        super().__init__()
        self.features = nn.Sequential(
            ResidualBlock(1, base),
            nn.Conv2d(base, base * 2, 3, stride=2, padding=1, bias=False),
            ResidualBlock(base * 2, base * 2),
            nn.Conv2d(base * 2, base * 4, 3, stride=2, padding=1, bias=False),
            ResidualBlock(base * 4, base * 4),
            nn.Conv2d(base * 4, base * 8, 3, stride=2, padding=1, bias=False),
            ResidualBlock(base * 8, base * 8),
        )
        self.projection = nn.Conv2d(base * 8, base * 16, 1)

    def forward(self, voltage: torch.Tensor) -> torch.Tensor:
        centered = voltage - voltage.median(dim=1, keepdim=True).values
        scale = torch.quantile(centered.abs(), 0.985, dim=1, keepdim=True).clamp_min(1e-6)
        table = torch.clamp(centered / scale, -4.0, 4.0).reshape(-1, 1, 76, 31) / 4.0
        encoded = self.features(table)
        return self.projection(F.adaptive_avg_pool2d(encoded, (4, 4)))


class ImplicitFieldHead(nn.Module):
    """Assemble a continuous field from coarse spline-like coefficient maps."""

    def __init__(self, base: int) -> None:
        super().__init__()
        self.coarse = nn.Conv2d(base * 16, 1, 1)
        self.middle = nn.Conv2d(base * 4, 1, 1)
        self.fine = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))
        nn.init.zeros_(self.coarse.weight)
        nn.init.zeros_(self.coarse.bias)
        nn.init.zeros_(self.middle.weight)
        nn.init.zeros_(self.middle.bias)
        nn.init.zeros_(self.fine[-1].weight)
        nn.init.zeros_(self.fine[-1].bias)

    def forward(self, bottleneck: torch.Tensor, middle: torch.Tensor, fine: torch.Tensor) -> torch.Tensor:
        size = fine.shape[-2:]
        coarse = F.interpolate(self.coarse(bottleneck), size=size, mode="bicubic", align_corners=False)
        middle_field = F.interpolate(self.middle(middle), size=size, mode="bicubic", align_corners=False)
        return 1.15 * torch.tanh(coarse) + 0.85 * torch.tanh(middle_field) + 0.55 * torch.tanh(self.fine(fine))


class ImplicitBooleanNet(nn.Module):
    def __init__(self, base: int) -> None:
        super().__init__()
        self.base = base
        self.stem = ResidualBlock(6, base)
        self.enc1 = ResidualBlock(base, base * 2)
        self.enc2 = ResidualBlock(base * 2, base * 4)
        self.enc3 = ResidualBlock(base * 4, base * 8)
        self.bottleneck = nn.Sequential(
            ResidualBlock(base * 8, base * 16),
            nn.Dropout2d(0.10),
            ResidualBlock(base * 16, base * 16),
        )
        self.voltage = VoltageEncoder(base)
        self.voltage_gate = nn.Parameter(torch.tensor(-1.5))
        self.dec3 = DecoderStage(base * 16, base * 8, base * 8)
        self.dec2 = DecoderStage(base * 8, base * 4, base * 4)
        self.dec1 = DecoderStage(base * 4, base * 2, base * 2)
        self.dec0 = DecoderStage(base * 2, base, base)
        self.support_field = ImplicitFieldHead(base)
        self.cutout_field = ImplicitFieldHead(base)
        self.polarity = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 2, 1))
        self.mouth_head = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))
        # Explicit bank confidence prevents the topology decoder from treating
        # every high cutout response as removable material.  It is trained on
        # the foreground immediately adjacent to the true inward background.
        self.bank_head = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))
        self.amplitudes = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(base * 16, 2))
        self.contrast_residual = nn.Conv2d(base, 1, 1)
        self.use_external_connectivity = False
        self.connectivity_steps = 28
        nn.init.zeros_(self.polarity[-1].weight)
        nn.init.zeros_(self.polarity[-1].bias)
        nn.init.zeros_(self.contrast_residual.weight)
        nn.init.zeros_(self.contrast_residual.bias)
        nn.init.zeros_(self.mouth_head[-1].weight)
        nn.init.constant_(self.mouth_head[-1].bias, -3.0)
        nn.init.zeros_(self.bank_head[-1].weight)
        nn.init.constant_(self.bank_head[-1].bias, -2.0)

    def forward(
        self,
        adapted_image: torch.Tensor,
        voltage: torch.Tensor,
        coarse_probability: torch.Tensor,
        *,
        cutout_bias: float = -1.25,
        support_residual_scale: float = 1.0,
        cutout_residual_scale: float = 1.0,
    ) -> dict[str, torch.Tensor]:
        e0 = self.stem(torch.cat((adapted_image, coarse_probability), dim=1))
        e1 = self.enc1(F.max_pool2d(e0, 2))
        e2 = self.enc2(F.max_pool2d(e1, 2))
        e3 = self.enc3(F.max_pool2d(e2, 2))
        bottleneck = self.bottleneck(F.max_pool2d(e3, 2))
        bottleneck = bottleneck + torch.sigmoid(self.voltage_gate) * self.voltage(voltage)
        d3 = self.dec3(bottleneck, e3)
        d2 = self.dec2(d3, e2)
        d1 = self.dec1(d2, e1)
        fine = self.dec0(d1, e0)

        coarse_foreground = coarse_probability[:, 1:].sum(dim=1, keepdim=True).clamp(1e-5, 1.0 - 1e-5)
        coarse_field = torch.clamp(torch.logit(coarse_foreground) / 3.0, -1.5, 1.5)
        support_residual = self.support_field(bottleneck, d2, fine)
        cutout_residual = self.cutout_field(bottleneck, d2, fine)
        support_field = 0.55 * coarse_field + support_residual_scale * support_residual
        cutout_field = cutout_bias + cutout_residual_scale * cutout_residual
        temperature = 0.36
        support_probability = torch.sigmoid(support_field / temperature)
        cutout_probability = torch.sigmoid(cutout_field / temperature)
        mouth_field = self.mouth_head(fine)
        mouth_probability = torch.sigmoid(mouth_field / temperature)
        bank_field = self.bank_head(fine)
        bank_probability = torch.sigmoid(bank_field / temperature)
        if self.use_external_connectivity:
            # Soft flood fill: only cutout pixels reachable from a predicted
            # mouth can remove material. This is differentiable and mirrors
            # the exterior-connected component used at evaluation time.
            reachable = (cutout_probability * mouth_probability).clamp(0.0, 1.0)
            for _ in range(max(1, int(self.connectivity_steps))):
                reachable = torch.maximum(
                    reachable,
                    F.max_pool2d(reachable, 3, stride=1, padding=1) * cutout_probability,
                )
            external_cutout_probability = cutout_probability * reachable
        else:
            external_cutout_probability = cutout_probability
        foreground_probability = (support_probability * (1.0 - external_cutout_probability)).clamp(1e-6, 1.0 - 1e-6)

        coarse_polarity = coarse_probability[:, 1:].clamp_min(1e-6)
        coarse_polarity = coarse_polarity / coarse_polarity.sum(dim=1, keepdim=True)
        polarity = torch.softmax(torch.log(coarse_polarity) + self.polarity(fine), dim=1)
        probabilities = torch.cat(
            (
                1.0 - foreground_probability,
                foreground_probability * polarity[:, 0:1],
                foreground_probability * polarity[:, 1:2],
            ),
            dim=1,
        ).clamp_min(1e-7)
        amplitude_raw = self.amplitudes(bottleneck)
        negative = 0.08 + 0.88 * torch.sigmoid(amplitude_raw[:, 0:1, None, None])
        positive = 0.08 + 1.10 * torch.sigmoid(amplitude_raw[:, 1:2, None, None])
        delta = foreground_probability * (
            -negative * polarity[:, 0:1] + positive * polarity[:, 1:2]
        )
        delta = delta + foreground_probability * 0.18 * torch.tanh(self.contrast_residual(fine))
        return {
            "logits": torch.log(probabilities),
            "probabilities": probabilities,
            "support_field": support_field,
            "cutout_field": cutout_field,
            "coarse_field": coarse_field,
            "support_residual": support_residual,
            "cutout_residual": cutout_residual,
            "polarity_probability": polarity,
            "support_probability": support_probability,
            "cutout_probability": cutout_probability,
            "external_cutout_probability": external_cutout_probability,
            "mouth_field": mouth_field,
            "mouth_probability": mouth_probability,
            "bank_field": bank_field,
            "bank_probability": bank_probability,
            "foreground_probability": foreground_probability,
            "delta": delta,
        }


def gradients(image: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    return image[:, :, 1:, :] - image[:, :, :-1, :], image[:, :, :, 1:] - image[:, :, :, :-1]


def masked_mean(value: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    numerator = (value * mask).sum(dim=(1, 2, 3))
    denominator = mask.sum(dim=(1, 2, 3))
    valid = denominator > 0
    per_case = numerator / denominator.clamp_min(1.0)
    return per_case[valid].mean() if valid.any() else value.new_zeros(())


def balanced_bce(
    logits: torch.Tensor,
    target: torch.Tensor,
    domain: torch.Tensor,
    positive_weight: torch.Tensor | None = None,
) -> torch.Tensor:
    raw = F.binary_cross_entropy_with_logits(logits, target, reduction="none") * domain
    positive = target * domain
    negative = (1.0 - target) * domain
    if positive_weight is None:
        positive_weight = torch.ones_like(target)
    positive_loss = (raw * positive * positive_weight).sum(dim=(1, 2, 3)) / (
        positive * positive_weight
    ).sum(dim=(1, 2, 3)).clamp_min(1.0)
    negative_loss = (raw * negative).sum(dim=(1, 2, 3)) / negative.sum(dim=(1, 2, 3)).clamp_min(1.0)
    has_positive = positive.sum(dim=(1, 2, 3)) > 0
    per_case = torch.where(has_positive, 0.5 * (positive_loss + negative_loss), negative_loss)
    return per_case.mean()


def soft_erode(image: torch.Tensor) -> torch.Tensor:
    vertical = -F.max_pool2d(-image, kernel_size=(3, 1), stride=1, padding=(1, 0))
    horizontal = -F.max_pool2d(-image, kernel_size=(1, 3), stride=1, padding=(0, 1))
    return torch.minimum(vertical, horizontal)


def soft_open(image: torch.Tensor) -> torch.Tensor:
    return F.max_pool2d(soft_erode(image), kernel_size=3, stride=1, padding=1)


def soft_skeleton(image: torch.Tensor, iterations: int) -> torch.Tensor:
    opened = soft_open(image)
    skeleton = F.relu(image - opened)
    eroded = image
    for _ in range(iterations):
        eroded = soft_erode(eroded)
        delta = F.relu(eroded - soft_open(eroded))
        skeleton = skeleton + F.relu(delta - skeleton * delta)
    return skeleton


def cutout_topology_loss(
    probability: torch.Tensor,
    target: torch.Tensor,
    domain: torch.Tensor,
    iterations: int,
) -> torch.Tensor:
    """Soft clDice on the background channel that enters the outer support."""
    prediction = probability * domain
    truth = target * domain
    prediction_skeleton = soft_skeleton(prediction, iterations)
    truth_skeleton = soft_skeleton(truth, iterations)
    dims = (1, 2, 3)
    precision = (prediction_skeleton * truth).sum(dim=dims) / prediction_skeleton.sum(dim=dims).clamp_min(1e-6)
    sensitivity = (truth_skeleton * prediction).sum(dim=dims) / truth_skeleton.sum(dim=dims).clamp_min(1e-6)
    cldice = (2.0 * precision * sensitivity) / (precision + sensitivity).clamp_min(1e-6)
    valid = truth.sum(dim=dims) > 0
    return (1.0 - cldice[valid]).mean() if valid.any() else probability.new_zeros(())


def compute_loss(
    outputs: dict[str, torch.Tensor],
    batch: dict[str, torch.Tensor],
    physics: PhysicsOperator,
    args: argparse.Namespace,
    ramp: float,
) -> tuple[torch.Tensor, dict[str, float]]:
    labels = batch["labels"]
    logits = outputs["logits"]
    class_weights = logits.new_tensor((0.35, 1.25, 1.25))
    segmentation = F.nll_loss(logits, labels, weight=class_weights) + soft_dice_loss(logits, labels)
    support = batch["support"]
    cutout = batch["cutout"]
    support_loss = balanced_bce(outputs["support_field"] / 0.36, support, torch.ones_like(support))
    cutout_domain = F.max_pool2d(support, 11, stride=1, padding=5)
    depth_weight = 1.0 + 3.0 * batch["cutout_depth"]
    cutout_loss = balanced_bce(outputs["cutout_field"] / 0.36, cutout, cutout_domain, depth_weight)
    topology = cutout_topology_loss(
        outputs["cutout_probability"], cutout, cutout_domain, args.topology_iterations
    )
    field_loss = F.smooth_l1_loss(torch.tanh(outputs["support_field"]), batch["support_sdf"], beta=0.08)
    field_loss = field_loss + masked_mean(
        F.smooth_l1_loss(torch.tanh(outputs["cutout_field"]), batch["cutout_sdf"], beta=0.08, reduction="none"),
        cutout_domain,
    )
    target_foreground = (labels != 0).float().unsqueeze(1)
    pred_dy, pred_dx = gradients(outputs["foreground_probability"])
    true_dy, true_dx = gradients(target_foreground)
    boundary = F.l1_loss(pred_dy, true_dy) + F.l1_loss(pred_dx, true_dx)
    notch_rim = cutout * F.max_pool2d(target_foreground, 11, stride=1, padding=5)
    banks = target_foreground * F.max_pool2d(cutout, 11, stride=1, padding=5)
    false_fill = masked_mean(outputs["foreground_probability"], notch_rim * depth_weight)
    false_cut = masked_mean(1.0 - outputs["foreground_probability"], banks)
    exterior_near_support = F.max_pool2d(1.0 - support, 5, stride=1, padding=2)
    mouth = cutout * exterior_near_support
    mouth_corridor = cutout * F.max_pool2d(mouth, 7, stride=1, padding=3)
    mouth_closure = masked_mean(outputs["foreground_probability"], mouth_corridor)
    # A contact target is more precise than a wide corridor: it marks the
    # support pixels where a generated opening reaches the outside.  The
    # stress gate keeps this topology-specific objective from changing the
    # ordinary convex/non-convex base distribution.
    support_boundary = support * exterior_near_support
    mouth_contact = cutout * support_boundary
    stress_gate = batch["source"].to(outputs["foreground_probability"].dtype).view(-1, 1, 1, 1)
    mouth_contact = mouth_contact * stress_gate
    mouth_contact_closure = masked_mean(outputs["foreground_probability"], mouth_contact)
    mouth_contact_cutout = masked_mean(1.0 - outputs["cutout_probability"], mouth_contact)
    mouth_domain = F.max_pool2d(support_boundary * stress_gate, 9, stride=1, padding=4)
    mouth_field_loss = balanced_bce(
        outputs["mouth_field"] / 0.36,
        mouth_contact,
        mouth_domain,
    )
    # The bank target is the foreground ring next to the generated inward
    # background.  Restricting its domain to a local support neighborhood
    # keeps this head focused on the pixels that must survive a cutout.
    bank_target = banks
    bank_domain = F.max_pool2d(cutout, 13, stride=1, padding=6)
    bank_field_loss = balanced_bce(
        outputs["bank_field"] / 0.36,
        bank_target,
        bank_domain,
    )
    containment = masked_mean(outputs["cutout_probability"], 1.0 - F.max_pool2d(support, 7, stride=1, padding=3))
    conductivity = F.smooth_l1_loss(outputs["delta"], batch["delta"], beta=0.08)
    physical = physics.loss(outputs["delta"], batch["clean_voltage"])
    total = segmentation + ramp * (
        args.support_weight * support_loss
        + args.cutout_weight * cutout_loss
        + args.field_weight * field_loss
        + args.boundary_weight * boundary
        + args.bank_weight * false_cut
        + args.deep_cutout_weight * false_fill
        + args.mouth_weight * mouth_closure
        + args.mouth_contact_weight * mouth_contact_closure
        + args.mouth_cutout_weight * mouth_contact_cutout
        + args.mouth_field_weight * mouth_field_loss
        + args.bank_field_weight * bank_field_loss
        + args.topology_weight * topology
        + args.containment_weight * containment
        + args.conductivity_weight * conductivity
        + args.physics_weight * physical
    )
    pieces = {
        "total": total,
        "segmentation": segmentation,
        "support": support_loss,
        "cutout": cutout_loss,
        "topology": topology,
        "field": field_loss,
        "boundary": boundary,
        "false_fill": false_fill,
        "false_cut": false_cut,
        "mouth_closure": mouth_closure,
        "mouth_contact_closure": mouth_contact_closure,
        "mouth_contact_cutout": mouth_contact_cutout,
        "mouth_field": mouth_field_loss,
        "bank_field": bank_field_loss,
        "containment": containment,
        "conductivity": conductivity,
        "physics": physical,
    }
    return total, {key: float(value.detach()) for key, value in pieces.items()}


@torch.no_grad()
def coarse_probability(
    coarse: FrozenCoarseEnsemble, adapted: torch.Tensor, voltage: torch.Tensor
) -> torch.Tensor:
    return torch.softmax(coarse(adapted, voltage)["logits"], dim=1)


@torch.no_grad()
def predict_loader(
    coarse: FrozenCoarseEnsemble,
    model: ImplicitBooleanNet,
    adapter: InputAdapter,
    loader: DataLoader,
    device: torch.device,
) -> tuple[np.ndarray, np.ndarray]:
    coarse_predictions: list[np.ndarray] = []
    predictions: list[np.ndarray] = []
    model.eval()
    for batch in loader:
        image = adapter(batch["image"].to(device))
        voltage = batch["voltage"].to(device)
        base = coarse_probability(coarse, image, voltage)
        output = model(image, voltage, base)
        coarse_predictions.append(base.argmax(dim=1).cpu().numpy().astype(np.uint8))
        predictions.append(output["logits"].argmax(dim=1).cpu().numpy().astype(np.uint8))
    return np.concatenate(coarse_predictions), np.concatenate(predictions)


def standard_metrics(truths: np.ndarray, predictions: np.ndarray, indentations: np.ndarray) -> dict[str, float]:
    return aggregate_rows(
        [confusion_metrics(t, p, i) for t, p, i in zip(truths, predictions, indentations)]
    )


def stress_metrics(
    truths: np.ndarray,
    predictions: np.ndarray,
    cutouts: np.ndarray,
    depths: np.ndarray,
    family_codes: np.ndarray,
) -> tuple[dict[str, float], dict[str, dict[str, float]], list[dict[str, float]]]:
    rows: list[dict[str, float]] = []
    for truth, prediction, cutout, depth, family in zip(truths, predictions, cutouts, depths, family_codes):
        row = confusion_metrics(truth, prediction, cutout)
        background = prediction == 0
        foreground = prediction != 0
        target_foreground = truth != 0
        cutout_bool = cutout != 0
        depth_weight = cutout_bool * (1.0 + 3.0 * depth)
        bank = target_foreground & (distance_transform_edt(~cutout_bool) <= 3.0)
        row["cutout_recovery"] = float((background & cutout_bool).sum() / max(1, int(cutout_bool.sum())))
        row["deep_cutout_recovery"] = float((background * depth_weight).sum() / max(1e-6, float(depth_weight.sum())))
        background_components, _ = connected_components(
            background, structure=np.ones((3, 3), dtype=np.uint8)
        )
        border_labels = np.unique(
            np.concatenate(
                (
                    background_components[0],
                    background_components[-1],
                    background_components[:, 0],
                    background_components[:, -1],
                )
            )
        )
        exterior_background = np.isin(background_components, border_labels[border_labels != 0])
        row["open_cutout_recovery"] = float(
            (exterior_background & cutout_bool).sum() / max(1, int(cutout_bool.sum()))
        )
        row["open_deep_cutout_recovery"] = float(
            (exterior_background * depth_weight).sum() / max(1e-6, float(depth_weight.sum()))
        )
        row["cutout_connectivity"] = float(
            (exterior_background & background & cutout_bool).sum()
            / max(1, int((background & cutout_bool).sum()))
        )
        row["bank_retention"] = float((foreground & bank).sum() / max(1, int(bank.sum())))
        row["structural_joint"] = float(
            max(row["foreground_iou"], 1e-8)
            * max(row["deep_cutout_recovery"], 1e-8)
            * max(row["bank_retention"], 1e-8)
        ) ** (1.0 / 3.0)
        row["topology_structural_joint"] = float(
            max(row["foreground_iou"], 1e-8)
            * max(row["open_deep_cutout_recovery"], 1e-8)
            * max(row["bank_retention"], 1e-8)
        ) ** (1.0 / 3.0)
        row["family"] = float(family)
        rows.append(row)
    overall = aggregate_rows([{k: v for k, v in row.items() if k != "family"} for row in rows])
    by_family: dict[str, dict[str, float]] = {}
    for code, family in enumerate(FAMILIES):
        selected = [{k: v for k, v in row.items() if k != "family"} for row in rows if int(row["family"]) == code]
        by_family[family] = aggregate_rows(selected) if selected else {}
    return overall, by_family, rows


def validation_score(
    base_metrics: dict[str, float], stress: dict[str, float], profile: str = "balanced"
) -> float:
    if profile == "topology":
        return float(
            0.15 * base_metrics["foreground_iou"]
            + 0.10 * base_metrics["boundary_f1"]
            + 0.15 * stress["foreground_iou"]
            + 0.10 * stress["boundary_f1"]
            + 0.25 * stress["topology_structural_joint"]
            + 0.15 * stress["open_deep_cutout_recovery"]
            + 0.10 * stress["bank_retention"]
        )
    return float(
        0.30 * base_metrics["foreground_iou"]
        + 0.20 * base_metrics["boundary_f1"]
        + 0.20 * stress["foreground_iou"]
        + 0.15 * stress["boundary_f1"]
        + 0.15 * stress["structural_joint"]
    )


def save_stress_montage(
    path: Path,
    truths: np.ndarray,
    coarse: np.ndarray,
    predictions: np.ndarray,
    cutouts: np.ndarray,
    family_codes: np.ndarray,
    title: str,
) -> None:
    indices = [
        next((i for i, value in enumerate(family_codes) if int(value) == code), None)
        for code in range(len(FAMILIES))
    ]
    indices = [index for index in indices if index is not None]
    if not indices:
        return
    figure, axes = plt.subplots(len(indices), 4, figsize=(10.0, 2.3 * len(indices)), squeeze=False)
    for row, index in enumerate(indices):
        images = (
            (truths[index], f"{FAMILIES[int(family_codes[index])]} truth"),
            (coarse[index], "coarse fusion"),
            (predictions[index], "implicit Boolean"),
            (cutouts[index], "target inward background"),
        )
        for column, (image, name) in enumerate(images):
            axes[row, column].imshow(image, cmap="viridis", vmin=0, vmax=2, interpolation="nearest")
            axes[row, column].set_title(name)
            axes[row, column].set_axis_off()
    figure.suptitle(title)
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def train_model(
    base_archive: np.lib.npyio.NpzFile,
    stress_archive: np.lib.npyio.NpzFile,
    base_arrays: StructuralArrays,
    stress_arrays: StructuralArrays,
    coarse: FrozenCoarseEnsemble,
    adapter: InputAdapter,
    args: argparse.Namespace,
    output_dir: Path,
    device: torch.device,
) -> tuple[ImplicitBooleanNet, list[dict[str, float]]]:
    base_training = StructuralDataset(base_arrays, base_archive["train_indices"], 0)
    stress_training = StructuralDataset(stress_arrays, stress_archive["train_indices"], 1)
    stress_repeats = max(1, int(args.stress_repeat))
    training = ConcatDataset((base_training, *([stress_training] * stress_repeats)))
    train_loader = DataLoader(
        training,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.workers,
        pin_memory=device.type == "cuda",
        drop_last=True,
    )
    base_validation_indices = np.asarray(base_archive["validation_indices"], dtype=np.int64)
    stress_validation_indices = np.asarray(stress_archive["validation_indices"], dtype=np.int64)
    base_validation_loader = DataLoader(
        StructuralDataset(base_arrays, base_validation_indices, 0),
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.workers,
    )
    stress_validation_loader = DataLoader(
        StructuralDataset(stress_arrays, stress_validation_indices, 1),
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.workers,
    )
    model = ImplicitBooleanNet(args.base_channels).to(device)
    model.use_external_connectivity = bool(args.external_connectivity)
    model.connectivity_steps = int(args.connectivity_steps)
    if args.initial_checkpoint is not None:
        initial = torch.load(args.initial_checkpoint.resolve(), map_location=device, weights_only=False)
        model.load_state_dict(initial["model"], strict=False)
        print(f"topology fine-tuning from {args.initial_checkpoint.resolve()}", flush=True)
    if args.freeze_backbone:
        for name, parameter in model.named_parameters():
            parameter.requires_grad = name.startswith("bank_head.")
        print("freeze-backbone enabled: optimizing only bank_head", flush=True)
    optimizer = torch.optim.AdamW(
        [parameter for parameter in model.parameters() if parameter.requires_grad],
        lr=args.learning_rate,
        weight_decay=args.weight_decay,
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    physics = PhysicsOperator(
        jacobian=torch.from_numpy(np.asarray(base_archive["jacobian"], dtype=np.float32)).to(device),
        node_to_raw_pixel=torch.from_numpy(
            np.asarray(base_archive["node_to_raw_pixel"], dtype=np.int64)
        ).to(device),
        voltage_scale=2.0,
    )
    best_score = -math.inf
    stale = 0
    history: list[dict[str, float]] = []
    checkpoint_path = output_dir / "implicit_boolean_best.pt"
    for epoch in range(1, args.epochs + 1):
        model.train()
        pieces: dict[str, list[float]] = {}
        ramp = min(1.0, epoch / max(6.0, 0.18 * args.epochs))
        for batch in train_loader:
            image = adapter(batch["image"].to(device, non_blocking=True))
            voltage = batch["voltage"].to(device, non_blocking=True)
            with torch.no_grad():
                base_probability = coarse_probability(coarse, image, voltage)
            moved = {
                key: value.to(device, non_blocking=True) if isinstance(value, torch.Tensor) else value
                for key, value in batch.items()
            }
            optimizer.zero_grad(set_to_none=True)
            with torch.amp.autocast("cuda", enabled=device.type == "cuda"):
                outputs = model(image, voltage, base_probability)
                loss, batch_pieces = compute_loss(outputs, moved, physics, args, ramp)
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            scaler.step(optimizer)
            scaler.update()
            for key, value in batch_pieces.items():
                pieces.setdefault(key, []).append(value)
        scheduler.step()
        base_coarse, base_prediction = predict_loader(
            coarse, model, adapter, base_validation_loader, device
        )
        stress_coarse, stress_prediction = predict_loader(
            coarse, model, adapter, stress_validation_loader, device
        )
        base_metrics = standard_metrics(
            base_arrays.labels[base_validation_indices],
            base_prediction,
            base_arrays.indentation[base_validation_indices],
        )
        stress_summary, _, _ = stress_metrics(
            stress_arrays.labels[stress_validation_indices],
            stress_prediction,
            stress_arrays.cutout[stress_validation_indices],
            stress_arrays.cutout_depth[stress_validation_indices],
            stress_arrays.family_codes[stress_validation_indices],
        )
        score = validation_score(base_metrics, stress_summary, args.selection_profile)
        # With a frozen reconstruction backbone the validation segmentation
        # score is intentionally constant; use epoch as a deterministic tie
        # breaker so the final bank head, rather than its random initialization,
        # is retained.
        if args.freeze_backbone:
            score += epoch * 1e-6
        if stress_summary["bank_retention"] < args.min_selection_bank:
            score = -math.inf
        record = {
            "epoch": float(epoch),
            "score": score,
            "base_iou": base_metrics["foreground_iou"],
            "base_boundary": base_metrics["boundary_f1"],
            "stress_iou": stress_summary["foreground_iou"],
            "stress_boundary": stress_summary["boundary_f1"],
            "stress_deep_cutout": stress_summary["deep_cutout_recovery"],
            "stress_open_deep_cutout": stress_summary["open_deep_cutout_recovery"],
            "stress_bank": stress_summary["bank_retention"],
            "stress_joint": stress_summary["structural_joint"],
            "stress_topology_joint": stress_summary["topology_structural_joint"],
            "learning_rate": float(optimizer.param_groups[0]["lr"]),
            **{f"train_{key}": float(np.mean(value)) for key, value in pieces.items()},
        }
        history.append(record)
        if args.progress_every and (epoch == 1 or epoch % args.progress_every == 0):
            print(
                f"epoch {epoch:03d}: score={score:.4f}, base IoU={record['base_iou']:.4f}, "
                f"stress IoU={record['stress_iou']:.4f}, deep={record['stress_deep_cutout']:.4f}, "
                f"open={record['stress_open_deep_cutout']:.4f}, bank={record['stress_bank']:.4f}, "
                f"topology={record['stress_topology_joint']:.4f}",
                flush=True,
            )
        if score > best_score + 1e-5:
            best_score = score
            stale = 0
            torch.save(
                {
                    "model": model.state_dict(),
                    "base_channels": args.base_channels,
                    "external_connectivity": bool(model.use_external_connectivity),
                    "connectivity_steps": int(model.connectivity_steps),
                    "epoch": epoch,
                    "validation_score": score,
                    "base_metrics": base_metrics,
                    "stress_metrics": stress_summary,
                },
                checkpoint_path,
            )
        else:
            stale += 1
            if stale >= args.patience:
                print(f"early stopping at epoch {epoch}; best={best_score:.4f}", flush=True)
                break
    state = torch.load(checkpoint_path, map_location=device, weights_only=False)
    model.load_state_dict(state["model"])
    model.eval()
    (output_dir / "training_history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    return model, history


@torch.no_grad()
def infer_real(
    coarse: FrozenCoarseEnsemble,
    model: ImplicitBooleanNet,
    adapter: InputAdapter,
    images: np.ndarray,
    voltages: np.ndarray,
    device: torch.device,
    batch_size: int,
) -> tuple[np.ndarray, np.ndarray]:
    coarse_result: list[np.ndarray] = []
    model_result: list[np.ndarray] = []
    for start in range(0, len(images), batch_size):
        image = torch.from_numpy(images[start : start + batch_size, None].astype(np.float32)).to(device)
        voltage = torch.from_numpy(voltages[start : start + batch_size].astype(np.float32)).to(device)
        adapted = adapter(image)
        base = coarse_probability(coarse, adapted, voltage)
        output = model(adapted, voltage, base)
        base_logits = F.interpolate(torch.log(base.clamp_min(1e-7)), size=(256, 256), mode="bilinear", align_corners=False)
        model_logits = F.interpolate(output["logits"], size=(256, 256), mode="bilinear", align_corners=False)
        coarse_result.append(base_logits.argmax(dim=1).cpu().numpy().astype(np.uint8))
        model_result.append(model_logits.argmax(dim=1).cpu().numpy().astype(np.uint8))
    return np.concatenate(coarse_result), np.concatenate(model_result)


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    base_archive = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress_archive = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    base_arrays = prepare_structural_arrays(base_archive, "base nonlinear CEM")
    stress_arrays = prepare_structural_arrays(stress_archive, "deep-concavity stress")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    coarse, coarse_states, coarse_weights = load_coarse_ensemble(
        args.coarse_checkpoint, args.coarse_weights, device
    )
    adapter = InputAdapter(base_archive["fov_mask"]).to(device)
    print(
        f"device={device}; base train={len(base_archive['train_indices'])}; "
        f"stress train={len(stress_archive['train_indices'])}; coarse={coarse_weights}",
        flush=True,
    )
    model, history = train_model(
        base_archive,
        stress_archive,
        base_arrays,
        stress_arrays,
        coarse,
        adapter,
        args,
        output_dir,
        device,
    )

    base_test_indices = np.asarray(base_archive["test_indices"], dtype=np.int64)
    stress_test_indices = np.asarray(stress_archive["test_indices"], dtype=np.int64)
    base_test_loader = DataLoader(
        StructuralDataset(base_arrays, base_test_indices, 0), batch_size=args.batch_size, shuffle=False
    )
    stress_test_loader = DataLoader(
        StructuralDataset(stress_arrays, stress_test_indices, 1), batch_size=args.batch_size, shuffle=False
    )
    base_coarse, base_prediction = predict_loader(coarse, model, adapter, base_test_loader, device)
    stress_coarse, stress_prediction = predict_loader(coarse, model, adapter, stress_test_loader, device)
    base_test = {
        "coarse_fusion": standard_metrics(
            base_arrays.labels[base_test_indices], base_coarse, base_arrays.indentation[base_test_indices]
        ),
        "implicit_boolean": standard_metrics(
            base_arrays.labels[base_test_indices], base_prediction, base_arrays.indentation[base_test_indices]
        ),
    }
    stress_coarse_summary, stress_coarse_family, _ = stress_metrics(
        stress_arrays.labels[stress_test_indices],
        stress_coarse,
        stress_arrays.cutout[stress_test_indices],
        stress_arrays.cutout_depth[stress_test_indices],
        stress_arrays.family_codes[stress_test_indices],
    )
    stress_model_summary, stress_model_family, stress_rows = stress_metrics(
        stress_arrays.labels[stress_test_indices],
        stress_prediction,
        stress_arrays.cutout[stress_test_indices],
        stress_arrays.cutout_depth[stress_test_indices],
        stress_arrays.family_codes[stress_test_indices],
    )
    save_stress_montage(
        output_dir / "stress_test_comparison.png",
        stress_arrays.labels[stress_test_indices],
        stress_coarse,
        stress_prediction,
        stress_arrays.cutout[stress_test_indices],
        stress_arrays.family_codes[stress_test_indices],
        "Independent nonlinear-CEM deep-concavity stress test",
    )

    # The 21 public truths are opened only after model selection and both
    # independent synthetic test sets have been evaluated.
    real_coarse, real_prediction = infer_real(
        coarse,
        model,
        adapter,
        base_archive["real_linear_images"],
        base_archive["real_voltages"],
        device,
        args.batch_size,
    )
    real_truths = base_archive["real_labels"]
    real_ids = base_archive["real_ids"]
    real_summary: dict[str, dict[str, float]] = {}
    real_rows: list[dict[str, object]] = []
    real_predictions = {"coarse_fusion": real_coarse, "implicit_boolean": real_prediction}
    for name, prediction in real_predictions.items():
        real_summary[name], rows = evaluate_real_predictions(name, prediction, real_truths, real_ids)
        real_rows.extend(rows)
    write_rows(output_dir / "real_case_metrics.csv", real_rows)
    save_real_montage(
        output_dir / "real_all_21_comparison.png", real_truths, real_ids, real_predictions, real_rows
    )
    save_focus_montage(
        output_dir / "real_most_concave_comparison.png", real_truths, real_ids, real_predictions, real_rows
    )
    np.savez_compressed(
        output_dir / "predictions.npz",
        base_test_indices=base_test_indices,
        base_coarse=base_coarse,
        base_implicit_boolean=base_prediction,
        stress_test_indices=stress_test_indices,
        stress_coarse=stress_coarse,
        stress_implicit_boolean=stress_prediction,
        real_coarse=real_coarse,
        real_implicit_boolean=real_prediction,
    )
    result = {
        "method": "multiresolution implicit Boolean support-minus-cutout network",
        "base_dataset": str(args.base_dataset.resolve()),
        "stress_dataset": str(args.stress_dataset.resolve()),
        "device": str(device),
        "seed": args.seed,
        "coarse_checkpoints": [str(path.resolve()) for path in args.coarse_checkpoint],
        "coarse_weights": coarse_weights,
        "base_synthetic_untouched_test": base_test,
        "deep_concavity_stress_untouched_test": {
            "coarse_fusion": stress_coarse_summary,
            "implicit_boolean": stress_model_summary,
        },
        "stress_by_family": {
            "coarse_fusion": stress_coarse_family,
            "implicit_boolean": stress_model_family,
        },
        "real_evaluation": real_summary,
        "evaluation_truth_used_for_training_or_selection": False,
        "selection_rule": "base validation region/boundary plus stress validation region/boundary/structural joint",
        "best_epoch": int(max(history, key=lambda row: row["score"])["epoch"]),
        "args": {
            key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()
        },
    }
    (output_dir / "summary.json").write_text(json.dumps(result, indent=2, default=str), encoding="utf-8")
    print(json.dumps(result, indent=2, default=str), flush=True)


if __name__ == "__main__":
    main()
