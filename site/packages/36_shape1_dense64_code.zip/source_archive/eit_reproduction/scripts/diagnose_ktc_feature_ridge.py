"""Fast outer-level diagnostic for physics/topology feature-only ridge rankers.

This is an analysis tool, not the final OOF method.  It deliberately reports
the candidate chosen by a feature-only ridge model and the corresponding
public target deltas, so we can determine whether the failure is caused by
the neural ranker or by the candidate pool itself.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np


ROOT = Path(r"E:\Codex\eit_reproduction")
CACHE = Path(r"E:\Codex\ktc_expanded_pure_bay_candidate_cache_seed20260820")
TARGET = Path(r"E:\Codex\ktc_expanded_pure_bay_training_targets_seed20260820")
STRICT = {
    "level_2/1", "level_2/3", "level_3/2", "level_5/2", "level_6/1",
    "level_6/2", "level_6/3", "level_7/1", "level_7/2", "level_7/3",
}


def features(z: np.lib.npyio.NpzFile) -> np.ndarray:
    desc = z["descriptors"].astype(np.float64)
    delta = desc - desc[:1]
    base = np.broadcast_to(desc[:1], desc.shape)
    cv = z["cv_fold_residuals"].astype(np.float64)
    gain = np.clip(1.0 - cv / np.maximum(cv[:1], 1e-12), -2.0, 1.0)
    cv_summary = np.stack(
        (gain.mean(1), gain.std(1), gain.min(1), gain.max(1), (gain > 0).mean(1)), 1,
    )

    def finite_gain(values: np.ndarray) -> np.ndarray:
        values = values.astype(np.float64)
        reference = max(abs(float(values[0])), 1e-12)
        return np.clip(1.0 - values / reference, -2.0, 1.0)

    fixed = np.stack(
        [finite_gain(z[f"fixed_{name}"]) for name in
         ("global_nmse", "drive_median_nmse", "cosine", "hybrid_ratio")], 1,
    )
    pool_iou = z["pool_foreground_iou"].astype(np.float64)
    pool_agreement = z["pool_label_agreement"].astype(np.float64)
    pool = np.concatenate(
        (pool_iou - pool_iou[:1], pool_agreement - pool_agreement[:1],
         np.stack((pool_iou.mean(1), pool_iou.max(1), pool_iou.std(1),
                   pool_agreement.mean(1), pool_agreement.max(1),
                   pool_agreement.std(1)), 1)), 1,
    )

    def one_hot(values: np.ndarray, count: int) -> np.ndarray:
        return np.eye(count)[np.clip(values.astype(np.int64), 0, count - 1)]

    kind = z["meta_kind"].astype(np.int64)
    class_id = z["meta_class_id"].astype(np.int64)
    component = z["meta_component_rank"].astype(np.int64) + 1
    profile = z["meta_profile"].astype(np.int64)
    metadata = np.stack(
        [z[key].astype(np.float64) for key in
         ("meta_angle_sin", "meta_angle_cos", "meta_depth", "meta_width",
          "meta_expansion", "meta_removed", "meta_added", "meta_open",
          "meta_radius", "meta_span")], 1,
    )
    categorical = np.concatenate(
        (one_hot(kind, 3), one_hot(class_id, 3), one_hot(component, 4),
         one_hot(profile, 4)), 1,
    )
    saturation = np.full((len(desc), 1), float(bool(z["fixed_saturated"])))
    return np.concatenate(
        (delta, desc, base, gain, cv_summary, fixed, pool,
         z["vote_features"].astype(np.float64), metadata, categorical,
         saturation), 1,
    )


def utility(targets: np.ndarray, removed: np.ndarray) -> np.ndarray:
    targets = np.nan_to_num(targets, nan=0.0)
    bay = np.nan_to_num(targets[:, 2])
    depth = np.nan_to_num(targets[:, 6])
    value = targets[:, 0] + .25 * targets[:, 1] + .80 * bay + .15 * targets[:, 3] + .12 * depth
    value -= 7 * np.maximum(-targets[:, 0], 0)
    value -= 2 * np.maximum(-.005 - targets[:, 1], 0)
    value -= 3 * np.maximum(-bay, 0)
    value -= np.maximum(-.020 - np.nan_to_num(targets[:, 4]), 0)
    return value - .015 * removed


def main() -> None:
    cases = []
    for path in sorted(CACHE.glob("*.npz")):
        z = np.load(path, allow_pickle=False)
        target = np.load(TARGET / path.name, allow_pickle=False)
        delta = target["delta"].astype(np.float64)
        removed = z["meta_removed"].astype(np.float64)
        valid = ((z["meta_kind"] == 2) & (removed >= .005) &
                 (z["meta_added"] <= 1e-8) & (z["meta_open"] >= .995) &
                 (z["meta_new_holes"] == 0))
        valid[0] = True
        cases.append({"id": str(z["case_id"].item()), "x": features(z),
                      "y": delta, "removed": removed, "valid": valid})
    rows = []
    for alpha in (0.1, 1.0, 10.0, 100.0, 1000.0):
        choices = []
        for outer, case in enumerate(cases):
            level = case["id"].split("/")[0]
            train = [c for c in cases if c["id"].split("/")[0] != level]
            x = np.concatenate([c["x"][c["valid"]] for c in train])
            y = np.concatenate([utility(c["y"][c["valid"]], c["removed"][c["valid"]]) for c in train])
            mean, scale = np.nanmean(x, 0), np.maximum(np.nanstd(x, 0), 1e-4)
            xn = (np.nan_to_num(x) - mean) / scale
            coef = np.linalg.solve(xn.T @ xn + alpha * np.eye(xn.shape[1]),
                                   xn.T @ np.clip(y, -.5, .5))
            score = ((np.nan_to_num(case["x"]) - mean) / scale) @ coef
            valid = case["valid"] & (case["removed"] <= .35)
            valid[0] = True
            index = int(np.argmax(np.where(valid, score, -np.inf)))
            choices.append(index)
            rows.append({"alpha": alpha, "id": case["id"], "strict": case["id"] in STRICT,
                         "choice": index, "removed": float(case["removed"][index]),
                         "iou": float(case["y"][index, 0]),
                         "boundary": float(case["y"][index, 1]),
                         "bay_f1": float(case["y"][index, 3]),
                         "bay_depth": float(case["y"][index, 6])})
        chosen = np.asarray([case["y"][i] for case, i in zip(cases, choices)])
        mask = np.asarray([case["id"] in STRICT for case in cases])
        print({"alpha": alpha, "all_iou": float(chosen[:, 0].mean()),
               "strict_iou": float(chosen[mask, 0].mean()),
               "strict_bay_f1": float(np.nanmean(chosen[mask, 3])),
               "changed": int(np.count_nonzero(choices)),
               "strict_changed": int(np.count_nonzero(np.asarray(choices)[mask]))})
    (ROOT / "outputs" / "ktc_feature_ridge_diagnostic.json").write_text(
        json.dumps(rows, indent=2), encoding="utf-8",
    )


if __name__ == "__main__":
    main()
