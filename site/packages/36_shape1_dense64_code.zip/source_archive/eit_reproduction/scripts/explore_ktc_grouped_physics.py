"""Explore direction-consensus physics ranking for exterior bay candidates."""
from __future__ import annotations

import itertools
import json
from pathlib import Path

import numpy as np


CACHE = Path(r"E:\Codex\ktc_expanded_pure_bay_candidate_cache_seed20260820")
TARGET = Path(r"E:\Codex\ktc_expanded_pure_bay_training_targets_seed20260820")
STRICT = {
    "level_2/1", "level_2/3", "level_3/2", "level_5/2", "level_6/1",
    "level_6/2", "level_6/3", "level_7/1", "level_7/2", "level_7/3",
}


def load_cases():
    cases = []
    for path in sorted(CACHE.glob("*.npz")):
        z = np.load(path, allow_pickle=False)
        target = np.load(TARGET / path.name, allow_pickle=False)
        removed = z["meta_removed"].astype(np.float64)
        cv = z["cv_fold_residuals"].astype(np.float64)
        gain = np.clip(1 - cv / np.maximum(cv[:1], 1e-12), -2, 1)
        physical = {
            "cv_mean": gain.mean(1), "cv_min": gain.min(1),
            "cv_positive": (gain > 0).mean(1),
        }
        valid = ((z["meta_kind"] == 2) & (removed >= .005) &
                 (z["meta_added"] <= 1e-8) & (z["meta_open"] >= .995) &
                 (z["meta_new_holes"] == 0))
        valid[0] = True
        angle = np.round(np.arctan2(z["meta_angle_sin"], z["meta_angle_cos"]), 3)
        group = np.stack((z["meta_component_rank"], angle), 1)
        cases.append({"id": str(z["case_id"].item()), "target": target["delta"],
                      "removed": removed, "valid": valid, "group": group,
                      "physical": physical})
    return cases


def select(case, name, aggregate, within, max_removal, penalty):
    valid = case["valid"] & (case["removed"] <= max_removal)
    valid[0] = False
    if not valid.any():
        return 0
    score = case["physical"][name] - penalty * case["removed"]
    groups = np.unique(case["group"][valid], axis=0)
    group_scores = []
    for group in groups:
        members = np.flatnonzero(valid & np.all(case["group"] == group, axis=1))
        values = np.sort(score[members])[::-1]
        count = min(aggregate, len(values))
        group_scores.append(float(values[:count].mean()))
    best_group = groups[int(np.argmax(group_scores))]
    members = np.flatnonzero(valid & np.all(case["group"] == best_group, axis=1))
    order = members[np.argsort(score[members])[::-1]]
    return int(order[min(within - 1, len(order) - 1)]), float(max(group_scores))


def main():
    cases = load_cases()
    strict = np.asarray([case["id"] in STRICT for case in cases])
    rows = []
    for name, aggregate, within, limit, penalty in itertools.product(
        ("cv_mean", "cv_min", "cv_positive"), (1, 3, 5, 10),
        (1, 2, 3, 5), (.08, .12, .16, .25), (0, .05, .15, .30),
    ):
        selected = [select(c, name, aggregate, within, limit, penalty) for c in cases]
        raw_choices = np.asarray([value[0] if isinstance(value, tuple) else 0 for value in selected])
        confidence = np.asarray([value[1] if isinstance(value, tuple) else -np.inf for value in selected])
        for gate in (-.02, 0, .01, .03, .05):
         choices = np.where(confidence >= gate, raw_choices, 0)
         values = np.stack([c["target"][i] for c, i in zip(cases, choices)])
         changed = choices != 0
         ordinary = ~strict
         row = {"name": name, "aggregate": aggregate, "within": within,
                "limit": limit, "penalty": penalty, "gate": gate,
               "all_iou": float(values[:, 0].mean()),
               "strict_iou": float(values[strict, 0].mean()),
               "ordinary_iou": float(values[ordinary, 0].mean()),
               "strict_bay": float(np.nanmean(values[strict, 3])),
               "changed": int(changed.sum()), "strict_changed": int(changed[strict].sum()),
               "harmed": int(np.count_nonzero(values[:, 0] < -1e-9)),
               "ordinary_harmed": int(np.count_nonzero(values[ordinary, 0] < -1e-9))}
         rows.append((row, choices, values))
    ranked = sorted(rows, key=lambda x: (
        x[0]["ordinary_iou"] >= 0, x[0]["strict_iou"], x[0]["all_iou"],
        -x[0]["ordinary_harmed"]), reverse=True)
    serial = [{**row, "choices": choices.tolist()} for row, choices, _ in ranked[:100]]
    (Path(r"E:\Codex\eit_reproduction\outputs") / "ktc_grouped_physics_explore.json").write_text(
        json.dumps(serial, indent=2), encoding="utf-8",
    )
    for row, choices, values in ranked[:40]:
        print(row)
        print([(case["id"], int(index), round(float(case["removed"][index]), 3),
                round(float(value[0]), 3), round(float(value[3]), 3))
               for case, index, value in zip(cases, choices, values) if index])


if __name__ == "__main__":
    main()
