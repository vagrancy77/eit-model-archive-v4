"""Outer-level OOF feature-only utility MLP diagnostic.

The spatial CNN is expensive and can lose the global candidate geometry.  This
small expert uses the complete physics/topology feature vector and predicts a
single safe utility.  It is intentionally independent of the final policy so
we can measure whether a better candidate score is possible before adding any
new constraints.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from diagnose_ktc_feature_ridge import CACHE, TARGET, STRICT, features


DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def utility(targets: np.ndarray, removed: np.ndarray) -> np.ndarray:
    targets = np.nan_to_num(targets, nan=0.0)
    bay = targets[:, 2]
    depth = targets[:, 6]
    value = targets[:, 0] + .25 * targets[:, 1] + .80 * bay + .15 * targets[:, 3] + .12 * depth
    value -= 7 * np.maximum(-targets[:, 0], 0)
    value -= 2 * np.maximum(-.005 - targets[:, 1], 0)
    value -= 3 * np.maximum(-bay, 0)
    value -= np.maximum(-.020 - targets[:, 4], 0)
    return value - .015 * removed


class UtilityMLP(nn.Module):
    def __init__(self, dimensions: int) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dimensions, 192), nn.LayerNorm(192), nn.SiLU(), nn.Dropout(.10),
            nn.Linear(192, 96), nn.SiLU(), nn.Dropout(.05), nn.Linear(96, 1),
        )

    def forward(self, x):
        return self.net(x).squeeze(1)


def load_cases():
    out = []
    for path in sorted(CACHE.glob("*.npz")):
        z = np.load(path, allow_pickle=False)
        t = np.load(TARGET / path.name, allow_pickle=False)["delta"].astype(np.float32)
        rem = z["meta_removed"].astype(np.float32)
        valid = ((z["meta_kind"] == 2) & (rem >= .005) & (z["meta_added"] <= 1e-8) &
                 (z["meta_open"] >= .995) & (z["meta_new_holes"] == 0))
        valid[0] = True
        out.append({"id": str(z["case_id"].item()), "x": features(z).astype(np.float32),
                    "target": t, "removed": rem, "valid": valid})
    return out


def fit(train, epochs=30, seed=20260820):
    torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)
    x = np.concatenate([c["x"][c["valid"]] for c in train])
    y = np.concatenate([utility(c["target"][c["valid"]], c["removed"][c["valid"]]) for c in train])
    mean, scale = np.nanmean(x, 0), np.maximum(np.nanstd(x, 0), 1e-4)
    x = ((np.nan_to_num(x) - mean) / scale).astype(np.float32)
    # Keep all identity/negative examples but make high-utility candidates more
    # visible.  The MLP still sees the full distribution through random batches.
    weight = 1.0 + 8.0 * np.clip(y, 0, .15) / .15 + 2.0 * (y > .01)
    ds = TensorDataset(torch.from_numpy(x), torch.from_numpy(y.astype(np.float32)),
                       torch.from_numpy(weight.astype(np.float32)))
    loader = DataLoader(ds, batch_size=4096, shuffle=True, drop_last=False)
    model = UtilityMLP(x.shape[1]).to(DEVICE)
    opt = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=2e-4)
    model.train()
    for _ in range(epochs):
        for xb, yb, wb in loader:
            xb, yb, wb = xb.to(DEVICE), yb.to(DEVICE), wb.to(DEVICE)
            pred = model(xb)
            loss = (wb * nn.functional.smooth_l1_loss(pred, yb, beta=.03, reduction="none")).mean()
            opt.zero_grad(set_to_none=True); loss.backward(); nn.utils.clip_grad_norm_(model.parameters(), 5); opt.step()
    model.eval()
    return model, mean, scale


def main():
    cases = load_cases(); rows = []
    for outer, case in enumerate(cases):
        level = case["id"].split("/")[0]
        train = [c for c in cases if c["id"].split("/")[0] != level]
        model, mean, scale = fit(train, epochs=25, seed=20260820 + outer)
        x = torch.from_numpy(((np.nan_to_num(case["x"]) - mean) / scale).astype(np.float32)).to(DEVICE)
        with torch.no_grad(): score = model(x).cpu().numpy()
        valid = case["valid"] & (case["removed"] <= .35); valid[0] = True
        index = int(np.argmax(np.where(valid, score, -np.inf)))
        rows.append({"id": case["id"], "strict": case["id"] in STRICT, "choice": index,
                     "removed": float(case["removed"][index]),
                     "iou": float(case["target"][index, 0]), "boundary": float(case["target"][index, 1]),
                     "bay_f1": float(case["target"][index, 3]), "score": float(score[index])})
        print(rows[-1], flush=True)
    mask = np.asarray([r["strict"] for r in rows])
    print("summary", {"all_iou": float(np.mean([r["iou"] for r in rows])),
                       "strict_iou": float(np.mean([r["iou"] for r, m in zip(rows, mask) if m])),
                       "strict_bay_f1": float(np.mean([r["bay_f1"] for r, m in zip(rows, mask) if m])),
                       "changed": int(sum(r["choice"] != 0 for r in rows))})
    (Path(r"E:\Codex\eit_reproduction\outputs") / "ktc_feature_mlp_oof.json").write_text(
        json.dumps(rows, indent=2), encoding="utf-8")


if __name__ == "__main__": main()
