"""Nested set-aware physics/topology ranker for pure exterior bays.

The candidate cache is label-free.  A synthetic-CEM pretrained encoder is
adapted with public labels only from complete KTC levels other than the level
being predicted.  Inner policy calibration uses models that exclude both the
outer level and the corresponding inner level.  Strict-concavity subgroup IDs
are used only after every prediction is frozen.
"""
from __future__ import annotations

import argparse
import copy
import csv
import itertools
import json
import random
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy import ndimage as ndi

from audit_ktc_instance_bay_topology import case_metrics, edit_metrics, paired_bootstrap
from build_ktc_instance_bay_candidate_cache import case_filename
from train_ktc_instance_bay_nested_ranker import (
    STRICT_INWARD_IDS,
    boundary_f1_per_case,
    foreground_iou_per_case,
    load_cases,
    save_montage,
    topology_checks,
)
from train_ktc_synthetic_bay_risk_ranker import RiskRankVerifier


TARGET_NAMES = (
    "foreground_iou", "boundary_f1", "bay_f1", "bay_precision", "bay_depth_score"
)
CLASS_NAMES = (
    "safe_iou", "safe_boundary", "safe_bay", "useful_bay", "safe_depth", "joint_good"
)
STRUCTURE = np.ones((3, 3), dtype=np.uint8)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument(
        "--cache-dir", type=Path,
        default=root / "outputs" / "ktc_instance_bay_candidate_cache_seed20260820",
    )
    parser.add_argument(
        "--target-dir", type=Path,
        default=Path(r"E:\Codex\ktc_instance_bay_training_targets_seed20260820"),
    )
    parser.add_argument(
        "--pretrained", type=Path,
        default=Path(r"E:\Codex\ktc_synthetic_pure_bay_physics_ranker_seed20260820")
        / "synthetic_bay_risk_ranker.pt",
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=Path(r"E:\Codex\ktc_setaware_pure_bay_oof_seed20260820"),
    )
    parser.add_argument("--epochs", type=int, default=90)
    parser.add_argument("--ensemble-size", type=int, default=3)
    parser.add_argument("--case-batch-size", type=int, default=5)
    parser.add_argument("--learning-rate", type=float, default=2e-4)
    parser.add_argument("--weight-decay", type=float, default=2e-4)
    parser.add_argument("--bootstrap-repetitions", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260820)
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


@dataclass
class PublicCase:
    case_id: str
    level: str
    candidates: np.ndarray
    features: np.ndarray
    targets: np.ndarray
    valid: np.ndarray
    removed: np.ndarray


def component_signature(labels: np.ndarray) -> tuple[int, int, int]:
    return tuple(
        int(ndi.label(mask, structure=STRUCTURE)[1])
        for mask in (labels != 0, labels == 1, labels == 2)
    )


def load_public_cases(args: argparse.Namespace) -> tuple[list[PublicCase], np.ndarray, np.ndarray]:
    base_cases, truths, ids = load_cases(args.dataset.resolve(), args.cache_dir.resolve())
    output: list[PublicCase] = []
    for case in base_cases:
        archive = np.load(args.target_dir.resolve() / case_filename(case.case_id), allow_pickle=False)
        names = [str(value) for value in archive["target_names"]]
        delta = np.asarray(archive["delta"], dtype=np.float32)
        targets = np.column_stack([delta[:, names.index(name)] for name in TARGET_NAMES]).astype(np.float32)
        baseline_signature = component_signature(case.candidates[0])
        topology_preserved = np.asarray([
            component_signature(candidate) == baseline_signature for candidate in case.candidates
        ])
        valid = (
            (case.kind == 2) & (case.removed >= 0.005) & (case.added <= 1e-8)
            & (case.new_holes == 0) & (case.open_fraction >= 0.995)
            & topology_preserved
        )
        valid[0] = True
        output.append(PublicCase(
            case.case_id, case.level, case.candidates,
            np.asarray(case.features, dtype=np.float32), targets, valid,
            np.asarray(case.removed, dtype=np.float32),
        ))
    return output, truths, ids


def class_targets(targets: np.ndarray) -> np.ndarray:
    finite_bay = np.isfinite(targets[:, 2])
    finite_depth = np.isfinite(targets[:, 4])
    safe_iou = targets[:, 0] >= -1e-9
    safe_boundary = targets[:, 1] >= -0.005
    safe_bay = finite_bay & (targets[:, 2] >= -1e-9)
    useful_bay = finite_bay & (targets[:, 2] >= 0.005)
    safe_depth = finite_depth & (targets[:, 4] >= -0.020)
    joint = safe_iou & safe_boundary & useful_bay & safe_depth
    return np.column_stack((
        safe_iou, safe_boundary, safe_bay, useful_bay, safe_depth, joint
    )).astype(np.float32)


def utility(targets: torch.Tensor) -> torch.Tensor:
    finite_bay = torch.isfinite(targets[:, 2])
    finite_depth = torch.isfinite(targets[:, 4])
    bay = torch.nan_to_num(targets[:, 2])
    depth = torch.nan_to_num(targets[:, 4])
    value = targets[:, 0] + 0.25 * targets[:, 1] + 0.75 * bay + 0.15 * depth
    value = value - 0.06 * (~finite_bay).float()
    risk = (
        5.0 * F.relu(-targets[:, 0]) + 1.5 * F.relu(-0.005 - targets[:, 1])
        + 2.0 * F.relu(-bay) + F.relu(-0.020 - depth)
    )
    value = value - risk
    value[0] = 0.0
    return value


class SetAwareRanker(nn.Module):
    def __init__(self, pretrained_state: dict[str, torch.Tensor]) -> None:
        super().__init__()
        source = RiskRankVerifier(150)
        source.load_state_dict(pretrained_state)
        self.encoder = copy.deepcopy(source.trunk)
        self.context_norm = nn.LayerNorm(96 * 3)
        self.candidate = nn.Sequential(
            nn.Linear(96 * 4, 192), nn.LayerNorm(192), nn.SiLU(), nn.Dropout(0.08),
            nn.Linear(192, 128), nn.SiLU(), nn.Linear(128, 96), nn.SiLU(),
        )
        self.regression = nn.Linear(96, len(TARGET_NAMES))
        self.classification = nn.Linear(96, len(CLASS_NAMES))
        self.rank = nn.Linear(96, 1)
        self.case_head = nn.Sequential(
            nn.Linear(96 * 3, 128), nn.SiLU(), nn.Dropout(0.08), nn.Linear(128, 1)
        )

    def forward(self, features: torch.Tensor):
        latent = self.encoder(features)
        context = self.context_norm(torch.cat((latent[:1].squeeze(0), latent.mean(0), latent.max(0).values)))
        joined = torch.cat((latent, context.expand(len(latent), -1)), dim=1)
        candidate = self.candidate(joined)
        return (
            self.regression(candidate), self.classification(candidate),
            self.rank(candidate).squeeze(1), self.case_head(context).squeeze(0),
        )


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def target_normalization(cases: list[PublicCase]) -> tuple[np.ndarray, np.ndarray]:
    rows = np.concatenate([case.targets[case.valid] for case in cases])
    mean = np.asarray([
        np.nanmean(rows[:, index]) for index in range(rows.shape[1])
    ], dtype=np.float32)
    scale = np.asarray([
        np.nanstd(rows[:, index]) for index in range(rows.shape[1])
    ], dtype=np.float32).clip(min=1e-4)
    return mean, scale


def positive_weights(cases: list[PublicCase]) -> tuple[np.ndarray, float]:
    rows = np.concatenate([class_targets(case.targets[case.valid]) for case in cases])
    positive = rows.sum(0)
    weights = np.clip((len(rows) - positive) / np.maximum(positive, 1), 1, 50).astype(np.float32)
    case_positive = sum(bool(class_targets(case.targets[case.valid])[:, 5].any()) for case in cases)
    case_weight = float(np.clip((len(cases) - case_positive) / max(case_positive, 1), 1, 20))
    return weights, case_weight


def train_one(
    cases: list[PublicCase], pretrained_state: dict[str, torch.Tensor],
    feature_mean: np.ndarray, feature_scale: np.ndarray,
    target_mean: np.ndarray, target_scale: np.ndarray,
    args: argparse.Namespace, seed: int, device: torch.device,
) -> tuple[SetAwareRanker, list[dict[str, float]]]:
    set_seed(seed)
    model = SetAwareRanker(pretrained_state).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay
    )
    fm = torch.from_numpy(feature_mean).to(device)
    fs = torch.from_numpy(feature_scale).to(device)
    tm = torch.from_numpy(target_mean).to(device)
    ts = torch.from_numpy(target_scale).to(device)
    pos_weight_np, case_pos_weight = positive_weights(cases)
    pos_weight = torch.from_numpy(pos_weight_np).to(device)
    case_weight = torch.tensor(case_pos_weight, dtype=torch.float32, device=device)
    rng = np.random.default_rng(seed)
    history: list[dict[str, float]] = []
    for epoch in range(args.epochs):
        model.train()
        order = rng.permutation(len(cases))
        losses: list[float] = []
        for start in range(0, len(order), args.case_batch_size):
            batch_losses: list[torch.Tensor] = []
            for case_index in order[start:start + args.case_batch_size]:
                case = cases[int(case_index)]
                indices = np.flatnonzero(case.valid)
                features = torch.from_numpy(case.features[indices]).to(device)
                targets = torch.from_numpy(case.targets[indices]).to(device)
                regression, logits, rank, case_logit = model(
                    torch.clamp((features - fm) / fs, -12.0, 12.0)
                )
                finite = torch.isfinite(targets)
                normalized = (torch.nan_to_num(targets) - tm) / ts
                regression_loss = F.smooth_l1_loss(
                    regression[finite], normalized[finite], beta=0.35
                )
                classes_np = class_targets(case.targets[indices])
                classes = torch.from_numpy(classes_np).to(device)
                classification_loss = F.binary_cross_entropy_with_logits(
                    logits, classes, pos_weight=pos_weight
                )
                target_distribution = torch.softmax(utility(targets) / 0.045, dim=0)
                rank_loss = -torch.sum(target_distribution * F.log_softmax(rank, dim=0))
                case_target = torch.tensor(
                    float(classes_np[:, 5].any()), dtype=torch.float32, device=device
                )
                case_loss = F.binary_cross_entropy_with_logits(
                    case_logit.view(()), case_target,
                    pos_weight=case_weight if case_target > 0 else None,
                )
                identity_target = -tm / ts
                identity_loss = (
                    F.smooth_l1_loss(regression[0], identity_target, beta=0.35)
                    + rank[0].square()
                )
                batch_losses.append(
                    regression_loss + 0.55 * classification_loss + 0.20 * rank_loss
                    + 0.45 * case_loss + 0.06 * identity_loss
                )
            loss = torch.stack(batch_losses).mean()
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            losses.append(float(loss.detach()))
        record = {"epoch": epoch + 1, "loss": float(np.mean(losses))}
        history.append(record)
    model.eval()
    return model, history


def train_or_load_ensemble(
    name: str, training: list[PublicCase], pretrained: dict[str, object],
    args: argparse.Namespace, device: torch.device,
) -> tuple[list[SetAwareRanker], np.ndarray, np.ndarray]:
    model_dir = args.output_dir.resolve() / "model_cache"
    model_dir.mkdir(parents=True, exist_ok=True)
    path = model_dir / f"{name}.pt"
    histories_path = model_dir / f"{name}_history.json"
    if path.exists() and not args.force:
        payload = torch.load(path, map_location=device, weights_only=False)
        models: list[SetAwareRanker] = []
        for member, state in enumerate(payload["models"]):
            model = SetAwareRanker(pretrained["models"][member % len(pretrained["models"])]).to(device)
            model.load_state_dict(state)
            model.eval()
            models.append(model)
        return models, payload["target_mean"], payload["target_scale"]
    target_mean, target_scale = target_normalization(training)
    histories: dict[str, object] = {}
    models = []
    for member in range(args.ensemble_size):
        seed = args.seed + member
        model, history = train_one(
            training, pretrained["models"][member % len(pretrained["models"])],
            np.asarray(pretrained["feature_mean"], dtype=np.float32),
            np.asarray(pretrained["feature_scale"], dtype=np.float32),
            target_mean, target_scale, args, seed, device,
        )
        models.append(model)
        histories[str(seed)] = history
    torch.save({
        "models": [model.state_dict() for model in models],
        "target_mean": target_mean, "target_scale": target_scale,
        "training_case_ids": [case.case_id for case in training],
        "excluded_model_name": name,
    }, path)
    histories_path.write_text(json.dumps(histories, indent=2), encoding="utf-8")
    return models, target_mean, target_scale


@dataclass
class Evidence:
    regression: np.ndarray
    regression_std: np.ndarray
    probability: np.ndarray
    probability_std: np.ndarray
    rank: np.ndarray
    rank_std: np.ndarray
    case_probability: float
    case_probability_std: float


@torch.no_grad()
def predict_case(
    case: PublicCase, models: list[SetAwareRanker], pretrained: dict[str, object],
    target_mean: np.ndarray, target_scale: np.ndarray, device: torch.device,
) -> Evidence:
    indices = np.flatnonzero(case.valid)
    fm = torch.from_numpy(np.asarray(pretrained["feature_mean"], dtype=np.float32)).to(device)
    fs = torch.from_numpy(np.asarray(pretrained["feature_scale"], dtype=np.float32)).to(device)
    features = torch.clamp((torch.from_numpy(case.features[indices]).to(device) - fm) / fs, -12, 12)
    regressions, probabilities, ranks, case_probabilities = [], [], [], []
    for model in models:
        regression, logits, rank, case_logit = model(features)
        regressions.append(regression.cpu().numpy() * target_scale + target_mean)
        probabilities.append(torch.sigmoid(logits).cpu().numpy())
        ranks.append((rank - rank[:1]).cpu().numpy())
        case_probabilities.append(float(torch.sigmoid(case_logit)))
    length = len(case.features)
    regression = np.full((len(models), length, len(TARGET_NAMES)), -np.inf, dtype=np.float32)
    probability = np.zeros((len(models), length, len(CLASS_NAMES)), dtype=np.float32)
    rank = np.full((len(models), length), -np.inf, dtype=np.float32)
    for member in range(len(models)):
        regression[member, indices] = regressions[member]
        probability[member, indices] = probabilities[member]
        rank[member, indices] = ranks[member]
    regression[:, 0] = 0.0
    rank[:, 0] = 0.0
    regression_mean = np.full((length, len(TARGET_NAMES)), -np.inf, dtype=np.float32)
    regression_std = np.full((length, len(TARGET_NAMES)), np.inf, dtype=np.float32)
    probability_mean = np.zeros((length, len(CLASS_NAMES)), dtype=np.float32)
    probability_std = np.full((length, len(CLASS_NAMES)), np.inf, dtype=np.float32)
    rank_mean = np.full(length, -np.inf, dtype=np.float32)
    rank_std = np.full(length, np.inf, dtype=np.float32)
    regression_mean[indices] = regression[:, indices].mean(0)
    regression_std[indices] = regression[:, indices].std(0)
    probability_mean[indices] = probability[:, indices].mean(0)
    probability_std[indices] = probability[:, indices].std(0)
    rank_mean[indices] = rank[:, indices].mean(0)
    rank_std[indices] = rank[:, indices].std(0)
    return Evidence(
        regression_mean, regression_std, probability_mean, probability_std,
        rank_mean, rank_std, float(np.mean(case_probabilities)),
        float(np.std(case_probabilities)),
    )


@dataclass(frozen=True)
class Policy:
    case_probability: float
    safe_probability: float
    useful_bay_probability: float
    joint_probability: float
    rank_margin: float
    uncertainty: float
    max_removal: float


POLICIES = tuple(
    Policy(case, safe, useful, joint, rank, uncertainty, removal)
    for case in (0.60, 0.75, 0.90)
    for safe in (0.60, 0.75, 0.90)
    for useful in (0.50, 0.70)
    for joint in (0.05, 0.20)
    for rank in (0.00, 0.05)
    for uncertainty in (0.50, 1.00)
    for removal in (0.10, 0.18, 0.30)
) + (Policy(1, 1, 1, 1, 1, 1, 0.10),)


def choose(case: PublicCase, evidence: Evidence, policy: Policy) -> int:
    case_lower = evidence.case_probability - policy.uncertainty * evidence.case_probability_std
    if case_lower < policy.case_probability:
        return 0
    probability = evidence.probability - policy.uncertainty * evidence.probability_std
    regression = evidence.regression - policy.uncertainty * evidence.regression_std
    rank = evidence.rank - policy.uncertainty * evidence.rank_std
    valid = case.valid.copy()
    valid &= case.removed <= policy.max_removal
    valid &= probability[:, 0] >= policy.safe_probability
    valid &= probability[:, 1] >= 0.50
    valid &= probability[:, 2] >= policy.safe_probability
    valid &= probability[:, 3] >= policy.useful_bay_probability
    valid &= probability[:, 4] >= 0.50
    valid &= probability[:, 5] >= policy.joint_probability
    valid &= regression[:, 0] >= -0.002
    valid &= regression[:, 2] >= 0.0
    valid &= rank >= policy.rank_margin
    valid[0] = True
    score = rank + 0.50 * regression[:, 0] + 0.50 * regression[:, 2] + 0.10 * regression[:, 1]
    score[0] = 0.0
    return int(np.argmax(np.where(valid, score, -np.inf)))


def policy_result(cases: list[PublicCase], evidence: dict[str, Evidence], policy: Policy):
    choices = np.asarray([choose(case, evidence[case.case_id], policy) for case in cases])
    values = np.stack([case.targets[index] for case, index in zip(cases, choices)])
    changed = choices != 0
    finite_bay = np.isfinite(values[:, 2])
    eligible = (
        not np.any(values[:, 0] < -1e-9)
        and not np.any(values[:, 1] < -0.005)
        and not np.any(values[changed & finite_bay, 2] < -1e-9)
        and not np.any(values[changed & np.isfinite(values[:, 4]), 4] < -0.020)
    )
    bay = np.nan_to_num(values[:, 2])
    depth = np.nan_to_num(values[:, 4])
    utility_values = values[:, 0] + 0.25 * values[:, 1] + 0.75 * bay + 0.15 * depth
    return choices, values, {
        "eligible": bool(eligible), "changed": int(changed.sum()),
        "joint_improved": int(np.count_nonzero(
            changed & (values[:, 0] > 0) & finite_bay & (values[:, 2] > 0)
        )),
        "harmed_iou": int(np.count_nonzero(values[:, 0] < 0)),
        "harmed_bay": int(np.count_nonzero(changed & finite_bay & (values[:, 2] < 0))),
        "mean_iou": float(values[:, 0].mean()),
        "mean_boundary": float(values[:, 1].mean()),
        "mean_bay": float(np.nanmean(values[:, 2])),
        "mean_utility": float(utility_values.mean()),
        "minimum_iou": float(values[:, 0].min()),
    }


def select_policy(cases: list[PublicCase], evidence: dict[str, Evidence]):
    rows: list[dict[str, object]] = []
    best = None
    for policy in POLICIES:
        _, _, result = policy_result(cases, evidence, policy)
        rows.append({**asdict(policy), **result})
        key = (
            int(result["eligible"]), float(result["mean_utility"]),
            int(result["joint_improved"]), float(result["mean_iou"]),
            -int(result["changed"]),
        )
        if best is None or key > best[0]:
            best = (key, policy, result)
    return best[1], best[2], rows


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        return
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def group_summary(mask, truths, baselines, predictions, repetitions, seed):
    indices = np.flatnonzero(mask)
    before_iou = foreground_iou_per_case(truths[indices], baselines[indices])
    after_iou = foreground_iou_per_case(truths[indices], predictions[indices])
    before_boundary = boundary_f1_per_case(truths[indices], baselines[indices])
    after_boundary = boundary_f1_per_case(truths[indices], predictions[indices])
    before_geometry = [case_metrics(truths[i], baselines[i]) for i in indices]
    after_geometry = [case_metrics(truths[i], predictions[i]) for i in indices]
    result = {
        "case_count": int(len(indices)),
        "changed_cases": int(np.count_nonzero(np.any(predictions[indices] != baselines[indices], axis=(1, 2)))),
        "improved_iou_cases": int(np.count_nonzero(after_iou > before_iou + 1e-9)),
        "harmed_iou_cases": int(np.count_nonzero(after_iou < before_iou - 1e-9)),
        "baseline_iou": float(before_iou.mean()), "final_iou": float(after_iou.mean()),
        "delta_iou": paired_bootstrap(after_iou - before_iou, repetitions, seed),
        "baseline_boundary_f1": float(before_boundary.mean()),
        "final_boundary_f1": float(after_boundary.mean()),
        "delta_boundary_f1": paired_bootstrap(after_boundary - before_boundary, repetitions, seed + 1),
    }
    for offset, metric in enumerate(("bay_f1", "bay_precision", "bay_depth_score", "bay_direction_score")):
        before = np.asarray([float(row[metric]) for row in before_geometry])
        after = np.asarray([float(row[metric]) for row in after_geometry])
        result[f"baseline_{metric}"] = float(np.nanmean(before))
        result[f"final_{metric}"] = float(np.nanmean(after))
        result[f"delta_{metric}"] = paired_bootstrap(after - before, repetitions, seed + 2 + offset)
    return result


def main() -> None:
    args = parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    pretrained = torch.load(args.pretrained.resolve(), map_location="cpu", weights_only=False)
    cases, truths, ids = load_public_cases(args)
    levels = sorted({case.level for case in cases})

    pair_evidence: dict[tuple[str, str], dict[str, Evidence]] = {}
    for index, (left, right) in enumerate(itertools.combinations(levels, 2), 1):
        name = f"exclude_{left}_{right}"
        training = [case for case in cases if case.level not in (left, right)]
        models, target_mean, target_scale = train_or_load_ensemble(
            name, training, pretrained, args, device
        )
        held = [case for case in cases if case.level in (left, right)]
        pair_evidence[(left, right)] = {
            case.case_id: predict_case(
                case, models, pretrained, target_mean, target_scale, device
            ) for case in held
        }
        print(f"pair {index:02d}/21 {left}+{right}: train={len(training)} held={len(held)}", flush=True)

    predictions = np.stack([case.candidates[0] for case in cases])
    baselines = predictions.copy()
    choices = np.zeros(len(cases), dtype=np.int64)
    policies: list[dict[str, object]] = []
    calibration_rows: list[dict[str, object]] = []
    for fold, outer in enumerate(levels, 1):
        inner_cases = [case for case in cases if case.level != outer]
        inner_evidence: dict[str, Evidence] = {}
        for inner in levels:
            if inner == outer:
                continue
            pair = tuple(sorted((outer, inner)))
            for case in cases:
                if case.level == inner:
                    inner_evidence[case.case_id] = pair_evidence[pair][case.case_id]
        policy, inner_result, calibration = select_policy(inner_cases, inner_evidence)
        calibration_rows.extend({"outer_level": outer, **row} for row in calibration)

        training = [case for case in cases if case.level != outer]
        models, target_mean, target_scale = train_or_load_ensemble(
            f"exclude_{outer}", training, pretrained, args, device
        )
        outer_choices: list[int] = []
        for case_index, case in enumerate(cases):
            if case.level != outer:
                continue
            evidence = predict_case(case, models, pretrained, target_mean, target_scale, device)
            choice = choose(case, evidence, policy)
            choices[case_index] = choice
            predictions[case_index] = case.candidates[choice]
            outer_choices.append(choice)
        record = {
            "outer_level": outer, **asdict(policy),
            **{f"inner_oof_{key}": value for key, value in inner_result.items()},
            "outer_choices": outer_choices,
        }
        policies.append(record)
        print(f"outer {fold}/7: {record}", flush=True)

    before_iou = foreground_iou_per_case(truths, baselines)
    after_iou = foreground_iou_per_case(truths, predictions)
    before_boundary = boundary_f1_per_case(truths, baselines)
    after_boundary = boundary_f1_per_case(truths, predictions)
    case_rows: list[dict[str, object]] = []
    for index, case in enumerate(cases):
        before_geometry = case_metrics(truths[index], baselines[index])
        after_geometry = case_metrics(truths[index], predictions[index])
        row: dict[str, object] = {
            "id": case.case_id, "strict_inward": case.case_id in STRICT_INWARD_IDS,
            "choice": int(choices[index]), "baseline_iou": float(before_iou[index]),
            "final_iou": float(after_iou[index]), "delta_iou": float(after_iou[index] - before_iou[index]),
            "baseline_boundary_f1": float(before_boundary[index]),
            "final_boundary_f1": float(after_boundary[index]),
            "delta_boundary_f1": float(after_boundary[index] - before_boundary[index]),
            **topology_checks(baselines[index], predictions[index]),
            **edit_metrics(truths[index], baselines[index], predictions[index]),
        }
        for metric in ("bay_f1", "bay_precision", "bay_depth_score", "bay_direction_score"):
            row[f"baseline_{metric}"] = before_geometry[metric]
            row[f"final_{metric}"] = after_geometry[metric]
            row[f"delta_{metric}"] = float(after_geometry[metric] - before_geometry[metric])
        case_rows.append(row)
    strict = np.asarray([case.case_id in STRICT_INWARD_IDS for case in cases])
    groups = {
        "all": group_summary(np.ones(len(cases), bool), truths, baselines, predictions, args.bootstrap_repetitions, args.seed),
        "strict_inward": group_summary(strict, truths, baselines, predictions, args.bootstrap_repetitions, args.seed + 20),
        "ordinary": group_summary(~strict, truths, baselines, predictions, args.bootstrap_repetitions, args.seed + 40),
    }
    write_csv(output / "public_case_metrics.csv", case_rows)
    write_csv(output / "nested_calibration.csv", calibration_rows)
    (output / "fold_policies.json").write_text(json.dumps(policies, indent=2), encoding="utf-8")
    np.savez_compressed(
        output / "predictions.npz", ids=ids, truths=truths, baseline=baselines,
        prediction=predictions, choices=choices,
    )
    save_montage(
        output / "strict_inward_setaware.png", truths, baselines, predictions,
        baselines, ids, np.flatnonzero(strict),
    )
    summary = {
        "method": "synthetic-pretrained set-aware physics/topology pure exterior-bay ranker",
        "status": "complete-level nested outer-OOF evaluation",
        "outer_truth_used_for_training_or_policy_selection": False,
        "strict_inward_ids_used_for_training_or_policy_selection": False,
        "candidate_constraints": {
            "added_pixels": 0, "removed_background_exterior_connected": True,
            "new_holes_forbidden": True,
            "foreground_and_class_component_counts_preserved": True,
            "identity_fallback": True,
        },
        "synthetic_pretrained_checkpoint": str(args.pretrained.resolve()),
        "groups": groups, "fold_policies": policies,
        "args": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
    }
    (output / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=True), encoding="utf-8"
    )
    print(json.dumps(groups, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
