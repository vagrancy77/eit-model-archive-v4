"""Build synthetic parametric-bay candidates and truth-blind evidence.

The split files from ``build_ktc_cross_representation_pool.py`` provide 13
frozen neural reconstructions.  Around their ``fusion_primary`` baseline this
script generates the exact exterior-connected parametric family used for the
public KTC cases, then caches physics/network evidence and post-hoc targets.
Targets are stored separately from features in every file and are never read
by public inference.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch
from scipy import ndimage as ndi

from audit_ktc_instance_bay_candidates import fit_voltage_cv_torch, generate_candidates
from build_ktc_instance_bay_candidate_cache import (
    metadata_arrays,
    pairwise_label_agreement,
    pairwise_mask_iou,
    vote_features,
)
from evaluate_ktc_cross_pool_physics_ranking import residual_scores
from train_ktc_cross_representation_ranker import candidate_descriptors
from train_ktc_implicit_boolean_network import stress_metrics
from train_ktc_instance_bay_nested_ranker import build_case_features


TARGET_NAMES = (
    "foreground_iou",
    "boundary_f1",
    "open_deep_cutout_recovery",
    "bank_retention",
    "topology_structural_joint",
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz"
    )
    parser.add_argument(
        "--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz"
    )
    parser.add_argument(
        "--pool-dir", type=Path,
        default=root / "outputs" / "ktc_cross_representation_pool_seed20260820",
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=Path(r"E:\Codex\ktc_synthetic_instance_bay_cache_seed20260820"),
    )
    parser.add_argument(
        "--splits", default="base_train,base_validation,base_test,stress_train,stress_validation,stress_test"
    )
    parser.add_argument("--base-train-limit", type=int, default=520)
    parser.add_argument("--sample-limit", type=int, default=0)
    parser.add_argument("--angles", type=int, default=12)
    parser.add_argument("--max-components", type=int, default=3)
    parser.add_argument("--min-component-fraction", type=float, default=0.0015)
    parser.add_argument("--physics-chunk", type=int, default=256)
    parser.add_argument(
        "--skip-physics", action="store_true",
        help="Zero CV/fixed-residual columns for a complementary shape-only verifier.",
    )
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--seed", type=int, default=20260820)
    return parser.parse_args()


def split_source(name: str) -> tuple[str, str]:
    source, split = name.split("_", 1)
    return source, split + "_indices"


def payload_features(
    candidates: np.ndarray,
    pool_candidates: np.ndarray,
    image: np.ndarray,
    voltage: np.ndarray,
    fov: np.ndarray,
    jacobian: np.ndarray,
    node_map: np.ndarray,
    metadata: list[dict[str, object]],
    device_jacobian: torch.Tensor,
    device_node_map: torch.Tensor,
    physics_chunk: int,
    skip_physics: bool,
) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    descriptors = candidate_descriptors(
        image[None], candidates[:, None], fov
    )[0].astype(np.float32)
    if skip_physics:
        cv = np.ones((len(candidates), 4), dtype=np.float32)
        fixed = {
            name: np.ones((len(candidates), 1), dtype=np.float32)
            for name in ("global_nmse", "drive_median_nmse", "cosine", "hybrid_ratio")
        }
        contrasts = np.zeros((1, 2), dtype=np.float32)
        saturated = np.zeros(1, dtype=bool)
    else:
        cv = fit_voltage_cv_torch(
            candidates, voltage, device_jacobian, device_node_map, physics_chunk
        ).astype(np.float32)
        fixed, contrasts, saturated = residual_scores(
            candidates[:, None], voltage[None], jacobian, node_map
        )
    payload: dict[str, np.ndarray] = {
        "descriptors": descriptors,
        "cv_fold_residuals": cv,
        "pool_foreground_iou": pairwise_mask_iou(candidates, pool_candidates),
        "pool_label_agreement": pairwise_label_agreement(candidates, pool_candidates, fov),
        "vote_features": vote_features(candidates, pool_candidates, fov),
        "fixed_contrasts": contrasts[0].astype(np.float32),
        "fixed_saturated": np.asarray(bool(saturated[0])),
    }
    for name, values in fixed.items():
        payload[f"fixed_{name}"] = values[:, 0].astype(np.float32)
    payload.update(metadata_arrays(metadata))
    return build_case_features(payload).astype(np.float32), payload


def target_matrix(
    truth: np.ndarray,
    candidates: np.ndarray,
    cutout: np.ndarray,
    depth: np.ndarray,
    family: int,
) -> np.ndarray:
    count = len(candidates)
    _, _, rows = stress_metrics(
        np.repeat(truth[None], count, axis=0),
        candidates,
        np.repeat(cutout[None], count, axis=0),
        np.repeat(depth[None], count, axis=0),
        np.full(count, family, dtype=np.int16),
    )
    return np.asarray(
        [[float(row[name]) for name in TARGET_NAMES] for row in rows], dtype=np.float32
    )


def main() -> None:
    args = parse_args()
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    base = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    archives = {"base": base, "stress": stress}
    fov = np.asarray(base["fov_mask"], dtype=bool)
    jacobian = np.asarray(base["jacobian"], dtype=np.float32)
    node_map = np.asarray(base["node_to_raw_pixel"], dtype=np.int64)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    device_jacobian = torch.from_numpy(jacobian).to(device)
    device_node_map = torch.from_numpy(node_map).to(device)
    requested = [value.strip() for value in args.splits.split(",") if value.strip()]
    manifest: dict[str, object] = {
        "status": "synthetic label-bearing candidate training cache",
        "public_cases_used": False,
        "feature_target_separation": True,
        "target_names": TARGET_NAMES,
        "shape_feature_columns": "all build_case_features columns except 72:85",
        "device": str(device),
        "splits": {},
    }
    for split_name in requested:
        source, index_key = split_source(split_name)
        dataset = archives[source]
        pool = np.load(args.pool_dir.resolve() / f"{split_name}.npz", allow_pickle=False)
        indices = np.asarray(pool["indices"], dtype=np.int64)
        pool_candidates = np.asarray(pool["candidates"], dtype=np.uint8)
        if split_name == "base_train" and args.base_train_limit > 0:
            indices = indices[: args.base_train_limit]
            pool_candidates = pool_candidates[:, : args.base_train_limit]
        if args.sample_limit > 0:
            indices = indices[: args.sample_limit]
            pool_candidates = pool_candidates[:, : args.sample_limit]
        if not np.array_equal(indices, np.asarray(dataset[index_key], dtype=np.int64)[: len(indices)]):
            raise ValueError(f"pool/dataset index mismatch for {split_name}")
        split_dir = output_dir / split_name
        split_dir.mkdir(parents=True, exist_ok=True)
        records: list[dict[str, object]] = []
        for local_index, global_index in enumerate(indices):
            path = split_dir / f"sample_{local_index:04d}.npz"
            if path.exists() and not args.force:
                cached = np.load(path, allow_pickle=False)
                records.append({
                    "local_index": local_index,
                    "global_index": int(global_index),
                    "file": path.name,
                    "candidate_count": int(len(cached["targets"])),
                })
                continue
            baseline = pool_candidates[0, local_index]
            candidates, metadata = generate_candidates(
                baseline, args.angles, args.max_components, args.min_component_fraction
            )
            features, payload = payload_features(
                candidates,
                pool_candidates[:, local_index],
                np.asarray(dataset["linear_images"][global_index], dtype=np.float32),
                np.asarray(dataset["voltages"][global_index], dtype=np.float32),
                fov, jacobian, node_map, metadata,
                device_jacobian, device_node_map, args.physics_chunk, args.skip_physics,
            )
            truth = np.asarray(dataset["labels"][global_index], dtype=np.uint8)
            if source == "stress":
                cutout = np.asarray(dataset["cutout_masks"][global_index], dtype=np.uint8)
                depth = np.asarray(dataset["cutout_depth_weights"][global_index], dtype=np.float32)
                family = int(dataset["family_codes"][global_index])
            else:
                cutout = np.asarray(dataset["indentation_masks"][global_index], dtype=np.uint8)
                distance = ndi.distance_transform_edt(cutout != 0)
                depth = (distance / max(float(distance.max()), 1.0)).astype(np.float32)
                family = -1
            targets = target_matrix(truth, candidates, cutout, depth, family)
            np.savez_compressed(
                path,
                global_index=np.asarray(global_index, dtype=np.int64),
                candidates=candidates.astype(np.uint8),
                features=features,
                target_names=np.asarray(TARGET_NAMES),
                targets=targets,
                target_delta=(targets - targets[:1]).astype(np.float32),
                family=np.asarray(family, dtype=np.int16),
                **{key: value for key, value in payload.items() if key.startswith("meta_")},
            )
            records.append({
                "local_index": local_index,
                "global_index": int(global_index),
                "file": path.name,
                "candidate_count": len(candidates),
            })
            print(
                f"{split_name} {local_index + 1:04d}/{len(indices)}: "
                f"global={global_index}, candidates={len(candidates)}",
                flush=True,
            )
        manifest["splits"][split_name] = records
        (output_dir / "manifest.json").write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
        )
    manifest["args"] = {
        key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()
    }
    (output_dir / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
