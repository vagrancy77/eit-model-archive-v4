from pathlib import Path
import os
import sys

import numpy as np

repo_root = Path(__file__).resolve().parents[1] / "external" / "KTC2023-ABC2"
os.chdir(repo_root)
sys.path.insert(0, str(repo_root))
from utils import solver

output, details = solver.solve(
    str(repo_root / "inputs" / "data1.mat"),
    1,
    num_iter_override=2,
    prior_mask=np.ones((256, 256), dtype=np.float64),
    prior_reliability=np.ones((256, 256), dtype=np.float64),
    geo_lambda=1e-3,
    learn_reliability=True,
    reliability_reg=1e-4,
    learn_registration=True,
    registration_reg=1e-4,
    reliability_fallback=True,
    return_details=True,
)
assert output.shape == (256, 256)
assert details["final_registration_raw"].shape == (4,)
print("registration interface ok", details["final_registration_raw"])
