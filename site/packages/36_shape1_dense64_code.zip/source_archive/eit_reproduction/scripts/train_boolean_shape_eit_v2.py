"""Train the independent Boolean Shape EIT v2 network.

The public KTC truths are not used for optimization or checkpoint selection.
Three synthetic nonlinear-CEM datasets are mixed for training, while their
validation and test splits remain separate so ordinary-case protection and
concavity recovery can be measured independently.
"""
from __future__ import annotations

import argparse
import json
import math
import random
import sys
import time
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import binary_dilation, binary_erosion, distance_transform_edt
from torch.utils.data import ConcatDataset, DataLoader, Dataset

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from pytorch_eit.boolean_shape_net import BooleanShapeNet, PhysicsOperator


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=ROOT / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument(
        "--biological-dataset", type=Path,
        default=ROOT / "datasets" / "ktc_biological_concavity_v1.npz",
    )
    parser.add_argument(
        "--stress-dataset", type=Path,
        default=ROOT / "datasets" / "ktc_deep_concavity_stress_v1.npz",
    )
    parser.add_argument("--output-dir", type=Path, default=ROOT / "outputs" / "boolean_shape_eit_v2")
    parser.add_argument("--epochs", type=int, default=72)
    parser.add_argument("--patience", type=int, default=14)
    parser.add_argument("--batch-size", type=int, default=18)
    parser.add_argument("--base-channels", type=int, default=24)
    parser.add_argument("--learning-rate", type=float, default=1.5e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--stress-repeat", type=int, default=2)
    parser.add_argument("--seed", type=int, default=20260831)
    parser.add_argument("--device", choices=("auto", "cuda", "cpu"), default="auto")
    parser.add_argument("--physics-weight", type=float, default=1.5e-4)
    parser.add_argument("--max-train-batches", type=int, default=0)
    parser.add_argument("--progress-every", type=int, default=4)
    parser.add_argument("--resume", type=Path, default=None)
    parser.add_argument(
        "--diagnose-gradients", action="store_true",
        help="stop after the first batch and report non-finite parameter gradients",
    )
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = True


def signed_distance(binary: np.ndarray) -> np.ndarray:
    foreground = binary.astype(bool)
    distance = distance_transform_edt(foreground) - distance_transform_edt(~foreground)
    return np.clip(distance / 12.0, -1.0, 1.0).astype(np.float32)


@dataclass
class StructuralArrays:
    name: str
    images: np.ndarray
    voltages: np.ndarray
    labels: np.ndarray
    delta: np.ndarray
    support: np.ndarray
    cutout: np.ndarray
    support_sdf: np.ndarray
    cutout_sdf: np.ndarray
    cutout_depth: np.ndarray
    mouth: np.ndarray
    indentation: np.ndarray
    fov_mask: np.ndarray
    family_codes: np.ndarray


def prepare_arrays(archive: np.lib.npyio.NpzFile, name: str) -> StructuralArrays:
    labels = np.asarray(archive["labels"], dtype=np.uint8)
    foreground = labels != 0
    indentation = np.asarray(archive["indentation_masks"], dtype=np.uint8)
    if "support_masks" in archive.files:
        support = np.asarray(archive["support_masks"], dtype=np.uint8)
        cutout = np.asarray(archive["cutout_masks"], dtype=np.uint8)
    else:
        support = np.logical_or(foreground, indentation != 0).astype(np.uint8)
        cutout = indentation.copy()

    count = len(labels)
    if "support_signed_distance" in archive.files:
        support_sdf = np.asarray(archive["support_signed_distance"], dtype=np.float32)
    else:
        support_sdf = np.empty(labels.shape, dtype=np.float32)
        print(f"computing {name} support SDF targets ({count})", flush=True)
        for index in range(count):
            support_sdf[index] = signed_distance(support[index])
    if "cutout_signed_distance" in archive.files:
        cutout_sdf = np.asarray(archive["cutout_signed_distance"], dtype=np.float32)
    else:
        cutout_sdf = np.empty(labels.shape, dtype=np.float32)
        print(f"computing {name} cutout SDF targets ({count})", flush=True)
        for index in range(count):
            cutout_sdf[index] = signed_distance(cutout[index])
    if "cutout_depth_weights" in archive.files:
        cutout_depth = np.asarray(archive["cutout_depth_weights"], dtype=np.float32)
    else:
        cutout_depth = np.empty(labels.shape, dtype=np.float32)
        for index in range(count):
            depth = distance_transform_edt(cutout[index] != 0)
            cutout_depth[index] = depth / max(1.0, float(depth.max()))

    mouth = np.zeros_like(cutout, dtype=np.uint8)
    cross = np.asarray([[0, 1, 0], [1, 1, 1], [0, 1, 0]], dtype=bool)
    for index in range(count):
        mouth[index] = (
            (cutout[index] != 0)
            & binary_dilation(support[index] == 0, structure=cross)
        ).astype(np.uint8)
    family = (
        np.asarray(archive["family_codes"], dtype=np.int16)
        if "family_codes" in archive.files
        else np.full(count, -1, dtype=np.int16)
    )
    return StructuralArrays(
        name=name,
        images=np.asarray(archive["linear_images"], dtype=np.float32),
        voltages=np.asarray(archive["voltages"], dtype=np.float32),
        labels=labels,
        delta=np.asarray(archive["delta"], dtype=np.float32),
        support=support,
        cutout=cutout,
        support_sdf=support_sdf,
        cutout_sdf=cutout_sdf,
        cutout_depth=cutout_depth,
        mouth=mouth,
        indentation=indentation,
        fov_mask=np.asarray(archive["fov_mask"], dtype=np.uint8),
        family_codes=family,
    )


class StructuralDataset(Dataset):
    def __init__(self, arrays: StructuralArrays, indices: np.ndarray, source: int) -> None:
        self.arrays = arrays
        self.indices = np.asarray(indices, dtype=np.int64)
        self.source = source

    def __len__(self) -> int:
        return int(self.indices.size)

    def __getitem__(self, item: int) -> dict[str, torch.Tensor]:
        index = int(self.indices[item])
        a = self.arrays
        return {
            "image": torch.from_numpy(a.images[index][None]),
            "voltage": torch.from_numpy(a.voltages[index]),
            "labels": torch.from_numpy(a.labels[index].astype(np.int64)),
            "delta": torch.from_numpy(a.delta[index][None]),
            "support": torch.from_numpy(a.support[index].astype(np.float32)[None]),
            "cutout": torch.from_numpy(a.cutout[index].astype(np.float32)[None]),
            "support_sdf": torch.from_numpy(a.support_sdf[index][None]),
            "cutout_sdf": torch.from_numpy(a.cutout_sdf[index][None]),
            "cutout_depth": torch.from_numpy(a.cutout_depth[index][None]),
            "mouth": torch.from_numpy(a.mouth[index].astype(np.float32)[None]),
            "indent": torch.from_numpy(a.indentation[index].astype(np.float32)[None]),
            "index": torch.tensor(index, dtype=torch.int64),
            "source": torch.tensor(self.source, dtype=torch.int64),
            "family": torch.tensor(int(a.family_codes[index]), dtype=torch.int64),
        }


def to_device(batch: dict[str, torch.Tensor], device: torch.device) -> dict[str, torch.Tensor]:
    return {key: value.to(device, non_blocking=True) for key, value in batch.items()}


def soft_dice_loss(probability: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    one_hot = F.one_hot(target, num_classes=3).permute(0, 3, 1, 2).float()
    intersection = (probability[:, 1:] * one_hot[:, 1:]).sum(dim=(0, 2, 3))
    denominator = (probability[:, 1:] + one_hot[:, 1:]).sum(dim=(0, 2, 3))
    return 1.0 - ((2.0 * intersection + 1.0) / (denominator + 1.0)).mean()


def balanced_bce(logits: torch.Tensor, target: torch.Tensor, domain: torch.Tensor) -> torch.Tensor:
    raw = F.binary_cross_entropy_with_logits(logits, target, reduction="none") * domain
    positive = target * domain
    negative = (1.0 - target) * domain
    dims = (1, 2, 3)
    positive_loss = (raw * positive).sum(dim=dims) / positive.sum(dim=dims).clamp_min(1.0)
    negative_loss = (raw * negative).sum(dim=dims) / negative.sum(dim=dims).clamp_min(1.0)
    has_positive = positive.sum(dim=dims) > 0
    return torch.where(has_positive, 0.5 * (positive_loss + negative_loss), negative_loss).mean()


def weighted_case_mean(value: torch.Tensor, case_weight: torch.Tensor) -> torch.Tensor:
    per_case = value.flatten(1).mean(dim=1)
    weight = case_weight.flatten()
    return (per_case * weight).sum() / weight.sum().clamp_min(1.0)


def balanced_confidence_loss(
    logits: torch.Tensor, target: torch.Tensor, case_weight: torch.Tensor
) -> torch.Tensor:
    raw = F.binary_cross_entropy_with_logits(logits, target, reduction="none").flatten()
    target_flat = target.flatten()
    valid = case_weight.flatten() > 0
    positive = valid & (target_flat > 0.5)
    negative = valid & (target_flat <= 0.5)
    terms: list[torch.Tensor] = []
    if positive.any():
        terms.append(raw[positive].mean())
    if negative.any():
        terms.append(raw[negative].mean())
    return torch.stack(terms).mean() if terms else raw.new_zeros(())


def binary_structure_dice(
    probability: torch.Tensor, target: torch.Tensor, case_weight: torch.Tensor
) -> torch.Tensor:
    dims = (1, 2, 3)
    intersection = (probability * target).sum(dim=dims)
    denominator = probability.sum(dim=dims) + target.sum(dim=dims)
    positive = target.sum(dim=dims) > 0
    positive_loss = 1.0 - (2.0 * intersection + 1.0) / (denominator + 1.0)
    empty_loss = probability.mean(dim=dims)
    per_case = torch.where(positive, positive_loss, empty_loss)
    weight = case_weight.flatten()
    return (per_case * weight).sum() / weight.sum().clamp_min(1.0)


def image_gradients(image: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    return image[:, :, 1:, :] - image[:, :, :-1, :], image[:, :, :, 1:] - image[:, :, :, :-1]


def soft_erode(image: torch.Tensor) -> torch.Tensor:
    vertical = -F.max_pool2d(-image, (3, 1), stride=1, padding=(1, 0))
    horizontal = -F.max_pool2d(-image, (1, 3), stride=1, padding=(0, 1))
    return torch.minimum(vertical, horizontal)


def soft_skeleton(image: torch.Tensor, iterations: int = 8) -> torch.Tensor:
    def opened(value: torch.Tensor) -> torch.Tensor:
        return F.max_pool2d(soft_erode(value), 3, stride=1, padding=1)

    skeleton = F.relu(image - opened(image))
    eroded = image
    for _ in range(iterations):
        eroded = soft_erode(eroded)
        delta = F.relu(eroded - opened(eroded))
        skeleton = skeleton + F.relu(delta - skeleton * delta)
    return skeleton


def cutout_cldice(probability: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    pred_skeleton = soft_skeleton(probability)
    truth_skeleton = soft_skeleton(target)
    dims = (1, 2, 3)
    precision = (pred_skeleton * target).sum(dim=dims) / pred_skeleton.sum(dim=dims).clamp_min(1e-6)
    sensitivity = (truth_skeleton * probability).sum(dim=dims) / truth_skeleton.sum(dim=dims).clamp_min(1e-6)
    score = 2.0 * precision * sensitivity / (precision + sensitivity).clamp_min(1e-6)
    valid = target.sum(dim=dims) > 0
    return (1.0 - score[valid]).mean() if valid.any() else probability.new_zeros(())


def compute_loss(
    outputs: dict[str, torch.Tensor],
    batch: dict[str, torch.Tensor],
    fov: torch.Tensor,
    physics: PhysicsOperator,
    physics_weight: float,
) -> tuple[torch.Tensor, dict[str, float]]:
    probabilities = outputs["probabilities"]
    # The legacy base archive has only a convex-hull-derived approximation of
    # support/cutout.  It remains valuable for final image and physics losses,
    # but only archives with explicit structural truths supervise the Boolean
    # branches (source 1=biological, source 2=deep stress).
    structural_case = (batch["source"] != 0).float()
    structural_domain = fov * structural_case[:, None, None, None]
    class_weights = probabilities.new_tensor([0.24, 1.0, 1.0])
    final_ce = F.nll_loss(outputs["logits"], batch["labels"], weight=class_weights)
    final_dice = soft_dice_loss(probabilities, batch["labels"])
    body_bce = balanced_bce(outputs["body_field"] / 0.42, batch["support"], structural_domain)
    cutout_bce = balanced_bce(outputs["cutout_field"] / 0.42, batch["cutout"], structural_domain)
    cutout_dice = binary_structure_dice(
        outputs["raw_cutout_probability"], batch["cutout"], structural_case
    )
    body_sdf = weighted_case_mean(
        F.smooth_l1_loss(
            torch.tanh(outputs["body_field"]), batch["support_sdf"], beta=0.08, reduction="none"
        ),
        structural_case,
    )
    cutout_sdf = weighted_case_mean(
        F.smooth_l1_loss(
            torch.tanh(outputs["cutout_field"]), batch["cutout_sdf"], beta=0.08, reduction="none"
        ),
        structural_case,
    )

    target_foreground = (batch["labels"] != 0).float().unsqueeze(1)
    pred_dy, pred_dx = image_gradients(outputs["foreground_probability"])
    true_dy, true_dx = image_gradients(target_foreground)
    boundary = F.l1_loss(pred_dy, true_dy) + F.l1_loss(pred_dx, true_dx)

    target_confidence = (batch["cutout"].sum(dim=(1, 2, 3)) > 0).float().unsqueeze(1)
    confidence = balanced_confidence_loss(
        outputs["confidence_logit"], target_confidence, structural_case
    )
    mouth = balanced_bce(outputs["mouth_logit"], batch["mouth"], structural_domain)
    mouth_dice = binary_structure_dice(
        outputs["mouth_probability"], batch["mouth"], structural_case
    )
    topology = cutout_cldice(
        outputs["raw_cutout_probability"] * batch["support"] * structural_domain,
        batch["cutout"] * structural_domain,
    )

    deep_numerator = -torch.log(outputs["raw_cutout_probability"].clamp_min(1e-6))
    deep_weight = batch["cutout"] * (0.25 + 0.75 * batch["cutout_depth"]) * structural_domain
    deep_cutout = (deep_numerator * deep_weight).sum() / deep_weight.sum().clamp_min(1.0)
    bank_retention = (
        (1.0 - outputs["foreground_probability"]) * target_foreground
    ).sum() / target_foreground.sum().clamp_min(1.0)
    containment = (
        outputs["raw_cutout_probability"] * (1.0 - outputs["body_probability"]) * fov
    ).mean()
    empty = (
        (batch["cutout"].sum(dim=(1, 2, 3)) == 0).float() * structural_case
    ).reshape(-1, 1, 1, 1)
    ordinary_cut = (
        outputs["cutout_probability"] * batch["support"] * empty
    ).sum() / (batch["support"] * empty).sum().clamp_min(1.0)

    conductivity = F.smooth_l1_loss(outputs["delta"] * fov, batch["delta"] * fov, beta=0.06)
    physical = physics.loss(outputs["delta"], batch["voltage"])

    total = (
        1.00 * final_ce
        + 1.00 * final_dice
        + 0.55 * body_bce
        + 0.82 * cutout_bce
        + 0.45 * cutout_dice
        + 0.22 * body_sdf
        + 0.32 * cutout_sdf
        + 0.38 * boundary
        + 0.35 * confidence
        + 0.55 * mouth
        + 0.35 * mouth_dice
        + 0.16 * topology
        + 0.24 * deep_cutout
        + 0.28 * bank_retention
        + 0.06 * containment
        + 0.65 * ordinary_cut
        + 0.42 * conductivity
        + physics_weight * physical
    )
    pieces = {
        "total": float(total.detach()),
        "ce": float(final_ce.detach()),
        "dice": float(final_dice.detach()),
        "body": float(body_bce.detach()),
        "cutout": float(cutout_bce.detach()),
        "cutout_dice": float(cutout_dice.detach()),
        "body_sdf": float(body_sdf.detach()),
        "cutout_sdf": float(cutout_sdf.detach()),
        "boundary": float(boundary.detach()),
        "confidence": float(confidence.detach()),
        "mouth": float(mouth.detach()),
        "mouth_dice": float(mouth_dice.detach()),
        "topology": float(topology.detach()),
        "deep_cutout": float(deep_cutout.detach()),
        "bank": float(bank_retention.detach()),
        "ordinary_cut": float(ordinary_cut.detach()),
        "conductivity": float(conductivity.detach()),
        "physics": float(physical.detach()),
    }
    return total, pieces


def case_metrics(
    truth: np.ndarray,
    prediction: np.ndarray,
    support: np.ndarray,
    cutout: np.ndarray,
    body_probability: np.ndarray,
    cutout_probability: np.ndarray,
    raw_cutout_probability: np.ndarray,
    mouth_probability: np.ndarray,
    confidence: float,
) -> dict[str, float]:
    truth_fg = truth != 0
    pred_fg = prediction != 0
    intersection = np.logical_and(truth_fg, pred_fg).sum()
    union = np.logical_or(truth_fg, pred_fg).sum()
    result = {
        "foreground_iou": float(intersection / max(1, union)),
        "foreground_dice": float(2 * intersection / max(1, truth_fg.sum() + pred_fg.sum())),
        "bank_retention": float(pred_fg[truth_fg].mean()) if truth_fg.any() else float("nan"),
        "concavity_confidence": float(confidence),
        "has_cutout": float(cutout.astype(bool).any()),
    }
    body_pred = body_probability >= 0.5
    body_union = np.logical_or(support != 0, body_pred).sum()
    result["body_iou"] = float(np.logical_and(support != 0, body_pred).sum() / max(1, body_union))
    cut_pred = cutout_probability >= 0.5
    if cutout.astype(bool).any():
        cut_union = np.logical_or(cutout != 0, cut_pred).sum()
        result["cutout_iou"] = float(np.logical_and(cutout != 0, cut_pred).sum() / max(1, cut_union))
        raw_cut_pred = raw_cutout_probability >= 0.5
        raw_union = np.logical_or(cutout != 0, raw_cut_pred).sum()
        result["raw_cutout_iou"] = float(
            np.logical_and(cutout != 0, raw_cut_pred).sum() / max(1, raw_union)
        )
        mouth_pred = mouth_probability >= 0.5
        result["mouth_peak"] = float(mouth_probability.max())
        result["notch_preservation"] = float((~pred_fg[cutout != 0]).mean())
        result["false_cutout_fraction"] = float("nan")
    else:
        result["cutout_iou"] = float("nan")
        result["raw_cutout_iou"] = float("nan")
        result["mouth_peak"] = float(mouth_probability.max())
        result["notch_preservation"] = float("nan")
        result["false_cutout_fraction"] = float(cut_pred[support != 0].mean()) if (support != 0).any() else 0.0

    truth_edge = np.logical_xor(truth_fg, binary_erosion(truth_fg))
    pred_edge = np.logical_xor(pred_fg, binary_erosion(pred_fg))
    tolerance = np.ones((3, 3), dtype=bool)
    precision = (pred_edge & binary_dilation(truth_edge, structure=tolerance)).sum() / max(1, pred_edge.sum())
    recall = (truth_edge & binary_dilation(pred_edge, structure=tolerance)).sum() / max(1, truth_edge.sum())
    result["boundary_f1"] = float(2 * precision * recall / max(1e-9, precision + recall))
    return result


def aggregate(rows: list[dict[str, float]]) -> dict[str, float]:
    keys = sorted({key for row in rows for key in row})
    result: dict[str, float] = {"cases": float(len(rows))}
    for key in keys:
        values = np.asarray([row.get(key, np.nan) for row in rows], dtype=float)
        finite = np.isfinite(values)
        result[key] = float(values[finite].mean()) if finite.any() else float("nan")
    return result


@torch.no_grad()
def evaluate_loader(
    model: BooleanShapeNet,
    loader: DataLoader,
    device: torch.device,
) -> tuple[dict[str, dict[str, float]], dict[str, np.ndarray]]:
    model.eval()
    rows: list[dict[str, float]] = []
    saved: dict[str, list[np.ndarray]] = {
        key: [] for key in (
            "index", "image", "truth", "support", "cutout", "body", "raw_cut", "mouth",
            "connected_cut", "cut", "prediction", "delta", "confidence"
        )
    }
    for batch in loader:
        device_batch = to_device(batch, device)
        outputs = model(device_batch["image"], device_batch["voltage"])
        prediction = outputs["logits"].argmax(dim=1).cpu().numpy()
        body = outputs["body_probability"][:, 0].cpu().numpy()
        cut = outputs["cutout_probability"][:, 0].cpu().numpy()
        raw_cut = outputs["raw_cutout_probability"][:, 0].cpu().numpy()
        mouth_probability = outputs["mouth_probability"][:, 0].cpu().numpy()
        connected_cut = outputs["connected_cutout_probability"][:, 0].cpu().numpy()
        delta = outputs["delta"][:, 0].cpu().numpy()
        confidence = outputs["confidence"][:, 0, 0, 0].cpu().numpy()
        for offset in range(len(prediction)):
            rows.append(
                case_metrics(
                    batch["labels"][offset].numpy(), prediction[offset],
                    batch["support"][offset, 0].numpy(), batch["cutout"][offset, 0].numpy(),
                    body[offset], cut[offset], raw_cut[offset], mouth_probability[offset],
                    float(confidence[offset]),
                )
            )
        saved["index"].append(batch["index"].numpy())
        saved["image"].append(batch["image"][:, 0].numpy())
        saved["truth"].append(batch["labels"].numpy())
        saved["support"].append(batch["support"][:, 0].numpy())
        saved["cutout"].append(batch["cutout"][:, 0].numpy())
        saved["body"].append(body)
        saved["raw_cut"].append(raw_cut)
        saved["mouth"].append(mouth_probability)
        saved["connected_cut"].append(connected_cut)
        saved["cut"].append(cut)
        saved["prediction"].append(prediction)
        saved["delta"].append(delta)
        saved["confidence"].append(confidence)
    concave = [row for row in rows if row["has_cutout"] > 0.5]
    ordinary = [row for row in rows if row["has_cutout"] <= 0.5]
    summaries = {
        "all": aggregate(rows),
        "concave": aggregate(concave) if concave else {"cases": 0.0},
        "ordinary": aggregate(ordinary) if ordinary else {"cases": 0.0},
    }
    arrays = {key: np.concatenate(value, axis=0) for key, value in saved.items()}
    return summaries, arrays


def selection_score(metrics: dict[str, dict[str, dict[str, float]]]) -> float:
    base = metrics["base"]
    biological = metrics["biological"]
    stress = metrics["stress"]
    score = (
        0.15 * base["all"]["foreground_iou"]
        + 0.10 * base["all"]["boundary_f1"]
        + 0.12 * biological["all"]["foreground_iou"]
        + 0.15 * biological["ordinary"].get("foreground_iou", 0.0)
        + 0.10 * biological["concave"].get("foreground_iou", 0.0)
        + 0.12 * biological["concave"].get("notch_preservation", 0.0)
        + 0.13 * stress["all"]["foreground_iou"]
        + 0.13 * stress["concave"].get("notch_preservation", 0.0)
    )
    false_cut = biological["ordinary"].get("false_cutout_fraction", 0.0)
    bank = min(
        base["all"].get("bank_retention", 0.0),
        biological["all"].get("bank_retention", 0.0),
        stress["all"].get("bank_retention", 0.0),
    )
    return float(score - 0.90 * max(0.0, false_cut - 0.005) - 0.30 * max(0.0, 0.84 - bank))


def choose_visual_indices(arrays: dict[str, np.ndarray], count: int = 2) -> np.ndarray:
    cut_pixels = arrays["cutout"].reshape(len(arrays["cutout"]), -1).sum(axis=1)
    concave = np.argsort(cut_pixels)[-count:][::-1]
    ordinary_pool = np.flatnonzero(cut_pixels == 0)
    ordinary = ordinary_pool[:count] if ordinary_pool.size else np.asarray([], dtype=int)
    return np.concatenate((concave, ordinary)).astype(int)


def save_montage(path: Path, groups: dict[str, dict[str, np.ndarray]], title: str) -> None:
    selected: list[tuple[str, int]] = []
    for name, arrays in groups.items():
        selected.extend((name, int(index)) for index in choose_visual_indices(arrays))
    columns = (
        "linear input", "truth", "body target", "cutout target", "body probability",
        "raw cutout", "mouth", "effective cutout", "Boolean output", "conductivity"
    )
    figure, axes = plt.subplots(len(selected), len(columns), figsize=(18.0, 2.15 * len(selected)), squeeze=False)
    for row, (name, index) in enumerate(selected):
        a = groups[name]
        linear = a["image"][index]
        scale = max(float(np.percentile(np.abs(linear), 99)), 1e-6)
        panels = (
            (linear, "coolwarm", -scale, scale),
            (a["truth"][index], "viridis", 0, 2),
            (a["support"][index], "gray", 0, 1),
            (a["cutout"][index], "magma", 0, 1),
            (a["body"][index], "gray", 0, 1),
            (a["raw_cut"][index], "magma", 0, 1),
            (a["mouth"][index], "plasma", 0, 1),
            (a["cut"][index], "magma", 0, 1),
            (a["prediction"][index], "viridis", 0, 2),
            (a["delta"][index], "coolwarm", -1.1, 1.1),
        )
        for column, (panel, cmap, vmin, vmax) in enumerate(panels):
            axes[row, column].imshow(panel, cmap=cmap, vmin=vmin, vmax=vmax)
            axes[row, column].set_axis_off()
            if row == 0:
                axes[row, column].set_title(columns[column], fontsize=9)
        cut_pixels = int(a["cutout"][index].sum())
        axes[row, 0].set_ylabel(
            f"{name} #{int(a['index'][index])}\ncut={cut_pixels}, conf={float(a['confidence'][index]):.2f}",
            fontsize=8,
        )
    figure.suptitle(title, fontsize=14)
    figure.tight_layout()
    figure.savefig(path, dpi=150)
    plt.close(figure)


def save_history(path: Path, history: list[dict[str, object]]) -> None:
    epochs = [int(row["epoch"]) for row in history]
    figure, axes = plt.subplots(1, 3, figsize=(13.5, 3.8))
    axes[0].plot(epochs, [float(row["train_loss"]) for row in history], marker="o", ms=3)
    axes[0].set_title("training loss")
    axes[1].plot(epochs, [float(row["score"]) for row in history], marker="o", ms=3)
    axes[1].set_title("validation selection score")
    for name in ("base", "biological", "stress"):
        axes[2].plot(
            epochs,
            [float(row["validation"][name]["all"]["foreground_iou"]) for row in history],
            label=name,
        )
    axes[2].set_title("validation foreground IoU")
    axes[2].legend(fontsize=8)
    for axis in axes:
        axis.grid(alpha=0.25)
        axis.set_xlabel("epoch")
    figure.tight_layout()
    figure.savefig(path, dpi=160)
    plt.close(figure)


def make_loader(dataset: Dataset, args: argparse.Namespace, shuffle: bool) -> DataLoader:
    return DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=shuffle,
        num_workers=args.workers,
        pin_memory=torch.cuda.is_available(),
        persistent_workers=args.workers > 0,
    )


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    archives = {
        "base": np.load(args.base_dataset.resolve(), allow_pickle=True),
        "biological": np.load(args.biological_dataset.resolve(), allow_pickle=True),
        "stress": np.load(args.stress_dataset.resolve(), allow_pickle=True),
    }
    arrays = {name: prepare_arrays(archive, name) for name, archive in archives.items()}
    for name in ("biological", "stress"):
        if not np.array_equal(arrays["base"].fov_mask, arrays[name].fov_mask):
            raise ValueError(f"{name} FOV differs from the base KTC protocol")
    if args.device == "auto":
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is not available")

    train_parts: list[Dataset] = [
        StructuralDataset(arrays["base"], archives["base"]["train_indices"], 0),
        StructuralDataset(arrays["biological"], archives["biological"]["train_indices"], 1),
    ]
    for _ in range(max(1, args.stress_repeat)):
        train_parts.append(StructuralDataset(arrays["stress"], archives["stress"]["train_indices"], 2))
    train_loader = make_loader(ConcatDataset(train_parts), args, shuffle=True)
    validation_loaders = {
        name: make_loader(
            StructuralDataset(arrays[name], archives[name]["validation_indices"], source), args, shuffle=False
        )
        for source, name in enumerate(("base", "biological", "stress"))
    }
    test_loaders = {
        name: make_loader(
            StructuralDataset(arrays[name], archives[name]["test_indices"], source), args, shuffle=False
        )
        for source, name in enumerate(("base", "biological", "stress"))
    }
    model = BooleanShapeNet(arrays["base"].fov_mask, base=args.base_channels).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(1, args.epochs), eta_min=1e-5)
    # The topology and signed-distance terms can produce large but valid early
    # gradients.  Starting at 65536 overflows FP16 before dynamic scaling has
    # time to adapt and causes the first optimizer steps to be skipped.
    scaler = torch.amp.GradScaler(
        "cuda", enabled=device.type == "cuda", init_scale=1024.0, growth_interval=1000
    )
    physics = PhysicsOperator(
        jacobian=torch.from_numpy(np.asarray(archives["base"]["jacobian"], dtype=np.float32)).to(device),
        node_to_raw_pixel=torch.from_numpy(
            np.asarray(archives["base"]["node_to_raw_pixel"], dtype=np.int64)
        ).to(device),
    )
    fov = torch.from_numpy(arrays["base"].fov_mask.astype(np.float32))[None, None].to(device)
    start_epoch = 1
    best_score = -float("inf")
    history: list[dict[str, object]] = []
    if args.resume is not None:
        state = torch.load(args.resume, map_location=device, weights_only=False)
        model.load_state_dict(state["model"])
        if "optimizer" in state:
            optimizer.load_state_dict(state["optimizer"])
        start_epoch = int(state.get("epoch", 0)) + 1
        best_score = float(state.get("validation_score", -float("inf")))

    parameter_count = sum(parameter.numel() for parameter in model.parameters())
    print(
        f"device={device}; gpu={torch.cuda.get_device_name(0) if device.type == 'cuda' else 'none'}; "
        f"parameters={parameter_count:,}; train={len(train_loader.dataset)}; "
        f"validation={[len(loader.dataset) for loader in validation_loaders.values()]}",
        flush=True,
    )
    checkpoint_path = output_dir / "boolean_shape_v2_best.pt"
    stale = 0
    for epoch in range(start_epoch, args.epochs + 1):
        epoch_start = time.perf_counter()
        model.train()
        totals: dict[str, float] = {}
        batches = 0
        for batch_index, batch in enumerate(train_loader, start=1):
            if args.max_train_batches and batch_index > args.max_train_batches:
                break
            batch = to_device(batch, device)
            optimizer.zero_grad(set_to_none=True)
            with torch.amp.autocast(device.type, enabled=device.type == "cuda"):
                outputs = model(batch["image"], batch["voltage"])
                loss, pieces = compute_loss(outputs, batch, fov, physics, args.physics_weight)
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            if args.diagnose_gradients:
                invalid = []
                for name, parameter in model.named_parameters():
                    if parameter.grad is not None and not torch.isfinite(parameter.grad).all():
                        invalid.append(name)
                print(
                    json.dumps(
                        {
                            "loss": float(loss.detach()),
                            "pieces": pieces,
                            "nonfinite_gradient_parameters": invalid,
                        },
                        indent=2,
                    ),
                    flush=True,
                )
                return
            torch.nn.utils.clip_grad_norm_(model.parameters(), 4.0)
            scaler.step(optimizer)
            scaler.update()
            batches += 1
            for key, value in pieces.items():
                totals[key] = totals.get(key, 0.0) + value
        scheduler.step()
        averages = {key: value / max(1, batches) for key, value in totals.items()}
        validation: dict[str, dict[str, dict[str, float]]] = {}
        visuals: dict[str, dict[str, np.ndarray]] = {}
        for name, loader in validation_loaders.items():
            validation[name], visuals[name] = evaluate_loader(model, loader, device)
        score = selection_score(validation)
        elapsed = time.perf_counter() - epoch_start
        row: dict[str, object] = {
            "epoch": epoch,
            "train_loss": averages.get("total", float("nan")),
            "train_pieces": averages,
            "learning_rate": optimizer.param_groups[0]["lr"],
            "score": score,
            "elapsed_seconds": elapsed,
            "validation": validation,
        }
        history.append(row)
        improved = score > best_score
        if improved:
            best_score = score
            stale = 0
            torch.save(
                {
                    "model": model.state_dict(),
                    "optimizer": optimizer.state_dict(),
                    "epoch": epoch,
                    "validation_score": score,
                    "validation": validation,
                    "base_channels": args.base_channels,
                    "temperature": model.temperature,
                    "args": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
                },
                checkpoint_path,
            )
        else:
            stale += 1
        print(
            f"epoch={epoch:03d} loss={averages.get('total', float('nan')):.4f} score={score:.4f} "
            f"base_iou={validation['base']['all']['foreground_iou']:.4f} "
            f"bio_iou={validation['biological']['all']['foreground_iou']:.4f} "
            f"bio_notch={validation['biological']['concave'].get('notch_preservation', float('nan')):.4f} "
            f"stress_iou={validation['stress']['all']['foreground_iou']:.4f} "
            f"stress_notch={validation['stress']['concave'].get('notch_preservation', float('nan')):.4f} "
            f"ordinary_false={validation['base']['ordinary'].get('false_cutout_fraction', float('nan')):.4f} "
            f"best={improved} time={elapsed:.1f}s",
            flush=True,
        )
        (output_dir / "training_history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
        save_history(output_dir / "training_history.png", history)
        if improved or epoch == 1 or epoch % max(1, args.progress_every) == 0:
            save_montage(
                output_dir / f"validation_epoch_{epoch:03d}.png",
                visuals,
                f"Boolean Shape EIT v2 validation, epoch {epoch} (score={score:.4f})",
            )
        if stale >= args.patience:
            print(f"early stopping at epoch {epoch}; best score={best_score:.4f}", flush=True)
            break

    state = torch.load(checkpoint_path, map_location=device, weights_only=False)
    model.load_state_dict(state["model"])
    model.eval()
    test_metrics: dict[str, dict[str, dict[str, float]]] = {}
    test_visuals: dict[str, dict[str, np.ndarray]] = {}
    for name, loader in test_loaders.items():
        test_metrics[name], test_visuals[name] = evaluate_loader(model, loader, device)
    save_montage(
        output_dir / "independent_test_comparison.png",
        test_visuals,
        f"Boolean Shape EIT v2 independent tests (best epoch {state['epoch']})",
    )
    np.savez_compressed(
        output_dir / "test_predictions.npz",
        **{
            f"{name}_{key}": value
            for name, group in test_visuals.items()
            for key, value in group.items()
        },
    )
    summary = {
        "method": "independent differentiable Boolean body-minus-cutout EIT network",
        "device": str(device),
        "gpu": torch.cuda.get_device_name(0) if device.type == "cuda" else None,
        "parameters": parameter_count,
        "best_epoch": int(state["epoch"]),
        "best_validation_score": float(state["validation_score"]),
        "validation": state["validation"],
        "independent_test": test_metrics,
        "public_ktc_truth_used_for_training_or_selection": False,
        "training_samples": len(train_loader.dataset),
        "args": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
