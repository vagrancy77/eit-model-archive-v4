#!/usr/bin/env bash
set -euo pipefail

cd /mnt/e/Codex/eit_reproduction
python reproduce_gn4ip.py
python train_gn4ip_short.py --epochs 3
python adapt_cem_to_gn4ip.py
python train_gn4ip_on_cem.py --epochs 20
