"""Validation-selected pixel fusion for concave/open EIT lesions.

The stable Boolean reconstruction supplies the lesion banks.  The entrance
branch supplies a cutout confidence field.  Only pixels that are background in
an exterior-connected entrance component and have high cutout confidence are
removed from the stable foreground.  This is deliberately local: it cannot
replace an entire lesion with the more aggressive proposal.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from types import SimpleNamespace

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import binary_dilation, label as connected_components

from prepare_ktc_deep_concavity_stress import FAMILIES
from train_ktc_concavity_network import InputAdapter, save_focus_montage, save_real_montage, write_rows
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_highres_refiner import load_coarse_ensemble
from train_ktc_implicit_boolean_network import ImplicitBooleanNet, prepare_structural_arrays, standard_metrics, stress_metrics
from calibrate_ktc_implicit_boolean import collect_raw_fields, predict_from_fields
from select_ktc_mouth_gating import collect_entrance_fields, case_features, component_count

STRUCTURE = np.ones((3, 3), dtype=np.uint8)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    parser.add_argument("--stable-checkpoint", type=Path, default=root / "outputs" / "ktc_topology_boolean_smoke_seed20260819" / "implicit_boolean_best.pt")
    parser.add_argument("--entrance-checkpoint", type=Path, default=root / "outputs" / "ktc_mouth_contact_repeat4_seed20260820" / "implicit_boolean_best.pt")
    parser.add_argument("--coarse-checkpoint", nargs="+", type=Path, default=[
        root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "boundary_best.pt",
        root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "indent_best.pt",
        root / "outputs" / "ktc_concavity_voltage_seed20260819" / "voltage_best.pt",
    ])
    parser.add_argument("--coarse-weights", nargs="+", type=float, default=[0.30, 0.40, 0.30])
    parser.add_argument("--output-dir", type=Path, default=root / "ktc_pixel_fusion_seed20260820")
    parser.add_argument("--batch-size", type=int, default=24)
    return parser.parse_args()


def load_model(path: Path, device: torch.device) -> ImplicitBooleanNet:
    state = torch.load(path.resolve(), map_location=device, weights_only=False)
    model = ImplicitBooleanNet(int(state["base_channels"])).to(device)
    model.load_state_dict(state["model"], strict=False)
    model.eval()
    return model


def exterior_background(prediction: np.ndarray) -> np.ndarray:
    background = prediction == 0
    components, count = connected_components(background.astype(np.uint8), structure=STRUCTURE)
    if count == 0:
        return np.zeros_like(background, dtype=bool)
    border = np.unique(np.concatenate((components[0], components[-1], components[:, 0], components[:, -1])))
    return np.isin(components, border[border != 0])


def pixel_fusion(stable: np.ndarray, entrance: np.ndarray, cutout: np.ndarray, mouth: np.ndarray, selected: np.ndarray, threshold: float, mouth_threshold: float = 0.5, mouth_dilation: int = 0) -> np.ndarray:
    result = stable.copy()
    for index in np.flatnonzero(selected):
        corridor = exterior_background(entrance[index])
        contact = mouth[index] >= mouth_threshold
        if mouth_dilation > 0:
            contact = binary_dilation(contact, structure=STRUCTURE, iterations=mouth_dilation)
        # The stable foreground protects the lesion banks.  The entrance head
        # can only carve a high-confidence, externally connected corridor;
        # the contact field supplies the missing one-to-several-pixel mouth.
        carve = (stable[index] != 0) & (entrance[index] == 0) & corridor & ((cutout[index] >= threshold) | contact)
        result[index][carve] = 0
    return result


def select_gate(base_truth, base_indent, base_stable, base_entrance, base_cutout, base_mouth, stress_truth, stress_cutout_truth, stress_depth, stress_family, stress_stable, stress_entrance, stress_cutout, stress_mouth):
    base_stable_metric = standard_metrics(base_truth, base_stable, base_indent)
    stress_stable_metric, _, _ = stress_metrics(stress_truth, stress_stable, stress_cutout_truth, stress_depth, stress_family)
    bf = case_features(base_stable, base_entrance, base_cutout)
    sf = case_features(stress_stable, stress_entrance, stress_cutout)
    rows = []
    best = None
    for area_threshold in (0.70, 0.80, 0.90, 0.95):
        for opening_threshold in (0.60, 0.70, 0.80, 0.90):
            base_area_ok = bf["area_ratio"] >= area_threshold
            stress_area_ok = sf["area_ratio"] >= area_threshold
            base_open_ok = bf["opening_confidence"] >= opening_threshold
            stress_open_ok = sf["opening_confidence"] >= opening_threshold
            # A split lesion is a failure mode for an open target, so the
            # structural gate never enables a proposal with more components.
            base_selected = base_area_ok & base_open_ok & (bf["entrance_components"] <= bf["stable_components"])
            stress_selected = stress_area_ok & stress_open_ok & (sf["entrance_components"] <= sf["stable_components"])
            for cutout_threshold in (0.50, 0.60, 0.70, 0.80, 0.90):
                for mouth_threshold in (0.30, 0.50, 0.70):
                    for mouth_dilation in (0, 1, 2, 3, 4):
                        base_pred = pixel_fusion(base_stable, base_entrance, base_cutout, base_mouth, base_selected, cutout_threshold, mouth_threshold, mouth_dilation)
                        stress_pred = pixel_fusion(stress_stable, stress_entrance, stress_cutout, stress_mouth, stress_selected, cutout_threshold, mouth_threshold, mouth_dilation)
                        bm = standard_metrics(base_truth, base_pred, base_indent)
                        sm, fam, _ = stress_metrics(stress_truth, stress_pred, stress_cutout_truth, stress_depth, stress_family)
                        eligible = bm["foreground_iou"] >= base_stable_metric["foreground_iou"] - 0.010 and bm["boundary_f1"] >= base_stable_metric["boundary_f1"] - 0.015 and sm["foreground_iou"] >= stress_stable_metric["foreground_iou"] - 0.015 and sm["bank_retention"] >= stress_stable_metric["bank_retention"] - 0.04
                        row = {"area_threshold": area_threshold, "opening_threshold": opening_threshold, "cutout_threshold": cutout_threshold, "mouth_threshold": mouth_threshold, "mouth_dilation": mouth_dilation, "eligible": bool(eligible), "base_iou": bm["foreground_iou"], "base_boundary_f1": bm["boundary_f1"], "stress_iou": sm["foreground_iou"], "stress_boundary_f1": sm["boundary_f1"], "stress_open_deep_cutout": sm["open_deep_cutout_recovery"], "stress_bank_retention": sm["bank_retention"], "stress_topology_joint": sm["topology_structural_joint"], "deep_c_open_deep_cutout": fam["deep_c"]["open_deep_cutout_recovery"], "deep_c_bank_retention": fam["deep_c"]["bank_retention"], "base_selected_fraction": float(base_selected.mean()), "stress_selected_fraction": float(stress_selected.mean())}
                        rows.append(row)
                        key = (float(row["stress_topology_joint"]), float(row["deep_c_open_deep_cutout"]), float(row["stress_open_deep_cutout"]), -float(row["stress_selected_fraction"]))
                        if row["eligible"] and (best is None or key > best["_key"]):
                            best = {**row, "_key": key}
    if best is None:
        best = max(rows, key=lambda r: (float(r["stress_topology_joint"]), float(r["deep_c_open_deep_cutout"])))
    best.pop("_key", None)
    return best, rows


def apply_selected(stable, entrance, cutout, mouth, area_threshold, opening_threshold, cutout_threshold, mouth_threshold, mouth_dilation):
    feat = case_features(stable, entrance, cutout)
    selected = (feat["area_ratio"] >= area_threshold) & (feat["opening_confidence"] >= opening_threshold) & (feat["entrance_components"] <= feat["stable_components"])
    return pixel_fusion(stable, entrance, cutout, mouth, selected, cutout_threshold, mouth_threshold, mouth_dilation), selected


def save_montage(path, truth, stable, entrance, fused, selected, title):
    indices = list(range(min(16, len(truth))))
    figure, axes = plt.subplots(len(indices), 5, figsize=(12, 2.3 * len(indices)), squeeze=False)
    selected_image = np.broadcast_to(selected[:, None, None], fused.shape)
    for row, index in enumerate(indices):
        for col, (image, name) in enumerate(((truth[index], "truth"), (stable[index], "stable"), (entrance[index], "entrance"), (fused[index], "pixel fusion"), (selected_image[index], "gate"))):
            axes[row, col].imshow(image, cmap="viridis", vmin=0, vmax=2, interpolation="nearest"); axes[row, col].set_title(name); axes[row, col].set_axis_off()
    figure.suptitle(title); figure.tight_layout(); figure.savefig(path, dpi=180); plt.close(figure)


def main() -> None:
    args = parse_args(); out = args.output_dir.resolve(); out.mkdir(parents=True, exist_ok=True)
    ba = np.load(args.base_dataset.resolve(), allow_pickle=False); sa = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    # The base archive has no implicit support fields and does not need them
    # for this evaluator.  Avoid recomputing 3,000 signed-distance maps just
    # to access its images/labels.
    base = SimpleNamespace(
        images=np.asarray(ba["linear_images"], dtype=np.float32),
        voltages=np.asarray(ba["voltages"], dtype=np.float32),
        labels=np.asarray(ba["labels"], dtype=np.uint8),
        indentation=np.asarray(ba["indentation_masks"], dtype=np.uint8),
    )
    stress = prepare_structural_arrays(sa, "stress")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    coarse, _, weights = load_coarse_ensemble(args.coarse_checkpoint, args.coarse_weights, device); adapter = InputAdapter(ba["fov_mask"]).to(device)
    stable_model = load_model(args.stable_checkpoint, device); entrance_model = load_model(args.entrance_checkpoint, device)

    def infer(images, voltages):
        stable_fields = collect_raw_fields(images, voltages, coarse, stable_model, adapter, device, args.batch_size)
        stable = predict_from_fields(stable_fields, -1.25, 0.35, 0.70)
        entrance_fields = collect_entrance_fields(images, voltages, coarse, entrance_model, adapter, device, args.batch_size)
        entrance = entrance_fields["prediction"]
        return stable, entrance, entrance_fields["cutout"], entrance_fields["mouth"]

    bv = np.asarray(ba["validation_indices"], dtype=np.int64); sv = np.asarray(sa["validation_indices"], dtype=np.int64)
    bs, be, bc, bm = infer(base.images[bv], base.voltages[bv]); ss, se, sc, smouth = infer(stress.images[sv], stress.voltages[sv])
    selected, grid = select_gate(base.labels[bv], base.indentation[bv], bs, be, bc, bm, stress.labels[sv], stress.cutout[sv], stress.cutout_depth[sv], stress.family_codes[sv], ss, se, sc, smouth)
    with (out / "validation_grid.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(grid[0])); writer.writeheader(); writer.writerows(grid)

    def run_split(name, bs, be, bc, bm, ss, se, sc, sm, btruth, bindent, struth, scut, sdepth, sfamily):
        fused, bsel = apply_selected(bs, be, bc, bm, float(selected["area_threshold"]), float(selected["opening_threshold"]), float(selected["cutout_threshold"]), float(selected["mouth_threshold"]), int(selected["mouth_dilation"]))
        sfused, ssel = apply_selected(ss, se, sc, sm, float(selected["area_threshold"]), float(selected["opening_threshold"]), float(selected["cutout_threshold"]), float(selected["mouth_threshold"]), int(selected["mouth_dilation"]))
        smethods = {"stable": bs, "entrance": be, "pixel_fusion": fused}; tmethods = {"stable": ss, "entrance": se, "pixel_fusion": sfused}
        bmetrics = {k: standard_metrics(btruth, v, bindent) for k, v in smethods.items()}
        smetrics = {}
        for k, v in tmethods.items():
            summary, family, rows = stress_metrics(struth, v, scut, sdepth, sfamily); smetrics[k] = {"summary": summary, "by_family": family, "rows": rows}
        save_montage(out / f"{name}_pixel_fusion_montage.png", btruth, bs, be, fused, bsel, f"{name}: pixel-level stable/entrance fusion")
        return {"base": bmetrics, "stress": smetrics, "base_selected_fraction": float(bsel.mean()), "stress_selected_fraction": float(ssel.mean())}, (fused, sfused)

    bt = np.asarray(ba["test_indices"], dtype=np.int64); st = np.asarray(sa["test_indices"], dtype=np.int64)
    bts, bte, btc, btm = infer(base.images[bt], base.voltages[bt]); sts, ste, stc, stm = infer(stress.images[st], stress.voltages[st])
    test, test_pred = run_split("test", bts, bte, btc, btm, sts, ste, stc, stm, base.labels[bt], base.indentation[bt], stress.labels[st], stress.cutout[st], stress.cutout_depth[st], stress.family_codes[st])

    real_images = np.asarray(ba["real_linear_images"], dtype=np.float32); real_voltages = np.asarray(ba["real_voltages"], dtype=np.float32)
    rs, re, rc, rm = infer(real_images, real_voltages)
    rs = predict_from_fields(collect_raw_fields(real_images, real_voltages, coarse, stable_model, adapter, device, args.batch_size), -1.25, 0.35, 0.70, output_size=256)
    ef = collect_entrance_fields(real_images, real_voltages, coarse, entrance_model, adapter, device, args.batch_size)
    re = F.interpolate(torch.from_numpy(ef["logits"]), size=(256, 256), mode="bilinear", align_corners=False).argmax(dim=1).numpy().astype(np.uint8)
    rc = F.interpolate(torch.from_numpy(ef["cutout"][:, None]), size=(256, 256), mode="bilinear", align_corners=False)[:, 0].numpy()
    rm = F.interpolate(torch.from_numpy(ef["mouth"][:, None]), size=(256, 256), mode="bilinear", align_corners=False)[:, 0].numpy()
    rg, rsel = apply_selected(rs, re, rc, rm, float(selected["area_threshold"]), float(selected["opening_threshold"]), float(selected["cutout_threshold"]), float(selected["mouth_threshold"]), int(selected["mouth_dilation"]))
    truth = np.asarray(ba["real_labels"]); ids = np.asarray(ba["real_ids"]); real_predictions = {"stable_boolean": rs, "entrance_boolean": re, "pixel_fusion": rg}; real_summary = {}; real_rows = []
    for method, pred in real_predictions.items():
        summary, rows = evaluate_real_predictions(method, pred, truth, ids); real_summary[method] = summary; real_rows.extend(rows)
    write_rows(out / "real_case_metrics.csv", real_rows); save_real_montage(out / "real_all_21_comparison.png", truth, ids, real_predictions, real_rows); save_focus_montage(out / "real_most_concave_comparison.png", truth, ids, real_predictions, real_rows)
    np.savez_compressed(out / "predictions.npz", base_test_indices=bt, stress_test_indices=st, base_stable=bts, base_entrance=bte, base_pixel_fusion=test_pred[0], stress_stable=sts, stress_entrance=ste, stress_pixel_fusion=test_pred[1], real_stable=rs, real_entrance=re, real_pixel_fusion=rg, real_selected=rsel)
    result = {"method": "validation-selected exterior-connected cutout pixel fusion", "selected_parameters": selected, "test": test, "real_evaluation": real_summary, "real_selected_fraction": float(rsel.mean()), "evaluation_truth_used_for_training_or_selection": False, "stable_checkpoint": str(args.stable_checkpoint.resolve()), "entrance_checkpoint": str(args.entrance_checkpoint.resolve()), "coarse_weights": weights}
    (out / "summary.json").write_text(json.dumps(result, indent=2), encoding="utf-8"); print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
