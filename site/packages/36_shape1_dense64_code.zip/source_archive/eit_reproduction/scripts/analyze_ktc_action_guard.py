"""Select an action-conditional reliability guard without using KTC labels.

The neural gate proposes one implicit-Boolean expert.  This analysis accepts
that proposal only when it lies near synthetic training samples for which the
same expert produced a real utility improvement over coarse EIT.  All guard
hyperparameters are selected on synthetic validation utility; public KTC
labels are opened only after the guard is frozen.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch
from scipy.spatial import cKDTree

from train_ktc_implicit_boolean_network import prepare_structural_arrays, standard_metrics, stress_metrics
from train_ktc_reliability_gate import (
    CANDIDATE_SPECS,
    GAIN_SCALE,
    GateArrays,
    ReliabilityGate,
    gate_logits,
    gather,
    select_candidates,
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--experiment-dir", type=Path,
        default=root / "outputs" / "ktc_reliability_ood_guard_seed20260901",
    )
    parser.add_argument(
        "--gate-checkpoint", type=Path,
        default=root / "outputs" / "ktc_reliability_gain_gate_seed20260901" / "reliability_gate_best.pt",
    )
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument(
        "--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz"
    )
    parser.add_argument("--gate-threshold", type=float, default=2.0)
    parser.add_argument("--seed", type=int, default=20260903)
    return parser.parse_args()


def action_distances(
    train_features: np.ndarray,
    train_utilities: np.ndarray,
    query_features: np.ndarray,
    actions: np.ndarray,
    minimum_gain: float,
    neighbours: int,
) -> np.ndarray:
    result = np.full(len(query_features), np.inf, dtype=np.float64)
    for action in range(1, len(CANDIDATE_SPECS)):
        query_mask = actions == action
        if not np.any(query_mask):
            continue
        gains = train_utilities[:, action] - train_utilities[:, 0]
        reference = train_features[gains >= minimum_gain]
        if len(reference) < neighbours:
            continue
        tree = cKDTree(reference.astype(np.float64))
        distance, _ = tree.query(
            query_features[query_mask].astype(np.float64), k=min(neighbours, len(reference)), workers=-1
        )
        if neighbours > 1:
            distance = np.mean(distance, axis=1)
        result[query_mask] = distance
    return result


def action_cutoffs(
    distances: np.ndarray,
    actions: np.ndarray,
    utilities: np.ndarray,
    minimum_gain: float,
    quantile: float,
) -> np.ndarray:
    cutoffs = np.zeros(len(CANDIDATE_SPECS), dtype=np.float64)
    for action in range(1, len(CANDIDATE_SPECS)):
        actual_gain = utilities[:, action] - utilities[:, 0]
        calibration = distances[(actions == action) & (actual_gain >= minimum_gain)]
        calibration = calibration[np.isfinite(calibration)]
        if len(calibration) >= 3:
            cutoffs[action] = float(np.quantile(calibration, quantile, method="higher"))
    return cutoffs


def guard(actions: np.ndarray, distances: np.ndarray, cutoffs: np.ndarray) -> np.ndarray:
    accepted = (actions != 0) & np.isfinite(distances) & (distances <= cutoffs[actions])
    return np.where(accepted, actions, 0).astype(np.int64)


def utility_summary(selected: np.ndarray, utilities: np.ndarray, split_at: int) -> dict[str, float]:
    rows: dict[str, float] = {}
    for name, values, choices in (
        ("base", utilities[:split_at], selected[:split_at]),
        ("stress", utilities[split_at:], selected[split_at:]),
        ("combined", utilities, selected),
    ):
        chosen = values[np.arange(len(choices)), choices]
        coarse = values[:, 0]
        proposed_gain = chosen - coarse
        accepted = choices != 0
        rows[f"{name}_utility"] = float(np.mean(chosen))
        rows[f"{name}_gain"] = float(np.mean(proposed_gain))
        rows[f"{name}_acceptance"] = float(np.mean(accepted))
        rows[f"{name}_accepted_precision"] = (
            float(np.mean(proposed_gain[accepted] > 0.0)) if np.any(accepted) else 1.0
        )
    return rows


def main() -> None:
    args = parse_args()
    experiment_dir = args.experiment_dir.resolve()
    saved = np.load(experiment_dir / "predictions.npz", allow_pickle=False)
    base_archive = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress_archive = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    train_features = saved["train_features"]
    train_utilities = saved["train_utilities"]
    validation_features = saved["validation_features"]
    validation_utilities = saved["validation_utilities"]

    base_val_indices = np.asarray(base_archive["validation_indices"], dtype=np.int64)
    stress_val_indices = np.asarray(stress_archive["validation_indices"], dtype=np.int64)
    validation_images = np.concatenate((
        base_archive["linear_images"][base_val_indices], stress_archive["linear_images"][stress_val_indices]
    ))
    validation_voltages = np.concatenate((
        base_archive["voltages"][base_val_indices], stress_archive["voltages"][stress_val_indices]
    ))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    state = torch.load(args.gate_checkpoint.resolve(), map_location=device, weights_only=False)
    model = ReliabilityGate(validation_features.shape[1], validation_utilities.shape[1]).to(device)
    model.load_state_dict(state["model"])
    model.eval()
    validation_input = GateArrays(
        validation_images, validation_voltages, validation_features,
        np.zeros_like(validation_utilities, dtype=np.float32),
    )
    validation_logits = gate_logits(model, validation_input, device, batch_size=64)
    validation_proposed = select_candidates(validation_logits, args.gate_threshold)
    split_at = len(base_val_indices)

    rows: list[dict[str, float | int]] = []
    configurations: list[tuple[float, int, float, np.ndarray]] = []
    for minimum_gain in (0.0, 0.02, 0.04, 0.06, args.gate_threshold / GAIN_SCALE):
        for neighbours in (1, 3, 5, 10):
            distances = action_distances(
                train_features, train_utilities, validation_features, validation_proposed,
                minimum_gain, neighbours,
            )
            for quantile in (0.80, 0.90, 0.95, 0.975, 0.99):
                cutoffs = action_cutoffs(
                    distances, validation_proposed, validation_utilities, minimum_gain, quantile
                )
                selected = guard(validation_proposed, distances, cutoffs)
                row: dict[str, float | int] = {
                    "minimum_gain": minimum_gain, "neighbours": neighbours, "quantile": quantile,
                    **utility_summary(selected, validation_utilities, split_at),
                }
                rows.append(row)
                configurations.append((minimum_gain, neighbours, quantile, cutoffs))

    coarse_base = float(np.mean(validation_utilities[:split_at, 0]))
    coarse_stress = float(np.mean(validation_utilities[split_at:, 0]))
    eligible = [
        index for index, row in enumerate(rows)
        if row["base_utility"] >= coarse_base - 0.001
        and row["stress_utility"] >= coarse_stress
        and row["combined_accepted_precision"] >= 0.70
    ]
    if not eligible:
        eligible = list(range(len(rows)))
    best_index = max(
        eligible,
        key=lambda index: (
            rows[index]["stress_gain"], rows[index]["combined_gain"],
            rows[index]["combined_accepted_precision"],
        ),
    )
    best_row = rows[best_index]
    minimum_gain, neighbours, quantile, cutoffs = configurations[best_index]

    test_sources: dict[str, dict[str, np.ndarray]] = {}
    for source in ("base", "stress", "real"):
        features = saved[f"{source}_test_features"] if source != "real" else saved["real_features"]
        proposed = saved[f"{source}_proposed"] if source == "real" else saved[f"{source}_proposed"]
        distances = action_distances(
            train_features, train_utilities, features, proposed, minimum_gain, neighbours
        )
        selected = guard(proposed, distances, cutoffs)
        test_sources[source] = {"distances": distances, "proposed": proposed, "selected": selected}

    base_arrays = prepare_structural_arrays(base_archive, "base nonlinear CEM")
    stress_arrays = prepare_structural_arrays(stress_archive, "deep-concavity stress")
    base_indices = saved["base_test_indices"]
    stress_indices = saved["stress_test_indices"]
    base_prediction = gather(saved["base_candidates"], test_sources["base"]["selected"])
    stress_prediction = gather(saved["stress_candidates"], test_sources["stress"]["selected"])
    base_summary = standard_metrics(
        base_arrays.labels[base_indices], base_prediction, base_arrays.indentation[base_indices]
    )
    stress_summary, _, _ = stress_metrics(
        stress_arrays.labels[stress_indices], stress_prediction,
        stress_arrays.cutout[stress_indices], stress_arrays.cutout_depth[stress_indices],
        stress_arrays.family_codes[stress_indices],
    )

    real_ids = np.asarray(base_archive["real_ids"])
    real_rows = []
    for index, case_id in enumerate(real_ids):
        real_rows.append({
            "id": str(case_id),
            "proposed": CANDIDATE_SPECS[int(test_sources["real"]["proposed"][index])][0],
            "selected": CANDIDATE_SPECS[int(test_sources["real"]["selected"][index])][0],
            "action_distance": float(test_sources["real"]["distances"][index]),
            "action_cutoff": float(cutoffs[int(test_sources["real"]["proposed"][index])]),
        })

    result = {
        "selection_uses_public_ktc_truth": False,
        "selection_rule": {
            "minimum_actual_training_gain": minimum_gain,
            "neighbours": neighbours,
            "positive_validation_distance_quantile": quantile,
            "action_cutoffs": cutoffs.tolist(),
        },
        "validation": best_row,
        "independent_base_test": base_summary,
        "independent_stress_test": stress_summary,
        "selection_counts": {
            source: {
                "proposed_noncoarse": int(np.sum(values["proposed"] != 0)),
                "accepted_noncoarse": int(np.sum(values["selected"] != 0)),
            }
            for source, values in test_sources.items()
        },
        "real_decisions_before_label_evaluation": real_rows,
    }
    (experiment_dir / "action_guard_search.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    (experiment_dir / "action_guard_grid.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
    np.savez_compressed(
        experiment_dir / "action_guard_selections.npz",
        base_selected=test_sources["base"]["selected"],
        stress_selected=test_sources["stress"]["selected"],
        real_selected=test_sources["real"]["selected"],
        real_distances=test_sources["real"]["distances"],
        action_cutoffs=cutoffs,
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
