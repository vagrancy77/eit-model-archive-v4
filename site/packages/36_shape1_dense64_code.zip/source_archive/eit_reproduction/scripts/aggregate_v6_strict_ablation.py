"""Aggregate matched-seed v6 component ablations without test-set tuning."""
from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


METRICS = (
    "foreground_iou",
    "foreground_dice",
    "boundary_f1",
    "notch_preservation",
    "bank_retention",
)
METHODS = (
    "anchor_v4",
    "no_physics",
    "no_topology_supervision",
    "no_connectivity",
    "full_ungated",
    "benefit_only_gate",
    "full_dual_risk_gate",
)
LABELS = {
    "anchor_v4": "v4 anchor",
    "no_physics": "without physics BP",
    "no_topology_supervision": "without topology supervision",
    "no_connectivity": "without connectivity operator",
    "full_ungated": "full, ungated",
    "benefit_only_gate": "benefit-only gate",
    "full_dual_risk_gate": "full dual-risk gate",
}
GROUP_ORDER = (
    ("base", "concave", "Base concave"),
    ("biological", "concave", "Biological concave"),
    ("biological", "ordinary", "Biological ordinary"),
    ("stress", "concave", "Stress concave"),
    ("public_ktc", "concave", "Public KTC nonconvex"),
    ("public_ktc", "ordinary", "Public KTC ordinary"),
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--full-runs", nargs="+", type=Path, required=True)
    parser.add_argument("--no-physics-runs", nargs="+", type=Path, required=True)
    parser.add_argument("--no-topology-runs", nargs="+", type=Path, required=True)
    parser.add_argument("--no-connectivity-runs", nargs="+", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--bootstrap", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20261031)
    return parser.parse_args()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def run_payload(path: Path) -> tuple[str, dict[str, object], list[dict[str, str]]]:
    summary_path = path.resolve() / "v6_summary.json"
    metrics_path = path.resolve() / "v6_case_metrics.csv"
    if not summary_path.is_file() or not metrics_path.is_file():
        raise FileNotFoundError(f"incomplete run: {path}")
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    seed = str(summary["seed"])
    return seed, summary, read_csv(metrics_path)


def metric_values(row: dict[str, str]) -> dict[str, float]:
    return {metric: float(row[metric]) for metric in METRICS}


def indexed(rows: list[dict[str, str]]) -> dict[tuple[str, str, str, str], dict[str, str]]:
    return {
        (row["group"], row["case_id"], row["subset"], row["method"]): row
        for row in rows
    }


def assemble(args: argparse.Namespace) -> list[dict[str, object]]:
    collections = {
        "full": args.full_runs,
        "no_physics": args.no_physics_runs,
        "no_topology_supervision": args.no_topology_runs,
        "no_connectivity": args.no_connectivity_runs,
    }
    loaded: dict[str, dict[str, tuple[dict[str, object], dict[tuple[str, str, str, str], dict[str, str]]]]] = {}
    for variant, paths in collections.items():
        loaded[variant] = {}
        for path in paths:
            seed, summary, rows = run_payload(path)
            if seed in loaded[variant]:
                raise ValueError(f"duplicate {variant} seed {seed}")
            loaded[variant][seed] = (summary, indexed(rows))
    seeds = sorted(loaded["full"])
    for variant in loaded:
        if sorted(loaded[variant]) != seeds:
            raise ValueError(f"seed mismatch for {variant}")

    assembled: list[dict[str, object]] = []
    for seed in seeds:
        full_summary, full = loaded["full"][seed]
        benefit_threshold = float(full_summary["gate_rule"]["minimum_predicted_benefit_q20"])
        case_keys = sorted(
            (group, case_id, subset)
            for group, case_id, subset, method in full
            if method == "anchor_v4"
        )
        for group, case_id, subset in case_keys:
            anchor_row = full[(group, case_id, subset, "anchor_v4")]
            candidate_row = full[(group, case_id, subset, "candidate_v6")]
            gated_row = full[(group, case_id, subset, "gated_v6")]
            benefit_selected = float(candidate_row["predicted_benefit_q20"]) >= benefit_threshold
            source_rows = {
                "anchor_v4": anchor_row,
                "full_ungated": candidate_row,
                "benefit_only_gate": candidate_row if benefit_selected else anchor_row,
                "full_dual_risk_gate": gated_row,
            }
            for variant in ("no_physics", "no_topology_supervision", "no_connectivity"):
                _, table = loaded[variant][seed]
                key = (group, case_id, subset, "gated_v6")
                if key not in table:
                    raise KeyError(f"missing {variant} case {seed}/{group}/{case_id}")
                source_rows[variant] = table[key]
            for method in METHODS:
                row = source_rows[method]
                assembled.append(
                    {
                        "seed": seed,
                        "group": group,
                        "case_id": case_id,
                        "subset": subset,
                        "method": method,
                        "selected": (
                            int(benefit_selected)
                            if method == "benefit_only_gate"
                            else int(float(row.get("gate_selected", 0)))
                        ),
                        **metric_values(row),
                    }
                )
    return assembled


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def paired_matrix(
    lookup: dict[tuple[str, str, str, str, str], dict[str, object]],
    seeds: list[str],
    group: str,
    subset: str,
    ids: list[str],
    method: str,
    metric: str,
) -> np.ndarray:
    return np.asarray(
        [
            [float(lookup[(seed, group, case_id, subset, method)][metric]) for case_id in ids]
            for seed in seeds
        ],
        dtype=np.float64,
    )


def hierarchical_bootstrap(
    difference: np.ndarray, repetitions: int, rng: np.random.Generator
) -> dict[str, object]:
    finite = np.isfinite(difference).all(axis=0)
    difference = difference[:, finite]
    if difference.size == 0:
        return {
            "mean_difference": float("nan"),
            "ci95_low": float("nan"),
            "ci95_high": float("nan"),
            "probability_positive": float("nan"),
            "seeds": 0,
            "cases_per_seed": 0,
        }
    seed_count, case_count = difference.shape
    draws = np.empty(repetitions, dtype=np.float64)
    for start in range(0, repetitions, 1000):
        stop = min(repetitions, start + 1000)
        count = stop - start
        sampled_seeds = rng.integers(seed_count, size=(count, seed_count))
        sampled_cases = rng.integers(case_count, size=(count, case_count))
        draws[start:stop] = difference[
            sampled_seeds[:, :, None], sampled_cases[:, None, :]
        ].mean(axis=(1, 2))
    return {
        "mean_difference": float(difference.mean()),
        "ci95_low": float(np.percentile(draws, 2.5)),
        "ci95_high": float(np.percentile(draws, 97.5)),
        "probability_positive": float(np.mean(draws > 0.0)),
        "seeds": seed_count,
        "cases_per_seed": case_count,
        "per_seed_mean_difference": [float(value) for value in difference.mean(axis=1)],
    }


def summarize(
    rows: list[dict[str, object]], repetitions: int, seed: int
) -> dict[str, object]:
    seeds = sorted({str(row["seed"]) for row in rows})
    lookup = {
        (
            str(row["seed"]), str(row["group"]), str(row["case_id"]),
            str(row["subset"]), str(row["method"]),
        ): row
        for row in rows
    }
    reference_seed = seeds[0]
    rng = np.random.default_rng(seed)
    groups: dict[str, object] = {}
    effects: list[dict[str, object]] = []
    for group, subset, label in GROUP_ORDER:
        ids = sorted(
            str(row["case_id"])
            for row in rows
            if str(row["seed"]) == reference_seed
            and row["group"] == group
            and row["subset"] == subset
            and row["method"] == "anchor_v4"
        )
        if not ids:
            continue
        matrices = {
            (method, metric): paired_matrix(
                lookup, seeds, group, subset, ids, method, metric
            )
            for method in METHODS
            for metric in METRICS
        }
        method_means: dict[str, object] = {}
        for method in METHODS:
            method_means[method] = {
                metric: float(np.nanmean(matrices[(method, metric)]))
                for metric in METRICS
                if np.isfinite(matrices[(method, metric)]).any()
            }
            selected_values = [
                float(lookup[(s, group, case_id, subset, method)]["selected"])
                for s in seeds for case_id in ids
            ]
            method_means[method]["selected_fraction"] = float(np.mean(selected_values))
        groups[label] = {"cases_per_seed": len(ids), "method_means": method_means}

        for method in METHODS[1:]:
            for metric in METRICS:
                value = hierarchical_bootstrap(
                    matrices[(method, metric)] - matrices[("anchor_v4", metric)],
                    repetitions,
                    rng,
                )
                effects.append(
                    {
                        "label": label,
                        "group": group,
                        "subset": subset,
                        "comparison": f"{method}_minus_anchor_v4",
                        "metric": metric,
                        **value,
                    }
                )
        for ablated in (
            "no_physics", "no_topology_supervision", "no_connectivity",
            "benefit_only_gate", "full_ungated",
        ):
            for metric in METRICS:
                value = hierarchical_bootstrap(
                    matrices[("full_dual_risk_gate", metric)] - matrices[(ablated, metric)],
                    repetitions,
                    rng,
                )
                effects.append(
                    {
                        "label": label,
                        "group": group,
                        "subset": subset,
                        "comparison": f"full_dual_risk_gate_minus_{ablated}",
                        "metric": metric,
                        **value,
                    }
                )
    return {
        "seeds": seeds,
        "bootstrap_repetitions": repetitions,
        "groups": groups,
        "effects": effects,
    }


def effect_lookup(summary: dict[str, object]) -> dict[tuple[str, str, str], dict[str, object]]:
    return {
        (str(row["label"]), str(row["comparison"]), str(row["metric"])): row
        for row in summary["effects"]
    }


def plot_method_effects(path: Path, summary: dict[str, object]) -> None:
    effects = effect_lookup(summary)
    group_labels = [label for _, _, label in GROUP_ORDER if label in summary["groups"]]
    methods = ("no_physics", "no_topology_supervision", "no_connectivity", "full_dual_risk_gate")
    colors = ("#777777", "#cc6677", "#aa4499", "#117733")
    figure, axes = plt.subplots(1, 3, figsize=(16.5, 5.7))
    for axis, metric, title in zip(
        axes,
        ("foreground_iou", "notch_preservation", "bank_retention"),
        ("IoU difference from v4", "Notch difference from v4", "Bank difference from v4"),
    ):
        width = 0.18
        x = np.arange(len(group_labels))
        for offset, (method, color) in enumerate(zip(methods, colors)):
            values = []
            low = []
            high = []
            for label in group_labels:
                row = effects.get((label, f"{method}_minus_anchor_v4", metric))
                values.append(float(row["mean_difference"]) if row else np.nan)
                low.append(float(row["ci95_low"]) if row else np.nan)
                high.append(float(row["ci95_high"]) if row else np.nan)
            values_array = np.asarray(values)
            error = np.maximum(
                0.0,
                np.vstack((values_array - np.asarray(low), np.asarray(high) - values_array)),
            )
            axis.errorbar(
                x + (offset - 1.5) * width, values_array, yerr=error,
                fmt="o", capsize=3, color=color, label=LABELS[method],
            )
        axis.axhline(0.0, color="black", linestyle="--", linewidth=1)
        axis.set_xticks(x, group_labels, rotation=30, ha="right")
        axis.set_title(title)
        axis.grid(alpha=0.22)
    axes[0].legend(frameon=False, fontsize=8)
    figure.suptitle("Strict matched-seed v6 component ablation (95% hierarchical bootstrap CI)")
    figure.tight_layout()
    figure.savefig(path, dpi=240)
    plt.close(figure)


def plot_component_attribution(path: Path, summary: dict[str, object]) -> None:
    effects = effect_lookup(summary)
    groups = ("Biological concave", "Stress concave", "Public KTC nonconvex")
    ablations = ("no_physics", "no_topology_supervision", "no_connectivity")
    figure, axes = plt.subplots(2, 1, figsize=(10.5, 8.0), sharex=False)
    for axis, metric in zip(axes, ("notch_preservation", "foreground_iou")):
        labels: list[str] = []
        means: list[float] = []
        lows: list[float] = []
        highs: list[float] = []
        for group in groups:
            for ablation in ablations:
                row = effects[(group, f"full_dual_risk_gate_minus_{ablation}", metric)]
                labels.append(f"{group}: {LABELS[ablation]}")
                means.append(float(row["mean_difference"]))
                lows.append(float(row["ci95_low"]))
                highs.append(float(row["ci95_high"]))
        y = np.arange(len(labels))
        means_array = np.asarray(means)
        axis.errorbar(
            means_array,
            y,
            xerr=np.maximum(
                0.0,
                np.vstack((means_array - np.asarray(lows), np.asarray(highs) - means_array)),
            ),
            fmt="o",
            capsize=3,
            color="#236b8e" if metric == "notch_preservation" else "#8c4b2d",
        )
        axis.axvline(0.0, color="black", linestyle="--", linewidth=1)
        axis.set_yticks(y, labels, fontsize=8)
        axis.set_title(f"Full dual-risk v6 advantage: {metric.replace('_', ' ')}")
        axis.grid(axis="x", alpha=0.25)
    figure.tight_layout()
    figure.savefig(path, dpi=240)
    plt.close(figure)


def write_report(path: Path, summary: dict[str, object]) -> None:
    effects = effect_lookup(summary)
    lines = [
        "# Strict v6 Ablation Report",
        "",
        "All variants used matched v4 seeds and identical train/validation/test splits. "
        "Every checkpoint and gate was selected without synthetic-test or public truth.",
        "",
        f"Hierarchical bootstrap repetitions: {summary['bootstrap_repetitions']}.",
        "",
        "## Full gated v6 versus v4",
        "",
        "| Group | IoU difference (95% CI) | Notch difference (95% CI) |",
        "|---|---:|---:|",
    ]
    for label in summary["groups"]:
        iou = effects[(label, "full_dual_risk_gate_minus_anchor_v4", "foreground_iou")]
        notch = effects.get((label, "full_dual_risk_gate_minus_anchor_v4", "notch_preservation"))
        notch_text = "n/a" if notch is None or not np.isfinite(notch["mean_difference"]) else (
            f"{notch['mean_difference']:+.5f} "
            f"[{notch['ci95_low']:+.5f}, {notch['ci95_high']:+.5f}]"
        )
        lines.append(
            f"| {label} | {iou['mean_difference']:+.5f} "
            f"[{iou['ci95_low']:+.5f}, {iou['ci95_high']:+.5f}] | {notch_text} |"
        )
    lines.extend(
        [
            "",
            "## Component attribution",
            "",
            "Positive values mean the complete dual-risk v6 outperformed the ablated variant.",
            "",
            "| Group | Removed component | IoU contribution | Notch contribution |",
            "|---|---|---:|---:|",
        ]
    )
    for label in ("Biological concave", "Stress concave", "Public KTC nonconvex"):
        for ablated in ("no_physics", "no_topology_supervision", "no_connectivity"):
            iou = effects[(label, f"full_dual_risk_gate_minus_{ablated}", "foreground_iou")]
            notch = effects[(label, f"full_dual_risk_gate_minus_{ablated}", "notch_preservation")]
            lines.append(
                f"| {label} | {LABELS[ablated]} | {iou['mean_difference']:+.5f} | "
                f"{notch['mean_difference']:+.5f} |"
            )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = assemble(args)
    write_rows(output_dir / "v6_ablation_case_metrics.csv", rows)
    summary = summarize(rows, args.bootstrap, args.seed)
    summary["protocol"] = {
        "matched_model_seeds": True,
        "identical_frozen_v4_cache_per_seed": True,
        "ablation_checkpoint_selection": "synthetic validation only",
        "ablation_gate_calibration": "synthetic validation only",
        "test_or_public_truth_used_for_selection": False,
        "benefit_only_gate": "same validation-selected benefit q20 threshold; IoU and bank risk limits ignored",
    }
    (output_dir / "v6_ablation_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    plot_method_effects(output_dir / "v6_ablation_effects.png", summary)
    plot_component_attribution(output_dir / "v6_component_attribution.png", summary)
    write_report(output_dir / "V6_ABLATION_REPORT.md", summary)
    print(json.dumps({"output_dir": str(output_dir), "rows": len(rows)}, indent=2))


if __name__ == "__main__":
    main()
