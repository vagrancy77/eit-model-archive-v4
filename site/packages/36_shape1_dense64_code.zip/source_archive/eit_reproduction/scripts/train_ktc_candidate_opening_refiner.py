"""Learn whether and how widely to open an enclosed EIT background cavity.

The coarse networks often recover the deep background of a C/U-shaped target
but leave a one-to-few-pixel foreground bridge across its mouth.  A fixed
geodesic cut opens these shapes, but it can also connect a hallucinated hole to
the exterior.  This script trains an action scorer on both failure modes:

* positive augmentation: a true inward cutout is deliberately sealed;
* negative augmentation: a false hole is inserted into a solid lesion.

For every candidate path the scorer evaluates four corridor widths.  It may
reject every action, so unchanged convex/solid targets remain unchanged.
Synthetic test labels, the 21 KTC labels, and the four ABC2 calibration truths
are not used for training, checkpoint selection, or threshold selection.
"""
from __future__ import annotations

import argparse
import csv
import heapq
import json
import math
import random
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy.ndimage import (
    binary_dilation,
    binary_erosion,
    distance_transform_edt,
    label as connected_components,
    zoom,
)
from torch.utils.data import DataLoader, Dataset

from fuse_ktc_joint_shape_models import blend, infer_probability, load_model
from prepare_ktc_deep_concavity_stress import FAMILIES
from train_ktc_concavity_network import InputAdapter
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_highres_refiner import load_dip_four_case_predictions, load_official_four_case_truths
from train_ktc_implicit_boolean_network import standard_metrics, stress_metrics


NEIGHBORS = ((-1, 0), (1, 0), (0, -1), (0, 1))
ACTION_RADII = (0, 1, 2, 3)
FEATURE_COUNT = 14
CHANNEL_COUNT = 12


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    parser.add_argument("--conservative", type=Path, default=Path("E:/Codex/ktc_joint_shape_pretrained_seed20260820/best.pt"))
    parser.add_argument("--aggressive", type=Path, default=Path("E:/Codex/ktc_joint_shape_network_seed20260820/best.pt"))
    parser.add_argument("--output-dir", type=Path, default=Path("E:/Codex/ktc_candidate_opening_seed20260820"))
    parser.add_argument("--epochs", type=int, default=36)
    parser.add_argument("--batch-size", type=int, default=192)
    parser.add_argument("--inference-batch-size", type=int, default=48)
    parser.add_argument("--learning-rate", type=float, default=2e-3)
    parser.add_argument("--weight-decay", type=float, default=2e-4)
    parser.add_argument("--patience", type=int, default=10)
    parser.add_argument("--seed", type=int, default=20260820)
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def exterior_background(foreground: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    components, count = connected_components(~foreground, structure=np.ones((3, 3), dtype=np.uint8))
    border = np.unique(np.concatenate((components[0], components[-1], components[:, 0], components[:, -1])))
    border = border[border != 0]
    exterior = np.isin(components, border)
    cavities = np.asarray([component for component in range(1, count + 1) if component not in border], dtype=np.int32)
    return exterior, components, cavities


def shortest_path(
    foreground: np.ndarray,
    cavity: np.ndarray,
    exterior: np.ndarray,
    cost: np.ndarray,
) -> list[tuple[int, int]]:
    height, width = foreground.shape
    distance = np.full((height, width), np.inf, dtype=np.float64)
    parent_y = np.full((height, width), -1, dtype=np.int16)
    parent_x = np.full((height, width), -1, dtype=np.int16)
    queue: list[tuple[float, int, int]] = []
    for y, x in np.argwhere(cavity):
        distance[y, x] = 0.0
        heapq.heappush(queue, (0.0, int(y), int(x)))
    target: tuple[int, int] | None = None
    while queue:
        value, y, x = heapq.heappop(queue)
        if value != distance[y, x]:
            continue
        if exterior[y, x]:
            target = (y, x)
            break
        for dy, dx in NEIGHBORS:
            ny, nx = y + dy, x + dx
            if not (0 <= ny < height and 0 <= nx < width):
                continue
            step = float(cost[ny, nx]) if foreground[ny, nx] else 0.01
            proposal = value + step
            if proposal < distance[ny, nx]:
                distance[ny, nx] = proposal
                parent_y[ny, nx] = y
                parent_x[ny, nx] = x
                heapq.heappush(queue, (proposal, ny, nx))
    if target is None:
        return []
    path: list[tuple[int, int]] = []
    y, x = target
    while parent_y[y, x] >= 0:
        if foreground[y, x]:
            path.append((y, x))
        y, x = int(parent_y[y, x]), int(parent_x[y, x])
        if cavity[y, x]:
            break
    return path


@dataclass
class Candidate:
    cavity: np.ndarray
    path: np.ndarray
    exterior: np.ndarray


def find_candidates(
    labels: np.ndarray,
    conservative: np.ndarray,
    aggressive: np.ndarray,
    max_length: int,
    min_background: float,
    min_hole: int,
) -> list[Candidate]:
    foreground = labels != 0
    exterior, components, cavity_ids = exterior_background(foreground)
    cost = 0.10 + 0.45 * conservative[1:].sum(axis=0) + 0.45 * aggressive[1:].sum(axis=0)
    records: list[Candidate] = []
    for component in cavity_ids:
        cavity = components == int(component)
        if int(cavity.sum()) < min_hole:
            continue
        coordinates = shortest_path(foreground, cavity, exterior, cost)
        if not coordinates or len(coordinates) > max_length:
            continue
        path = np.zeros_like(foreground)
        for y, x in coordinates:
            path[y, x] = True
        if float(aggressive[0, path].mean()) < min_background:
            continue
        records.append(Candidate(cavity=cavity, path=path, exterior=exterior))
    return records


def action_removal(
    foreground: np.ndarray,
    path: np.ndarray,
    aggressive_background: np.ndarray,
    radius: int,
    scale: int = 1,
) -> np.ndarray:
    scaled_radius = radius * scale
    if scaled_radius == 0:
        return path & foreground
    corridor = binary_dilation(
        path,
        structure=np.ones((3, 3), dtype=bool),
        iterations=scaled_radius,
    )
    return (path | (corridor & (aggressive_background >= 0.10))) & foreground


def normalized_image(image: np.ndarray) -> np.ndarray:
    finite = image[np.isfinite(image)]
    if finite.size == 0:
        return np.zeros_like(image, dtype=np.float32)
    center = float(np.median(finite))
    scale = float(np.quantile(np.abs(finite - center), 0.985))
    return np.clip((image - center) / max(scale, 1e-6), -4.0, 4.0).astype(np.float32) / 4.0


def crop_resize(channels: np.ndarray, center: tuple[float, float], scale: int, size: int = 40) -> np.ndarray:
    half = 20 * scale
    cy, cx = int(round(center[0])), int(round(center[1]))
    y0, y1 = cy - half, cy + half
    x0, x1 = cx - half, cx + half
    pad_y0, pad_y1 = max(0, -y0), max(0, y1 - channels.shape[1])
    pad_x0, pad_x1 = max(0, -x0), max(0, x1 - channels.shape[2])
    if pad_y0 or pad_y1 or pad_x0 or pad_x1:
        channels = np.pad(channels, ((0, 0), (pad_y0, pad_y1), (pad_x0, pad_x1)), mode="constant")
        y0 += pad_y0
        y1 += pad_y0
        x0 += pad_x0
        x1 += pad_x0
    crop = channels[:, y0:y1, x0:x1]
    if crop.shape[1:] != (size, size):
        crop = zoom(crop, (1.0, size / crop.shape[1], size / crop.shape[2]), order=1)
    return crop.astype(np.float32)


def candidate_input(
    image: np.ndarray,
    labels: np.ndarray,
    conservative: np.ndarray,
    aggressive: np.ndarray,
    candidate: Candidate,
    removal: np.ndarray,
    radius: int,
    scale: int = 1,
) -> tuple[np.ndarray, np.ndarray]:
    foreground = labels != 0
    edge = binary_dilation(foreground) ^ binary_erosion(foreground)
    path_coordinates = np.argwhere(candidate.path)
    center = tuple(path_coordinates.mean(axis=0)) if len(path_coordinates) else tuple(np.argwhere(candidate.cavity).mean(axis=0))
    conservative_fg = conservative[1:].sum(axis=0)
    aggressive_fg = aggressive[1:].sum(axis=0)
    channels = np.stack((
        normalized_image(image),
        foreground.astype(np.float32),
        conservative[0],
        aggressive[0],
        conservative_fg,
        aggressive_fg,
        np.abs(conservative_fg - aggressive_fg),
        candidate.cavity.astype(np.float32),
        candidate.path.astype(np.float32),
        removal.astype(np.float32),
        candidate.exterior.astype(np.float32),
        edge.astype(np.float32),
    ))
    height, width = labels.shape
    path = candidate.path
    cavity_coordinates = np.argwhere(candidate.cavity)
    cavity_center = cavity_coordinates.mean(axis=0)
    path_cons = conservative[0, path]
    path_aggr = aggressive[0, path]
    removal_aggr = aggressive[0, removal]
    features = np.asarray((
        candidate.cavity.sum() / (height * width),
        candidate.cavity.sum() / max(1, foreground.sum()),
        path.sum() / max(height, width),
        removal.sum() / (height * width),
        float(path_cons.mean()),
        float(path_cons.min()),
        float(path_aggr.mean()),
        float(path_aggr.min()),
        float(removal_aggr.mean()),
        float(np.abs(path_cons - path_aggr).mean()),
        min(cavity_center[0], cavity_center[1], height - 1 - cavity_center[0], width - 1 - cavity_center[1]) / max(height, width),
        foreground.sum() / (height * width),
        radius / max(ACTION_RADII),
        float(aggressive[0, candidate.cavity].mean()),
    ), dtype=np.float32)
    return crop_resize(channels, center, scale), features


def soften_labels(labels: np.ndarray, background_confidence: float) -> np.ndarray:
    classes = np.eye(3, dtype=np.float32)[labels].transpose(2, 0, 1)
    confidence = np.full(labels.shape, 0.82, dtype=np.float32)
    confidence[labels == 0] = background_confidence
    probability = classes * confidence[None] + (1.0 - classes) * ((1.0 - confidence)[None] / 2.0)
    return probability / probability.sum(axis=0, keepdims=True)


def pseudo_probabilities(actual: np.ndarray, labels: np.ndarray, strength: float, background_confidence: float) -> np.ndarray:
    pseudo = soften_labels(labels, background_confidence)
    result = (1.0 - strength) * actual + strength * pseudo
    return result / result.sum(axis=0, keepdims=True)


def target_for_action(truth: np.ndarray, cavity: np.ndarray, removal: np.ndarray) -> tuple[float, float]:
    correct_background = int(np.count_nonzero(truth[removal] == 0))
    destroyed_foreground = int(np.count_nonzero(truth[removal] != 0))
    area = max(1, int(removal.sum()))
    precision = correct_background / area
    cavity_quality = float(np.mean(truth[cavity] == 0))
    utility = (correct_background - 1.5 * destroyed_foreground) / area
    beneficial = float(precision >= 0.65 and cavity_quality >= 0.55 and utility > 0.0)
    return beneficial, float(np.clip(utility, -1.0, 1.0))


@dataclass
class Examples:
    patches: list[np.ndarray]
    features: list[np.ndarray]
    beneficial: list[float]
    utility: list[float]
    kind: list[str]

    @classmethod
    def empty(cls) -> "Examples":
        return cls([], [], [], [], [])

    def add_candidate(
        self,
        image: np.ndarray,
        labels: np.ndarray,
        conservative: np.ndarray,
        aggressive: np.ndarray,
        candidate: Candidate,
        truth: np.ndarray,
        kind: str,
    ) -> None:
        foreground = labels != 0
        for radius in ACTION_RADII:
            removal = action_removal(foreground, candidate.path, aggressive[0], radius)
            patch, feature = candidate_input(image, labels, conservative, aggressive, candidate, removal, radius)
            target, utility = target_for_action(truth, candidate.cavity, removal)
            self.patches.append(patch)
            self.features.append(feature)
            self.beneficial.append(target)
            self.utility.append(utility)
            self.kind.append(kind)

    def arrays(self) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        return (
            np.stack(self.patches).astype(np.float32),
            np.stack(self.features).astype(np.float32),
            np.asarray(self.beneficial, dtype=np.float32),
            np.asarray(self.utility, dtype=np.float32),
        )


def synthetic_positive(
    truth: np.ndarray,
    support: np.ndarray,
    cutout: np.ndarray,
    conservative: np.ndarray,
    aggressive: np.ndarray,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray, np.ndarray] | None:
    cutout = cutout.astype(bool)
    if int(cutout.sum()) < 8:
        return None
    distance = distance_transform_edt(cutout)
    threshold = float(rng.uniform(0.8, min(2.6, max(0.9, float(distance.max()) * 0.65))))
    core = distance >= threshold
    if int(core.sum()) < 3:
        core = distance >= max(0.5, float(distance.max()) * 0.55)
    if int(core.sum()) < 3:
        return None
    foreground_truth = truth != 0
    values, counts = np.unique(truth[foreground_truth], return_counts=True)
    if len(values) == 0:
        return None
    class_id = int(values[int(np.argmax(counts))])
    corrupted = truth.copy()
    corrupted[support.astype(bool)] = class_id
    corrupted[core] = 0
    conservative_pseudo = pseudo_probabilities(conservative, corrupted, float(rng.uniform(0.56, 0.76)), 0.88)
    aggressive_pseudo = pseudo_probabilities(aggressive, corrupted, float(rng.uniform(0.30, 0.52)), 0.86)
    return corrupted, conservative_pseudo, aggressive_pseudo


def synthetic_negative(
    truth: np.ndarray,
    conservative: np.ndarray,
    aggressive: np.ndarray,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray, np.ndarray] | None:
    foreground = truth != 0
    components, count = connected_components(foreground, structure=np.ones((3, 3), dtype=np.uint8))
    viable: list[tuple[int, np.ndarray, float]] = []
    for component in range(1, count + 1):
        mask = components == component
        distance = distance_transform_edt(mask)
        if float(distance.max()) >= 3.0:
            viable.append((component, distance, float(distance.max())))
    if not viable:
        return None
    _, distance, maximum = viable[int(rng.integers(len(viable)))]
    centers = np.argwhere(distance >= max(2.5, 0.70 * maximum))
    cy, cx = centers[int(rng.integers(len(centers)))]
    radius = float(rng.uniform(1.5, min(3.8, max(1.8, maximum * 0.62))))
    yy, xx = np.indices(truth.shape)
    hole = ((yy - cy) ** 2 + (xx - cx) ** 2 <= radius * radius) & foreground
    if int(hole.sum()) < 3:
        return None
    corrupted = truth.copy()
    corrupted[hole] = 0
    conservative_pseudo = pseudo_probabilities(conservative, corrupted, float(rng.uniform(0.60, 0.82)), 0.90)
    aggressive_pseudo = pseudo_probabilities(aggressive, corrupted, float(rng.uniform(0.62, 0.86)), 0.92)
    return corrupted, conservative_pseudo, aggressive_pseudo


def add_first_matching_candidate(
    examples: Examples,
    image: np.ndarray,
    corrupted: np.ndarray,
    conservative: np.ndarray,
    aggressive: np.ndarray,
    truth: np.ndarray,
    kind: str,
    max_length: int,
) -> bool:
    candidates = find_candidates(corrupted, conservative, aggressive, max_length, 0.0, 3)
    if not candidates:
        return False
    candidates.sort(key=lambda item: int(item.cavity.sum()), reverse=True)
    examples.add_candidate(image, corrupted, conservative, aggressive, candidates[0], truth, kind)
    return True


def build_examples(
    base: np.lib.npyio.NpzFile,
    stress: np.lib.npyio.NpzFile,
    base_indices: np.ndarray,
    stress_indices: np.ndarray,
    base_conservative: np.ndarray,
    base_aggressive: np.ndarray,
    stress_conservative: np.ndarray,
    stress_aggressive: np.ndarray,
    seed: int,
) -> Examples:
    rng = np.random.default_rng(seed)
    examples = Examples.empty()
    for local, index in enumerate(stress_indices):
        positive = synthetic_positive(
            stress["labels"][index], stress["support_masks"][index], stress["cutout_masks"][index],
            stress_conservative[local], stress_aggressive[local], rng,
        )
        if positive is not None:
            add_first_matching_candidate(examples, stress["linear_images"][index], *positive, stress["labels"][index], "sealed_true_cutout", 12)
        negative = synthetic_negative(stress["labels"][index], stress_conservative[local], stress_aggressive[local], rng)
        if negative is not None:
            add_first_matching_candidate(examples, stress["linear_images"][index], *negative, stress["labels"][index], "false_hole_stress", 14)
        raw = blend(stress_conservative[local:local + 1], stress_aggressive[local:local + 1], 0.5)[0]
        for candidate in find_candidates(raw, stress_conservative[local], stress_aggressive[local], 6, 0.10, 3):
            examples.add_candidate(stress["linear_images"][index], raw, stress_conservative[local], stress_aggressive[local], candidate, stress["labels"][index], "natural_stress")
        if (local + 1) % 100 == 0 or local + 1 == len(stress_indices):
            print(f"  stress candidate augmentation {local + 1}/{len(stress_indices)}", flush=True)

    base_order = rng.permutation(len(base_indices))
    positive_budget = min(len(base_indices), max(300, 2 * len(stress_indices)))
    negative_budget = min(len(base_indices), max(400, 2 * len(stress_indices)))
    for position, local in enumerate(base_order):
        index = int(base_indices[local])
        if position < positive_budget:
            foreground = base["labels"][index] != 0
            support = foreground | (base["indentation_masks"][index] != 0)
            cutout = support & ~foreground
            positive = synthetic_positive(base["labels"][index], support, cutout, base_conservative[local], base_aggressive[local], rng)
            if positive is not None:
                add_first_matching_candidate(examples, base["linear_images"][index], *positive, base["labels"][index], "sealed_base_indent", 12)
        if position < negative_budget:
            negative = synthetic_negative(base["labels"][index], base_conservative[local], base_aggressive[local], rng)
            if negative is not None:
                add_first_matching_candidate(examples, base["linear_images"][index], *negative, base["labels"][index], "false_hole_base", 14)
        raw = blend(base_conservative[local:local + 1], base_aggressive[local:local + 1], 0.5)[0]
        for candidate in find_candidates(raw, base_conservative[local], base_aggressive[local], 6, 0.10, 3):
            examples.add_candidate(base["linear_images"][index], raw, base_conservative[local], base_aggressive[local], candidate, base["labels"][index], "natural_base")
        if (position + 1) % 100 == 0 or position + 1 == len(base_order):
            print(f"  base candidate augmentation {position + 1}/{len(base_order)}", flush=True)
    return examples


class ActionDataset(Dataset):
    def __init__(self, patches: np.ndarray, features: np.ndarray, target: np.ndarray, utility: np.ndarray) -> None:
        self.patches = torch.from_numpy(patches)
        self.features = torch.from_numpy(features)
        self.target = torch.from_numpy(target)
        self.utility = torch.from_numpy(utility)

    def __len__(self) -> int:
        return len(self.target)

    def __getitem__(self, index: int):
        return self.patches[index], self.features[index], self.target[index], self.utility[index]


class ResidualUnit(nn.Module):
    def __init__(self, channels: int) -> None:
        super().__init__()
        self.layers = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1, bias=False),
            nn.GroupNorm(4, channels),
            nn.SiLU(),
            nn.Conv2d(channels, channels, 3, padding=1, bias=False),
            nn.GroupNorm(4, channels),
        )

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        return F.silu(inputs + self.layers(inputs))


class CandidateActionNet(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.image = nn.Sequential(
            nn.Conv2d(CHANNEL_COUNT, 24, 5, padding=2, bias=False),
            nn.GroupNorm(4, 24),
            nn.SiLU(),
            ResidualUnit(24),
            nn.Conv2d(24, 48, 3, stride=2, padding=1, bias=False),
            nn.GroupNorm(6, 48),
            nn.SiLU(),
            ResidualUnit(48),
            nn.Conv2d(48, 96, 3, stride=2, padding=1, bias=False),
            nn.GroupNorm(8, 96),
            nn.SiLU(),
            ResidualUnit(96),
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
        )
        self.head = nn.Sequential(
            nn.Linear(96 + FEATURE_COUNT, 96),
            nn.SiLU(),
            nn.Dropout(0.15),
            nn.Linear(96, 48),
            nn.SiLU(),
        )
        self.benefit = nn.Linear(48, 1)
        self.utility = nn.Linear(48, 1)

    def forward(self, patch: torch.Tensor, features: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        hidden = self.head(torch.cat((self.image(patch), features), dim=1))
        return self.benefit(hidden).squeeze(1), torch.tanh(self.utility(hidden).squeeze(1))


@torch.no_grad()
def score_actions(
    model: CandidateActionNet,
    records: list[dict[str, object]],
    feature_mean: np.ndarray,
    feature_scale: np.ndarray,
    device: torch.device,
    batch_size: int = 256,
) -> None:
    if not records:
        return
    patches = np.stack([record["patch"] for record in records]).astype(np.float32)
    features = np.stack([record["features"] for record in records]).astype(np.float32)
    features = (features - feature_mean) / feature_scale
    model.eval()
    probabilities, utilities = [], []
    for start in range(0, len(records), batch_size):
        patch = torch.from_numpy(patches[start:start + batch_size]).to(device)
        feature = torch.from_numpy(features[start:start + batch_size]).to(device)
        logit, utility = model(patch, feature)
        probabilities.extend(torch.sigmoid(logit).cpu().numpy().tolist())
        utilities.extend(utility.cpu().numpy().tolist())
    for record, probability, utility in zip(records, probabilities, utilities):
        record["probability"] = float(probability)
        record["predicted_utility"] = float(utility)


def inference_records(
    images: np.ndarray,
    raw: np.ndarray,
    conservative: np.ndarray,
    aggressive: np.ndarray,
    scale: int = 1,
) -> list[dict[str, object]]:
    records: list[dict[str, object]] = []
    max_length, min_hole = 6 * scale, 3 * scale * scale
    for sample in range(len(raw)):
        candidates = find_candidates(raw[sample], conservative[sample], aggressive[sample], max_length, 0.10, min_hole)
        for candidate_id, candidate in enumerate(candidates):
            foreground = raw[sample] != 0
            for radius in ACTION_RADII:
                removal = action_removal(foreground, candidate.path, aggressive[sample, 0], radius, scale)
                patch, features = candidate_input(images[sample], raw[sample], conservative[sample], aggressive[sample], candidate, removal, radius, scale)
                records.append({
                    "sample": sample,
                    "candidate": candidate_id,
                    "radius": radius,
                    "removal": removal,
                    "patch": patch,
                    "features": features,
                })
    return records


def apply_scored_actions(
    raw: np.ndarray,
    records: list[dict[str, object]],
    threshold: float,
    width_bonus: float = 0.0,
    fallback_path: bool = False,
) -> tuple[np.ndarray, int, list[dict[str, object]]]:
    output = raw.copy()
    grouped: dict[tuple[int, int], list[dict[str, object]]] = {}
    for record in records:
        grouped.setdefault((int(record["sample"]), int(record["candidate"])), []).append(record)
    accepted: list[dict[str, object]] = []
    for (sample, _), options in grouped.items():
        viable = [option for option in options if float(option["probability"]) >= threshold and float(option["predicted_utility"]) > 0.0]
        if not viable:
            if not fallback_path:
                continue
            selected = min(options, key=lambda option: int(option["radius"]))
            selected["fallback"] = True
        else:
            selected = max(
                viable,
                key=lambda option: (
                    float(option["probability"])
                    + 0.20 * float(option["predicted_utility"])
                    + width_bonus * float(option["radius"]) / max(ACTION_RADII)
                ),
            )
            selected["fallback"] = False
        output[sample][selected["removal"]] = 0
        accepted.append({key: value for key, value in selected.items() if key not in {"patch", "features", "removal"}})
    return output, len(accepted), accepted


def validation_choice(
    model: CandidateActionNet,
    base_records: list[dict[str, object]],
    stress_records: list[dict[str, object]],
    base_raw: np.ndarray,
    stress_raw: np.ndarray,
    base_truth: np.ndarray,
    base_indent: np.ndarray,
    stress_truth: np.ndarray,
    stress_cutout: np.ndarray,
    stress_depth: np.ndarray,
    stress_family: np.ndarray,
    feature_mean: np.ndarray,
    feature_scale: np.ndarray,
    device: torch.device,
) -> tuple[dict[str, object], list[dict[str, object]]]:
    score_actions(model, base_records, feature_mean, feature_scale, device)
    score_actions(model, stress_records, feature_mean, feature_scale, device)
    base_reference = standard_metrics(base_truth, base_raw, base_indent)
    stress_reference, _, _ = stress_metrics(stress_truth, stress_raw, stress_cutout, stress_depth, stress_family)
    candidates: list[dict[str, object]] = []
    for width_bonus in (0.0, 0.03, 0.06, 0.10, 0.15):
        for threshold in np.linspace(0.25, 0.85, 13):
            base_prediction, base_count, _ = apply_scored_actions(base_raw, base_records, float(threshold), width_bonus)
            stress_prediction, stress_count, _ = apply_scored_actions(stress_raw, stress_records, float(threshold), width_bonus)
            base_metric = standard_metrics(base_truth, base_prediction, base_indent)
            stress_metric, _, _ = stress_metrics(stress_truth, stress_prediction, stress_cutout, stress_depth, stress_family)
            eligible = (
                base_metric["foreground_iou"] >= base_reference["foreground_iou"] - 0.006
                and stress_metric["foreground_iou"] >= stress_reference["foreground_iou"] - 0.008
                and stress_metric["bank_retention"] >= stress_reference["bank_retention"] - 0.010
            )
            score = (
                0.18 * base_metric["foreground_iou"]
                + 0.20 * stress_metric["foreground_iou"]
                + 0.28 * stress_metric["open_deep_cutout_recovery"]
                + 0.18 * stress_metric["bank_retention"]
                + 0.16 * stress_metric["topology_structural_joint"]
            )
            candidates.append({
                "threshold": float(threshold), "width_bonus": width_bonus,
                "eligible": bool(eligible), "score": float(score),
                "base_actions": base_count, "stress_actions": stress_count,
                "base": base_metric, "stress": stress_metric,
            })
    eligible = [row for row in candidates if row["eligible"]]
    return max(eligible or candidates, key=lambda row: float(row["score"])), candidates


def train_model(
    train: Examples,
    validation: Examples,
    validation_context: dict[str, object],
    args: argparse.Namespace,
    device: torch.device,
) -> tuple[CandidateActionNet, dict[str, object], dict[str, np.ndarray], list[dict[str, object]]]:
    train_patches, train_features, train_target, train_utility = train.arrays()
    validation_patches, validation_features, validation_target, validation_utility = validation.arrays()
    feature_mean = train_features.mean(axis=0)
    feature_scale = train_features.std(axis=0)
    feature_scale[feature_scale < 1e-5] = 1.0
    train_features = (train_features - feature_mean) / feature_scale
    validation_features = (validation_features - feature_mean) / feature_scale
    train_loader = DataLoader(ActionDataset(train_patches, train_features, train_target, train_utility), batch_size=args.batch_size, shuffle=True, num_workers=0)
    validation_loader = DataLoader(ActionDataset(validation_patches, validation_features, validation_target, validation_utility), batch_size=args.batch_size * 2, shuffle=False, num_workers=0)
    model = CandidateActionNet().to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    positives = max(1.0, float(train_target.sum()))
    negatives = max(1.0, float(len(train_target) - positives))
    positive_weight = torch.tensor(negatives / positives, device=device)
    history: list[dict[str, object]] = []
    best_score = -math.inf
    best_selection: dict[str, object] = {}
    stale = 0
    checkpoint = args.output_dir.resolve() / "best.pt"
    for epoch in range(1, args.epochs + 1):
        model.train()
        losses = []
        for patch, features, target, utility in train_loader:
            patch, features, target, utility = patch.to(device), features.to(device), target.to(device), utility.to(device)
            optimizer.zero_grad(set_to_none=True)
            logit, predicted_utility = model(patch, features)
            classification = F.binary_cross_entropy_with_logits(logit, target, pos_weight=positive_weight)
            regression = F.smooth_l1_loss(predicted_utility, utility, beta=0.20)
            loss = classification + 0.45 * regression
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            losses.append(float(loss.detach()))
        scheduler.step()
        model.eval()
        probabilities, targets, utility_errors = [], [], []
        with torch.no_grad():
            for patch, features, target, utility in validation_loader:
                logit, predicted_utility = model(patch.to(device), features.to(device))
                probabilities.extend(torch.sigmoid(logit).cpu().numpy().tolist())
                targets.extend(target.numpy().tolist())
                utility_errors.extend(torch.abs(predicted_utility.cpu() - utility).numpy().tolist())
        probabilities_array = np.asarray(probabilities)
        targets_array = np.asarray(targets)
        accuracy = float(((probabilities_array >= 0.5) == (targets_array >= 0.5)).mean())
        positive_recall = float(((probabilities_array >= 0.5) & (targets_array >= 0.5)).sum() / max(1, int((targets_array >= 0.5).sum())))
        selection, threshold_rows = validation_choice(
            model,
            validation_context["base_records"], validation_context["stress_records"],
            validation_context["base_raw"], validation_context["stress_raw"],
            validation_context["base_truth"], validation_context["base_indent"],
            validation_context["stress_truth"], validation_context["stress_cutout"],
            validation_context["stress_depth"], validation_context["stress_family"],
            feature_mean, feature_scale, device,
        )
        row = {
            "epoch": epoch, "train_loss": float(np.mean(losses)),
            "validation_accuracy": accuracy, "validation_positive_recall": positive_recall,
            "validation_utility_mae": float(np.mean(utility_errors)), "selection": selection,
        }
        history.append(row)
        print(
            f"epoch {epoch:02d}: loss={row['train_loss']:.4f} acc={accuracy:.3f} recall={positive_recall:.3f} "
            f"thr={selection['threshold']:.2f} width={selection['width_bonus']:.2f} stress_iou={selection['stress']['foreground_iou']:.4f} "
            f"open={selection['stress']['open_deep_cutout_recovery']:.4f} bank={selection['stress']['bank_retention']:.4f} "
            f"eligible={selection['eligible']}", flush=True,
        )
        selection_score = float(selection["score"]) if selection["eligible"] else -math.inf
        if selection_score > best_score + 1e-5:
            best_score = selection_score
            best_selection = selection
            stale = 0
            torch.save({
                "model": model.state_dict(), "feature_mean": feature_mean, "feature_scale": feature_scale,
                "selection": selection, "epoch": epoch, "seed": args.seed,
            }, checkpoint)
            (args.output_dir.resolve() / "best_validation_thresholds.json").write_text(json.dumps(threshold_rows, indent=2), encoding="utf-8")
        else:
            stale += 1
        if epoch >= 12 and stale >= args.patience and checkpoint.exists():
            break
    if not checkpoint.exists():
        raise RuntimeError("No checkpoint satisfied the validation preservation constraints")
    state = torch.load(checkpoint, map_location=device, weights_only=False)
    model.load_state_dict(state["model"])
    (args.output_dir.resolve() / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    return model, state["selection"], {"mean": state["feature_mean"], "scale": state["feature_scale"]}, history


def paired_bootstrap(before: list[dict[str, float]], after: list[dict[str, float]], samples: int, seed: int) -> list[dict[str, object]]:
    metrics = ("foreground_iou", "open_deep_cutout_recovery", "bank_retention", "topology_structural_joint")
    rng = np.random.default_rng(seed)
    draws = rng.integers(0, len(before), size=(samples, len(before)))
    rows = []
    for metric in metrics:
        first = np.asarray([row[metric] for row in before])
        second = np.asarray([row[metric] for row in after])
        difference = second - first
        boot = difference[draws].mean(axis=1)
        rows.append({
            "metric": metric, "before": float(first.mean()), "after": float(second.mean()),
            "difference": float(difference.mean()), "ci95_low": float(np.quantile(boot, 0.025)),
            "ci95_high": float(np.quantile(boot, 0.975)), "improved_fraction": float((difference > 0).mean()),
        })
    return rows


def save_grid(path: Path, truth: np.ndarray, raw: np.ndarray, corrected: np.ndarray, labels: list[str], indices: np.ndarray) -> None:
    figure, axes = plt.subplots(len(indices), 4, figsize=(10.2, 2.35 * len(indices)), squeeze=False)
    for row, index in enumerate(indices):
        images = (truth[index], raw[index], corrected[index], (raw[index] != corrected[index]).astype(np.uint8))
        for column, image in enumerate(images):
            axes[row, column].imshow(image, cmap="viridis", vmin=0, vmax=2, interpolation="nearest")
            axes[row, column].set_axis_off()
        axes[row, 0].set_ylabel(labels[row], fontsize=8)
    for axis, title in zip(axes[0], ("truth", "raw fusion", "learned opening", "changed pixels")):
        axis.set_title(title)
    figure.tight_layout()
    figure.savefig(path, dpi=190)
    plt.close(figure)


def infer_pair(
    conservative_model: nn.Module,
    aggressive_model: nn.Module,
    adapter: InputAdapter,
    images: np.ndarray,
    voltages: np.ndarray,
    device: torch.device,
    batch_size: int,
    size: int = 64,
) -> tuple[np.ndarray, np.ndarray]:
    conservative = infer_probability(conservative_model, adapter, images, voltages, device, batch_size, size)
    aggressive = infer_probability(aggressive_model, adapter, images, voltages, device, batch_size, size)
    return conservative, aggressive


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    base = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    adapter = InputAdapter(base["fov_mask"]).to(device)
    conservative_model = load_model(args.conservative, device)
    aggressive_model = load_model(args.aggressive, device)
    print(f"device={device}; building augmented action data", flush=True)

    all_base_train = np.asarray(base["train_indices"])
    training_rng = np.random.default_rng(args.seed + 17)
    base_train = np.sort(training_rng.choice(all_base_train, size=min(900, len(all_base_train)), replace=False))
    stress_train = np.asarray(stress["train_indices"])
    base_validation, stress_validation = np.asarray(base["validation_indices"]), np.asarray(stress["validation_indices"])
    btc, bta = infer_pair(conservative_model, aggressive_model, adapter, base["linear_images"][base_train], base["voltages"][base_train], device, args.inference_batch_size)
    stc, sta = infer_pair(conservative_model, aggressive_model, adapter, stress["linear_images"][stress_train], stress["voltages"][stress_train], device, args.inference_batch_size)
    train_examples = build_examples(base, stress, base_train, stress_train, btc, bta, stc, sta, args.seed + 1)
    bvc, bva = infer_pair(conservative_model, aggressive_model, adapter, base["linear_images"][base_validation], base["voltages"][base_validation], device, args.inference_batch_size)
    svc, sva = infer_pair(conservative_model, aggressive_model, adapter, stress["linear_images"][stress_validation], stress["voltages"][stress_validation], device, args.inference_batch_size)
    validation_examples = build_examples(base, stress, base_validation, stress_validation, bvc, bva, svc, sva, args.seed + 2)
    train_counts = {kind: train_examples.kind.count(kind) for kind in sorted(set(train_examples.kind))}
    validation_counts = {kind: validation_examples.kind.count(kind) for kind in sorted(set(validation_examples.kind))}
    print(f"training actions={len(train_examples.kind)} positive={int(sum(train_examples.beneficial))} kinds={train_counts}", flush=True)
    print(f"validation actions={len(validation_examples.kind)} positive={int(sum(validation_examples.beneficial))} kinds={validation_counts}", flush=True)

    base_validation_raw = blend(bvc, bva, 0.5)
    stress_validation_raw = blend(svc, sva, 0.5)
    validation_context = {
        "base_records": inference_records(base["linear_images"][base_validation], base_validation_raw, bvc, bva),
        "stress_records": inference_records(stress["linear_images"][stress_validation], stress_validation_raw, svc, sva),
        "base_raw": base_validation_raw, "stress_raw": stress_validation_raw,
        "base_truth": base["labels"][base_validation], "base_indent": base["indentation_masks"][base_validation],
        "stress_truth": stress["labels"][stress_validation], "stress_cutout": stress["cutout_masks"][stress_validation],
        "stress_depth": stress["cutout_depth_weights"][stress_validation], "stress_family": stress["family_codes"][stress_validation],
    }
    model, selected, normalization, history = train_model(train_examples, validation_examples, validation_context, args, device)
    threshold = float(selected["threshold"])
    width_bonus = float(selected["width_bonus"])

    base_test, stress_test = np.asarray(base["test_indices"]), np.asarray(stress["test_indices"])
    btc, bta = infer_pair(conservative_model, aggressive_model, adapter, base["linear_images"][base_test], base["voltages"][base_test], device, args.inference_batch_size)
    stc, sta = infer_pair(conservative_model, aggressive_model, adapter, stress["linear_images"][stress_test], stress["voltages"][stress_test], device, args.inference_batch_size)
    base_raw, stress_raw = blend(btc, bta, 0.5), blend(stc, sta, 0.5)
    base_records = inference_records(base["linear_images"][base_test], base_raw, btc, bta)
    stress_records = inference_records(stress["linear_images"][stress_test], stress_raw, stc, sta)
    score_actions(model, base_records, normalization["mean"], normalization["scale"], device)
    score_actions(model, stress_records, normalization["mean"], normalization["scale"], device)
    base_prediction, base_actions, _ = apply_scored_actions(base_raw, base_records, threshold, width_bonus)
    stress_prediction, stress_actions, accepted_stress = apply_scored_actions(stress_raw, stress_records, threshold, width_bonus)
    base_metric = standard_metrics(base["labels"][base_test], base_prediction, base["indentation_masks"][base_test])
    stress_raw_metric, _, stress_raw_rows = stress_metrics(stress["labels"][stress_test], stress_raw, stress["cutout_masks"][stress_test], stress["cutout_depth_weights"][stress_test], stress["family_codes"][stress_test])
    stress_metric, stress_family, stress_rows = stress_metrics(stress["labels"][stress_test], stress_prediction, stress["cutout_masks"][stress_test], stress["cutout_depth_weights"][stress_test], stress["family_codes"][stress_test])
    bootstrap = paired_bootstrap(stress_raw_rows, stress_rows, 10000, args.seed)

    # Full public KTC2023 evaluation.  Decisions are made at native 256 x 256,
    # while the ridge image is smoothly resized from the 64 x 64 input.
    rc, ra = infer_pair(conservative_model, aggressive_model, adapter, base["real_linear_images"], base["real_voltages"], device, args.inference_batch_size, 256)
    real_raw = blend(rc, ra, 0.5)
    real_images = zoom(base["real_linear_images"], (1.0, 4.0, 4.0), order=1)
    real_records = inference_records(real_images, real_raw, rc, ra, scale=4)
    score_actions(model, real_records, normalization["mean"], normalization["scale"], device)
    real_prediction, real_actions, accepted_real = apply_scored_actions(real_raw, real_records, threshold, width_bonus)
    real_raw_metric, _ = evaluate_real_predictions("raw_fusion", real_raw, base["real_labels"], base["real_ids"])
    real_metric, real_rows = evaluate_real_predictions("candidate_opening", real_prediction, base["real_labels"], base["real_ids"])

    # Original four ABC2 examples are reported as calibration cases only.
    cc, ca = infer_pair(conservative_model, aggressive_model, adapter, base["calibration_linear_images"], base["calibration_voltages"], device, args.inference_batch_size)
    calibration_raw = blend(cc, ca, 0.5)
    calibration_records = inference_records(base["calibration_linear_images"], calibration_raw, cc, ca)
    score_actions(model, calibration_records, normalization["mean"], normalization["scale"], device)
    calibration_prediction, calibration_actions, accepted_calibration = apply_scored_actions(calibration_raw, calibration_records, threshold, width_bonus)
    official_truth, official_ids = load_official_four_case_truths(Path(__file__).resolve().parents[1] / "external" / "KTC2023-ABC2")
    official_predictions = np.repeat(np.repeat(calibration_prediction, 4, axis=1), 4, axis=2)
    official_raw = np.repeat(np.repeat(calibration_raw, 4, axis=1), 4, axis=2)
    dip = load_dip_four_case_predictions(Path(__file__).resolve().parents[1])
    official_summary = {}
    official_rows: list[dict[str, object]] = []
    for name, prediction in (("DIP_TV", dip), ("raw_fusion", official_raw), ("candidate_opening", official_predictions)):
        official_summary[name], rows = evaluate_real_predictions(name, prediction, official_truth, official_ids)
        official_rows.extend(rows)

    changed = np.flatnonzero(np.any(stress_raw != stress_prediction, axis=(1, 2)))
    if len(changed):
        improvement = np.asarray([stress_rows[i]["topology_structural_joint"] - stress_raw_rows[i]["topology_structural_joint"] for i in changed])
        focus = changed[np.argsort(improvement)[::-1][:min(24, len(changed))]]
        save_grid(out / "stress_changed_cases.png", stress["labels"][stress_test], stress_raw, stress_prediction, [FAMILIES[int(stress["family_codes"][stress_test][i])] for i in focus], focus)
    family_focus = []
    for code in range(len(FAMILIES)):
        candidates = np.flatnonzero(stress["family_codes"][stress_test] == code)
        family_focus.append(int(candidates[np.argmax(stress["cutout_depth_weights"][stress_test][candidates].sum(axis=(1, 2)))]))
    save_grid(out / "stress_family_cases.png", stress["labels"][stress_test], stress_raw, stress_prediction, list(FAMILIES), np.asarray(family_focus))
    real_changed = np.flatnonzero(np.any(real_raw != real_prediction, axis=(1, 2)))
    if len(real_changed):
        save_grid(out / "real_changed_cases.png", base["real_labels"], real_raw, real_prediction, [str(base["real_ids"][i]) for i in real_changed], real_changed)
    save_grid(out / "official_four_cases.png", official_truth, official_raw, official_predictions, [str(item) for item in official_ids], np.arange(4))

    np.savez_compressed(
        out / "predictions.npz", base=base_prediction, stress=stress_prediction, stress_raw=stress_raw,
        real=real_prediction, real_raw=real_raw, calibration=official_predictions, calibration_raw=official_raw,
    )
    with (out / "stress_bootstrap.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(bootstrap[0])); writer.writeheader(); writer.writerows(bootstrap)
    with (out / "official_four_metrics.csv").open("w", newline="", encoding="utf-8") as handle:
        keys = sorted({key for row in official_rows for key in row}); writer = csv.DictWriter(handle, fieldnames=keys); writer.writeheader(); writer.writerows(official_rows)
    summary = {
        "method": "augmentation-trained candidate geodesic opening and width scorer",
        "data_policy": "train/validation only for fitting and threshold selection; synthetic test, 21 KTC labels, and ABC2 truths held out",
        "training_examples": {"actions": len(train_examples.kind), "positive_actions": int(sum(train_examples.beneficial)), "kinds": train_counts},
        "validation_examples": {"actions": len(validation_examples.kind), "positive_actions": int(sum(validation_examples.beneficial)), "kinds": validation_counts},
        "selected": selected,
        "test": {
            "base_actions": base_actions, "stress_actions": stress_actions, "real_actions": real_actions, "calibration_actions": calibration_actions,
            "base": base_metric, "stress_raw": stress_raw_metric, "stress_candidate": stress_metric,
            "stress_by_family": stress_family, "bootstrap": bootstrap,
            "real_raw": real_raw_metric, "real_candidate": real_metric, "real_cases": real_rows,
            "official_four": official_summary, "accepted_stress": accepted_stress,
            "accepted_real": accepted_real, "accepted_calibration": accepted_calibration,
        },
        "checkpoint_epoch": int(torch.load(out / "best.pt", map_location="cpu", weights_only=False)["epoch"]),
        "args": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
    }
    (out / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary["test"], ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
