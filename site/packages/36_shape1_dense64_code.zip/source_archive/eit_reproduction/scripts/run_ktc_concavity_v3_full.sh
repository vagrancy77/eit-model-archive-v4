#!/usr/bin/env bash
set -euo pipefail

ROOT=/mnt/e/Codex/eit_reproduction
PY=/home/luandingyu/miniforge3/envs/gn4ip-env/bin/python
DATA="$ROOT/datasets/ktc_joint_concavity_v1.npz"
BIO="$ROOT/datasets/ktc_biological_concavity_v1.npz"
OUT="$ROOT/outputs/ktc_concavity_v3_biological"

mkdir -p "$OUT"
date -Iseconds > "$OUT/started_at.txt"
"$PY" -c "import torch; assert torch.cuda.is_available(); print(torch.__version__); print(torch.version.cuda); print(torch.cuda.get_device_name(0))" \
  | tee "$OUT/gpu_environment.txt"

"$PY" "$ROOT/scripts/build_ktc_joint_concavity_dataset.py" \
  --biological "$BIO" \
  --output "$DATA"

# End-to-end runtime check on the production data shape. These checkpoints are
# never used by the pilot or final experiment.
"$PY" "$ROOT/scripts/train_ktc_concavity_network_v3.py" \
  --dataset "$DATA" \
  --output-dir "$OUT/smoke/train" \
  --models vanilla,indent \
  --epochs 1 \
  --patience 1 \
  --base-channels 8 \
  --batch-size 48 \
  --calibration-weight 0.05 \
  --seed 20260830 \
  2>&1 | tee "$OUT/smoke_train.log"

# Architecture pilot: all choices are made from the joint validation split.
"$PY" "$ROOT/scripts/train_ktc_concavity_network_v3.py" \
  --dataset "$DATA" \
  --output-dir "$OUT/pilot" \
  --models vanilla,boundary,indent,voltage,v2 \
  --epochs 45 \
  --patience 10 \
  --base-channels 24 \
  --batch-size 32 \
  --seed 20260830 \
  2>&1 | tee "$OUT/pilot.log"

CANDIDATE=$("$PY" -c "import json; print(json.load(open('$OUT/pilot/selection_summary.json'))['selection']['selected_model'])")
printf '%s\n' "$CANDIDATE" > "$OUT/frozen_candidate_architecture.txt"
echo "Frozen candidate architecture: $CANDIDATE"

# Exercise the complete evaluator only after the architecture has been frozen.
"$PY" "$ROOT/scripts/evaluate_ktc_concavity_v3.py" \
  --dataset "$DATA" \
  --reference-checkpoint "$OUT/smoke/train/vanilla_best.pt" \
  --candidate-checkpoint "$OUT/smoke/train/indent_best.pt" \
  --candidate-architecture indent \
  --output-dir "$OUT/smoke/evaluation" \
  --batch-size 48 \
  --bootstrap-repetitions 100 \
  --seed 20260830 \
  2>&1 | tee "$OUT/smoke_evaluation.log"

SEEDS=(20260831 20260901 20260902)
RUN_ARGS=()
for SEED in "${SEEDS[@]}"; do
  SEED_OUT="$OUT/seed_$SEED"
  "$PY" "$ROOT/scripts/train_ktc_concavity_network_v3.py" \
    --dataset "$DATA" \
    --output-dir "$SEED_OUT/train" \
    --models "vanilla,$CANDIDATE" \
    --epochs 72 \
    --patience 14 \
    --base-channels 32 \
    --batch-size 32 \
    --seed "$SEED" \
    2>&1 | tee "$SEED_OUT-train.log"

  "$PY" "$ROOT/scripts/evaluate_ktc_concavity_v3.py" \
    --dataset "$DATA" \
    --reference-checkpoint "$SEED_OUT/train/vanilla_best.pt" \
    --candidate-checkpoint "$SEED_OUT/train/${CANDIDATE}_best.pt" \
    --candidate-architecture "$CANDIDATE" \
    --output-dir "$SEED_OUT/evaluation" \
    --batch-size 48 \
    --bootstrap-repetitions 5000 \
    --seed "$SEED" \
    2>&1 | tee "$SEED_OUT-evaluation.log"
  RUN_ARGS+=("$SEED=$SEED_OUT/evaluation")
done

"$PY" "$ROOT/scripts/aggregate_ktc_concavity_v3_multiseed.py" \
  --runs "${RUN_ARGS[@]}" \
  --output-dir "$OUT/aggregate" \
  --bootstrap-repetitions 20000 \
  --seed 20260903 \
  2>&1 | tee "$OUT/aggregate.log"

"$PY" "$ROOT/scripts/assess_ktc_concavity_v3.py" \
  --aggregate "$OUT/aggregate/summary.json" \
  --output-dir "$OUT/aggregate" \
  --candidate-architecture "$CANDIDATE" \
  --pilot-summary "$OUT/pilot/selection_summary.json" \
  2>&1 | tee "$OUT/assessment.log"

date -Iseconds > "$OUT/completed_at.txt"
echo "Full KTC concavity v3 experiment completed."
