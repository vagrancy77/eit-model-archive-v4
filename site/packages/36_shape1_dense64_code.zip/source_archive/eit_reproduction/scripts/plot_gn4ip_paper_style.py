from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.tri as mtri
import numpy as np
from scipy.io import loadmat


def parse_arguments() -> argparse.Namespace:
    project_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(
        description=(
            "Render MATLAB-paper-style GN4IP Conv U-Net reproduction figures "
            "from the public test data and the public author yhat artifact."
        )
    )
    parser.add_argument(
        "--project-root",
        type=Path,
        default=project_root,
        help="Root of this reproduction project.",
    )
    parser.add_argument(
        "--samples",
        type=int,
        default=3,
        help="Number of public test samples to render.",
    )
    return parser.parse_args()


def correlation(truth: np.ndarray, prediction: np.ndarray) -> float:
    truth_centered = truth - truth.mean()
    prediction_centered = prediction - prediction.mean()
    denominator = np.linalg.norm(truth_centered) * np.linalg.norm(prediction_centered)
    if denominator <= np.finfo(float).eps:
        return float("nan")
    return float(np.sum(truth_centered * prediction_centered) / denominator)


def relative_l2(truth: np.ndarray, prediction: np.ndarray) -> float:
    denominator = max(float(np.linalg.norm(truth)), np.finfo(float).eps)
    return float(np.linalg.norm(truth - prediction) / denominator)


def grid_to_mesh(grid: np.ndarray, closest_pixels: np.ndarray) -> np.ndarray:
    flattened = grid.reshape(grid.shape[0], -1)
    return flattened[:, closest_pixels]


def render_sample(
    sample_index: int,
    triangulation: mtri.Triangulation,
    truth_mesh: np.ndarray,
    lm_mesh: np.ndarray,
    yhat_mesh: np.ndarray,
    lm_grid: np.ndarray,
    yhat_grid: np.ndarray,
    metrics: dict[str, float],
    output_path: Path,
) -> None:
    figure, axes = plt.subplots(
        2,
        3,
        figsize=(10.5, 7.0),
        constrained_layout=True,
    )
    mesh_items = [
        (lm_mesh, "Network input: 3-step LM X2"),
        (yhat_mesh, "Network output: Conv U-Net"),
        (truth_mesh, "Ground truth Y"),
    ]
    vmin, vmax = -0.05, 0.35
    for column, (field, title) in enumerate(mesh_items):
        image = axes[0, column].tripcolor(
            triangulation,
            facecolors=field,
            shading="flat",
            cmap="viridis",
            vmin=vmin,
            vmax=vmax,
        )
        axes[0, column].set_title(title)
        axes[0, column].set_aspect("equal")
        axes[0, column].set_axis_off()
        figure.colorbar(image, ax=axes[0, column], fraction=0.046, pad=0.04)

    grid_items = [
        (lm_grid, "X2 embedded on 32×32 grid"),
        (yhat_grid, "Conv U-Net yhat grid"),
    ]
    for column, (field, title) in enumerate(grid_items):
        image = axes[1, column].imshow(
            np.flipud(field),
            cmap="viridis",
            vmin=vmin,
            vmax=vmax,
            interpolation="nearest",
        )
        axes[1, column].set_title(title)
        axes[1, column].set_aspect("equal")
        axes[1, column].set_axis_off()
        figure.colorbar(image, ax=axes[1, column], fraction=0.046, pad=0.04)

    axes[1, 2].set_axis_off()
    axes[1, 2].text(
        0.0,
        0.78,
        "\n".join(
            [
                f"Public test sample: {sample_index}",
                f"corr(Y, X2): {metrics['lm_correlation']:.4f}",
                f"corr(Y, yhat): {metrics['unet_correlation']:.4f}",
                f"relL2(Y, X2): {metrics['lm_relative_l2']:.4f}",
                f"relL2(Y, yhat): {metrics['unet_relative_l2']:.4f}",
            ]
        ),
        ha="left",
        va="top",
        fontsize=11,
        family="monospace",
    )
    figure.suptitle(
        "GN4IP public Conv U-Net reproduction",
        fontsize=14,
    )
    figure.savefig(output_path, dpi=220)
    plt.close(figure)


def render_training_loss(training_output: dict, output_path: Path) -> None:
    loss_tr = np.asarray(training_output["loss_tr"], dtype=float).reshape(-1)
    loss_va = np.asarray(training_output["loss_va"], dtype=float).reshape(-1)
    epochs = np.arange(1, loss_tr.size + 1)
    best_epoch = int(np.argmin(loss_va) + 1)

    figure, axis = plt.subplots(figsize=(7.5, 4.5), constrained_layout=True)
    axis.plot(epochs, loss_tr, label="Training")
    axis.plot(epochs, loss_va, label="Validation")
    axis.axvline(best_epoch, color="black", linestyle="--", label="Best weights")
    axis.set_title("Conv U-Net loss")
    axis.set_xlabel("Epoch")
    axis.set_ylabel("MSE loss")
    axis.set_ylim(0, 1)
    axis.grid(True, alpha=0.4)
    axis.legend(loc="upper center")
    figure.savefig(output_path, dpi=220)
    plt.close(figure)


def main() -> None:
    arguments = parse_arguments()
    project_root = arguments.project_root.resolve()
    data_dir = project_root / "external" / "GN4IP" / "data"
    output_dir = project_root / "outputs_gn4ip" / "paper_style_figures"
    output_dir.mkdir(parents=True, exist_ok=True)

    testing = loadmat(data_dir / "test_data_v0.mat")
    author_output = loadmat(data_dir / "conv_unet_test_output_v0.mat")
    training_output = loadmat(data_dir / "conv_unet_train_output.mat")

    closest_elements = testing["closest_elements"].astype(np.int64).reshape(-1) - 1
    closest_pixels = testing["closest_pixels"].astype(np.int64).reshape(-1) - 1
    n_pixels = int(testing["n_pixels"].item())
    truth_mesh_all = np.asarray(testing["Y"], dtype=float)
    lm_mesh_all = np.asarray(testing["X2"], dtype=float)
    lm_grid_all = lm_mesh_all[:, closest_elements].reshape(-1, n_pixels, n_pixels)
    yhat_grid_all = np.asarray(author_output["yhat"], dtype=float)
    yhat_mesh_all = grid_to_mesh(yhat_grid_all, closest_pixels)

    rec_model = testing["rec_fmdl"][0, 0]
    nodes = np.asarray(rec_model["nodes"], dtype=float)
    elements = np.asarray(rec_model["elems"], dtype=np.int64) - 1
    triangulation = mtri.Triangulation(nodes[:, 0], nodes[:, 1], elements)

    rows: list[dict[str, float | int]] = []
    n_samples = min(arguments.samples, truth_mesh_all.shape[0])
    for sample_index in range(n_samples):
        metrics = {
            "lm_correlation": correlation(
                truth_mesh_all[sample_index],
                lm_mesh_all[sample_index],
            ),
            "unet_correlation": correlation(
                truth_mesh_all[sample_index],
                yhat_mesh_all[sample_index],
            ),
            "lm_relative_l2": relative_l2(
                truth_mesh_all[sample_index],
                lm_mesh_all[sample_index],
            ),
            "unet_relative_l2": relative_l2(
                truth_mesh_all[sample_index],
                yhat_mesh_all[sample_index],
            ),
        }
        rows.append({"sample": sample_index, **metrics})
        render_sample(
            sample_index,
            triangulation,
            truth_mesh_all[sample_index],
            lm_mesh_all[sample_index],
            yhat_mesh_all[sample_index],
            lm_grid_all[sample_index],
            yhat_grid_all[sample_index],
            metrics,
            output_dir / f"gn4ip_conv_unet_sample_{sample_index}_paper_style.png",
        )

    render_training_loss(
        training_output,
        output_dir / "gn4ip_conv_unet_training_loss.png",
    )

    with (output_dir / "per_sample_metrics.csv").open(
        "w",
        encoding="utf-8",
        newline="",
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "sample",
                "lm_correlation",
                "unet_correlation",
                "lm_relative_l2",
                "unet_relative_l2",
            ],
        )
        writer.writeheader()
        writer.writerows(rows)

    mean_metrics = {
        "mean_lm_correlation": float(np.mean([r["lm_correlation"] for r in rows])),
        "mean_unet_correlation": float(np.mean([r["unet_correlation"] for r in rows])),
        "mean_lm_relative_l2": float(np.mean([r["lm_relative_l2"] for r in rows])),
        "mean_unet_relative_l2": float(np.mean([r["unet_relative_l2"] for r in rows])),
        "rendered_samples": n_samples,
    }
    with (output_dir / "paper_style_summary.json").open(
        "w",
        encoding="utf-8",
    ) as handle:
        json.dump(mean_metrics, handle, ensure_ascii=False, indent=2)

    print(f"Rendered GN4IP paper-style figures to {output_dir}")


if __name__ == "__main__":
    main()
