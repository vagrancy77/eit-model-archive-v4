"""Audit all public KTC2023 v3 ground truths for non-convex structure.

The audit treats all non-zero labels as the foreground for geometry metrics,
while retaining per-label areas so resistive/conductive inclusions are not
silently merged in later experiments.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
import scipy.io as sio
from PIL import Image, ImageDraw
from scipy.ndimage import label as connected_components
from scipy.spatial import ConvexHull, QhullError


def convex_hull_mask(binary: np.ndarray) -> np.ndarray:
    rows, cols = np.nonzero(binary)
    if rows.size < 3:
        return binary.copy()
    points = np.column_stack((cols, rows))
    try:
        hull = ConvexHull(points)
    except QhullError:
        return binary.copy()
    canvas = Image.new("1", (binary.shape[1], binary.shape[0]), 0)
    polygon = [tuple(point) for point in points[hull.vertices]]
    ImageDraw.Draw(canvas).polygon(polygon, outline=1, fill=1)
    return np.asarray(canvas, dtype=bool)


def audit_truth(truth: np.ndarray) -> dict[str, object]:
    foreground = truth != 0
    hull = convex_hull_mask(foreground)
    indentation = hull & ~foreground
    components, count = connected_components(foreground, structure=np.ones((3, 3), dtype=np.uint8))
    component_rows: list[dict[str, float | int | bool]] = []
    component_area = 0
    component_hull_area = 0
    component_indentations = 0
    for component_id in range(1, count + 1):
        component = components == component_id
        area = int(component.sum())
        if area < 8:
            continue
        component_hull = convex_hull_mask(component)
        hull_area = int(component_hull.sum())
        indentation_pixels = int((component_hull & ~component).sum())
        indentation_fraction = float(indentation_pixels / max(1, hull_area))
        component_rows.append(
            {
                "component_id": int(component_id),
                "area": area,
                "convex_hull_area": hull_area,
                "convexity": float(area / max(1, hull_area)),
                "indentation_pixels": indentation_pixels,
                "indentation_fraction_of_hull": indentation_fraction,
                # Ignore tiny rasterization defects on otherwise round objects.
                "is_materially_concave": bool(indentation_pixels >= 50 and indentation_fraction >= 0.03),
            }
        )
        component_area += area
        component_hull_area += hull_area
        component_indentations += indentation_pixels
    labels = [int(value) for value in np.unique(truth) if value != 0]
    return {
        "height": int(truth.shape[0]),
        "width": int(truth.shape[1]),
        "labels": labels,
        "label_areas": {str(label): int((truth == label).sum()) for label in labels},
        "foreground_area": int(foreground.sum()),
        "connected_components": int(count),
        "components": component_rows,
        "materially_concave_components": int(sum(bool(row["is_materially_concave"]) for row in component_rows)),
        "componentwise_convexity": float(component_area / max(1, component_hull_area)),
        "componentwise_indentation_pixels": int(component_indentations),
        "componentwise_indentation_fraction": float(component_indentations / max(1, component_hull_area)),
        "convex_hull_area": int(hull.sum()),
        "truth_convexity": float(foreground.sum() / max(1, hull.sum())),
        "indentation_pixels": int(indentation.sum()),
        "indentation_fraction_of_hull": float(indentation.sum() / max(1, hull.sum())),
        "has_nonconvex_boundary": bool(any(bool(row["is_materially_concave"]) for row in component_rows)),
    }


def save_montage(records: list[dict[str, object]], output: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    columns = 7
    rows = int(np.ceil(len(records) / columns))
    figure, axes = plt.subplots(rows, columns, figsize=(columns * 2.35, rows * 2.75), squeeze=False)
    for axis in axes.ravel():
        axis.set_axis_off()
    for axis, record in zip(axes.ravel(), records):
        image = np.asarray(Image.open(record["png_path"])) if record.get("png_path") else record["truth"]
        axis.imshow(image, cmap="gray", vmin=0, vmax=2)
        axis.set_title(
            f"L{record['level']} / {record['sample']}\n"
            f"conv={record['componentwise_convexity']:.2f}, notch={record['componentwise_indentation_pixels']}"
        )
        axis.set_axis_off()
    figure.suptitle("KTC2023 v3 public evaluation ground truths: non-convexity audit", fontsize=15)
    figure.tight_layout()
    figure.savefig(output, dpi=180)
    plt.close(figure)


def parse_args() -> argparse.Namespace:
    project_root = Path(__file__).resolve().parents[1]
    default_root = project_root / "datasets" / "ktc2023_full" / "v3" / "evaluation_full" / "EvaluationData_full"
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-root", type=Path, default=default_root)
    parser.add_argument("--output-dir", type=Path, default=project_root / "outputs" / "ktc2023_full_audit")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    truth_root = args.dataset_root.resolve() / "GroundTruths"
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    records: list[dict[str, object]] = []
    for path in sorted(truth_root.glob("level_*/*_true.mat")):
        level = int(path.parent.name.split("_")[-1])
        sample = int(path.stem.split("_")[0])
        truth = np.asarray(sio.loadmat(path)["truth"])
        record = {"level": level, "sample": sample, "mat_path": str(path), "png_path": str(path.with_suffix(".png"))}
        record.update(audit_truth(truth))
        records.append(record)

    records.sort(key=lambda item: (int(item["level"]), int(item["sample"])))
    with (output_dir / "shape_audit.json").open("w", encoding="utf-8") as handle:
        json.dump(records, handle, ensure_ascii=False, indent=2)
    fields = [
        "level", "sample", "foreground_area", "connected_components", "materially_concave_components",
        "componentwise_convexity", "componentwise_indentation_pixels", "componentwise_indentation_fraction",
        "truth_convexity", "convex_hull_area", "indentation_pixels", "indentation_fraction_of_hull",
        "has_nonconvex_boundary", "labels", "label_areas", "mat_path",
    ]
    with (output_dir / "shape_audit.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for record in records:
            writer.writerow({field: record.get(field) for field in fields})
    save_montage(records, output_dir / "ground_truth_montage.png")

    nonconvex = [record for record in records if record["has_nonconvex_boundary"]]
    most_concave = sorted(records, key=lambda item: float(item["componentwise_indentation_fraction"]), reverse=True)
    summary = {
        "dataset_root": str(args.dataset_root.resolve()),
        "num_samples": len(records),
        "num_nonconvex": len(nonconvex),
        "nonconvex_ids": [f"level_{r['level']}/{r['sample']}" for r in nonconvex],
        "most_nonconvex": [
            {
                "id": f"level_{r['level']}/{r['sample']}",
                "convexity": r["componentwise_convexity"],
                "indentation_pixels": r["componentwise_indentation_pixels"],
                "indentation_fraction_of_hull": r["componentwise_indentation_fraction"],
            }
            for r in most_concave[:10]
        ],
    }
    with (output_dir / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print(f"Saved {output_dir / 'shape_audit.csv'}")
    print(f"Saved {output_dir / 'ground_truth_montage.png'}")


if __name__ == "__main__":
    main()
