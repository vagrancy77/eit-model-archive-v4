"""Train a local, safety-calibrated fusion network over frozen EIT candidates.

The first candidate is treated as the conservative reconstruction.  The model
does not redraw the image freely: at every pixel it can only mix class labels
already proposed by the frozen candidate pool.  A learned gate limits these
local edits, and validation-only calibration selects the final edit strength.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import random
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy import ndimage as ndi
from torch.utils.data import DataLoader, Dataset, WeightedRandomSampler

from prepare_ktc_deep_concavity_stress import FAMILIES
from train_ktc_concavity_network import aggregate_rows, confusion_metrics
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_implicit_boolean_network import standard_metrics, stress_metrics


STRICT_INWARD_IDS = (
    "level_2/1", "level_2/3", "level_3/2", "level_5/2",
    "level_6/2", "level_6/3", "level_7/1", "level_7/2", "level_7/3",
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    parser.add_argument(
        "--pool-dir", type=Path,
        default=root / "outputs" / "ktc_cross_representation_pool_seed20260820",
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=root / "outputs" / "ktc_cross_representation_pixel_fusion_seed20260820",
    )
    parser.add_argument("--epochs", type=int, default=65)
    parser.add_argument("--patience", type=int, default=14)
    parser.add_argument("--batch-size", type=int, default=24)
    parser.add_argument("--public-batch-size", type=int, default=2)
    parser.add_argument("--base-channels", type=int, default=24)
    parser.add_argument("--learning-rate", type=float, default=8e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--stress-sampling-weight", type=float, default=3.0)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--seed", type=int, default=20260820)
    parser.add_argument("--bootstrap-repetitions", type=int, default=10000)
    parser.add_argument("--base-iou-tolerance", type=float, default=0.003)
    parser.add_argument("--base-boundary-tolerance", type=float, default=0.004)
    parser.add_argument("--stress-iou-tolerance", type=float, default=0.006)
    parser.add_argument("--stress-bank-tolerance", type=float, default=0.012)
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = True


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def load_pool(path: Path) -> tuple[list[str], np.ndarray, np.ndarray]:
    archive = np.load(path, allow_pickle=False)
    return (
        [str(value) for value in archive["candidate_names"]],
        np.asarray(archive["indices"], dtype=np.int64),
        np.asarray(archive["candidates"], dtype=np.uint8),
    )


@dataclass
class SplitArrays:
    name: str
    source: str
    indices: np.ndarray
    images: np.ndarray
    voltages: np.ndarray
    truths: np.ndarray
    candidates: np.ndarray
    cutouts: np.ndarray
    depths: np.ndarray
    families: np.ndarray


def depth_weights(masks: np.ndarray) -> np.ndarray:
    result = np.zeros_like(masks, dtype=np.float32)
    for index, mask in enumerate(masks):
        distance = ndi.distance_transform_edt(mask != 0)
        if distance.max() > 0:
            distance /= distance.max()
        result[index] = distance.astype(np.float32)
    return result


def prepare_split(
    name: str,
    source: str,
    dataset: np.lib.npyio.NpzFile,
    pool_dir: Path,
) -> tuple[list[str], SplitArrays]:
    names, indices, candidates = load_pool(pool_dir / f"{name}.npz")
    if source == "stress":
        cutouts = np.asarray(dataset["cutout_masks"][indices], dtype=np.uint8)
        depths = np.asarray(dataset["cutout_depth_weights"][indices], dtype=np.float32)
        families = np.asarray(dataset["family_codes"][indices], dtype=np.int16)
    else:
        cutouts = np.asarray(dataset["indentation_masks"][indices], dtype=np.uint8)
        depths = depth_weights(cutouts)
        families = np.full(len(indices), -1, dtype=np.int16)
    return names, SplitArrays(
        name=name,
        source=source,
        indices=indices,
        images=np.asarray(dataset["linear_images"][indices], dtype=np.float32),
        voltages=np.asarray(dataset["voltages"][indices], dtype=np.float32),
        truths=np.asarray(dataset["labels"][indices], dtype=np.uint8),
        candidates=candidates,
        cutouts=cutouts,
        depths=depths,
        families=families,
    )


class FusionDataset(Dataset):
    def __init__(self, splits: SplitArrays | list[SplitArrays]) -> None:
        self.splits = splits if isinstance(splits, list) else [splits]
        self.lookup: list[tuple[int, int]] = []
        for split_index, split in enumerate(self.splits):
            self.lookup.extend((split_index, item) for item in range(len(split.indices)))

    def __len__(self) -> int:
        return len(self.lookup)

    def __getitem__(self, index: int) -> dict[str, torch.Tensor]:
        split_index, item = self.lookup[index]
        split = self.splits[split_index]
        return {
            "image": torch.from_numpy(split.images[item][None]),
            "voltage": torch.from_numpy(split.voltages[item]),
            "truth": torch.from_numpy(split.truths[item].astype(np.int64)),
            "candidates": torch.from_numpy(split.candidates[:, item].astype(np.int64)),
            "cutout": torch.from_numpy(split.cutouts[item][None].astype(np.float32)),
            "depth": torch.from_numpy(split.depths[item][None].astype(np.float32)),
            "source": torch.tensor(1 if split.source == "stress" else 0, dtype=torch.int64),
        }


def norm_layer(channels: int) -> nn.GroupNorm:
    groups = min(8, channels)
    while channels % groups:
        groups -= 1
    return nn.GroupNorm(groups, channels)


class ResidualBlock(nn.Module):
    def __init__(self, in_channels: int, out_channels: int) -> None:
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, 3, padding=1, bias=False)
        self.norm1 = norm_layer(out_channels)
        self.conv2 = nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False)
        self.norm2 = norm_layer(out_channels)
        self.skip = nn.Identity() if in_channels == out_channels else nn.Conv2d(in_channels, out_channels, 1, bias=False)

    def forward(self, value: torch.Tensor) -> torch.Tensor:
        residual = self.skip(value)
        value = F.silu(self.norm1(self.conv1(value)))
        return F.silu(self.norm2(self.conv2(value)) + residual)


class DecoderStage(nn.Module):
    def __init__(self, in_channels: int, skip_channels: int, out_channels: int) -> None:
        super().__init__()
        self.reduce = nn.Conv2d(in_channels, out_channels, 1)
        self.block = ResidualBlock(out_channels + skip_channels, out_channels)

    def forward(self, value: torch.Tensor, skip: torch.Tensor) -> torch.Tensor:
        value = F.interpolate(value, size=skip.shape[-2:], mode="bilinear", align_corners=False)
        value = self.reduce(value)
        return self.block(torch.cat((value, skip), dim=1))


class PixelCandidateFusionNet(nn.Module):
    def __init__(self, candidate_count: int, base: int, fov_mask: np.ndarray) -> None:
        super().__init__()
        self.candidate_count = candidate_count
        input_channels = 3 * candidate_count + 7
        self.register_buffer("fov", torch.from_numpy(fov_mask.astype(np.float32))[None, None])
        self.stem = ResidualBlock(input_channels, base)
        self.enc1 = ResidualBlock(base, base * 2)
        self.enc2 = ResidualBlock(base * 2, base * 4)
        self.enc3 = ResidualBlock(base * 4, base * 8)
        self.bottleneck = nn.Sequential(
            ResidualBlock(base * 8, base * 8), nn.Dropout2d(0.10), ResidualBlock(base * 8, base * 8)
        )
        self.voltage = nn.Sequential(
            nn.Linear(2356, 256), nn.LayerNorm(256), nn.SiLU(), nn.Dropout(0.10),
            nn.Linear(256, base * 8), nn.SiLU(),
        )
        self.voltage_gate = nn.Parameter(torch.tensor(-1.0))
        self.dec3 = DecoderStage(base * 8, base * 8, base * 8)
        self.dec2 = DecoderStage(base * 8, base * 4, base * 4)
        self.dec1 = DecoderStage(base * 4, base * 2, base * 2)
        self.dec0 = DecoderStage(base * 2, base, base)
        self.attention_head = nn.Conv2d(base, candidate_count, 1)
        self.gate_head = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))
        nn.init.zeros_(self.attention_head.weight)
        nn.init.zeros_(self.attention_head.bias)
        nn.init.zeros_(self.gate_head[-1].weight)
        nn.init.constant_(self.gate_head[-1].bias, -2.2)

    @staticmethod
    def normalize_image(image: torch.Tensor) -> torch.Tensor:
        flat = image.flatten(1)
        center = flat.median(dim=1, keepdim=True).values
        centered = flat - center
        scale = torch.quantile(centered.abs(), 0.985, dim=1, keepdim=True).clamp_min(1e-6)
        return (torch.clamp(centered / scale, -3.0, 3.0) / 3.0).reshape_as(image)

    @staticmethod
    def normalize_voltage(voltage: torch.Tensor) -> torch.Tensor:
        center = voltage.median(dim=1, keepdim=True).values
        centered = voltage - center
        scale = torch.quantile(centered.abs(), 0.985, dim=1, keepdim=True).clamp_min(1e-6)
        return torch.clamp(centered / scale, -4.0, 4.0) / 4.0

    def features(self, image: torch.Tensor, candidates: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        batch, count, height, width = candidates.shape
        one_hot = F.one_hot(candidates, num_classes=3).permute(0, 1, 4, 2, 3).float()
        vote = one_hot.mean(dim=1)
        entropy = -(vote.clamp_min(1e-6) * vote.clamp_min(1e-6).log()).sum(dim=1, keepdim=True) / math.log(3.0)
        foreground = (candidates != 0).float()
        baseline_foreground = foreground[:, :1]
        removed_vote = (baseline_foreground * (1.0 - foreground)).mean(dim=1, keepdim=True)
        added_vote = ((1.0 - baseline_foreground) * foreground).mean(dim=1, keepdim=True)
        normalized = self.normalize_image(image)
        if normalized.shape[-2:] != (height, width):
            normalized = F.interpolate(normalized, size=(height, width), mode="bilinear", align_corners=False)
        inputs = torch.cat((
            normalized,
            one_hot.reshape(batch, 3 * count, height, width),
            vote,
            entropy,
            removed_vote,
            added_vote,
        ), dim=1)
        return inputs, one_hot, entropy

    def forward(self, image: torch.Tensor, voltage: torch.Tensor, candidates: torch.Tensor) -> dict[str, torch.Tensor]:
        inputs, candidate_one_hot, entropy = self.features(image, candidates)
        e0 = self.stem(inputs)
        e1 = self.enc1(F.max_pool2d(e0, 2))
        e2 = self.enc2(F.max_pool2d(e1, 2))
        e3 = self.enc3(F.max_pool2d(e2, 2))
        value = self.bottleneck(F.max_pool2d(e3, 2))
        context = self.voltage(self.normalize_voltage(voltage))[:, :, None, None]
        value = value + torch.sigmoid(self.voltage_gate) * context
        value = self.dec3(value, e3)
        value = self.dec2(value, e2)
        value = self.dec1(value, e1)
        value = self.dec0(value, e0)
        attention = torch.softmax(self.attention_head(value), dim=1)
        proposed = (attention[:, :, None] * candidate_one_hot).sum(dim=1).clamp_min(1e-7)
        gate = torch.sigmoid(self.gate_head(value))
        baseline = candidate_one_hot[:, 0] * 0.98 + (1.0 - candidate_one_hot[:, 0]) * 0.01
        fov = F.interpolate(self.fov, size=gate.shape[-2:], mode="nearest")
        gate = gate * fov
        final = ((1.0 - gate) * baseline + gate * proposed).clamp_min(1e-7)
        return {
            "probabilities": final,
            "proposed": proposed,
            "attention": attention,
            "gate": gate,
            "gate_logit": self.gate_head(value),
            "baseline": baseline,
            "entropy": entropy,
        }


def soft_dice_loss(probabilities: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    one_hot = F.one_hot(target, num_classes=3).permute(0, 3, 1, 2).float()
    intersection = (probabilities[:, 1:] * one_hot[:, 1:]).sum(dim=(0, 2, 3))
    denominator = (probabilities[:, 1:] + one_hot[:, 1:]).sum(dim=(0, 2, 3))
    return 1.0 - ((2.0 * intersection + 1.0) / (denominator + 1.0)).mean()


def masked_mean(value: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    per_case = (value * mask).sum(dim=(1, 2, 3)) / mask.sum(dim=(1, 2, 3)).clamp_min(1.0)
    valid = mask.sum(dim=(1, 2, 3)) > 0
    return per_case[valid].mean() if valid.any() else value.new_zeros(())


def balanced_gate_loss(logit: torch.Tensor, target: torch.Tensor, domain: torch.Tensor) -> torch.Tensor:
    raw = F.binary_cross_entropy_with_logits(logit, target, reduction="none")
    positive = target * domain
    negative = (1.0 - target) * domain
    pos = (raw * positive).sum(dim=(1, 2, 3)) / positive.sum(dim=(1, 2, 3)).clamp_min(1.0)
    neg = (raw * negative).sum(dim=(1, 2, 3)) / negative.sum(dim=(1, 2, 3)).clamp_min(1.0)
    valid = positive.sum(dim=(1, 2, 3)) > 0
    return torch.where(valid, 0.5 * (pos + neg), neg).mean()


def compute_loss(outputs: dict[str, torch.Tensor], batch: dict[str, torch.Tensor]) -> tuple[torch.Tensor, dict[str, float]]:
    probabilities = outputs["probabilities"]
    target = batch["truth"]
    target_one_hot = F.one_hot(target, num_classes=3).permute(0, 3, 1, 2).float()
    candidates = batch["candidates"]
    baseline = candidates[:, 0]
    disagreement = (candidates != baseline[:, None]).float().mean(dim=1, keepdim=True)
    correct_any = (candidates == target[:, None]).any(dim=1, keepdim=True).float()
    fixable = ((baseline != target)[:, None].float() * correct_any * (disagreement > 0).float())
    domain = (disagreement > 0).float()
    true_probability = (probabilities * target_one_hot).sum(dim=1, keepdim=True).clamp_min(1e-7)
    class_weight = torch.where((target != 0)[:, None], 1.25, 0.55).float()
    pixel_weight = class_weight * (1.0 + 1.75 * disagreement)
    segmentation = masked_mean(-torch.log(true_probability), pixel_weight)
    dice = soft_dice_loss(probabilities, target)
    foreground = probabilities[:, 1:].sum(dim=1, keepdim=True)
    target_foreground = (target != 0).float()[:, None]
    pred_dy = foreground[:, :, 1:, :] - foreground[:, :, :-1, :]
    true_dy = target_foreground[:, :, 1:, :] - target_foreground[:, :, :-1, :]
    pred_dx = foreground[:, :, :, 1:] - foreground[:, :, :, :-1]
    true_dx = target_foreground[:, :, :, 1:] - target_foreground[:, :, :, :-1]
    boundary = F.l1_loss(pred_dy, true_dy) + F.l1_loss(pred_dx, true_dx)
    gate = balanced_gate_loss(outputs["gate_logit"], fixable, domain)
    proposed_true = (outputs["proposed"] * target_one_hot).sum(dim=1, keepdim=True).clamp_min(1e-7)
    proposal = masked_mean(-torch.log(proposed_true), fixable)

    cutout = batch["cutout"]
    depth_weight = cutout * (1.0 + 3.0 * batch["depth"])
    background_probability = probabilities[:, 0:1]
    cutout_loss = masked_mean(-torch.log(background_probability.clamp_min(1e-7)), depth_weight)
    banks = target_foreground * F.max_pool2d(cutout, 7, stride=1, padding=3)
    bank_loss = masked_mean(-torch.log(foreground.clamp_min(1e-7)), banks)
    consensus = (outputs["entropy"] < 0.08).float()
    baseline_correct = (baseline == target).float()[:, None]
    identity = masked_mean(-torch.log(true_probability), consensus * baseline_correct)
    sparsity = masked_mean(outputs["gate"], (disagreement <= 0).float())
    stress = batch["source"].float().view(-1, 1, 1, 1)
    stress_cutout = masked_mean(-torch.log(background_probability.clamp_min(1e-7)), depth_weight * stress)
    stress_bank = masked_mean(-torch.log(foreground.clamp_min(1e-7)), banks * stress)
    total = (
        segmentation + 0.75 * dice + 0.30 * boundary + 0.30 * gate + 0.18 * proposal
        + 0.10 * cutout_loss + 0.12 * bank_loss + 0.10 * identity + 0.04 * sparsity
        + 0.35 * stress_cutout + 0.45 * stress_bank
    )
    pieces = {
        "total": total, "segmentation": segmentation, "dice": dice, "boundary": boundary,
        "gate": gate, "proposal": proposal, "cutout": cutout_loss, "bank": bank_loss,
        "identity": identity, "sparsity": sparsity, "stress_cutout": stress_cutout,
        "stress_bank": stress_bank,
    }
    return total, {name: float(value.detach()) for name, value in pieces.items()}


@torch.no_grad()
def mean_loader_loss(model: PixelCandidateFusionNet, loader: DataLoader, device: torch.device) -> float:
    model.eval()
    values: list[float] = []
    for batch in loader:
        moved = {name: value.to(device, non_blocking=True) for name, value in batch.items()}
        outputs = model(moved["image"], moved["voltage"], moved["candidates"])
        loss, _ = compute_loss(outputs, moved)
        values.append(float(loss.detach()))
    return float(np.mean(values))


def train_model(
    train_splits: list[SplitArrays],
    validation_splits: list[SplitArrays],
    candidate_count: int,
    fov: np.ndarray,
    args: argparse.Namespace,
    output_dir: Path,
    device: torch.device,
) -> tuple[PixelCandidateFusionNet, list[dict[str, float]]]:
    training = FusionDataset(train_splits)
    sample_weights = np.concatenate([
        np.full(len(split.indices), args.stress_sampling_weight if split.source == "stress" else 1.0)
        for split in train_splits
    ])
    sampler = WeightedRandomSampler(
        sample_weights, num_samples=len(sample_weights), replacement=True,
        generator=torch.Generator().manual_seed(args.seed),
    )
    train_loader = DataLoader(
        training, batch_size=args.batch_size, sampler=sampler, num_workers=args.workers,
        pin_memory=device.type == "cuda", drop_last=False,
    )
    validation_loaders = [
        DataLoader(FusionDataset(split), batch_size=args.batch_size, shuffle=False, num_workers=args.workers)
        for split in validation_splits
    ]
    model = PixelCandidateFusionNet(candidate_count, args.base_channels, fov).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    checkpoint = output_dir / "pixel_fusion_best.pt"
    history: list[dict[str, float]] = []
    best_loss = math.inf
    stale = 0
    for epoch in range(1, args.epochs + 1):
        model.train()
        totals: list[float] = []
        for batch in train_loader:
            moved = {name: value.to(device, non_blocking=True) for name, value in batch.items()}
            optimizer.zero_grad(set_to_none=True)
            with torch.amp.autocast("cuda", enabled=device.type == "cuda"):
                outputs = model(moved["image"], moved["voltage"], moved["candidates"])
                loss, _ = compute_loss(outputs, moved)
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            scaler.step(optimizer)
            scaler.update()
            totals.append(float(loss.detach()))
        scheduler.step()
        validation_losses = [mean_loader_loss(model, loader, device) for loader in validation_loaders]
        validation_loss = 0.45 * validation_losses[0] + 0.55 * validation_losses[1]
        record = {
            "epoch": float(epoch), "train_loss": float(np.mean(totals)),
            "base_validation_loss": validation_losses[0], "stress_validation_loss": validation_losses[1],
            "validation_loss": validation_loss, "learning_rate": float(optimizer.param_groups[0]["lr"]),
        }
        history.append(record)
        if epoch == 1 or epoch % 3 == 0:
            print(
                f"epoch {epoch:03d}: train={record['train_loss']:.4f} "
                f"base_val={validation_losses[0]:.4f} stress_val={validation_losses[1]:.4f}", flush=True,
            )
        if validation_loss < best_loss - 2e-4:
            best_loss = validation_loss
            stale = 0
            torch.save({
                "model": model.state_dict(), "candidate_count": candidate_count,
                "base_channels": args.base_channels, "epoch": epoch, "validation_loss": validation_loss,
            }, checkpoint)
        else:
            stale += 1
            if stale >= args.patience:
                print(f"early stopping at epoch {epoch}", flush=True)
                break
    state = torch.load(checkpoint, map_location=device, weights_only=False)
    model.load_state_dict(state["model"])
    model.eval()
    (output_dir / "training_history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    return model, history


@torch.no_grad()
def infer_fields(
    model: PixelCandidateFusionNet,
    split: SplitArrays,
    device: torch.device,
    batch_size: int,
) -> tuple[np.ndarray, np.ndarray]:
    loader = DataLoader(FusionDataset(split), batch_size=batch_size, shuffle=False)
    proposed: list[np.ndarray] = []
    gates: list[np.ndarray] = []
    model.eval()
    for batch in loader:
        output = model(
            batch["image"].to(device), batch["voltage"].to(device), batch["candidates"].to(device)
        )
        proposed.append(output["proposed"].cpu().numpy().astype(np.float32))
        gates.append(output["gate"].cpu().numpy()[:, 0].astype(np.float32))
    return np.concatenate(proposed), np.concatenate(gates)


def apply_fields(
    baseline: np.ndarray,
    proposed: np.ndarray,
    gate: np.ndarray,
    alpha: float,
    gate_threshold: float,
) -> np.ndarray:
    baseline_one_hot = np.eye(3, dtype=np.float32)[baseline].transpose(0, 3, 1, 2)
    baseline_probability = baseline_one_hot * 0.98 + (1.0 - baseline_one_hot) * 0.01
    effective = gate * (gate >= gate_threshold)
    final = (1.0 - alpha * effective[:, None]) * baseline_probability + alpha * effective[:, None] * proposed
    return final.argmax(axis=1).astype(np.uint8)


def metric_for(split: SplitArrays, prediction: np.ndarray) -> dict[str, float]:
    if split.source == "stress":
        summary, _, _ = stress_metrics(split.truths, prediction, split.cutouts, split.depths, split.families)
        return summary
    return standard_metrics(split.truths, prediction, split.cutouts)


def calibrate_policy(
    base: SplitArrays,
    stress: SplitArrays,
    base_fields: tuple[np.ndarray, np.ndarray],
    stress_fields: tuple[np.ndarray, np.ndarray],
    args: argparse.Namespace,
) -> tuple[dict[str, object], list[dict[str, object]]]:
    base_reference = metric_for(base, base.candidates[0])
    stress_reference = metric_for(stress, stress.candidates[0])
    rows: list[dict[str, object]] = []
    for alpha in (0.0, 0.25, 0.50, 0.75, 1.0):
        for gate_threshold in (0.0, 0.25, 0.40, 0.50, 0.60, 0.70, 0.80):
            base_prediction = apply_fields(base.candidates[0], *base_fields, alpha, gate_threshold)
            stress_prediction = apply_fields(stress.candidates[0], *stress_fields, alpha, gate_threshold)
            base_metric = metric_for(base, base_prediction)
            stress_metric = metric_for(stress, stress_prediction)
            eligible = (
                base_metric["foreground_iou"] >= base_reference["foreground_iou"] - args.base_iou_tolerance
                and base_metric["boundary_f1"] >= base_reference["boundary_f1"] - args.base_boundary_tolerance
                and stress_metric["foreground_iou"] >= stress_reference["foreground_iou"] - args.stress_iou_tolerance
                and stress_metric["bank_retention"] >= stress_reference["bank_retention"] - args.stress_bank_tolerance
            )
            rows.append({
                "alpha": alpha, "gate_threshold": gate_threshold, "eligible": bool(eligible),
                "base_iou": base_metric["foreground_iou"], "base_boundary_f1": base_metric["boundary_f1"],
                "stress_iou": stress_metric["foreground_iou"],
                "stress_boundary_f1": stress_metric["boundary_f1"],
                "stress_open_deep": stress_metric["open_deep_cutout_recovery"],
                "stress_bank": stress_metric["bank_retention"],
                "stress_topology_joint": stress_metric["topology_structural_joint"],
                "base_changed_fraction": float(np.mean(np.any(base_prediction != base.candidates[0], axis=(1, 2)))),
                "stress_changed_fraction": float(np.mean(np.any(stress_prediction != stress.candidates[0], axis=(1, 2)))),
            })
    eligible_rows = [row for row in rows if row["eligible"]]
    identity = next(row for row in rows if row["alpha"] == 0.0 and row["gate_threshold"] == 0.0)
    selected = max(
        eligible_rows,
        key=lambda row: (
            float(row["stress_topology_joint"]), float(row["stress_open_deep"]),
            float(row["base_iou"]), -float(row["base_changed_fraction"]),
        ),
    ) if eligible_rows else identity
    return selected, rows


def foreground_iou_per_case(truths: np.ndarray, predictions: np.ndarray) -> np.ndarray:
    truth = truths != 0
    prediction = predictions != 0
    intersection = np.logical_and(truth, prediction).sum(axis=(1, 2))
    union = np.logical_or(truth, prediction).sum(axis=(1, 2))
    return intersection / np.maximum(union, 1)


def paired_bootstrap(
    truths: np.ndarray,
    baseline: np.ndarray,
    proposed: np.ndarray,
    repetitions: int,
    seed: int,
) -> dict[str, float]:
    difference = foreground_iou_per_case(truths, proposed) - foreground_iou_per_case(truths, baseline)
    rng = np.random.default_rng(seed)
    draws = difference[rng.integers(0, len(difference), size=(repetitions, len(difference)))].mean(axis=1)
    return {
        "mean_iou_difference": float(difference.mean()),
        "ci95_low": float(np.quantile(draws, 0.025)),
        "ci95_high": float(np.quantile(draws, 0.975)),
        "probability_positive": float(np.mean(draws > 0)),
    }


def casewise_oracle(split: SplitArrays) -> np.ndarray:
    scores = np.stack([foreground_iou_per_case(split.truths, candidate) for candidate in split.candidates], axis=1)
    selected = scores.argmax(axis=1)
    return split.candidates[selected, np.arange(len(selected))]


def evaluate_split(
    split: SplitArrays,
    prediction: np.ndarray,
    repetitions: int,
    seed: int,
) -> dict[str, object]:
    baseline = split.candidates[0]
    result: dict[str, object] = {
        "baseline": metric_for(split, baseline),
        "pixel_fusion": metric_for(split, prediction),
        "casewise_oracle": metric_for(split, casewise_oracle(split)),
        "bootstrap_iou": paired_bootstrap(split.truths, baseline, prediction, repetitions, seed),
    }
    differences = foreground_iou_per_case(split.truths, prediction) - foreground_iou_per_case(split.truths, baseline)
    result["changed_cases"] = int(np.count_nonzero(np.any(prediction != baseline, axis=(1, 2))))
    result["improved_cases"] = int(np.count_nonzero(differences > 1e-6))
    result["harmed_cases"] = int(np.count_nonzero(differences < -1e-6))
    result["material_improvements"] = int(np.count_nonzero(differences >= 0.01))
    result["material_harms"] = int(np.count_nonzero(differences <= -0.01))
    if split.source == "stress":
        families: dict[str, dict[str, object]] = {}
        for code, family in enumerate(FAMILIES):
            selected = split.families == code
            if not selected.any():
                continue
            before, _, _ = stress_metrics(
                split.truths[selected], baseline[selected], split.cutouts[selected],
                split.depths[selected], split.families[selected],
            )
            after, _, _ = stress_metrics(
                split.truths[selected], prediction[selected], split.cutouts[selected],
                split.depths[selected], split.families[selected],
            )
            families[family] = {"baseline": before, "pixel_fusion": after}
        result["by_family"] = families
    return result


def reliability_rows(
    split_name: str,
    truths: np.ndarray,
    baseline: np.ndarray,
    proposed: np.ndarray,
    gates: np.ndarray,
    bins: int = 10,
) -> tuple[list[dict[str, object]], dict[str, float]]:
    proposed_class = proposed.argmax(axis=1)
    change = proposed_class != baseline
    confidence = gates * proposed.max(axis=1)
    correct = proposed_class == truths
    rows: list[dict[str, object]] = []
    total = max(1, int(change.sum()))
    ece = 0.0
    for index in range(bins):
        low, high = index / bins, (index + 1) / bins
        selected = change & (confidence >= low) & (confidence < high if index + 1 < bins else confidence <= high)
        count = int(selected.sum())
        mean_confidence = float(confidence[selected].mean()) if count else float("nan")
        accuracy = float(correct[selected].mean()) if count else float("nan")
        if count:
            ece += count / total * abs(mean_confidence - accuracy)
        rows.append({
            "split": split_name, "bin_low": low, "bin_high": high, "pixels": count,
            "mean_confidence": mean_confidence, "correction_accuracy": accuracy,
        })
    summary = {
        "ece": float(ece), "proposed_change_pixels": int(change.sum()),
        "correction_accuracy": float(correct[change].mean()) if change.any() else float("nan"),
        "mean_confidence": float(confidence[change].mean()) if change.any() else float("nan"),
    }
    return rows, summary


def save_reliability_plot(path: Path, rows: list[dict[str, object]]) -> None:
    figure, axis = plt.subplots(figsize=(6.4, 5.4))
    for split in sorted({str(row["split"]) for row in rows}):
        selected = [row for row in rows if row["split"] == split and int(row["pixels"]) > 0]
        axis.plot(
            [float(row["mean_confidence"]) for row in selected],
            [float(row["correction_accuracy"]) for row in selected],
            marker="o", label=split,
        )
    axis.plot((0, 1), (0, 1), linestyle="--", color="black", linewidth=1, label="ideal")
    axis.set(xlim=(0, 1), ylim=(0, 1), xlabel="predicted correction confidence", ylabel="empirical correctness")
    axis.grid(alpha=0.25)
    axis.legend()
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def save_stress_family_montage(path: Path, split: SplitArrays, prediction: np.ndarray) -> None:
    baseline = split.candidates[0]
    oracle = casewise_oracle(split)
    differences = foreground_iou_per_case(split.truths, prediction) - foreground_iou_per_case(split.truths, baseline)
    indices = []
    for code in range(len(FAMILIES)):
        family_indices = np.flatnonzero(split.families == code)
        if len(family_indices):
            indices.append(int(family_indices[np.argmax(differences[family_indices])]))
    figure, axes = plt.subplots(len(indices), 6, figsize=(14.0, 2.25 * len(indices)), squeeze=False)
    for row, index in enumerate(indices):
        removed = ((baseline[index] != 0) & (prediction[index] == 0)).astype(np.uint8)
        images = (
            (split.truths[index], f"{FAMILIES[int(split.families[index])]} truth", 0, 2),
            (baseline[index], "baseline", 0, 2),
            (prediction[index], f"pixel fusion\nDelta IoU {differences[index]:+.3f}", 0, 2),
            (oracle[index], "casewise oracle", 0, 2),
            (removed, "removed foreground", 0, 1),
            (split.cutouts[index], "true inward region", 0, 1),
        )
        for column, (image, title, low, high) in enumerate(images):
            axes[row, column].imshow(image, cmap="viridis", vmin=low, vmax=high, interpolation="nearest")
            axes[row, column].set_title(title, fontsize=9)
            axes[row, column].set_axis_off()
    figure.suptitle("Independent nonlinear-CEM stress test: one best changed case per geometry family", y=0.995)
    figure.subplots_adjust(top=0.965, hspace=0.28, wspace=0.08)
    figure.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(figure)


def save_public_montage(
    path: Path,
    split: SplitArrays,
    prediction: np.ndarray,
    ids: np.ndarray,
    selected_indices: np.ndarray,
    title: str,
) -> None:
    baseline = split.candidates[0]
    oracle = casewise_oracle(split)
    differences = foreground_iou_per_case(split.truths, prediction) - foreground_iou_per_case(split.truths, baseline)
    figure, axes = plt.subplots(len(selected_indices), 5, figsize=(12.0, 2.25 * len(selected_indices)), squeeze=False)
    for row, index in enumerate(selected_indices):
        removed = ((baseline[index] != 0) & (prediction[index] == 0)).astype(np.uint8)
        images = (
            (split.truths[index], f"{ids[index]} truth", 0, 2),
            (baseline[index], "baseline", 0, 2),
            (prediction[index], f"pixel fusion\nDelta IoU {differences[index]:+.3f}", 0, 2),
            (oracle[index], "casewise oracle", 0, 2),
            (removed, "removed foreground", 0, 1),
        )
        for column, (image, subtitle, low, high) in enumerate(images):
            axes[row, column].imshow(image, cmap="viridis", vmin=low, vmax=high, interpolation="nearest")
            axes[row, column].set_title(subtitle, fontsize=9)
            axes[row, column].set_axis_off()
    figure.suptitle(title, y=0.995)
    figure.subplots_adjust(top=0.965, hspace=0.28, wspace=0.08)
    figure.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(figure)


def public_subgroup_metrics(
    name: str,
    split: SplitArrays,
    prediction: np.ndarray,
    ids: np.ndarray,
    selected: np.ndarray,
    repetitions: int,
    seed: int,
) -> dict[str, object]:
    baseline_summary, _ = evaluate_real_predictions(name + "_baseline", split.candidates[0][selected], split.truths[selected], ids[selected])
    proposed_summary, rows = evaluate_real_predictions(name, prediction[selected], split.truths[selected], ids[selected])
    return {
        "baseline": baseline_summary,
        "pixel_fusion": proposed_summary,
        "bootstrap_iou": paired_bootstrap(
            split.truths[selected], split.candidates[0][selected], prediction[selected], repetitions, seed,
        ),
        "rows": rows,
    }


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    base_archive = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress_archive = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    pool_dir = args.pool_dir.resolve()
    split_specs = (
        ("base_train", "base", base_archive),
        ("base_validation", "base", base_archive),
        ("base_test", "base", base_archive),
        ("stress_train", "stress", stress_archive),
        ("stress_validation", "stress", stress_archive),
        ("stress_test", "stress", stress_archive),
    )
    splits: dict[str, SplitArrays] = {}
    candidate_names: list[str] | None = None
    for name, source, archive in split_specs:
        names, split = prepare_split(name, source, archive, pool_dir)
        if candidate_names is None:
            candidate_names = names
        elif names != candidate_names:
            raise ValueError(f"candidate order differs in {name}")
        splits[name] = split
    assert candidate_names is not None
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"device={device}; candidates={len(candidate_names)}; seed={args.seed}", flush=True)
    model, history = train_model(
        [splits["base_train"], splits["stress_train"]],
        [splits["base_validation"], splits["stress_validation"]],
        len(candidate_names), np.asarray(base_archive["fov_mask"]), args, output_dir, device,
    )

    base_validation_fields = infer_fields(model, splits["base_validation"], device, args.batch_size)
    stress_validation_fields = infer_fields(model, splits["stress_validation"], device, args.batch_size)
    policy, calibration_rows = calibrate_policy(
        splits["base_validation"], splits["stress_validation"],
        base_validation_fields, stress_validation_fields, args,
    )
    write_csv(output_dir / "validation_calibration.csv", calibration_rows)
    print(f"selected validation policy: {policy}", flush=True)
    alpha = float(policy["alpha"])
    threshold = float(policy["gate_threshold"])

    results: dict[str, object] = {}
    stored: dict[str, np.ndarray] = {}
    reliability: list[dict[str, object]] = []
    reliability_summary: dict[str, dict[str, float]] = {}
    for offset, split_name in enumerate(("base_test", "stress_test")):
        split = splits[split_name]
        fields = infer_fields(model, split, device, args.batch_size)
        prediction = apply_fields(split.candidates[0], *fields, alpha, threshold)
        results[split_name] = evaluate_split(
            split, prediction, args.bootstrap_repetitions, args.seed + offset,
        )
        rows, summary = reliability_rows(split_name, split.truths, split.candidates[0], *fields)
        reliability.extend(rows)
        reliability_summary[split_name] = summary
        stored[f"{split_name}_prediction"] = prediction
        stored[f"{split_name}_gate"] = fields[1]
        if split_name == "stress_test":
            save_stress_family_montage(output_dir / "stress_family_pixel_fusion.png", split, prediction)

    public_names, public_indices, public_candidates = load_pool(pool_dir / "public_21.npz")
    if public_names != candidate_names:
        raise ValueError("candidate order differs in public pool")
    public_ids = np.asarray(base_archive["real_ids"])
    public_split = SplitArrays(
        name="public_21", source="base", indices=public_indices,
        images=np.asarray(base_archive["real_linear_images"], dtype=np.float32),
        voltages=np.asarray(base_archive["real_voltages"], dtype=np.float32),
        truths=np.asarray(base_archive["real_labels"], dtype=np.uint8),
        candidates=public_candidates,
        cutouts=np.zeros_like(base_archive["real_labels"], dtype=np.uint8),
        depths=np.zeros_like(base_archive["real_labels"], dtype=np.float32),
        families=np.full(len(public_indices), -1, dtype=np.int16),
    )
    public_fields = infer_fields(model, public_split, device, args.public_batch_size)
    public_prediction = apply_fields(public_candidates[0], *public_fields, alpha, threshold)
    strict = np.asarray([str(case_id) in STRICT_INWARD_IDS for case_id in public_ids])
    ordinary = ~strict
    public_all = public_subgroup_metrics(
        "pixel_fusion", public_split, public_prediction, public_ids, np.ones(len(public_ids), dtype=bool),
        args.bootstrap_repetitions, args.seed + 10,
    )
    public_strict = public_subgroup_metrics(
        "pixel_fusion_strict_inward", public_split, public_prediction, public_ids, strict,
        args.bootstrap_repetitions, args.seed + 11,
    )
    public_ordinary = public_subgroup_metrics(
        "pixel_fusion_ordinary", public_split, public_prediction, public_ids, ordinary,
        args.bootstrap_repetitions, args.seed + 12,
    )
    public_difference = foreground_iou_per_case(public_split.truths, public_prediction) - foreground_iou_per_case(
        public_split.truths, public_candidates[0]
    )
    results["public_21"] = {
        "all": {key: value for key, value in public_all.items() if key != "rows"},
        "strict_inward": {key: value for key, value in public_strict.items() if key != "rows"},
        "ordinary": {key: value for key, value in public_ordinary.items() if key != "rows"},
        "changed_cases": int(np.count_nonzero(np.any(public_prediction != public_candidates[0], axis=(1, 2)))),
        "improved_cases": int(np.count_nonzero(public_difference > 1e-6)),
        "harmed_cases": int(np.count_nonzero(public_difference < -1e-6)),
        "material_improvements": int(np.count_nonzero(public_difference >= 0.01)),
        "material_harms": int(np.count_nonzero(public_difference <= -0.01)),
    }
    write_csv(output_dir / "public_case_metrics.csv", public_all["rows"])
    rows, summary = reliability_rows(
        "public_21", public_split.truths, public_candidates[0], *public_fields,
    )
    reliability.extend(rows)
    reliability_summary["public_21"] = summary
    save_public_montage(
        output_dir / "public_strict_inward_pixel_fusion.png", public_split, public_prediction,
        public_ids, np.flatnonzero(strict), "Public KTC2023: strict inward-boundary cases",
    )
    changed = np.flatnonzero(np.any(public_prediction != public_candidates[0], axis=(1, 2)))
    if len(changed):
        ordering = changed[np.argsort(public_difference[changed])[::-1]]
        save_public_montage(
            output_dir / "public_changed_cases_pixel_fusion.png", public_split, public_prediction,
            public_ids, ordering, "Public KTC2023: every case changed by frozen validation policy",
        )
    write_csv(output_dir / "confidence_reliability.csv", reliability)
    save_reliability_plot(output_dir / "confidence_reliability.png", reliability)
    stored.update(
        public_prediction=public_prediction,
        public_gate=public_fields[1],
        public_proposed_probability=public_fields[0],
    )
    np.savez_compressed(output_dir / "predictions.npz", **stored)
    summary = {
        "method": "validation-calibrated pixelwise mixture of frozen cross-representation candidates",
        "candidate_names": candidate_names,
        "selected_policy": policy,
        "results": results,
        "confidence_reliability": reliability_summary,
        "evaluation_truth_used_for_training_or_selection": False,
        "selection_data": "synthetic base validation plus independent nonlinear-CEM stress validation only",
        "device": str(device),
        "seed": args.seed,
        "best_epoch": int(min(history, key=lambda row: row["validation_loss"])["epoch"]),
        "args": {
            key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()
        },
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
