"""Validation-selected, topology-safe local fusion of frozen EIT networks.

Vanilla reconstruction remains the protected base. Shape-aware changes are
accepted only where posterior evidence is strong, a proposed inward cut is
connected to exterior background, and foreground component/hole counts are
preserved. Public KTC evaluation truths are loaded only after selection.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from PIL import Image
from scipy import ndimage as ndi

import finalize_ktc_topology_selective as core
import train_ktc_concavity_network as net
from audit_ktc_instance_bay_topology import case_metrics as bay_metrics


STRUCTURE = np.ones((3, 3), dtype=np.uint8)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--checkpoint-dir", type=Path, default=root / "outputs" / "ktc_shape_network_v1")
    parser.add_argument("--output-dir", type=Path, default=Path(r"E:\Codex\ktc_topology_pixel_fusion_final_cpu"))
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--ood-samples", type=int, default=420)
    parser.add_argument("--bootstrap", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260821)
    return parser.parse_args()


def exterior_background(binary: np.ndarray) -> np.ndarray:
    labels, _ = ndi.label(binary, structure=STRUCTURE)
    border = np.unique(np.concatenate((labels[0], labels[-1], labels[:, 0], labels[:, -1])))
    border = border[border != 0]
    return np.isin(labels, border)


def topology(labels: np.ndarray) -> tuple[int, int]:
    foreground = labels != 0
    _, components = ndi.label(foreground, structure=STRUCTURE)
    holes = ndi.binary_fill_holes(foreground) & ~foreground
    _, hole_count = ndi.label(holes, structure=STRUCTURE)
    return int(components), int(hole_count)


def fuse_one(
    vanilla: np.ndarray,
    shape: np.ndarray,
    vanilla_probability: np.ndarray,
    shape_probability: np.ndarray,
    remove_threshold: float,
    remove_margin: float,
    vanilla_confidence_cap: float,
    max_remove_fraction: float,
    add_threshold: float,
    add_margin: float,
    dilation: int,
) -> np.ndarray:
    output = vanilla.copy()
    vanilla_fg = vanilla != 0
    shape_fg = shape != 0
    vanilla_class_probability = np.take_along_axis(
        vanilla_probability, vanilla[None].astype(np.int64), axis=0
    )[0]
    proposed_remove = (
        vanilla_fg & ~shape_fg
        & (shape_probability[0] >= remove_threshold)
        & ((shape_probability[0] - vanilla_probability[0]) >= remove_margin)
        & (vanilla_class_probability <= vanilla_confidence_cap)
    )
    traversable = ~vanilla_fg | proposed_remove
    connected = exterior_background(traversable)
    remove = proposed_remove & connected

    # Test coherent bays independently. One topologically invalid proposal must
    # not suppress another valid inward cut elsewhere on the same lesion.
    components, count = ndi.label(remove, structure=STRUCTURE)
    foreground_area = max(int(vanilla_fg.sum()), 1)
    candidates = []
    for component in range(1, count + 1):
        region = components == component
        area = int(region.sum())
        if area < 2:
            continue
        if area / foreground_area > max_remove_fraction:
            continue
        evidence = float(np.mean(
            shape_probability[0][region] - vanilla_class_probability[region]
        ))
        candidates.append((evidence, region))
    for _, region in sorted(candidates, key=lambda item: item[0], reverse=True):
        proposal = output.copy()
        proposal[region] = 0
        if topology(proposal) == topology(vanilla):
            output = proposal

    if math.isfinite(add_threshold):
        shape_class_probability = np.take_along_axis(
            shape_probability, shape[None].astype(np.int64), axis=0
        )[0]
        vanilla_same_probability = np.take_along_axis(
            vanilla_probability, shape[None].astype(np.int64), axis=0
        )[0]
        neighborhood = ndi.binary_dilation(vanilla_fg, structure=STRUCTURE, iterations=dilation)
        add = (
            ~vanilla_fg & shape_fg & neighborhood
            & (shape_class_probability >= add_threshold)
            & ((shape_class_probability - vanilla_same_probability) >= add_margin)
        )
        output[add] = shape[add]

    # A local bay should not create a hole, split a lesion, or merge lesions.
    if topology(output) != topology(vanilla):
        return vanilla.copy()
    return output


def fuse_batch(
    vanilla_outputs: dict[str, np.ndarray],
    shape_outputs: dict[str, np.ndarray],
    parameters: dict[str, float | int],
) -> np.ndarray:
    vanilla = core.hard_predictions(vanilla_outputs)
    shape = core.hard_predictions(shape_outputs)
    vp = core.probabilities(vanilla_outputs["logits"])
    sp = core.probabilities(shape_outputs["logits"])
    return np.stack([
        fuse_one(vanilla[i], shape[i], vp[i], sp[i], **parameters)
        for i in range(len(vanilla))
    ])


def fast_rows(truths: np.ndarray, predictions: np.ndarray, indentations: np.ndarray):
    return [
        net.confusion_metrics(truth, prediction, indentation.astype(bool))
        for truth, prediction, indentation in zip(truths, predictions, indentations)
    ]


def gains(
    baseline_rows: list[dict[str, float]],
    candidate_rows: list[dict[str, float]],
    mask: np.ndarray,
) -> tuple[float, float, float, int]:
    indices = np.flatnonzero(mask)
    if not len(indices):
        return 0.0, 0.0, 0.0, 0
    iou = np.asarray([candidate_rows[i]["foreground_iou"] - baseline_rows[i]["foreground_iou"] for i in indices])
    boundary = np.asarray([candidate_rows[i]["boundary_f1"] - baseline_rows[i]["boundary_f1"] for i in indices])
    notch = np.asarray([
        candidate_rows[i]["notch_preservation"] - baseline_rows[i]["notch_preservation"]
        if np.isfinite(candidate_rows[i]["notch_preservation"]) and np.isfinite(baseline_rows[i]["notch_preservation"])
        else 0.0 for i in indices
    ])
    return float(iou.mean()), float(boundary.mean()), float(notch.mean()), int(np.sum(iou < -0.01))


def select_policy(
    validation_truths: np.ndarray,
    validation_indent: np.ndarray,
    validation_concave: np.ndarray,
    validation_vout: dict[str, np.ndarray],
    validation_sout: dict[str, np.ndarray],
    calibration_truths: np.ndarray,
    calibration_indent: np.ndarray,
    calibration_vout: dict[str, np.ndarray],
    calibration_sout: dict[str, np.ndarray],
    development_truths: np.ndarray,
    development_indent: np.ndarray,
    development_concave: np.ndarray,
    development_vout: dict[str, np.ndarray],
    development_sout: dict[str, np.ndarray],
):
    val_vp = core.hard_predictions(validation_vout)
    cal_vp = core.hard_predictions(calibration_vout)
    val_base = fast_rows(validation_truths, val_vp, validation_indent)
    cal_base = fast_rows(calibration_truths, cal_vp, calibration_indent)
    dev_vp = core.hard_predictions(development_vout)
    dev_base = fast_rows(development_truths, dev_vp, development_indent)
    rows = []
    best = None
    for remove_threshold in (0.45, 0.60, 0.75, 0.88, 0.94):
        for remove_margin in (0.00, 0.10, 0.22, 0.35):
            for vanilla_confidence_cap in (0.40, 0.48, 0.56, 0.65, 0.75, 0.88):
                for max_remove_fraction in (0.01, 0.025, 0.05, 0.10):
                    add_threshold = float("inf")
                    add_margin = 0.10
                    parameters = {
                        "remove_threshold": remove_threshold,
                        "remove_margin": remove_margin,
                        "vanilla_confidence_cap": vanilla_confidence_cap,
                        "max_remove_fraction": max_remove_fraction,
                        "add_threshold": add_threshold,
                        "add_margin": add_margin,
                        "dilation": 2,
                    }
                    val_prediction = fuse_batch(validation_vout, validation_sout, parameters)
                    cal_prediction = fuse_batch(calibration_vout, calibration_sout, parameters)
                    dev_prediction = fuse_batch(development_vout, development_sout, parameters)
                    val_rows = fast_rows(validation_truths, val_prediction, validation_indent)
                    cal_rows = fast_rows(calibration_truths, cal_prediction, calibration_indent)
                    dev_rows = fast_rows(development_truths, dev_prediction, development_indent)
                    ci, cb, cn, ch = gains(val_base, val_rows, validation_concave)
                    oi, ob, on, oh = gains(val_base, val_rows, ~validation_concave)
                    cai, cab, can, cah = gains(cal_base, cal_rows, np.ones(len(cal_rows), dtype=bool))
                    di, db, dn, dh = gains(dev_base, dev_rows, development_concave)
                    doi, dob, don, doh = gains(dev_base, dev_rows, ~development_concave)
                    changed = int(np.sum(np.any(val_prediction != val_vp, axis=(1, 2))))
                    calibration_changed = int(np.sum(np.any(cal_prediction != cal_vp, axis=(1, 2))))
                    development_changed = int(np.sum(np.any(dev_prediction != dev_vp, axis=(1, 2))))
                    development_ordinary_cases = max(int((~development_concave).sum()), 1)
                    eligible = bool(
                        oi >= -0.0005 and ob >= -0.0015 and oh == 0
                        and cai >= -0.001 and cab >= -0.002 and cah == 0
                        and ci >= -0.002 and cb >= -0.003 and cn >= 0.0
                        and di >= -0.001 and db >= -0.002 and dn >= 0.004
                        and doi >= -0.0002 and dob >= -0.001
                        and doh / development_ordinary_cases <= 0.05
                    )
                    objective = (
                        0.25 * ci + 0.10 * cb + 0.20 * cn
                        + 0.20 * di + 0.10 * db + 0.20 * dn
                        + 0.08 * oi + 0.05 * doi + 0.02 * cai
                    )
                    row = {
                        **parameters, "eligible": eligible, "objective": float(objective),
                        "validation_changed": changed, "calibration_changed": calibration_changed,
                        "concave_iou_gain": ci, "concave_boundary_gain": cb, "concave_notch_gain": cn,
                        "ordinary_iou_gain": oi, "ordinary_boundary_gain": ob, "ordinary_harmed": oh,
                        "calibration_iou_gain": cai, "calibration_boundary_gain": cab,
                        "calibration_harmed": cah,
                        "development_changed": development_changed,
                        "development_concave_iou_gain": di,
                        "development_concave_boundary_gain": db,
                        "development_concave_notch_gain": dn,
                        "development_ordinary_iou_gain": doi,
                        "development_ordinary_boundary_gain": dob,
                        "development_ordinary_harmed": doh,
                    }
                    rows.append(row)
                    if eligible and changed > 0 and (best is None or objective > best["objective"]):
                        best = row
    if best is None:
        best = {
            "remove_threshold": 2.0, "remove_margin": 2.0,
            "vanilla_confidence_cap": 0.0, "max_remove_fraction": 0.0,
            "add_threshold": float("inf"), "add_margin": 2.0, "dilation": 2,
            "eligible": True, "objective": 0.0, "validation_changed": 0,
            "calibration_changed": 0, "fallback_identity": True,
        }
    parameters = {key: best[key] for key in (
        "remove_threshold", "remove_margin", "vanilla_confidence_cap",
        "max_remove_fraction", "add_threshold", "add_margin", "dilation"
    )}
    return parameters, best, rows


def write_csv(path: Path, rows: list[dict]) -> None:
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def evaluate(truths, vanilla, shape, final, group):
    predictions = {"vanilla": vanilla, "shape": shape, "topology_fusion": final}
    summary = {}
    rows_by_method = {}
    for method, values in predictions.items():
        rows = core.per_case_metrics(truths, values)
        rows_by_method[method] = rows
        summary[method] = {
            "all": core.aggregate(rows),
            "concave": core.aggregate(rows, group),
            "ordinary": core.aggregate(rows, ~group),
        }
    base, end = rows_by_method["vanilla"], rows_by_method["topology_fusion"]
    summary["ordinary_harmed_iou_gt_0.01"] = int(sum(
        end[i]["foreground_iou"] < base[i]["foreground_iou"] - 0.01
        for i in np.flatnonzero(~group)
    ))
    return summary, rows_by_method


def plot_cases(path, ids, truths, images, vanilla, shape, final, selected):
    figure, axes = plt.subplots(len(selected), 6, figsize=(14.5, 2.35 * len(selected)), squeeze=False)
    for row_index, index in enumerate(selected):
        scale = max(float(np.quantile(np.abs(images[index]), 0.99)), 1e-6)
        panels = (truths[index], images[index], vanilla[index], shape[index], final[index])
        titles = ("Truth", "Linear EIT", "Vanilla", "Shape-aware", "Topology fusion")
        for column, (panel, title) in enumerate(zip(panels, titles)):
            if column == 1:
                axes[row_index, column].imshow(panel, cmap="coolwarm", vmin=-scale, vmax=scale)
            else:
                axes[row_index, column].imshow(panel, cmap="viridis", vmin=0, vmax=2)
            if row_index == 0:
                axes[row_index, column].set_title(title, fontsize=10)
            axes[row_index, column].set_axis_off()
        edit = np.zeros((*truths[index].shape, 3), dtype=float)
        edit[vanilla[index] == final[index]] = (0.08, 0.08, 0.08)
        edit[(vanilla[index] != 0) & (final[index] == 0)] = (0.95, 0.20, 0.65)
        edit[(vanilla[index] == 0) & (final[index] != 0)] = (0.10, 0.85, 0.25)
        axes[row_index, 5].imshow(edit)
        axes[row_index, 5].set_axis_off()
        if row_index == 0:
            axes[row_index, 5].set_title("Accepted edits", fontsize=10)
        base = net.confusion_metrics(truths[index], vanilla[index], net.indentation_mask(truths[index]))
        end = net.confusion_metrics(truths[index], final[index], net.indentation_mask(truths[index]))
        axes[row_index, 0].set_ylabel(
            f"{ids[index]}\nIoU {base['foreground_iou']:.3f}->{end['foreground_iou']:.3f}\n"
            f"notch {base['notch_preservation']:.2f}->{end['notch_preservation']:.2f}", fontsize=8
        )
    figure.suptitle("Topology-safe local fusion for inward-boundary EIT", fontsize=14)
    figure.tight_layout()
    figure.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    args = parse_args()
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    archive = np.load(args.dataset.resolve(), allow_pickle=False)
    device = torch.device("cpu")
    adapter = net.InputAdapter(archive["fov_mask"]).to(device)
    vanilla_model = net.ConcavityUNet(32, False).to(device)
    shape_model = net.ConcavityUNet(32, True).to(device)
    vanilla_model.load_state_dict(torch.load(args.checkpoint_dir / "vanilla_best.pt", map_location=device, weights_only=False)["model"])
    shape_model.load_state_dict(torch.load(args.checkpoint_dir / "shape_best.pt", map_location=device, weights_only=False)["model"])

    validation = archive["validation_indices"]
    print("inference validation and official calibration", flush=True)
    val_vout = core.infer(vanilla_model, adapter, archive["linear_images"][validation], device, args.batch_size)
    val_sout = core.infer(shape_model, adapter, archive["linear_images"][validation], device, args.batch_size)
    cal_vout = core.infer(vanilla_model, adapter, archive["calibration_linear_images"], device, args.batch_size)
    cal_sout = core.infer(shape_model, adapter, archive["calibration_linear_images"], device, args.batch_size)
    val_concave = core.materially_concave(
        archive["labels"][validation], archive["indentation_masks"][validation]
    )
    print("generate and infer independent cell-like development set", flush=True)
    dev_truths, _, dev_indent, dev_group, _, dev_images = core.generate_biological_ood(
        archive, args.ood_samples, args.seed + 51
    )
    dev_vout = core.infer(vanilla_model, adapter, dev_images, device, args.batch_size)
    dev_sout = core.infer(shape_model, adapter, dev_images, device, args.batch_size)
    parameters, policy, grid = select_policy(
        archive["labels"][validation], archive["indentation_masks"][validation], val_concave,
        val_vout, val_sout, archive["calibration_labels"], archive["calibration_indentation_masks"],
        cal_vout, cal_sout, dev_truths, dev_indent, dev_group, dev_vout, dev_sout,
    )
    write_csv(output / "validation_policy_grid.csv", grid)
    print(f"frozen pixel policy: {policy}", flush=True)

    test = archive["test_indices"]
    print("inference untouched synthetic test", flush=True)
    test_vout = core.infer(vanilla_model, adapter, archive["linear_images"][test], device, args.batch_size)
    test_sout = core.infer(shape_model, adapter, archive["linear_images"][test], device, args.batch_size)
    test_vp, test_sp = core.hard_predictions(test_vout), core.hard_predictions(test_sout)
    test_final = fuse_batch(test_vout, test_sout, parameters)
    test_group = core.materially_concave(archive["labels"][test], archive["indentation_masks"][test])
    test_summary, test_rows = evaluate(archive["labels"][test], test_vp, test_sp, test_final, test_group)

    print("generate and infer smooth cell-like OOD", flush=True)
    ood_truths, _, ood_indent, ood_group, ood_voltage, ood_images = core.generate_biological_ood(
        archive, args.ood_samples, args.seed + 1001
    )
    ood_vout = core.infer(vanilla_model, adapter, ood_images, device, args.batch_size)
    ood_sout = core.infer(shape_model, adapter, ood_images, device, args.batch_size)
    ood_vp, ood_sp = core.hard_predictions(ood_vout), core.hard_predictions(ood_sout)
    ood_final = fuse_batch(ood_vout, ood_sout, parameters)
    ood_summary, ood_rows = evaluate(ood_truths, ood_vp, ood_sp, ood_final, ood_group)

    print("infer untouched KTC evaluation", flush=True)
    real_vout = core.infer(vanilla_model, adapter, archive["real_linear_images"], device, args.batch_size)
    real_sout = core.infer(shape_model, adapter, archive["real_linear_images"], device, args.batch_size)
    real_vp = core.resize_predictions(core.hard_predictions(real_vout))
    real_sp = core.resize_predictions(core.hard_predictions(real_sout))
    real_final = core.resize_predictions(fuse_batch(real_vout, real_sout, parameters))
    real_ids = np.asarray(archive["real_ids"])
    strict = np.asarray([str(value) in core.STRICT_IDS for value in real_ids])
    real_summary, real_rows = evaluate(archive["real_labels"], real_vp, real_sp, real_final, strict)

    case_rows = []
    for index, case_id in enumerate(real_ids):
        for method in ("vanilla", "shape", "topology_fusion"):
            prediction = {"vanilla": real_vp, "shape": real_sp, "topology_fusion": real_final}[method][index]
            case_rows.append({
                "id": str(case_id), "method": method, "strict_inward": bool(strict[index]),
                **real_rows[method][index],
                **{f"bay_{key}": value for key, value in bay_metrics(archive["real_labels"][index], prediction).items()},
            })
    write_csv(output / "real_case_metrics.csv", case_rows)
    real_bootstrap = {
        "strict": core.bootstrap(real_rows["vanilla"], real_rows["topology_fusion"], strict, args.bootstrap, args.seed + 1),
        "ordinary": core.bootstrap(real_rows["vanilla"], real_rows["topology_fusion"], ~strict, args.bootstrap, args.seed + 2),
    }
    ood_bootstrap = {
        "concave": core.bootstrap(ood_rows["vanilla"], ood_rows["topology_fusion"], ood_group, args.bootstrap, args.seed + 3),
        "ordinary": core.bootstrap(ood_rows["vanilla"], ood_rows["topology_fusion"], ~ood_group, args.bootstrap, args.seed + 4),
    }
    strict_indices = np.flatnonzero(strict)
    plot_cases(
        output / "ktc_strict_inward_comparison.png", real_ids, archive["real_labels"],
        archive["real_linear_images"], real_vp, real_sp, real_final, strict_indices,
    )
    ood_indices = np.r_[np.flatnonzero(ood_group)[:8], np.flatnonzero(~ood_group)[:4]]
    plot_cases(
        output / "biological_ood_comparison.png", np.asarray([f"OOD-{i}" for i in range(len(ood_truths))]),
        ood_truths, ood_images, ood_vp, ood_sp, ood_final, ood_indices,
    )
    np.savez_compressed(
        output / "predictions.npz", real_ids=real_ids, real_truths=archive["real_labels"],
        real_vanilla=real_vp, real_shape=real_sp, real_final=real_final,
        ood_truths=ood_truths, ood_vanilla=ood_vp, ood_shape=ood_sp, ood_final=ood_final,
        ood_concave=ood_group,
    )
    result = {
        "method": "validation-selected topology-safe local fusion",
        "selection": {
            "synthetic_validation_truth_used": True,
            "official_training_truth_used_as_safety_calibration": True,
            "independent_cell_like_development_truth_used": True,
            "ktc_evaluation_truth_used": False,
            "parameters": parameters,
            "policy": policy,
        },
        "synthetic_test": test_summary,
        "biological_ood": ood_summary,
        "biological_ood_bootstrap": ood_bootstrap,
        "ktc_public": real_summary,
        "ktc_public_bootstrap": real_bootstrap,
    }
    (output / "summary.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
