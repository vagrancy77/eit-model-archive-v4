"""Audit the truth-blind expanded pure-bay representation on public KTC2023.

Public labels are opened only after the deterministic candidate bank is frozen.
This is a representation upper-bound audit, not a deployable selector result.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy import ndimage as ndi

from audit_ktc_instance_bay_candidates import (
    STRICT_INWARD_IDS,
    foreground_iou,
    generate_expanded_pure_candidates,
)
from audit_ktc_instance_bay_topology import boundary_f1, case_metrics, edit_metrics


STRUCTURE = np.ones((3, 3), dtype=np.uint8)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument(
        "--pool", type=Path,
        default=root / "outputs" / "ktc_cross_representation_pool_seed20260820" / "public_21.npz",
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=Path(r"E:\Codex\ktc_expanded_pure_bay_coverage_seed20260820"),
    )
    parser.add_argument("--angles", type=int, default=16)
    parser.add_argument("--max-components", type=int, default=3)
    parser.add_argument("--min-component-fraction", type=float, default=0.0015)
    return parser.parse_args()


def signature(labels: np.ndarray) -> tuple[int, int, int]:
    return tuple(int(ndi.label(mask, structure=STRUCTURE)[1]) for mask in (labels != 0, labels == 1, labels == 2))


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    args = parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    data = np.load(args.dataset.resolve(), allow_pickle=False)
    pool = np.load(args.pool.resolve(), allow_pickle=False)
    names = [str(value) for value in pool["candidate_names"]]
    baselines = np.asarray(pool["candidates"][names.index("fusion_primary")], dtype=np.uint8)
    truths = np.asarray(data["real_labels"], dtype=np.uint8)
    ids = np.asarray(data["real_ids"])
    rows: list[dict[str, object]] = []
    panels: list[tuple[str, np.ndarray, np.ndarray, np.ndarray]] = []

    for index, case_id_value in enumerate(ids):
        case_id = str(case_id_value)
        truth, baseline = truths[index], baselines[index]
        candidates, metadata = generate_expanded_pure_candidates(
            baseline, args.angles, args.max_components, args.min_component_fraction
        )
        base_signature = signature(baseline)
        topology = np.asarray([signature(candidate) == base_signature for candidate in candidates])
        ious = np.asarray([foreground_iou(truth, candidate) for candidate in candidates])
        base_iou = float(ious[0])
        plausible = np.flatnonzero(topology & (ious >= base_iou - 1e-12))
        scored: list[tuple[tuple[float, ...], int, dict[str, float], float]] = []
        base_geometry = case_metrics(truth, baseline)
        base_boundary = boundary_f1(truth, baseline)
        for candidate_index in plausible:
            geometry = case_metrics(truth, candidates[candidate_index])
            boundary = boundary_f1(truth, candidates[candidate_index])
            bay_delta = float(geometry["bay_f1"] - base_geometry["bay_f1"])
            depth_delta = float(geometry["bay_depth_score"] - base_geometry["bay_depth_score"])
            finite = np.isfinite(bay_delta) and np.isfinite(depth_delta)
            joint = finite and bay_delta > 0.0 and depth_delta >= -0.02
            key = (
                float(joint),
                float(ious[candidate_index] - base_iou),
                bay_delta if np.isfinite(bay_delta) else -1e6,
                float(boundary - base_boundary),
                depth_delta if np.isfinite(depth_delta) else -1e6,
            )
            scored.append((key, int(candidate_index), geometry, boundary))
        _, choice, final_geometry, final_boundary = max(scored, key=lambda item: item[0])
        prediction = candidates[choice]
        edits = edit_metrics(truth, baseline, prediction)
        row: dict[str, object] = {
            "id": case_id,
            "strict_inward": case_id in STRICT_INWARD_IDS,
            "candidate_count": len(candidates),
            "topology_preserved_count": int(topology.sum()),
            "choice": choice,
            "profile": str(metadata[choice].get("profile", "identity")),
            "baseline_iou": base_iou,
            "final_iou": float(ious[choice]),
            "delta_iou": float(ious[choice] - base_iou),
            "baseline_boundary_f1": base_boundary,
            "final_boundary_f1": float(final_boundary),
            "delta_boundary_f1": float(final_boundary - base_boundary),
            **edits,
        }
        for metric in ("bay_f1", "bay_precision", "bay_depth_score", "bay_direction_score"):
            row[f"baseline_{metric}"] = float(base_geometry[metric])
            row[f"final_{metric}"] = float(final_geometry[metric])
            row[f"delta_{metric}"] = float(final_geometry[metric] - base_geometry[metric])
        rows.append(row)
        if case_id in STRICT_INWARD_IDS:
            panels.append((case_id, truth, baseline, prediction))
        print(
            f"{index + 1:02d}/{len(ids)} {case_id}: candidates={len(candidates)}, "
            f"choice={choice}, IoU {base_iou:.4f}->{ious[choice]:.4f}, "
            f"bayF1 delta={row['delta_bay_f1']:+.4f}", flush=True,
        )

    write_csv(output / "case_metrics.csv", rows)
    strict_rows = [row for row in rows if bool(row["strict_inward"])]
    ordinary_rows = [row for row in rows if not bool(row["strict_inward"])]
    summary = {
        "status": "truth-blind candidate-family upper-bound audit",
        "public_truth_used_for_candidate_generation": False,
        "public_truth_used_for_oracle_selection": True,
        "candidate_constraints": {
            "pure_removal": True,
            "exterior_connected": True,
            "no_new_holes": True,
            "component_signature_preserved_for_oracle": True,
        },
        "strict": {
            "cases": len(strict_rows),
            "joint_improved": sum(float(row["delta_iou"]) > 0 and float(row["delta_bay_f1"]) > 0 for row in strict_rows),
            "mean_delta_iou": float(np.mean([float(row["delta_iou"]) for row in strict_rows])),
            "mean_delta_bay_f1": float(np.nanmean([float(row["delta_bay_f1"]) for row in strict_rows])),
        },
        "ordinary": {
            "cases": len(ordinary_rows),
            "identity_available": True,
        },
        "args": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
    }
    (output / "summary.json").write_text(json.dumps(summary, indent=2, allow_nan=True), encoding="utf-8")

    figure, axes = plt.subplots(len(panels), 4, figsize=(12, 3 * len(panels)), squeeze=False)
    for row_axes, (case_id, truth, baseline, prediction) in zip(axes, panels):
        removed = (baseline != 0) & (prediction == 0)
        for axis, image, title, cmap in (
            (row_axes[0], truth, f"{case_id} truth", "viridis"),
            (row_axes[1], baseline, "baseline", "viridis"),
            (row_axes[2], prediction, "expanded pure-bay oracle", "viridis"),
            (row_axes[3], removed, "removed pixels", "magma"),
        ):
            axis.imshow(image, cmap=cmap, interpolation="nearest")
            axis.set_title(title)
            axis.axis("off")
    figure.suptitle("Expanded pure exterior-bay representation audit", fontsize=14)
    figure.tight_layout()
    figure.savefig(output / "strict_expanded_pure_bay_oracle.png", dpi=180, bbox_inches="tight")
    plt.close(figure)
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
