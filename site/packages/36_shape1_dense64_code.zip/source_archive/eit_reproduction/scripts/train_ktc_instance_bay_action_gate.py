"""Calibrate a physical action gate over the nested instance-bay ranker.

This second stage keeps the first-stage ridge configuration frozen per outer
KTC level.  Inner complete-level OOF predictions select an action policy.  A
compensated bay must add supported lesion tissue while carving an
exterior-connected indentation at a resolvable spatial scale.  Public labels
from the outer level and the strict-inward subgroup IDs are never used by the
gate.
"""
from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np

from train_ktc_instance_bay_nested_ranker import (
    CaseData,
    Policy,
    STRICT_INWARD_IDS,
    boundary_f1_per_case,
    fit_ridge,
    foreground_iou_per_case,
    inner_ensemble_predictions,
    load_cases,
    paired_bootstrap,
    predict_ensemble,
    save_montage,
    summarize_group,
    topology_checks,
    write_csv,
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz"
    )
    parser.add_argument(
        "--cache-dir", type=Path,
        default=root / "outputs" / "ktc_instance_bay_candidate_cache_seed20260820",
    )
    parser.add_argument(
        "--stage-one-dir", type=Path,
        default=root / "outputs" / "ktc_instance_bay_nested_ranker_seed20260820",
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=root / "outputs" / "ktc_instance_bay_action_gate_v3_seed20260820",
    )
    parser.add_argument(
        "--allow-unrestricted-ablation", action="store_true",
        help="Include non-physical actions. This reproduces the failed V1 ablation only.",
    )
    parser.add_argument(
        "--relaxed-physical-ablation", action="store_true",
        help="Allow sub-resolution edits and predicted gains below 0.01 (failed V2 ablation).",
    )
    parser.add_argument(
        "--pure-bay", action="store_true",
        help="Permit only exterior-connected removals with zero compensating expansion.",
    )
    parser.add_argument("--bootstrap-repetitions", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260820)
    return parser.parse_args()


@dataclass(frozen=True)
class ActionGate:
    name: str
    compensated_bay: bool
    min_local_change: float
    min_added_polarity: float
    pure_bay: bool = False


ABLATION_ACTION_GATES = (
    ActionGate("unrestricted", False, 0.0, -2.0),
    ActionGate("compensated_bay", True, 0.0, -2.0),
)


STRICT_PHYSICAL_ACTION_GATES = (
    *tuple(
        ActionGate(
            f"compensated_bay_scale_{local_change:.3f}_polarity_{polarity:.2f}",
            True, local_change, polarity,
        )
        for local_change in (0.015, 0.020, 0.025)
        for polarity in (0.50, 0.60, 0.70)
    ),
)


PURE_BAY_ACTION_GATES = tuple(
    ActionGate(
        f"pure_bay_scale_{local_change:.3f}",
        False, local_change, -2.0, True,
    )
    for local_change in (0.015, 0.020, 0.025)
)


RELAXED_PHYSICAL_ACTION_GATES = (
    *tuple(
        ActionGate(
            f"compensated_bay_scale_{local_change:.3f}_polarity_{polarity:.2f}",
            True, local_change, polarity,
        )
        for local_change in (0.005, 0.010, 0.015, 0.020, 0.025)
        for polarity in (0.50, 0.60, 0.70)
    ),
)


STRICT_CORE_POLICIES = tuple(
    Policy(threshold, uncertainty, agreement, max_change, max_removal)
    for threshold in (0.010, 0.020, 0.040, 1.0)
    for uncertainty in (0.0, 0.5, 1.0)
    for agreement in (0.50, 0.67, 0.84, 1.0)
    for max_change in (0.36, 0.62)
    for max_removal in (0.18, 0.36, 0.62)
)


RELAXED_CORE_POLICIES = tuple(
    Policy(threshold, uncertainty, agreement, max_change, max_removal)
    for threshold in (0.0025, 0.005, 0.010, 0.020, 0.040, 1.0)
    for uncertainty in (0.0, 0.5, 1.0)
    for agreement in (0.50, 0.67, 0.84, 1.0)
    for max_change in (0.36, 0.62)
    for max_removal in (0.18, 0.36, 0.62)
)


def choose_with_action_gate(
    case: CaseData,
    mean: np.ndarray,
    std: np.ndarray,
    agreement: np.ndarray,
    policy: Policy,
    action_gate: ActionGate,
) -> tuple[int, float]:
    lower = mean - policy.uncertainty_multiplier * std
    valid = (
        (case.change <= policy.max_change)
        & (case.removed <= policy.max_removal)
        & (case.new_holes == 0)
        & (case.open_fraction >= 0.995)
        & (agreement >= policy.minimum_model_agreement)
    )
    if action_gate.compensated_bay:
        valid &= case.kind == 2
        valid &= case.removed >= 0.005
        valid &= case.added >= 0.005
        valid &= case.local_change >= action_gate.min_local_change
        valid &= case.added_polarity_evidence >= action_gate.min_added_polarity
    if action_gate.pure_bay:
        valid &= case.kind == 2
        valid &= case.removed >= 0.005
        valid &= case.added <= 1e-8
        valid &= case.local_change >= action_gate.min_local_change
    valid[0] = True
    score = np.where(valid, lower, -np.inf)
    choice = int(np.argmax(score))
    gain = float(score[choice])
    if choice == 0 or gain < policy.threshold:
        return 0, gain
    return choice, gain


def evaluate_policy(
    cases: list[CaseData],
    predictions: dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]],
    policy: Policy,
    action_gate: ActionGate,
) -> dict[str, object]:
    choices = np.zeros(len(cases), dtype=np.int64)
    for index, case in enumerate(cases):
        choices[index], _ = choose_with_action_gate(
            case, *predictions[case.case_id], policy, action_gate
        )
    delta = np.asarray([case.targets[choice] for case, choice in zip(cases, choices)])
    changed = choices != 0
    return {
        "choices": choices,
        "mean_delta": float(delta.mean()),
        "minimum_delta": float(delta.min()),
        "harmed": int(np.count_nonzero(delta < -1e-9)),
        "improved": int(np.count_nonzero(delta > 1e-9)),
        "material_improved": int(np.count_nonzero(delta >= 0.01)),
        "changed": int(changed.sum()),
        "mean_changed_delta": float(delta[changed].mean()) if changed.any() else 0.0,
    }


def select_action_policy(
    cases: list[CaseData],
    predictions: dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]],
    action_gates: tuple[ActionGate, ...],
    core_policies: tuple[Policy, ...],
) -> tuple[Policy, ActionGate, list[dict[str, object]]]:
    rows: list[dict[str, object]] = []
    best: tuple[tuple[float, ...], Policy, ActionGate] | None = None
    for action_gate in action_gates:
        for policy in core_policies:
            result = evaluate_policy(cases, predictions, policy, action_gate)
            # Zero harmed complete cases is a hard, subgroup-agnostic gate.
            eligible = int(result["harmed"]) == 0
            row = {
                **asdict(action_gate), **asdict(policy),
                **{key: value for key, value in result.items() if key != "choices"},
                "eligible": eligible,
            }
            rows.append(row)
            key = (
                1.0 if eligible else 0.0,
                float(result["mean_delta"]),
                float(result["material_improved"]),
                float(result["improved"]),
                float(result["mean_changed_delta"]),
                -float(result["changed"]),
            )
            if best is None or key > best[0]:
                best = (key, policy, action_gate)
    assert best is not None
    return best[1], best[2], rows


def fit_outer_ensemble(
    training_cases: list[CaseData],
    parameters: dict[str, float],
) -> list[object]:
    levels = sorted({case.level for case in training_cases})
    models = [
        fit_ridge(
            [case for case in training_cases if case.level != omitted],
            parameters["regularization"], parameters["positive_weight"],
            parameters["kind_balance"],
        )
        for omitted in levels
    ]
    models.append(fit_ridge(
        training_cases, parameters["regularization"],
        parameters["positive_weight"], parameters["kind_balance"],
    ))
    return models


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    cases, truths, ids = load_cases(args.dataset, args.cache_dir)
    stage_one_policies = json.loads(
        (args.stage_one_dir.resolve() / "fold_policies.json").read_text(encoding="utf-8")
    )
    stage_one_by_level = {str(row["outer_level"]): row for row in stage_one_policies}
    action_gates = STRICT_PHYSICAL_ACTION_GATES
    core_policies = STRICT_CORE_POLICIES
    if args.relaxed_physical_ablation:
        action_gates = RELAXED_PHYSICAL_ACTION_GATES
        core_policies = RELAXED_CORE_POLICIES
    if args.allow_unrestricted_ablation:
        action_gates = ABLATION_ACTION_GATES + action_gates
    if args.pure_bay:
        action_gates = PURE_BAY_ACTION_GATES
    predictions = np.stack([case.candidates[0] for case in cases])
    choices = np.zeros(len(cases), dtype=np.int64)
    confidence = np.zeros(len(cases), dtype=np.float64)
    selected_records: list[dict[str, object]] = []
    calibration_rows: list[dict[str, object]] = []
    for fold, outer_level in enumerate(sorted(stage_one_by_level)):
        source = stage_one_by_level[outer_level]
        parameters = {
            "regularization": float(source["regularization"]),
            "positive_weight": float(source["positive_weight"]),
            "kind_balance": float(source["kind_balance"]),
        }
        training_cases = [case for case in cases if case.level != outer_level]
        inner_predictions = inner_ensemble_predictions(training_cases, **parameters)
        policy, action_gate, calibration = select_action_policy(
            training_cases, inner_predictions, action_gates, core_policies
        )
        for row in calibration:
            calibration_rows.append({"outer_level": outer_level, **row})
        selected_inner = evaluate_policy(training_cases, inner_predictions, policy, action_gate)
        models = fit_outer_ensemble(training_cases, parameters)
        outer_choices: list[int] = []
        for index, case in enumerate(cases):
            if case.level != outer_level:
                continue
            evidence = predict_ensemble(models, case)
            choice, lower = choose_with_action_gate(case, *evidence, policy, action_gate)
            predictions[index] = case.candidates[choice]
            choices[index] = choice
            confidence[index] = lower
            outer_choices.append(choice)
        record = {
            "outer_level": outer_level,
            **parameters,
            **asdict(action_gate),
            **asdict(policy),
            **{f"inner_oof_{key}": value for key, value in selected_inner.items() if key != "choices"},
            "outer_choices": outer_choices,
        }
        selected_records.append(record)
        print(f"fold {fold + 1}/7: {record}", flush=True)

    baselines = np.stack([case.candidates[0] for case in cases])
    oracles = np.stack([case.candidates[int(np.argmax(case.targets))] for case in cases])
    before = foreground_iou_per_case(truths, baselines)
    after = foreground_iou_per_case(truths, predictions)
    oracle_iou = foreground_iou_per_case(truths, oracles)
    boundary_before = boundary_f1_per_case(truths, baselines)
    boundary_after = boundary_f1_per_case(truths, predictions)
    rows: list[dict[str, object]] = []
    for index, case in enumerate(cases):
        rows.append({
            "id": case.case_id,
            "strict_inward": case.case_id in STRICT_INWARD_IDS,
            "choice": int(choices[index]),
            "confidence_lower_score": float(confidence[index]),
            "baseline_iou": float(before[index]),
            "final_iou": float(after[index]),
            "delta_iou": float(after[index] - before[index]),
            "oracle_iou": float(oracle_iou[index]),
            "baseline_boundary_f1": float(boundary_before[index]),
            "final_boundary_f1": float(boundary_after[index]),
            "delta_boundary_f1": float(boundary_after[index] - boundary_before[index]),
            **topology_checks(baselines[index], predictions[index]),
        })
    strict = np.asarray([case.case_id in STRICT_INWARD_IDS for case in cases])
    groups = {
        "all": summarize_group(
            "all", np.ones(len(cases), dtype=bool), truths, baselines, predictions,
            oracles, ids, args.bootstrap_repetitions, args.seed,
        ),
        "strict_inward": summarize_group(
            "strict_inward", strict, truths, baselines, predictions, oracles,
            ids, args.bootstrap_repetitions, args.seed + 1,
        ),
        "ordinary": summarize_group(
            "ordinary", ~strict, truths, baselines, predictions, oracles,
            ids, args.bootstrap_repetitions, args.seed + 2,
        ),
    }
    write_csv(output_dir / "public_case_metrics.csv", rows)
    write_csv(output_dir / "action_gate_calibration.csv", calibration_rows)
    (output_dir / "fold_policies.json").write_text(
        json.dumps(selected_records, indent=2), encoding="utf-8"
    )
    np.savez_compressed(
        output_dir / "predictions.npz", ids=ids, truths=truths, baseline=baselines,
        prediction=predictions, oracle=oracles, choices=choices,
        confidence_lower_score=confidence,
    )
    save_montage(
        output_dir / "strict_inward_action_gate.png", truths, baselines,
        predictions, oracles, ids, np.flatnonzero(strict),
    )
    action_principle = (
        "accept only training-calibrated exterior-connected removals with zero added support"
        if args.pure_bay else
        "accept only training-calibrated actions that jointly add locally polarity-supported "
        "lesion tissue and carve an exterior-connected bay at a resolvable scale"
    )
    summary = {
        "method": (
            "nested ridge candidate ranker plus pure exterior-bay physical action gate"
            if args.pure_bay else
            "nested ridge candidate ranker plus compensated-bay physical action gate"
        ),
        "status": "deployable complete-level out-of-fold evaluation",
        "stage_one_configuration_selected_without_outer_truth": True,
        "action_gate_selected_without_outer_truth": True,
        "strict_inward_ids_used_for_selection": False,
        "identity_fallback_always_available": True,
        "physical_action_gate_cannot_be_disabled": not args.allow_unrestricted_ablation,
        "minimum_resolvable_local_change": 0.015 if not args.relaxed_physical_ablation else 0.005,
        "minimum_predicted_iou_gain": 0.01 if not args.relaxed_physical_ablation else 0.0025,
        "action_principle": action_principle,
        "groups": groups,
        "fold_policies": selected_records,
        "stage_one_failure_ablation": str((args.stage_one_dir.resolve() / "summary.json")),
        "args": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
    }
    (output_dir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(groups, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
