"""Train and evaluate shape-aware networks for non-convex KTC EIT targets.

The public 21 KTC2023 v3 evaluation labels are never exposed to optimization.
They are loaded only after both synthetic-data checkpoints have been selected.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import random
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import scipy.signal as sps
import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image, ImageDraw
from scipy.ndimage import binary_dilation, binary_erosion, label as connected_components
from scipy.spatial import ConvexHull, QhullError
from torch.utils.data import DataLoader, Dataset


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--output-dir", type=Path, default=root / "outputs" / "ktc_shape_network_v1")
    parser.add_argument("--models", choices=("both", "vanilla", "shape"), default="both")
    parser.add_argument("--epochs", type=int, default=80)
    parser.add_argument("--batch-size", type=int, default=20)
    parser.add_argument("--base-channels", type=int, default=32)
    parser.add_argument("--learning-rate", type=float, default=2e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--patience", type=int, default=16)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--seed", type=int, default=20260819)
    parser.add_argument("--physics-weight", type=float, default=2e-4)
    parser.add_argument("--indent-weight", type=float, default=0.35)
    parser.add_argument("--calibration-weight", type=float, default=0.20)
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


class EITDataset(Dataset):
    def __init__(self, archive: np.lib.npyio.NpzFile, indices: np.ndarray, augment: bool) -> None:
        self.linear = archive["linear_images"]
        self.labels = archive["labels"]
        self.delta = archive["delta"]
        self.sdf = archive["signed_distance"]
        self.indent = archive["indentation_masks"]
        self.voltage = archive["clean_voltages"]
        self.indices = np.asarray(indices, dtype=np.int64)
        self.augment = augment

    def __len__(self) -> int:
        return int(self.indices.size)

    def __getitem__(self, item: int) -> dict[str, torch.Tensor]:
        index = int(self.indices[item])
        arrays = [
            np.asarray(self.linear[index], dtype=np.float32),
            np.asarray(self.labels[index], dtype=np.int64),
            np.asarray(self.delta[index], dtype=np.float32),
            np.asarray(self.sdf[index], dtype=np.float32),
            np.asarray(self.indent[index], dtype=np.float32),
        ]
        if self.augment:
            turns = int(np.random.randint(0, 4))
            arrays = [np.rot90(array, turns) for array in arrays]
            if np.random.random() < 0.5:
                arrays = [np.fliplr(array) for array in arrays]
            if np.random.random() < 0.5:
                arrays = [np.flipud(array) for array in arrays]
        arrays = [np.ascontiguousarray(array) for array in arrays]
        return {
            "image": torch.from_numpy(arrays[0][None]),
            "labels": torch.from_numpy(arrays[1]),
            "delta": torch.from_numpy(arrays[2][None]),
            "sdf": torch.from_numpy(arrays[3][None]),
            "indent": torch.from_numpy(arrays[4][None]),
            "voltage": torch.from_numpy(np.asarray(self.voltage[index], dtype=np.float32)),
            "index": torch.tensor(index, dtype=torch.int64),
        }


class CalibrationDataset(Dataset):
    def __init__(self, archive: np.lib.npyio.NpzFile, augment: bool = True) -> None:
        self.linear = archive["calibration_linear_images"]
        self.labels = archive["calibration_labels"]
        self.sdf = archive["calibration_signed_distance"]
        self.indent = archive["calibration_indentation_masks"]
        self.augment = augment

    def __len__(self) -> int:
        return int(len(self.linear))

    def __getitem__(self, index: int) -> dict[str, torch.Tensor]:
        arrays = [
            np.asarray(self.linear[index], dtype=np.float32),
            np.asarray(self.labels[index], dtype=np.int64),
            np.asarray(self.sdf[index], dtype=np.float32),
            np.asarray(self.indent[index], dtype=np.float32),
        ]
        if self.augment:
            turns = int(np.random.randint(0, 4))
            arrays = [np.rot90(array, turns) for array in arrays]
            if np.random.random() < 0.5:
                arrays = [np.fliplr(array) for array in arrays]
            if np.random.random() < 0.5:
                arrays = [np.flipud(array) for array in arrays]
        arrays = [np.ascontiguousarray(array) for array in arrays]
        return {
            "image": torch.from_numpy(arrays[0][None]),
            "labels": torch.from_numpy(arrays[1]),
            "sdf": torch.from_numpy(arrays[2][None]),
            "indent": torch.from_numpy(arrays[3][None]),
        }


class InputAdapter(nn.Module):
    """Convert a scale-dependent ridge image into signed, smooth, and edge channels."""

    def __init__(self, fov_mask: np.ndarray) -> None:
        super().__init__()
        mask = torch.from_numpy(np.asarray(fov_mask, dtype=np.float32))[None, None]
        self.register_buffer("mask", mask)
        sobel_x = torch.tensor(
            [[-1.0, 0.0, 1.0], [-2.0, 0.0, 2.0], [-1.0, 0.0, 1.0]], dtype=torch.float32
        ) / 8.0
        self.register_buffer("sobel_x", sobel_x[None, None])
        self.register_buffer("sobel_y", sobel_x.T[None, None])

    def forward(self, image: torch.Tensor) -> torch.Tensor:
        batch = image.shape[0]
        selected = image[:, 0, self.mask[0, 0].bool()]
        center = selected.median(dim=1).values.reshape(batch, 1, 1, 1)
        centered = (image - center) * self.mask
        selected_abs = centered[:, 0, self.mask[0, 0].bool()].abs()
        scale = torch.quantile(selected_abs, 0.985, dim=1).clamp_min(1e-5).reshape(batch, 1, 1, 1)
        signed = torch.clamp(centered / scale, -3.0, 3.0) / 3.0
        signed = signed * self.mask
        smooth = F.avg_pool2d(signed, kernel_size=7, stride=1, padding=3) * self.mask
        grad_x = F.conv2d(signed, self.sobel_x, padding=1)
        grad_y = F.conv2d(signed, self.sobel_y, padding=1)
        edge = torch.sqrt(grad_x.square() + grad_y.square() + 1e-8).clamp(0.0, 1.0) * self.mask
        return torch.cat((signed, smooth, edge), dim=1)


def norm_layer(channels: int) -> nn.GroupNorm:
    groups = min(8, channels)
    while channels % groups:
        groups -= 1
    return nn.GroupNorm(groups, channels)


class ResidualBlock(nn.Module):
    def __init__(self, in_channels: int, out_channels: int) -> None:
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, 3, padding=1, bias=False)
        self.norm1 = norm_layer(out_channels)
        self.conv2 = nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False)
        self.norm2 = norm_layer(out_channels)
        self.skip = (
            nn.Identity() if in_channels == out_channels else nn.Conv2d(in_channels, out_channels, 1, bias=False)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = self.skip(x)
        x = F.silu(self.norm1(self.conv1(x)))
        x = self.norm2(self.conv2(x))
        return F.silu(x + residual)


class AttentionGate(nn.Module):
    def __init__(self, skip_channels: int, gate_channels: int) -> None:
        super().__init__()
        hidden = max(8, skip_channels // 2)
        self.skip_projection = nn.Conv2d(skip_channels, hidden, 1, bias=False)
        self.gate_projection = nn.Conv2d(gate_channels, hidden, 1, bias=False)
        self.score = nn.Conv2d(hidden, 1, 1)

    def forward(self, skip: torch.Tensor, gate: torch.Tensor) -> torch.Tensor:
        attention = torch.sigmoid(self.score(F.silu(self.skip_projection(skip) + self.gate_projection(gate))))
        return skip * attention


class DecoderStage(nn.Module):
    def __init__(self, in_channels: int, skip_channels: int, out_channels: int) -> None:
        super().__init__()
        self.reduce = nn.Conv2d(in_channels, out_channels, 1)
        self.attention = AttentionGate(skip_channels, out_channels)
        self.block = ResidualBlock(out_channels + skip_channels, out_channels)

    def forward(self, x: torch.Tensor, skip: torch.Tensor) -> torch.Tensor:
        x = F.interpolate(x, size=skip.shape[-2:], mode="bilinear", align_corners=False)
        x = self.reduce(x)
        skip = self.attention(skip, x)
        return self.block(torch.cat((x, skip), dim=1))


class ConcavityUNet(nn.Module):
    def __init__(self, base: int, shape_aware: bool) -> None:
        super().__init__()
        self.shape_aware = shape_aware
        self.stem = ResidualBlock(3, base)
        self.enc1 = ResidualBlock(base, base * 2)
        self.enc2 = ResidualBlock(base * 2, base * 4)
        self.enc3 = ResidualBlock(base * 4, base * 8)
        self.bottleneck = nn.Sequential(
            ResidualBlock(base * 8, base * 16),
            nn.Dropout2d(0.12),
            ResidualBlock(base * 16, base * 16),
        )
        self.dec3 = DecoderStage(base * 16, base * 8, base * 8)
        self.dec2 = DecoderStage(base * 8, base * 4, base * 4)
        self.dec1 = DecoderStage(base * 4, base * 2, base * 2)
        self.dec0 = DecoderStage(base * 2, base, base)
        self.segmentation = nn.Conv2d(base, 3, 1)
        if shape_aware:
            self.sdf_head = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))
            self.delta_head = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))

    def forward(self, x: torch.Tensor) -> dict[str, torch.Tensor]:
        e0 = self.stem(x)
        e1 = self.enc1(F.max_pool2d(e0, 2))
        e2 = self.enc2(F.max_pool2d(e1, 2))
        e3 = self.enc3(F.max_pool2d(e2, 2))
        x = self.bottleneck(F.max_pool2d(e3, 2))
        x = self.dec3(x, e3)
        x = self.dec2(x, e2)
        x = self.dec1(x, e1)
        features = self.dec0(x, e0)
        raw_logits = self.segmentation(features)
        if not self.shape_aware:
            return {"logits": raw_logits}
        sdf = torch.tanh(self.sdf_head(features))
        geometry_bias = 1.5 * sdf
        logits = torch.cat(
            (
                raw_logits[:, 0:1] - geometry_bias,
                raw_logits[:, 1:2] + 0.5 * geometry_bias,
                raw_logits[:, 2:3] + 0.5 * geometry_bias,
            ),
            dim=1,
        )
        return {"logits": logits, "sdf": sdf, "delta": 1.25 * torch.tanh(self.delta_head(features))}


def soft_dice_loss(logits: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    probabilities = torch.softmax(logits, dim=1)
    one_hot = F.one_hot(target, num_classes=3).permute(0, 3, 1, 2).float()
    intersection = (probabilities[:, 1:] * one_hot[:, 1:]).sum(dim=(0, 2, 3))
    denominator = (probabilities[:, 1:] + one_hot[:, 1:]).sum(dim=(0, 2, 3))
    return 1.0 - ((2.0 * intersection + 1.0) / (denominator + 1.0)).mean()


def image_gradient(image: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    return image[:, :, 1:, :] - image[:, :, :-1, :], image[:, :, :, 1:] - image[:, :, :, :-1]


@dataclass
class PhysicsOperator:
    jacobian: torch.Tensor
    node_to_raw_pixel: torch.Tensor
    voltage_scale: float

    def loss(self, delta: torch.Tensor, voltage: torch.Tensor) -> torch.Tensor:
        # The KTC matrix spans several orders of magnitude. Keep this product
        # in float32 even when the CNN runs under automatic mixed precision.
        with torch.amp.autocast("cuda", enabled=False):
            display_pixels = delta[:, 0].float()
            raw_pixels = torch.flip(display_pixels, dims=(1,)).flatten(1)
            nodes = raw_pixels[:, self.node_to_raw_pixel]
            predicted = self.voltage_scale * (nodes @ self.jacobian.float().T)
            voltage_float = voltage.float()
            rms = torch.sqrt(voltage_float.square().mean(dim=1, keepdim=True) + 1e-10)
            return torch.mean(((predicted - voltage_float) / rms).square())


def compute_loss(
    outputs: dict[str, torch.Tensor],
    batch: dict[str, torch.Tensor],
    class_weights: torch.Tensor,
    physics: PhysicsOperator,
    physics_weight: float,
    indent_weight: float,
) -> tuple[torch.Tensor, dict[str, float]]:
    logits = outputs["logits"]
    ce = F.cross_entropy(logits, batch["labels"], weight=class_weights)
    dice = soft_dice_loss(logits, batch["labels"])
    total = ce + dice
    pieces = {"ce": float(ce.detach()), "dice": float(dice.detach())}
    if "sdf" in outputs:
        sdf = F.smooth_l1_loss(outputs["sdf"], batch["sdf"], beta=0.08)
        conductivity = F.smooth_l1_loss(outputs["delta"], batch["delta"], beta=0.08)
        foreground_probability = torch.softmax(logits, dim=1)[:, 1:].sum(dim=1, keepdim=True)
        target_foreground = (batch["labels"] != 0).float().unsqueeze(1)
        pred_dy, pred_dx = image_gradient(foreground_probability)
        true_dy, true_dx = image_gradient(target_foreground)
        boundary = F.l1_loss(pred_dy, true_dy) + F.l1_loss(pred_dx, true_dx)
        indentation = (foreground_probability * batch["indent"]).sum() / (batch["indent"].sum() + 1.0)
        physical = physics.loss(outputs["delta"], batch["voltage"])
        total = (
            total
            + 0.55 * sdf
            + 0.45 * conductivity
            + 0.35 * boundary
            + indent_weight * indentation
            + physics_weight * physical
        )
        pieces.update(
            sdf=float(sdf.detach()),
            conductivity=float(conductivity.detach()),
            boundary=float(boundary.detach()),
            indentation=float(indentation.detach()),
            physics=float(physical.detach()),
        )
    pieces["total"] = float(total.detach())
    return total, pieces


def calibration_loss(
    outputs: dict[str, torch.Tensor],
    batch: dict[str, torch.Tensor],
    class_weights: torch.Tensor,
    indent_weight: float,
) -> torch.Tensor:
    logits = outputs["logits"]
    total = F.cross_entropy(logits, batch["labels"], weight=class_weights) + soft_dice_loss(
        logits, batch["labels"]
    )
    if "sdf" in outputs:
        sdf = F.smooth_l1_loss(outputs["sdf"], batch["sdf"], beta=0.08)
        foreground_probability = torch.softmax(logits, dim=1)[:, 1:].sum(dim=1, keepdim=True)
        target_foreground = (batch["labels"] != 0).float().unsqueeze(1)
        pred_dy, pred_dx = image_gradient(foreground_probability)
        true_dy, true_dx = image_gradient(target_foreground)
        boundary = F.l1_loss(pred_dy, true_dy) + F.l1_loss(pred_dx, true_dx)
        indentation = (foreground_probability * batch["indent"]).sum() / (batch["indent"].sum() + 1.0)
        total = total + 0.55 * sdf + 0.35 * boundary + 0.5 * indent_weight * indentation
    return total


def confusion_metrics(truth: np.ndarray, prediction: np.ndarray, indentation: np.ndarray) -> dict[str, float]:
    result: dict[str, float] = {}
    truth_fg = truth != 0
    pred_fg = prediction != 0
    intersection = np.logical_and(truth_fg, pred_fg).sum()
    union = np.logical_or(truth_fg, pred_fg).sum()
    result["foreground_iou"] = float(intersection / max(1, union))
    result["foreground_dice"] = float(2 * intersection / max(1, truth_fg.sum() + pred_fg.sum()))
    for class_id in (1, 2):
        class_truth = truth == class_id
        class_pred = prediction == class_id
        class_union = np.logical_or(class_truth, class_pred).sum()
        result[f"class_{class_id}_iou"] = (
            float(np.logical_and(class_truth, class_pred).sum() / class_union) if class_union else float("nan")
        )
    notch_pixels = indentation.astype(bool)
    result["notch_pixels"] = float(notch_pixels.sum())
    result["notch_preservation"] = (
        float((~pred_fg[notch_pixels]).mean()) if notch_pixels.any() else float("nan")
    )
    result["concavity_score"] = (
        float(math.sqrt(result["foreground_iou"] * result["notch_preservation"]))
        if notch_pixels.any()
        else float("nan")
    )
    truth_edge = np.logical_xor(truth_fg, binary_erosion(truth_fg))
    pred_edge = np.logical_xor(pred_fg, binary_erosion(pred_fg))
    tolerance = np.ones((3, 3), dtype=bool)
    precision = float((pred_edge & binary_dilation(truth_edge, structure=tolerance)).sum() / max(1, pred_edge.sum()))
    recall = float((truth_edge & binary_dilation(pred_edge, structure=tolerance)).sum() / max(1, truth_edge.sum()))
    result["boundary_f1"] = float(2 * precision * recall / max(1e-9, precision + recall))
    return result


def aggregate_rows(rows: list[dict[str, float]]) -> dict[str, float]:
    keys = sorted({key for row in rows for key in row})
    return {key: float(np.nanmean([row.get(key, np.nan) for row in rows])) for key in keys}


@torch.no_grad()
def evaluate_synthetic(
    model: nn.Module,
    adapter: InputAdapter,
    loader: DataLoader,
    device: torch.device,
) -> tuple[dict[str, float], dict[int, np.ndarray]]:
    model.eval()
    predictions: dict[int, np.ndarray] = {}
    rows: list[dict[str, float]] = []
    for batch in loader:
        image = batch["image"].to(device)
        outputs = model(adapter(image))
        prediction = outputs["logits"].argmax(dim=1).cpu().numpy()
        truth = batch["labels"].numpy()
        indentation = batch["indent"].numpy()[:, 0]
        for offset, index in enumerate(batch["index"].numpy()):
            predictions[int(index)] = prediction[offset]
            rows.append(confusion_metrics(truth[offset], prediction[offset], indentation[offset]))
    return aggregate_rows(rows), predictions


def train_one(
    name: str,
    archive: np.lib.npyio.NpzFile,
    args: argparse.Namespace,
    output_dir: Path,
    device: torch.device,
) -> tuple[ConcavityUNet, list[dict[str, float]]]:
    shape_aware = name == "shape"
    # Shapes already have continuous random rotations and positions. Keeping
    # the physical image/voltage pair unchanged is required by the Jacobian loss.
    train_data = EITDataset(archive, archive["train_indices"], augment=False)
    validation_data = EITDataset(archive, archive["validation_indices"], augment=False)
    train_loader = DataLoader(
        train_data, batch_size=args.batch_size, shuffle=True, num_workers=args.workers,
        pin_memory=device.type == "cuda", drop_last=True,
    )
    validation_loader = DataLoader(
        validation_data, batch_size=args.batch_size, shuffle=False, num_workers=args.workers,
        pin_memory=device.type == "cuda",
    )
    calibration_loader = None
    calibration_iterator = None
    if "calibration_linear_images" in archive.files and args.calibration_weight > 0:
        calibration_loader = DataLoader(
            CalibrationDataset(archive, augment=True),
            batch_size=len(archive["calibration_linear_images"]),
            shuffle=True,
            num_workers=0,
        )
        calibration_iterator = iter(calibration_loader)
    adapter = InputAdapter(archive["fov_mask"]).to(device)
    model = ConcavityUNet(args.base_channels, shape_aware=shape_aware).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(1, args.epochs))
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    counts = np.bincount(archive["labels"][archive["train_indices"]].reshape(-1), minlength=3).astype(np.float64)
    class_weights_np = np.sqrt(counts.sum() / np.maximum(counts, 1.0))
    class_weights_np /= class_weights_np.mean()
    class_weights = torch.from_numpy(class_weights_np.astype(np.float32)).to(device)
    physics = PhysicsOperator(
        jacobian=torch.from_numpy(archive["jacobian"]).to(device),
        node_to_raw_pixel=torch.from_numpy(archive["node_to_raw_pixel"]).long().to(device),
        voltage_scale=2.0,
    )
    checkpoint = output_dir / f"{name}_best.pt"
    history: list[dict[str, float]] = []
    best_score = -math.inf
    stale = 0
    for epoch in range(1, args.epochs + 1):
        model.train()
        totals: list[float] = []
        auxiliary_ramp = min(1.0, max(0.0, (epoch - 5) / 10.0))
        for batch in train_loader:
            batch = {
                key: value.to(device, non_blocking=True) if isinstance(value, torch.Tensor) else value
                for key, value in batch.items()
            }
            optimizer.zero_grad(set_to_none=True)
            with torch.amp.autocast("cuda", enabled=device.type == "cuda"):
                outputs = model(adapter(batch["image"]))
                loss, _ = compute_loss(
                    outputs, batch, class_weights, physics,
                    args.physics_weight * auxiliary_ramp if shape_aware else 0.0,
                    args.indent_weight * auxiliary_ramp if shape_aware else 0.0,
                )
                if calibration_loader is not None:
                    try:
                        calibration_batch = next(calibration_iterator)
                    except StopIteration:
                        calibration_iterator = iter(calibration_loader)
                        calibration_batch = next(calibration_iterator)
                    calibration_batch = {
                        key: value.to(device, non_blocking=True)
                        for key, value in calibration_batch.items()
                    }
                    calibration_outputs = model(adapter(calibration_batch["image"]))
                    loss = loss + args.calibration_weight * calibration_loss(
                        calibration_outputs,
                        calibration_batch,
                        class_weights,
                        args.indent_weight * auxiliary_ramp if shape_aware else 0.0,
                    )
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            scaler.step(optimizer)
            scaler.update()
            totals.append(float(loss.detach()))
        scheduler.step()
        validation, _ = evaluate_synthetic(model, adapter, validation_loader, device)
        score = 0.70 * validation["foreground_iou"] + 0.30 * validation["boundary_f1"]
        row = {
            "epoch": float(epoch),
            "train_loss": float(np.mean(totals)),
            "learning_rate": float(optimizer.param_groups[0]["lr"]),
            "selection_score": float(score),
            **{f"validation_{key}": value for key, value in validation.items()},
        }
        history.append(row)
        print(
            f"{name} epoch {epoch}/{args.epochs}: loss={row['train_loss']:.4f}, "
            f"IoU={validation['foreground_iou']:.4f}, boundary={validation['boundary_f1']:.4f}, "
            f"notch={validation['notch_preservation']:.4f}",
            flush=True,
        )
        if score > best_score + 1e-5:
            best_score = score
            stale = 0
            torch.save(
                {
                    "model": model.state_dict(),
                    "base_channels": args.base_channels,
                    "shape_aware": shape_aware,
                    "epoch": epoch,
                    "selection_score": score,
                    "class_weights": class_weights_np.tolist(),
                },
                checkpoint,
            )
        else:
            stale += 1
        if stale >= args.patience:
            print(f"{name}: early stopping after {epoch} epochs", flush=True)
            break
    state = torch.load(checkpoint, map_location=device, weights_only=False)
    model.load_state_dict(state["model"])
    (output_dir / f"{name}_history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    return model, history


def multi_otsu_labels(image: np.ndarray, fov_mask: np.ndarray) -> np.ndarray:
    values = image[fov_mask]
    low, high = np.percentile(values, (0.2, 99.8))
    hist, edges = np.histogram(np.clip(values, low, high), bins=192, range=(low, high))
    probability = hist.astype(np.float64) / max(1, hist.sum())
    centers = 0.5 * (edges[:-1] + edges[1:])
    omega = np.cumsum(probability)
    moment = np.cumsum(probability * centers)
    total_moment = moment[-1]
    best_score = -np.inf
    best = (63, 127)
    for first in range(1, len(hist) - 2):
        second = np.arange(first + 1, len(hist) - 1)
        weights = np.stack(
            (
                np.full_like(second, omega[first], dtype=np.float64),
                omega[second] - omega[first],
                1.0 - omega[second],
            ),
            axis=1,
        )
        means = np.stack(
            (
                np.full_like(second, moment[first], dtype=np.float64),
                moment[second] - moment[first],
                total_moment - moment[second],
            ),
            axis=1,
        ) / np.maximum(weights, 1e-12)
        scores = (weights * (means - total_moment) ** 2).sum(axis=1)
        index = int(np.argmax(scores))
        if scores[index] > best_score:
            best_score = float(scores[index])
            best = (first, int(second[index]))
    threshold_1, threshold_2 = edges[best[0] + 1], edges[best[1] + 1]
    groups = np.digitize(image, (threshold_1, threshold_2))
    counts = [int(((groups == group) & fov_mask).sum()) for group in range(3)]
    background_group = int(np.argmax(counts))
    result = np.zeros(image.shape, dtype=np.uint8)
    if background_group == 0:
        result[(groups > 0) & fov_mask] = 2
    elif background_group == 1:
        result[(groups == 0) & fov_mask] = 1
        result[(groups == 2) & fov_mask] = 2
    else:
        result[(groups < 2) & fov_mask] = 1
    return result


def convex_hull_mask(binary: np.ndarray) -> np.ndarray:
    rows, cols = np.nonzero(binary)
    if rows.size < 3:
        return binary.copy()
    points = np.column_stack((cols, rows))
    try:
        hull = ConvexHull(points)
    except QhullError:
        return binary.copy()
    canvas = Image.new("1", (binary.shape[1], binary.shape[0]), 0)
    ImageDraw.Draw(canvas).polygon([tuple(point) for point in points[hull.vertices]], fill=1)
    return np.asarray(canvas, dtype=bool)


def indentation_mask(labels: np.ndarray) -> np.ndarray:
    result = np.zeros(labels.shape, dtype=bool)
    for class_id in (1, 2):
        components, count = connected_components(labels == class_id, structure=np.ones((3, 3), dtype=np.uint8))
        for component_id in range(1, count + 1):
            component = components == component_id
            if component.sum() >= 8:
                result |= convex_hull_mask(component) & ~component
    return result


def ssim_fft(truth: np.ndarray, reconstruction: np.ndarray) -> float:
    c1, c2, radius = 1e-4, 9e-4, 80
    coordinates = np.arange(-2 * radius, 2 * radius + 1)
    x, y = np.meshgrid(coordinates, coordinates)
    kernel = (1 / np.sqrt(2 * np.pi)) * np.exp(-0.5 * (x * x + y * y) / (radius * radius))
    correction = sps.fftconvolve(np.ones(truth.shape), kernel, mode="same")

    def conv(array: np.ndarray) -> np.ndarray:
        return sps.fftconvolve(array, kernel, mode="same") / correction

    mean_truth, mean_reconstruction = conv(truth), conv(reconstruction)
    var_truth = conv(truth * truth) - mean_truth**2
    var_reconstruction = conv(reconstruction * reconstruction) - mean_reconstruction**2
    covariance = conv(truth * reconstruction) - mean_truth * mean_reconstruction
    numerator = (2 * mean_truth * mean_reconstruction + c1) * (2 * covariance + c2)
    denominator = (mean_truth**2 + mean_reconstruction**2 + c1) * (var_truth + var_reconstruction + c2)
    return float(np.mean(numerator / denominator))


def ktc_score(truth: np.ndarray, reconstruction: np.ndarray) -> float:
    scores = []
    for class_id in (1, 2):
        scores.append(ssim_fft((truth == class_id).astype(float), (reconstruction == class_id).astype(float)))
    return float(np.mean(scores))


@torch.no_grad()
def infer_real(
    model: nn.Module,
    adapter: InputAdapter,
    images: np.ndarray,
    device: torch.device,
    batch_size: int,
) -> np.ndarray:
    model.eval()
    outputs = []
    for start in range(0, len(images), batch_size):
        tensor = torch.from_numpy(images[start : start + batch_size, None].astype(np.float32)).to(device)
        outputs.append(model(adapter(tensor))["logits"].argmax(dim=1).cpu().numpy())
    return np.concatenate(outputs)


def resize_labels(labels: np.ndarray, size: int = 256) -> np.ndarray:
    return np.asarray(
        Image.fromarray(labels.astype(np.uint8)).resize((size, size), resample=Image.Resampling.NEAREST)
    )


def evaluate_real_method(
    name: str,
    predictions_64: np.ndarray,
    truths: np.ndarray,
    ids: np.ndarray,
) -> tuple[dict[str, float], list[dict[str, object]], np.ndarray]:
    predictions = np.stack([resize_labels(prediction) for prediction in predictions_64])
    rows: list[dict[str, object]] = []
    numeric_rows: list[dict[str, float]] = []
    for index, (truth, prediction) in enumerate(zip(truths, predictions)):
        metrics = confusion_metrics(truth, prediction, indentation_mask(truth))
        metrics["ktc_ssim"] = ktc_score(truth, prediction)
        numeric_rows.append(metrics)
        rows.append({"id": str(ids[index]), "method": name, **metrics})
    return aggregate_rows(numeric_rows), rows, predictions


def save_real_montage(
    path: Path,
    truths: np.ndarray,
    ids: np.ndarray,
    predictions: dict[str, np.ndarray],
    rows: list[dict[str, object]],
) -> None:
    method_names = list(predictions)
    lookup = {(str(row["id"]), str(row["method"])): row for row in rows}
    figure, axes = plt.subplots(len(truths), 1 + len(method_names), figsize=(3.0 * (1 + len(method_names)), 2.9 * len(truths)), squeeze=False)
    for index, truth in enumerate(truths):
        axes[index, 0].imshow(truth, vmin=0, vmax=2, cmap="viridis")
        axes[index, 0].set_title(f"{ids[index]}\ntruth")
        for column, method in enumerate(method_names, start=1):
            row = lookup[(str(ids[index]), method)]
            axes[index, column].imshow(predictions[method][index], vmin=0, vmax=2, cmap="viridis")
            axes[index, column].set_title(
                f"{method}\nIoU={row['foreground_iou']:.3f}, notch={row['notch_preservation']:.3f}"
            )
        for axis in axes[index]:
            axis.set_axis_off()
    figure.suptitle("KTC2023 v3: all 21 untouched real evaluation phantoms", fontsize=16)
    figure.tight_layout()
    figure.savefig(path, dpi=145)
    plt.close(figure)


def save_focus_montage(
    path: Path,
    truths: np.ndarray,
    ids: np.ndarray,
    predictions: dict[str, np.ndarray],
    rows: list[dict[str, object]],
) -> None:
    indentation_sizes = np.asarray([indentation_mask(truth).sum() for truth in truths])
    focus = np.argsort(indentation_sizes)[::-1][:8]
    lookup = {(str(row["id"]), str(row["method"])): row for row in rows}
    methods = list(predictions)
    figure, axes = plt.subplots(len(focus), 1 + len(methods), figsize=(3.2 * (1 + len(methods)), 3.0 * len(focus)), squeeze=False)
    for row_index, case_index in enumerate(focus):
        axes[row_index, 0].imshow(truths[case_index], vmin=0, vmax=2, cmap="viridis")
        axes[row_index, 0].set_title(f"{ids[case_index]} truth\nnotch pixels={indentation_sizes[case_index]}")
        for column, method in enumerate(methods, start=1):
            metric = lookup[(str(ids[case_index]), method)]
            axes[row_index, column].imshow(predictions[method][case_index], vmin=0, vmax=2, cmap="viridis")
            axes[row_index, column].set_title(
                f"{method}\nIoU={metric['foreground_iou']:.3f}, boundary={metric['boundary_f1']:.3f}\n"
                f"notch preserved={metric['notch_preservation']:.3f}"
            )
        for axis in axes[row_index]:
            axis.set_axis_off()
    figure.suptitle("Most strongly non-convex public KTC cases", fontsize=16)
    figure.tight_layout()
    figure.savefig(path, dpi=170)
    plt.close(figure)


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    keys = ["id", "method", "foreground_iou", "foreground_dice", "class_1_iou", "class_2_iou", "boundary_f1", "notch_pixels", "notch_preservation", "concavity_score", "ktc_ssim"]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        writer.writerows({key: row.get(key) for key in keys} for row in rows)


def subgroup_summary(rows: list[dict[str, object]], minimum_notch_pixels: float) -> dict[str, dict[str, float]]:
    methods = sorted({str(row["method"]) for row in rows})
    result: dict[str, dict[str, float]] = {}
    for method in methods:
        selected = [
            row
            for row in rows
            if str(row["method"]) == method and float(row["notch_pixels"]) >= minimum_notch_pixels
        ]
        numeric = [
            {key: float(value) for key, value in row.items() if key not in ("id", "method")}
            for row in selected
        ]
        result[method] = {"cases": float(len(selected)), **aggregate_rows(numeric)}
    return result


def paired_bootstrap(
    rows: list[dict[str, object]],
    candidate: str,
    reference: str,
    minimum_notch_pixels: float,
    seed: int,
    repetitions: int = 10000,
) -> dict[str, dict[str, float]]:
    lookup = {(str(row["id"]), str(row["method"])): row for row in rows}
    ids = sorted(
        {
            str(row["id"])
            for row in rows
            if str(row["method"]) == candidate
            and float(row["notch_pixels"]) >= minimum_notch_pixels
            and (str(row["id"]), reference) in lookup
        }
    )
    rng = np.random.default_rng(seed)
    metrics = ("foreground_iou", "boundary_f1", "notch_preservation", "concavity_score", "ktc_ssim")
    output: dict[str, dict[str, float]] = {}
    for metric in metrics:
        differences = np.asarray(
            [float(lookup[(case_id, candidate)][metric]) - float(lookup[(case_id, reference)][metric]) for case_id in ids],
            dtype=np.float64,
        )
        differences = differences[np.isfinite(differences)]
        if differences.size == 0:
            continue
        sampled = differences[rng.integers(0, differences.size, size=(repetitions, differences.size))].mean(axis=1)
        output[metric] = {
            "cases": float(differences.size),
            "mean_difference": float(differences.mean()),
            "ci95_low": float(np.percentile(sampled, 2.5)),
            "ci95_high": float(np.percentile(sampled, 97.5)),
            "bootstrap_probability_positive": float((sampled > 0).mean()),
        }
    return output


def save_training_curves(path: Path, histories: dict[str, list[dict[str, float]]]) -> None:
    figure, axes = plt.subplots(1, 3, figsize=(13.5, 4.0), squeeze=False)
    fields = (
        ("train_loss", "training loss"),
        ("validation_foreground_iou", "validation foreground IoU"),
        ("validation_boundary_f1", "validation boundary F1"),
    )
    for name, history in histories.items():
        epochs = [int(row["epoch"]) for row in history]
        for axis, (field, title) in zip(axes[0], fields):
            axis.plot(epochs, [row[field] for row in history], label=name, linewidth=2)
            axis.set_title(title)
            axis.set_xlabel("epoch")
            axis.grid(alpha=0.25)
    for axis in axes[0]:
        axis.legend()
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    archive = np.load(args.dataset.resolve(), allow_pickle=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"device={device}; dataset={args.dataset.resolve()}", flush=True)
    model_names = ["vanilla", "shape"] if args.models == "both" else [args.models]
    trained: dict[str, ConcavityUNet] = {}
    histories: dict[str, list[dict[str, float]]] = {}
    for name in model_names:
        set_seed(args.seed)
        trained[name], histories[name] = train_one(name, archive, args, output_dir, device)

    # Synthetic test evaluation is completed before public real labels are accessed.
    adapter = InputAdapter(archive["fov_mask"]).to(device)
    test_loader = DataLoader(
        EITDataset(archive, archive["test_indices"], augment=False),
        batch_size=args.batch_size, shuffle=False, num_workers=args.workers,
    )
    synthetic_summary: dict[str, dict[str, float]] = {}
    for name, model in trained.items():
        synthetic_summary[name], _ = evaluate_synthetic(model, adapter, test_loader, device)
        print(f"synthetic test {name}: {synthetic_summary[name]}", flush=True)

    real_images = archive["real_linear_images"]
    real_ids = archive["real_ids"]
    real_truths = archive["real_labels"]
    fov = archive["fov_mask"].astype(bool)
    real_predictions_64: dict[str, np.ndarray] = {
        "ridge": np.stack([multi_otsu_labels(image, fov) for image in real_images])
    }
    for name, model in trained.items():
        real_predictions_64[name] = infer_real(model, adapter, real_images, device, args.batch_size)
    real_summary: dict[str, dict[str, float]] = {}
    real_rows: list[dict[str, object]] = []
    real_predictions: dict[str, np.ndarray] = {}
    for name, prediction in real_predictions_64.items():
        summary, rows, resized = evaluate_real_method(name, prediction, real_truths, real_ids)
        real_summary[name] = summary
        real_rows.extend(rows)
        real_predictions[name] = resized
        print(f"real test {name}: {summary}", flush=True)

    real_concave_summary = subgroup_summary(real_rows, minimum_notch_pixels=50.0)
    bootstrap = {}
    if "shape" in real_predictions:
        for reference in ("ridge", "vanilla"):
            if reference in real_predictions:
                bootstrap[f"shape_minus_{reference}"] = paired_bootstrap(
                    real_rows,
                    candidate="shape",
                    reference=reference,
                    minimum_notch_pixels=50.0,
                    seed=args.seed + len(bootstrap),
                )

    write_rows(output_dir / "real_case_metrics.csv", real_rows)
    save_real_montage(output_dir / "real_all_21_comparison.png", real_truths, real_ids, real_predictions, real_rows)
    save_focus_montage(output_dir / "real_most_concave_comparison.png", real_truths, real_ids, real_predictions, real_rows)
    save_training_curves(output_dir / "training_curves.png", histories)
    (output_dir / "bootstrap_concave.json").write_text(
        json.dumps(bootstrap, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    result = {
        "dataset": str(args.dataset.resolve()),
        "output_dir": str(output_dir),
        "device": str(device),
        "seed": args.seed,
        "models": model_names,
        "synthetic_test": synthetic_summary,
        "real_untouched_test": real_summary,
        "real_materially_concave_test": real_concave_summary,
        "paired_bootstrap_materially_concave": bootstrap,
        "evaluation_truth_used_for_training": False,
        "selection_rule": "0.70 * synthetic validation foreground IoU + 0.30 * synthetic validation boundary F1",
        "method": {
            "vanilla": "residual attention U-Net with CE and Dice",
            "shape": "same backbone plus SDF, conductivity, boundary, indentation false-fill, and Jacobian consistency losses",
        },
        "args": vars(args) | {"dataset": str(args.dataset), "output_dir": str(args.output_dir)},
    }
    (output_dir / "summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
