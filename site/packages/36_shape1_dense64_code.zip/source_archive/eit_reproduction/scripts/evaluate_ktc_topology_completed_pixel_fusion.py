"""Complete or reject closed cavities produced by local candidate fusion.

Every new cavity must be connected to exterior background along the background
component of one frozen candidate.  Validation selects the minimum cavity and
path confidence; test and public labels are used only after this policy is
frozen.
"""
from __future__ import annotations

import argparse
import csv
import heapq
import json
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from scipy import ndimage as ndi

from prepare_ktc_deep_concavity_stress import FAMILIES
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_cross_representation_pixel_fusion import (
    STRICT_INWARD_IDS,
    PixelCandidateFusionNet,
    SplitArrays,
    apply_fields,
    evaluate_split,
    foreground_iou_per_case,
    infer_fields,
    load_pool,
    metric_for,
    paired_bootstrap,
    prepare_split,
    public_subgroup_metrics,
)
from train_ktc_implicit_boolean_network import stress_metrics


STRUCTURE = np.ones((3, 3), dtype=np.uint8)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    parser.add_argument("--pool-dir", type=Path, default=root / "outputs" / "ktc_cross_representation_pool_seed20260820")
    parser.add_argument(
        "--pixel-fusion-dir", type=Path,
        default=root / "outputs" / "ktc_cross_representation_pixel_fusion_seed20260820",
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=root / "outputs" / "ktc_topology_completed_pixel_fusion_seed20260820",
    )
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--public-batch-size", type=int, default=1)
    parser.add_argument("--bootstrap-repetitions", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260820)
    parser.add_argument("--base-iou-tolerance", type=float, default=0.003)
    parser.add_argument("--base-boundary-tolerance", type=float, default=0.004)
    parser.add_argument("--stress-iou-tolerance", type=float, default=0.006)
    parser.add_argument("--stress-bank-tolerance", type=float, default=0.012)
    return parser.parse_args()


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def exterior_background(prediction: np.ndarray) -> np.ndarray:
    components, count = ndi.label(prediction == 0, structure=STRUCTURE)
    if count == 0:
        return np.zeros_like(prediction, dtype=bool)
    border = np.unique(np.concatenate((components[0], components[-1], components[:, 0], components[:, -1])))
    return np.isin(components, border[border != 0])


def shortest_path(
    allowed: np.ndarray,
    starts: np.ndarray,
    goals: np.ndarray,
    costs: np.ndarray,
) -> np.ndarray | None:
    height, width = allowed.shape
    distance = np.full((height, width), np.inf, dtype=np.float32)
    predecessor = np.full((height, width, 2), -1, dtype=np.int16)
    queue: list[tuple[float, int, int]] = []
    for row, column in np.argwhere(starts & allowed):
        value = float(costs[row, column])
        distance[row, column] = value
        heapq.heappush(queue, (value, int(row), int(column)))
    end: tuple[int, int] | None = None
    while queue:
        current, row, column = heapq.heappop(queue)
        if current != float(distance[row, column]):
            continue
        if goals[row, column]:
            end = (row, column)
            break
        for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            rr, cc = row + dr, column + dc
            if rr < 0 or rr >= height or cc < 0 or cc >= width or not allowed[rr, cc]:
                continue
            proposal = current + 0.5 * float(costs[row, column] + costs[rr, cc])
            if proposal < float(distance[rr, cc]):
                distance[rr, cc] = proposal
                predecessor[rr, cc] = (row, column)
                heapq.heappush(queue, (proposal, rr, cc))
    if end is None:
        return None
    path = np.zeros_like(allowed)
    current = end
    while current[0] >= 0:
        path[current] = True
        previous = predecessor[current]
        current = (int(previous[0]), int(previous[1]))
    return path


@dataclass
class CavityAction:
    cavity: np.ndarray
    path: np.ndarray | None
    cavity_confidence: float
    path_confidence: float
    path_length: int
    candidate_index: int


def build_case_actions(
    baseline: np.ndarray,
    initial: np.ndarray,
    candidates: np.ndarray,
    proposed: np.ndarray,
    gate: np.ndarray,
) -> list[CavityAction]:
    baseline_foreground = baseline != 0
    initial_foreground = initial != 0
    components, count = ndi.label(~initial_foreground, structure=STRUCTURE)
    border = np.unique(np.concatenate((components[0], components[-1], components[:, 0], components[:, -1])))
    outside = np.isin(components, border[border != 0])
    goals = ndi.binary_dilation(outside, structure=STRUCTURE) & initial_foreground
    background_vote = (candidates == 0).mean(axis=0).astype(np.float32)
    confidence = np.clip(0.55 * proposed[0] + 0.25 * gate + 0.20 * background_vote, 0.0, 1.0)
    costs = 0.08 + 2.5 * (1.0 - confidence)
    actions: list[CavityAction] = []
    for component_id in range(1, count + 1):
        if component_id in border:
            continue
        cavity = components == component_id
        new_cavity = cavity & baseline_foreground
        if not new_cavity.any():
            continue
        cavity_confidence = float(confidence[new_cavity].mean())
        best: CavityAction | None = None
        for candidate_index, candidate in enumerate(candidates):
            candidate_outside = exterior_background(candidate)
            starts = new_cavity & candidate_outside
            candidate_goals = goals & candidate_outside
            if not starts.any() or not candidate_goals.any():
                continue
            path = shortest_path(candidate_outside, starts, candidate_goals, costs)
            if path is None:
                continue
            removal_path = path & initial_foreground
            length = int(removal_path.sum())
            if length == 0:
                path_confidence = 1.0
            else:
                path_confidence = float(confidence[removal_path].mean())
            action = CavityAction(
                cavity=new_cavity,
                path=removal_path,
                cavity_confidence=cavity_confidence,
                path_confidence=path_confidence,
                path_length=length,
                candidate_index=candidate_index,
            )
            key = (action.path_confidence - 0.012 * action.path_length, -action.path_length)
            if best is None or key > (best.path_confidence - 0.012 * best.path_length, -best.path_length):
                best = action
        if best is None:
            best = CavityAction(new_cavity, None, cavity_confidence, 0.0, 10**9, -1)
        actions.append(best)
    return actions


def build_actions(
    baseline: np.ndarray,
    initial: np.ndarray,
    candidates: np.ndarray,
    proposed: np.ndarray,
    gate: np.ndarray,
) -> list[list[CavityAction]]:
    return [
        build_case_actions(baseline[index], initial[index], candidates[:, index], proposed[index], gate[index])
        for index in range(len(initial))
    ]


def apply_actions(
    baseline: np.ndarray,
    initial: np.ndarray,
    actions: list[list[CavityAction]],
    cavity_threshold: float,
    path_threshold: float,
    max_path_length: int,
    scale: int = 1,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    result = initial.copy()
    accepted = np.zeros(len(initial), dtype=np.int32)
    rejected = np.zeros(len(initial), dtype=np.int32)
    for case_index, case_actions in enumerate(actions):
        for action in case_actions:
            accept = (
                action.path is not None
                and action.cavity_confidence >= cavity_threshold
                and action.path_confidence >= path_threshold
                and action.path_length <= max_path_length * scale
            )
            if accept:
                result[case_index][action.path] = 0
                accepted[case_index] += 1
            else:
                result[case_index][action.cavity] = baseline[case_index][action.cavity]
                rejected[case_index] += 1
    return result, accepted, rejected


def action_rows(name: str, actions: list[list[CavityAction]]) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for case_index, case_actions in enumerate(actions):
        for action_index, action in enumerate(case_actions):
            rows.append({
                "split": name, "case_index": case_index, "action_index": action_index,
                "cavity_pixels": int(action.cavity.sum()), "cavity_confidence": action.cavity_confidence,
                "path_confidence": action.path_confidence, "path_length": action.path_length,
                "candidate_index": action.candidate_index,
            })
    return rows


def calibrate(
    base: SplitArrays,
    stress: SplitArrays,
    base_initial: np.ndarray,
    stress_initial: np.ndarray,
    base_actions: list[list[CavityAction]],
    stress_actions: list[list[CavityAction]],
    args: argparse.Namespace,
) -> tuple[dict[str, object], list[dict[str, object]]]:
    base_reference = metric_for(base, base.candidates[0])
    stress_reference = metric_for(stress, stress.candidates[0])
    rows: list[dict[str, object]] = []
    for cavity_threshold in (0.30, 0.40, 0.50, 0.60, 0.70):
        for path_threshold in (0.15, 0.25, 0.35, 0.45, 0.55):
            for max_path_length in (3, 5, 8, 12, 16):
                base_prediction, base_accepted, _ = apply_actions(
                    base.candidates[0], base_initial, base_actions,
                    cavity_threshold, path_threshold, max_path_length,
                )
                stress_prediction, stress_accepted, _ = apply_actions(
                    stress.candidates[0], stress_initial, stress_actions,
                    cavity_threshold, path_threshold, max_path_length,
                )
                base_metric = metric_for(base, base_prediction)
                stress_metric = metric_for(stress, stress_prediction)
                eligible = (
                    base_metric["foreground_iou"] >= base_reference["foreground_iou"] - args.base_iou_tolerance
                    and base_metric["boundary_f1"] >= base_reference["boundary_f1"] - args.base_boundary_tolerance
                    and stress_metric["foreground_iou"] >= stress_reference["foreground_iou"] - args.stress_iou_tolerance
                    and stress_metric["bank_retention"] >= stress_reference["bank_retention"] - args.stress_bank_tolerance
                )
                rows.append({
                    "cavity_threshold": cavity_threshold, "path_threshold": path_threshold,
                    "max_path_length": max_path_length, "eligible": bool(eligible),
                    "base_iou": base_metric["foreground_iou"],
                    "base_boundary_f1": base_metric["boundary_f1"],
                    "stress_iou": stress_metric["foreground_iou"],
                    "stress_boundary_f1": stress_metric["boundary_f1"],
                    "stress_open_deep": stress_metric["open_deep_cutout_recovery"],
                    "stress_bank": stress_metric["bank_retention"],
                    "stress_topology_joint": stress_metric["topology_structural_joint"],
                    "base_accepted_actions": int(base_accepted.sum()),
                    "stress_accepted_actions": int(stress_accepted.sum()),
                })
    eligible_rows = [row for row in rows if row["eligible"]]
    if not eligible_rows:
        return {
            "safe_fallback": True, "cavity_threshold": 2.0, "path_threshold": 2.0,
            "max_path_length": 0, "eligible": False,
        }, rows
    selected = max(eligible_rows, key=lambda row: (
        float(row["stress_topology_joint"]), float(row["stress_open_deep"]),
        float(row["stress_iou"]), float(row["base_iou"]),
    ))
    selected["safe_fallback"] = False
    return selected, rows


def save_stress_montage(
    path: Path,
    split: SplitArrays,
    initial: np.ndarray,
    completed: np.ndarray,
) -> None:
    baseline = split.candidates[0]
    difference = foreground_iou_per_case(split.truths, completed) - foreground_iou_per_case(split.truths, baseline)
    indices: list[int] = []
    for code in range(len(FAMILIES)):
        family = np.flatnonzero(split.families == code)
        if len(family):
            indices.append(int(family[np.argmax(difference[family])]))
    figure, axes = plt.subplots(len(indices), 6, figsize=(14.0, 2.25 * len(indices)), squeeze=False)
    for row, index in enumerate(indices):
        entrance = ((initial[index] != 0) & (completed[index] == 0)).astype(np.uint8)
        images = (
            (split.truths[index], f"{FAMILIES[int(split.families[index])]} truth", 0, 2),
            (baseline[index], "baseline", 0, 2),
            (initial[index], "pixel mixture", 0, 2),
            (completed[index], f"topology completed\nDelta IoU {difference[index]:+.3f}", 0, 2),
            (entrance, "added entrance", 0, 1),
            (split.cutouts[index], "true inward region", 0, 1),
        )
        for column, (image, title, low, high) in enumerate(images):
            axes[row, column].imshow(image, cmap="viridis", vmin=low, vmax=high, interpolation="nearest")
            axes[row, column].set_title(title, fontsize=9)
            axes[row, column].set_axis_off()
    figure.suptitle("Candidate-coherent topology completion on independent nonlinear-CEM stress test", y=0.995)
    figure.subplots_adjust(top=0.965, hspace=0.28, wspace=0.08)
    figure.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(figure)


def save_public_montage(
    path: Path,
    split: SplitArrays,
    initial: np.ndarray,
    completed: np.ndarray,
    ids: np.ndarray,
    indices: np.ndarray,
) -> None:
    baseline = split.candidates[0]
    difference = foreground_iou_per_case(split.truths, completed) - foreground_iou_per_case(split.truths, baseline)
    figure, axes = plt.subplots(len(indices), 5, figsize=(12.0, 2.25 * len(indices)), squeeze=False)
    for row, index in enumerate(indices):
        entrance = ((initial[index] != 0) & (completed[index] == 0)).astype(np.uint8)
        images = (
            (split.truths[index], f"{ids[index]} truth", 0, 2),
            (baseline[index], "baseline", 0, 2),
            (initial[index], "pixel mixture", 0, 2),
            (completed[index], f"topology completed\nDelta IoU {difference[index]:+.3f}", 0, 2),
            (entrance, "added entrance", 0, 1),
        )
        for column, (image, title, low, high) in enumerate(images):
            axes[row, column].imshow(image, cmap="viridis", vmin=low, vmax=high, interpolation="nearest")
            axes[row, column].set_title(title, fontsize=9)
            axes[row, column].set_axis_off()
    figure.suptitle("Public KTC2023 strict inward cases: topology-safe local fusion", y=0.995)
    figure.subplots_adjust(top=0.965, hspace=0.28, wspace=0.08)
    figure.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    base_archive = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress_archive = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    pool_dir = args.pool_dir.resolve()
    candidate_names: list[str] | None = None
    splits: dict[str, SplitArrays] = {}
    for name, source, archive in (
        ("base_validation", "base", base_archive), ("base_test", "base", base_archive),
        ("stress_validation", "stress", stress_archive), ("stress_test", "stress", stress_archive),
    ):
        names, split = prepare_split(name, source, archive, pool_dir)
        candidate_names = names if candidate_names is None else candidate_names
        if names != candidate_names:
            raise ValueError(f"candidate order differs in {name}")
        splits[name] = split
    assert candidate_names is not None
    pixel_summary = json.loads((args.pixel_fusion_dir.resolve() / "summary.json").read_text(encoding="utf-8"))
    pixel_policy = pixel_summary["selected_policy"]
    state = torch.load(args.pixel_fusion_dir.resolve() / "pixel_fusion_best.pt", map_location="cpu", weights_only=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = PixelCandidateFusionNet(
        len(candidate_names), int(state["base_channels"]), np.asarray(base_archive["fov_mask"])
    ).to(device)
    model.load_state_dict(state["model"])
    model.eval()
    alpha = float(pixel_policy["alpha"])
    gate_threshold = float(pixel_policy["gate_threshold"])
    validation: dict[str, tuple[np.ndarray, tuple[np.ndarray, np.ndarray], list[list[CavityAction]]]] = {}
    all_action_rows: list[dict[str, object]] = []
    for name in ("base_validation", "stress_validation"):
        split = splits[name]
        fields = infer_fields(model, split, device, args.batch_size)
        initial = apply_fields(split.candidates[0], *fields, alpha, gate_threshold)
        actions = build_actions(split.candidates[0], initial, split.candidates, *fields)
        validation[name] = (initial, fields, actions)
        all_action_rows.extend(action_rows(name, actions))
    policy, grid = calibrate(
        splits["base_validation"], splits["stress_validation"],
        validation["base_validation"][0], validation["stress_validation"][0],
        validation["base_validation"][2], validation["stress_validation"][2], args,
    )
    write_csv(output_dir / "validation_topology_grid.csv", grid)
    print(f"selected topology policy: {policy}", flush=True)
    cavity_threshold = float(policy["cavity_threshold"])
    path_threshold = float(policy["path_threshold"])
    max_path = int(policy["max_path_length"])

    results: dict[str, object] = {}
    predictions: dict[str, np.ndarray] = {}
    for offset, name in enumerate(("base_test", "stress_test")):
        split = splits[name]
        fields = infer_fields(model, split, device, args.batch_size)
        initial = apply_fields(split.candidates[0], *fields, alpha, gate_threshold)
        actions = build_actions(split.candidates[0], initial, split.candidates, *fields)
        completed, accepted, rejected = apply_actions(
            split.candidates[0], initial, actions, cavity_threshold, path_threshold, max_path,
        )
        evaluation = evaluate_split(split, completed, args.bootstrap_repetitions, args.seed + offset)
        evaluation["pixel_mixture"] = metric_for(split, initial)
        evaluation["accepted_actions"] = int(accepted.sum())
        evaluation["rejected_actions"] = int(rejected.sum())
        results[name] = evaluation
        predictions[name + "_initial"] = initial
        predictions[name + "_completed"] = completed
        all_action_rows.extend(action_rows(name, actions))
        if name == "stress_test":
            save_stress_montage(output_dir / "stress_family_topology_completed.png", split, initial, completed)

    public_names, public_indices, public_candidates = load_pool(pool_dir / "public_21.npz")
    if public_names != candidate_names:
        raise ValueError("candidate order differs in public pool")
    public_ids = np.asarray(base_archive["real_ids"])
    public_truths = np.asarray(base_archive["real_labels"], dtype=np.uint8)
    public_split = SplitArrays(
        "public_21", "base", public_indices,
        np.asarray(base_archive["real_linear_images"], dtype=np.float32),
        np.asarray(base_archive["real_voltages"], dtype=np.float32), public_truths,
        public_candidates, np.zeros_like(public_truths), np.zeros_like(public_truths, dtype=np.float32),
        np.full(len(public_ids), -1, dtype=np.int16),
    )
    fields = infer_fields(model, public_split, device, args.public_batch_size)
    public_initial = apply_fields(public_candidates[0], *fields, alpha, gate_threshold)
    public_actions = build_actions(public_candidates[0], public_initial, public_candidates, *fields)
    public_completed, public_accepted, public_rejected = apply_actions(
        public_candidates[0], public_initial, public_actions,
        cavity_threshold, path_threshold, max_path, scale=4,
    )
    strict = np.asarray([str(case_id) in STRICT_INWARD_IDS for case_id in public_ids])
    ordinary = ~strict
    public_all = public_subgroup_metrics(
        "topology_completed", public_split, public_completed, public_ids,
        np.ones(len(public_ids), dtype=bool), args.bootstrap_repetitions, args.seed + 10,
    )
    public_strict = public_subgroup_metrics(
        "topology_completed_strict", public_split, public_completed, public_ids,
        strict, args.bootstrap_repetitions, args.seed + 11,
    )
    public_ordinary = public_subgroup_metrics(
        "topology_completed_ordinary", public_split, public_completed, public_ids,
        ordinary, args.bootstrap_repetitions, args.seed + 12,
    )
    initial_summary, _ = evaluate_real_predictions("pixel_mixture", public_initial, public_truths, public_ids)
    results["public_21"] = {
        "pixel_mixture": initial_summary,
        "all": {key: value for key, value in public_all.items() if key != "rows"},
        "strict_inward": {key: value for key, value in public_strict.items() if key != "rows"},
        "ordinary": {key: value for key, value in public_ordinary.items() if key != "rows"},
        "accepted_actions": int(public_accepted.sum()), "rejected_actions": int(public_rejected.sum()),
    }
    write_csv(output_dir / "public_case_metrics.csv", public_all["rows"])
    all_action_rows.extend(action_rows("public_21", public_actions))
    write_csv(output_dir / "cavity_actions.csv", all_action_rows)
    save_public_montage(
        output_dir / "public_strict_inward_topology_completed.png", public_split,
        public_initial, public_completed, public_ids, np.flatnonzero(strict),
    )
    predictions["public_initial"] = public_initial
    predictions["public_completed"] = public_completed
    np.savez_compressed(output_dir / "predictions.npz", **predictions)
    summary = {
        "method": "candidate-coherent exterior-connected topology completion after pixel fusion",
        "pixel_fusion_policy": pixel_policy,
        "selected_topology_policy": policy,
        "results": results,
        "evaluation_truth_used_for_training_or_selection": False,
        "selection_data": "synthetic base and nonlinear-CEM stress validation only",
        "checkpoint": str((args.pixel_fusion_dir.resolve() / "pixel_fusion_best.pt")),
        "device": str(device),
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
