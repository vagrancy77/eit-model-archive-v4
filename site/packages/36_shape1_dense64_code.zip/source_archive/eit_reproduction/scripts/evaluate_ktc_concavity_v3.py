"""Freeze a validation-only protection gate, then run all final EIT tests."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader

import train_ktc_concavity_network as base
import train_ktc_concavity_network_v2 as v2
from train_ktc_concavity_network_v3 import CachedArchive


METRICS = (
    "foreground_iou",
    "foreground_dice",
    "class_1_iou",
    "class_2_iou",
    "boundary_f1",
    "notch_preservation",
    "concavity_score",
)
BIOLOGICAL_FAMILIES = (
    "oval_control",
    "shallow_bay",
    "soft_kidney",
    "lobulated_nodule",
    "rounded_control",
    "asymmetric_bay",
    "fused_cell_cluster",
    "smooth_crescent",
)
STRESS_FAMILIES = (
    "deep_c",
    "deep_u",
    "keyhole_bay",
    "crescent",
    "heart_notch",
    "sharp_star",
    "reentrant_v",
    "multi_object_gap",
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_joint_concavity_v1.npz")
    parser.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    parser.add_argument("--reference-checkpoint", type=Path, required=True)
    parser.add_argument("--candidate-checkpoint", type=Path, required=True)
    parser.add_argument("--candidate-architecture", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--ordinary-notch-pixels", type=int, default=12)
    parser.add_argument("--ordinary-iou-tolerance", type=float, default=0.002)
    parser.add_argument("--source-iou-tolerance", type=float, default=0.005)
    parser.add_argument("--bootstrap-repetitions", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=20260831)
    parser.add_argument(
        "--audit",
        type=Path,
        default=root / "outputs" / "ktc2023_full_audit" / "summary.json",
    )
    return parser.parse_args()


def load_model(path: Path, architecture: str, device: torch.device) -> v2.ConcavityNetV2:
    state = torch.load(path.resolve(), map_location=device, weights_only=False)
    if "spec" in state:
        spec = v2.ModelSpec(**state["spec"])
    else:
        spec = v2.SPECS[architecture]
    model = v2.ConcavityNetV2(int(state["base_channels"]), spec).to(device)
    model.load_state_dict(state["model"])
    model.eval()
    return model


@torch.no_grad()
def infer_archive(
    model: v2.ConcavityNetV2,
    adapter: v2.InputAdapter,
    archive: np.lib.npyio.NpzFile,
    indices: np.ndarray,
    device: torch.device,
    batch_size: int,
    workers: int,
) -> np.ndarray:
    loader = DataLoader(
        v2.EITDatasetV2(archive, indices),
        batch_size=batch_size,
        shuffle=False,
        num_workers=workers,
        pin_memory=True,
    )
    logits: list[np.ndarray] = []
    for batch in loader:
        image = batch["image"].to(device, non_blocking=True)
        voltage = batch["input_voltage"].to(device, non_blocking=True)
        logits.append(model(adapter(image), voltage)["logits"].float().cpu().numpy())
    return np.concatenate(logits)


@torch.no_grad()
def infer_arrays(
    model: v2.ConcavityNetV2,
    adapter: v2.InputAdapter,
    images: np.ndarray,
    voltages: np.ndarray,
    device: torch.device,
    batch_size: int,
) -> np.ndarray:
    logits: list[np.ndarray] = []
    for start in range(0, len(images), batch_size):
        image = torch.from_numpy(images[start : start + batch_size, None].astype(np.float32)).to(device)
        voltage = torch.from_numpy(voltages[start : start + batch_size].astype(np.float32)).to(device)
        logits.append(model(adapter(image), voltage)["logits"].float().cpu().numpy())
    return np.concatenate(logits)


def prediction_features(
    reference_logits: np.ndarray,
    candidate_logits: np.ndarray,
    fov: np.ndarray,
) -> dict[str, np.ndarray]:
    reference_prob = torch.softmax(torch.from_numpy(reference_logits), dim=1).numpy()
    candidate_prob = torch.softmax(torch.from_numpy(candidate_logits), dim=1).numpy()
    reference = reference_logits.argmax(axis=1)
    candidate = candidate_logits.argmax(axis=1)
    pixels = max(1, int(fov.sum()))
    predicted_notch = np.asarray(
        [base.indentation_mask(prediction).sum() / pixels for prediction in candidate], dtype=np.float64
    )
    disagreement = np.asarray(
        [np.logical_and(left != right, fov).sum() / pixels for left, right in zip(reference, candidate)],
        dtype=np.float64,
    )
    reference_confidence = reference_prob.max(axis=1)[:, fov].mean(axis=1)
    candidate_confidence = candidate_prob.max(axis=1)[:, fov].mean(axis=1)
    return {
        "predicted_notch_fraction": predicted_notch,
        "disagreement_fraction": disagreement,
        "candidate_confidence": candidate_confidence,
        "confidence_advantage": candidate_confidence - reference_confidence,
    }


def metric_arrays(
    truths: np.ndarray,
    indentations: np.ndarray,
    predictions: np.ndarray,
) -> dict[str, np.ndarray]:
    rows = [
        base.confusion_metrics(truth, prediction, indentation)
        for truth, prediction, indentation in zip(truths, predictions, indentations)
    ]
    return {
        metric: np.asarray([row[metric] for row in rows], dtype=np.float64)
        for metric in METRICS
    }


def selected_summary(
    reference: dict[str, np.ndarray],
    candidate: dict[str, np.ndarray],
    use_candidate: np.ndarray,
    subset: np.ndarray | None = None,
) -> dict[str, float]:
    selected = np.arange(use_candidate.size) if subset is None else np.asarray(subset, dtype=np.int64)
    result = {"cases": float(selected.size)}
    for metric in METRICS:
        values = np.where(use_candidate, candidate[metric], reference[metric])[selected]
        result[metric] = float(np.nanmean(values))
    return result


def gate_mask(features: dict[str, np.ndarray], rule: dict[str, object]) -> np.ndarray:
    if rule["mode"] == "reference":
        return np.zeros(len(features["predicted_notch_fraction"]), dtype=bool)
    if rule["mode"] == "candidate":
        return np.ones(len(features["predicted_notch_fraction"]), dtype=bool)
    return (
        (features["predicted_notch_fraction"] >= float(rule["minimum_predicted_notch_fraction"]))
        & (features["disagreement_fraction"] <= float(rule["maximum_disagreement_fraction"]))
        & (features["candidate_confidence"] >= float(rule["minimum_candidate_confidence"]))
    )


def fit_protection_gate(
    features: dict[str, np.ndarray],
    reference_metrics: dict[str, np.ndarray],
    candidate_metrics: dict[str, np.ndarray],
    notch_pixels: np.ndarray,
    sources: np.ndarray,
    args: argparse.Namespace,
) -> dict[str, object]:
    size = len(notch_pixels)
    all_indices = np.arange(size)
    ordinary = all_indices[notch_pixels < args.ordinary_notch_pixels]
    source_indices = {int(source): all_indices[sources == source] for source in np.unique(sources)}
    baseline_all = selected_summary(reference_metrics, candidate_metrics, np.zeros(size, dtype=bool))
    baseline_ordinary = selected_summary(
        reference_metrics, candidate_metrics, np.zeros(size, dtype=bool), ordinary
    )
    baseline_sources = {
        source: selected_summary(
            reference_metrics, candidate_metrics, np.zeros(size, dtype=bool), indices
        )
        for source, indices in source_indices.items()
    }

    quantiles = np.linspace(0.0, 1.0, 9)
    notch_thresholds = np.unique(np.quantile(features["predicted_notch_fraction"], quantiles))
    disagreement_thresholds = np.unique(
        np.quantile(features["disagreement_fraction"], np.linspace(0.50, 1.0, 6))
    )
    confidence_thresholds = np.unique(
        np.quantile(features["candidate_confidence"], np.asarray((0.0, 0.10, 0.25, 0.50)))
    )
    rules: list[dict[str, object]] = [
        {"mode": "reference"},
        {"mode": "candidate"},
    ]
    rules.extend(
        {
            "mode": "gated",
            "minimum_predicted_notch_fraction": float(notch),
            "maximum_disagreement_fraction": float(disagreement),
            "minimum_candidate_confidence": float(confidence),
        }
        for notch in notch_thresholds
        for disagreement in disagreement_thresholds
        for confidence in confidence_thresholds
    )

    records: list[dict[str, object]] = []
    for rule in rules:
        use = gate_mask(features, rule)
        overall = selected_summary(reference_metrics, candidate_metrics, use)
        ordinary_summary = selected_summary(reference_metrics, candidate_metrics, use, ordinary)
        per_source = {
            source: selected_summary(reference_metrics, candidate_metrics, use, indices)
            for source, indices in source_indices.items()
        }
        eligible = (
            overall["foreground_iou"] >= baseline_all["foreground_iou"] - args.source_iou_tolerance
            and ordinary_summary["foreground_iou"]
            >= baseline_ordinary["foreground_iou"] - args.ordinary_iou_tolerance
            and all(
                per_source[source]["foreground_iou"]
                >= baseline_sources[source]["foreground_iou"] - args.source_iou_tolerance
                for source in source_indices
            )
        )
        score = (
            0.50 * overall["foreground_iou"]
            + 0.20 * overall["boundary_f1"]
            + 0.30 * overall["concavity_score"]
        )
        records.append(
            {
                **rule,
                "eligible": bool(eligible),
                "changed_cases": int(use.sum()),
                "changed_fraction": float(use.mean()),
                "score": float(score),
                "overall": overall,
                "ordinary": ordinary_summary,
                "per_source": {str(key): value for key, value in per_source.items()},
            }
        )
    eligible_records = [record for record in records if record["eligible"]]
    best = max(eligible_records, key=lambda record: (record["score"], -record["changed_fraction"]))
    return {
        "selected_rule": best,
        "reference_validation": baseline_all,
        "reference_ordinary_validation": baseline_ordinary,
        "search_size": len(records),
        "eligible_rules": len(eligible_records),
        "objective": "0.50 * validation IoU + 0.20 * boundary F1 + 0.30 * concavity score",
        "truth_inputs": "joint synthetic validation labels only",
    }


def case_rows(
    ids: np.ndarray,
    truths: np.ndarray,
    indentations: np.ndarray,
    predictions: dict[str, np.ndarray],
    include_ktc_ssim: bool,
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for method, values in predictions.items():
        for case_id, truth, indentation, prediction in zip(ids, truths, indentations, values):
            metrics = base.confusion_metrics(truth, prediction, indentation)
            if include_ktc_ssim:
                metrics["ktc_ssim"] = base.ktc_score(truth, prediction)
            rows.append({"id": str(case_id), "method": method, **metrics})
    return rows


def aggregate_method_rows(rows: list[dict[str, object]]) -> dict[str, dict[str, float]]:
    output: dict[str, dict[str, float]] = {}
    for method in sorted({str(row["method"]) for row in rows}):
        selected = [row for row in rows if str(row["method"]) == method]
        numeric = [
            {
                key: float(value)
                for key, value in row.items()
                if key not in {"partition", "id", "method"}
            }
            for row in selected
        ]
        output[method] = {"cases": float(len(selected)), **base.aggregate_rows(numeric)}
    return output


def paired_bootstrap(
    rows: list[dict[str, object]],
    candidate: str,
    reference: str,
    repetitions: int,
    seed: int,
) -> dict[str, dict[str, float]]:
    lookup = {(str(row["id"]), str(row["method"])): row for row in rows}
    ids = sorted({str(row["id"]) for row in rows if str(row["method"]) == candidate})
    rng = np.random.default_rng(seed)
    result: dict[str, dict[str, float]] = {}
    metric_names = sorted(
        set.intersection(
            *[
                {
                    key
                    for key in lookup[(case_id, candidate)]
                    if key not in {"partition", "id", "method"}
                }
                & {
                    key
                    for key in lookup[(case_id, reference)]
                    if key not in {"partition", "id", "method"}
                }
                for case_id in ids
            ]
        )
    )
    for metric in metric_names:
        differences = np.asarray(
            [float(lookup[(case_id, candidate)][metric]) - float(lookup[(case_id, reference)][metric]) for case_id in ids]
        )
        differences = differences[np.isfinite(differences)]
        if differences.size == 0:
            continue
        draws = differences[
            rng.integers(0, differences.size, size=(repetitions, differences.size))
        ].mean(axis=1)
        result[metric] = {
            "cases": float(differences.size),
            "mean_difference": float(differences.mean()),
            "ci95_low": float(np.percentile(draws, 2.5)),
            "ci95_high": float(np.percentile(draws, 97.5)),
            "bootstrap_probability_positive": float((draws > 0).mean()),
        }
    return result


def write_case_rows(path: Path, rows: list[dict[str, object]]) -> None:
    fields = ["partition", "id", "method", *METRICS, "notch_pixels", "ktc_ssim"]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows({key: row.get(key) for key in fields} for row in rows)


def failure_records(rows: list[dict[str, object]], limit: int = 12) -> list[dict[str, object]]:
    lookup = {(str(row["id"]), str(row["method"])): row for row in rows}
    ids = sorted({str(row["id"]) for row in rows if str(row["method"]) == "protected"})
    records = []
    for case_id in ids:
        reference = lookup[(case_id, "vanilla")]
        candidate = lookup[(case_id, "candidate")]
        protected = lookup[(case_id, "protected")]
        records.append(
            {
                "partition": str(protected.get("partition", "")),
                "id": case_id,
                "protected_iou_delta": float(protected["foreground_iou"])
                - float(reference["foreground_iou"]),
                "candidate_iou_delta": float(candidate["foreground_iou"])
                - float(reference["foreground_iou"]),
                "protected_concavity_delta": float(protected["concavity_score"])
                - float(reference["concavity_score"]),
                "candidate_concavity_delta": float(candidate["concavity_score"])
                - float(reference["concavity_score"]),
            }
        )
    return sorted(records, key=lambda row: (row["protected_iou_delta"], row["protected_concavity_delta"]))[:limit]


def apply_rule_predictions(
    reference_logits: np.ndarray,
    candidate_logits: np.ndarray,
    rule: dict[str, object],
    fov: np.ndarray,
) -> tuple[dict[str, np.ndarray], np.ndarray, dict[str, np.ndarray]]:
    features = prediction_features(reference_logits, candidate_logits, fov)
    use = gate_mask(features, rule)
    reference = reference_logits.argmax(axis=1)
    candidate = candidate_logits.argmax(axis=1)
    protected = reference.copy()
    protected[use] = candidate[use]
    return {"vanilla": reference, "candidate": candidate, "protected": protected}, use, features


def evaluate_synthetic_partition(
    label: str,
    archive: np.lib.npyio.NpzFile,
    indices: np.ndarray,
    reference_model: v2.ConcavityNetV2,
    candidate_model: v2.ConcavityNetV2,
    adapter: v2.InputAdapter,
    rule: dict[str, object],
    device: torch.device,
    args: argparse.Namespace,
) -> tuple[dict[str, object], list[dict[str, object]], dict[str, np.ndarray]]:
    indices = np.asarray(indices, dtype=np.int64)
    reference_logits = infer_archive(
        reference_model, adapter, archive, indices, device, args.batch_size, args.workers
    )
    candidate_logits = infer_archive(
        candidate_model, adapter, archive, indices, device, args.batch_size, args.workers
    )
    predictions, use, features = apply_rule_predictions(
        reference_logits, candidate_logits, rule, archive["fov_mask"].astype(bool)
    )
    truths = np.asarray(archive["labels"])[indices]
    indentations = np.asarray(archive["indentation_masks"])[indices]
    if "sample_ids" in archive.files:
        ids = np.asarray(archive["sample_ids"])[indices]
    else:
        ids = np.asarray([f"{label}/{int(index):04d}" for index in indices])
    rows = case_rows(ids, truths, indentations, predictions, include_ktc_ssim=False)
    rows = [{"partition": label, **row} for row in rows]
    summary = {
        "methods": aggregate_method_rows(rows),
        "protected_changed_cases": int(use.sum()),
        "protected_changed_fraction": float(use.mean()),
        "bootstrap_candidate_minus_vanilla": paired_bootstrap(
            rows, "candidate", "vanilla", args.bootstrap_repetitions, args.seed + 101
        ),
        "bootstrap_protected_minus_vanilla": paired_bootstrap(
            rows, "protected", "vanilla", args.bootstrap_repetitions, args.seed + 103
        ),
    }
    if "family_codes" in archive.files:
        family_names = STRESS_FAMILIES if label == "deep_concavity_stress_test" else BIOLOGICAL_FAMILIES
        codes = np.asarray(archive["family_codes"])[indices]
        family_summary: dict[str, object] = {}
        for code in np.unique(codes):
            code_value = int(code)
            if code_value < 0:
                continue
            family = family_names[code_value] if code_value < len(family_names) else f"family_{code_value}"
            selected_ids = set(str(value) for value in ids[codes == code])
            selected_rows = [row for row in rows if str(row["id"]) in selected_ids]
            family_summary[family] = {
                "methods": aggregate_method_rows(selected_rows),
                "bootstrap_protected_minus_vanilla": paired_bootstrap(
                    selected_rows,
                    "protected",
                    "vanilla",
                    args.bootstrap_repetitions,
                    args.seed + 131 + code_value,
                ),
            }
        if family_summary:
            summary["families"] = family_summary
    saved = {
        f"{label}_ids": ids,
        f"{label}_truth": truths,
        **{f"{label}_{name}": value for name, value in predictions.items()},
        f"{label}_gate": use.astype(np.uint8),
        **{f"{label}_feature_{name}": value for name, value in features.items()},
    }
    return summary, rows, saved


def main() -> None:
    args = parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required for final neural-network evaluation")
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda")
    joint = CachedArchive(np.load(args.dataset.resolve(), allow_pickle=False))
    stress = CachedArchive(np.load(args.stress_dataset.resolve(), allow_pickle=False))
    adapter = v2.InputAdapter(joint["fov_mask"]).to(device)
    reference_model = load_model(args.reference_checkpoint, "vanilla", device)
    candidate_model = load_model(args.candidate_checkpoint, args.candidate_architecture, device)

    # Fit and freeze the protection rule before using any test truth.
    validation_indices = np.asarray(joint["validation_indices"], dtype=np.int64)
    reference_validation_logits = infer_archive(
        reference_model, adapter, joint, validation_indices, device, args.batch_size, args.workers
    )
    candidate_validation_logits = infer_archive(
        candidate_model, adapter, joint, validation_indices, device, args.batch_size, args.workers
    )
    validation_features = prediction_features(
        reference_validation_logits,
        candidate_validation_logits,
        joint["fov_mask"].astype(bool),
    )
    validation_truths = np.asarray(joint["labels"])[validation_indices]
    validation_indentations = np.asarray(joint["indentation_masks"])[validation_indices]
    reference_validation_metrics = metric_arrays(
        validation_truths, validation_indentations, reference_validation_logits.argmax(axis=1)
    )
    candidate_validation_metrics = metric_arrays(
        validation_truths, validation_indentations, candidate_validation_logits.argmax(axis=1)
    )
    gate = fit_protection_gate(
        validation_features,
        reference_validation_metrics,
        candidate_validation_metrics,
        validation_indentations.reshape(len(validation_indices), -1).sum(axis=1),
        np.asarray(joint["sample_source"])[validation_indices],
        args,
    )
    frozen_rule = gate["selected_rule"]
    (output_dir / "frozen_gate.json").write_text(
        json.dumps(gate, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"frozen validation-only rule: {json.dumps(frozen_rule, ensure_ascii=False)}", flush=True)

    partitions = {
        "legacy_test": (joint, np.asarray(joint["legacy_test_indices"], dtype=np.int64)),
        "biological_held_out_test": (
            joint,
            np.asarray(joint["biological_test_indices"], dtype=np.int64),
        ),
        "deep_concavity_stress_test": (
            stress,
            np.asarray(stress["test_indices"], dtype=np.int64),
        ),
    }
    synthetic_summary: dict[str, object] = {}
    synthetic_rows: list[dict[str, object]] = []
    saved_predictions: dict[str, np.ndarray] = {}
    for offset, (label, (archive, indices)) in enumerate(partitions.items()):
        summary, rows, saved = evaluate_synthetic_partition(
            label,
            archive,
            indices,
            reference_model,
            candidate_model,
            adapter,
            frozen_rule,
            device,
            args,
        )
        synthetic_summary[label] = summary
        synthetic_rows.extend(rows)
        saved_predictions.update(saved)
        print(f"completed {label}: {summary['methods']}", flush=True)

    # Apply the already-frozen rule to KTC predictions before loading labels.
    real_images = np.asarray(joint["real_linear_images"])
    real_voltages = np.asarray(joint["real_voltages"])
    real_ids = np.asarray(joint["real_ids"])
    reference_real_logits = infer_arrays(
        reference_model, adapter, real_images, real_voltages, device, args.batch_size
    )
    candidate_real_logits = infer_arrays(
        candidate_model, adapter, real_images, real_voltages, device, args.batch_size
    )
    real_features = prediction_features(
        reference_real_logits, candidate_real_logits, joint["fov_mask"].astype(bool)
    )
    real_use = gate_mask(real_features, frozen_rule)
    reference_256 = F.interpolate(
        torch.from_numpy(reference_real_logits), size=(256, 256), mode="bilinear", align_corners=False
    ).argmax(dim=1).numpy()
    candidate_256 = F.interpolate(
        torch.from_numpy(candidate_real_logits), size=(256, 256), mode="bilinear", align_corners=False
    ).argmax(dim=1).numpy()
    protected_256 = reference_256.copy()
    protected_256[real_use] = candidate_256[real_use]
    fov = joint["fov_mask"].astype(bool)
    ridge_64 = np.stack([base.multi_otsu_labels(image, fov) for image in real_images])
    ridge_256 = np.repeat(np.repeat(ridge_64, 4, axis=1), 4, axis=2)
    real_predictions = {
        "ridge": ridge_256,
        "vanilla": reference_256,
        "candidate": candidate_256,
        "protected": protected_256,
    }

    real_truths = np.asarray(joint["real_labels"])
    real_indentations = np.stack([base.indentation_mask(truth) for truth in real_truths])
    real_rows = case_rows(real_ids, real_truths, real_indentations, real_predictions, include_ktc_ssim=True)
    real_rows = [{"partition": "ktc2023_evaluation", **row} for row in real_rows]
    real_summary: dict[str, object] = {
        "all_21": aggregate_method_rows(real_rows),
        "protected_changed_cases": int(real_use.sum()),
        "protected_changed_ids": [str(value) for value in real_ids[real_use]],
        "bootstrap_candidate_minus_vanilla": paired_bootstrap(
            real_rows, "candidate", "vanilla", args.bootstrap_repetitions, args.seed + 211
        ),
        "bootstrap_protected_minus_vanilla": paired_bootstrap(
            real_rows, "protected", "vanilla", args.bootstrap_repetitions, args.seed + 223
        ),
    }
    if args.audit.resolve().exists():
        audit = json.loads(args.audit.resolve().read_text(encoding="utf-8"))
        strict_ids = set(str(value) for value in audit["nonconvex_ids"])
        strict_rows = [row for row in real_rows if str(row["id"]) in strict_ids]
        ordinary_rows = [row for row in real_rows if str(row["id"]) not in strict_ids]
        real_summary["audited_nonconvex"] = aggregate_method_rows(strict_rows)
        real_summary["audited_ordinary"] = aggregate_method_rows(ordinary_rows)
        real_summary["audited_nonconvex_bootstrap_protected_minus_vanilla"] = paired_bootstrap(
            strict_rows, "protected", "vanilla", args.bootstrap_repetitions, args.seed + 227
        )

    failures = {
        "synthetic_worst_protected_cases": failure_records(synthetic_rows),
        "ktc_worst_protected_cases": failure_records(real_rows),
        "ordering_rule": "ascending protected-minus-vanilla foreground IoU, then concavity score",
    }
    (output_dir / "failure_analysis.json").write_text(
        json.dumps(failures, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    write_case_rows(output_dir / "synthetic_case_metrics.csv", synthetic_rows)
    write_case_rows(output_dir / "real_case_metrics.csv", real_rows)
    np.savez_compressed(output_dir / "synthetic_predictions.npz", **saved_predictions)
    np.savez_compressed(
        output_dir / "real_predictions.npz",
        ids=real_ids,
        truth=real_truths,
        ridge=ridge_256,
        vanilla=reference_256,
        candidate=candidate_256,
        protected=protected_256,
        gate=real_use.astype(np.uint8),
        **{f"feature_{key}": value for key, value in real_features.items()},
    )
    base.save_real_montage(
        output_dir / "real_all_21_comparison.png", real_truths, real_ids, real_predictions, real_rows
    )
    base.save_focus_montage(
        output_dir / "real_most_concave_comparison.png", real_truths, real_ids, real_predictions, real_rows
    )
    worst_ids = [record["id"] for record in failures["ktc_worst_protected_cases"][:6]]
    worst_indices = np.asarray([list(map(str, real_ids)).index(case_id) for case_id in worst_ids], dtype=np.int64)
    worst_rows = [row for row in real_rows if str(row["id"]) in set(worst_ids)]
    base.save_real_montage(
        output_dir / "real_worst_protected_cases.png",
        real_truths[worst_indices],
        real_ids[worst_indices],
        {name: values[worst_indices] for name, values in real_predictions.items()},
        worst_rows,
    )

    result = {
        "dataset": str(args.dataset.resolve()),
        "stress_dataset": str(args.stress_dataset.resolve()),
        "reference_checkpoint": str(args.reference_checkpoint.resolve()),
        "candidate_checkpoint": str(args.candidate_checkpoint.resolve()),
        "candidate_architecture": args.candidate_architecture,
        "device": "cuda",
        "cuda_device_name": torch.cuda.get_device_name(0),
        "seed": args.seed,
        "gate": gate,
        "synthetic_tests": synthetic_summary,
        "ktc2023_untouched_evaluation": real_summary,
        "failure_analysis": failures,
        "test_truth_used_for_model_or_gate_selection": False,
        "ktc_predictions_and_gate_decisions_computed_before_evaluation_labels_loaded": True,
        "args": vars(args)
        | {
            "dataset": str(args.dataset),
            "stress_dataset": str(args.stress_dataset),
            "reference_checkpoint": str(args.reference_checkpoint),
            "candidate_checkpoint": str(args.candidate_checkpoint),
            "output_dir": str(args.output_dir),
            "audit": str(args.audit),
        },
    }
    (output_dir / "summary.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
