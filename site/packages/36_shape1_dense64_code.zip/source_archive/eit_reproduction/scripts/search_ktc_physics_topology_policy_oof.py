"""Exploratory level-OOF search for conservative physics/topology bay policies."""
from __future__ import annotations

import argparse
import csv
import json
from dataclasses import dataclass, asdict
from pathlib import Path

import numpy as np

from train_ktc_pairwise_topology_bay_oof import group_summary, target_utility
from train_ktc_setaware_pure_bay_oof import STRICT_INWARD_IDS, load_public_cases


@dataclass(frozen=True)
class Policy:
    score: str
    threshold: float
    max_removal: float
    min_fold_gain: float


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--cache-dir", type=Path, default=Path(r"E:\Codex\ktc_expanded_pure_bay_candidate_cache_seed20260820"))
    parser.add_argument("--target-dir", type=Path, default=Path(r"E:\Codex\ktc_expanded_pure_bay_training_targets_seed20260820"))
    parser.add_argument("--output-dir", type=Path, default=Path(r"E:\Codex\ktc_physics_topology_policy_oof_seed20260820"))
    parser.add_argument("--bootstrap-repetitions", type=int, default=2000)
    parser.add_argument("--seed", type=int, default=20260820)
    return parser.parse_args()


def robust_z(values: np.ndarray) -> np.ndarray:
    median = np.median(values, axis=0)
    lower, upper = np.quantile(values, (0.25, 0.75), axis=0)
    scale = (upper - lower) / 1.349
    scale = np.where(scale > 1e-6, scale, np.std(values, axis=0))
    return np.clip((values - median) / np.maximum(scale, 1e-6), -10, 10)


def score_bank(case) -> dict[str, np.ndarray]:
    x = case.features
    z = robust_z(x)
    cv = x[:, 72:76]
    fixed = x[:, 81:85]
    pool_delta = x[:, 98:111]
    output = {
        "cv_mean": x[:, 76], "cv_min": x[:, 78], "cv_positive": x[:, 80],
        "fixed_global": x[:, 81], "fixed_drive": x[:, 82],
        "fixed_cosine": x[:, 83], "fixed_hybrid": x[:, 84],
        "cv_consensus": 0.45 * x[:, 76] + 0.35 * x[:, 78] + 0.20 * x[:, 80],
        "cv_robust": cv.mean(1) - 0.6 * cv.std(1),
        "fixed_consensus": fixed.mean(1) - 0.5 * fixed.std(1),
        "pool_delta_mean": pool_delta.mean(1),
        "pool_delta_max": pool_delta.max(1),
        "background_vote": x[:, 117], "negative_foreground_vote": -x[:, 118],
        "cv_pool": z[:, 76] + 0.5 * z[:, 78] + 0.35 * z[:, 114] + 0.35 * z[:, 117],
        "fixed_pool": z[:, 81:85].mean(1) + 0.4 * z[:, 114] + 0.4 * z[:, 117],
    }
    for index in range(4):
        output[f"cv_fold_{index}"] = cv[:, index]
    for index in range(13):
        output[f"pool_model_{index}"] = pool_delta[:, index]
    for values in output.values():
        values[0] = 0.0
    return output


def choose(case, scores: dict[str, np.ndarray], policy: Policy) -> int:
    score = scores[policy.score]
    valid = case.valid.copy()
    valid &= case.removed <= policy.max_removal
    valid &= case.features[:, 78] >= policy.min_fold_gain
    valid[0] = True
    index = int(np.argmax(np.where(valid, score, -np.inf)))
    return index if score[index] >= policy.threshold else 0


def evaluate(cases, banks, policy: Policy):
    choices = np.asarray([choose(case, bank, policy) for case, bank in zip(cases, banks)])
    values = np.stack([case.targets[index] for case, index in zip(cases, choices)])
    changed = choices != 0
    finite_bay = np.isfinite(values[:, 2])
    joint = changed & (values[:, 0] >= 0.002) & finite_bay & (values[:, 2] >= 0.005)
    safe = (
        np.all(values[:, 0] >= -1e-9)
        and np.all(values[:, 1] >= -0.005)
        and np.all(values[changed & finite_bay, 2] >= -1e-9)
        and np.all(values[changed & np.isfinite(values[:, 4]), 4] >= -0.020)
    )
    utility = target_utility(values, np.asarray([case.removed[index] for case, index in zip(cases, choices)]))
    result = {
        "safe": bool(safe), "changed": int(changed.sum()),
        "joint": int(joint.sum()), "harmed_iou": int(np.count_nonzero(values[:, 0] < 0)),
        "mean_iou": float(values[:, 0].mean()), "mean_bay": float(np.nanmean(values[:, 2])),
        "utility": float(utility.mean()), "minimum_iou": float(values[:, 0].min()),
    }
    return choices, values, result


def policies() -> list[Policy]:
    names = [
        "cv_mean", "cv_min", "cv_positive", "fixed_global", "fixed_drive",
        "fixed_cosine", "fixed_hybrid", "cv_consensus", "cv_robust",
        "fixed_consensus", "pool_delta_mean", "pool_delta_max", "background_vote",
        "negative_foreground_vote", "cv_pool", "fixed_pool",
        *[f"cv_fold_{index}" for index in range(4)],
        *[f"pool_model_{index}" for index in range(13)],
    ]
    return [
        Policy(name, threshold, removal, fold_gain)
        for name in names
        for threshold in (0.0, 0.002, 0.005, 0.01, 0.02, 0.04, 0.08, 0.15, 0.30, 0.60, 1.0)
        for removal in (0.01, 0.02, 0.035, 0.05, 0.08)
        for fold_gain in (-2.0, -0.02, 0.0, 0.01, 0.03)
    ]


def write_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    args = parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    cases, truths, ids = load_public_cases(args)
    banks = [score_bank(case) for case in cases]
    levels = sorted({case.level for case in cases})
    policy_bank = policies()
    choices = np.zeros(len(cases), dtype=np.int64)
    fold_rows, search_rows = [], []
    for outer in levels:
        train_indices = [index for index, case in enumerate(cases) if case.level != outer]
        outer_indices = [index for index, case in enumerate(cases) if case.level == outer]
        ranked = []
        for policy in policy_bank:
            _, _, result = evaluate(
                [cases[index] for index in train_indices], [banks[index] for index in train_indices], policy
            )
            key = (
                int(result["safe"] and result["joint"] > 0), result["joint"],
                result["utility"], result["mean_iou"], -result["changed"],
            )
            ranked.append((key, policy, result))
        _, selected, train_result = max(ranked, key=lambda item: item[0])
        if not train_result["safe"] or train_result["joint"] < 1:
            selected = Policy("cv_mean", 1e9, 0.01, 1e9)
        outer_choices, outer_values, outer_result = evaluate(
            [cases[index] for index in outer_indices], [banks[index] for index in outer_indices], selected
        )
        choices[outer_indices] = outer_choices
        fold_rows.append({
            "outer_level": outer, **asdict(selected),
            **{f"train_{key}": value for key, value in train_result.items()},
            **{f"outer_{key}": value for key, value in outer_result.items()},
        })
        for index, value in zip(outer_indices, outer_values):
            search_rows.append({
                "id": cases[index].case_id, "strict_inward": cases[index].case_id in STRICT_INWARD_IDS,
                "choice": int(choices[index]), "delta_iou": float(value[0]),
                "delta_boundary_f1": float(value[1]), "delta_bay_f1": float(value[2]),
                "delta_bay_depth": float(value[4]), **asdict(selected),
            })
        print(f"{outer}: policy={selected}; train={train_result}; outer={outer_result}", flush=True)
    baseline = np.stack([case.candidates[0] for case in cases])
    prediction = np.stack([case.candidates[index] for case, index in zip(cases, choices)])
    strict = np.asarray([case.case_id in STRICT_INWARD_IDS for case in cases])
    groups = {
        "all": group_summary(np.ones(len(cases), bool), truths, baseline, prediction, args.bootstrap_repetitions, args.seed),
        "strict_inward": group_summary(strict, truths, baseline, prediction, args.bootstrap_repetitions, args.seed + 1),
        "ordinary": group_summary(~strict, truths, baseline, prediction, args.bootstrap_repetitions, args.seed + 2),
    }
    write_csv(output / "public_case_metrics.csv", search_rows)
    write_csv(output / "fold_policies.csv", fold_rows)
    np.savez_compressed(output / "predictions.npz", ids=ids, truth=truths, baseline=baseline, prediction=prediction, choices=choices)
    summary = {
        "method": "exploratory complete-level-held-out conservative physics/topology policy search",
        "strict_ids_used_for_selection": False,
        "outer_level_truth_used_for_selection": False,
        "candidate_constraints_inherited": "pure removal, exterior connected, no new holes, component preserving",
        "groups": groups,
    }
    (output / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(groups, indent=2), flush=True)


if __name__ == "__main__":
    main()
