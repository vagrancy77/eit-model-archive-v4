"""Combine a guarded topology path with a learned wide inward-cutout field.

The stable raw reconstruction remains the foreground anchor.  The candidate
action network decides whether an enclosed cavity may be connected to the
exterior.  A competitive Boolean network then widens only the accepted path,
using its cutout field while its bank field protects the two lesion sides.

All decoder parameters are selected on synthetic validation data.  Synthetic
test labels and the 21 public KTC2023 labels are read only after selection.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from scipy.ndimage import binary_dilation, label as connected_components, zoom
from torch.utils.data import DataLoader

from evaluate_ktc_candidate_opening_hybrid import infer_pair
from fuse_ktc_joint_shape_models import blend, load_model
from prepare_ktc_deep_concavity_stress import FAMILIES
from train_ktc_candidate_opening_refiner import (
    CandidateActionNet,
    apply_scored_actions,
    inference_records,
    paired_bootstrap,
    score_actions,
)
from train_ktc_competitive_boolean_network import (
    CompetitiveBooleanNet,
    collect_fields,
    infer_real_fields,
)
from train_ktc_concavity_network import InputAdapter, aggregate_rows
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_highres_refiner import load_coarse_ensemble
from train_ktc_implicit_boolean_network import (
    StructuralDataset,
    prepare_structural_arrays,
    standard_metrics,
    stress_metrics,
)


CORE_FAMILY_CODES = (0, 1, 2, 3, 4, 6)
PUBLIC_INWARD_BAY_IDS = (
    "level_2/1", "level_2/3", "level_3/2", "level_5/2", "level_6/2",
    "level_6/3", "level_7/1", "level_7/2", "level_7/3",
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument(
        "--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz"
    )
    parser.add_argument(
        "--competitive-checkpoint", type=Path,
        default=root / "outputs" / "ktc_competitive_boolean_v2_seed20260820" / "competitive_boolean_best.pt",
    )
    parser.add_argument(
        "--coarse-checkpoint", nargs="+", type=Path,
        default=[
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "boundary_best.pt",
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "indent_best.pt",
            root / "outputs" / "ktc_concavity_voltage_seed20260819" / "voltage_best.pt",
        ],
    )
    parser.add_argument("--coarse-weights", nargs="+", type=float, default=[0.30, 0.40, 0.30])
    parser.add_argument(
        "--action-checkpoint", type=Path, default=Path("E:/Codex/ktc_candidate_opening_seed20260820/best.pt")
    )
    parser.add_argument(
        "--path-summary", type=Path, default=Path("E:/Codex/ktc_candidate_hybrid_seed20260820/summary.json")
    )
    parser.add_argument(
        "--conservative", type=Path, default=Path("E:/Codex/ktc_joint_shape_pretrained_seed20260820/best.pt")
    )
    parser.add_argument(
        "--aggressive", type=Path, default=Path("E:/Codex/ktc_joint_shape_network_seed20260820/best.pt")
    )
    parser.add_argument(
        "--output-dir", type=Path, default=root / "outputs" / "ktc_bank_guarded_wide_cutout_seed20260820"
    )
    parser.add_argument("--batch-size", type=int, default=48)
    parser.add_argument("--seed", type=int, default=20260820)
    return parser.parse_args()


def load_action_model(path: Path, device: torch.device) -> tuple[CandidateActionNet, np.ndarray, np.ndarray]:
    state = torch.load(path.resolve(), map_location=device, weights_only=False)
    model = CandidateActionNet().to(device)
    model.load_state_dict(state["model"])
    model.eval()
    return model, np.asarray(state["feature_mean"]), np.asarray(state["feature_scale"])


def load_competitive_model(path: Path, device: torch.device) -> CompetitiveBooleanNet:
    state = torch.load(path.resolve(), map_location=device, weights_only=False)
    model = CompetitiveBooleanNet(int(state["base_channels"])).to(device)
    model.load_state_dict(state["model"])
    model.eval()
    return model


def infer_path_prediction(
    action_model: CandidateActionNet,
    feature_mean: np.ndarray,
    feature_scale: np.ndarray,
    images: np.ndarray,
    raw: np.ndarray,
    conservative: np.ndarray,
    aggressive: np.ndarray,
    device: torch.device,
    threshold: float,
    width_bonus: float,
    fallback_path: bool,
    scale: int = 1,
) -> tuple[np.ndarray, list[dict[str, object]]]:
    records = inference_records(images, raw, conservative, aggressive, scale=scale)
    score_actions(action_model, records, feature_mean, feature_scale, device)
    prediction, _, accepted = apply_scored_actions(raw, records, threshold, width_bonus, fallback_path)
    return prediction, accepted


def cavity_seed(foreground: np.ndarray, path_removed: np.ndarray) -> np.ndarray:
    background_components, count = connected_components(~foreground, structure=np.ones((3, 3), dtype=np.uint8))
    border_ids = np.unique(
        np.concatenate((background_components[0], background_components[-1], background_components[:, 0], background_components[:, -1]))
    )
    enclosed_ids = [component for component in range(1, count + 1) if component not in border_ids]
    near_path = binary_dilation(path_removed, structure=np.ones((3, 3), dtype=bool), iterations=2)
    seed = path_removed.copy()
    for component in enclosed_ids:
        cavity = background_components == component
        if np.any(binary_dilation(cavity, structure=np.ones((3, 3), dtype=bool)) & near_path):
            seed |= cavity
    return seed


def widen_one(
    raw: np.ndarray,
    path_prediction: np.ndarray,
    support_probability: np.ndarray,
    cutout_probability: np.ndarray,
    bank_probability: np.ndarray,
    cutout_threshold: float,
    bank_threshold: float,
    overlap_radius: int,
    minimum_component: int,
) -> np.ndarray:
    foreground = raw != 0
    path_removed = foreground & (path_prediction == 0)
    if not np.any(path_removed):
        return path_prediction.copy()
    proposed = (
        (cutout_probability >= cutout_threshold)
        & (bank_probability <= bank_threshold)
        & (support_probability >= 0.25)
    )
    components, count = connected_components(proposed, structure=np.ones((3, 3), dtype=np.uint8))
    seed = binary_dilation(
        cavity_seed(foreground, path_removed),
        structure=np.ones((3, 3), dtype=bool),
        iterations=overlap_radius,
    )
    keep_ids = []
    for component in range(1, count + 1):
        mask = components == component
        if int(mask.sum()) >= minimum_component and np.any(mask & seed):
            keep_ids.append(component)
    output = path_prediction.copy()
    if keep_ids:
        wide_cutout = np.isin(components, np.asarray(keep_ids)) & foreground
        output[wide_cutout] = 0
    return output


def apply_widening(
    raw: np.ndarray,
    path_prediction: np.ndarray,
    fields: dict[str, np.ndarray],
    cutout_threshold: float,
    bank_threshold: float,
    overlap_radius: int,
    minimum_component: int,
) -> np.ndarray:
    return np.stack([
        widen_one(
            raw[index], path_prediction[index], fields["support"][index, 0],
            fields["cutout_proposal"][index, 0], fields["bank"][index, 0],
            cutout_threshold, bank_threshold, overlap_radius, minimum_component,
        )
        for index in range(len(raw))
    ])


def core_metrics(
    stress: np.lib.npyio.NpzFile, indices: np.ndarray, prediction: np.ndarray
) -> tuple[dict[str, float], list[dict[str, float]]]:
    selected = np.isin(stress["family_codes"][indices], np.asarray(CORE_FAMILY_CODES))
    summary, _, rows = stress_metrics(
        stress["labels"][indices][selected], prediction[selected],
        stress["cutout_masks"][indices][selected], stress["cutout_depth_weights"][indices][selected],
        stress["family_codes"][indices][selected],
    )
    return summary, rows


def calibrate_widening(
    base: np.lib.npyio.NpzFile,
    stress: np.lib.npyio.NpzFile,
    base_indices: np.ndarray,
    stress_indices: np.ndarray,
    base_raw: np.ndarray,
    stress_raw: np.ndarray,
    base_path: np.ndarray,
    stress_path: np.ndarray,
    base_fields: dict[str, np.ndarray],
    stress_fields: dict[str, np.ndarray],
) -> tuple[dict[str, object], list[dict[str, object]]]:
    base_reference = standard_metrics(base["labels"][base_indices], base_raw, base["indentation_masks"][base_indices])
    core_path_reference, _ = core_metrics(stress, stress_indices, stress_path)
    candidates: list[dict[str, object]] = []
    for cutout_threshold in (0.25, 0.35, 0.45, 0.55, 0.65):
        for bank_threshold in (0.25, 0.35, 0.45, 0.55, 0.65):
            for overlap_radius in (1, 2, 3):
                for minimum_component in (3, 6):
                    base_prediction = apply_widening(
                        base_raw, base_path, base_fields, cutout_threshold, bank_threshold,
                        overlap_radius, minimum_component,
                    )
                    stress_prediction = apply_widening(
                        stress_raw, stress_path, stress_fields, cutout_threshold, bank_threshold,
                        overlap_radius, minimum_component,
                    )
                    base_metric = standard_metrics(
                        base["labels"][base_indices], base_prediction, base["indentation_masks"][base_indices]
                    )
                    core_metric, _ = core_metrics(stress, stress_indices, stress_prediction)
                    eligible = (
                        base_metric["foreground_iou"] >= base_reference["foreground_iou"] - 0.008
                        and core_metric["foreground_iou"] >= core_path_reference["foreground_iou"] - 0.012
                        and core_metric["bank_retention"] >= core_path_reference["bank_retention"] - 0.015
                    )
                    score = (
                        0.10 * base_metric["foreground_iou"]
                        + 0.14 * core_metric["foreground_iou"]
                        + 0.34 * core_metric["open_deep_cutout_recovery"]
                        + 0.16 * core_metric["bank_retention"]
                        + 0.26 * core_metric["topology_structural_joint"]
                    )
                    candidates.append({
                        "cutout_threshold": cutout_threshold,
                        "bank_threshold": bank_threshold,
                        "overlap_radius": overlap_radius,
                        "minimum_component": minimum_component,
                        "eligible": bool(eligible),
                        "score": float(score),
                        "base": base_metric,
                        "core": core_metric,
                    })
    eligible = [row for row in candidates if row["eligible"]]
    selected = max(eligible or candidates, key=lambda row: float(row["score"]))
    return selected, candidates


def save_stress_grid(
    path: Path,
    stress: np.lib.npyio.NpzFile,
    indices: np.ndarray,
    raw: np.ndarray,
    path_prediction: np.ndarray,
    competitive: np.ndarray,
    wide: np.ndarray,
) -> None:
    family_codes = stress["family_codes"][indices]
    focus = []
    for code in CORE_FAMILY_CODES:
        candidates = np.flatnonzero(family_codes == code)
        depth = stress["cutout_depth_weights"][indices][candidates].sum(axis=(1, 2))
        focus.append(int(candidates[int(np.argmax(depth))]))
    figure, axes = plt.subplots(len(focus), 5, figsize=(12.6, 2.3 * len(focus)), squeeze=False)
    columns = ("truth", "stable raw", "guarded path", "direct Boolean", "bank-guarded wide")
    for row, index in enumerate(focus):
        images = (stress["labels"][indices][index], raw[index], path_prediction[index], competitive[index], wide[index])
        for column, image in enumerate(images):
            axes[row, column].imshow(image, cmap="viridis", vmin=0, vmax=2, interpolation="nearest")
            axes[row, column].set_axis_off()
            if row == 0:
                axes[row, column].set_title(columns[column], fontsize=10)
        axes[row, 0].set_ylabel(FAMILIES[int(family_codes[index])], fontsize=9)
    figure.suptitle("Core inward-bay stress test: stable anchor plus bank-guarded wide cutout")
    figure.tight_layout()
    figure.savefig(path, dpi=190)
    plt.close(figure)


def save_real_grid(
    path: Path,
    truths: np.ndarray,
    ids: np.ndarray,
    raw: np.ndarray,
    path_prediction: np.ndarray,
    wide: np.ndarray,
) -> None:
    focus = [index for index, case_id in enumerate(ids) if str(case_id) in PUBLIC_INWARD_BAY_IDS]
    figure, axes = plt.subplots(len(focus), 5, figsize=(12.6, 2.35 * len(focus)), squeeze=False)
    for row, index in enumerate(focus):
        changed = (raw[index] != wide[index]).astype(np.uint8)
        images = (truths[index], raw[index], path_prediction[index], wide[index], changed)
        titles = ("truth", "stable raw", "guarded path", "bank-guarded wide", "changed pixels")
        for column, image in enumerate(images):
            axes[row, column].imshow(
                image, cmap="magma" if column == 4 else "viridis",
                vmin=0, vmax=1 if column == 4 else 2, interpolation="nearest",
            )
            axes[row, column].set_axis_off()
            if row == 0:
                axes[row, column].set_title(titles[column], fontsize=10)
        axes[row, 0].set_ylabel(str(ids[index]), fontsize=9)
    figure.suptitle("Public KTC2023 cases with an inward bay, notch, crescent, or reentrant boundary")
    figure.tight_layout()
    figure.savefig(path, dpi=185)
    plt.close(figure)


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    keys = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    args = parse_args()
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    base = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    base_arrays = prepare_structural_arrays(base, "base nonlinear CEM")
    stress_arrays = prepare_structural_arrays(stress, "deep-concavity stress")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    adapter = InputAdapter(base["fov_mask"]).to(device)

    conservative_model = load_model(args.conservative, device)
    aggressive_model = load_model(args.aggressive, device)
    action_model, feature_mean, feature_scale = load_action_model(args.action_checkpoint, device)
    path_selected = json.loads(args.path_summary.resolve().read_text(encoding="utf-8"))["selected"]
    action_threshold = float(path_selected["threshold"])
    width_bonus = float(path_selected["width_bonus"])
    fallback_path = bool(path_selected["fallback_path"])

    coarse, _, _ = load_coarse_ensemble(args.coarse_checkpoint, args.coarse_weights, device)
    competitive_model = load_competitive_model(args.competitive_checkpoint, device)

    base_validation = np.asarray(base["validation_indices"], dtype=np.int64)
    stress_validation = np.asarray(stress["validation_indices"], dtype=np.int64)
    base_conservative, base_aggressive = infer_pair(
        conservative_model, aggressive_model, adapter,
        base["linear_images"][base_validation], base["voltages"][base_validation], device, args.batch_size,
    )
    stress_conservative, stress_aggressive = infer_pair(
        conservative_model, aggressive_model, adapter,
        stress["linear_images"][stress_validation], stress["voltages"][stress_validation], device, args.batch_size,
    )
    base_raw = blend(base_conservative, base_aggressive, 0.5)
    stress_raw = blend(stress_conservative, stress_aggressive, 0.5)
    base_path, _ = infer_path_prediction(
        action_model, feature_mean, feature_scale, base["linear_images"][base_validation], base_raw,
        base_conservative, base_aggressive, device, action_threshold, width_bonus, fallback_path,
    )
    stress_path, _ = infer_path_prediction(
        action_model, feature_mean, feature_scale, stress["linear_images"][stress_validation], stress_raw,
        stress_conservative, stress_aggressive, device, action_threshold, width_bonus, fallback_path,
    )
    base_validation_loader = DataLoader(
        StructuralDataset(base_arrays, base_validation, 0), batch_size=args.batch_size, shuffle=False
    )
    stress_validation_loader = DataLoader(
        StructuralDataset(stress_arrays, stress_validation, 1), batch_size=args.batch_size, shuffle=False
    )
    base_fields = collect_fields(coarse, competitive_model, adapter, base_validation_loader, device)
    stress_fields = collect_fields(coarse, competitive_model, adapter, stress_validation_loader, device)
    selected, candidates = calibrate_widening(
        base, stress, base_validation, stress_validation, base_raw, stress_raw,
        base_path, stress_path, base_fields, stress_fields,
    )
    (output_dir / "validation_grid.json").write_text(json.dumps(candidates, indent=2), encoding="utf-8")
    print(f"selected widening decoder: {json.dumps(selected)}", flush=True)

    # Test truths are accessed only after all decoder choices above are frozen.
    base_test = np.asarray(base["test_indices"], dtype=np.int64)
    stress_test = np.asarray(stress["test_indices"], dtype=np.int64)
    base_conservative, base_aggressive = infer_pair(
        conservative_model, aggressive_model, adapter,
        base["linear_images"][base_test], base["voltages"][base_test], device, args.batch_size,
    )
    stress_conservative, stress_aggressive = infer_pair(
        conservative_model, aggressive_model, adapter,
        stress["linear_images"][stress_test], stress["voltages"][stress_test], device, args.batch_size,
    )
    base_raw = blend(base_conservative, base_aggressive, 0.5)
    stress_raw = blend(stress_conservative, stress_aggressive, 0.5)
    base_path, accepted_base = infer_path_prediction(
        action_model, feature_mean, feature_scale, base["linear_images"][base_test], base_raw,
        base_conservative, base_aggressive, device, action_threshold, width_bonus, fallback_path,
    )
    stress_path, accepted_stress = infer_path_prediction(
        action_model, feature_mean, feature_scale, stress["linear_images"][stress_test], stress_raw,
        stress_conservative, stress_aggressive, device, action_threshold, width_bonus, fallback_path,
    )
    base_test_loader = DataLoader(StructuralDataset(base_arrays, base_test, 0), batch_size=args.batch_size, shuffle=False)
    stress_test_loader = DataLoader(StructuralDataset(stress_arrays, stress_test, 1), batch_size=args.batch_size, shuffle=False)
    base_fields = collect_fields(coarse, competitive_model, adapter, base_test_loader, device)
    stress_fields = collect_fields(coarse, competitive_model, adapter, stress_test_loader, device)
    decoder = (
        float(selected["cutout_threshold"]), float(selected["bank_threshold"]),
        int(selected["overlap_radius"]), int(selected["minimum_component"]),
    )
    base_wide = apply_widening(base_raw, base_path, base_fields, *decoder)
    stress_wide = apply_widening(stress_raw, stress_path, stress_fields, *decoder)
    competitive_stress = (
        (stress_fields["support"][:, 0] >= 0.58)
        & ~(stress_fields["cutout"][:, 0] >= 0.28)
    ) * (stress_fields["polarity"].argmax(axis=1) + 1)
    competitive_stress = competitive_stress.astype(np.uint8)

    base_summary = {
        name: standard_metrics(base["labels"][base_test], prediction, base["indentation_masks"][base_test])
        for name, prediction in (("stable_raw", base_raw), ("guarded_path", base_path), ("bank_guarded_wide", base_wide))
    }
    stress_summary = {}
    stress_family = {}
    core_rows = {}
    for name, prediction in (
        ("stable_raw", stress_raw), ("guarded_path", stress_path),
        ("direct_competitive_boolean", competitive_stress), ("bank_guarded_wide", stress_wide),
    ):
        stress_summary[name], stress_family[name], _ = stress_metrics(
            stress["labels"][stress_test], prediction, stress["cutout_masks"][stress_test],
            stress["cutout_depth_weights"][stress_test], stress["family_codes"][stress_test],
        )
        _, core_rows[name] = core_metrics(stress, stress_test, prediction)
    core_summary = {name: core_metrics(stress, stress_test, prediction)[0] for name, prediction in (
        ("stable_raw", stress_raw), ("guarded_path", stress_path),
        ("direct_competitive_boolean", competitive_stress), ("bank_guarded_wide", stress_wide),
    )}
    bootstrap = paired_bootstrap(core_rows["guarded_path"], core_rows["bank_guarded_wide"], 10000, args.seed)

    real_conservative, real_aggressive = infer_pair(
        conservative_model, aggressive_model, adapter,
        base["real_linear_images"], base["real_voltages"], device, args.batch_size, 256,
    )
    real_raw = blend(real_conservative, real_aggressive, 0.5)
    real_images = zoom(base["real_linear_images"], (1.0, 4.0, 4.0), order=1)
    real_path, accepted_real = infer_path_prediction(
        action_model, feature_mean, feature_scale, real_images, real_raw,
        real_conservative, real_aggressive, device, action_threshold, width_bonus, fallback_path, scale=4,
    )
    real_fields = infer_real_fields(
        coarse, competitive_model, adapter, base["real_linear_images"], base["real_voltages"],
        device, args.batch_size,
    )
    real_wide = apply_widening(real_raw, real_path, real_fields, *decoder)
    real_summary = {}
    real_rows: list[dict[str, object]] = []
    for name, prediction in (("stable_raw", real_raw), ("guarded_path", real_path), ("bank_guarded_wide", real_wide)):
        real_summary[name], rows = evaluate_real_predictions(name, prediction, base["real_labels"], base["real_ids"])
        real_rows.extend(rows)
    public_bay_summary = {
        name: aggregate_rows([
            {key: float(value) for key, value in row.items() if key not in ("id", "method")}
            for row in real_rows if row["method"] == name and str(row["id"]) in PUBLIC_INWARD_BAY_IDS
        ])
        for name in ("stable_raw", "guarded_path", "bank_guarded_wide")
    }

    save_stress_grid(
        output_dir / "stress_core_comparison.png", stress, stress_test,
        stress_raw, stress_path, competitive_stress, stress_wide,
    )
    save_real_grid(
        output_dir / "public_inward_bay_comparison.png", base["real_labels"], base["real_ids"],
        real_raw, real_path, real_wide,
    )
    write_csv(output_dir / "real_case_metrics.csv", real_rows)
    write_csv(output_dir / "paired_bootstrap_core.csv", bootstrap)
    np.savez_compressed(
        output_dir / "predictions.npz",
        base_test_indices=base_test, base_raw=base_raw, base_path=base_path, base_wide=base_wide,
        stress_test_indices=stress_test, stress_raw=stress_raw, stress_path=stress_path,
        stress_competitive=competitive_stress, stress_wide=stress_wide,
        real_raw=real_raw, real_path=real_path, real_wide=real_wide,
        stress_cutout_probability=stress_fields["cutout_proposal"], stress_bank_probability=stress_fields["bank"],
        real_cutout_probability=real_fields["cutout_proposal"], real_bank_probability=real_fields["bank"],
    )
    result = {
        "method": "action-gated topology path plus bank-guarded learned wide cutout",
        "representation": "stable foreground anchor - accepted external connector - connected high-cutout/low-bank field",
        "selected_on_synthetic_validation": selected,
        "path_decoder_selected_on_synthetic_validation": path_selected,
        "test": {
            "base": base_summary,
            "stress_all": stress_summary,
            "stress_core_inward_families": core_summary,
            "stress_by_family": stress_family,
            "paired_bootstrap_guarded_path_to_wide": bootstrap,
            "accepted_actions": {
                "base": len(accepted_base), "stress": len(accepted_stress), "real": len(accepted_real),
            },
            "real_all_21": real_summary,
            "real_inward_bay_subset": {"ids": list(PUBLIC_INWARD_BAY_IDS), "metrics": public_bay_summary},
        },
        "core_inward_families": [FAMILIES[code] for code in CORE_FAMILY_CODES],
        "excluded_as_primary_targets": [FAMILIES[5], FAMILIES[7]],
        "evaluation_truth_used_for_selection": False,
        "device": str(device),
        "args": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
    }
    (output_dir / "summary.json").write_text(json.dumps(result, indent=2, default=str), encoding="utf-8")
    print(json.dumps({"selected": selected, "test": result["test"]}, indent=2, default=str), flush=True)


if __name__ == "__main__":
    main()
