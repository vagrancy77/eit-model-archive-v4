"""Train a case-wise reliability gate for non-convex EIT reconstruction.

The frozen implicit-Boolean network supplies a family of increasingly strong
support-minus-cutout experts.  A dual measurement/image encoder and explicit
topology descriptors decide whether a case should retain the coarse EIT image
or accept a mild/strong inward-boundary proposal.  Training utilities reward
only cutouts connected to the exterior, so an internal hole is not treated as
a recovered C/U-shaped bay.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import random
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy import ndimage as ndi
from scipy.spatial import cKDTree
from torch.utils.data import DataLoader, Dataset

from calibrate_ktc_implicit_boolean import RawFields, collect_raw_fields, predict_from_fields
from prepare_ktc_deep_concavity_stress import FAMILIES
from train_ktc_concavity_network import (
    InputAdapter,
    save_focus_montage,
    save_real_montage,
    write_rows,
)
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_highres_refiner import load_coarse_ensemble
from train_ktc_implicit_boolean_network import (
    ImplicitBooleanNet,
    prepare_structural_arrays,
    standard_metrics,
    stress_metrics,
)


CANDIDATE_SPECS: tuple[tuple[str, float, float, float] | tuple[str, None, None, None], ...] = (
    ("coarse_identity", None, None, None),
    ("very_safe", -2.50, 0.35, 0.70),
    ("safe", -2.25, 0.35, 1.00),
    ("calibrated", -2.00, 0.35, 1.00),
    ("mild", -1.75, 0.50, 0.85),
    ("balanced", -1.75, 0.65, 1.00),
    ("moderate", -1.50, 0.65, 0.85),
    ("strong", -1.50, 0.80, 1.00),
    ("v1_default", -1.25, 1.00, 1.00),
)
GAIN_SCALE = 25.0


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument(
        "--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz"
    )
    parser.add_argument(
        "--implicit-checkpoint", type=Path,
        default=root / "outputs" / "ktc_implicit_boolean_seed20260829" / "implicit_boolean_best.pt",
    )
    parser.add_argument(
        "--coarse-checkpoint", nargs="+", type=Path,
        default=[
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "boundary_best.pt",
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "indent_best.pt",
            root / "outputs" / "ktc_concavity_voltage_seed20260819" / "voltage_best.pt",
        ],
    )
    parser.add_argument("--coarse-weights", nargs="+", type=float, default=[0.30, 0.40, 0.30])
    parser.add_argument(
        "--output-dir", type=Path, default=root / "outputs" / "ktc_reliability_gate_seed20260901"
    )
    parser.add_argument("--epochs", type=int, default=80)
    parser.add_argument("--patience", type=int, default=14)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--inference-batch-size", type=int, default=24)
    parser.add_argument("--learning-rate", type=float, default=1.2e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--seed", type=int, default=20260901)
    parser.add_argument("--base-iou-tolerance", type=float, default=0.005)
    parser.add_argument("--base-boundary-tolerance", type=float, default=0.005)
    parser.add_argument("--stress-iou-tolerance", type=float, default=0.010)
    parser.add_argument("--min-bank-retention", type=float, default=0.82)
    parser.add_argument(
        "--pretrained-gate", type=Path, default=None,
        help="Reuse a frozen reliability-gate checkpoint instead of retraining it.",
    )
    parser.add_argument(
        "--ood-quantile", type=float, default=0.99,
        help="Synthetic-validation quantile used as the nearest-neighbour OOD cutoff.",
    )
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def build_candidates(fields: RawFields, output_size: int | None = None) -> np.ndarray:
    predictions: list[np.ndarray] = []
    for _, bias, support_scale, cutout_scale in CANDIDATE_SPECS:
        if bias is None:
            logits = torch.from_numpy(np.log(np.clip(fields.coarse_probability, 1e-7, None)))
            if output_size is not None and logits.shape[-1] != output_size:
                logits = F.interpolate(
                    logits, size=(output_size, output_size), mode="bilinear", align_corners=False
                )
            predictions.append(logits.argmax(dim=1).numpy().astype(np.uint8))
        else:
            predictions.append(
                predict_from_fields(
                    fields, float(bias), float(support_scale), float(cutout_scale), output_size=output_size
                )
            )
    return np.stack(predictions)


def normalized_linear_images(images: np.ndarray, fov: np.ndarray) -> np.ndarray:
    selected = images[:, fov]
    center = np.median(selected, axis=1, keepdims=True)
    centered = images - center[:, :, None]
    scale = np.quantile(np.abs(centered[:, fov]), 0.985, axis=1).clip(1e-6)
    return np.clip(centered / scale[:, None, None], -3.0, 3.0).astype(np.float32)


def topology_features(
    fields: RawFields,
    candidates: np.ndarray,
    images: np.ndarray,
    voltages: np.ndarray,
    fov_mask: np.ndarray,
) -> np.ndarray:
    count = candidates.shape[1]
    fov = np.asarray(fov_mask, dtype=bool)
    fov_area = max(1, int(fov.sum()))
    normalized_image = normalized_linear_images(images, fov)
    voltage_center = np.median(voltages, axis=1, keepdims=True)
    voltage_centered = voltages - voltage_center
    voltage_scale = np.quantile(np.abs(voltage_centered), 0.985, axis=1, keepdims=True).clip(1e-6)
    normalized_voltages = np.clip(voltage_centered / voltage_scale, -4.0, 4.0)
    coarse = candidates[0]
    rows = np.zeros((count, len(CANDIDATE_SPECS) * 8 + 20), dtype=np.float32)
    structure = ndi.generate_binary_structure(2, 2)
    for sample in range(count):
        offset = 0
        coarse_fg = coarse[sample] != 0
        for candidate in candidates[:, sample]:
            foreground = candidate != 0
            removed = coarse_fg & ~foreground
            added = foreground & ~coarse_fg
            components, component_count = ndi.label(foreground, structure=structure)
            holes = ndi.binary_fill_holes(foreground) & ~foreground
            foreground_values = normalized_image[sample][foreground & fov]
            negative_values = normalized_image[sample][candidate == 1]
            positive_values = normalized_image[sample][candidate == 2]
            evidence = float(np.mean(np.abs(foreground_values))) if foreground_values.size else 0.0
            sign_evidence = 0.0
            sign_terms = 0
            if negative_values.size:
                sign_evidence += float(np.mean(-negative_values))
                sign_terms += 1
            if positive_values.size:
                sign_evidence += float(np.mean(positive_values))
                sign_terms += 1
            if sign_terms:
                sign_evidence /= sign_terms
            rows[sample, offset : offset + 8] = (
                foreground.sum() / fov_area,
                np.logical_xor(foreground, coarse_fg).sum() / fov_area,
                removed.sum() / fov_area,
                added.sum() / fov_area,
                holes.sum() / fov_area,
                min(component_count, 8) / 8.0,
                evidence,
                sign_evidence,
            )
            offset += 8
        coarse_entropy = -np.sum(
            fields.coarse_probability[sample] * np.log(np.clip(fields.coarse_probability[sample], 1e-7, None)),
            axis=0,
        )
        summaries = []
        for array in (
            fields.coarse_field[sample], fields.support_residual[sample], fields.cutout_residual[sample],
        ):
            summaries.extend(np.quantile(array[fov], [0.05, 0.25, 0.50, 0.75, 0.95]).tolist())
        summaries.extend(
            (
                float(np.mean(coarse_entropy[fov])),
                float(np.quantile(coarse_entropy[fov], 0.90)),
                float(np.sqrt(np.mean(np.square(normalized_voltages[sample])))),
                float(np.quantile(np.abs(normalized_voltages[sample]), 0.90)),
                float(np.quantile(np.abs(normalized_voltages[sample]), 0.99)),
            )
        )
        rows[sample, offset:] = summaries
    return rows


def candidate_utilities(
    truths: np.ndarray,
    candidates: np.ndarray,
    cutouts: np.ndarray,
    depths: np.ndarray,
    stress_source: bool,
) -> np.ndarray:
    utilities = np.empty((len(truths), len(CANDIDATE_SPECS)), dtype=np.float32)
    dummy_family = np.zeros(len(truths), dtype=np.int16)
    for candidate_index, prediction in enumerate(candidates):
        _, _, rows = stress_metrics(truths, prediction, cutouts, depths, dummy_family)
        for sample, row in enumerate(rows):
            # Use one definition on both data sources.  Source-dependent
            # utilities make an identical measurement imply two targets and
            # teach the gate dataset identity rather than reconstruction risk.
            utilities[sample, candidate_index] = (
                0.55 * row["foreground_iou"]
                + 0.20 * row["boundary_f1"]
                + 0.15 * row["open_deep_cutout_recovery"]
                + 0.10 * row["bank_retention"]
            )
    return utilities


@dataclass
class GateArrays:
    images: np.ndarray
    voltages: np.ndarray
    features: np.ndarray
    utilities: np.ndarray


class GateDataset(Dataset):
    def __init__(self, arrays: GateArrays) -> None:
        self.arrays = arrays

    def __len__(self) -> int:
        return len(self.arrays.images)

    def __getitem__(self, index: int) -> dict[str, torch.Tensor]:
        return {
            "image": torch.from_numpy(self.arrays.images[index][None].astype(np.float32)),
            "voltage": torch.from_numpy(self.arrays.voltages[index].astype(np.float32)),
            "features": torch.from_numpy(self.arrays.features[index].astype(np.float32)),
            "utility": torch.from_numpy(self.arrays.utilities[index].astype(np.float32)),
        }


class ConvBranch(nn.Module):
    def __init__(self, input_channels: int, output_channels: int) -> None:
        super().__init__()
        self.network = nn.Sequential(
            nn.Conv2d(input_channels, 16, 5, stride=2, padding=2, bias=False),
            nn.GroupNorm(4, 16), nn.SiLU(),
            nn.Conv2d(16, 32, 3, stride=2, padding=1, bias=False),
            nn.GroupNorm(8, 32), nn.SiLU(),
            nn.Conv2d(32, 64, 3, stride=2, padding=1, bias=False),
            nn.GroupNorm(8, 64), nn.SiLU(),
            nn.Conv2d(64, output_channels, 3, stride=2, padding=1, bias=False),
            nn.GroupNorm(8, output_channels), nn.SiLU(),
            nn.AdaptiveAvgPool2d(1), nn.Flatten(),
        )

    def forward(self, value: torch.Tensor) -> torch.Tensor:
        return self.network(value)


class ReliabilityGate(nn.Module):
    def __init__(self, feature_count: int, candidate_count: int) -> None:
        super().__init__()
        self.voltage_branch = ConvBranch(1, 96)
        self.image_branch = ConvBranch(1, 64)
        self.feature_branch = nn.Sequential(
            nn.Linear(feature_count, 128), nn.LayerNorm(128), nn.SiLU(), nn.Dropout(0.10),
            nn.Linear(128, 64), nn.SiLU(),
        )
        self.fusion = nn.Sequential(
            nn.Linear(224, 160), nn.LayerNorm(160), nn.SiLU(), nn.Dropout(0.15),
            nn.Linear(160, 96), nn.SiLU(), nn.Linear(96, candidate_count - 1),
        )

    @staticmethod
    def normalize_image(image: torch.Tensor) -> torch.Tensor:
        flattened = image.flatten(1)
        center = flattened.median(dim=1, keepdim=True).values
        centered = flattened - center
        scale = torch.quantile(centered.abs(), 0.985, dim=1, keepdim=True).clamp_min(1e-6)
        return torch.clamp(centered / scale, -3.0, 3.0).reshape_as(image) / 3.0

    @staticmethod
    def voltage_table(voltage: torch.Tensor) -> torch.Tensor:
        centered = voltage - voltage.median(dim=1, keepdim=True).values
        scale = torch.quantile(centered.abs(), 0.985, dim=1, keepdim=True).clamp_min(1e-6)
        return (torch.clamp(centered / scale, -4.0, 4.0) / 4.0).reshape(-1, 1, 76, 31)

    def forward(self, image: torch.Tensor, voltage: torch.Tensor, features: torch.Tensor) -> torch.Tensor:
        encoded = torch.cat(
            (
                self.voltage_branch(self.voltage_table(voltage)),
                self.image_branch(self.normalize_image(image)),
                self.feature_branch(features),
            ),
            dim=1,
        )
        noncoarse_gain = self.fusion(encoded)
        return torch.cat((torch.zeros_like(noncoarse_gain[:, :1]), noncoarse_gain), dim=1)


@torch.no_grad()
def gate_logits(
    model: ReliabilityGate,
    arrays: GateArrays,
    device: torch.device,
    batch_size: int,
) -> np.ndarray:
    loader = DataLoader(GateDataset(arrays), batch_size=batch_size, shuffle=False)
    result: list[np.ndarray] = []
    model.eval()
    for batch in loader:
        logits = model(
            batch["image"].to(device), batch["voltage"].to(device), batch["features"].to(device)
        )
        result.append(logits.cpu().numpy())
    return np.concatenate(result)


def train_gate(
    train: GateArrays,
    validation: GateArrays,
    device: torch.device,
    args: argparse.Namespace,
    output_dir: Path,
) -> tuple[ReliabilityGate, list[dict[str, float]]]:
    model = ReliabilityGate(train.features.shape[1], train.utilities.shape[1]).to(device)
    loader = DataLoader(
        GateDataset(train), batch_size=args.batch_size, shuffle=True,
        pin_memory=device.type == "cuda", drop_last=False,
    )
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    history: list[dict[str, float]] = []
    best_score = -math.inf
    stale = 0
    checkpoint = output_dir / "reliability_gate_best.pt"
    for epoch in range(1, args.epochs + 1):
        model.train()
        losses: list[float] = []
        for batch in loader:
            image = batch["image"].to(device, non_blocking=True)
            voltage = batch["voltage"].to(device, non_blocking=True)
            features = batch["features"].to(device, non_blocking=True)
            utility = batch["utility"].to(device, non_blocking=True)
            oracle = utility.argmax(dim=1)
            target_gain = GAIN_SCALE * (utility - utility[:, :1])
            optimizer.zero_grad(set_to_none=True)
            with torch.amp.autocast("cuda", enabled=device.type == "cuda"):
                logits = model(image, voltage, features)
                regression = F.smooth_l1_loss(logits[:, 1:], target_gain[:, 1:], beta=0.20)
                ranking = F.cross_entropy(logits, oracle)
                loss = regression + 0.10 * ranking
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            scaler.step(optimizer)
            scaler.update()
            losses.append(float(loss.detach()))
        scheduler.step()
        logits = gate_logits(model, validation, device, args.batch_size)
        chosen = logits.argmax(axis=1)
        utility = validation.utilities[np.arange(len(chosen)), chosen]
        oracle_utility = validation.utilities.max(axis=1)
        score = float(np.mean(utility - oracle_utility))
        accuracy = float(np.mean(chosen == validation.utilities.argmax(axis=1)))
        record = {
            "epoch": float(epoch), "train_loss": float(np.mean(losses)),
            "validation_mean_regret": -score, "validation_oracle_accuracy": accuracy,
            "learning_rate": float(optimizer.param_groups[0]["lr"]),
        }
        history.append(record)
        if epoch == 1 or epoch % 5 == 0:
            print(
                f"epoch {epoch:03d}: loss={record['train_loss']:.4f}, "
                f"regret={record['validation_mean_regret']:.4f}, oracle_acc={accuracy:.3f}", flush=True,
            )
        if score > best_score + 1e-5:
            best_score = score
            stale = 0
            torch.save(
                {
                    "model": model.state_dict(), "feature_count": train.features.shape[1],
                    "candidate_specs": CANDIDATE_SPECS, "epoch": epoch,
                    "validation_mean_regret": -score,
                },
                checkpoint,
            )
        else:
            stale += 1
            if stale >= args.patience:
                print(f"early stopping at epoch {epoch}", flush=True)
                break
    state = torch.load(checkpoint, map_location=device, weights_only=False)
    model.load_state_dict(state["model"])
    model.eval()
    (output_dir / "training_history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    return model, history


def select_candidates(logits: np.ndarray, threshold: float) -> np.ndarray:
    noncoarse = logits[:, 1:].argmax(axis=1) + 1
    gain = logits[np.arange(len(logits)), noncoarse] - logits[:, 0]
    return np.where(gain >= threshold, noncoarse, 0).astype(np.int64)


def nearest_training_distances(train_features: np.ndarray, query_features: np.ndarray) -> np.ndarray:
    """Distance to the synthetic training support in standardized feature space."""
    tree = cKDTree(np.asarray(train_features, dtype=np.float64))
    distances, _ = tree.query(np.asarray(query_features, dtype=np.float64), k=1, workers=-1)
    return np.asarray(distances, dtype=np.float64)


def apply_ood_rejection(
    selected: np.ndarray, distances: np.ndarray, cutoff: float
) -> tuple[np.ndarray, np.ndarray]:
    accepted = np.asarray(distances) <= cutoff
    guarded = np.where(accepted, selected, 0).astype(np.int64)
    return guarded, accepted


def gather(candidates: np.ndarray, selected: np.ndarray) -> np.ndarray:
    return candidates[selected, np.arange(len(selected))]


def save_gate_stress_montage(
    path: Path,
    truths: np.ndarray,
    candidates: np.ndarray,
    gated: np.ndarray,
    cutouts: np.ndarray,
    family_codes: np.ndarray,
    selected: np.ndarray,
) -> None:
    indices = [
        next((index for index, value in enumerate(family_codes) if int(value) == code), None)
        for code in range(len(FAMILIES))
    ]
    indices = [index for index in indices if index is not None]
    figure, axes = plt.subplots(len(indices), 5, figsize=(13.2, 2.4 * len(indices)), squeeze=False)
    for row, index in enumerate(indices):
        images = (
            (truths[index], f"{FAMILIES[int(family_codes[index])]} truth"),
            (candidates[0, index], "coarse EIT"),
            (candidates[3, index], "global calibrated"),
            (gated[index], f"gated: {CANDIDATE_SPECS[int(selected[index])][0]}"),
            (cutouts[index], "true inward cutout"),
        )
        for column, (image, title) in enumerate(images):
            axes[row, column].imshow(image, cmap="viridis", vmin=0, vmax=2, interpolation="nearest")
            axes[row, column].set_title(title)
            axes[row, column].set_axis_off()
    figure.suptitle("Reliability-gated implicit Boolean EIT on independent stress cases")
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def write_selection_csv(
    path: Path,
    selected: np.ndarray,
    logits: np.ndarray,
    ids: np.ndarray | None = None,
    proposed: np.ndarray | None = None,
    ood_distances: np.ndarray | None = None,
    ood_cutoff: float | None = None,
) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        fieldnames = [
            "index", "id", "proposed_index", "proposed", "candidate_index", "candidate",
            "confidence", "noncoarse_margin", "ood_distance", "ood_cutoff", "in_distribution",
        ]
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        probabilities = torch.softmax(torch.from_numpy(logits), dim=1).numpy()
        for index, candidate in enumerate(selected):
            noncoarse = int(logits[index, 1:].argmax() + 1)
            proposal = int(proposed[index]) if proposed is not None else int(candidate)
            distance = float(ood_distances[index]) if ood_distances is not None else math.nan
            writer.writerow(
                {
                    "index": index, "id": str(ids[index]) if ids is not None else "",
                    "proposed_index": proposal, "proposed": CANDIDATE_SPECS[proposal][0],
                    "candidate_index": int(candidate), "candidate": CANDIDATE_SPECS[int(candidate)][0],
                    "confidence": float(probabilities[index, candidate]),
                    "noncoarse_margin": float(logits[index, noncoarse] - logits[index, 0]),
                    "ood_distance": distance,
                    "ood_cutoff": float(ood_cutoff) if ood_cutoff is not None else math.nan,
                    "in_distribution": bool(distance <= ood_cutoff) if ood_cutoff is not None else True,
                }
            )


def main() -> None:
    args = parse_args()
    if not 0.0 < args.ood_quantile <= 1.0:
        raise ValueError("--ood-quantile must be in (0, 1]")
    set_seed(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    base_archive = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress_archive = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    base_arrays = prepare_structural_arrays(base_archive, "base nonlinear CEM")
    stress_arrays = prepare_structural_arrays(stress_archive, "deep-concavity stress")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    coarse, _, coarse_weights = load_coarse_ensemble(args.coarse_checkpoint, args.coarse_weights, device)
    implicit_state = torch.load(args.implicit_checkpoint.resolve(), map_location=device, weights_only=False)
    implicit = ImplicitBooleanNet(int(implicit_state["base_channels"])).to(device)
    implicit.load_state_dict(implicit_state["model"])
    implicit.eval()
    adapter = InputAdapter(base_archive["fov_mask"]).to(device)
    fov = np.asarray(base_archive["fov_mask"], dtype=bool)

    split_data: dict[str, dict[str, object]] = {}
    for split_name, indices_name in (("train", "train_indices"), ("validation", "validation_indices")):
        for source, arrays, archive in (("base", base_arrays, base_archive), ("stress", stress_arrays, stress_archive)):
            indices = np.asarray(archive[indices_name], dtype=np.int64)
            print(f"collecting {source} {split_name}: {len(indices)} cases", flush=True)
            fields = collect_raw_fields(
                arrays.images[indices], arrays.voltages[indices], coarse, implicit, adapter,
                device, args.inference_batch_size,
            )
            candidates = build_candidates(fields)
            features = topology_features(fields, candidates, arrays.images[indices], arrays.voltages[indices], fov)
            utilities = candidate_utilities(
                arrays.labels[indices], candidates, arrays.cutout[indices], arrays.cutout_depth[indices],
                stress_source=source == "stress",
            )
            split_data[f"{source}_{split_name}"] = {
                "indices": indices, "fields": fields, "candidates": candidates,
                "features": features, "utilities": utilities,
            }

    base_train = split_data["base_train"]
    stress_train = split_data["stress_train"]
    base_validation = split_data["base_validation"]
    stress_validation = split_data["stress_validation"]
    train_features = np.concatenate((base_train["features"], stress_train["features"]))
    feature_mean = train_features.mean(axis=0)
    feature_std = train_features.std(axis=0).clip(1e-5)
    standardized_train_features = ((train_features - feature_mean) / feature_std).astype(np.float32)

    def gate_arrays(source: str, split: str, arrays: object) -> GateArrays:
        values = split_data[f"{source}_{split}"]
        indices = values["indices"]
        return GateArrays(
            images=arrays.images[indices], voltages=arrays.voltages[indices],
            features=((values["features"] - feature_mean) / feature_std).astype(np.float32),
            utilities=values["utilities"],
        )

    train = GateArrays(
        images=np.concatenate((base_arrays.images[base_train["indices"]], stress_arrays.images[stress_train["indices"]])),
        voltages=np.concatenate((base_arrays.voltages[base_train["indices"]], stress_arrays.voltages[stress_train["indices"]])),
        features=standardized_train_features,
        utilities=np.concatenate((base_train["utilities"], stress_train["utilities"])),
    )
    validation = GateArrays(
        images=np.concatenate((
            base_arrays.images[base_validation["indices"]], stress_arrays.images[stress_validation["indices"]]
        )),
        voltages=np.concatenate((
            base_arrays.voltages[base_validation["indices"]], stress_arrays.voltages[stress_validation["indices"]]
        )),
        features=np.concatenate((
            (base_validation["features"] - feature_mean) / feature_std,
            (stress_validation["features"] - feature_mean) / feature_std,
        )).astype(np.float32),
        utilities=np.concatenate((base_validation["utilities"], stress_validation["utilities"])),
    )
    np.savez_compressed(output_dir / "feature_normalization.npz", mean=feature_mean, std=feature_std)
    target_counts = np.bincount(train.utilities.argmax(axis=1), minlength=len(CANDIDATE_SPECS))
    print(f"oracle target counts={target_counts.tolist()}", flush=True)
    if args.pretrained_gate is None:
        model, history = train_gate(train, validation, device, args, output_dir)
        gate_checkpoint = output_dir / "reliability_gate_best.pt"
    else:
        gate_checkpoint = args.pretrained_gate.resolve()
        state = torch.load(gate_checkpoint, map_location=device, weights_only=False)
        if int(state["feature_count"]) != train.features.shape[1]:
            raise ValueError("pretrained reliability gate uses a different feature dimension")
        if tuple(tuple(value) for value in state["candidate_specs"]) != CANDIDATE_SPECS:
            raise ValueError("pretrained reliability gate uses different candidate specifications")
        model = ReliabilityGate(train.features.shape[1], train.utilities.shape[1]).to(device)
        model.load_state_dict(state["model"])
        model.eval()
        history = []
        print(f"loaded frozen reliability gate: {gate_checkpoint}", flush=True)

    validation_logits = gate_logits(model, validation, device, args.batch_size)
    validation_ood_distances = nearest_training_distances(standardized_train_features, validation.features)
    ood_cutoff = float(np.quantile(validation_ood_distances, args.ood_quantile, method="higher"))
    ood_quantiles = {
        str(value): float(np.quantile(validation_ood_distances, value, method="higher"))
        for value in (0.50, 0.90, 0.95, 0.975, 0.99, 0.995, 1.0)
    }
    print(
        f"frozen OOD cutoff={ood_cutoff:.6f} at synthetic-validation quantile={args.ood_quantile}",
        flush=True,
    )
    base_count = len(base_validation["indices"])
    base_logits = validation_logits[:base_count]
    stress_logits = validation_logits[base_count:]
    base_candidates = base_validation["candidates"]
    stress_candidates = stress_validation["candidates"]
    base_indices = base_validation["indices"]
    stress_indices = stress_validation["indices"]
    base_coarse_metrics = standard_metrics(
        base_arrays.labels[base_indices], base_candidates[0], base_arrays.indentation[base_indices]
    )
    stress_coarse_metrics, _, _ = stress_metrics(
        stress_arrays.labels[stress_indices], stress_candidates[0], stress_arrays.cutout[stress_indices],
        stress_arrays.cutout_depth[stress_indices], stress_arrays.family_codes[stress_indices],
    )
    threshold_rows: list[dict[str, object]] = []
    thresholds = [-1.0, -0.5, -0.25, 0.0, 0.10, 0.20, 0.35, 0.50, 0.75, 1.0, 1.5, 2.0, 3.0, 99.0]
    for threshold in thresholds:
        base_proposed = select_candidates(base_logits, threshold)
        stress_proposed = select_candidates(stress_logits, threshold)
        base_selected, base_accepted = apply_ood_rejection(
            base_proposed, validation_ood_distances[:base_count], ood_cutoff
        )
        stress_selected, stress_accepted = apply_ood_rejection(
            stress_proposed, validation_ood_distances[base_count:], ood_cutoff
        )
        base_prediction = gather(base_candidates, base_selected)
        stress_prediction = gather(stress_candidates, stress_selected)
        base_metric = standard_metrics(
            base_arrays.labels[base_indices], base_prediction, base_arrays.indentation[base_indices]
        )
        stress_metric, _, _ = stress_metrics(
            stress_arrays.labels[stress_indices], stress_prediction, stress_arrays.cutout[stress_indices],
            stress_arrays.cutout_depth[stress_indices], stress_arrays.family_codes[stress_indices],
        )
        eligible = (
            base_metric["foreground_iou"] >= base_coarse_metrics["foreground_iou"] - args.base_iou_tolerance
            and base_metric["boundary_f1"] >= base_coarse_metrics["boundary_f1"] - args.base_boundary_tolerance
            and stress_metric["foreground_iou"] >= stress_coarse_metrics["foreground_iou"] - args.stress_iou_tolerance
            and stress_metric["bank_retention"] >= args.min_bank_retention
        )
        threshold_rows.append(
            {
                "threshold": threshold, "eligible": bool(eligible),
                "base_iou": base_metric["foreground_iou"], "base_boundary_f1": base_metric["boundary_f1"],
                "stress_iou": stress_metric["foreground_iou"],
                "stress_boundary_f1": stress_metric["boundary_f1"],
                "stress_open_deep_cutout": stress_metric["open_deep_cutout_recovery"],
                "stress_bank_retention": stress_metric["bank_retention"],
                "stress_topology_joint": stress_metric["topology_structural_joint"],
                "base_noncoarse_rate": float(np.mean(base_selected != 0)),
                "stress_noncoarse_rate": float(np.mean(stress_selected != 0)),
                "base_ood_rejection_rate": float(np.mean(~base_accepted)),
                "stress_ood_rejection_rate": float(np.mean(~stress_accepted)),
            }
        )
    eligible_thresholds = [row for row in threshold_rows if row["eligible"]]
    selected_threshold = max(
        eligible_thresholds,
        key=lambda row: (row["stress_topology_joint"], row["stress_open_deep_cutout"], row["base_iou"]),
    ) if eligible_thresholds else max(threshold_rows, key=lambda row: row["base_iou"] + row["stress_iou"])
    with (output_dir / "validation_thresholds.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(threshold_rows[0]))
        writer.writeheader(); writer.writerows(threshold_rows)
    threshold = float(selected_threshold["threshold"])
    print(f"selected validation threshold={selected_threshold}", flush=True)

    # The test splits and public KTC truth are opened only after gate and threshold are frozen.
    final_data: dict[str, dict[str, object]] = {}
    for source, arrays, archive in (("base", base_arrays, base_archive), ("stress", stress_arrays, stress_archive)):
        indices = np.asarray(archive["test_indices"], dtype=np.int64)
        fields = collect_raw_fields(
            arrays.images[indices], arrays.voltages[indices], coarse, implicit, adapter,
            device, args.inference_batch_size,
        )
        candidates = build_candidates(fields)
        features = topology_features(fields, candidates, arrays.images[indices], arrays.voltages[indices], fov)
        gate_input = GateArrays(
            arrays.images[indices], arrays.voltages[indices],
            ((features - feature_mean) / feature_std).astype(np.float32),
            np.zeros((len(indices), len(CANDIDATE_SPECS)), dtype=np.float32),
        )
        logits = gate_logits(model, gate_input, device, args.batch_size)
        proposed = select_candidates(logits, threshold)
        ood_distances = nearest_training_distances(standardized_train_features, gate_input.features)
        selected, ood_accepted = apply_ood_rejection(proposed, ood_distances, ood_cutoff)
        final_data[source] = {
            "indices": indices, "fields": fields, "candidates": candidates,
            "logits": logits, "proposed": proposed, "selected": selected,
            "features": gate_input.features, "ood_distances": ood_distances, "ood_accepted": ood_accepted,
            "prediction": gather(candidates, selected),
        }

    base_test = final_data["base"]
    stress_test = final_data["stress"]
    base_test_summary = {
        "coarse_fusion": standard_metrics(
            base_arrays.labels[base_test["indices"]], base_test["candidates"][0],
            base_arrays.indentation[base_test["indices"]],
        ),
        "global_calibrated": standard_metrics(
            base_arrays.labels[base_test["indices"]], base_test["candidates"][3],
            base_arrays.indentation[base_test["indices"]],
        ),
        "reliability_gated": standard_metrics(
            base_arrays.labels[base_test["indices"]], base_test["prediction"],
            base_arrays.indentation[base_test["indices"]],
        ),
    }
    stress_test_summary: dict[str, dict[str, float]] = {}
    stress_by_family: dict[str, dict[str, dict[str, float]]] = {}
    for name, prediction in (
        ("coarse_fusion", stress_test["candidates"][0]),
        ("global_calibrated", stress_test["candidates"][3]),
        ("reliability_gated", stress_test["prediction"]),
    ):
        summary, family, _ = stress_metrics(
            stress_arrays.labels[stress_test["indices"]], prediction,
            stress_arrays.cutout[stress_test["indices"]], stress_arrays.cutout_depth[stress_test["indices"]],
            stress_arrays.family_codes[stress_test["indices"]],
        )
        stress_test_summary[name] = summary
        stress_by_family[name] = family

    real_fields = collect_raw_fields(
        base_archive["real_linear_images"], base_archive["real_voltages"], coarse, implicit, adapter,
        device, args.inference_batch_size,
    )
    real_candidates64 = build_candidates(real_fields)
    real_features = topology_features(
        real_fields, real_candidates64, base_archive["real_linear_images"], base_archive["real_voltages"], fov
    )
    real_input = GateArrays(
        base_archive["real_linear_images"], base_archive["real_voltages"],
        ((real_features - feature_mean) / feature_std).astype(np.float32),
        np.zeros((len(real_features), len(CANDIDATE_SPECS)), dtype=np.float32),
    )
    real_logits = gate_logits(model, real_input, device, args.batch_size)
    real_proposed = select_candidates(real_logits, threshold)
    real_ood_distances = nearest_training_distances(standardized_train_features, real_input.features)
    real_selected, real_ood_accepted = apply_ood_rejection(real_proposed, real_ood_distances, ood_cutoff)
    real_candidates = build_candidates(real_fields, output_size=256)
    real_prediction = gather(real_candidates, real_selected)
    real_truths = base_archive["real_labels"]
    real_ids = base_archive["real_ids"]
    real_predictions = {
        "coarse_fusion": real_candidates[0],
        "global_calibrated": real_candidates[3],
        "reliability_gated": real_prediction,
    }
    real_summary: dict[str, dict[str, float]] = {}
    real_rows: list[dict[str, object]] = []
    for name, prediction in real_predictions.items():
        real_summary[name], rows = evaluate_real_predictions(name, prediction, real_truths, real_ids)
        real_rows.extend(rows)
    write_rows(output_dir / "real_case_metrics.csv", real_rows)

    save_gate_stress_montage(
        output_dir / "stress_test_comparison.png",
        stress_arrays.labels[stress_test["indices"]], stress_test["candidates"], stress_test["prediction"],
        stress_arrays.cutout[stress_test["indices"]], stress_arrays.family_codes[stress_test["indices"]],
        stress_test["selected"],
    )
    save_real_montage(output_dir / "real_all_21_comparison.png", real_truths, real_ids, real_predictions, real_rows)
    save_focus_montage(
        output_dir / "real_most_concave_comparison.png", real_truths, real_ids, real_predictions, real_rows
    )
    write_selection_csv(
        output_dir / "base_test_gate.csv", base_test["selected"], base_test["logits"],
        proposed=base_test["proposed"], ood_distances=base_test["ood_distances"], ood_cutoff=ood_cutoff,
    )
    write_selection_csv(
        output_dir / "stress_test_gate.csv", stress_test["selected"], stress_test["logits"],
        proposed=stress_test["proposed"], ood_distances=stress_test["ood_distances"], ood_cutoff=ood_cutoff,
    )
    write_selection_csv(
        output_dir / "real_gate.csv", real_selected, real_logits, real_ids,
        proposed=real_proposed, ood_distances=real_ood_distances, ood_cutoff=ood_cutoff,
    )
    np.savez_compressed(
        output_dir / "predictions.npz",
        train_features=standardized_train_features, train_utilities=train.utilities,
        validation_features=validation.features, validation_utilities=validation.utilities,
        validation_ood_distances=validation_ood_distances,
        base_test_indices=base_test["indices"], base_candidates=base_test["candidates"],
        base_proposed=base_test["proposed"], base_selected=base_test["selected"],
        base_test_features=base_test["features"],
        base_ood_distances=base_test["ood_distances"], base_gated=base_test["prediction"],
        stress_test_indices=stress_test["indices"], stress_candidates=stress_test["candidates"],
        stress_proposed=stress_test["proposed"], stress_selected=stress_test["selected"],
        stress_test_features=stress_test["features"],
        stress_ood_distances=stress_test["ood_distances"], stress_gated=stress_test["prediction"],
        real_candidates=real_candidates, real_proposed=real_proposed, real_selected=real_selected,
        real_features=real_input.features, real_ood_distances=real_ood_distances, real_gated=real_prediction,
    )
    result = {
        "method": "measurement-conditioned case-wise reliability gate over implicit Boolean experts",
        "candidate_specs": CANDIDATE_SPECS,
        "selected_threshold": selected_threshold,
        "eligible_thresholds": len(eligible_thresholds),
        "ood_guard": {
            "reference": "standardized synthetic training topology features",
            "calibration": "nearest-neighbour distances on synthetic validation only",
            "quantile": args.ood_quantile,
            "cutoff": ood_cutoff,
            "validation_distance_quantiles": ood_quantiles,
        },
        "base_synthetic_untouched_test": base_test_summary,
        "deep_concavity_stress_untouched_test": stress_test_summary,
        "stress_by_family": stress_by_family,
        "real_evaluation": real_summary,
        "selection_counts": {
            "base_test_proposed": np.bincount(base_test["proposed"], minlength=len(CANDIDATE_SPECS)).tolist(),
            "base_test": np.bincount(base_test["selected"], minlength=len(CANDIDATE_SPECS)).tolist(),
            "stress_test_proposed": np.bincount(stress_test["proposed"], minlength=len(CANDIDATE_SPECS)).tolist(),
            "stress_test": np.bincount(stress_test["selected"], minlength=len(CANDIDATE_SPECS)).tolist(),
            "real_proposed": np.bincount(real_proposed, minlength=len(CANDIDATE_SPECS)).tolist(),
            "real": np.bincount(real_selected, minlength=len(CANDIDATE_SPECS)).tolist(),
        },
        "ood_rejection_rates": {
            "base_test": float(np.mean(~base_test["ood_accepted"])),
            "stress_test": float(np.mean(~stress_test["ood_accepted"])),
            "real": float(np.mean(~real_ood_accepted)),
        },
        "evaluation_truth_used_for_training_or_selection": False,
        "topology_definition": "cutout pixels count only when reconstructed background is connected to image exterior",
        "seed": args.seed, "device": str(device), "coarse_weights": coarse_weights,
        "implicit_checkpoint": str(args.implicit_checkpoint.resolve()),
        "gate_checkpoint": str(gate_checkpoint),
    }
    (output_dir / "summary.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
