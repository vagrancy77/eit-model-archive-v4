"""Calibrate an exterior-connected cutout layer for non-convex EIT shapes.

The implicit Boolean network predicts an outer support and an inward-background
field.  A global cutout threshold can recover a cavity while still sealing its
mouth.  This script replaces that decision with hysteresis connectivity: a
low-threshold cutout component is removed only when it contains a high-confidence
core and reaches the predicted outer-support boundary.  Parameters are selected
on the two validation splits; synthetic test truth and the 21 public KTC truths
are not accessed until selection is complete.
"""
from __future__ import annotations

import argparse
import csv
import heapq
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import binary_dilation, label as connected_components

from calibrate_ktc_implicit_boolean import collect_raw_fields, predict_from_fields
from prepare_ktc_deep_concavity_stress import FAMILIES
from train_ktc_concavity_network import InputAdapter, save_focus_montage, save_real_montage, write_rows
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_highres_refiner import load_coarse_ensemble
from train_ktc_implicit_boolean_network import (
    ImplicitBooleanNet,
    prepare_structural_arrays,
    standard_metrics,
    stress_metrics,
)


STRUCTURE = np.ones((3, 3), dtype=np.uint8)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument(
        "--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz"
    )
    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=root / "outputs" / "ktc_openmouth_boolean_smoke_seed20260819" / "implicit_boolean_best.pt",
    )
    parser.add_argument(
        "--topology-predictions",
        type=Path,
        default=root / "outputs" / "ktc_topology_boolean_balanced_seed20260819" / "predictions.npz",
    )
    parser.add_argument(
        "--coarse-checkpoint",
        nargs="+",
        type=Path,
        default=[
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "boundary_best.pt",
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "indent_best.pt",
            root / "outputs" / "ktc_concavity_voltage_seed20260819" / "voltage_best.pt",
        ],
    )
    parser.add_argument("--coarse-weights", nargs="+", type=float, default=[0.30, 0.40, 0.30])
    parser.add_argument(
        "--output-dir", type=Path, default=root / "outputs" / "ktc_connected_cutout_seed20260819"
    )
    parser.add_argument("--batch-size", type=int, default=24)
    parser.add_argument("--body-cutout-bias", type=float, default=-2.0)
    parser.add_argument("--body-support-scale", type=float, default=0.35)
    parser.add_argument("--body-cutout-scale", type=float, default=1.0)
    parser.add_argument("--link-cutout-bias", type=float, default=-1.25)
    parser.add_argument("--link-cutout-scale", type=float, default=1.0)
    parser.add_argument("--base-iou-tolerance", type=float, default=0.025)
    parser.add_argument("--stress-iou-tolerance", type=float, default=0.035)
    parser.add_argument("--min-bank-retention", type=float, default=0.70)
    return parser.parse_args()


def sigmoid_field(field: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(field / 0.36, -30.0, 30.0)))


def structural_probabilities(
    fields,
    support_scale: float,
    link_bias: float,
    link_scale: float,
) -> tuple[np.ndarray, np.ndarray]:
    support = sigmoid_field(0.55 * fields.coarse_field + support_scale * fields.support_residual)
    cutout = sigmoid_field(link_bias + link_scale * fields.cutout_residual)
    return support, cutout


def connected_cutout_masks(
    support_probability: np.ndarray,
    cutout_probability: np.ndarray,
    support_threshold: float,
    path_threshold: float,
    core_threshold: float,
    min_core_pixels: int,
) -> np.ndarray:
    """Return core cutouts plus a narrow minimum-cost path to the boundary.

    Removing a whole low-threshold component is too destructive for EIT: the
    network can assign moderately high cutout scores to an entire lesion bank.
    We therefore retain only high-confidence core components and connect each
    one to the outer support with a one-pixel geodesic path through the cutout
    score field.  The path is a structural post-processing layer, not a truth-
    dependent operation.
    """

    def shortest_path_to_boundary(
        seeds: np.ndarray,
        support: np.ndarray,
        score: np.ndarray,
    ) -> np.ndarray:
        height, width = support.shape
        boundary = support & binary_dilation(~support, structure=STRUCTURE)
        distances = np.full((height, width), np.inf, dtype=np.float32)
        previous = np.full((height, width, 2), -1, dtype=np.int16)
        queue: list[tuple[float, int, int]] = []
        for y, x in np.argwhere(seeds):
            distances[y, x] = 0.0
            heapq.heappush(queue, (0.0, int(y), int(x)))
        neighbours = (
            (-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)
        )
        target: tuple[int, int] | None = None
        while queue:
            distance, y, x = heapq.heappop(queue)
            if distance != float(distances[y, x]):
                continue
            if boundary[y, x]:
                target = (y, x)
                break
            for dy, dx in neighbours:
                ny, nx = y + dy, x + dx
                if ny < 0 or ny >= height or nx < 0 or nx >= width or not support[ny, nx]:
                    continue
                # A small length term favors a short entrance; the score term
                # keeps it in pixels the network already calls background.
                step = 0.20 + float((1.0 - score[ny, nx]) ** 2)
                candidate = distance + step
                if candidate < float(distances[ny, nx]):
                    distances[ny, nx] = candidate
                    previous[ny, nx] = (y, x)
                    heapq.heappush(queue, (candidate, ny, nx))
        path = np.zeros_like(support, dtype=bool)
        if target is None:
            return path
        y, x = target
        while y >= 0 and x >= 0:
            path[y, x] = True
            py, px = previous[y, x]
            if py < 0:
                break
            y, x = int(py), int(px)
        return path

    masks = np.zeros(support_probability.shape, dtype=bool)
    for index, (support_score, cutout_score) in enumerate(
        zip(support_probability, cutout_probability)
    ):
        support = support_score >= support_threshold
        high = support & (cutout_score >= core_threshold)
        if not high.any():
            continue
        components, count = connected_components(high, structure=STRUCTURE)
        for component_id in range(1, count + 1):
            component = components == component_id
            if int((component & high).sum()) < min_core_pixels:
                continue
            path = shortest_path_to_boundary(component, support, cutout_score)
            if not path.any():
                continue
            # The entrance may be weak in EIT.  The low threshold still enters
            # the path cost, but we do not reject a valid geodesic merely
            # because several mouth pixels fall below it.
            masks[index] |= component | path
    return masks


def apply_connected_cutout(
    body_prediction: np.ndarray,
    masks: np.ndarray,
    output_size: int | None = None,
) -> np.ndarray:
    prediction = body_prediction.copy()
    if output_size is not None and masks.shape[-1] != output_size:
        tensor = torch.from_numpy(masks[:, None].astype(np.float32))
        masks = F.interpolate(tensor, size=(output_size, output_size), mode="nearest")[:, 0].numpy() > 0.5
    prediction[masks] = 0
    return prediction


def predict_connected(
    fields,
    args: argparse.Namespace,
    support_threshold: float,
    path_threshold: float,
    core_threshold: float,
    min_core_pixels: int,
    output_size: int | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    body = predict_from_fields(
        fields,
        args.body_cutout_bias,
        args.body_support_scale,
        args.body_cutout_scale,
        output_size=output_size,
    )
    support, cutout = structural_probabilities(
        fields,
        args.body_support_scale,
        args.link_cutout_bias,
        args.link_cutout_scale,
    )
    masks = connected_cutout_masks(
        support, cutout, support_threshold, path_threshold, core_threshold, min_core_pixels
    )
    return apply_connected_cutout(body, masks, output_size), masks


def write_grid(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def save_stress_comparison(
    path: Path,
    truths: np.ndarray,
    coarse: np.ndarray,
    topology: np.ndarray,
    body: np.ndarray,
    connected: np.ndarray,
    cutouts: np.ndarray,
    family_codes: np.ndarray,
) -> None:
    indices = [
        next((i for i, value in enumerate(family_codes) if int(value) == code), None)
        for code in range(len(FAMILIES))
    ]
    indices = [i for i in indices if i is not None]
    figure, axes = plt.subplots(len(indices), 6, figsize=(15.2, 2.35 * len(indices)), squeeze=False)
    for row, index in enumerate(indices):
        family = FAMILIES[int(family_codes[index])]
        images = (
            (truths[index], f"{family} truth"),
            (coarse[index], "coarse EIT"),
            (topology[index], "topology balanced"),
            (body[index], "mouth body"),
            (connected[index], "connected cutout"),
            (cutouts[index], "true inward cutout"),
        )
        for column, (image, title) in enumerate(images):
            axes[row, column].imshow(image, cmap="viridis", vmin=0, vmax=2, interpolation="nearest")
            axes[row, column].set_title(title)
            axes[row, column].set_axis_off()
    figure.suptitle("Exterior-connected reconstruction of non-convex EIT targets")
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    base_archive = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress_archive = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    base_arrays = prepare_structural_arrays(base_archive, "base nonlinear CEM")
    stress_arrays = prepare_structural_arrays(stress_archive, "deep-concavity stress")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    coarse, _, coarse_weights = load_coarse_ensemble(args.coarse_checkpoint, args.coarse_weights, device)
    state = torch.load(args.checkpoint.resolve(), map_location=device, weights_only=False)
    model = ImplicitBooleanNet(int(state["base_channels"])).to(device)
    model.load_state_dict(state["model"])
    model.eval()
    adapter = InputAdapter(base_archive["fov_mask"]).to(device)

    base_validation_indices = np.asarray(base_archive["validation_indices"], dtype=np.int64)
    stress_validation_indices = np.asarray(stress_archive["validation_indices"], dtype=np.int64)
    print(f"device={device}; collecting validation fields", flush=True)
    base_validation_fields = collect_raw_fields(
        base_arrays.images[base_validation_indices], base_arrays.voltages[base_validation_indices],
        coarse, model, adapter, device, args.batch_size,
    )
    stress_validation_fields = collect_raw_fields(
        stress_arrays.images[stress_validation_indices], stress_arrays.voltages[stress_validation_indices],
        coarse, model, adapter, device, args.batch_size,
    )
    base_body_validation = predict_from_fields(
        base_validation_fields, args.body_cutout_bias, args.body_support_scale, args.body_cutout_scale
    )
    stress_body_validation = predict_from_fields(
        stress_validation_fields, args.body_cutout_bias, args.body_support_scale, args.body_cutout_scale
    )
    base_body_metric = standard_metrics(
        base_arrays.labels[base_validation_indices], base_body_validation,
        base_arrays.indentation[base_validation_indices],
    )
    stress_body_metric, _, _ = stress_metrics(
        stress_arrays.labels[stress_validation_indices], stress_body_validation,
        stress_arrays.cutout[stress_validation_indices], stress_arrays.cutout_depth[stress_validation_indices],
        stress_arrays.family_codes[stress_validation_indices],
    )
    base_support, base_cutout = structural_probabilities(
        base_validation_fields, args.body_support_scale, args.link_cutout_bias, args.link_cutout_scale
    )
    stress_support, stress_cutout = structural_probabilities(
        stress_validation_fields, args.body_support_scale, args.link_cutout_bias, args.link_cutout_scale
    )

    support_thresholds = (0.30, 0.40, 0.50, 0.60)
    path_thresholds = (0.05, 0.08, 0.12, 0.18, 0.25, 0.35)
    core_thresholds = (0.45, 0.60, 0.75, 0.88)
    min_core_values = (2, 5)
    grid_rows: list[dict[str, object]] = []
    for support_threshold in support_thresholds:
        for path_threshold in path_thresholds:
            for core_threshold in core_thresholds:
                if core_threshold <= path_threshold:
                    continue
                for min_core_pixels in min_core_values:
                    base_masks = connected_cutout_masks(
                        base_support, base_cutout, support_threshold, path_threshold,
                        core_threshold, min_core_pixels,
                    )
                    stress_masks = connected_cutout_masks(
                        stress_support, stress_cutout, support_threshold, path_threshold,
                        core_threshold, min_core_pixels,
                    )
                    base_prediction = apply_connected_cutout(base_body_validation, base_masks)
                    stress_prediction = apply_connected_cutout(stress_body_validation, stress_masks)
                    base_metric = standard_metrics(
                        base_arrays.labels[base_validation_indices], base_prediction,
                        base_arrays.indentation[base_validation_indices],
                    )
                    stress_metric, family_metric, _ = stress_metrics(
                        stress_arrays.labels[stress_validation_indices], stress_prediction,
                        stress_arrays.cutout[stress_validation_indices],
                        stress_arrays.cutout_depth[stress_validation_indices],
                        stress_arrays.family_codes[stress_validation_indices],
                    )
                    deep_c = family_metric["deep_c"]
                    eligible = (
                        base_metric["foreground_iou"] >= base_body_metric["foreground_iou"] - args.base_iou_tolerance
                        and stress_metric["foreground_iou"] >= stress_body_metric["foreground_iou"] - args.stress_iou_tolerance
                        and stress_metric["bank_retention"] >= args.min_bank_retention
                    )
                    grid_rows.append(
                        {
                            "support_threshold": support_threshold,
                            "path_threshold": path_threshold,
                            "core_threshold": core_threshold,
                            "min_core_pixels": min_core_pixels,
                            "eligible": bool(eligible),
                            "base_iou": base_metric["foreground_iou"],
                            "stress_iou": stress_metric["foreground_iou"],
                            "stress_boundary_f1": stress_metric["boundary_f1"],
                            "stress_open_deep_cutout": stress_metric["open_deep_cutout_recovery"],
                            "stress_bank_retention": stress_metric["bank_retention"],
                            "stress_topology_joint": stress_metric["topology_structural_joint"],
                            "deep_c_iou": deep_c["foreground_iou"],
                            "deep_c_open_deep_cutout": deep_c["open_deep_cutout_recovery"],
                            "deep_c_bank_retention": deep_c["bank_retention"],
                            "carved_fraction": float(stress_masks.mean()),
                        }
                    )
    eligible_rows = [row for row in grid_rows if row["eligible"]]
    candidates = eligible_rows or grid_rows
    selected = max(
        candidates,
        key=lambda row: (
            row["stress_topology_joint"],
            row["deep_c_open_deep_cutout"],
            row["stress_iou"],
        ),
    )
    write_grid(output_dir / "validation_grid.csv", grid_rows)
    print(f"eligible={len(eligible_rows)}/{len(grid_rows)}; selected={selected}", flush=True)

    # Test/public truth is first accessed after the validation-only selection above.
    params = (
        float(selected["support_threshold"]),
        float(selected["path_threshold"]),
        float(selected["core_threshold"]),
        int(selected["min_core_pixels"]),
    )
    base_test_indices = np.asarray(base_archive["test_indices"], dtype=np.int64)
    stress_test_indices = np.asarray(stress_archive["test_indices"], dtype=np.int64)
    base_test_fields = collect_raw_fields(
        base_arrays.images[base_test_indices], base_arrays.voltages[base_test_indices],
        coarse, model, adapter, device, args.batch_size,
    )
    stress_test_fields = collect_raw_fields(
        stress_arrays.images[stress_test_indices], stress_arrays.voltages[stress_test_indices],
        coarse, model, adapter, device, args.batch_size,
    )
    base_body = predict_from_fields(
        base_test_fields, args.body_cutout_bias, args.body_support_scale, args.body_cutout_scale
    )
    stress_body = predict_from_fields(
        stress_test_fields, args.body_cutout_bias, args.body_support_scale, args.body_cutout_scale
    )
    base_connected, base_masks = predict_connected(base_test_fields, args, *params)
    stress_connected, stress_masks = predict_connected(stress_test_fields, args, *params)

    topology_archive = np.load(args.topology_predictions.resolve(), allow_pickle=False)
    topology_stress = topology_archive["stress_calibrated"]
    topology_base = topology_archive["base_calibrated"]
    topology_real = topology_archive["real_calibrated"]

    base_methods = {
        "coarse_fusion": base_test_fields.coarse_prediction,
        "topology_balanced": topology_base,
        "mouth_balanced_body": base_body,
        "connected_cutout": base_connected,
    }
    base_summary = {
        name: standard_metrics(
            base_arrays.labels[base_test_indices], prediction,
            base_arrays.indentation[base_test_indices],
        )
        for name, prediction in base_methods.items()
    }
    stress_methods = {
        "coarse_fusion": stress_test_fields.coarse_prediction,
        "topology_balanced": topology_stress,
        "mouth_balanced_body": stress_body,
        "connected_cutout": stress_connected,
    }
    stress_summary: dict[str, dict[str, float]] = {}
    stress_by_family: dict[str, dict[str, dict[str, float]]] = {}
    for name, prediction in stress_methods.items():
        summary, family, _ = stress_metrics(
            stress_arrays.labels[stress_test_indices], prediction,
            stress_arrays.cutout[stress_test_indices], stress_arrays.cutout_depth[stress_test_indices],
            stress_arrays.family_codes[stress_test_indices],
        )
        stress_summary[name] = summary
        stress_by_family[name] = family

    real_fields = collect_raw_fields(
        base_archive["real_linear_images"], base_archive["real_voltages"],
        coarse, model, adapter, device, args.batch_size,
    )
    real_body = predict_from_fields(
        real_fields, args.body_cutout_bias, args.body_support_scale, args.body_cutout_scale, output_size=256
    )
    real_connected, real_masks = predict_connected(real_fields, args, *params, output_size=256)
    real_coarse_logits = torch.from_numpy(np.log(np.clip(real_fields.coarse_probability, 1e-7, None)))
    real_coarse = F.interpolate(
        real_coarse_logits, size=(256, 256), mode="bilinear", align_corners=False
    ).argmax(dim=1).numpy().astype(np.uint8)
    real_truths = base_archive["real_labels"]
    real_ids = base_archive["real_ids"]
    real_methods = {
        "coarse_fusion": real_coarse,
        "topology_balanced": topology_real,
        "mouth_balanced_body": real_body,
        "connected_cutout": real_connected,
    }
    real_summary: dict[str, dict[str, float]] = {}
    real_rows: list[dict[str, object]] = []
    for name, prediction in real_methods.items():
        real_summary[name], rows = evaluate_real_predictions(name, prediction, real_truths, real_ids)
        real_rows.extend(rows)
    write_rows(output_dir / "real_case_metrics.csv", real_rows)

    save_stress_comparison(
        output_dir / "stress_connected_comparison.png",
        stress_arrays.labels[stress_test_indices], stress_test_fields.coarse_prediction,
        topology_stress, stress_body, stress_connected,
        stress_arrays.cutout[stress_test_indices], stress_arrays.family_codes[stress_test_indices],
    )
    save_real_montage(
        output_dir / "real_all_21_comparison.png", real_truths, real_ids, real_methods, real_rows
    )
    save_focus_montage(
        output_dir / "real_most_concave_comparison.png", real_truths, real_ids, real_methods, real_rows
    )
    np.savez_compressed(
        output_dir / "predictions.npz",
        base_test_indices=base_test_indices,
        base_coarse=base_test_fields.coarse_prediction,
        base_topology=topology_base,
        base_body=base_body,
        base_connected=base_connected,
        base_connected_mask=base_masks,
        stress_test_indices=stress_test_indices,
        stress_coarse=stress_test_fields.coarse_prediction,
        stress_topology=topology_stress,
        stress_body=stress_body,
        stress_connected=stress_connected,
        stress_connected_mask=stress_masks,
        real_coarse=real_coarse,
        real_topology=topology_real,
        real_body=real_body,
        real_connected=real_connected,
        real_connected_mask=real_masks,
    )
    result = {
        "method": "validation-calibrated exterior-connected hysteresis cutout",
        "selection_status": "hard_constraints_satisfied" if eligible_rows else "no_candidate_satisfied_all_constraints",
        "eligible_candidates": len(eligible_rows),
        "grid_candidates": len(grid_rows),
        "selected_parameters": {
            "support_threshold": params[0],
            "path_threshold": params[1],
            "core_threshold": params[2],
            "min_core_pixels": params[3],
        },
        "fixed_body_parameters": {
            "cutout_bias": args.body_cutout_bias,
            "support_scale": args.body_support_scale,
            "cutout_scale": args.body_cutout_scale,
            "link_cutout_bias": args.link_cutout_bias,
            "link_cutout_scale": args.link_cutout_scale,
        },
        "validation": {
            "body_base": base_body_metric,
            "body_stress": stress_body_metric,
            "selected": selected,
        },
        "base_synthetic_untouched_test": base_summary,
        "deep_concavity_stress_untouched_test": stress_summary,
        "stress_by_family": stress_by_family,
        "real_evaluation": real_summary,
        "evaluation_truth_used_for_training_or_selection": False,
        "checkpoint": str(args.checkpoint.resolve()),
        "device": str(device),
        "coarse_weights": coarse_weights,
    }
    (output_dir / "summary.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
