"""Train a voltage-conditioned network jointly on ordinary and concave KTC data.

The earlier refiner was intentionally frozen around a coarse reconstruction.
This experiment removes that bottleneck: a fresh multi-scale U-Net sees the
linear EIT image and the ordered KTC voltage table, predicts a continuous SDF,
conductivity contrast and class logits, and is trained on the independent
non-convex stress distribution together with the ordinary synthetic set.
"""
from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import ConcatDataset, DataLoader, Dataset

from train_ktc_concavity_network import InputAdapter, PhysicsOperator, ResidualBlock, soft_dice_loss
from train_ktc_concavity_network_v2 import ConcavityNetV2, ModelSpec, evaluate_real_predictions
from train_ktc_implicit_boolean_network import standard_metrics, stress_metrics


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    p.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    p.add_argument("--baseline-predictions", type=Path, default=Path("E:/Codex/ktc_shape_expert_seed20260820/predictions.npz"))
    p.add_argument("--output-dir", type=Path, default=Path("E:/Codex/ktc_joint_shape_network_seed20260820"))
    p.add_argument("--epochs", type=int, default=48)
    p.add_argument("--batch-size", type=int, default=32)
    p.add_argument("--base-channels", type=int, default=24)
    p.add_argument("--learning-rate", type=float, default=1.6e-3)
    p.add_argument("--weight-decay", type=float, default=1e-4)
    p.add_argument("--patience", type=int, default=10)
    p.add_argument("--stress-repeat", type=int, default=3)
    p.add_argument("--initial-checkpoint", type=Path, default=None)
    p.add_argument("--teacher-weight", type=float, default=0.0)
    p.add_argument("--base-limit", type=int, default=0, help="Optional training subset for smoke runs")
    p.add_argument("--stress-limit", type=int, default=0, help="Optional training subset for smoke runs")
    p.add_argument("--physics-every", type=int, default=8, help="Evaluate the expensive Jacobian loss every N batches")
    p.add_argument("--seed", type=int, default=20260820)
    return p.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)


class ArchiveDataset(Dataset):
    def __init__(self, archive: np.lib.npyio.NpzFile, indices: np.ndarray, source: int) -> None:
        self.indices = np.asarray(indices, dtype=np.int64); self.source = source
        self.has_cutout = "cutout_masks" in archive.files
        # NpzFile indexing re-inflates a compressed member.  Materialize each
        # field once; otherwise a training epoch decompresses multi-GB arrays
        # once per sample.
        self.linear = np.asarray(archive["linear_images"], dtype=np.float32)
        self.voltages = np.asarray(archive["voltages"], dtype=np.float32)
        self.clean = np.asarray(archive["clean_voltages"], dtype=np.float32)
        self.labels = np.asarray(archive["labels"], dtype=np.uint8)
        self.delta = np.asarray(archive["delta"], dtype=np.float32)
        self.sdf = np.asarray(archive["signed_distance"], dtype=np.float32)
        self.indent = np.asarray(archive["indentation_masks"], dtype=np.uint8)
        if self.has_cutout:
            self.support = np.asarray(archive["support_masks"], dtype=np.uint8)
            self.cutout = np.asarray(archive["cutout_masks"], dtype=np.uint8)
            self.depth = np.asarray(archive["cutout_depth_weights"], dtype=np.float32)

    def __len__(self) -> int: return int(self.indices.size)

    def __getitem__(self, item: int) -> dict[str, torch.Tensor]:
        i = int(self.indices[item])
        labels = self.labels[i].astype(np.int64)
        sdf = self.sdf[i]
        indent = self.indent[i].astype(np.float32)
        if self.has_cutout:
            support = self.support[i].astype(np.float32)
            cutout = self.cutout[i].astype(np.float32)
            depth = self.depth[i]
        else:
            support = (labels != 0).astype(np.float32)
            cutout = np.zeros_like(support)
            depth = np.zeros_like(support)
        return {
            "image": torch.from_numpy(self.linear[i][None]),
            "voltage": torch.from_numpy(self.voltages[i]),
            "clean_voltage": torch.from_numpy(self.clean[i]),
            "labels": torch.from_numpy(labels),
            "delta": torch.from_numpy(self.delta[i][None]),
            "sdf": torch.from_numpy(sdf[None]),
            "indent": torch.from_numpy(indent[None]),
            "support": torch.from_numpy(support[None]),
            "cutout": torch.from_numpy(cutout[None]),
            "depth": torch.from_numpy(depth[None]),
            "source": torch.tensor(self.source, dtype=torch.long),
            "index": torch.tensor(i, dtype=torch.long),
        }


def gradients(value: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    return value[:, :, 1:, :] - value[:, :, :-1, :], value[:, :, :, 1:] - value[:, :, :, :-1]


def masked_mean(value: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    per = (value * mask).sum(dim=(1, 2, 3)) / mask.sum(dim=(1, 2, 3)).clamp_min(1.0)
    valid = mask.sum(dim=(1, 2, 3)) > 0
    return per[valid].mean() if valid.any() else value.new_zeros(())


def compute_loss(output: dict[str, torch.Tensor], batch: dict[str, torch.Tensor], physics: PhysicsOperator, physics_weight: float = 2e-4, teacher_logits: torch.Tensor | None = None, teacher_weight: float = 0.0) -> torch.Tensor:
    labels = batch["labels"]
    logits = output["logits"]
    ce = F.cross_entropy(logits, labels, weight=logits.new_tensor((0.30, 1.35, 1.35)))
    dice = soft_dice_loss(logits, labels)
    fg = torch.softmax(logits, dim=1)[:, 1:].sum(dim=1, keepdim=True)
    target = (labels != 0).float().unsqueeze(1)
    sdf = F.smooth_l1_loss(output["sdf"], batch["sdf"], beta=0.08)
    dy, dx = gradients(fg); ty, tx = gradients(target)
    boundary = F.l1_loss(dy, ty) + F.l1_loss(dx, tx)
    delta = F.smooth_l1_loss(output["delta"], batch["delta"], beta=0.08)
    indentation = masked_mean(fg, batch["indent"])
    cutout = batch["cutout"]
    depth = 1.0 + 3.0 * batch["depth"]
    false_fill = masked_mean(fg, cutout * depth)
    bank = target * F.max_pool2d(cutout, 9, 1, 4)
    bank_loss = masked_mean(1.0 - fg, bank)
    # Use the actual voltage operator rather than a proxy image loss.  The
    # low coefficient keeps the segmentation objective from being dominated by
    # the ill-conditioned linearized forward map.
    physical = physics.loss(output["delta"], batch["voltage"]) if physics_weight else output["delta"].new_zeros(())
    distillation = logits.new_zeros(())
    if teacher_logits is not None and teacher_weight:
        base_cases = batch["source"] == 0
        if base_cases.any():
            teacher_probability = torch.softmax(teacher_logits[base_cases], dim=1)
            distillation = F.kl_div(torch.log_softmax(logits[base_cases], dim=1), teacher_probability, reduction="batchmean") / (logits.shape[-1] * logits.shape[-2])
    return ce + dice + 0.60 * sdf + 0.38 * boundary + 0.42 * delta + 0.30 * indentation + 0.78 * false_fill + 0.72 * bank_loss + physics_weight * physical + teacher_weight * distillation


@torch.no_grad()
def infer(model: torch.nn.Module, adapter: InputAdapter, loader: DataLoader, device: torch.device) -> np.ndarray:
    model.eval(); outputs = []
    for batch in loader:
        image = adapter(batch["image"].to(device)); voltage = batch["voltage"].to(device)
        outputs.append(model(image, voltage)["logits"].argmax(dim=1).cpu().numpy().astype(np.uint8))
    return np.concatenate(outputs)


def save_montage(path: Path, truth: np.ndarray, predictions: dict[str, np.ndarray], ids: np.ndarray, limit: int = 20) -> None:
    names = list(predictions); count = min(limit, len(truth))
    fig, axes = plt.subplots(count, 1 + len(names), figsize=(3.0 * (1 + len(names)), max(2.0, 2.2 * count)), squeeze=False)
    for i in range(count):
        axes[i, 0].imshow(truth[i], vmin=0, vmax=2, cmap="viridis"); axes[i, 0].axis("off"); axes[i, 0].set_ylabel(str(ids[i]), fontsize=7)
        for j, name in enumerate(names, start=1):
            axes[i, j].imshow(predictions[name][i], vmin=0, vmax=2, cmap="viridis"); axes[i, j].axis("off")
    for j, name in enumerate(["truth"] + names): axes[0, j].set_title(name)
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def main() -> None:
    args = parse_args(); set_seed(args.seed)
    out = args.output_dir.resolve(); out.mkdir(parents=True, exist_ok=True)
    base = np.load(args.base_dataset.resolve(), allow_pickle=False); stress = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    baseline = np.load(args.baseline_predictions.resolve(), allow_pickle=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = ConcavityNetV2(args.base_channels, ModelSpec(sdf=True, boundary=True, indentation=True, physics=True, voltage=True)).to(device)
    teacher = None
    if args.initial_checkpoint is not None:
        initial_state = torch.load(args.initial_checkpoint.resolve(), map_location=device, weights_only=False)
        missing, unexpected = model.load_state_dict(initial_state["model"], strict=False)
        print(f"initialized from {args.initial_checkpoint}; missing={len(missing)}, unexpected={len(unexpected)}", flush=True)
        teacher_spec = ModelSpec(**initial_state["spec"])
        teacher = ConcavityNetV2(int(initial_state["base_channels"]), teacher_spec).to(device)
        teacher.load_state_dict(initial_state["model"]); teacher.eval(); teacher.requires_grad_(False)
    adapter = InputAdapter(base["fov_mask"]).to(device)
    physics = PhysicsOperator(torch.from_numpy(base["jacobian"].astype(np.float32)).to(device), torch.from_numpy(base["node_to_raw_pixel"].astype(np.int64)).to(device), 2.0)
    base_train_indices = np.asarray(base["train_indices"], dtype=np.int64)
    stress_train_indices = np.asarray(stress["train_indices"], dtype=np.int64)
    if args.base_limit:
        base_train_indices = base_train_indices[: args.base_limit]
    if args.stress_limit:
        stress_train_indices = stress_train_indices[: args.stress_limit]
    base_train_dataset = ArchiveDataset(base, base_train_indices, 0)
    stress_train_dataset = ArchiveDataset(stress, stress_train_indices, 1)
    train = ConcatDataset((base_train_dataset,) + tuple(stress_train_dataset for _ in range(max(1, args.stress_repeat))))
    loader = DataLoader(train, batch_size=args.batch_size, shuffle=True, drop_last=True)
    base_val = DataLoader(ArchiveDataset(base, base["validation_indices"], 0), batch_size=args.batch_size, shuffle=False)
    stress_val = DataLoader(ArchiveDataset(stress, stress["validation_indices"], 1), batch_size=args.batch_size, shuffle=False)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    best_score = -float("inf"); stale = 0; history = []
    for epoch in range(1, args.epochs + 1):
        model.train(); losses = []
        for batch_index, batch in enumerate(loader):
            moved = {k: v.to(device) for k, v in batch.items() if isinstance(v, torch.Tensor)}
            optimizer.zero_grad(set_to_none=True)
            adapted = adapter(moved["image"])
            output = model(adapted, moved["voltage"])
            with torch.no_grad():
                teacher_logits = teacher(adapted, moved["voltage"])["logits"] if teacher is not None else None
            physics_weight = 2e-4 if batch_index % max(1, args.physics_every) == 0 else 0.0
            loss = compute_loss(output, moved, physics, physics_weight, teacher_logits, args.teacher_weight); loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0); optimizer.step(); losses.append(float(loss.detach()))
        scheduler.step()
        bp = infer(model, adapter, base_val, device); sp = infer(model, adapter, stress_val, device)
        bm = standard_metrics(base["labels"][base["validation_indices"]], bp, base["indentation_masks"][base["validation_indices"]])
        sm, _, _ = stress_metrics(stress["labels"][stress["validation_indices"]], sp, stress["cutout_masks"][stress["validation_indices"]], stress["cutout_depth_weights"][stress["validation_indices"]], stress["family_codes"][stress["validation_indices"]])
        score = 0.28 * bm["foreground_iou"] + 0.22 * sm["foreground_iou"] + 0.20 * sm["open_deep_cutout_recovery"] + 0.15 * sm["bank_retention"] + 0.15 * sm["topology_structural_joint"]
        row = {"epoch": epoch, "loss": float(np.mean(losses)), "score": score, "base_iou": bm["foreground_iou"], "stress_iou": sm["foreground_iou"], "open_deep": sm["open_deep_cutout_recovery"], "bank": sm["bank_retention"], "topology": sm["topology_structural_joint"]}; history.append(row)
        print(row, flush=True)
        if score > best_score:
            best_score = score; stale = 0; torch.save({"model": model.state_dict(), "base_channels": args.base_channels, "epoch": epoch, "validation": row}, out / "best.pt")
        else: stale += 1
        if stale >= args.patience: break
    state = torch.load(out / "best.pt", map_location=device, weights_only=False); model.load_state_dict(state["model"]); model.eval()
    base_test = DataLoader(ArchiveDataset(base, base["test_indices"], 0), batch_size=args.batch_size, shuffle=False)
    stress_test = DataLoader(ArchiveDataset(stress, stress["test_indices"], 1), batch_size=args.batch_size, shuffle=False)
    bp = infer(model, adapter, base_test, device); sp = infer(model, adapter, stress_test, device)
    bm = standard_metrics(base["labels"][base["test_indices"]], bp, base["indentation_masks"][base["test_indices"]])
    sm, by_family, stress_rows = stress_metrics(stress["labels"][stress["test_indices"]], sp, stress["cutout_masks"][stress["test_indices"]], stress["cutout_depth_weights"][stress["test_indices"]], stress["family_codes"][stress["test_indices"]])
    # Real cases are carried in separate archive keys; use a small adapter batch directly.
    real_out = []
    with torch.no_grad():
        for start in range(0, len(base["real_linear_images"]), args.batch_size):
            image = torch.from_numpy(base["real_linear_images"][start:start + args.batch_size, None].astype(np.float32)).to(device)
            voltage = torch.from_numpy(base["real_voltages"][start:start + args.batch_size].astype(np.float32)).to(device)
            logits = model(adapter(image), voltage)["logits"]
            logits = F.interpolate(logits, size=(256, 256), mode="bilinear", align_corners=False)
            real_out.append(logits.argmax(dim=1).cpu().numpy().astype(np.uint8))
    real_pred = np.concatenate(real_out)
    real_summary, _ = evaluate_real_predictions("joint_shape", real_pred, base["real_labels"], base["real_ids"])
    baseline_stress = baseline["stress_expert"]
    baseline_real = baseline["real_expert"]
    baseline_sm, _, _ = stress_metrics(stress["labels"][stress["test_indices"]], baseline_stress, stress["cutout_masks"][stress["test_indices"]], stress["cutout_depth_weights"][stress["test_indices"]], stress["family_codes"][stress["test_indices"]])
    baseline_real_summary, _ = evaluate_real_predictions("shape_expert", baseline_real, base["real_labels"], base["real_ids"])
    np.savez_compressed(out / "predictions.npz", base=bp, stress=sp, real=real_pred)
    save_montage(out / "stress_comparison.png", stress["labels"][stress["test_indices"]], {"shape_expert": baseline_stress, "joint_shape": sp}, stress["test_indices"], 24)
    save_montage(out / "real_comparison.png", base["real_labels"], {"shape_expert": baseline_real, "joint_shape": real_pred}, base["real_ids"], 21)
    summary = {"method": "joint voltage-conditioned SDF network", "device": str(device), "history": history, "base": bm, "stress": {"shape_expert": baseline_sm, "joint_shape": sm, "by_family": by_family}, "real": {"shape_expert": baseline_real_summary, "joint_shape": real_summary}}
    (out / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
