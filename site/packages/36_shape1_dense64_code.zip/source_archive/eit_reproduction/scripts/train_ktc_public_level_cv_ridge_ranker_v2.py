"""Nested all-level OOF ridge ranking with topology-safety constraints.

For each held-out KTC level, hyperparameters are selected from cross-fitted
predictions over all six remaining levels. The outer prediction averages the
six inner models and a final model trained on all remaining levels.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from train_ktc_cross_representation_pixel_fusion import (
    STRICT_INWARD_IDS,
    foreground_iou_per_case,
    load_pool,
    metric_for,
    paired_bootstrap,
    prepare_split,
)
from train_ktc_public_level_cv_ridge_ranker import (
    FeatureSet,
    RidgeModel,
    build_features,
    candidate_targets,
    casewise_oracle,
    fit_ridge,
    public_group_metrics,
    save_montage,
    select_candidates,
    subset_split,
    write_csv,
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    parser.add_argument(
        "--pool-dir", type=Path,
        default=root / "outputs" / "ktc_cross_representation_pool_seed20260820",
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=root / "outputs" / "ktc_public_level_cv_ridge_ranker_v2_seed20260820",
    )
    parser.add_argument("--base-train-samples", type=int, default=600)
    parser.add_argument("--stress-train-samples", type=int, default=300)
    parser.add_argument("--bootstrap-repetitions", type=int, default=10000)
    parser.add_argument("--fold-limit", type=int, default=0)
    parser.add_argument("--seed", type=int, default=20260820)
    return parser.parse_args()


def feature_subset(features: FeatureSet, selected: np.ndarray) -> FeatureSet:
    return FeatureSet(
        features=features.features[selected],
        risks={key: values[:, selected] for key, values in features.risks.items()},
    )


def fit_public_model(
    selected: np.ndarray,
    public_features: FeatureSet,
    public_truths: np.ndarray,
    public_candidates: np.ndarray,
    synthetic_train: list[tuple[np.ndarray, np.ndarray]],
    public_weight: float,
    regularization: float,
) -> RidgeModel:
    targets = candidate_targets(public_truths[selected], public_candidates[:, selected])
    remaining = 1.0 - public_weight
    return fit_ridge([
        (public_features.features[selected], targets, public_weight),
        (synthetic_train[0][0], synthetic_train[0][1], remaining * 0.45),
        (synthetic_train[1][0], synthetic_train[1][1], remaining * 0.55),
    ], regularization)


def calibrate_outer_fold(
    outer_level: str,
    ids: np.ndarray,
    levels: np.ndarray,
    public_features: FeatureSet,
    public_truths: np.ndarray,
    public_candidates: np.ndarray,
    synthetic_train: list[tuple[np.ndarray, np.ndarray]],
    base_validation: object,
    stress_validation: object,
    base_validation_features: FeatureSet,
    stress_validation_features: FeatureSet,
) -> tuple[list[RidgeModel], RidgeModel, dict[str, object], list[dict[str, object]]]:
    remaining_indices = np.flatnonzero(levels != outer_level)
    remaining_levels = sorted(set(levels[remaining_indices]))
    base_reference = metric_for(base_validation, base_validation.candidates[0])
    stress_reference = metric_for(stress_validation, stress_validation.candidates[0])
    baseline_all = foreground_iou_per_case(
        public_truths[remaining_indices], public_candidates[0, remaining_indices]
    ).mean()
    rows: list[dict[str, object]] = []
    best: tuple[tuple[float, ...], list[RidgeModel], RidgeModel, dict[str, object]] | None = None
    strict_global = np.asarray([str(case_id) in STRICT_INWARD_IDS for case_id in ids])
    strict_remaining = strict_global[remaining_indices]
    baseline_strict = foreground_iou_per_case(
        public_truths[remaining_indices][strict_remaining],
        public_candidates[0, remaining_indices][strict_remaining],
    ).mean()

    for public_weight in (0.65, 0.85):
        for regularization in (0.10, 1.0, 10.0):
            oof_scores = np.zeros((len(levels), public_candidates.shape[0]), dtype=np.float64)
            inner_models: list[RidgeModel] = []
            for inner_level in remaining_levels:
                inner = np.flatnonzero(levels == inner_level)
                train = np.flatnonzero((levels != outer_level) & (levels != inner_level))
                model = fit_public_model(
                    train, public_features, public_truths, public_candidates,
                    synthetic_train, public_weight, regularization,
                )
                oof_scores[inner] = model.predict(public_features.features[inner])
                inner_models.append(model)
            final_model = fit_public_model(
                remaining_indices, public_features, public_truths, public_candidates,
                synthetic_train, public_weight, regularization,
            )
            base_scores = final_model.predict(base_validation_features.features)
            stress_scores = final_model.predict(stress_validation_features.features)
            for threshold in (0.0, 0.01, 0.03, 1.0):
                for max_change in (0.075, 1.0):
                    for max_removal in (0.30, 1.0):
                        remaining_features = feature_subset(public_features, remaining_indices)
                        oof_prediction, oof_choice, _ = select_candidates(
                            public_candidates[:, remaining_indices], oof_scores[remaining_indices],
                            remaining_features.risks, threshold, max_change, max_removal,
                        )
                        base_prediction, base_choice, _ = select_candidates(
                            base_validation.candidates, base_scores, base_validation_features.risks,
                            threshold, max_change, max_removal,
                        )
                        stress_prediction, stress_choice, _ = select_candidates(
                            stress_validation.candidates, stress_scores, stress_validation_features.risks,
                            threshold, max_change, max_removal,
                        )
                        oof_iou = float(foreground_iou_per_case(
                            public_truths[remaining_indices], oof_prediction
                        ).mean())
                        oof_strict_iou = float(foreground_iou_per_case(
                            public_truths[remaining_indices][strict_remaining],
                            oof_prediction[strict_remaining],
                        ).mean())
                        base_metric = metric_for(base_validation, base_prediction)
                        stress_metric = metric_for(stress_validation, stress_prediction)
                        eligible = (
                            base_metric["foreground_iou"] >= base_reference["foreground_iou"] - 0.003
                            and base_metric["boundary_f1"] >= base_reference["boundary_f1"] - 0.005
                            and stress_metric["foreground_iou"] >= stress_reference["foreground_iou"] - 0.005
                            and stress_metric["bank_retention"] >= stress_reference["bank_retention"] - 0.015
                            and stress_metric["open_deep_cutout_recovery"]
                            >= stress_reference["open_deep_cutout_recovery"] - 0.003
                            and stress_metric["topology_structural_joint"]
                            >= stress_reference["topology_structural_joint"] - 0.004
                        )
                        oof_delta = oof_iou - float(baseline_all)
                        strict_delta = oof_strict_iou - float(baseline_strict)
                        objective = (
                            oof_delta + 0.75 * strict_delta
                            + 0.20 * (
                                stress_metric["open_deep_cutout_recovery"]
                                - stress_reference["open_deep_cutout_recovery"]
                            )
                        )
                        row: dict[str, object] = {
                            "public_weight": public_weight, "regularization": regularization,
                            "score_threshold": threshold, "max_change_fraction": max_change,
                            "max_component_removal": max_removal, "eligible": bool(eligible),
                            "objective": float(objective), "oof_iou": oof_iou,
                            "oof_iou_delta": float(oof_delta), "oof_strict_iou": oof_strict_iou,
                            "oof_strict_iou_delta": float(strict_delta),
                            "base_validation_iou": base_metric["foreground_iou"],
                            "stress_validation_iou": stress_metric["foreground_iou"],
                            "stress_open_deep": stress_metric["open_deep_cutout_recovery"],
                            "stress_topology_joint": stress_metric["topology_structural_joint"],
                            "stress_bank": stress_metric["bank_retention"],
                            "oof_changed": int(np.count_nonzero(oof_choice)),
                            "base_changed": int(np.count_nonzero(base_choice)),
                            "stress_changed": int(np.count_nonzero(stress_choice)),
                        }
                        rows.append(row)
                        key = (
                            1.0 if eligible else 0.0, float(objective), float(strict_delta),
                            float(oof_delta), -float(np.count_nonzero(oof_choice)),
                        )
                        if best is None or key > best[0]:
                            best = (key, inner_models, final_model, row)
    assert best is not None
    return best[1], best[2], best[3], rows


def main() -> None:
    args = parse_args()
    rng = np.random.default_rng(args.seed)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    base = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    pool_dir = args.pool_dir.resolve()
    names, base_train = prepare_split("base_train", "base", base, pool_dir)
    _, stress_train = prepare_split("stress_train", "stress", stress, pool_dir)
    _, base_validation = prepare_split("base_validation", "base", base, pool_dir)
    _, stress_validation = prepare_split("stress_validation", "stress", stress, pool_dir)
    _, base_test = prepare_split("base_test", "base", base, pool_dir)
    _, stress_test = prepare_split("stress_test", "stress", stress, pool_dir)
    public_names, public_indices, public_candidates = load_pool(pool_dir / "public_21.npz")
    if names != public_names or not np.array_equal(public_indices, np.arange(len(public_indices))):
        raise ValueError("candidate ordering mismatch")
    base_selected = np.sort(rng.choice(len(base_train.indices), min(args.base_train_samples, len(base_train.indices)), replace=False))
    stress_selected = np.sort(rng.choice(len(stress_train.indices), min(args.stress_train_samples, len(stress_train.indices)), replace=False))
    base_train = subset_split(base_train, base_selected, "base_train_subset")
    stress_train = subset_split(stress_train, stress_selected, "stress_train_subset")
    print("building cached synthetic/public features", flush=True)
    base_train_features = build_features(base_train.images, base_train.voltages, base_train.candidates, base)
    stress_train_features = build_features(stress_train.images, stress_train.voltages, stress_train.candidates, stress)
    base_validation_features = build_features(base_validation.images, base_validation.voltages, base_validation.candidates, base)
    stress_validation_features = build_features(stress_validation.images, stress_validation.voltages, stress_validation.candidates, stress)
    base_test_features = build_features(base_test.images, base_test.voltages, base_test.candidates, base)
    stress_test_features = build_features(stress_test.images, stress_test.voltages, stress_test.candidates, stress)
    synthetic_train = [
        (base_train_features.features, candidate_targets(base_train.truths, base_train.candidates)),
        (stress_train_features.features, candidate_targets(stress_train.truths, stress_train.candidates)),
    ]
    ids = np.asarray(base["real_ids"])
    levels = np.asarray([str(case_id).split("/")[0] for case_id in ids])
    unique_levels = sorted(set(levels))
    public_features = build_features(
        np.asarray(base["real_linear_images"]), np.asarray(base["real_voltages"]), public_candidates, base
    )
    public_truths = np.asarray(base["real_labels"], dtype=np.uint8)
    prediction = np.zeros_like(public_candidates[0])
    choices = np.zeros(len(ids), dtype=np.int64)
    predicted = np.zeros(len(ids), dtype=bool)
    policies: list[dict[str, object]] = []
    synthetic_audits: list[dict[str, object]] = []
    fold_count = len(unique_levels) if args.fold_limit <= 0 else min(args.fold_limit, len(unique_levels))
    for fold, outer_level in enumerate(unique_levels[:fold_count]):
        outer = np.flatnonzero(levels == outer_level)
        print(f"outer fold {fold}: held out {outer_level}", flush=True)
        inner_models, final_model, policy, grid = calibrate_outer_fold(
            outer_level, ids, levels, public_features, public_truths, public_candidates,
            synthetic_train, base_validation, stress_validation,
            base_validation_features, stress_validation_features,
        )
        policy = {"fold": fold, "outer_level": outer_level, **policy}
        policies.append(policy)
        write_csv(output_dir / f"fold_{fold}_calibration.csv", grid)
        ensemble = [final_model, *inner_models]
        outer_scores = np.mean([model.predict(public_features.features[outer]) for model in ensemble], axis=0)
        outer_features = feature_subset(public_features, outer)
        fold_prediction, fold_choice, _ = select_candidates(
            public_candidates[:, outer], outer_scores, outer_features.risks,
            float(policy["score_threshold"]), float(policy["max_change_fraction"]),
            float(policy["max_component_removal"]),
        )
        prediction[outer] = fold_prediction
        choices[outer] = fold_choice
        predicted[outer] = True
        np.savez_compressed(
            output_dir / f"fold_{fold}_ensemble.npz",
            means=np.stack([model.mean for model in ensemble]),
            scales=np.stack([model.scale for model in ensemble]),
            coefficients=np.stack([model.coefficients for model in ensemble]),
        )
        base_test_scores = np.mean([model.predict(base_test_features.features) for model in ensemble], axis=0)
        stress_test_scores = np.mean([model.predict(stress_test_features.features) for model in ensemble], axis=0)
        base_test_prediction, _, _ = select_candidates(
            base_test.candidates, base_test_scores, base_test_features.risks,
            float(policy["score_threshold"]), float(policy["max_change_fraction"]),
            float(policy["max_component_removal"]),
        )
        stress_test_prediction, _, _ = select_candidates(
            stress_test.candidates, stress_test_scores, stress_test_features.risks,
            float(policy["score_threshold"]), float(policy["max_change_fraction"]),
            float(policy["max_component_removal"]),
        )
        synthetic_audits.append({
            "fold": fold, "base_test": metric_for(base_test, base_test_prediction),
            "stress_test": metric_for(stress_test, stress_test_prediction),
        })
        print(f"fold {fold} policy={policy}; outer choices={fold_choice.tolist()}", flush=True)
    if not predicted.all():
        prediction[~predicted] = public_candidates[0, ~predicted]
    (output_dir / "fold_policies.json").write_text(json.dumps(policies, indent=2), encoding="utf-8")
    baseline = public_candidates[0]
    oracle = casewise_oracle(public_truths, public_candidates)
    strict = np.asarray([str(case_id) in STRICT_INWARD_IDS for case_id in ids])
    all_mask = predicted if args.fold_limit > 0 else np.ones(len(ids), dtype=bool)
    strict_mask = strict & all_mask
    ordinary_mask = ~strict & all_mask
    before = foreground_iou_per_case(public_truths, baseline)
    after = foreground_iou_per_case(public_truths, prediction)
    differences = after[all_mask] - before[all_mask]
    rows = [{
        "id": str(ids[index]), "strict_inward": bool(strict[index]),
        "choice": int(choices[index]), "candidate": names[int(choices[index])],
        "baseline_iou": float(before[index]), "ridge_v2_iou": float(after[index]),
        "delta_iou": float(after[index] - before[index]),
    } for index in np.flatnonzero(all_mask)]
    write_csv(output_dir / "public_case_metrics.csv", rows)
    if strict_mask.any():
        save_montage(
            output_dir / "public_strict_inward_level_cv_ridge_v2.png", public_truths,
            baseline, prediction, oracle, choices, ids, np.flatnonzero(strict_mask),
        )
    np.savez_compressed(
        output_dir / "predictions.npz", prediction=prediction, choices=choices,
        predicted_mask=predicted, ids=ids,
    )
    summary = {
        "method": "outer-level-held-out, six-level OOF-selected ridge ensemble",
        "outer_folds_completed": fold_count,
        "public_21": public_group_metrics(
            "all", all_mask, public_truths, baseline, prediction, oracle, ids,
            args.bootstrap_repetitions, args.seed + 20,
        ),
        "public_strict_inward": public_group_metrics(
            "strict", strict_mask, public_truths, baseline, prediction, oracle, ids,
            args.bootstrap_repetitions, args.seed + 21,
        ) if strict_mask.any() else {},
        "public_ordinary": public_group_metrics(
            "ordinary", ordinary_mask, public_truths, baseline, prediction, oracle, ids,
            args.bootstrap_repetitions, args.seed + 22,
        ) if ordinary_mask.any() else {},
        "public_changes": {
            "changed": int(np.count_nonzero(choices[all_mask])),
            "improved": int(np.count_nonzero(differences > 1e-6)),
            "harmed": int(np.count_nonzero(differences < -1e-6)),
            "material_improvements": int(np.count_nonzero(differences >= 0.01)),
            "material_harms": int(np.count_nonzero(differences <= -0.01)),
        },
        "fold_policies": policies, "synthetic_test_audits": synthetic_audits,
        "leakage_policy": "outer level excluded from every inner model, policy, and ensemble member",
        "outer_truth_used_for_training_or_selection": False, "seed": args.seed,
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
