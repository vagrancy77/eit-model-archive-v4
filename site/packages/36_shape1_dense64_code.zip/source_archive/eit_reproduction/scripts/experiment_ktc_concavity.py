from __future__ import annotations

import argparse
import json
import os
import random
import sys
from pathlib import Path

import numpy as np
import scipy.io as sio
import scipy.signal as sps
from PIL import Image, ImageDraw
from scipy.spatial import ConvexHull, QhullError

os.environ.setdefault("CUDA_VISIBLE_DEVICES", "")

import torch


VARIANTS = {
    "baseline": {
        "tv_mode": "l1",
        "tv_weight": 5e-8,
        "upsample_mode": "bilinear",
        "input_noise_std": 0.04,
    },
    "low_tv": {
        "tv_mode": "l1",
        "tv_weight": 1e-8,
        "upsample_mode": "bilinear",
        "input_noise_std": 0.04,
    },
    "no_tv": {
        "tv_mode": "l1",
        "tv_weight": 0.0,
        "upsample_mode": "bilinear",
        "input_noise_std": 0.04,
    },
    "log_tv": {
        "tv_mode": "log",
        "tv_weight": 5e-8,
        "tv_epsilon": 1e-2,
        "upsample_mode": "bilinear",
        "input_noise_std": 0.04,
    },
    "lp_tv": {
        "tv_mode": "lp",
        "tv_weight": 1e-8,
        "tv_epsilon": 1e-3,
        "tv_power": 0.5,
        "upsample_mode": "bilinear",
        "input_noise_std": 0.04,
    },
    "nearest_log_tv": {
        "tv_mode": "log",
        "tv_weight": 5e-8,
        "tv_epsilon": 1e-2,
        "upsample_mode": "nearest",
        "input_noise_std": 0.04,
    },
    "sharp_interpolation": {
        "tv_mode": "log",
        "tv_weight": 5e-8,
        "tv_epsilon": 1e-2,
        "interpolation_sigma": 2e-3,
        "upsample_mode": "bilinear",
        "input_noise_std": 0.04,
    },
    "shallow_dip": {
        "tv_mode": "log",
        "tv_weight": 5e-8,
        "tv_epsilon": 1e-2,
        "architecture_num_scales": 4,
        "upsample_mode": "bilinear",
        "input_noise_std": 0.04,
    },
    "sharp_shallow_dip": {
        "tv_mode": "log",
        "tv_weight": 5e-8,
        "tv_epsilon": 1e-2,
        "interpolation_sigma": 2e-3,
        "architecture_num_scales": 4,
        "upsample_mode": "bilinear",
        "input_noise_std": 0.04,
    },
    "very_shallow_dip": {
        "tv_mode": "log",
        "tv_weight": 5e-8,
        "tv_epsilon": 1e-2,
        "architecture_num_scales": 3,
        "upsample_mode": "bilinear",
        "input_noise_std": 0.04,
    },
    "nearest_map_shallow": {
        "tv_mode": "log",
        "tv_weight": 5e-8,
        "tv_epsilon": 1e-2,
        "interpolation_mode": "nearest",
        "architecture_num_scales": 4,
        "upsample_mode": "bilinear",
        "input_noise_std": 0.04,
    },
    "nearest_map_very_shallow": {
        "tv_mode": "log",
        "tv_weight": 5e-8,
        "tv_epsilon": 1e-2,
        "interpolation_mode": "nearest",
        "architecture_num_scales": 3,
        "upsample_mode": "bilinear",
        "input_noise_std": 0.04,
    },
    "nearest_map_nearest_up": {
        "tv_mode": "log",
        "tv_weight": 5e-8,
        "tv_epsilon": 1e-2,
        "interpolation_mode": "nearest",
        "architecture_num_scales": 4,
        "upsample_mode": "nearest",
        "input_noise_std": 0.04,
    },
}


def parse_args() -> argparse.Namespace:
    project_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(
        description="Controlled DIP regularizer study for the concave KTC data4 target."
    )
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=project_root / "external" / "KTC2023-ABC2",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=project_root / "outputs" / "ktc_concavity_pilot",
    )
    parser.add_argument("--case", type=int, default=4, choices=(1, 2, 3, 4))
    parser.add_argument("--seed", type=int, default=1237)
    parser.add_argument("--num-iter", type=int, default=750)
    parser.add_argument("--progress-every", type=int, default=100)
    parser.add_argument(
        "--variants",
        default="baseline,low_tv,log_tv,nearest_log_tv",
        help=f"Comma-separated subset of: {','.join(VARIANTS)}",
    )
    parser.add_argument(
        "--opening-iterations",
        default="0,2,5,10",
        help="Comma-separated postprocessing strengths evaluated from the same DIP image.",
    )
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    try:
        torch.use_deterministic_algorithms(True)
    except Exception:
        pass


def png_to_labels(path: Path) -> np.ndarray:
    image = np.asarray(Image.open(path), dtype=np.float64)
    return np.rint(image * 2.0 / 255.0).astype(np.int64)


def convex_hull_mask(binary: np.ndarray) -> np.ndarray:
    rows, cols = np.nonzero(binary)
    if rows.size < 3:
        return binary.copy()
    points = np.column_stack((cols, rows))
    try:
        hull = ConvexHull(points)
    except QhullError:
        return binary.copy()
    polygon = [tuple(point) for point in points[hull.vertices]]
    canvas = Image.new("1", (binary.shape[1], binary.shape[0]), 0)
    ImageDraw.Draw(canvas).polygon(polygon, outline=1, fill=1)
    return np.asarray(canvas, dtype=bool)


def shape_metrics(truth: np.ndarray, reconstruction: np.ndarray) -> dict[str, float]:
    foreground_labels = [int(value) for value in np.unique(truth) if value != 0]
    truth_fg = truth != 0
    reconstruction_fg = np.isin(reconstruction, foreground_labels)
    intersection = float(np.logical_and(truth_fg, reconstruction_fg).sum())
    union = float(np.logical_or(truth_fg, reconstruction_fg).sum())
    denominator = float(truth_fg.sum() + reconstruction_fg.sum())

    truth_hull = convex_hull_mask(truth_fg)
    reconstruction_hull = convex_hull_mask(reconstruction_fg)
    truth_indentations = np.logical_and(truth_hull, ~truth_fg)
    indentation_count = int(truth_indentations.sum())
    indentation_preservation = (
        float((~reconstruction_fg[truth_indentations]).mean())
        if indentation_count
        else 1.0
    )

    truth_convexity = float(truth_fg.sum() / max(1, truth_hull.sum()))
    reconstruction_convexity = float(
        reconstruction_fg.sum() / max(1, reconstruction_hull.sum())
    )
    return {
        "foreground_iou": intersection / union if union else 1.0,
        "foreground_dice": 2.0 * intersection / denominator if denominator else 1.0,
        "foreground_recall": intersection / float(max(1, truth_fg.sum())),
        "foreground_precision": intersection / float(max(1, reconstruction_fg.sum())),
        "area_ratio_to_truth": float(reconstruction_fg.sum() / max(1, truth_fg.sum())),
        "truth_convexity": truth_convexity,
        "reconstruction_convexity": reconstruction_convexity,
        "convexity_absolute_error": abs(reconstruction_convexity - truth_convexity),
        "truth_indentation_pixels": float(indentation_count),
        "indentation_preservation": indentation_preservation,
        "indentation_false_fill": 1.0 - indentation_preservation,
    }


def class_metrics(truth: np.ndarray, reconstruction: np.ndarray) -> dict[str, float]:
    result: dict[str, float] = {
        "pixel_accuracy": float(np.mean(truth == reconstruction))
    }
    ious = []
    dices = []
    for label in (1, 2):
        truth_class = truth == label
        reconstruction_class = reconstruction == label
        intersection = float(np.logical_and(truth_class, reconstruction_class).sum())
        union = float(np.logical_or(truth_class, reconstruction_class).sum())
        denominator = float(truth_class.sum() + reconstruction_class.sum())
        iou = intersection / union if union else 1.0
        dice = 2.0 * intersection / denominator if denominator else 1.0
        result[f"class{label}_iou"] = iou
        result[f"class{label}_dice"] = dice
        ious.append(iou)
        dices.append(dice)
    result["mean_iou"] = float(np.mean(ious))
    result["mean_dice"] = float(np.mean(dices))
    return result


def _ssim_fft(truth: np.ndarray, reconstruction: np.ndarray) -> float:
    c1 = 1e-4
    c2 = 9e-4
    radius = 80
    width = int(np.ceil(2 * radius))
    coordinates = np.arange(-width, width + 1)
    xx, yy = np.meshgrid(coordinates, coordinates)
    kernel = (1 / np.sqrt(2 * np.pi)) * np.exp(
        -0.5 * ((xx * xx + yy * yy) / (radius * radius))
    )
    correction = sps.fftconvolve(np.ones(truth.shape), kernel, mode="same")

    def convolution(image: np.ndarray) -> np.ndarray:
        return sps.fftconvolve(image, kernel, mode="same") / correction

    mean_truth = convolution(truth)
    mean_reconstruction = convolution(reconstruction)
    mean_truth_squared = np.square(mean_truth)
    mean_reconstruction_squared = np.square(mean_reconstruction)
    mean_product = mean_truth * mean_reconstruction
    variance_truth = convolution(np.square(truth)) - mean_truth_squared
    variance_reconstruction = (
        convolution(np.square(reconstruction)) - mean_reconstruction_squared
    )
    covariance = convolution(truth * reconstruction) - mean_product
    numerator = (2 * mean_product + c1) * (2 * covariance + c2)
    denominator = (
        mean_truth_squared + mean_reconstruction_squared + c1
    ) * (variance_truth + variance_reconstruction + c2)
    return float(np.mean(numerator / denominator))


def ktc_score(truth: np.ndarray, reconstruction: np.ndarray) -> float:
    scores = []
    for label in (2, 1):
        truth_class = (truth == label).astype(np.float64)
        reconstruction_class = (reconstruction == label).astype(np.float64)
        scores.append(_ssim_fft(truth_class, reconstruction_class))
    return float(np.mean(scores))


def save_labels(labels: np.ndarray, path: Path) -> None:
    Image.fromarray(np.asarray(labels * 127.5, dtype=np.uint8)).save(path)


def write_figure(
    truth: np.ndarray,
    author: np.ndarray,
    local_3000: np.ndarray | None,
    results: list[dict[str, object]],
    output_path: Path,
) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    n_rows = 1 + len(results)
    figure, axes = plt.subplots(
        n_rows,
        4,
        figsize=(12, 3.05 * n_rows),
        squeeze=False,
        constrained_layout=True,
    )
    references = [truth, author, local_3000]
    reference_titles = ["Ground truth", "Author 3000 iter", "Local 3000 iter"]
    for column, (image, title) in enumerate(zip(references, reference_titles)):
        if image is None:
            axes[0, column].set_axis_off()
            continue
        axes[0, column].imshow(image, cmap="gray", vmin=0, vmax=2)
        axes[0, column].set_title(title)
        axes[0, column].set_axis_off()
    axes[0, 3].text(
        0.02,
        0.98,
        "Goal: recover the inward notches\nwithout sacrificing overlap.",
        va="top",
        fontsize=11,
    )
    axes[0, 3].set_axis_off()

    for row_index, result in enumerate(results, start=1):
        continuous = np.load(str(result["continuous_path"]))
        variants = result["postprocessing"]
        selected = [variants[key] for key in ("0", "2", "10") if key in variants]
        axes[row_index, 0].imshow(continuous, cmap="viridis")
        axes[row_index, 0].set_title(f"{result['name']}: continuous")
        axes[row_index, 0].set_axis_off()
        for column, post_result in enumerate(selected, start=1):
            image = png_to_labels(Path(str(post_result["image_path"])))
            metrics = post_result["metrics"]
            axes[row_index, column].imshow(image, cmap="gray", vmin=0, vmax=2)
            axes[row_index, column].set_title(
                f"opening={post_result['opening']}\n"
                f"IoU={metrics['foreground_iou']:.3f}, "
                f"notch={metrics['indentation_preservation']:.3f}"
            )
            axes[row_index, column].set_axis_off()
        for column in range(1 + len(selected), 4):
            axes[row_index, column].set_axis_off()
    figure.suptitle("KTC data4 concavity-preservation pilot", fontsize=16)
    figure.savefig(output_path, dpi=180)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    repo_root = args.repo_root.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    os.chdir(repo_root)
    sys.path.insert(0, str(repo_root))

    from utils import solver

    names = [name.strip() for name in args.variants.split(",") if name.strip()]
    unknown = sorted(set(names) - set(VARIANTS))
    if unknown:
        raise ValueError(f"unknown variants: {unknown}")
    openings = sorted(
        set(int(value.strip()) for value in args.opening_iterations.split(",") if value.strip())
    )

    input_path = repo_root / "inputs" / f"data{args.case}.mat"
    truth = sio.loadmat(repo_root / "groundTruths" / f"true{args.case}.mat")["truth"]
    author = png_to_labels(repo_root / "outputs" / f"data{args.case}.png")
    local_3000_path = (
        repo_root.parents[1]
        / "outputs"
        / "ktc2023_abc2_3000_data3_data4"
        / f"data{args.case}.png"
    )
    local_3000 = png_to_labels(local_3000_path) if local_3000_path.exists() else None

    summary: dict[str, object] = {
        "case": args.case,
        "seed": args.seed,
        "num_iter": args.num_iter,
        "opening_iterations": openings,
        "reference_metrics": {
            "author_3000": shape_metrics(truth, author),
            "local_3000": shape_metrics(truth, local_3000) if local_3000 is not None else None,
        },
        "variants": [],
    }

    solver_matrices = solver.get_solver_matrices(str(input_path), 1, 0.7927)

    for name in names:
        parameters = VARIANTS[name]
        print(f"\n=== {name}: {parameters} ===", flush=True)
        set_seed(args.seed)
        _, details = solver.solve(
            str(input_path),
            1,
            num_iter_override=args.num_iter,
            progress_every=args.progress_every,
            return_details=True,
            opening_iterations=0,
            solver_matrices_override=solver_matrices,
            **parameters,
        )
        continuous = np.asarray(details.pop("continuous_image"), dtype=np.float64)
        details.pop("segmented_before_opening", None)
        continuous_path = output_dir / f"{name}_continuous.npy"
        np.save(continuous_path, continuous)
        np.save(
            output_dir / f"{name}_loss.npy",
            np.asarray(details.pop("loss_history"), dtype=np.float64),
        )
        details.pop("geo_loss_history", None)
        details.pop("final_reliability", None)
        details.pop("final_registration_raw", None)

        postprocessing: dict[str, object] = {}
        for opening in openings:
            segmented = solver.segment(continuous, opening_iterations=opening)
            image_path = output_dir / f"{name}_opening{opening}.png"
            save_labels(segmented, image_path)
            metrics = shape_metrics(truth, segmented)
            postprocessing[str(opening)] = {
                "opening": opening,
                "image_path": str(image_path),
                "metrics": metrics,
                "class_metrics": class_metrics(truth, segmented),
                "ktc_ssim": ktc_score(truth, segmented),
            }
            print(
                f"{name}, opening={opening}: IoU={metrics['foreground_iou']:.4f}, "
                f"notch={metrics['indentation_preservation']:.4f}, "
                f"convexity_error={metrics['convexity_absolute_error']:.4f}",
                flush=True,
            )

        summary["variants"].append(
            {
                "name": name,
                "parameters": parameters,
                "continuous_path": str(continuous_path),
                "final_total_loss": details["final_total_loss"],
                "postprocessing": postprocessing,
            }
        )

    with (output_dir / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    write_figure(
        truth,
        author,
        local_3000,
        summary["variants"],
        output_dir / "comparison.png",
    )
    print(f"Saved {output_dir / 'summary.json'}", flush=True)
    print(f"Saved {output_dir / 'comparison.png'}", flush=True)


if __name__ == "__main__":
    main()
