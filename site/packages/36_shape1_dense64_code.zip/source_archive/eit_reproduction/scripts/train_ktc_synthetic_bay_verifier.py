"""Train a synthetic-only topology verifier for parametric EIT bay edits.

The verifier is intentionally complementary to the public nested physics
ranker: CV/fixed-residual columns are removed from its input.  It learns from
independent base/stress CEM simulations whether a proposed exterior-connected
bay improves region, boundary, true open-deep cutout recovery, bank retention,
and their topology joint score.  Policy selection uses validation splits only;
test splits are opened once after the policy is frozen.
"""
from __future__ import annotations

import argparse
import json
import random
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


HEAD_NAMES = (
    "foreground_iou",
    "boundary_f1",
    "open_deep_cutout_recovery",
    "bank_retention",
    "topology_structural_joint",
)
SHAPE_FEATURE_COLUMNS = np.r_[0:72, 85:150]
STRESS_FAMILIES = (
    "deep_c", "deep_u", "keyhole_bay", "crescent", "heart_notch",
    "sharp_star", "reentrant_v", "multi_object_gap",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--stress-cache", type=Path,
        default=Path(r"E:\Codex\ktc_synthetic_instance_bay_cache_stress_seed20260820"),
    )
    parser.add_argument(
        "--base-cache", type=Path,
        default=Path(r"E:\Codex\ktc_synthetic_instance_bay_cache_base_seed20260820"),
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=Path(r"E:\Codex\ktc_synthetic_bay_verifier_seed20260820"),
    )
    parser.add_argument("--epochs", type=int, default=80)
    parser.add_argument("--ensemble-size", type=int, default=3)
    parser.add_argument("--case-batch-size", type=int, default=24)
    parser.add_argument("--candidates-per-case", type=int, default=96)
    parser.add_argument("--learning-rate", type=float, default=8e-4)
    parser.add_argument("--weight-decay", type=float, default=2e-4)
    parser.add_argument("--seed", type=int, default=20260820)
    parser.add_argument(
        "--checkpoint", type=Path, default=None,
        help="Reuse a trained ensemble and recalibrate the policy on validation data.",
    )
    return parser.parse_args()


@dataclass
class CachedCase:
    source: str
    split: str
    case_id: str
    features: np.ndarray
    targets: np.ndarray
    valid: np.ndarray
    global_index: int
    family: int


class BayVerifier(nn.Module):
    def __init__(self, feature_count: int, head_count: int) -> None:
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(feature_count, 224),
            nn.LayerNorm(224),
            nn.SiLU(),
            nn.Dropout(0.10),
            nn.Linear(224, 160),
            nn.LayerNorm(160),
            nn.SiLU(),
            nn.Dropout(0.08),
            nn.Linear(160, 96),
            nn.SiLU(),
            nn.Linear(96, head_count),
        )

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        return self.network(features)


@dataclass(frozen=True)
class Policy:
    min_iou: float
    min_boundary: float
    min_open_deep: float
    min_bank: float
    uncertainty: float
    agreement: float
    max_change: float
    max_removal: float
    open_weight: float
    topology_weight: float


POLICIES = tuple(
    Policy(iou, boundary, open_deep, bank, uncertainty, agreement, change, removal, open_weight, topology_weight)
    for iou in (-0.040, -0.020, 0.000)
    # Boundary regression is deliberately a soft ranking signal at -1.0;
    # stricter alternatives are retained for validation-only calibration.
    for boundary in (-1.000, -0.080, -0.030)
    for open_deep in (0.000, 0.050, 0.120)
    for bank in (-0.120, -0.060, -0.020)
    for uncertainty in (0.0, 0.5)
    for agreement in (0.00, 0.34)
    for change in (0.36, 0.62)
    for removal in (0.18, 0.36)
    for open_weight in (0.70, 1.20)
    for topology_weight in (0.50,)
) + (
    Policy(1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.36, 0.18, 0.70, 0.50),
)


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def load_split(root: Path, split: str, source: str) -> list[CachedCase]:
    cases: list[CachedCase] = []
    for path in sorted((root.resolve() / split).glob("sample_*.npz")):
        archive = np.load(path, allow_pickle=False)
        target_names = [str(value) for value in archive["target_names"]]
        target = np.asarray(archive["target_delta"], dtype=np.float32)
        selected_targets = target[:, [target_names.index(name) for name in HEAD_NAMES]]
        features_all = np.asarray(archive["features"], dtype=np.float32)
        features = features_all[:, SHAPE_FEATURE_COLUMNS]
        kind = np.asarray(archive["meta_kind"], dtype=np.int64)
        removed = np.asarray(archive["meta_removed"], dtype=np.float32)
        added = np.asarray(archive["meta_added"], dtype=np.float32)
        open_fraction = np.asarray(archive["meta_open"], dtype=np.float32)
        holes = np.asarray(archive["meta_new_holes"], dtype=np.float32)
        local_change = features_all[:, 3]
        valid = (
            (kind == 2)
            & (removed >= 0.005)
            & (added >= 0.005)
            & (local_change >= 0.015)
            & (open_fraction >= 0.995)
            & (holes == 0)
        )
        valid[0] = True
        cases.append(CachedCase(
            source=source,
            split=split,
            case_id=f"{source}/{split}/{path.stem}",
            features=features,
            targets=selected_targets,
            valid=valid,
            global_index=int(np.asarray(archive["global_index"]).item()),
            family=int(np.asarray(archive["family"]).item()),
        ))
    if not cases:
        raise FileNotFoundError(f"no cache files under {root / split}")
    return cases


def normalization(cases: list[CachedCase]) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    # Case-balanced moments prevent a many-component case from dominating.
    feature_mean = np.mean([case.features.mean(axis=0) for case in cases], axis=0)
    feature_second = np.mean([np.square(case.features).mean(axis=0) for case in cases], axis=0)
    feature_scale = np.sqrt(np.maximum(feature_second - np.square(feature_mean), 1e-8)).clip(min=1e-4)
    target_rows = np.concatenate([case.targets[np.isfinite(case.targets).all(axis=1)] for case in cases])
    target_scale = np.nanstd(target_rows, axis=0).clip(min=0.015)
    target_mean = np.zeros(len(HEAD_NAMES), dtype=np.float32)
    return (
        feature_mean.astype(np.float32), feature_scale.astype(np.float32),
        target_mean, target_scale.astype(np.float32),
    )


def sample_epoch(
    cases: list[CachedCase],
    rng: np.random.Generator,
    candidates_per_case: int,
) -> list[tuple[np.ndarray, np.ndarray, list[int]]]:
    order = rng.permutation(len(cases))
    output: list[tuple[np.ndarray, np.ndarray, list[int]]] = []
    for case_index in order:
        case = cases[int(case_index)]
        admissible = np.flatnonzero(case.valid)
        positives = admissible[np.any(case.targets[admissible] > 0.005, axis=1)]
        negatives = admissible[np.any(case.targets[admissible] < -0.005, axis=1)]
        random_count = max(8, candidates_per_case - len(positives[: candidates_per_case // 3]) - len(negatives[: candidates_per_case // 3]) - 1)
        random_selected = rng.choice(admissible, size=min(random_count, len(admissible)), replace=False)
        selected = np.unique(np.concatenate((
            np.asarray([0]),
            rng.choice(positives, size=min(len(positives), candidates_per_case // 3), replace=False),
            rng.choice(negatives, size=min(len(negatives), candidates_per_case // 3), replace=False),
            random_selected,
        )))
        if len(selected) > candidates_per_case:
            selected = selected[:candidates_per_case]
        output.append((case.features[selected], case.targets[selected], selected.tolist()))
    return output


def train_model(
    seed: int,
    train_cases: list[CachedCase],
    normalization_values: tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray],
    args: argparse.Namespace,
    device: torch.device,
) -> tuple[BayVerifier, list[dict[str, float]]]:
    set_seed(seed)
    feature_mean, feature_scale, target_mean, target_scale = normalization_values
    fm = torch.from_numpy(feature_mean).to(device)
    fs = torch.from_numpy(feature_scale).to(device)
    tm = torch.from_numpy(target_mean).to(device)
    ts = torch.from_numpy(target_scale).to(device)
    model = BayVerifier(len(feature_mean), len(HEAD_NAMES)).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay
    )
    rng = np.random.default_rng(seed)
    history: list[dict[str, float]] = []
    for epoch in range(args.epochs):
        model.train()
        sampled = sample_epoch(train_cases, rng, args.candidates_per_case)
        losses: list[float] = []
        optimizer.zero_grad(set_to_none=True)
        accumulated = 0
        for start in range(0, len(sampled), args.case_batch_size):
            case_batch = sampled[start : start + args.case_batch_size]
            features = torch.from_numpy(np.concatenate([row[0] for row in case_batch])).to(device)
            targets = torch.from_numpy(np.concatenate([row[1] for row in case_batch])).to(device)
            prediction = model((features - fm) / fs)
            normalized_target = (targets - tm) / ts
            finite = torch.isfinite(normalized_target)
            regression = F.smooth_l1_loss(
                prediction[finite], normalized_target[finite], beta=0.35
            )
            # Explicitly preserve the identity fixed point.
            identity_indices: list[int] = []
            offset = 0
            for features_case, _, selected in case_batch:
                if 0 in selected:
                    identity_indices.append(offset + selected.index(0))
                offset += len(features_case)
            identity = prediction[identity_indices].square().mean() if identity_indices else prediction.sum() * 0.0
            loss = regression + 0.10 * identity
            loss.backward()
            accumulated += 1
            if accumulated == 2 or start + args.case_batch_size >= len(sampled):
                torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
                optimizer.step()
                optimizer.zero_grad(set_to_none=True)
                accumulated = 0
            losses.append(float(loss.detach()))
        record = {"epoch": epoch + 1, "loss": float(np.mean(losses))}
        history.append(record)
        if epoch == 0 or (epoch + 1) % 10 == 0:
            print(f"seed={seed} epoch={epoch + 1}/{args.epochs} loss={record['loss']:.5f}", flush=True)
    model.eval()
    return model, history


@torch.no_grad()
def predict_cases(
    models: list[BayVerifier],
    cases: list[CachedCase],
    normalization_values: tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray],
    device: torch.device,
) -> dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]]:
    feature_mean, feature_scale, target_mean, target_scale = normalization_values
    fm = torch.from_numpy(feature_mean).to(device)
    fs = torch.from_numpy(feature_scale).to(device)
    tm = torch.from_numpy(target_mean).to(device)
    ts = torch.from_numpy(target_scale).to(device)
    output: dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]] = {}
    for case in cases:
        features = torch.from_numpy(case.features).to(device)
        matrix = torch.stack([model((features - fm) / fs) * ts + tm for model in models])
        matrix = matrix.cpu().numpy()
        matrix -= matrix[:, :1]
        output[case.case_id] = (
            matrix.mean(axis=0), matrix.std(axis=0), (matrix > 0.0).mean(axis=0)
        )
    return output


def choose(
    case: CachedCase,
    evidence: tuple[np.ndarray, np.ndarray, np.ndarray],
    policy: Policy,
) -> int:
    mean, std, agreement = evidence
    lower = mean - policy.uncertainty * std
    valid = case.valid.copy()
    # The physics-free matrix is original columns [0:72, 85:150], so original
    # meta_removed/meta_added columns 130/131 map to shape columns 117/118.
    removed = case.features[:, 117]
    added = case.features[:, 118]
    valid &= (removed + added) <= policy.max_change
    valid &= removed <= policy.max_removal
    valid &= agreement[:, 0] >= policy.agreement
    valid &= lower[:, 0] >= policy.min_iou
    valid &= lower[:, 1] >= policy.min_boundary
    valid &= lower[:, 2] >= policy.min_open_deep
    valid &= lower[:, 3] >= policy.min_bank
    valid[0] = True
    score = (
        lower[:, 0]
        + 0.25 * lower[:, 1]
        + policy.open_weight * lower[:, 2]
        + 0.25 * lower[:, 3]
        + policy.topology_weight * lower[:, 4]
    )
    score = np.where(valid, score, -np.inf)
    return int(np.argmax(score))


def policy_result(
    cases: list[CachedCase],
    predictions: dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]],
    policy: Policy,
) -> dict[str, object]:
    choices = np.asarray([choose(case, predictions[case.case_id], policy) for case in cases])
    values = np.stack([case.targets[choice] for case, choice in zip(cases, choices)])
    changed = choices != 0
    return {
        "choices": choices,
        "changed": int(changed.sum()),
        "mean_iou": float(values[:, 0].mean()),
        "mean_boundary": float(values[:, 1].mean()),
        "mean_open_deep": float(values[:, 2].mean()),
        "mean_bank": float(values[:, 3].mean()),
        "mean_topology": float(values[:, 4].mean()),
        "harmed_iou_005": int(np.count_nonzero(values[:, 0] < -0.005)),
        "harmed_iou_010": int(np.count_nonzero(values[:, 0] < -0.010)),
        "harmed_bank_010": int(np.count_nonzero(values[:, 3] < -0.010)),
        "improved_open_010": int(np.count_nonzero(values[:, 2] > 0.010)),
        "minimum_iou": float(values[:, 0].min()),
    }


def bootstrap_means(values: np.ndarray, seed: int, draws: int = 5000) -> dict[str, list[float]]:
    rng = np.random.default_rng(seed)
    sample_indices = rng.integers(0, len(values), size=(draws, len(values)))
    means = values[sample_indices].mean(axis=1)
    return {
        name: [float(x) for x in np.quantile(means[:, index], (0.025, 0.975))]
        for index, name in enumerate(HEAD_NAMES)
    }


def select_policy(
    base_cases: list[CachedCase],
    stress_cases: list[CachedCase],
    predictions: dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]],
) -> tuple[Policy, list[dict[str, object]]]:
    rows: list[dict[str, object]] = []
    best: tuple[tuple[float, ...], Policy] | None = None
    for policy in POLICIES:
        base = policy_result(base_cases, predictions, policy)
        stress = policy_result(stress_cases, predictions, policy)
        eligible = (
            base["mean_iou"] >= 0.0
            and base["minimum_iou"] >= -0.005
            and base["harmed_iou_010"] == 0
            and stress["mean_iou"] >= -0.001
            and stress["mean_bank"] >= -0.003
            and stress["harmed_iou_010"] <= max(1, int(round(0.005 * len(stress_cases))))
        )
        objective = (
            2.5 * stress["mean_open_deep"]
            + 1.5 * stress["mean_topology"]
            + stress["mean_iou"]
            + 0.50 * stress["mean_boundary"]
            + 0.50 * base["mean_iou"]
        )
        row = {
            **asdict(policy), "eligible": bool(eligible), "objective": float(objective),
            **{f"base_{key}": value for key, value in base.items() if key != "choices"},
            **{f"stress_{key}": value for key, value in stress.items() if key != "choices"},
        }
        rows.append(row)
        key = (
            1.0 if eligible else 0.0,
            float(objective),
            float(stress["mean_iou"]),
            float(base["mean_iou"]),
            -float(stress["changed"] + base["changed"]),
        )
        if best is None or key > best[0]:
            best = (key, policy)
    assert best is not None
    return best[1], rows


def summarize_test(
    cases: list[CachedCase],
    predictions: dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]],
    policy: Policy,
    seed: int,
) -> dict[str, object]:
    result = policy_result(cases, predictions, policy)
    choices = result.pop("choices")
    values = np.stack([case.targets[choice] for case, choice in zip(cases, choices)])
    result["case_count"] = len(cases)
    result["choices"] = choices.tolist()
    result["bootstrap_95_ci"] = bootstrap_means(values, seed)
    result["per_case"] = [
        {
            "case_id": case.case_id,
            "global_index": case.global_index,
            "family_code": case.family,
            "family": STRESS_FAMILIES[case.family] if 0 <= case.family < len(STRESS_FAMILIES) else "base",
            "candidate_index": int(choice),
            "changed": bool(choice != 0),
            **{name: float(value) for name, value in zip(HEAD_NAMES, target)},
        }
        for case, choice, target in zip(cases, choices, values)
    ]
    if any(case.family >= 0 for case in cases):
        result["per_family"] = {}
        for family_code, family_name in enumerate(STRESS_FAMILIES):
            selected = np.asarray([case.family == family_code for case in cases])
            family_values = values[selected]
            family_choices = choices[selected]
            result["per_family"][family_name] = {
                "case_count": int(selected.sum()),
                "changed": int(np.count_nonzero(family_choices)),
                **{
                    f"mean_{name}": float(family_values[:, index].mean())
                    for index, name in enumerate(HEAD_NAMES)
                },
                "minimum_iou": float(family_values[:, 0].min()),
                "bootstrap_95_ci": bootstrap_means(family_values, seed + 100 + family_code),
            }
    return result


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    train_cases = (
        load_split(args.base_cache, "base_train", "base")
        + load_split(args.stress_cache, "stress_train", "stress")
    )
    base_validation = load_split(args.base_cache, "base_validation", "base")
    stress_validation = load_split(args.stress_cache, "stress_validation", "stress")
    models: list[BayVerifier] = []
    histories: dict[str, object] = {}
    if args.checkpoint is not None:
        loaded = torch.load(args.checkpoint.resolve(), map_location=device, weights_only=False)
        norm = (
            np.asarray(loaded["feature_mean"], dtype=np.float32),
            np.asarray(loaded["feature_scale"], dtype=np.float32),
            np.asarray(loaded["target_mean"], dtype=np.float32),
            np.asarray(loaded["target_scale"], dtype=np.float32),
        )
        for state in loaded["models"]:
            model = BayVerifier(len(norm[0]), len(HEAD_NAMES)).to(device)
            model.load_state_dict(state)
            model.eval()
            models.append(model)
        histories["reused_checkpoint"] = str(args.checkpoint.resolve())
    else:
        norm = normalization(train_cases)
        for member in range(args.ensemble_size):
            seed = args.seed + member
            model, history = train_model(seed, train_cases, norm, args, device)
            models.append(model)
            histories[str(seed)] = history
    validation_cases = base_validation + stress_validation
    validation_predictions = predict_cases(models, validation_cases, norm, device)
    policy, calibration = select_policy(base_validation, stress_validation, validation_predictions)
    # Test labels are not loaded until training and validation-only policy
    # selection are complete.
    base_test = load_split(args.base_cache, "base_test", "base")
    stress_test = load_split(args.stress_cache, "stress_test", "stress")
    test_cases = base_test + stress_test
    test_predictions = predict_cases(models, test_cases, norm, device)
    test_summary = {
        "base": summarize_test(base_test, test_predictions, policy, args.seed + 5000),
        "stress": summarize_test(stress_test, test_predictions, policy, args.seed + 6000),
    }
    checkpoint = {
        "models": [model.state_dict() for model in models],
        "feature_mean": norm[0], "feature_scale": norm[1],
        "target_mean": norm[2], "target_scale": norm[3],
        "head_names": HEAD_NAMES,
        "shape_feature_columns": SHAPE_FEATURE_COLUMNS,
        "policy": asdict(policy),
        "args": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
    }
    torch.save(checkpoint, output_dir / "synthetic_bay_verifier.pt")
    (output_dir / "history.json").write_text(json.dumps(histories, indent=2), encoding="utf-8")
    (output_dir / "calibration.json").write_text(
        json.dumps(calibration, indent=2), encoding="utf-8"
    )
    summary = {
        "method": "synthetic-only shape/topology bay verifier ensemble",
        "public_cases_used_for_training_or_policy_selection": False,
        "physics_columns_excluded": list(range(72, 85)),
        "training_cases": len(train_cases),
        "validation_cases": {"base": len(base_validation), "stress": len(stress_validation)},
        "test_cases": {"base": len(base_test), "stress": len(stress_test)},
        "selected_policy": asdict(policy),
        "test": test_summary,
        "device": str(device),
    }
    (output_dir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps({
        "selected_policy": summary["selected_policy"],
        "base_test": {
            key: value for key, value in test_summary["base"].items()
            if key not in ("choices", "per_case")
        },
        "stress_test": {
            key: value for key, value in test_summary["stress"].items()
            if key not in ("choices", "per_case", "per_family")
        },
    }, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
