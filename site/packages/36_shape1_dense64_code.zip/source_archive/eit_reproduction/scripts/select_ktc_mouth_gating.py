"""Select a validation-only gate between a stable Boolean EIT branch and an
entrance-supervised branch.

The entrance branch is useful for open C/U-shaped lesions, but can over-cut
ordinary or weakly concave lesions.  This script treats the two reconstructions
as complementary proposals.  A case is accepted from the entrance branch only
when its foreground area, connected-component count, and predicted exterior
opening confidence are compatible with the stable branch.  All thresholds are
selected on synthetic validation splits and then frozen before test/public
evaluation.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import binary_dilation, label as connected_components

from prepare_ktc_deep_concavity_stress import FAMILIES
from train_ktc_concavity_network import InputAdapter, save_focus_montage, save_real_montage, write_rows
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_highres_refiner import load_coarse_ensemble
from train_ktc_implicit_boolean_network import (
    ImplicitBooleanNet,
    StructuralDataset,
    prepare_structural_arrays,
    standard_metrics,
    stress_metrics,
)
from calibrate_ktc_implicit_boolean import collect_raw_fields, predict_from_fields


STRUCTURE = np.ones((3, 3), dtype=np.uint8)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    parser.add_argument(
        "--stable-checkpoint", type=Path,
        default=root / "outputs" / "ktc_topology_boolean_smoke_seed20260819" / "implicit_boolean_best.pt",
    )
    parser.add_argument(
        "--entrance-checkpoint", type=Path,
        default=root / "outputs" / "ktc_mouth_contact_repeat2_soft_bank70_seed20260820" / "implicit_boolean_best.pt",
    )
    parser.add_argument(
        "--coarse-checkpoint", nargs="+", type=Path,
        default=[
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "boundary_best.pt",
            root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "indent_best.pt",
            root / "outputs" / "ktc_concavity_voltage_seed20260819" / "voltage_best.pt",
        ],
    )
    parser.add_argument("--coarse-weights", nargs="+", type=float, default=[0.30, 0.40, 0.30])
    parser.add_argument("--output-dir", type=Path, default=root / "outputs" / "ktc_mouth_gating_validation_seed20260820")
    parser.add_argument("--batch-size", type=int, default=24)
    parser.add_argument("--min-base-iou", type=float, default=0.0, help="Optional validation admissibility floor relative to stable branch.")
    return parser.parse_args()


def load_model(path: Path, device: torch.device) -> ImplicitBooleanNet:
    state = torch.load(path.resolve(), map_location=device, weights_only=False)
    model = ImplicitBooleanNet(int(state["base_channels"])).to(device)
    model.load_state_dict(state["model"], strict=False)
    model.use_external_connectivity = bool(state.get("external_connectivity", False))
    model.connectivity_steps = int(state.get("connectivity_steps", 28))
    model.eval()
    return model


@torch.no_grad()
def collect_entrance_fields(
    images: np.ndarray,
    voltages: np.ndarray,
    coarse: torch.nn.Module,
    model: ImplicitBooleanNet,
    adapter: InputAdapter,
    device: torch.device,
    batch_size: int,
) -> dict[str, np.ndarray]:
    values: dict[str, list[np.ndarray]] = {"prediction": [], "logits": [], "cutout": [], "support": [], "foreground": [], "mouth": [], "bank": []}
    for start in range(0, len(images), batch_size):
        image = torch.from_numpy(images[start : start + batch_size, None].astype(np.float32)).to(device)
        voltage = torch.from_numpy(voltages[start : start + batch_size].astype(np.float32)).to(device)
        adapted = adapter(image)
        base = torch.softmax(coarse(adapted, voltage)["logits"], dim=1)
        output = model(adapted, voltage, base)
        values["prediction"].append(output["logits"].argmax(dim=1).cpu().numpy().astype(np.uint8))
        values["logits"].append(output["logits"].cpu().numpy().astype(np.float32))
        values["cutout"].append(output["cutout_probability"][:, 0].cpu().numpy().astype(np.float32))
        values["support"].append(output["support_probability"][:, 0].cpu().numpy().astype(np.float32))
        values["foreground"].append(output["foreground_probability"][:, 0].cpu().numpy().astype(np.float32))
        values["mouth"].append(output["mouth_probability"][:, 0].cpu().numpy().astype(np.float32))
        values["bank"].append(output["bank_probability"][:, 0].cpu().numpy().astype(np.float32))
    return {key: np.concatenate(parts) for key, parts in values.items()}


def component_count(mask: np.ndarray) -> int:
    _, count = connected_components(mask.astype(np.uint8), structure=STRUCTURE)
    return int(count)


def opening_confidence(prediction: np.ndarray, cutout_probability: np.ndarray) -> float:
    """Model-only score: cutout confidence on a predicted exterior corridor."""
    background = prediction == 0
    components, count = connected_components(background.astype(np.uint8), structure=STRUCTURE)
    if count == 0:
        return 0.0
    border = np.unique(np.concatenate((components[0], components[-1], components[:, 0], components[:, -1])))
    exterior = np.isin(components, border[border != 0])
    # Ignore the broad exterior itself and score only pixels where the cutout
    # head independently predicts an inward background.
    inner = exterior & (cutout_probability > 0.5)
    return float(cutout_probability[inner].mean()) if inner.any() else 0.0


def case_features(stable: np.ndarray, entrance: np.ndarray, cutout: np.ndarray) -> dict[str, np.ndarray]:
    n = len(stable)
    stable_area = np.asarray([(x != 0).sum() for x in stable], dtype=np.float32)
    entrance_area = np.asarray([(x != 0).sum() for x in entrance], dtype=np.float32)
    area_ratio = entrance_area / np.maximum(stable_area, 1.0)
    stable_components = np.asarray([component_count(x != 0) for x in stable], dtype=np.int16)
    entrance_components = np.asarray([component_count(x != 0) for x in entrance], dtype=np.int16)
    opening = np.asarray([opening_confidence(p, c) for p, c in zip(entrance, cutout)], dtype=np.float32)
    return {
        "area_ratio": area_ratio,
        "stable_components": stable_components,
        "entrance_components": entrance_components,
        "opening_confidence": opening,
        "selected": np.zeros(n, dtype=bool),
    }


def apply_gate(features: dict[str, np.ndarray], area_threshold: float, allow_component_split: bool, opening_threshold: float) -> np.ndarray:
    area_ok = features["area_ratio"] >= area_threshold
    if allow_component_split:
        component_ok = np.ones_like(area_ok, dtype=bool)
    else:
        component_ok = features["entrance_components"] <= features["stable_components"]
    opening_ok = features["opening_confidence"] >= opening_threshold
    selected = area_ok & component_ok & opening_ok
    features["selected"] = selected
    return selected


def choose_gate(
    base_truth: np.ndarray,
    base_indent: np.ndarray,
    base_stable: np.ndarray,
    base_entrance: np.ndarray,
    stress_truth: np.ndarray,
    stress_cutout: np.ndarray,
    stress_depth: np.ndarray,
    stress_family: np.ndarray,
    stress_stable: np.ndarray,
    stress_entrance: np.ndarray,
    stress_cutout_probability: np.ndarray,
    base_features: dict[str, np.ndarray],
    stress_features: dict[str, np.ndarray],
    stable_base_metric: dict[str, float],
    stable_stress_metric: dict[str, float],
) -> tuple[dict[str, object], list[dict[str, object]]]:
    rows: list[dict[str, object]] = []
    best: dict[str, object] | None = None
    for area_threshold in (0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95):
        for allow_split in (False, True):
            for opening_threshold in (0.00, 0.50, 0.60, 0.70, 0.80, 0.90):
                base_use_entrance = apply_gate(base_features, area_threshold, allow_split, opening_threshold)
                stress_use_entrance = apply_gate(stress_features, area_threshold, allow_split, opening_threshold)
                base_pred = np.where(base_use_entrance[:, None, None], base_entrance, base_stable)
                stress_pred = np.where(stress_use_entrance[:, None, None], stress_entrance, stress_stable)
                base_metric = standard_metrics(base_truth, base_pred, base_indent)
                stress_metric, family_metric, _ = stress_metrics(
                    stress_truth, stress_pred, stress_cutout, stress_depth, stress_family
                )
                # The gate may improve open-cut recovery, but it is inadmissible
                # if it damages the stable branch on ordinary validation cases.
                eligible = (
                    base_metric["foreground_iou"] >= stable_base_metric["foreground_iou"] - 0.010
                    and base_metric["boundary_f1"] >= stable_base_metric["boundary_f1"] - 0.015
                    and stress_metric["foreground_iou"] >= stable_stress_metric["foreground_iou"] - 0.015
                    and stress_metric["bank_retention"] >= stable_stress_metric["bank_retention"] - 0.04
                )
                row: dict[str, object] = {
                    "area_threshold": area_threshold,
                    "allow_component_split": allow_split,
                    "opening_threshold": opening_threshold,
                    "eligible": bool(eligible),
                    "base_iou": base_metric["foreground_iou"],
                    "base_boundary_f1": base_metric["boundary_f1"],
                    "stress_iou": stress_metric["foreground_iou"],
                    "stress_boundary_f1": stress_metric["boundary_f1"],
                    "stress_open_deep_cutout": stress_metric["open_deep_cutout_recovery"],
                    "stress_bank_retention": stress_metric["bank_retention"],
                    "stress_topology_joint": stress_metric["topology_structural_joint"],
                    "deep_c_open_deep_cutout": family_metric["deep_c"]["open_deep_cutout_recovery"],
                    "deep_c_bank_retention": family_metric["deep_c"]["bank_retention"],
                    "base_entrance_fraction": float(base_use_entrance.mean()),
                    "stress_entrance_fraction": float(stress_use_entrance.mean()),
                }
                rows.append(row)
                key = (
                    float(row["stress_topology_joint"]),
                    float(row["deep_c_open_deep_cutout"]),
                    float(row["stress_open_deep_cutout"]),
                    -float(row["stress_entrance_fraction"]),
                )
                if bool(row["eligible"]) and (best is None or key > best["_key"]):
                    best = {**row, "_key": key}
    if best is None:
        eligible = [r for r in rows if r["eligible"]]
        best = max(eligible or rows, key=lambda r: (float(r["stress_topology_joint"]), float(r["deep_c_open_deep_cutout"])))
    best = {key: value for key, value in best.items() if key != "_key"}
    return best, rows


def save_gate_montage(path: Path, truth: np.ndarray, stable: np.ndarray, entrance: np.ndarray, gated: np.ndarray, selected: np.ndarray, title: str) -> None:
    chosen = list(range(min(len(truth), 16)))
    figure, axes = plt.subplots(len(chosen), 5, figsize=(12.0, 2.35 * len(chosen)), squeeze=False)
    for row, index in enumerate(chosen):
        for col, (image, name) in enumerate(((truth[index], "truth"), (stable[index], "stable Boolean"), (entrance[index], "entrance branch"), (gated[index], "gated"), (selected[index], "entrance selected"))):
            axes[row, col].imshow(image, cmap="viridis", vmin=0, vmax=2, interpolation="nearest")
            axes[row, col].set_title(name)
            axes[row, col].set_axis_off()
    figure.suptitle(title)
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    args.output_dir.resolve().mkdir(parents=True, exist_ok=True)
    base_archive = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress_archive = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    base = prepare_structural_arrays(base_archive, "base")
    stress = prepare_structural_arrays(stress_archive, "stress")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    coarse, _, weights = load_coarse_ensemble(args.coarse_checkpoint, args.coarse_weights, device)
    adapter = InputAdapter(base_archive["fov_mask"]).to(device)
    stable_model = load_model(args.stable_checkpoint, device)
    entrance_model = load_model(args.entrance_checkpoint, device)

    def infer_model(model: ImplicitBooleanNet, images: np.ndarray, voltages: np.ndarray, output_size: int | None = None) -> np.ndarray:
        fields = collect_raw_fields(images, voltages, coarse, model, adapter, device, args.batch_size)
        # The stable branch uses the validation-frozen calibration from the
        # preceding Boolean experiment.
        return predict_from_fields(fields, -1.25, 0.35, 0.70, output_size=output_size), fields

    def infer_entrance(images: np.ndarray, voltages: np.ndarray) -> tuple[np.ndarray, dict[str, np.ndarray]]:
        fields = collect_entrance_fields(images, voltages, coarse, entrance_model, adapter, device, args.batch_size)
        return fields["prediction"], fields

    base_val_idx = np.asarray(base_archive["validation_indices"], dtype=np.int64)
    stress_val_idx = np.asarray(stress_archive["validation_indices"], dtype=np.int64)
    base_stable_val, _ = infer_model(stable_model, base.images[base_val_idx], base.voltages[base_val_idx])
    stress_stable_val, _ = infer_model(stable_model, stress.images[stress_val_idx], stress.voltages[stress_val_idx])
    base_entrance_val, base_entrance_val_fields = infer_entrance(base.images[base_val_idx], base.voltages[base_val_idx])
    stress_entrance_val, stress_entrance_val_fields = infer_entrance(stress.images[stress_val_idx], stress.voltages[stress_val_idx])
    base_stable_metric = standard_metrics(base.labels[base_val_idx], base_stable_val, base.indentation[base_val_idx])
    stress_stable_metric, _, _ = stress_metrics(stress.labels[stress_val_idx], stress_stable_val, stress.cutout[stress_val_idx], stress.cutout_depth[stress_val_idx], stress.family_codes[stress_val_idx])
    base_features = case_features(base_stable_val, base_entrance_val, base_entrance_val_fields["cutout"])
    stress_features = case_features(stress_stable_val, stress_entrance_val, stress_entrance_val_fields["cutout"])
    selected, grid = choose_gate(
        base.labels[base_val_idx], base.indentation[base_val_idx], base_stable_val, base_entrance_val,
        stress.labels[stress_val_idx], stress.cutout[stress_val_idx], stress.cutout_depth[stress_val_idx], stress.family_codes[stress_val_idx],
        stress_stable_val, stress_entrance_val, stress_entrance_val_fields["cutout"], base_features, stress_features,
        base_stable_metric, stress_stable_metric,
    )
    with (args.output_dir.resolve() / "validation_grid.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(grid[0])); writer.writeheader(); writer.writerows(grid)

    def evaluate_split(name: str, base_stable: np.ndarray, base_entrance: np.ndarray, base_cutout: np.ndarray, stress_stable: np.ndarray, stress_entrance: np.ndarray, stress_cutout: np.ndarray, base_truth: np.ndarray, base_indent: np.ndarray, stress_truth: np.ndarray, stress_cutout_truth: np.ndarray, stress_depth: np.ndarray, stress_family: np.ndarray) -> tuple[dict[str, object], dict[str, np.ndarray]]:
        base_f = case_features(base_stable, base_entrance, base_cutout)
        stress_f = case_features(stress_stable, stress_entrance, stress_cutout)
        base_sel = apply_gate(base_f, float(selected["area_threshold"]), bool(selected["allow_component_split"]), float(selected["opening_threshold"]))
        stress_sel = apply_gate(stress_f, float(selected["area_threshold"]), bool(selected["allow_component_split"]), float(selected["opening_threshold"]))
        base_gated = np.where(base_sel[:, None, None], base_entrance, base_stable)
        stress_gated = np.where(stress_sel[:, None, None], stress_entrance, stress_stable)
        base_metrics = {"stable": standard_metrics(base_truth, base_stable, base_indent), "entrance": standard_metrics(base_truth, base_entrance, base_indent), "gated": standard_metrics(base_truth, base_gated, base_indent)}
        stress_metrics_all = {}
        for method, pred in (("stable", base_stable), ("entrance", base_entrance), ("gated", stress_gated)):
            if method == "stable": pred = stress_stable
            elif method == "entrance": pred = stress_entrance
            summary, family, rows = stress_metrics(stress_truth, pred, stress_cutout_truth, stress_depth, stress_family)
            stress_metrics_all[method] = {"summary": summary, "by_family": family, "rows": rows}
        selected_image = np.broadcast_to(base_sel[:, None, None], base_gated.shape).astype(np.uint8)
        save_gate_montage(args.output_dir.resolve() / f"{name}_gate_montage.png", base_truth, base_stable, base_entrance, base_gated, selected_image, f"{name}: stable versus entrance gate")
        return {"base": base_metrics, "stress": stress_metrics_all, "selected_fraction_base": float(base_sel.mean()), "selected_fraction_stress": float(stress_sel.mean())}, {"base": base_gated, "stress": stress_gated, "base_selected": base_sel, "stress_selected": stress_sel}

    base_test_idx = np.asarray(base_archive["test_indices"], dtype=np.int64)
    stress_test_idx = np.asarray(stress_archive["test_indices"], dtype=np.int64)
    base_stable_test, _ = infer_model(stable_model, base.images[base_test_idx], base.voltages[base_test_idx])
    stress_stable_test, _ = infer_model(stable_model, stress.images[stress_test_idx], stress.voltages[stress_test_idx])
    base_entrance_test, base_entrance_test_fields = infer_entrance(base.images[base_test_idx], base.voltages[base_test_idx])
    stress_entrance_test, stress_entrance_test_fields = infer_entrance(stress.images[stress_test_idx], stress.voltages[stress_test_idx])
    test_result, test_predictions = evaluate_split("test", base_stable_test, base_entrance_test, base_entrance_test_fields["cutout"], stress_stable_test, stress_entrance_test, stress_entrance_test_fields["cutout"], base.labels[base_test_idx], base.indentation[base_test_idx], stress.labels[stress_test_idx], stress.cutout[stress_test_idx], stress.cutout_depth[stress_test_idx], stress.family_codes[stress_test_idx])

    real_images = np.asarray(base_archive["real_linear_images"], dtype=np.float32)
    real_voltages = np.asarray(base_archive["real_voltages"], dtype=np.float32)
    real_stable, _ = infer_model(stable_model, real_images, real_voltages, output_size=256)
    real_entrance, real_fields = infer_entrance(real_images, real_voltages)
    real_entrance = F.interpolate(torch.from_numpy(real_fields["logits"]), size=(256, 256), mode="bilinear", align_corners=False).argmax(dim=1).numpy().astype(np.uint8)
    real_cutout = F.interpolate(torch.from_numpy(real_fields["cutout"][:, None]), size=(256, 256), mode="bilinear", align_corners=False)[:, 0].numpy()
    real_f = case_features(real_stable, real_entrance, real_cutout)
    real_sel = apply_gate(real_f, float(selected["area_threshold"]), bool(selected["allow_component_split"]), float(selected["opening_threshold"]))
    real_gated = np.where(real_sel[:, None, None], real_entrance, real_stable)
    real_truth = np.asarray(base_archive["real_labels"])
    real_ids = np.asarray(base_archive["real_ids"])
    real_predictions = {"stable_boolean": real_stable, "entrance_boolean": real_entrance, "gated_boolean": real_gated}
    real_summary: dict[str, dict[str, float]] = {}; real_rows: list[dict[str, object]] = []
    for method, pred in real_predictions.items():
        summary, rows = evaluate_real_predictions(method, pred, real_truth, real_ids); real_summary[method] = summary; real_rows.extend(rows)
    write_rows(args.output_dir.resolve() / "real_case_metrics.csv", real_rows)
    save_real_montage(args.output_dir.resolve() / "real_all_21_comparison.png", real_truth, real_ids, real_predictions, real_rows)
    save_focus_montage(args.output_dir.resolve() / "real_most_concave_comparison.png", real_truth, real_ids, real_predictions, real_rows)
    np.savez_compressed(args.output_dir.resolve() / "predictions.npz", base_test_indices=base_test_idx, stress_test_indices=stress_test_idx, base_stable=base_stable_test, base_entrance=base_entrance_test, base_gated=test_predictions["base"], stress_stable=stress_stable_test, stress_entrance=stress_entrance_test, stress_gated=test_predictions["stress"], real_stable=real_stable, real_entrance=real_entrance, real_gated=real_gated, real_selected=real_sel)
    result = {"method": "validation-only stable/entrance Boolean gate", "selected_gate": selected, "validation": {"stable_base": base_stable_metric, "stable_stress": stress_stable_metric}, "test": test_result, "real_evaluation": real_summary, "real_selected_fraction": float(real_sel.mean()), "evaluation_truth_used_for_training_or_selection": False, "stable_checkpoint": str(args.stable_checkpoint.resolve()), "entrance_checkpoint": str(args.entrance_checkpoint.resolve()), "coarse_weights": weights}
    (args.output_dir.resolve() / "summary.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
