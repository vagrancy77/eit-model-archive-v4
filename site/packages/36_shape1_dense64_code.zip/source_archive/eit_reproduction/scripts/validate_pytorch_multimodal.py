from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def load_json(path: Path) -> dict:
    require(path.exists(), f"missing artifact: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    synthetic_path = root / "datasets" / "multimodal_cem_v1.npz"
    public_path = root / "datasets" / "public_us_eit" / "public_us_eit_v1.npz"
    archive_path = root / "datasets" / "public_us_eit" / "Supplementary_Files.zip"
    require(synthetic_path.exists(), "missing prepared multimodal CEM dataset")
    require(public_path.exists(), "missing parsed public US-EIT dataset")
    synthetic = np.load(synthetic_path)
    public = np.load(public_path, allow_pickle=True)
    require(synthetic["baseline_grid"].shape == (1024, 64, 64), "invalid baseline grid")
    require(synthetic["ultrasound_grid"].shape == (1024, 64, 64), "invalid proxy ultrasound grid")
    require(synthetic["voltage_features"].shape == (1024, 208), "invalid CEM voltage features")
    require(synthetic["jacobian_scaled"].shape == (208, 560), "invalid Jacobian")
    require(public["baseline_tikhonov"].shape == (12, 200, 200), "invalid public Tikhonov data")
    require(public["pseudo_target_gn"].shape == (12, 200, 200), "invalid public GN data")
    require(public["voltage_features"].shape == (12, 416), "invalid complex public voltage data")
    archive_hash = hashlib.md5(archive_path.read_bytes()).hexdigest()
    require(archive_hash == "22e96c2dc08794381ea62e35c7fc2951", "public archive MD5 mismatch")

    training = load_json(root / "outputs_pytorch_multimodal" / "summary.json")
    require(training["parameters"] > 5_000_000, "network is unexpectedly small")
    multimodal = training["metrics"]["multimodal"]
    eit_only = training["metrics"]["eit_only"]
    require(multimodal["correlation"] > 0.95, "multimodal synthetic correlation is too low")
    require(multimodal["correlation"] > eit_only["correlation"], "ultrasound proxy did not improve correlation")
    require(multimodal["relative_l2"] < eit_only["relative_l2"], "ultrasound proxy did not improve relative L2")
    public_result = load_json(root / "outputs_public_us_eit" / "summary.json")
    require(public_result["fusion_correlation_to_public_gn"] > public_result["eit_only_correlation_to_public_gn"], "fusion did not improve agreement with the public GN pseudo-label")
    print("PyTorch multimodal EIT validation passed.")
    print(f"  parameters: {training['parameters']:,}")
    print(f"  synthetic correlation EIT-only -> fusion: {eit_only['correlation']:.4f} -> {multimodal['correlation']:.4f}")
    print(f"  public pseudo-GN correlation EIT-only -> fusion: {public_result['eit_only_correlation_to_public_gn']:.4f} -> {public_result['fusion_correlation_to_public_gn']:.4f}")


if __name__ == "__main__":
    main()

