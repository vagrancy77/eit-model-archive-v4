"""Fit low-dimensional non-convex level-set families directly to KTC voltages.

This is an intentionally independent reconstruction route.  Instead of asking a
pixel network to invent a missing bay, it optimizes a differentiable geometry
and an electrical contrast against the measured KTC Jacobian response.  The
templates are not used as ground-truth labels during fitting: on the public
cases every family is tried and the voltage residual chooses the candidate.

The stress set exposes the family code only for an oracle diagnostic.  The
reported ``all_family`` result still performs measurement-only selection.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F

from train_ktc_implicit_boolean_network import stress_metrics
from train_ktc_concavity_network_v2 import evaluate_real_predictions


FAMILY_NAMES = (
    "deep_c", "deep_u", "keyhole_bay", "crescent", "heart_notch",
    "sharp_star", "reentrant_v", "multi_object_gap",
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    p.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    p.add_argument("--shape-expert-predictions", type=Path, default=Path("E:/Codex/ktc_shape_expert_seed20260820/predictions.npz"))
    p.add_argument("--output-dir", type=Path, default=Path("E:/Codex/ktc_parametric_levelset_seed20260820"))
    p.add_argument("--steps", type=int, default=45)
    p.add_argument("--batch-size", type=int, default=32)
    p.add_argument("--restarts", type=int, default=1)
    p.add_argument("--stress-limit", type=int, default=0, help="0 uses the complete stress test split")
    p.add_argument("--real-only", action="store_true")
    p.add_argument("--seed", type=int, default=20260820)
    return p.parse_args()


def set_seed(seed: int) -> None:
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def make_grid(device: torch.device, size: int = 64) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    axis = torch.linspace(-1.0, 1.0, size, device=device)
    yy, xx = torch.meshgrid(axis, axis, indexing="ij")
    return xx, yy, (xx.square() + yy.square() <= 0.98**2).float()


def inverse_sigmoid(value: np.ndarray | float) -> np.ndarray:
    value = np.asarray(value, dtype=np.float32)
    value = np.clip(value, 1e-4, 1.0 - 1e-4)
    return np.log(value / (1.0 - value))


def initial_parameters(images: np.ndarray, xx: torch.Tensor, yy: torch.Tensor) -> torch.Tensor:
    """Moment initialization from the absolute ridge image, not the label."""
    image = np.abs(np.asarray(images, dtype=np.float32))
    b, h, w = image.shape
    gx = xx.detach().cpu().numpy()
    gy = yy.detach().cpu().numpy()
    weight = image + 1e-4
    weight /= weight.reshape(b, -1).sum(axis=1)[:, None, None]
    cx = (weight * gx).sum(axis=(1, 2)).clip(-0.42, 0.42)
    cy = (weight * gy).sum(axis=(1, 2)).clip(-0.42, 0.42)
    sx = np.sqrt((weight * (gx[None] - cx[:, None, None]) ** 2).sum(axis=(1, 2))) * 2.0
    sy = np.sqrt((weight * (gy[None] - cy[:, None, None]) ** 2).sum(axis=(1, 2))) * 2.0
    sx = np.clip(sx, 0.20, 0.56)
    sy = np.clip(sy, 0.20, 0.56)
    p = np.zeros((b, 8), dtype=np.float32)
    p[:, 0] = np.arctanh(cx / 0.55)
    p[:, 1] = np.arctanh(cy / 0.55)
    p[:, 2] = inverse_sigmoid((sx - 0.18) / 0.42)
    p[:, 3] = inverse_sigmoid((sy - 0.18) / 0.42)
    return torch.from_numpy(p)


def transform(p: torch.Tensor, xx: torch.Tensor, yy: torch.Tensor) -> tuple[torch.Tensor, ...]:
    cx = 0.55 * torch.tanh(p[:, 0])
    cy = 0.55 * torch.tanh(p[:, 1])
    sx = 0.18 + 0.42 * torch.sigmoid(p[:, 2])
    sy = 0.18 + 0.42 * torch.sigmoid(p[:, 3])
    theta = np.pi * torch.tanh(p[:, 4])
    ct, st = torch.cos(theta), torch.sin(theta)
    dx = xx[None] - cx[:, None, None]
    dy = yy[None] - cy[:, None, None]
    lx = ct[:, None, None] * dx + st[:, None, None] * dy
    ly = -st[:, None, None] * dx + ct[:, None, None] * dy
    return lx, ly, sx, sy


def soft_shape(p: torch.Tensor, family: int, xx: torch.Tensor, yy: torch.Tensor, fov: torch.Tensor) -> torch.Tensor:
    """Differentiable 64x64 occupancy for one geometric family."""
    lx, ly, sx, sy = transform(p, xx, yy)
    eps = 28.0
    ellipse = torch.sigmoid(eps * (1.0 - (lx / sx[:, None, None]).square() - (ly / sy[:, None, None]).square()))
    rect = torch.sigmoid(eps * (1.0 - (lx / sx[:, None, None]).abs())) * torch.sigmoid(eps * (1.0 - (ly / sy[:, None, None]).abs()))
    if family == 0:  # ellipse ring with a right-hand entrance
        wall = 0.10 + 0.35 * torch.sigmoid(p[:, 5])
        inner = torch.sigmoid(eps * (1.0 - (lx / (sx * (1.0 - wall))[:, None, None]).square() - (ly / (sy * (1.0 - wall))[:, None, None]).square()))
        mouth = 0.08 + 0.30 * torch.sigmoid(p[:, 6])
        opening = torch.sigmoid(eps * lx / sx[:, None, None]) * torch.sigmoid(eps * (mouth[:, None, None] - ly.abs() / sy[:, None, None]))
        return fov * ellipse * (1.0 - torch.maximum(inner, opening))
    if family == 1:  # U-shaped rectangular support
        half_width = 0.25 + 0.45 * torch.sigmoid(p[:, 5])
        floor = -(0.55 + 0.40 * torch.sigmoid(p[:, 6])) * sy
        cavity = torch.sigmoid(eps * (half_width[:, None, None] - lx.abs() / sx[:, None, None])) * torch.sigmoid(eps * ((ly - floor[:, None, None]) / sy[:, None, None]))
        return fov * rect * (1.0 - cavity)
    if family == 2:  # keyhole chamber + narrow corridor
        chamber_x = (-0.25 + 0.40 * torch.sigmoid(p[:, 5])) * sx
        radius = 0.20 + 0.25 * torch.sigmoid(p[:, 6])
        chamber = torch.sigmoid(eps * (radius[:, None, None].square() - ((lx - chamber_x[:, None, None]) / sx[:, None, None]).square() - (ly / sy[:, None, None]).square()))
        neck = 0.05 + 0.15 * torch.sigmoid(p[:, 7])
        corridor = torch.sigmoid(eps * (lx / sx[:, None, None] - chamber_x[:, None, None] / sx[:, None, None])) * torch.sigmoid(eps * (1.0 - lx / sx[:, None, None])) * torch.sigmoid(eps * (neck[:, None, None] - ly.abs() / sy[:, None, None]))
        return fov * ellipse * (1.0 - torch.maximum(chamber, corridor))
    if family == 3:  # crescent
        shift = 0.25 + 0.35 * torch.sigmoid(p[:, 5])
        inner = torch.sigmoid(eps * (1.0 - ((lx / sx[:, None, None] - shift[:, None, None]) / 0.82).square() - (ly / sy[:, None, None] / 0.86).square()))
        return fov * ellipse * (1.0 - inner)
    if family == 4:  # implicit heart with a notch-like upper boundary
        hx, hy = lx / sx[:, None, None], (ly + 0.13 * sy[:, None, None]) / sy[:, None, None]
        heart = (hx.square() + hy.square() - 0.72).pow(3) - hx.square() * hy.pow(3)
        return fov * ellipse * torch.sigmoid(-eps * heart)
    if family == 5:  # variable-frequency concave star
        radius = torch.sqrt((lx / sx[:, None, None]).square() + (ly / sy[:, None, None]).square())
        points = 5.0 + 3.0 * torch.sigmoid(p[:, 6])
        depth = 0.20 + 0.35 * torch.sigmoid(p[:, 5])
        target = 0.68 + depth[:, None, None] * torch.cos(points[:, None, None] * torch.atan2(ly, lx))
        return fov * torch.sigmoid(eps * (target - radius))
    if family == 6:  # re-entrant V bay
        depth = 0.50 + 0.60 * torch.sigmoid(p[:, 5])
        half_mouth = 0.20 + 0.40 * torch.sigmoid(p[:, 6])
        normalized_y = ((1.0 - ly / sy[:, None, None]) / depth[:, None, None]).clamp(0.0, 1.0)
        y_band = torch.sigmoid(eps * (ly / sy[:, None, None] - (1.0 - depth[:, None, None])))
        bay = y_band * torch.sigmoid(eps * (half_mouth[:, None, None] * normalized_y - lx.abs() / sx[:, None, None]))
        return fov * rect * (1.0 - bay)
    if family == 7:  # two objects separated by a narrow gap
        gap = 0.05 + 0.16 * torch.sigmoid(p[:, 5])
        rx = 0.40 + 0.16 * torch.sigmoid(p[:, 6])
        ry = 0.60 + 0.30 * torch.sigmoid(p[:, 7])
        offset = rx + gap / 2.0
        left = torch.sigmoid(eps * (1.0 - ((lx + offset[:, None, None]) / rx[:, None, None]).square() - (ly / ry[:, None, None]).square()))
        right = torch.sigmoid(eps * (1.0 - ((lx - offset[:, None, None]) / rx[:, None, None]).square() - (ly / ry[:, None, None]).square()))
        return fov * (left + right - left * right)
    raise ValueError(f"unknown family {family}")


def fit_family(
    voltages: np.ndarray,
    images: np.ndarray,
    family: int,
    jacobian: torch.Tensor,
    node_map: torch.Tensor,
    xx: torch.Tensor,
    yy: torch.Tensor,
    fov: torch.Tensor,
    area_prior: np.ndarray,
    steps: int,
    restarts: int,
    seed: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    device = jacobian.device
    target = torch.from_numpy(voltages.astype(np.float32)).to(device)
    b = target.shape[0]
    target_area = torch.from_numpy(np.asarray(area_prior, dtype=np.float32)).to(device).clamp_min(12.0)
    init = initial_parameters(images, xx, yy).to(device)
    best_loss = torch.full((b,), float("inf"), device=device)
    best_mask = torch.zeros((b, 64, 64), device=device)
    best_amp = torch.zeros((b,), device=device)
    generator = torch.Generator(device=device).manual_seed(seed + family * 17)
    for restart in range(restarts):
        p = torch.nn.Parameter(init.clone())
        if restart:
            p.data += 0.24 * torch.randn(p.shape, generator=generator, device=device)
        optimizer = torch.optim.Adam((p,), lr=0.075)
        target_scale = target.square().mean(dim=1).sqrt().clamp_min(1e-6)
        for _ in range(steps):
            optimizer.zero_grad(set_to_none=True)
            mask = soft_shape(p, family, xx, yy, fov)
            node = torch.flip(mask, dims=(1,)).flatten(1)[:, node_map]
            basis = 2.0 * (node @ jacobian.T)
            amplitude = (basis * target).sum(dim=1) / basis.square().sum(dim=1).clamp_min(1e-8)
            residual = ((amplitude[:, None] * basis - target) / target_scale[:, None]).square().mean(dim=1)
            # Voltage-only fitting has a degenerate solution: an almost empty
            # mask can explain a small fraction of the measurement and win the
            # normalized residual.  Keep the candidate in the same area scale
            # as the frozen coarse reconstruction, while still allowing the
            # boundary to move and form a bay.
            area = mask.sum(dim=(1, 2))
            area_penalty = ((area - target_area) / target_area).square()
            regularizer = 0.0008 * p.square().mean(dim=1)
            score = residual + 0.16 * area_penalty + regularizer
            loss = score.mean()
            loss.backward()
            torch.nn.utils.clip_grad_norm_((p,), 4.0)
            optimizer.step()
            with torch.no_grad():
                improved = score < best_loss
                best_loss = torch.where(improved, score, best_loss)
                best_mask = torch.where(improved[:, None, None], mask, best_mask)
                best_amp = torch.where(improved, amplitude, best_amp)
    return best_mask.detach().cpu().numpy(), best_loss.detach().cpu().numpy(), best_amp.detach().cpu().numpy()


def labels_from_masks(masks: np.ndarray, amplitudes: np.ndarray) -> np.ndarray:
    output = np.zeros(masks.shape, dtype=np.uint8)
    fg = masks >= 0.50
    output[fg & (amplitudes[:, None, None] < 0.0)] = 1
    output[fg & (amplitudes[:, None, None] >= 0.0)] = 2
    return output


def iou(truth: np.ndarray, prediction: np.ndarray) -> float:
    a, b = truth != 0, prediction != 0
    return float((a & b).sum() / max(1, (a | b).sum()))


def save_stress_montage(path: Path, truth: np.ndarray, param: np.ndarray, baseline: np.ndarray, ids: np.ndarray, families: np.ndarray) -> None:
    count = min(24, len(truth))
    fig, axes = plt.subplots(count, 4, figsize=(10.5, max(2.0, 2.3 * count)), squeeze=False)
    for row in range(count):
        for col, image in enumerate((truth[row], baseline[row], param[row], (truth[row] != 0) ^ (param[row] != 0))):
            axes[row, col].imshow(image, vmin=0, vmax=2, cmap="viridis")
            axes[row, col].axis("off")
        axes[row, 0].set_ylabel(f"{ids[row]}\n{FAMILY_NAMES[int(families[row])]}", fontsize=7)
    for axis, title in zip(axes[0], ("truth", "shape expert", "parametric fit", "xor")):
        axis.set_title(title)
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def save_real_montage(path: Path, truth: np.ndarray, param: np.ndarray, baseline: np.ndarray, ids: np.ndarray) -> None:
    focus = np.argsort([iou(t, p) for t, p in zip(truth, baseline)])[:12]
    fig, axes = plt.subplots(len(focus), 4, figsize=(10.5, max(2.0, 2.3 * len(focus))), squeeze=False)
    for row, index in enumerate(focus):
        for col, image in enumerate((truth[index], baseline[index], param[index], (truth[index] != 0) ^ (param[index] != 0))):
            axes[row, col].imshow(image, vmin=0, vmax=2, cmap="viridis"); axes[row, col].axis("off")
        axes[row, 0].set_ylabel(str(ids[index]), fontsize=7)
    for axis, title in zip(axes[0], ("truth", "shape expert", "parametric fit", "xor")):
        axis.set_title(title)
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def main() -> None:
    args = parse_args(); set_seed(args.seed)
    out = args.output_dir.resolve(); out.mkdir(parents=True, exist_ok=True)
    stress = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    base = np.load(args.base_dataset.resolve(), allow_pickle=False)
    predictions_archive = np.load(args.shape_expert_predictions.resolve(), allow_pickle=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"device={device}; fitting all eight geometric families", flush=True)
    jacobian = torch.from_numpy(stress["jacobian"].astype(np.float32)).to(device)
    node_map = torch.from_numpy(stress["node_to_raw_pixel"].astype(np.int64)).to(device)
    xx, yy, fov = make_grid(device)

    stress_indices = np.asarray(stress["test_indices"], dtype=np.int64)
    if args.stress_limit:
        stress_indices = stress_indices[: args.stress_limit]
    stress_voltages = stress["voltages"][stress_indices]
    stress_images = stress["linear_images"][stress_indices]
    stress_families = stress["family_codes"][stress_indices]
    all_masks = []; all_losses = []; all_amps = []
    for family in range(len(FAMILY_NAMES)):
        masks, losses, amps = fit_family(stress_voltages, stress_images, family, jacobian, node_map, xx, yy, fov, (predictions_archive["stress_expert"][: len(stress_indices)] != 0).sum(axis=(1, 2)), args.steps, args.restarts, args.seed)
        all_masks.append(masks); all_losses.append(losses); all_amps.append(amps)
        print(f"stress family {family} {FAMILY_NAMES[family]}: median normalized voltage loss={np.median(losses):.4f}", flush=True)
    all_losses_np = np.stack(all_losses, axis=1)
    selected = all_losses_np.argmin(axis=1)
    selected_masks = np.stack([all_masks[f][i] for i, f in enumerate(selected)])
    selected_amps = np.asarray([all_amps[f][i] for i, f in enumerate(selected)])
    param_labels = labels_from_masks(selected_masks, selected_amps)
    oracle_masks = np.stack([all_masks[int(f)][i] for i, f in enumerate(stress_families)])
    oracle_amps = np.asarray([all_amps[int(f)][i] for i, f in enumerate(stress_families)])
    oracle_labels = labels_from_masks(oracle_masks, oracle_amps)
    baseline = predictions_archive["stress_expert"][: len(stress_indices)]
    selected_metrics, _, selected_rows = stress_metrics(stress["labels"][stress_indices], param_labels, stress["cutout_masks"][stress_indices], stress["cutout_depth_weights"][stress_indices], stress_families)
    oracle_metrics, _, oracle_rows = stress_metrics(stress["labels"][stress_indices], oracle_labels, stress["cutout_masks"][stress_indices], stress["cutout_depth_weights"][stress_indices], stress_families)
    baseline_metrics, _, baseline_rows = stress_metrics(stress["labels"][stress_indices], baseline, stress["cutout_masks"][stress_indices], stress["cutout_depth_weights"][stress_indices], stress_families)
    np.savez_compressed(out / "stress_predictions.npz", indices=stress_indices, selected=param_labels, oracle=oracle_labels, selected_family=selected, family_losses=all_losses_np, selected_masks=selected_masks)
    save_stress_montage(out / "stress_comparison.png", stress["labels"][stress_indices], param_labels, baseline, stress_indices, stress_families)

    # The public labels remain a test-only evaluation target.  Every family is
    # fitted from voltage, then the lowest residual is selected per case.
    real_images = base["real_linear_images"]
    real_voltages = base["real_voltages"]
    real_truth = base["real_labels"]
    real_ids = base["real_ids"]
    real_losses = []; real_masks = []; real_amps = []
    for family in range(len(FAMILY_NAMES)):
        masks, losses, amps = fit_family(real_voltages, real_images, family, jacobian, node_map, xx, yy, fov, (predictions_archive["real_expert"] != 0).sum(axis=(1, 2)) / 16.0, args.steps, args.restarts, args.seed + 101)
        real_masks.append(masks); real_losses.append(losses); real_amps.append(amps)
        print(f"real family {family} {FAMILY_NAMES[family]}: median normalized voltage loss={np.median(losses):.4f}", flush=True)
    real_losses_np = np.stack(real_losses, axis=1)
    real_selected = real_losses_np.argmin(axis=1)
    real_mask64 = np.stack([real_masks[f][i] for i, f in enumerate(real_selected)])
    real_amp = np.asarray([real_amps[f][i] for i, f in enumerate(real_selected)])
    real_labels64 = labels_from_masks(real_mask64, real_amp)
    real_labels = np.repeat(np.repeat(real_labels64, 4, axis=1), 4, axis=2)
    real_baseline = predictions_archive["real_expert"]
    real_summary, _ = evaluate_real_predictions("parametric_levelset", real_labels, real_truth, real_ids)
    baseline_summary, _ = evaluate_real_predictions("shape_expert", real_baseline, real_truth, real_ids)
    np.savez_compressed(out / "real_predictions.npz", selected=real_labels, selected64=real_labels64, selected_family=real_selected, family_losses=real_losses_np, masks64=real_mask64)
    save_real_montage(out / "real_comparison.png", real_truth, real_labels, real_baseline, real_ids)

    summary = {
        "method": "measurement-only parametric level-set family fitting",
        "device": str(device), "steps": args.steps, "restarts": args.restarts,
        "stress": {"baseline_shape_expert": baseline_metrics, "all_family_selection": selected_metrics, "oracle_family": oracle_metrics},
        "real": {"baseline_shape_expert": baseline_summary, "all_family_selection": real_summary},
        "stress_family_selection_accuracy": float(np.mean(selected == stress_families)),
        "real_selected_families": {str(real_ids[i]): FAMILY_NAMES[int(real_selected[i])] for i in range(len(real_ids))},
    }
    (out / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
