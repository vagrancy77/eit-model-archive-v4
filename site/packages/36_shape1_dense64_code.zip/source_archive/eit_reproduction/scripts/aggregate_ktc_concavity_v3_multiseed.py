"""Aggregate frozen v3 runs with paired hierarchical seed/case bootstrap."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


METRICS = (
    "foreground_iou",
    "foreground_dice",
    "boundary_f1",
    "notch_preservation",
    "concavity_score",
    "ktc_ssim",
)
METHODS = ("vanilla", "candidate", "protected")


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", nargs="+", required=True, help="Entries formatted as seed=output_directory")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--bootstrap-repetitions", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260901)
    parser.add_argument("--ordinary-notch-pixels", type=float, default=12.0)
    parser.add_argument(
        "--audit",
        type=Path,
        default=root / "outputs" / "ktc2023_full_audit" / "summary.json",
    )
    return parser.parse_args()


def parse_runs(values: list[str]) -> list[tuple[str, Path]]:
    runs = []
    for value in values:
        if "=" not in value:
            raise ValueError(f"run must be seed=directory, got {value!r}")
        seed, path = value.split("=", 1)
        runs.append((seed, Path(path).resolve()))
    if len({seed for seed, _ in runs}) != len(runs):
        raise ValueError("run seed labels must be unique")
    if len(runs) < 2:
        raise ValueError("at least two runs are required for a multi-seed analysis")
    return runs


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def build_groups(
    synthetic_rows: list[dict[str, str]],
    real_rows: list[dict[str, str]],
    strict_ids: set[str],
    ordinary_limit: float,
) -> dict[str, list[str]]:
    groups: dict[str, list[str]] = {}
    partitions = sorted({row["partition"] for row in synthetic_rows})
    for partition in partitions:
        reference = [
            row for row in synthetic_rows if row["partition"] == partition and row["method"] == "vanilla"
        ]
        groups[partition] = sorted(row["id"] for row in reference)
        groups[f"{partition}_concave"] = sorted(
            row["id"] for row in reference if float(row["notch_pixels"]) >= ordinary_limit
        )
        groups[f"{partition}_ordinary"] = sorted(
            row["id"] for row in reference if float(row["notch_pixels"]) < ordinary_limit
        )
    real_ids = sorted(row["id"] for row in real_rows if row["method"] == "vanilla")
    groups["ktc2023_all"] = real_ids
    groups["ktc2023_audited_nonconvex"] = sorted(set(real_ids) & strict_ids)
    groups["ktc2023_audited_ordinary"] = sorted(set(real_ids) - strict_ids)
    return {name: ids for name, ids in groups.items() if ids}


def lookup_rows(rows: list[dict[str, str]]) -> dict[tuple[str, str], dict[str, str]]:
    return {(row["id"], row["method"]): row for row in rows}


def metric_matrix(
    lookups: list[dict[tuple[str, str], dict[str, str]]],
    case_ids: list[str],
    method: str,
    metric: str,
) -> np.ndarray:
    matrix = np.full((len(lookups), len(case_ids)), np.nan, dtype=np.float64)
    for seed_index, lookup in enumerate(lookups):
        for case_index, case_id in enumerate(case_ids):
            raw = lookup[(case_id, method)].get(metric, "")
            if raw not in (None, ""):
                matrix[seed_index, case_index] = float(raw)
    return matrix


def hierarchical_bootstrap(
    differences: np.ndarray,
    repetitions: int,
    rng: np.random.Generator,
) -> dict[str, float] | None:
    finite_columns = np.isfinite(differences).all(axis=0)
    differences = differences[:, finite_columns]
    if differences.size == 0:
        return None
    seed_count, case_count = differences.shape
    seed_draws = rng.integers(0, seed_count, size=(repetitions, seed_count))
    case_draws = rng.integers(0, case_count, size=(repetitions, case_count))
    samples = differences[seed_draws[:, :, None], case_draws[:, None, :]].mean(axis=(1, 2))
    return {
        "seeds": float(seed_count),
        "cases": float(case_count),
        "mean_difference": float(differences.mean()),
        "ci95_low": float(np.percentile(samples, 2.5)),
        "ci95_high": float(np.percentile(samples, 97.5)),
        "bootstrap_probability_positive": float((samples > 0).mean()),
    }


def summarize_group(
    lookups: list[dict[tuple[str, str], dict[str, str]]],
    case_ids: list[str],
    repetitions: int,
    rng: np.random.Generator,
) -> dict[str, object]:
    means: dict[str, dict[str, float]] = {}
    matrices: dict[tuple[str, str], np.ndarray] = {}
    for method in METHODS:
        means[method] = {}
        for metric in METRICS:
            matrix = metric_matrix(lookups, case_ids, method, metric)
            matrices[(method, metric)] = matrix
            finite = matrix[np.isfinite(matrix)]
            if finite.size:
                means[method][metric] = float(finite.mean())
    comparisons: dict[str, dict[str, object]] = {}
    for candidate in ("candidate", "protected"):
        comparison: dict[str, object] = {}
        for metric in METRICS:
            difference = matrices[(candidate, metric)] - matrices[("vanilla", metric)]
            result = hierarchical_bootstrap(difference, repetitions, rng)
            if result is not None:
                result["per_seed_mean_differences"] = [
                    float(np.nanmean(row)) for row in difference
                ]
                comparison[metric] = result
        comparisons[f"{candidate}_minus_vanilla"] = comparison
    return {
        "case_count": len(case_ids),
        "case_ids": case_ids,
        "method_means_across_seeds_and_cases": means,
        "paired_hierarchical_bootstrap": comparisons,
    }


def plot_key_results(path: Path, groups: dict[str, dict[str, object]]) -> None:
    preferred = (
        "biological_held_out_test",
        "deep_concavity_stress_test",
        "legacy_test_ordinary",
        "ktc2023_audited_nonconvex",
        "ktc2023_audited_ordinary",
    )
    selected = [name for name in preferred if name in groups]
    metrics = ("foreground_iou", "boundary_f1", "notch_preservation", "concavity_score")
    figure, axes = plt.subplots(len(selected), 1, figsize=(10.8, 3.0 * len(selected)), squeeze=False)
    x = np.arange(len(metrics))
    for axis, name in zip(axes[:, 0], selected):
        statistics = groups[name]["paired_hierarchical_bootstrap"]["protected_minus_vanilla"]
        available = [metric for metric in metrics if metric in statistics]
        values = np.asarray([statistics[metric]["mean_difference"] for metric in available])
        low = np.asarray([statistics[metric]["ci95_low"] for metric in available])
        high = np.asarray([statistics[metric]["ci95_high"] for metric in available])
        positions = x[: len(available)]
        colors = np.where(values >= 0, "#167d57", "#b53a3a")
        axis.bar(positions, values, width=0.62, color=colors)
        axis.errorbar(positions, values, yerr=(values - low, high - values), fmt="none", color="#222222", capsize=4)
        axis.axhline(0.0, color="#222222", linewidth=0.9)
        axis.set_xticks(positions, [metric.replace("_", " ") for metric in available])
        axis.set_title(name.replace("_", " "))
        axis.grid(axis="y", alpha=0.2)
    figure.suptitle("Protected model minus vanilla: hierarchical 95% confidence intervals")
    figure.tight_layout()
    figure.savefig(path, dpi=210)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    runs = parse_runs(args.runs)
    synthetic_by_seed = [read_rows(path / "synthetic_case_metrics.csv") for _, path in runs]
    real_by_seed = [read_rows(path / "real_case_metrics.csv") for _, path in runs]
    audit = json.loads(args.audit.resolve().read_text(encoding="utf-8"))
    strict_ids = set(str(value) for value in audit["nonconvex_ids"])
    group_ids = build_groups(
        synthetic_by_seed[0], real_by_seed[0], strict_ids, args.ordinary_notch_pixels
    )
    synthetic_lookups = [lookup_rows(rows) for rows in synthetic_by_seed]
    real_lookups = [lookup_rows(rows) for rows in real_by_seed]
    rng = np.random.default_rng(args.seed)
    groups: dict[str, dict[str, object]] = {}
    for name, case_ids in group_ids.items():
        lookups = real_lookups if name.startswith("ktc2023") else synthetic_lookups
        groups[name] = summarize_group(
            lookups, case_ids, args.bootstrap_repetitions, rng
        )

    selection_summaries = [
        json.loads((path.parent / "train" / "selection_summary.json").read_text(encoding="utf-8"))
        if (path.parent / "train" / "selection_summary.json").exists()
        else None
        for _, path in runs
    ]
    result = {
        "seeds": [seed for seed, _ in runs],
        "runs": {seed: str(path) for seed, path in runs},
        "methods": list(METHODS),
        "groups": groups,
        "bootstrap_repetitions": args.bootstrap_repetitions,
        "bootstrap_design": "paired hierarchical resampling of random seeds and fixed test cases",
        "test_truth_used_for_model_or_gate_selection": False,
        "training_selection_summaries_found": sum(summary is not None for summary in selection_summaries),
    }
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "summary.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    plot_key_results(output_dir / "multiseed_key_results.png", groups)
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
