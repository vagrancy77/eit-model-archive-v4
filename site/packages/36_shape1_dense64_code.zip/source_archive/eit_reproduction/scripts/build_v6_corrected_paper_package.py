"""Build the authoritative v6 simulation-paper result package.

This script only consumes frozen corrected runs and completed evaluations.  It
does not train, tune, or select a decision rule from test/public ground truth.
The test truth is used here only for final reporting and representative-case
visualization.
"""
from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(r"E:\Codex")
DEFAULT_RUNS = tuple(
    ROOT / f"topology_local_eit_v6_corrected_seed_{seed}"
    for seed in (20260911, 20260912, 20260913, 20260914)
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", nargs="+", type=Path, default=DEFAULT_RUNS)
    parser.add_argument(
        "--main-dir", type=Path,
        default=ROOT / "topology_local_eit_v6_corrected_multiseed_final",
    )
    parser.add_argument(
        "--ablation-dir", type=Path,
        default=ROOT / "topology_local_eit_v6_corrected_strict_ablation_final",
    )
    parser.add_argument(
        "--measurement-dir", type=Path,
        default=ROOT / "topology_local_eit_v6_corrected_measurement_shift_final",
    )
    parser.add_argument(
        "--physical-dir", type=Path,
        default=ROOT / "topology_local_eit_v6_corrected_physical_mismatch_final",
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=ROOT / "topology_local_eit_v6_corrected_paper_final",
    )
    return parser.parse_args()


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main_effect(
    summary: dict[str, Any], label: str, metric: str
) -> dict[str, Any]:
    return next(
        row for row in summary["effects"]
        if row["label"] == label
        and row["candidate"] == "gated_v6"
        and row["metric"] == metric
    )


def ablation_effect(
    summary: dict[str, Any], label: str, method: str, metric: str
) -> dict[str, Any]:
    comparison = f"{method}_minus_anchor_v4"
    return next(
        row for row in summary["effects"]
        if row["label"] == label
        and row["comparison"] == comparison
        and row["metric"] == metric
    )


def errorbar_points(
    axis: plt.Axes,
    labels: list[str],
    values: list[dict[str, Any]],
    title: str,
    zero: float = 0.0,
    color: str = "#167d6d",
) -> None:
    x = np.arange(len(labels))
    mean = np.asarray([float(value["mean_difference"]) for value in values])
    low = np.asarray([float(value["ci95_low"]) for value in values])
    high = np.asarray([float(value["ci95_high"]) for value in values])
    axis.errorbar(
        x,
        mean,
        yerr=np.maximum(0.0, np.vstack((mean - low, high - mean))),
        fmt="o",
        capsize=4,
        color=color,
        linewidth=1.8,
    )
    axis.axhline(zero, color="black", linestyle="--", linewidth=1)
    axis.set_xticks(x, labels, rotation=27, ha="right", fontsize=8)
    axis.set_title(title)
    axis.grid(axis="y", alpha=0.25)


def create_summary_figure(
    path: Path,
    main: dict[str, Any],
    ablation: dict[str, Any],
    measurement: dict[str, Any],
    physical: dict[str, Any],
) -> None:
    figure, axes = plt.subplots(2, 3, figsize=(17.0, 9.2))

    concave_labels = ["Biological", "Stress", "Public KTC", "Exact CEM"]
    concave_notch = [
        main_effect(main, "Biological concave", "notch_preservation"),
        main_effect(main, "Stress concave", "notch_preservation"),
        main_effect(main, "Public KTC nonconvex", "notch_preservation"),
        physical["groups"]["concave"]["conditions"]["nominal"]["comparisons"]
        ["gated_v6_minus_anchor_v4"]["notch_preservation"],
    ]
    errorbar_points(
        axes[0, 0], concave_labels, concave_notch,
        "A. Inward-boundary recovery (Notch delta)",
    )

    iou_labels = ["Bio concave", "Bio ordinary", "Stress", "Public", "CEM concave", "CEM ordinary"]
    iou_values = [
        main_effect(main, "Biological concave", "foreground_iou"),
        main_effect(main, "Biological ordinary", "foreground_iou"),
        main_effect(main, "Stress concave", "foreground_iou"),
        main_effect(main, "Public KTC nonconvex", "foreground_iou"),
        physical["groups"]["concave"]["conditions"]["nominal"]["comparisons"]
        ["gated_v6_minus_anchor_v4"]["foreground_iou"],
        physical["groups"]["ordinary"]["conditions"]["nominal"]["comparisons"]
        ["gated_v6_minus_anchor_v4"]["foreground_iou"],
    ]
    errorbar_points(
        axes[0, 1], iou_labels, iou_values,
        "B. Region accuracy (IoU delta)",
        color="#286f9e",
    )
    axes[0, 1].axhline(-0.003, color="#b33b3b", linestyle=":", linewidth=1.4)
    axes[0, 1].text(
        0.02, -0.003, " non-inferiority margin", color="#b33b3b",
        transform=axes[0, 1].get_yaxis_transform(), va="bottom", fontsize=8,
    )

    rate_specs = (
        ("Base concave", "Base concave"),
        ("Biological concave", "Bio concave"),
        ("Biological ordinary", "Bio ordinary"),
        ("Stress concave", "Stress"),
        ("Public KTC nonconvex", "Public concave"),
    )
    rate_labels = [display for _, display in rate_specs]
    rate_values = [main["rates"][key]["severe_iou_loss"] for key, _ in rate_specs]
    rate = np.asarray([float(value["rate"]) for value in rate_values])
    low = np.asarray([float(value["ci95_low"]) for value in rate_values])
    high = np.asarray([float(value["ci95_high"]) for value in rate_values])
    x = np.arange(len(rate_labels))
    axes[0, 2].errorbar(
        x, rate,
        yerr=np.maximum(0.0, np.vstack((rate - low, high - rate))),
        fmt="o", capsize=4, color="#a13d46",
    )
    axes[0, 2].set_xticks(x, rate_labels, rotation=27, ha="right", fontsize=8)
    axes[0, 2].set_ylim(bottom=0)
    axes[0, 2].set_title("C. Severe IoU-loss rate (> 0.01)")
    axes[0, 2].grid(axis="y", alpha=0.25)

    variants = ("no_physics", "no_topology_supervision", "no_connectivity", "full_dual_risk_gate")
    variant_labels = ("No physics BP", "No topology", "No connectivity", "Full gated")
    group_specs = (
        ("Biological concave", "#247ba0"),
        ("Stress concave", "#e07a5f"),
        ("Public KTC nonconvex", "#3d9970"),
    )
    for offset, (label, color) in enumerate(group_specs):
        values = [ablation_effect(ablation, label, variant, "notch_preservation") for variant in variants]
        mean = np.asarray([float(value["mean_difference"]) for value in values])
        low = np.asarray([float(value["ci95_low"]) for value in values])
        high = np.asarray([float(value["ci95_high"]) for value in values])
        axes[1, 0].errorbar(
            np.arange(len(variants)) + (offset - 1) * 0.12,
            mean,
            yerr=np.maximum(0.0, np.vstack((mean - low, high - mean))),
            fmt="o", capsize=3, color=color, label=label,
        )
    axes[1, 0].axhline(0, color="black", linestyle="--", linewidth=1)
    axes[1, 0].set_xticks(range(len(variants)), variant_labels, rotation=27, ha="right", fontsize=8)
    axes[1, 0].set_title("D. Strict component ablation (Notch delta)")
    axes[1, 0].legend(frameon=False, fontsize=7)
    axes[1, 0].grid(axis="y", alpha=0.25)

    condition_specs = (
        ("native", "Native"),
        ("snr_20db", "20 dB"),
        ("element_dropout_0p10", "10% random drop"),
        ("slot_dropout_8of76", "Drop 8 slots"),
        ("inverse_blur_sigma1", "Inverse blur"),
        ("inverse_grid_shift_1px", "Grid shift"),
    )
    measurement_values = [
        measurement["groups"]["biological_concave"]["conditions"][condition]
        ["comparisons"]["gated_v6_minus_anchor_v4"]["notch_preservation"]
        for condition, _ in condition_specs
    ]
    errorbar_points(
        axes[1, 1], [label for _, label in condition_specs], measurement_values,
        "E. Measurement-shift Notch delta", color="#7851a9",
    )

    physical_conditions = (
        ("nominal", "Nominal"),
        ("contact_global_2p4x", "Contact 2.4x"),
        ("contact_heterogeneous_logsd0p55", "Heterogeneous contact"),
        ("background_smooth_0p16", "Smooth background"),
        ("combined_contact_background", "Combined"),
    )
    physical_values = [
        physical["groups"]["concave"]["conditions"][condition]
        ["comparisons"]["gated_v6_minus_anchor_v4"]["notch_preservation"]
        for condition, _ in physical_conditions
    ]
    errorbar_points(
        axes[1, 2], [label for _, label in physical_conditions], physical_values,
        "F. Exact nonlinear-CEM Notch delta", color="#bf6f2f",
    )

    figure.suptitle(
        "Corrected v6: topology-aware local EIT correction with frozen dual-risk routing",
        fontsize=15,
    )
    figure.tight_layout(rect=(0, 0, 1, 0.965))
    figure.savefig(path, dpi=240)
    plt.close(figure)


def collect_case_records(runs: list[Path]) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for run in runs:
        rows = read_csv(run / "v6_case_metrics.csv")
        grouped: dict[tuple[str, str, str], dict[str, dict[str, str]]] = defaultdict(dict)
        for row in rows:
            grouped[(row["group"], row["case_id"], row["subset"])][row["method"]] = row
        for (group, case_id, subset), methods in grouped.items():
            anchor = methods["anchor_v4"]
            candidate = methods["candidate_v6"]
            gated = methods["gated_v6"]
            records.append(
                {
                    "seed": anchor["seed"],
                    "run": run,
                    "group": group,
                    "case_id": case_id,
                    "subset": subset,
                    "selected": bool(int(float(gated["gate_selected"]))),
                    "delta_iou": float(gated["foreground_iou"]) - float(anchor["foreground_iou"]),
                    "delta_notch": float(gated["notch_preservation"]) - float(anchor["notch_preservation"]),
                    "candidate_iou_loss": float(anchor["foreground_iou"]) - float(candidate["foreground_iou"]),
                    "anchor": anchor,
                    "candidate": candidate,
                    "gated": gated,
                }
            )
    return records


def choose_cases(records: list[dict[str, Any]]) -> list[tuple[str, dict[str, Any]]]:
    chosen: list[tuple[str, dict[str, Any]]] = []
    for group, label in (
        ("biological", "Biological concave success"),
        ("stress", "Unseen stress-shape success"),
        ("public_ktc", "Public KTC success"),
    ):
        candidates = [
            row for row in records
            if row["group"] == group and row["subset"] == "concave"
            and row["selected"] and row["delta_iou"] >= -0.02
            and np.isfinite(row["delta_notch"]) and row["delta_notch"] > 0.0
        ]
        if candidates:
            chosen.append((label, max(candidates, key=lambda row: row["delta_notch"])))

    protected = [
        row for row in records
        if row["subset"] == "ordinary" and not row["selected"]
    ]
    chosen.append(("Ordinary case protected by gate", max(protected, key=lambda row: row["candidate_iou_loss"])))

    ordinary = [row for row in records if row["subset"] == "ordinary"]
    chosen.append(("Worst ordinary failure (disclosed)", min(ordinary, key=lambda row: row["delta_iou"])))
    return chosen


def archive_prefix(group: str) -> str:
    return "public" if group == "public_ktc" else group


def archive_index(archive: np.lib.npyio.NpzFile, prefix: str, case_id: str) -> int:
    values = [str(value) for value in archive[f"{prefix}_ids"]]
    return values.index(case_id)


def create_case_figure(
    path: Path,
    selections: list[tuple[str, dict[str, Any]]],
) -> None:
    archives: dict[Path, np.lib.npyio.NpzFile] = {}
    figure, axes = plt.subplots(len(selections), 5, figsize=(12.6, 2.55 * len(selections)), squeeze=False)
    columns = ("Truth", "v4 anchor", "Predicted removal", "v6 candidate", "Final gated output")
    for row_index, (label, record) in enumerate(selections):
        run = record["run"]
        if run not in archives:
            archives[run] = np.load(run / "v6_predictions.npz", allow_pickle=False)
        archive = archives[run]
        prefix = archive_prefix(record["group"])
        index = archive_index(archive, prefix, record["case_id"])
        panels = (
            (archive[f"{prefix}_truth"][index], "viridis", 0, 2),
            (archive[f"{prefix}_anchor"][index], "viridis", 0, 2),
            (archive[f"{prefix}_removal"][index], "magma", 0, 1),
            (archive[f"{prefix}_candidate"][index], "viridis", 0, 2),
            (archive[f"{prefix}_gated"][index], "viridis", 0, 2),
        )
        for column, (image, cmap, vmin, vmax) in enumerate(panels):
            axes[row_index, column].imshow(
                image, cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest"
            )
            axes[row_index, column].set_axis_off()
            if row_index == 0:
                axes[row_index, column].set_title(columns[column], fontsize=10)
        notch_label = (
            "n/a"
            if not np.isfinite(float(record["delta_notch"]))
            else f"{float(record['delta_notch']):+.3f}"
        )
        axes[row_index, 0].text(
            0.02,
            0.02,
            f"{label}\nseed {record['seed']} / {record['case_id']}\n"
            f"gate={record['selected']}, dIoU={record['delta_iou']:+.3f}, "
            f"dNotch={notch_label}",
            transform=axes[row_index, 0].transAxes,
            color="white",
            fontsize=7.5,
            va="bottom",
            bbox={"facecolor": "black", "alpha": 0.72, "pad": 2},
        )
    for archive in archives.values():
        archive.close()
    figure.suptitle(
        "Independent cases: inward-boundary successes, safety fallback, and worst failure",
        fontsize=14,
    )
    figure.tight_layout(rect=(0, 0, 1, 0.975))
    figure.savefig(path, dpi=240)
    plt.close(figure)


def safety_by_variant(ablation_dir: Path) -> list[dict[str, Any]]:
    rows = read_csv(ablation_dir / "v6_ablation_case_metrics.csv")
    lookup = {
        (row["seed"], row["group"], row["case_id"], row["subset"], row["method"]): row
        for row in rows
    }
    variants = sorted({row["method"] for row in rows if row["method"] != "anchor_v4"})
    result: list[dict[str, Any]] = []
    for variant in variants:
        differences = []
        for row in rows:
            if row["group"] != "biological" or row["subset"] != "ordinary" or row["method"] != variant:
                continue
            anchor = lookup[(row["seed"], row["group"], row["case_id"], row["subset"], "anchor_v4")]
            differences.append(float(row["foreground_iou"]) - float(anchor["foreground_iou"]))
        values = np.asarray(differences, dtype=float)
        result.append(
            {
                "variant": variant,
                "biological_ordinary_cases": len(values),
                "mean_delta_iou": float(values.mean()),
                "severe_loss_rate": float(np.mean(values < -0.01)),
                "worst_delta_iou": float(values.min()),
            }
        )
    return result


def fmt_effect(value: dict[str, Any]) -> str:
    return (
        f"{float(value['mean_difference']):+.5f} "
        f"[{float(value['ci95_low']):+.5f}, {float(value['ci95_high']):+.5f}]"
    )


def write_report(
    path: Path,
    main: dict[str, Any],
    ablation: dict[str, Any],
    measurement: dict[str, Any],
    physical: dict[str, Any],
    safety: list[dict[str, Any]],
    selections: list[tuple[str, dict[str, Any]]],
) -> None:
    lines = [
        "# Corrected v6 Simulation-Methodology Paper Report",
        "",
        "## Bottom line",
        "",
        "The corrected four-seed experiment supports a narrow but reproducible claim: the frozen local topology corrector improves inward-boundary recovery relative to the v4 anchor while satisfying the predefined -0.003 IoU non-inferiority margin on biological concave and biological ordinary cases. The gain is statistically positive but small in population mean, and rare severe ordinary-case failures remain.",
        "",
        "This is sufficient for a simulation-methodology manuscript if the claim is written as topology-sensitive local correction with risk-controlled fallback. It is not evidence of a large general improvement in absolute EIT reconstruction, nor of clinical validity.",
        "",
        "## Protocol integrity",
        "",
        "- Matched seeds: 20260911-20260914.",
        "- Training and checkpoint selection used synthetic training/validation only.",
        "- Public and independent test truth was not used to tune checkpoints, thresholds, or routing rules.",
        "- All final intervals use 10,000 paired hierarchical bootstrap repetitions.",
        "- The corrected Boolean convex-hull indentation metric is authoritative; earlier uint8-mask reports are superseded.",
        "",
        "## Primary effects",
        "",
        "| Test subset | IoU delta (95% CI) | Notch delta (95% CI) | Severe IoU loss rate |",
        "|---|---:|---:|---:|",
    ]
    for label in ("Biological concave", "Stress concave", "Public KTC nonconvex"):
        iou = main_effect(main, label, "foreground_iou")
        notch = main_effect(main, label, "notch_preservation")
        rate = main["rates"][label]["severe_iou_loss"]
        lines.append(
            f"| {label} | {fmt_effect(iou)} | {fmt_effect(notch)} | "
            f"{rate['rate']:.4f} [{rate['ci95_low']:.4f}, {rate['ci95_high']:.4f}] |"
        )
    ordinary_iou = main_effect(main, "Biological ordinary", "foreground_iou")
    ordinary_rate = main["rates"]["Biological ordinary"]["severe_iou_loss"]
    lines.append(
        f"| Biological ordinary | {fmt_effect(ordinary_iou)} | n/a | "
        f"{ordinary_rate['rate']:.4f} [{ordinary_rate['ci95_low']:.4f}, {ordinary_rate['ci95_high']:.4f}] |"
    )

    lines.extend(
        [
            "",
            "All five preregistered criteria passed. The strongest supported result is the Notch trend; IoU changes are near zero. Bank retention decreased slightly, so the method should not be described as uniformly improving every boundary property.",
            "",
            "## Ablation interpretation",
            "",
            "Topology supervision is the necessary source of inward-boundary behavior: removing it collapses the correction to essentially zero. Physics backprojection and connectivity did not show stable positive mean-accuracy contributions across all datasets. They remain plausible sources of physical and structural context, but the present ablation does not establish an independent accuracy or safety benefit for either component.",
            "",
            "| Variant | Ordinary mean IoU delta | Severe-loss rate | Worst IoU delta |",
            "|---|---:|---:|---:|",
        ]
    )
    for row in safety:
        lines.append(
            f"| {row['variant']} | {row['mean_delta_iou']:+.5f} | "
            f"{row['severe_loss_rate']:.4f} | {row['worst_delta_iou']:+.5f} |"
        )

    physical_nominal = physical["groups"]["concave"]["conditions"]["nominal"]
    physical_background = physical["groups"]["concave"]["conditions"]["background_smooth_0p16"]
    measurement_native = measurement["groups"]["biological_concave"]["conditions"]["native"]
    measurement_dropout = measurement["groups"]["biological_concave"]["conditions"]["element_dropout_0p10"]
    lines.extend(
        [
            "",
            "## Distribution shifts",
            "",
            "The relative Notch effect remains positive under 20 dB noise, measurement/slot dropout, inverse-map shifts, contact-impedance mismatch, and smooth-background CEM mismatch. However, absolute gated reconstruction IoU degrades strongly when measurements are missing or the background conductivity distribution changes.",
            "",
            "| Evaluation | Relative IoU delta | Relative Notch delta | Absolute gated IoU degradation |",
            "|---|---:|---:|---:|",
            f"| Measurement native, biological concave | {fmt_effect(measurement_native['comparisons']['gated_v6_minus_anchor_v4']['foreground_iou'])} | {fmt_effect(measurement_native['comparisons']['gated_v6_minus_anchor_v4']['notch_preservation'])} | native |",
            f"| 10% random measurement dropout | {fmt_effect(measurement_dropout['comparisons']['gated_v6_minus_anchor_v4']['foreground_iou'])} | {fmt_effect(measurement_dropout['comparisons']['gated_v6_minus_anchor_v4']['notch_preservation'])} | {fmt_effect(measurement_dropout['degradation_from_native']['gated_v6']['foreground_iou'])} |",
            f"| Exact CEM nominal, concave | {fmt_effect(physical_nominal['comparisons']['gated_v6_minus_anchor_v4']['foreground_iou'])} | {fmt_effect(physical_nominal['comparisons']['gated_v6_minus_anchor_v4']['notch_preservation'])} | nominal |",
            f"| Exact CEM smooth-background mismatch | {fmt_effect(physical_background['comparisons']['gated_v6_minus_anchor_v4']['foreground_iou'])} | {fmt_effect(physical_background['comparisons']['gated_v6_minus_anchor_v4']['notch_preservation'])} | {fmt_effect(physical_background['degradation_from_nominal']['gated_v6']['foreground_iou'])} |",
            "",
            "Therefore the correct robustness statement is relative: v6 usually preserves a better inward-boundary trend than v4 under the same corrupted input. It does not make the underlying reconstruction immune to domain shift.",
            "",
            "## Rare failures and qualitative audit",
            "",
        ]
    )
    worst = min((record for _, record in selections if record["subset"] == "ordinary"), key=lambda row: row["delta_iou"])
    lines.extend(
        [
            f"The worst disclosed ordinary case is seed {worst['seed']}, case `{worst['case_id']}`, with IoU delta {worst['delta_iou']:+.5f}. This is consistent with the 2.25% biological-ordinary severe-loss rate and must remain in the limitations section.",
            "",
            "The final case montage deliberately includes successes, a gate-protected ordinary case, and this worst failure. It is not a best-case-only figure.",
            "",
            "## Manuscript-ready conclusion",
            "",
            "A defensible title is: *Physics- and topology-aware deep EIT with risk-controlled local correction for concave-boundary reconstruction*. The main contribution is not a new universal EIT backbone; it is a local topology correction mechanism, paired topology supervision, and validation-only dual-risk routing that recovers a small but consistent inward-boundary trend without violating the ordinary-case non-inferiority margin on average.",
            "",
            "Before a clinical or experimental-data claim, the remaining required work is real phantom/measurement validation and stronger domain adaptation for electrode dropout and background conductivity shifts.",
            "",
            "## Authoritative artifacts",
            "",
            "- `v6_paper_summary.png`: combined statistical evidence.",
            "- `v6_success_safety_failure_cases.png`: successes, safety fallback, and worst failure.",
            "- `v6_case_selection.csv`: exact cases used in the montage.",
            "- `v6_safety_by_variant.csv`: ordinary-case ablation safety audit.",
            "- `V6_CORRECTED_PAPER_REPORT.md`: this report.",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    runs = [path.resolve() for path in args.runs]
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    main_summary = load_json(args.main_dir / "v6_multiseed_summary.json")
    ablation_summary = load_json(args.ablation_dir / "v6_ablation_summary.json")
    measurement_summary = load_json(args.measurement_dir / "v6_measurement_shift_summary.json")
    physical_summary = load_json(args.physical_dir / "v6_physical_mismatch_summary.json")

    records = collect_case_records(runs)
    selections = choose_cases(records)
    safety = safety_by_variant(args.ablation_dir)

    create_summary_figure(
        output_dir / "v6_paper_summary.png",
        main_summary,
        ablation_summary,
        measurement_summary,
        physical_summary,
    )
    create_case_figure(
        output_dir / "v6_success_safety_failure_cases.png", selections
    )
    write_csv(
        output_dir / "v6_case_selection.csv",
        [
            {
                "role": role,
                "seed": record["seed"],
                "group": record["group"],
                "case_id": record["case_id"],
                "subset": record["subset"],
                "gate_selected": int(record["selected"]),
                "delta_iou": record["delta_iou"],
                "delta_notch": record["delta_notch"],
                "candidate_iou_loss": record["candidate_iou_loss"],
            }
            for role, record in selections
        ],
    )
    write_csv(output_dir / "v6_safety_by_variant.csv", safety)
    write_report(
        output_dir / "V6_CORRECTED_PAPER_REPORT.md",
        main_summary,
        ablation_summary,
        measurement_summary,
        physical_summary,
        safety,
        selections,
    )
    manifest = {
        "authoritative_corrected_boolean_notch_evaluation": True,
        "runs": [str(run) for run in runs],
        "sources": {
            "main": str(args.main_dir.resolve()),
            "ablation": str(args.ablation_dir.resolve()),
            "measurement_shift": str(args.measurement_dir.resolve()),
            "exact_cem": str(args.physical_dir.resolve()),
        },
        "test_truth_used_for_model_or_rule_selection": False,
        "test_truth_used_for_final_reporting_and_case_montage": True,
        "all_primary_criteria_met": bool(main_summary["all_primary_criteria_met"]),
    }
    (output_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps({"output_dir": str(output_dir), "cases": len(selections)}, indent=2))


if __name__ == "__main__":
    main()
