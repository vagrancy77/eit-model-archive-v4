"""Audit the topology-safe upper bound of the frozen candidate pool."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.ndimage import label as connected_components

from train_ktc_cross_representation_pixel_fusion import (
    STRICT_INWARD_IDS,
    foreground_iou_per_case,
    load_pool,
)


STRUCTURE = np.ones((3, 3), dtype=np.uint8)


def exterior_background(prediction: np.ndarray) -> np.ndarray:
    background = prediction == 0
    components, count = connected_components(background.astype(np.uint8), structure=STRUCTURE)
    if count == 0:
        return np.zeros_like(background)
    border = np.unique(np.concatenate((components[0], components[-1], components[:, 0], components[:, -1])))
    return np.isin(components, border[border != 0])


def topology_safe_candidates(candidates: np.ndarray) -> np.ndarray:
    safe = candidates.copy()
    baseline = candidates[0]
    for candidate_index in range(len(candidates)):
        for case_index in range(candidates.shape[1]):
            external = exterior_background(candidates[candidate_index, case_index])
            unsafe_hole = (candidates[candidate_index, case_index] == 0) & ~external
            safe[candidate_index, case_index][unsafe_hole] = baseline[case_index][unsafe_hole]
    return safe


def oracle_summary(truths: np.ndarray, candidates: np.ndarray) -> dict[str, float]:
    scores = np.stack([foreground_iou_per_case(truths, candidate) for candidate in candidates], axis=1)
    choice = scores.argmax(axis=1)
    casewise = candidates[choice, np.arange(len(choice))]
    pixelwise = candidates[0].copy()
    supported = (candidates == truths[None]).any(axis=0)
    pixelwise[supported] = truths[supported]
    return {
        "baseline_mean_iou": float(scores[:, 0].mean()),
        "casewise_oracle_mean_iou": float(scores.max(axis=1).mean()),
        "pixelwise_supported_oracle_mean_iou": float(foreground_iou_per_case(truths, pixelwise).mean()),
        "casewise_changed": int(np.count_nonzero(choice)),
    }


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    base = np.load(root / "datasets" / "ktc_shape_nonlinear_v1.npz", allow_pickle=False)
    stress = np.load(root / "datasets" / "ktc_deep_concavity_stress_v1.npz", allow_pickle=False)
    pool = root / "outputs" / "ktc_cross_representation_pool_seed20260820"
    result: dict[str, object] = {}
    for name, archive in (
        ("base_validation", base), ("base_test", base),
        ("stress_validation", stress), ("stress_test", stress),
    ):
        _, indices, candidates = load_pool(pool / f"{name}.npz")
        truths = np.asarray(archive["labels"][indices])
        result[name] = {
            "unrestricted": oracle_summary(truths, candidates),
            "exterior_connected": oracle_summary(truths, topology_safe_candidates(candidates)),
        }
    _, _, candidates = load_pool(pool / "public_21.npz")
    truths = np.asarray(base["real_labels"])
    ids = np.asarray(base["real_ids"])
    safe = topology_safe_candidates(candidates)
    strict = np.asarray([str(case_id) in STRICT_INWARD_IDS for case_id in ids])
    result["public_21"] = {
        "unrestricted": oracle_summary(truths, candidates),
        "exterior_connected": oracle_summary(truths, safe),
        "strict_inward_unrestricted": oracle_summary(truths[strict], candidates[:, strict]),
        "strict_inward_exterior_connected": oracle_summary(truths[strict], safe[:, strict]),
    }
    output = root / "outputs" / "ktc_cross_representation_pool_seed20260820" / "exterior_connected_audit.json"
    output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
