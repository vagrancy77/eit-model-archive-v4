param(
    [int[]]$Seeds = @(20260912, 20260913, 20260914),
    [string]$Python = 'E:\conda-envs\pytorch-gpu\python.exe',
    [string]$Root = 'E:\Codex'
)

$ErrorActionPreference = 'Stop'
$script = Join-Path $Root 'eit_reproduction\scripts\evaluate_topology_action_router.py'
foreach ($seed in $Seeds) {
    $trainingDir = Join-Path $Root "topology_risk_eit_v4_seed_$seed"
    $finalDir = Join-Path $Root "topology_risk_eit_v4_seed_${seed}_final"
    $outputDir = Join-Path $Root "topology_risk_eit_v4_router_seed_$seed"
    $summary = Join-Path $outputDir 'action_router_summary.json'
    if (Test-Path -LiteralPath $summary) {
        Write-Host "seed=$seed action router already complete; skipping"
        continue
    }
    Write-Host "seed=$seed validation-only action routing started at $(Get-Date -Format o)"
    & $Python $script `
        --checkpoint (Join-Path $trainingDir 'topology_residual_v4_best.pt') `
        --test-predictions (Join-Path $trainingDir 'test_predictions.npz') `
        --public-predictions (Join-Path $finalDir 'public_ktc_predictions.npz') `
        --output-dir $outputDir
    if ($LASTEXITCODE -ne 0) {
        throw "seed=$seed action routing failed with exit code $LASTEXITCODE"
    }
    Write-Host "seed=$seed action routing completed at $(Get-Date -Format o)"
}
