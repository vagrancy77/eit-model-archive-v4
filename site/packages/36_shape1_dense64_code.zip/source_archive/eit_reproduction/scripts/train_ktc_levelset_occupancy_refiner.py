"""Train a level-set occupancy refiner on frozen KTC Boolean fields.

The frozen EIT model supplies a coarse support/cutout decomposition.  This
second stage learns a continuous occupancy correction from those fields and
the raw ridge image.  It is intentionally trained on both the ordinary CEM
distribution and the independent deep-concavity distribution, so the model
can open a true bay without deleting the two banks that surround it.
"""
from __future__ import annotations

import argparse
import json
import math
import random
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import ConcatDataset, DataLoader

from train_ktc_concavity_network import (
    DecoderStage,
    InputAdapter,
    ResidualBlock,
    save_focus_montage,
    save_real_montage,
    write_rows,
)
from train_ktc_concavity_network_v2 import evaluate_real_predictions
from train_ktc_highres_refiner import load_coarse_ensemble
from train_ktc_implicit_boolean_network import (
    ImplicitBooleanNet,
    StructuralDataset,
    prepare_structural_arrays,
    standard_metrics,
    stress_metrics,
    soft_dice_loss,
    cutout_topology_loss,
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    parser.add_argument("--boolean-checkpoint", type=Path, required=True)
    parser.add_argument("--coarse-checkpoint", nargs="+", type=Path, default=[
        root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "boundary_best.pt",
        root / "outputs" / "ktc_concavity_v2_ablation_seed20260819" / "indent_best.pt",
        root / "outputs" / "ktc_concavity_voltage_seed20260819" / "voltage_best.pt",
    ])
    parser.add_argument("--coarse-weights", nargs="+", type=float, default=[0.30, 0.40, 0.30])
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--epochs", type=int, default=32)
    parser.add_argument("--patience", type=int, default=8)
    parser.add_argument("--batch-size", type=int, default=24)
    parser.add_argument("--base-channels", type=int, default=16)
    parser.add_argument("--learning-rate", type=float, default=1.2e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--seed", type=int, default=20260820)
    parser.add_argument("--stress-repeat", type=int, default=2)
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)


class ImplicitCorrectionField(nn.Module):
    """A spline-like multiresolution correction to the foreground logit."""

    def __init__(self, base: int) -> None:
        super().__init__()
        self.coarse = nn.Conv2d(base * 16, 1, 1)
        self.middle = nn.Conv2d(base * 4, 1, 1)
        self.fine = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))
        for layer in (self.coarse, self.middle, self.fine[-1]):
            nn.init.zeros_(layer.weight); nn.init.zeros_(layer.bias)

    def forward(self, bottleneck: torch.Tensor, middle: torch.Tensor, fine: torch.Tensor) -> torch.Tensor:
        size = fine.shape[-2:]
        coarse = F.interpolate(self.coarse(bottleneck), size=size, mode="bicubic", align_corners=False)
        middle_field = F.interpolate(self.middle(middle), size=size, mode="bicubic", align_corners=False)
        return 1.20 * torch.tanh(coarse) + 0.90 * torch.tanh(middle_field) + 0.60 * torch.tanh(self.fine(fine))


class OccupancyRefiner(nn.Module):
    """Predict a continuous entity occupancy correction with a learned gate."""

    def __init__(self, base: int) -> None:
        super().__init__()
        # adapted ridge (3), frozen class probabilities (3), and five Boolean
        # fields: support, cutout, mouth, bank, and foreground.
        self.stem = ResidualBlock(11, base)
        self.enc1 = ResidualBlock(base, base * 2)
        self.enc2 = ResidualBlock(base * 2, base * 4)
        self.enc3 = ResidualBlock(base * 4, base * 8)
        self.bottleneck = nn.Sequential(ResidualBlock(base * 8, base * 16), nn.Dropout2d(0.08), ResidualBlock(base * 16, base * 16))
        self.dec3 = DecoderStage(base * 16, base * 8, base * 8)
        self.dec2 = DecoderStage(base * 8, base * 4, base * 4)
        self.dec1 = DecoderStage(base * 4, base * 2, base * 2)
        self.dec0 = DecoderStage(base * 2, base, base)
        self.field = ImplicitCorrectionField(base)
        self.gate = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))
        self.sdf = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))
        nn.init.zeros_(self.gate[-1].weight); nn.init.constant_(self.gate[-1].bias, -1.5)
        nn.init.zeros_(self.sdf[-1].weight); nn.init.zeros_(self.sdf[-1].bias)

    def forward(self, features: torch.Tensor, base_output: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
        e0 = self.stem(features)
        e1 = self.enc1(F.max_pool2d(e0, 2)); e2 = self.enc2(F.max_pool2d(e1, 2)); e3 = self.enc3(F.max_pool2d(e2, 2))
        bottleneck = self.bottleneck(F.max_pool2d(e3, 2))
        d3 = self.dec3(bottleneck, e3); d2 = self.dec2(d3, e2); d1 = self.dec1(d2, e1); fine = self.dec0(d1, e0)
        correction = self.field(bottleneck, d2, fine)
        gate = torch.sigmoid(self.gate(fine))
        base_fg = base_output["foreground_probability"].clamp(1e-5, 1.0 - 1e-5)
        base_logit = torch.logit(base_fg)
        refined_field = base_logit + 2.6 * gate * correction
        foreground = torch.sigmoid(refined_field)
        polarity = base_output["polarity_probability"].clamp_min(1e-6)
        polarity = polarity / polarity.sum(dim=1, keepdim=True)
        probabilities = torch.cat((1.0 - foreground, foreground * polarity), dim=1).clamp_min(1e-7)
        return {
            "logits": torch.log(probabilities), "probabilities": probabilities,
            "foreground": foreground, "field": refined_field, "correction": correction,
            "gate": gate, "sdf": torch.tanh(self.sdf(fine)),
        }


def frozen_fields(
    coarse: torch.nn.Module, boolean: ImplicitBooleanNet, adapter: InputAdapter,
    image: torch.Tensor, voltage: torch.Tensor,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    adapted = adapter(image)
    with torch.no_grad():
        coarse_probability = torch.softmax(coarse(adapted, voltage)["logits"], dim=1)
        output = boolean(adapted, voltage, coarse_probability)
    fields = torch.cat((
        adapted,
        output["probabilities"].detach(),
        output["support_probability"].detach(),
        output["cutout_probability"].detach(),
        output["mouth_probability"].detach(),
        output["bank_probability"].detach(),
        output["foreground_probability"].detach(),
    ), dim=1)
    return fields, output


def gradients(image: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    return image[:, :, 1:, :] - image[:, :, :-1, :], image[:, :, :, 1:] - image[:, :, :, :-1]


def masked_mean(value: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    denom = mask.sum(dim=(1, 2, 3)); numer = (value * mask).sum(dim=(1, 2, 3))
    valid = denom > 0
    return (numer / denom.clamp_min(1.0))[valid].mean() if valid.any() else value.new_zeros(())


def refiner_loss(out: dict[str, torch.Tensor], base: dict[str, torch.Tensor], batch: dict[str, torch.Tensor], ramp: float) -> tuple[torch.Tensor, dict[str, float]]:
    labels = batch["labels"]
    foreground = out["foreground"]
    target_foreground = (labels != 0).float().unsqueeze(1)
    ce = F.nll_loss(out["logits"], labels, weight=out["logits"].new_tensor((0.35, 1.25, 1.25)))
    dice = soft_dice_loss(out["logits"], labels)
    dy, dx = gradients(foreground); ty, tx = gradients(target_foreground)
    boundary = F.l1_loss(dy, ty) + F.l1_loss(dx, tx)
    target_sdf = torch.minimum(batch["support_sdf"], -batch["cutout_sdf"]).clamp(-1.0, 1.0)
    sdf = F.smooth_l1_loss(out["sdf"], target_sdf, beta=0.08)
    cutout = batch["cutout"]
    depth = 1.0 + 3.0 * batch["cutout_depth"]
    notch_rim = cutout * F.max_pool2d(target_foreground, 11, stride=1, padding=5)
    banks = target_foreground * F.max_pool2d(cutout, 11, stride=1, padding=5)
    false_fill = masked_mean(foreground, notch_rim * depth)
    false_bank = masked_mean(1.0 - foreground, banks)
    support_domain = F.max_pool2d(batch["support"], 9, stride=1, padding=4)
    topology = cutout_topology_loss((1.0 - foreground) * support_domain, cutout, support_domain, 8)
    # Preserve already-correct, high-confidence ordinary boundaries. The
    # refiner is allowed to alter the uncertain cutout neighborhood.
    base_prob = base["probabilities"]
    base_pred = base_prob.argmax(dim=1)
    confident = (base_prob.max(dim=1).values > 0.86) & (base_pred == labels)
    uncertain_band = F.max_pool2d((cutout > 0).float(), 11, stride=1, padding=5)[:, 0] > 0
    identity = masked_mean((out["probabilities"] - base_prob).abs().sum(dim=1, keepdim=True), (confident & ~uncertain_band).float().unsqueeze(1))
    residual = (out["gate"] * out["correction"].abs()).mean()
    total = ce + dice + ramp * (0.30 * boundary + 0.30 * sdf + 0.58 * false_fill + 0.68 * false_bank + 0.24 * topology + 0.16 * identity + 0.018 * residual)
    parts = {"total": total, "ce": ce, "dice": dice, "boundary": boundary, "sdf": sdf, "false_fill": false_fill, "false_bank": false_bank, "topology": topology, "identity": identity}
    return total, {key: float(value.detach()) for key, value in parts.items()}


@torch.no_grad()
def infer_arrays(coarse, boolean, refiner, adapter, arrays, indices, device, batch_size):
    loader = DataLoader(StructuralDataset(arrays, indices, 0), batch_size=batch_size, shuffle=False)
    predictions = []; fields = []
    for batch in loader:
        image = batch["image"].to(device); voltage = batch["voltage"].to(device)
        x, base = frozen_fields(coarse, boolean, adapter, image, voltage)
        out = refiner(x, base)
        predictions.append(out["logits"].argmax(dim=1).cpu().numpy().astype(np.uint8))
        fields.append(out["logits"].cpu().numpy().astype(np.float32))
    return np.concatenate(predictions), np.concatenate(fields)


def main() -> None:
    args = parse_args(); set_seed(args.seed)
    out_dir = args.output_dir.resolve(); out_dir.mkdir(parents=True, exist_ok=True)
    base_archive = np.load(args.base_dataset.resolve(), allow_pickle=False); stress_archive = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    base_arrays = prepare_structural_arrays(base_archive, "base"); stress_arrays = prepare_structural_arrays(stress_archive, "stress")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    coarse, _, weights = load_coarse_ensemble(args.coarse_checkpoint, args.coarse_weights, device)
    state = torch.load(args.boolean_checkpoint.resolve(), map_location=device, weights_only=False)
    boolean = ImplicitBooleanNet(int(state["base_channels"])).to(device); boolean.load_state_dict(state["model"], strict=False); boolean.eval(); boolean.requires_grad_(False)
    adapter = InputAdapter(base_archive["fov_mask"]).to(device)
    refiner = OccupancyRefiner(args.base_channels).to(device)
    optimizer = torch.optim.AdamW(refiner.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    train = ConcatDataset((StructuralDataset(base_arrays, base_archive["train_indices"], 0), *([StructuralDataset(stress_arrays, stress_archive["train_indices"], 1)] * max(1, args.stress_repeat))))
    loader = DataLoader(train, batch_size=args.batch_size, shuffle=True, drop_last=True, num_workers=args.workers, pin_memory=device.type == "cuda")
    best_score = -math.inf; stale = 0; history = []; checkpoint = out_dir / "occupancy_refiner_best.pt"
    base_val = np.asarray(base_archive["validation_indices"], dtype=np.int64); stress_val = np.asarray(stress_archive["validation_indices"], dtype=np.int64)
    for epoch in range(1, args.epochs + 1):
        refiner.train(); records = []; ramp = min(1.0, epoch / 7.0)
        for batch in loader:
            moved = {key: value.to(device, non_blocking=True) for key, value in batch.items()}
            image = moved["image"]; voltage = moved["voltage"]
            x, base = frozen_fields(coarse, boolean, adapter, image, voltage)
            optimizer.zero_grad(set_to_none=True)
            with torch.amp.autocast("cuda", enabled=device.type == "cuda"):
                output = refiner(x, base); loss, parts = refiner_loss(output, base, moved, ramp)
            scaler.scale(loss).backward(); scaler.unscale_(optimizer); torch.nn.utils.clip_grad_norm_(refiner.parameters(), 5.0); scaler.step(optimizer); scaler.update()
            records.append(parts)
        scheduler.step()
        refiner.eval()
        bp, _ = infer_arrays(coarse, boolean, refiner, adapter, base_arrays, base_val, device, args.batch_size)
        sp, _ = infer_arrays(coarse, boolean, refiner, adapter, stress_arrays, stress_val, device, args.batch_size)
        bm = standard_metrics(base_arrays.labels[base_val], bp, base_arrays.indentation[base_val]); sm, _, _ = stress_metrics(stress_arrays.labels[stress_val], sp, stress_arrays.cutout[stress_val], stress_arrays.cutout_depth[stress_val], stress_arrays.family_codes[stress_val])
        score = 0.30 * bm["foreground_iou"] + 0.25 * sm["foreground_iou"] + 0.20 * sm["open_deep_cutout_recovery"] + 0.15 * sm["bank_retention"] + 0.10 * sm["topology_structural_joint"]
        eligible = bm["foreground_iou"] >= 0.584 - 0.012 and sm["foreground_iou"] >= 0.589 - 0.015 and sm["bank_retention"] >= 0.70
        row = {"epoch": epoch, "score": score, "eligible": eligible, "base_iou": bm["foreground_iou"], "stress_iou": sm["foreground_iou"], "open_deep": sm["open_deep_cutout_recovery"], "bank": sm["bank_retention"], "topology": sm["topology_structural_joint"], "train_loss": float(np.mean([r["total"] for r in records]))}
        history.append(row); print(f"epoch {epoch:03d}: score={score:.4f} base={row['base_iou']:.4f} stress={row['stress_iou']:.4f} open={row['open_deep']:.4f} bank={row['bank']:.4f}", flush=True)
        if eligible and score > best_score + 1e-5:
            best_score = score; stale = 0; torch.save({"model": refiner.state_dict(), "base_channels": args.base_channels, "epoch": epoch, "validation": row, "boolean_checkpoint": str(args.boolean_checkpoint.resolve())}, checkpoint)
        else: stale += 1
        if stale >= args.patience and checkpoint.exists(): break
    if not checkpoint.exists():
        raise RuntimeError("No occupancy refiner checkpoint satisfied validation constraints")
    refiner.load_state_dict(torch.load(checkpoint, map_location=device, weights_only=False)["model"]); refiner.eval()
    bt = np.asarray(base_archive["test_indices"], dtype=np.int64); st = np.asarray(stress_archive["test_indices"], dtype=np.int64)
    bp, blogits = infer_arrays(coarse, boolean, refiner, adapter, base_arrays, bt, device, args.batch_size); sp, slogits = infer_arrays(coarse, boolean, refiner, adapter, stress_arrays, st, device, args.batch_size)
    bm = standard_metrics(base_arrays.labels[bt], bp, base_arrays.indentation[bt]); sm, fam, rows = stress_metrics(stress_arrays.labels[st], sp, stress_arrays.cutout[st], stress_arrays.cutout_depth[st], stress_arrays.family_codes[st])
    # Public labels are opened only after model selection and synthetic test.
    real_images = np.asarray(base_archive["real_linear_images"], dtype=np.float32); real_voltages = np.asarray(base_archive["real_voltages"], dtype=np.float32)
    real_chunks = []
    for start in range(0, len(real_images), args.batch_size):
        image = torch.from_numpy(real_images[start:start + args.batch_size, None]).to(device); voltage = torch.from_numpy(real_voltages[start:start + args.batch_size]).to(device)
        x, base = frozen_fields(coarse, boolean, adapter, image, voltage); real_chunks.append(F.interpolate(refiner(x, base)["logits"], size=(256, 256), mode="bilinear", align_corners=False).argmax(dim=1).cpu().numpy().astype(np.uint8))
    real_prediction = np.concatenate(real_chunks); truth = np.asarray(base_archive["real_labels"]); ids = np.asarray(base_archive["real_ids"]); real_summary, real_rows = evaluate_real_predictions("occupancy_refiner", real_prediction, truth, ids)
    write_rows(out_dir / "real_case_metrics.csv", real_rows); save_real_montage(out_dir / "real_all_21_comparison.png", truth, ids, {"occupancy_refiner": real_prediction}, real_rows); save_focus_montage(out_dir / "real_most_concave_comparison.png", truth, ids, {"occupancy_refiner": real_prediction}, real_rows)
    np.savez_compressed(out_dir / "predictions.npz", base_test_indices=bt, stress_test_indices=st, base_refiner=bp, stress_refiner=sp, real_refiner=real_prediction)
    result = {"method": "frozen Boolean fields + continuous occupancy level-set refiner", "device": str(device), "seed": args.seed, "boolean_checkpoint": str(args.boolean_checkpoint.resolve()), "coarse_weights": weights, "validation_history": history, "synthetic_test": {"base": bm, "stress": {"summary": sm, "by_family": fam, "rows": rows}}, "real_evaluation": {"occupancy_refiner": real_summary}, "evaluation_truth_used_for_training_or_selection": False}
    (out_dir / "summary.json").write_text(json.dumps(result, indent=2, default=str), encoding="utf-8"); print(json.dumps(result, indent=2, default=str), flush=True)


if __name__ == "__main__": main()
