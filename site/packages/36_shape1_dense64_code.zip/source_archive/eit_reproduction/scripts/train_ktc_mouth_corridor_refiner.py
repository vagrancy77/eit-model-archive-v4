"""Train a precision-oriented mouth-corridor field for concave EIT targets.

The previous pixel refiner was trained by replacing almost the full cutout
with foreground and carving a smaller cavity.  Its target was consequently an
annulus, so the network learned to erode the entire cavity bank.  This version
creates a naturalistic error instead: only the open mouth of a true indentation
is sealed.  The target is therefore the missing bridge/corridor itself.

The model architecture and inference interface stay compatible with the
dual-gated evaluator.  Only synthetic train/validation splits are used here.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import distance_transform_edt
from torch.utils.data import DataLoader

from fuse_ktc_joint_shape_models import blend, load_model
from train_ktc_candidate_opening_refiner import (
    find_candidates,
    pseudo_probabilities,
    set_seed,
    synthetic_negative,
)
from train_ktc_concavity_network import InputAdapter
from train_ktc_connected_cutout_refiner_v2 import (
    ConnectedCutoutNet,
    PixelDataset,
    PixelExamples,
    add_largest_candidate,
    infer_pair,
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    parser.add_argument("--conservative", type=Path, default=Path("E:/Codex/ktc_joint_shape_pretrained_seed20260820/best.pt"))
    parser.add_argument("--aggressive", type=Path, default=Path("E:/Codex/ktc_joint_shape_network_seed20260820/best.pt"))
    parser.add_argument("--output-dir", type=Path, default=Path("E:/Codex/ktc_mouth_corridor_refiner_seed20260820"))
    parser.add_argument("--epochs", type=int, default=28)
    parser.add_argument("--batch-size", type=int, default=28)
    parser.add_argument("--inference-batch-size", type=int, default=48)
    parser.add_argument("--learning-rate", type=float, default=1.2e-3)
    parser.add_argument("--weight-decay", type=float, default=2e-4)
    parser.add_argument("--patience", type=int, default=8)
    parser.add_argument("--seed", type=int, default=20260820)
    return parser.parse_args()


def bridge_positive(
    truth: np.ndarray,
    support: np.ndarray,
    cutout: np.ndarray,
    conservative: np.ndarray,
    aggressive: np.ndarray,
    thickness: float,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray, np.ndarray] | None:
    """Seal only the cutout pixels at the support/exterior interface."""
    support = support.astype(bool)
    cutout = cutout.astype(bool)
    if int(cutout.sum()) < 8:
        return None
    foreground = truth != 0
    values, counts = np.unique(truth[foreground], return_counts=True)
    if len(values) == 0:
        return None
    class_id = int(values[int(np.argmax(counts))])

    inside_distance = distance_transform_edt(support)
    bridge = cutout & (inside_distance <= thickness)
    if int(bridge.sum()) < 2:
        return None
    corrupted = truth.copy()
    corrupted[bridge] = class_id
    conservative_pseudo = pseudo_probabilities(
        conservative, corrupted, float(rng.uniform(0.52, 0.72)), 0.90
    )
    aggressive_pseudo = pseudo_probabilities(
        aggressive, corrupted, float(rng.uniform(0.28, 0.48)), 0.88
    )
    return corrupted, conservative_pseudo, aggressive_pseudo


def add_bridge_variants(
    examples: PixelExamples,
    image: np.ndarray,
    truth: np.ndarray,
    support: np.ndarray,
    cutout: np.ndarray,
    conservative: np.ndarray,
    aggressive: np.ndarray,
    rng: np.random.Generator,
    count: int,
    kind: str,
) -> int:
    added = 0
    # Varying the seal depth teaches a continuous mouth width instead of four
    # hand-coded morphology radii.
    candidates = rng.choice(np.asarray((1.0, 1.5, 2.0, 2.5, 3.0, 3.5)), size=count, replace=False)
    for thickness in candidates:
        positive = bridge_positive(
            truth, support, cutout, conservative, aggressive, float(thickness), rng
        )
        if positive is None:
            continue
        corrupted, pseudo_conservative, pseudo_aggressive = positive
        if add_largest_candidate(
            examples, image, corrupted, pseudo_conservative, pseudo_aggressive,
            truth, kind, max_length=12,
        ):
            added += 1
    return added


def build_examples(
    base: np.lib.npyio.NpzFile,
    stress: np.lib.npyio.NpzFile,
    base_indices: np.ndarray,
    stress_indices: np.ndarray,
    base_conservative: np.ndarray,
    base_aggressive: np.ndarray,
    stress_conservative: np.ndarray,
    stress_aggressive: np.ndarray,
    seed: int,
    training: bool,
) -> PixelExamples:
    rng = np.random.default_rng(seed)
    examples = PixelExamples.empty()
    variants = 3 if training else 2

    for local, index in enumerate(stress_indices):
        add_bridge_variants(
            examples, stress["linear_images"][index], stress["labels"][index],
            stress["support_masks"][index], stress["cutout_masks"][index],
            stress_conservative[local], stress_aggressive[local], rng, variants,
            "mouth_bridge_stress",
        )
        negative = synthetic_negative(
            stress["labels"][index], stress_conservative[local], stress_aggressive[local], rng
        )
        if negative is not None:
            add_largest_candidate(
                examples, stress["linear_images"][index], *negative,
                stress["labels"][index], "false_hole_stress", 14,
            )
        raw = blend(stress_conservative[local:local + 1], stress_aggressive[local:local + 1], 0.5)[0]
        for candidate in find_candidates(raw, stress_conservative[local], stress_aggressive[local], 6, 0.10, 3):
            # Repeat scarce natural errors so their distribution is not
            # overwhelmed by deliberately generated bridge examples.
            repeats = 4 if training else 1
            for _ in range(repeats):
                examples.add(
                    stress["linear_images"][index], raw,
                    stress_conservative[local], stress_aggressive[local], candidate,
                    stress["labels"][index], "natural_stress",
                )
        if (local + 1) % 100 == 0 or local + 1 == len(stress_indices):
            print(f"  stress mouth augmentation {local + 1}/{len(stress_indices)}", flush=True)

    order = rng.permutation(len(base_indices))
    positive_budget = min(len(order), max(420, 2 * len(stress_indices)))
    negative_budget = min(len(order), max(500, 2 * len(stress_indices)))
    for position, local in enumerate(order):
        index = int(base_indices[local])
        if position < positive_budget:
            foreground = base["labels"][index] != 0
            support = foreground | (base["indentation_masks"][index] != 0)
            cutout = support & ~foreground
            add_bridge_variants(
                examples, base["linear_images"][index], base["labels"][index],
                support, cutout, base_conservative[local], base_aggressive[local],
                rng, variants, "mouth_bridge_base",
            )
        if position < negative_budget:
            negative = synthetic_negative(
                base["labels"][index], base_conservative[local], base_aggressive[local], rng
            )
            if negative is not None:
                add_largest_candidate(
                    examples, base["linear_images"][index], *negative,
                    base["labels"][index], "false_hole_base", 14,
                )
        raw = blend(base_conservative[local:local + 1], base_aggressive[local:local + 1], 0.5)[0]
        for candidate in find_candidates(raw, base_conservative[local], base_aggressive[local], 6, 0.10, 3):
            repeats = 4 if training else 1
            for _ in range(repeats):
                examples.add(
                    base["linear_images"][index], raw,
                    base_conservative[local], base_aggressive[local], candidate,
                    base["labels"][index], "natural_base",
                )
        if (position + 1) % 100 == 0 or position + 1 == len(order):
            print(f"  base mouth augmentation {position + 1}/{len(order)}", flush=True)
    return examples


def precision_loss(
    correction_logit: torch.Tensor,
    accept_logit: torch.Tensor,
    target: torch.Tensor,
    domain: torch.Tensor,
    accept: torch.Tensor,
    accept_positive_weight: torch.Tensor,
) -> tuple[torch.Tensor, dict[str, float]]:
    target = target.float()
    domain = domain.float()
    probability = torch.sigmoid(correction_logit.float()) * domain
    raw = F.binary_cross_entropy_with_logits(correction_logit.float(), target, reduction="none") * domain
    positive = target
    negative = domain * (1.0 - target)
    positive_loss = (raw * positive).sum((1, 2)) / positive.sum((1, 2)).clamp_min(1.0)
    negative_loss = (raw * negative).sum((1, 2)) / negative.sum((1, 2)).clamp_min(1.0)
    has_positive = positive.sum((1, 2)) > 0
    # False removal is deliberately more expensive than a one-pixel
    # under-opening because bank preservation is the hard constraint.
    region_case = torch.where(
        has_positive,
        0.65 * positive_loss + 1.35 * negative_loss,
        1.80 * negative_loss,
    )
    region = region_case.mean()
    intersection = (probability * target).sum((1, 2))
    dice_case = 1.0 - (2.0 * intersection + 1.0) / (
        probability.sum((1, 2)) + target.sum((1, 2)) + 1.0
    )
    dice = dice_case[has_positive].mean() if has_positive.any() else probability.sum() * 0.0
    excess = F.relu(probability.sum((1, 2)) - 1.20 * target.sum((1, 2)))
    excess = (excess / domain.sum((1, 2)).clamp_min(1.0)).mean()
    accept_loss = F.binary_cross_entropy_with_logits(
        accept_logit.float(), accept.float(), pos_weight=accept_positive_weight
    )
    total = region + 0.55 * dice + 1.25 * excess + 0.45 * accept_loss
    return total, {
        "region": float(region.detach()), "dice": float(dice.detach()),
        "excess": float(excess.detach()), "accept": float(accept_loss.detach()),
    }


def validation_statistics(
    model: ConnectedCutoutNet,
    loader: DataLoader,
    device: torch.device,
) -> dict[str, float]:
    model.eval()
    positive_dice: list[float] = []
    positive_precision: list[float] = []
    negative_area: list[float] = []
    accept_correct: list[float] = []
    with torch.no_grad():
        for channels, features, target, domain, accept in loader:
            correction, accept_logit = model(channels.float().to(device), features.to(device))
            probability = torch.sigmoid(correction).cpu() * domain.float()
            target = target.float()
            binary = probability >= 0.5
            positive = target.sum((1, 2)) > 0
            intersection = (binary * target.bool()).sum((1, 2)).float()
            dice = (2.0 * intersection + 1.0) / (binary.sum((1, 2)) + target.sum((1, 2)) + 1.0)
            precision = (intersection + 1.0) / (binary.sum((1, 2)).float() + 1.0)
            positive_dice.extend(dice[positive].numpy().tolist())
            positive_precision.extend(precision[positive].numpy().tolist())
            if (~positive).any():
                negative_area.extend(
                    (binary[~positive].sum((1, 2)).float() / domain[~positive].sum((1, 2)).clamp_min(1)).numpy().tolist()
                )
            predicted_accept = torch.sigmoid(accept_logit).cpu() >= 0.5
            accept_correct.extend((predicted_accept == (accept >= 0.5)).float().numpy().tolist())
    return {
        "positive_dice": float(np.mean(positive_dice)),
        "positive_precision": float(np.mean(positive_precision)),
        "negative_predicted_fraction": float(np.mean(negative_area)) if negative_area else 0.0,
        "accept_accuracy": float(np.mean(accept_correct)),
    }


def save_example_grid(path: Path, examples: PixelExamples, seed: int) -> None:
    rng = np.random.default_rng(seed)
    positives = np.flatnonzero([mask.any() for mask in examples.target])
    negatives = np.flatnonzero([not mask.any() for mask in examples.target])
    chosen = np.concatenate((
        rng.choice(positives, size=min(8, len(positives)), replace=False),
        rng.choice(negatives, size=min(4, len(negatives)), replace=False),
    ))
    figure, axes = plt.subplots(len(chosen), 4, figsize=(8, 2 * len(chosen)), squeeze=False)
    titles = ("coarse label", "cavity", "path", "mouth target")
    for row, index in enumerate(chosen):
        arrays = (
            examples.channels[index][1], examples.channels[index][7],
            examples.channels[index][8], examples.target[index],
        )
        for column, (array, title) in enumerate(zip(arrays, titles)):
            axes[row, column].imshow(array, vmin=0, vmax=1)
            axes[row, column].set_axis_off()
            if row == 0:
                axes[row, column].set_title(title)
        axes[row, 0].set_ylabel(examples.kind[index], fontsize=7)
    figure.tight_layout()
    figure.savefig(path, dpi=170, bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    base = np.load(args.base_dataset.resolve(), allow_pickle=False)
    stress = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    adapter = InputAdapter(base["fov_mask"]).to(device)
    conservative_model = load_model(args.conservative, device)
    aggressive_model = load_model(args.aggressive, device)

    rng = np.random.default_rng(args.seed + 17)
    all_base_train = np.asarray(base["train_indices"])
    base_train = np.sort(rng.choice(all_base_train, size=min(700, len(all_base_train)), replace=False))
    stress_train = np.asarray(stress["train_indices"])
    base_validation = np.asarray(base["validation_indices"])
    stress_validation = np.asarray(stress["validation_indices"])

    print(f"device={device}; inferring train split", flush=True)
    btc, bta = infer_pair(
        conservative_model, aggressive_model, adapter,
        base["linear_images"][base_train], base["voltages"][base_train],
        device, args.inference_batch_size,
    )
    stc, sta = infer_pair(
        conservative_model, aggressive_model, adapter,
        stress["linear_images"][stress_train], stress["voltages"][stress_train],
        device, args.inference_batch_size,
    )
    train_examples = build_examples(
        base, stress, base_train, stress_train, btc, bta, stc, sta, args.seed + 1, True
    )
    print("inferring validation split", flush=True)
    bvc, bva = infer_pair(
        conservative_model, aggressive_model, adapter,
        base["linear_images"][base_validation], base["voltages"][base_validation],
        device, args.inference_batch_size,
    )
    svc, sva = infer_pair(
        conservative_model, aggressive_model, adapter,
        stress["linear_images"][stress_validation], stress["voltages"][stress_validation],
        device, args.inference_batch_size,
    )
    validation_examples = build_examples(
        base, stress, base_validation, stress_validation, bvc, bva, svc, sva, args.seed + 2, False
    )
    if not train_examples.kind or not validation_examples.kind:
        raise RuntimeError("Mouth-corridor augmentation did not create usable candidates")
    save_example_grid(out / "training_examples.png", train_examples, args.seed)

    train_arrays = train_examples.arrays()
    validation_arrays = validation_examples.arrays()
    feature_mean = train_arrays[1].mean(axis=0)
    feature_scale = train_arrays[1].std(axis=0)
    feature_scale[feature_scale < 1e-5] = 1.0
    train_loader = DataLoader(
        PixelDataset(
            train_arrays[0], (train_arrays[1] - feature_mean) / feature_scale,
            train_arrays[2], train_arrays[3], train_arrays[4],
        ),
        batch_size=args.batch_size, shuffle=True, num_workers=0,
        pin_memory=torch.cuda.is_available(),
    )
    validation_loader = DataLoader(
        PixelDataset(
            validation_arrays[0], (validation_arrays[1] - feature_mean) / feature_scale,
            validation_arrays[2], validation_arrays[3], validation_arrays[4],
        ),
        batch_size=args.batch_size * 2, shuffle=False, num_workers=0,
    )
    positives = max(1.0, float(train_arrays[4].sum()))
    negatives = max(1.0, float(len(train_arrays[4]) - positives))
    accept_positive_weight = torch.tensor(negatives / positives, device=device)

    model = ConnectedCutoutNet().to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    checkpoint = out / "best.pt"
    best_score = -math.inf
    stale = 0
    history: list[dict[str, float]] = []
    for epoch in range(1, args.epochs + 1):
        model.train()
        losses: list[float] = []
        for channels, features, target, domain, accept in train_loader:
            channels = channels.float().to(device, non_blocking=True)
            features = features.to(device, non_blocking=True)
            target = target.to(device, non_blocking=True)
            domain = domain.to(device, non_blocking=True)
            accept = accept.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            correction, accept_logit = model(channels, features)
            loss, _ = precision_loss(
                correction, accept_logit, target, domain, accept, accept_positive_weight
            )
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            losses.append(float(loss.detach()))
        scheduler.step()
        stats = validation_statistics(model, validation_loader, device)
        score = (
            0.48 * stats["positive_dice"]
            + 0.30 * stats["positive_precision"]
            + 0.22 * stats["accept_accuracy"]
            - 0.70 * stats["negative_predicted_fraction"]
        )
        row = {"epoch": epoch, "train_loss": float(np.mean(losses)), "selection_score": float(score), **stats}
        history.append(row)
        print(
            f"epoch {epoch:02d}: loss={row['train_loss']:.4f} dice={stats['positive_dice']:.3f} "
            f"precision={stats['positive_precision']:.3f} neg_area={stats['negative_predicted_fraction']:.4f} "
            f"accept={stats['accept_accuracy']:.3f} score={score:.4f}",
            flush=True,
        )
        if score > best_score + 1e-5:
            best_score = score
            stale = 0
            torch.save({
                "model": model.state_dict(), "feature_mean": feature_mean,
                "feature_scale": feature_scale, "epoch": epoch, "seed": args.seed,
                "validation": stats, "selection_score": score,
            }, checkpoint)
        else:
            stale += 1
        if epoch >= 10 and stale >= args.patience:
            print(f"early stopping after epoch {epoch}", flush=True)
            break

    counts = {kind: train_examples.kind.count(kind) for kind in sorted(set(train_examples.kind))}
    validation_counts = {
        kind: validation_examples.kind.count(kind) for kind in sorted(set(validation_examples.kind))
    }
    state = torch.load(checkpoint, map_location="cpu", weights_only=False)
    result = {
        "method": "precision-oriented mouth-corridor field trained with bridge-only sealing",
        "training_examples": {
            "candidates": len(train_examples.kind), "positive": int(train_arrays[4].sum()), "kinds": counts,
        },
        "validation_examples": {
            "candidates": len(validation_examples.kind), "positive": int(validation_arrays[4].sum()),
            "kinds": validation_counts,
        },
        "best_epoch": int(state["epoch"]),
        "best_validation": state["validation"],
        "selection_score": float(state["selection_score"]),
        "data_policy": "synthetic training and validation splits only; no test or public KTC labels used",
    }
    (out / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    (out / "summary.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
