"""Diagnose outer-level predictions of the expanded set-aware pure-bay model."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch

import train_ktc_setaware_pure_bay_oof as core


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    parser.add_argument("--cache-dir", type=Path, required=True)
    parser.add_argument("--target-dir", type=Path, required=True)
    parser.add_argument("--pretrained", type=Path, default=Path(r"E:\Codex\ktc_synthetic_pure_bay_physics_ranker_seed20260820\synthetic_bay_risk_ranker.pt"))
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    load_args = argparse.Namespace(
        dataset=args.dataset, cache_dir=args.cache_dir, target_dir=args.target_dir
    )
    cases, _, _ = core.load_public_cases(load_args)
    pretrained = torch.load(args.pretrained.resolve(), map_location="cpu", weights_only=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    rows: list[dict[str, object]] = []
    for level in sorted({case.level for case in cases}):
        payload = torch.load(
            args.model_dir.resolve() / f"exclude_{level}.pt", map_location=device, weights_only=False
        )
        models = []
        for member, state in enumerate(payload["models"]):
            model = core.SetAwareRanker(pretrained["models"][member % len(pretrained["models"])]).to(device)
            model.load_state_dict(state)
            model.eval()
            models.append(model)
        for case in cases:
            if case.level != level:
                continue
            evidence = core.predict_case(
                case, models, pretrained, payload["target_mean"], payload["target_scale"], device
            )
            valid = case.valid.copy()
            valid[0] = False
            probability = evidence.probability
            regression = evidence.regression
            rank = evidence.rank
            relaxed_score = rank + 0.5 * regression[:, 0] + 0.5 * regression[:, 2] + 0.1 * regression[:, 1]
            predicted = int(np.argmax(np.where(valid, relaxed_score, -np.inf)))
            finite_bay = np.isfinite(case.targets[:, 2])
            oracle_valid = valid & finite_bay & (case.targets[:, 0] > 0) & (case.targets[:, 2] > 0.005)
            oracle_score = case.targets[:, 0] + 0.75 * np.nan_to_num(case.targets[:, 2])
            oracle = int(np.argmax(np.where(oracle_valid, oracle_score, -np.inf))) if oracle_valid.any() else 0
            rows.append({
                "id": case.case_id,
                "case_probability": evidence.case_probability,
                "candidate_count": int(valid.sum()),
                "max_safe_iou_probability": float(np.max(probability[valid, 0])),
                "max_useful_bay_probability": float(np.max(probability[valid, 3])),
                "max_joint_probability": float(np.max(probability[valid, 5])),
                "predicted_index": predicted,
                "predicted_rank": float(rank[predicted]),
                "predicted_iou_delta": float(case.targets[predicted, 0]),
                "predicted_boundary_delta": float(case.targets[predicted, 1]),
                "predicted_bay_f1_delta": float(case.targets[predicted, 2]),
                "predicted_bay_depth_delta": float(case.targets[predicted, 4]),
                "oracle_index": oracle,
                "oracle_iou_delta": float(case.targets[oracle, 0]),
                "oracle_bay_f1_delta": float(case.targets[oracle, 2]),
                "oracle_predicted_rank": float(rank[oracle]),
                "oracle_useful_bay_probability": float(probability[oracle, 3]),
                "oracle_joint_probability": float(probability[oracle, 5]),
            })
    args.output.resolve().write_text(json.dumps(rows, indent=2, allow_nan=True), encoding="utf-8")
    for row in rows:
        print(
            f"{row['id']}: case={row['case_probability']:.3f}; "
            f"pred={row['predicted_index']} dIoU={row['predicted_iou_delta']:+.4f} "
            f"dBay={row['predicted_bay_f1_delta']:+.4f}; oracle={row['oracle_index']} "
            f"dIoU={row['oracle_iou_delta']:+.4f} dBay={row['oracle_bay_f1_delta']:+.4f} "
            f"oracleP={row['oracle_useful_bay_probability']:.3f}/{row['oracle_joint_probability']:.3f}",
            flush=True,
        )


if __name__ == "__main__":
    main()
