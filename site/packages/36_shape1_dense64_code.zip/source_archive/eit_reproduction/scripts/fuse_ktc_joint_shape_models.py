"""Validation-selected fusion of conservative and aggressive concavity models."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F

from train_ktc_concavity_network import InputAdapter
from train_ktc_concavity_network_v2 import ConcavityNetV2, ModelSpec, evaluate_real_predictions
from train_ktc_implicit_boolean_network import standard_metrics, stress_metrics


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--base-dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz")
    p.add_argument("--stress-dataset", type=Path, default=root / "datasets" / "ktc_deep_concavity_stress_v1.npz")
    p.add_argument("--conservative", type=Path, default=Path("E:/Codex/ktc_joint_shape_pretrained_seed20260820/best.pt"))
    p.add_argument("--aggressive", type=Path, default=Path("E:/Codex/ktc_joint_shape_network_seed20260820/best.pt"))
    p.add_argument("--shape-expert", type=Path, default=Path("E:/Codex/ktc_shape_expert_seed20260820/predictions.npz"))
    p.add_argument("--output-dir", type=Path, default=Path("E:/Codex/ktc_joint_shape_fusion_seed20260820"))
    p.add_argument("--batch-size", type=int, default=32)
    return p.parse_args()


def load_model(path: Path, device: torch.device) -> torch.nn.Module:
    state = torch.load(path.resolve(), map_location=device, weights_only=False)
    model = ConcavityNetV2(int(state["base_channels"]), ModelSpec(sdf=True, boundary=True, indentation=True, physics=True, voltage=True)).to(device)
    model.load_state_dict(state["model"]); model.eval(); return model


@torch.no_grad()
def infer_probability(model: torch.nn.Module, adapter: InputAdapter, images: np.ndarray, voltages: np.ndarray, device: torch.device, batch: int, size: int = 64) -> np.ndarray:
    output = []
    for start in range(0, len(images), batch):
        image = torch.from_numpy(images[start:start + batch, None].astype(np.float32)).to(device)
        voltage = torch.from_numpy(voltages[start:start + batch].astype(np.float32)).to(device)
        logits = model(adapter(image), voltage)["logits"]
        if size != 64: logits = F.interpolate(logits, size=(size, size), mode="bilinear", align_corners=False)
        output.append(torch.softmax(logits, dim=1).cpu().numpy())
    return np.concatenate(output)


def blend(conservative: np.ndarray, aggressive: np.ndarray, alpha: float) -> np.ndarray:
    probability = (1.0 - alpha) * conservative + alpha * aggressive
    return probability.argmax(axis=1).astype(np.uint8)


def save_grid(path: Path, truth: np.ndarray, predictions: dict[str, np.ndarray], ids: np.ndarray, limit: int) -> None:
    names = list(predictions); count = min(limit, len(truth))
    fig, axes = plt.subplots(count, 1 + len(names), figsize=(3 * (1 + len(names)), 2.2 * count), squeeze=False)
    for i in range(count):
        axes[i, 0].imshow(truth[i], vmin=0, vmax=2, cmap="viridis"); axes[i, 0].axis("off"); axes[i, 0].set_ylabel(str(ids[i]), fontsize=7)
        for j, name in enumerate(names, 1):
            axes[i, j].imshow(predictions[name][i], vmin=0, vmax=2, cmap="viridis"); axes[i, j].axis("off")
    for j, name in enumerate(["truth"] + names): axes[0, j].set_title(name)
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def main() -> None:
    args = parse_args(); out = args.output_dir.resolve(); out.mkdir(parents=True, exist_ok=True)
    base = np.load(args.base_dataset.resolve(), allow_pickle=False); stress = np.load(args.stress_dataset.resolve(), allow_pickle=False)
    expert = np.load(args.shape_expert.resolve(), allow_pickle=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu"); adapter = InputAdapter(base["fov_mask"]).to(device)
    conservative = load_model(args.conservative, device); aggressive = load_model(args.aggressive, device)
    bv, sv = np.asarray(base["validation_indices"]), np.asarray(stress["validation_indices"])
    bc = infer_probability(conservative, adapter, base["linear_images"][bv], base["voltages"][bv], device, args.batch_size)
    ba = infer_probability(aggressive, adapter, base["linear_images"][bv], base["voltages"][bv], device, args.batch_size)
    sc = infer_probability(conservative, adapter, stress["linear_images"][sv], stress["voltages"][sv], device, args.batch_size)
    sa = infer_probability(aggressive, adapter, stress["linear_images"][sv], stress["voltages"][sv], device, args.batch_size)
    base_reference = standard_metrics(base["labels"][bv], bc.argmax(1), base["indentation_masks"][bv])
    stress_reference, _, _ = stress_metrics(stress["labels"][sv], sc.argmax(1), stress["cutout_masks"][sv], stress["cutout_depth_weights"][sv], stress["family_codes"][sv])
    candidates = []
    for alpha in np.linspace(0.0, 0.60, 13):
        bp, sp = blend(bc, ba, float(alpha)), blend(sc, sa, float(alpha))
        bm = standard_metrics(base["labels"][bv], bp, base["indentation_masks"][bv])
        sm, _, _ = stress_metrics(stress["labels"][sv], sp, stress["cutout_masks"][sv], stress["cutout_depth_weights"][sv], stress["family_codes"][sv])
        eligible = bm["foreground_iou"] >= base_reference["foreground_iou"] - 0.010 and sm["foreground_iou"] >= stress_reference["foreground_iou"] - 0.020 and sm["bank_retention"] >= stress_reference["bank_retention"] - 0.030
        score = 0.20 * bm["foreground_iou"] + 0.20 * sm["foreground_iou"] + 0.25 * sm["open_deep_cutout_recovery"] + 0.15 * sm["bank_retention"] + 0.20 * sm["topology_structural_joint"]
        candidates.append({"alpha": float(alpha), "eligible": bool(eligible), "score": float(score), "base": bm, "stress": sm})
        print(f"alpha={alpha:.2f} eligible={eligible} score={score:.4f} base={bm['foreground_iou']:.4f} stress={sm['foreground_iou']:.4f} open={sm['open_deep_cutout_recovery']:.4f} bank={sm['bank_retention']:.4f}", flush=True)
    eligible = [row for row in candidates if row["eligible"]]
    selected = max(eligible or candidates, key=lambda row: row["score"]); alpha = selected["alpha"]
    print(f"selected alpha={alpha:.2f}", flush=True)

    bt, st = np.asarray(base["test_indices"]), np.asarray(stress["test_indices"])
    btc = infer_probability(conservative, adapter, base["linear_images"][bt], base["voltages"][bt], device, args.batch_size); bta = infer_probability(aggressive, adapter, base["linear_images"][bt], base["voltages"][bt], device, args.batch_size)
    stc = infer_probability(conservative, adapter, stress["linear_images"][st], stress["voltages"][st], device, args.batch_size); sta = infer_probability(aggressive, adapter, stress["linear_images"][st], stress["voltages"][st], device, args.batch_size)
    bp, sp = blend(btc, bta, alpha), blend(stc, sta, alpha)
    bm = standard_metrics(base["labels"][bt], bp, base["indentation_masks"][bt]); sm, by_family, _ = stress_metrics(stress["labels"][st], sp, stress["cutout_masks"][st], stress["cutout_depth_weights"][st], stress["family_codes"][st])
    baseline_sm, _, _ = stress_metrics(stress["labels"][st], expert["stress_expert"], stress["cutout_masks"][st], stress["cutout_depth_weights"][st], stress["family_codes"][st])
    rc = infer_probability(conservative, adapter, base["real_linear_images"], base["real_voltages"], device, args.batch_size, 256); ra = infer_probability(aggressive, adapter, base["real_linear_images"], base["real_voltages"], device, args.batch_size, 256)
    rp = blend(rc, ra, alpha)
    real_summary, _ = evaluate_real_predictions("joint_fusion", rp, base["real_labels"], base["real_ids"]); expert_real, _ = evaluate_real_predictions("shape_expert", expert["real_expert"], base["real_labels"], base["real_ids"])
    np.savez_compressed(out / "predictions.npz", base=bp, stress=sp, real=rp, alpha=np.asarray(alpha))
    save_grid(out / "stress_comparison.png", stress["labels"][st], {"shape_expert": expert["stress_expert"], "conservative": stc.argmax(1), "fusion": sp}, st, 24)
    save_grid(out / "real_comparison.png", base["real_labels"], {"shape_expert": expert["real_expert"], "conservative": rc.argmax(1), "fusion": rp}, base["real_ids"], 21)
    summary = {"method": "validation-selected conservative/aggressive probability fusion", "selected_alpha": alpha, "validation_candidates": candidates, "test": {"base": bm, "stress_shape_expert": baseline_sm, "stress_fusion": sm, "stress_by_family": by_family, "real_shape_expert": expert_real, "real_fusion": real_summary}}
    (out / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary["test"], ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__": main()
