from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


def main() -> None:
    project_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description="Aggregate paired ultrasound/EIT robustness runs.")
    parser.add_argument("--run-dirs", nargs="+", type=Path, required=True)
    parser.add_argument("--output-path", type=Path, default=project_root / "outputs" / "us_prior_multiseed_summary.json")
    args = parser.parse_args()

    runs = [json.loads(path.resolve().joinpath("summary.json").read_text(encoding="utf-8")) for path in args.run_dirs]
    rows = [row for run in runs for row in run["rows"]]
    methods = sorted({row["method"] for row in rows})
    scenarios = sorted({row["scenario"] for row in rows})
    aggregates = {}
    for scenario in scenarios:
        aggregates[scenario] = {}
        for method in methods:
            values = [
                float(row["metrics"]["mean_iou"])
                for row in rows
                if row["scenario"] == scenario and row["method"] == method
            ]
            if values:
                aggregates[scenario][method] = {
                    "mean_iou": float(np.mean(values)),
                    "std_iou": float(np.std(values, ddof=1)) if len(values) > 1 else 0.0,
                    "values": values,
                }
    overall = {}
    for method in methods:
        values = [
            float(row["metrics"]["mean_iou"])
            for row in rows
            if row["scenario"] != "all" and row["method"] == method
        ]
        overall[method] = {
            "mean_iou": float(np.mean(values)),
            "std_iou": float(np.std(values, ddof=1)) if len(values) > 1 else 0.0,
            "values": values,
        }
    result = {
        "experiment": "paired_multiseed_us_prior_robustness",
        "n_runs": len(runs),
        "source_dirs": [str(path.resolve()) for path in args.run_dirs],
        "aggregates_by_scenario": aggregates,
        "overall": overall,
    }
    output_path = args.output_path.resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Saved {output_path}")
    for method, values in overall.items():
        print(f"{method}: {values['mean_iou']:.4f} +/- {values['std_iou']:.4f}")


if __name__ == "__main__":
    main()
