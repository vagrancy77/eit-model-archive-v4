"""Build evaluation/training targets for the truth-blind instance-bay cache.

This derived cache deliberately lives outside the inference cache.  It contains
public labels through candidate quality targets and may therefore be opened
only for training levels or final evaluation, never by candidate generation or
inference feature construction.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from audit_ktc_instance_bay_topology import boundary_f1, case_metrics
from train_ktc_instance_bay_nested_ranker import case_filename, foreground_iou


TARGET_NAMES = (
    "foreground_iou",
    "boundary_f1",
    "bay_iou",
    "bay_f1",
    "bay_recall",
    "bay_precision",
    "bay_depth_score",
    "bay_direction_score",
)


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--dataset", type=Path, default=root / "datasets" / "ktc_shape_nonlinear_v1.npz"
    )
    parser.add_argument(
        "--candidate-cache", type=Path,
        default=root / "outputs" / "ktc_instance_bay_candidate_cache_seed20260820",
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=Path(r"E:\Codex\ktc_instance_bay_training_targets_seed20260820"),
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    dataset = np.load(args.dataset.resolve(), allow_pickle=False)
    ids = np.asarray(dataset["real_ids"])
    truths = np.asarray(dataset["real_labels"], dtype=np.uint8)
    manifest: list[dict[str, object]] = []
    for case_index, case_id_value in enumerate(ids):
        case_id = str(case_id_value)
        cache = np.load(args.candidate_cache.resolve() / case_filename(case_id), allow_pickle=False)
        candidates = np.asarray(cache["candidates"], dtype=np.uint8)
        truth = truths[case_index]
        target = np.full((len(candidates), len(TARGET_NAMES)), np.nan, dtype=np.float32)
        for candidate_index, candidate in enumerate(candidates):
            geometry = case_metrics(truth, candidate)
            target[candidate_index] = (
                foreground_iou(truth, candidate),
                boundary_f1(truth, candidate),
                geometry["bay_iou"],
                geometry["bay_f1"],
                geometry["bay_recall"],
                geometry["bay_precision"],
                geometry["bay_depth_score"],
                geometry["bay_direction_score"],
            )
        delta = target - target[:1]
        path = output_dir / case_filename(case_id)
        np.savez_compressed(
            path,
            case_id=np.asarray(case_id),
            target_names=np.asarray(TARGET_NAMES),
            absolute=target,
            delta=delta,
        )
        manifest.append({
            "id": case_id,
            "file": path.name,
            "candidate_count": len(candidates),
            "material_bay_targets_finite": bool(np.isfinite(target[0, 3])),
            "oracle_delta": {
                name: float(np.nanmax(delta[:, index])) if np.isfinite(delta[:, index]).any() else None
                for index, name in enumerate(TARGET_NAMES)
            },
        })
        print(f"{case_index + 1:02d}/{len(ids)} {case_id}: {len(candidates)} targets", flush=True)
    summary = {
        "status": "label-bearing training/evaluation target cache",
        "must_not_be_used_for_inference_features": True,
        "candidate_cache": str(args.candidate_cache.resolve()),
        "dataset": str(args.dataset.resolve()),
        "target_names": TARGET_NAMES,
        "cases": manifest,
    }
    (output_dir / "manifest.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
