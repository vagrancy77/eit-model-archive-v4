# KTC2023-ABC2 DIP+TV 完整复现结果

## 复现对象

- 方法：`Deep image prior with total variation regularization to reconstruct Electrical Impedance Tomography images from limited data`
- 公开仓库：[robert-abc/KTC2023-ABC2](https://github.com/robert-abc/KTC2023-ABC2)
- 本地仓库：`E:\Codex\eit_reproduction\external\KTC2023-ABC2`
- 数据：`inputs/data1.mat`–`data4.mat`
- 真值：`groundTruths/true1.mat`–`true4.mat`
- 作者示例输出：`outputs/data1.png`–`data4.png`

## 方法是否已经跑通

已经跑通。每个样本都执行了作者默认的 3000 次 DIP 优化：

\[
\mathcal{L}(\theta)=\operatorname{MSE}(J f_\theta(z),\Delta V)+\lambda_{TV}\operatorname{TV}(f_\theta(z)).
\]

本地代码使用固定随机种子 1234、1235、1236、1237 对应 data1–data4；网络结构、EIT 雅可比矩阵、噪声扰动、TV 权重和 Otsu 三分类均来自公开仓库，只有 `solver.py` 增加了迭代覆盖、进度输出、损失保存和缺少 torchmetrics 时的 TV 兼容实现。

## 四个样本的结果

| 样本 | 本地 mean IoU | 作者 mean IoU | 本地 KTC-SSIM | 作者 KTC-SSIM |
|---|---:|---:|---:|---:|
| data1 | 0.7609 | 0.7504 | 0.8239 | 0.8144 |
| data2 | 0.8076 | 0.8294 | 0.8936 | 0.9076 |
| data3 | 0.8327 | 0.8206 | 0.8618 | 0.8480 |
| data4 | 0.6522 | 0.6563 | 0.6304 | 0.6358 |
| 平均 | 0.7634 | 0.7642 | 0.8024 | 0.8014 |

四个样本的平均 KTC-SSIM 与作者输出相差约 0.0010；平均 IoU 相差约 0.0008。data4 的星形目标被 DIP+TV 规则化成近似圆形，这是作者输出也出现的现象，属于该有限数据设置下的重建能力限制，而不是本地代码链路错误。

## 图像和损失曲线

四个样本的真值、作者输出、本地 3000 次重建和损失曲线在：

[comparison_all_cases.png](E:\Codex\eit_reproduction\outputs\ktc2023_abc2_final\comparison_all_cases.png)

![四样本完整对比](E:\Codex\eit_reproduction\outputs\ktc2023_abc2_final\comparison_all_cases.png)

最终结构化指标在：

[final_summary.json](E:\Codex\eit_reproduction\outputs\ktc2023_abc2_final\final_summary.json)

每个样本的单独结果目录为：

- [data1 结果](E:\Codex\eit_reproduction\outputs\ktc2023_abc2_3000_data1)
- [data2 结果](E:\Codex\eit_reproduction\outputs\ktc2023_abc2_3000_data2_seed1235)
- [data3/data4 结果](E:\Codex\eit_reproduction\outputs\ktc2023_abc2_3000_data3_data4)

每个目录包含重建 PNG、`loss_dataN.npy`、`summary.json` 和 `comparison.png`。

## 一键重跑

在 WSL conda 环境中：

```bash
source ~/miniforge3/etc/profile.d/conda.sh
conda activate gn4ip-env
cd /mnt/e/Codex/eit_reproduction

# data1
python scripts/reproduce_ktc2023_abc2.py --max-files 1 --seed 1234 --num-iter 3000 --progress-every 500 --output-dir outputs/ktc2023_abc2_3000_data1

# data2
python scripts/reproduce_ktc2023_abc2.py --start-index 1 --max-files 1 --seed 1234 --num-iter 3000 --progress-every 500 --output-dir outputs/ktc2023_abc2_3000_data2_seed1235

# data3、data4
python scripts/reproduce_ktc2023_abc2.py --start-index 2 --max-files 2 --seed 1234 --num-iter 3000 --progress-every 500 --output-dir outputs/ktc2023_abc2_3000_data3_data4

# 汇总图和 JSON
python scripts/aggregate_ktc2023_abc2.py
```

论文仓库自带 PNG 与本地 DIP 都是随机初始化优化的结果，因此不能合理要求 PNG 字节级完全相同；在作者没有公布随机种子、运行时版本和硬件细节的情况下，复现标准应看算法链路、目标位置/类别、损失收敛和统计指标。本次四样本结果已满足这一复现标准；作者 PNG 仍原样保留，可用于论文中的基线对照。
