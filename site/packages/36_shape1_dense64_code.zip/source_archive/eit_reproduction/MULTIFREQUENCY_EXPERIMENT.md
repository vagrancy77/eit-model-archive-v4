# 公开 10/50 kHz 双频 EIT：研究起点与正确解读

本实验回答的具体问题是：**在同一份公开的 10 kHz/50 kHz 配对测量中，使用两个频率的电压是否能让 EIT 重建更接近公开 GN 重建、且对测量噪声更稳定？**

它是后续多频 EIT 研究的可行性实验，不是临床有效性实验。

## 数据和样本单位

数据来自 Zenodo `10.5281/zenodo.19558489`（CC BY 4.0）。原始文件有 12 帧：

| 层位 | 激励幅值 | 频率 |
|---|---:|---|
| L1, L2, L3 | 1 Vpp、5 Vpp | 10 kHz、50 kHz |

`prepare_public_multifrequency_eit.py` 将其严格配为 6 对样本；一对的 10 kHz 和 50 kHz 来自相同层位和同一激励幅值。生成的文件是：

- `datasets/public_us_eit/public_us_eit_multifrequency_v1.npz`
- `datasets/public_us_eit/public_us_eit_multifrequency_v1.json`

每一对的电压形状为 `2 × 416`（208 路复数测量的实部和虚部），目标形状为 `2 × 64 × 64`。

重要限制：公开的 `pair_targets_gn` 是作者利用同一批测量得到的 Gauss--Newton 重建，**不是独立的电导率真值**。所以这里的 `pseudo_gn_*` 指标只能说“与作者 GN 图的一致性”，不能说“病灶真实定位/定量准确度”。

## 四组公平对照

| 名称 | 推理时输入 | 用途 |
|---|---|---|
| `public_tikhonov` | 作者公开的 Tikhonov 图 | 常规方法参考，不是神经网络 |
| `single_10khz` | 仅 10 kHz 电压 | 10 kHz 单频基线 |
| `single_50khz` | 仅 50 kHz 电压 | 50 kHz 单频基线 |
| `frequency_conditioned` | 单帧电压 + 数值频率（10 或 50 kHz） | 检验共享参数是否有益；不能看见另一频率 |
| `shared_encoder_frequency_heads` | 配对的 10 和 50 kHz 电压 | 真正双频模型：共享编码器、跨频注意力、两个频率专属输出头 |
| `shared_geometry_frequency_contrast` | 配对的 10 和 50 kHz 电压 | 一张共享病灶几何图、两个频率背景和两个有符号电导率对比度图 |

模型代码在 `pytorch_eit/multifrequency.py`：

```text
单频条件化： voltage -> shared voltage encoder --+-> spatial decoder -> conductivity image
                                           frequency --+ (FiLM 条件化)

双频模型：    V10 -> shared encoder --+                    +-> 10-kHz head -> image10
                                      +-> cross-frequency attention
               V50 -> shared encoder --+                    +-> 50-kHz head -> image50
                                  numeric frequency -> FiLM 条件化
```

双频模型比“频率条件化”多看到一个测量帧，这是设计上的关键区别：只有前者才直接检验“双频联合采集的增益”。两个频率仍各自输出一张图，避免强迫本来可能具有频散差异的电导率完全相同。

结构分解模型进一步写成：

```text
sigma_f(x) = bounded(background_f + geometry(x) * contrast_f(x))
```

其中 `geometry` 对两个频率完全共享，`background_f` 和 `contrast_f` 则保留频率差异。几何伪监督先从每张 GN 图中减去域内中位背景，再取显著局部偏差，避免把全局背景漂移误判为病灶。训练中还使用同一电压的两次独立加噪一致性约束。

## 防止数据泄漏的划分

只有 3 个层位，不能随机拆 12 帧；那样同一组织层的 10/50 kHz 版本会同时进入训练和测试，结果严重偏乐观。

本实验使用循环 leave-one-layer-out：每个折中一个层位训练、一个层位选择最优 epoch、第三个层位测试。每个测试层含两个配对测量（1 Vpp 和 5 Vpp）。这确保同一配对不会跨集合，但也意味着每折训练数据只有 2 个配对样本。因此网络是小型的（约 20--24 万参数），结论必须谨慎。

## 怎么运行

Windows Python 没有 PyTorch 时，请在 WSL 的 `gn4ip-env` 内运行：

```bash
cd /mnt/e/Codex/eit_reproduction

# 如果双频数据尚未生成（这一步在 Windows Python 也可运行）
python prepare_public_multifrequency_eit.py

# 先验证完整管线是否可跑
python train_public_multifrequency_eit.py --smoke \
  --output-dir outputs_public_multifrequency_smoke

# 研究用的第一版正式运行：3 个层位折，5 个随机种子
python train_public_multifrequency_eit.py \
  --epochs 300 --seeds 20260729,20260730,20260731,20260732,20260733 \
  --output-dir outputs_public_multifrequency
```

若单次任务有执行时限，可以按层位分别运行后合并：

```bash
python train_public_multifrequency_eit.py --epochs 80 --test-layer L1 --output-dir outputs_geometry_L1
python train_public_multifrequency_eit.py --epochs 80 --test-layer L2 --output-dir outputs_geometry_L2
python train_public_multifrequency_eit.py --epochs 80 --test-layer L3 --output-dir outputs_geometry_L3
python aggregate_public_multifrequency_runs.py outputs_geometry_L1 outputs_geometry_L2 outputs_geometry_L3 \
  --output-dir outputs_geometry_pilot
```

输出中最重要的三个文件：

- `per_sample_metrics.csv`：每个测试配对、频率、随机种子的所有原始指标；论文统计应从这里开始。
- `summary.json`：模型参数量、每折选择的 epoch、以及双频相对单频/条件化模型的配对 bootstrap 效应量和区间。
- `comparison.png`：仅供初步查看的汇总图，标题明确标为 GN pseudo-target。

## 什么结果才值得继续

对于 10 kHz 和 50 kHz，双频模型相对各自单频模型应同时呈现：

1. `pseudo_gn_mae` 和 `pseudo_gn_relative_l2` 下降；
2. `pseudo_gn_correlation` 与 `pseudo_gn_ssim` 上升；
3. 在相同输入 SNR 下 `noise_output_std` 降低；
4. 这些改进在不同层位和多个随机种子中方向一致，而非只在一两个 1/5 Vpp 样本有效。

即便以上都出现，正确的表述仍是：**公开实体数据上的双频重建具有更好的 GN 伪标签一致性和噪声稳定性。**

## 当前结构分解预实验结论

最终背景校准和噪声一致性版本位于 `outputs_public_multifrequency_geometry_robust_pilot/`。单随机种子、三个未见层位的汇总结果为：

| 频率 | 模型 | GN 伪标签 MAE ↓ | 相关性 ↑ | SSIM ↑ | 噪声输出标准差 ↓ |
|---:|---|---:|---:|---:|---:|
| 10 kHz | 频率条件化 | 0.0263 | 0.9120 | 0.9073 | 0.00123 |
| 10 kHz | 共享几何 + 专属对比度 | 0.1074 | 0.8450 | 0.8177 | 0.00536 |
| 50 kHz | 频率条件化 | 0.0243 | 0.9146 | 0.9092 | 0.00063 |
| 50 kHz | 共享几何 + 专属对比度 | 0.0411 | 0.8782 | 0.8402 | 0.00321 |

共享几何伪 Dice 为 0.672、IoU 为 0.538，平均覆盖圆域 17.8%，说明模型确实学到了局部结构，而不是将几何门铺满全域。但它没有同时改善重建误差和噪声稳定性，所以当前结果**不支持“已经明显优化”**。这更可能受六个配对样本、GN 伪标签和每折仅两个训练配对的限制，而不是足以否定结构分解假设。

若要将它发展为论文中的“病灶成像明显优化”，下一阶段必须增加至少一种独立证据：

- 有已知位置/尺寸/电导率的多频实体 phantom，且每个病灶有多次独立采集；或
- 可以生成频率依赖导电率且有真值的多频 CEM 仿真集，用作受控准确度实验；并且
- 最后在独立实体测量上检验域外泛化。
