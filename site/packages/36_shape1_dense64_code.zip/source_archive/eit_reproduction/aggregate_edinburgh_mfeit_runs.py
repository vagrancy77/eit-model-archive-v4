"""Aggregate repeated Edinburgh joint-versus-factorized experiments."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np


LOWER_IS_BETTER = {
    "mae",
    "rmse",
    "centroid_error_pixels",
    "lesion_contrast_mae",
    "background_false_positive",
}


def main() -> None:
    parser = argparse.ArgumentParser(description="Aggregate repeated Edinburgh mfEIT runs.")
    parser.add_argument("runs", nargs="+", type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path("outputs_edinburgh_mfeit_multiseed"))
    arguments = parser.parse_args()

    records: list[dict[str, object]] = []
    per_frame: list[dict[str, object]] = []
    for run in arguments.runs:
        with (run / "summary.json").open("r", encoding="utf-8") as handle:
            summary = json.load(handle)
        seed = int(summary["arguments"]["seed"])
        for model in ("joint", "factorized"):
            if model not in summary["models"]:
                continue
            records.append({"run": str(run), "seed": seed, "model": model, **summary["models"][model]})
        metrics_path = run / "per_sample_frequency_metrics.csv"
        if metrics_path.exists():
            with metrics_path.open("r", encoding="utf-8-sig", newline="") as handle:
                for row in csv.DictReader(handle):
                    if row["model"] in {"joint", "factorized"}:
                        per_frame.append({"seed": seed, **row})
    if not records:
        raise ValueError("no joint/factorized metrics found")

    metric_names = [
        key
        for key, value in records[0].items()
        if key not in {"run", "seed", "model", "parameters"} and isinstance(value, (int, float))
    ]
    aggregate: dict[str, dict[str, dict[str, float]]] = {}
    for model in ("joint", "factorized"):
        model_records = [record for record in records if record["model"] == model]
        aggregate[model] = {
            metric: {
                "mean": float(np.mean([float(record[metric]) for record in model_records])),
                "std": float(np.std([float(record[metric]) for record in model_records], ddof=1))
                if len(model_records) > 1
                else 0.0,
            }
            for metric in metric_names
            if all(metric in record for record in model_records)
        }

    shared_metrics = sorted(set(aggregate["joint"]).intersection(aggregate["factorized"]))
    improvements: dict[str, dict[str, float | str]] = {}
    for metric in shared_metrics:
        baseline = aggregate["joint"][metric]["mean"]
        candidate = aggregate["factorized"][metric]["mean"]
        if metric in LOWER_IS_BETTER:
            relative = 100.0 * (baseline - candidate) / max(abs(baseline), 1e-12)
            direction = "reduction"
        else:
            relative = 100.0 * (candidate - baseline) / max(abs(baseline), 1e-12)
            direction = "increase"
        improvements[metric] = {
            "joint_mean": baseline,
            "factorized_mean": candidate,
            "relative_improvement_percent": relative,
            "direction": direction,
        }

    result = {
        "runs": [str(run.resolve()) for run in arguments.runs],
        "seeds": sorted({int(record["seed"]) for record in records}),
        "aggregate": aggregate,
        "factorized_vs_joint": improvements,
        "conclusion_rule": "A positive relative improvement means the factorized model is better for that metric.",
    }
    if per_frame:
        bootstrap: dict[str, dict[str, float]] = {}
        rng = np.random.default_rng(20260729)
        for metric in shared_metrics:
            if metric not in per_frame[0]:
                continue
            lookup = {
                (
                    int(row["seed"]),
                    int(row["case"]),
                    int(row["sample_index"]),
                    int(row["frequency_channel"]),
                    str(row["model"]),
                ): float(row[metric])
                for row in per_frame
            }
            sample_improvements: dict[tuple[int, int], list[float]] = {}
            base_keys = {(key[0], key[1], key[2], key[3]) for key in lookup}
            for seed, case, sample_index, frequency in base_keys:
                joint_key = (seed, case, sample_index, frequency, "joint")
                factorized_key = (seed, case, sample_index, frequency, "factorized")
                if joint_key not in lookup or factorized_key not in lookup:
                    continue
                if metric in LOWER_IS_BETTER:
                    improvement = lookup[joint_key] - lookup[factorized_key]
                else:
                    improvement = lookup[factorized_key] - lookup[joint_key]
                sample_improvements.setdefault((case, sample_index), []).append(improvement)
            values = np.asarray([np.mean(value) for value in sample_improvements.values()], dtype=np.float64)
            draws = np.mean(rng.choice(values, size=(5000, len(values)), replace=True), axis=1)
            bootstrap[metric] = {
                "paired_mean_improvement": float(values.mean()),
                "bootstrap_ci95_low": float(np.quantile(draws, 0.025)),
                "bootstrap_ci95_high": float(np.quantile(draws, 0.975)),
                "bootstrap_probability_improvement": float(np.mean(draws > 0.0)),
                "independent_test_samples": int(len(values)),
            }
        result["paired_sample_bootstrap"] = bootstrap
    arguments.output_dir.mkdir(parents=True, exist_ok=True)
    with (arguments.output_dir / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(result, handle, ensure_ascii=False, indent=2)
    with (arguments.output_dir / "runs.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        leading = ["run", "seed", "model", "parameters"]
        remaining = sorted(set().union(*(record.keys() for record in records)).difference(leading))
        writer = csv.DictWriter(handle, fieldnames=leading + remaining)
        writer.writeheader()
        writer.writerows(records)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
