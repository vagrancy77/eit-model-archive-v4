from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from torch.utils.data import DataLoader

from pytorch_eit.data import MultimodalCEMDataset
from pytorch_eit.models import MultiModalEITNet, RegistrationRobustMultiModalEITNet
from train_registration_robust_multimodal import corrupt_ultrasound


def collect(model, loader, device, mask, condition):
    model.eval()
    rows = {"correlation": [], "relative_l2": [], "mae": []}
    with torch.no_grad():
        for batch in loader:
            batch = {key: value.to(device=device, dtype=torch.float32) for key, value in batch.items()}
            ultrasound = corrupt_ultrasound(batch["ultrasound"], condition)
            prediction = model(batch["eit_image"], batch["voltages"], ultrasound, torch.ones_like(batch["ultrasound_available"]))["reconstruction"][:, 0] * mask
            target = batch["target"][:, 0] * mask
            p = prediction.flatten(1) - prediction.flatten(1).mean(1, keepdim=True)
            t = target.flatten(1) - target.flatten(1).mean(1, keepdim=True)
            rows["correlation"].extend(((p * t).sum(1) / (torch.linalg.vector_norm(p, dim=1) * torch.linalg.vector_norm(t, dim=1)).clamp_min(1e-6)).cpu().numpy().tolist())
            rows["relative_l2"].extend((torch.linalg.vector_norm((prediction - target).flatten(1), dim=1) / torch.linalg.vector_norm(target.flatten(1), dim=1).clamp_min(1e-6)).cpu().numpy().tolist())
            rows["mae"].extend((torch.abs(prediction - target).sum(dim=(1, 2)) / mask.sum()).cpu().numpy().tolist())
    return {key: np.asarray(value, dtype=np.float64) for key, value in rows.items()}


def bootstrap_ci(values: np.ndarray, rng: np.random.Generator, n_bootstrap: int = 2000) -> dict[str, float]:
    samples = rng.choice(values, size=(n_bootstrap, values.size), replace=True).mean(axis=1)
    return {"mean": float(values.mean()), "std": float(values.std(ddof=1)), "ci95_low": float(np.quantile(samples, 0.025)), "ci95_high": float(np.quantile(samples, 0.975))}


def main() -> None:
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Paired bootstrap comparison on independent CEM phantoms.")
    parser.add_argument("--data", type=Path, default=root / "datasets" / "multimodal_cem_v2.npz")
    parser.add_argument("--robust-checkpoint", type=Path, default=root / "outputs_registration_robust_multimodal_warmstart" / "model.pt")
    parser.add_argument("--baseline-checkpoint", type=Path, default=root / "outputs_pytorch_multimodal" / "model.pt")
    parser.add_argument("--output-dir", type=Path, default=root / "outputs_registration_robust_bootstrap")
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--seed", type=int, default=20260803)
    parser.add_argument("--cpu", action="store_true")
    args = parser.parse_args()
    device = torch.device("cpu" if args.cpu or not torch.cuda.is_available() else "cuda")
    robust_ckpt = torch.load(args.robust_checkpoint, map_location=device, weights_only=False)
    baseline_ckpt = torch.load(args.baseline_checkpoint, map_location=device, weights_only=False)
    voltage_mean = np.asarray(robust_ckpt["voltage_mean"], dtype=np.float32)
    voltage_std = np.asarray(robust_ckpt["voltage_std"], dtype=np.float32)
    dataset = MultimodalCEMDataset(args.data, "test", modality_dropout=0.0)
    dataset.voltages = (dataset.voltages - voltage_mean) / voltage_std
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=0)
    data = np.load(args.data)
    mask = torch.from_numpy(np.asarray(data["mask"], dtype=np.float32)).to(device)
    robust = RegistrationRobustMultiModalEITNet(voltage_dim=dataset.voltages.shape[1], base_channels=int(robust_ckpt["base_channels"])).to(device)
    robust.load_state_dict(robust_ckpt["model_state"], strict=False)
    baseline = MultiModalEITNet(voltage_dim=dataset.voltages.shape[1], base_channels=int(baseline_ckpt["base_channels"])).to(device)
    baseline.load_state_dict(baseline_ckpt["model_state"], strict=False)
    rng = np.random.default_rng(args.seed)
    result = {"samples": len(dataset), "conditions": {}}
    for condition in ["clean", "shift10px", "rotate10deg", "blur_sigma4", "false_positive"]:
        base = collect(baseline, loader, device, mask, condition)
        robust_values = collect(robust, loader, device, mask, condition)
        result["conditions"][condition] = {}
        for metric in ("correlation", "relative_l2", "mae"):
            # Positive improvement means robust is better: corr increases,
            # while error metrics decrease.
            delta = robust_values[metric] - base[metric]
            if metric != "correlation":
                delta = -delta
            result["conditions"][condition][metric] = bootstrap_ci(delta, rng)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    figure, axes = plt.subplots(1, 3, figsize=(15, 4), constrained_layout=True)
    conditions = list(result["conditions"])
    x = np.arange(len(conditions))
    for ax, metric, title in zip(axes, ("correlation", "relative_l2", "mae"), ("Δ correlation ↑", "relative L2 reduction ↑", "MAE reduction ↑"), strict=True):
        means = np.asarray([result["conditions"][c][metric]["mean"] for c in conditions])
        low = means - np.asarray([result["conditions"][c][metric]["ci95_low"] for c in conditions])
        high = np.asarray([result["conditions"][c][metric]["ci95_high"] for c in conditions]) - means
        ax.errorbar(x, means, yerr=[low, high], fmt="o", capsize=4, color="tab:blue")
        ax.axhline(0.0, color="0.4", linewidth=1)
        ax.set_xticks(x, conditions, rotation=28, ha="right")
        ax.set_title(title)
        ax.grid(alpha=0.25)
    figure.savefig(args.output_dir / "paired_bootstrap.png", dpi=180)
    plt.close(figure)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
