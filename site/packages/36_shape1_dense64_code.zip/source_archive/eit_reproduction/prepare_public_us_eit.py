from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import h5py
import numpy as np
from PIL import Image


def read_csv(path: Path) -> np.ndarray:
    # Six metadata comment rows followed by the header and 208 records.
    return np.loadtxt(path, delimiter=",", skiprows=7, usecols=(1, 2, 3, 4), dtype=np.float32)


def read_reconstruction(path: Path, key: str) -> np.ndarray:
    with h5py.File(path, "r") as handle:
        image = np.asarray(handle[key], dtype=np.float32)
    image = np.nan_to_num(image, nan=0.0, posinf=0.0, neginf=0.0)
    return image


def resize_image(path: Path, size: int) -> np.ndarray:
    image = Image.open(path).convert("L")
    width, height = image.size
    # Remove the title and white page margins around the ultrasound sector.
    crop = image.crop((int(0.08 * width), int(0.065 * height), int(0.89 * width), int(0.835 * height)))
    crop = crop.resize((size, size), Image.Resampling.BILINEAR)
    array = np.asarray(crop, dtype=np.float32) / 255.0
    array -= array.min()
    array /= max(float(array.max()), 1e-6)
    return array


def main() -> None:
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Parse the public Zenodo ultrasound-EIT dataset.")
    parser.add_argument("--raw", type=Path, default=root / "datasets" / "public_us_eit" / "raw")
    parser.add_argument("--output", type=Path, default=root / "datasets" / "public_us_eit" / "public_us_eit_v1.npz")
    parser.add_argument("--pixels", type=int, default=64)
    args = parser.parse_args()

    csv_root = args.raw / "Supplementary Files" / "sample files" / "eit_csvs" / "eit_csvs"
    recon_root = args.raw / "Supplementary Files" / "sample files" / "recon_outputs"
    image_path = args.raw / "Supplementary Files" / "sample files" / "ALL figures" / "Original Ultrasonic Figure.png"
    csv_files = sorted(csv_root.glob("Layer_L*_*.csv"))
    voltage_rows: list[np.ndarray] = []
    metadata: list[dict[str, object]] = []
    pseudo_tik: list[np.ndarray] = []
    pseudo_gn: list[np.ndarray] = []
    for csv_path in csv_files:
        match = re.fullmatch(r"Layer_(L\d)_(\d+)kHz_(\d+)V", csv_path.stem)
        if match is None:
            raise ValueError(f"unexpected CSV name: {csv_path.name}")
        layer, frequency, voltage = match.groups()
        voltage_rows.append(read_csv(csv_path)[:, :2].T.reshape(-1))
        stem = csv_path.stem
        pseudo_tik.append(1.0 + read_reconstruction(recon_root / f"{stem}_recon.mat", "img_tik"))
        pseudo_gn.append(1.0 + read_reconstruction(recon_root / f"{stem}_recon.mat", "img_gn"))
        metadata.append({"sample": stem, "layer": layer, "frequency_khz": int(frequency), "voltage_vpp": int(voltage)})

    # Preserve both real and imaginary channels: 208 complex measurements -> 416 features.
    voltage_features = np.asarray(voltage_rows, dtype=np.float32)
    ultrasound = resize_image(image_path, args.pixels)
    ultrasound_rows = np.repeat(ultrasound[None, None], len(csv_files), axis=0)
    tik = np.asarray(pseudo_tik, dtype=np.float32)
    gn = np.asarray(pseudo_gn, dtype=np.float32)
    tik = np.clip(tik, 0.05, 2.95)
    gn = np.clip(gn, 0.05, 2.95)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        args.output,
        voltage_features=voltage_features,
        ultrasound=ultrasound_rows.astype(np.float32),
        baseline_tikhonov=tik,
        pseudo_target_gn=gn,
        metadata_json=np.asarray(json.dumps(metadata, ensure_ascii=False)),
        ultrasound_shared=np.asarray(True),
    )
    summary = {
        "source": "Zenodo 10.5281/zenodo.19558489, CC BY 4.0",
        "samples": len(csv_files),
        "voltage_features": list(voltage_features.shape),
        "ultrasound_shape": list(ultrasound.shape),
        "paired_status": "same experiment, but one shared ultrasound image rather than 12 spatially registered frames",
        "labels": "pseudo_target_gn is the author's GN reconstruction, not an independent conductivity ground truth",
        "metadata": metadata,
    }
    with args.output.with_suffix(".json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

