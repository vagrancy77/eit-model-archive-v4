from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.tri as mtri
import numpy as np

from eit_basic.measurements import load_measurement_vector
from eit_basic.neural import ResidualMLP


def parse_arguments() -> argparse.Namespace:
    project_root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(
        description="Reconstruct one 208-value EIT frame with the trained MLP."
    )
    parser.add_argument("measurement", type=Path)
    parser.add_argument(
        "--dataset",
        type=Path,
        default=project_root / "datasets" / "synthetic_cem_v1.npz",
    )
    parser.add_argument(
        "--model",
        type=Path,
        default=project_root / "models" / "residual_mlp_v1.npz",
    )
    parser.add_argument("--key", default="voltage")
    parser.add_argument("--csv-column", default="noisy")
    parser.add_argument("--background", type=Path)
    parser.add_argument("--background-key", default="voltage")
    parser.add_argument("--background-csv-column", default="background")
    parser.add_argument(
        "--output",
        type=Path,
        default=project_root / "outputs_neural" / "single_prediction.npz",
    )
    return parser.parse_args()


def main() -> None:
    arguments = parse_arguments()
    dataset = np.load(arguments.dataset)
    background_default = np.asarray(dataset["voltage_background"], dtype=float)
    n_measurements = background_default.size
    measured = load_measurement_vector(
        arguments.measurement,
        expected_size=n_measurements,
        key=arguments.key,
        csv_column=arguments.csv_column,
    )
    if arguments.background is None:
        background = background_default
    else:
        background = load_measurement_vector(
            arguments.background,
            expected_size=n_measurements,
            key=arguments.background_key,
            csv_column=arguments.background_csv_column,
        )

    reconstruction_operator = np.asarray(
        dataset["reconstruction_operator"],
        dtype=float,
    )
    linear_delta = reconstruction_operator @ (measured - background)
    model = ResidualMLP.load(arguments.model)
    neural_delta = linear_delta + model.predict_correction(
        linear_delta[None, :]
    )[0]
    conductivity = np.clip(1.0 + neural_delta, 0.05, 3.0)

    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        arguments.output,
        measured_voltage=measured,
        background_voltage=background,
        linear_delta=linear_delta,
        neural_delta=conductivity - 1.0,
        conductivity=conductivity,
    )
    nodes = dataset["inverse_nodes"][:, :2]
    elements = dataset["inverse_elements"][:, :3]
    triangulation = mtri.Triangulation(nodes[:, 0], nodes[:, 1], elements)
    figure, axes = plt.subplots(1, 2, figsize=(9, 4), constrained_layout=True)
    fields = [linear_delta, conductivity - 1.0]
    limit = float(np.max(np.abs(np.concatenate(fields))))
    for axis, field, title in zip(
        axes,
        fields,
        ["Linear CEM", "Neural post-processing"],
        strict=True,
    ):
        image = axis.tripcolor(
            triangulation,
            facecolors=field,
            shading="flat",
            cmap="RdBu_r",
            vmin=-limit,
            vmax=limit,
        )
        axis.set_title(title)
        axis.set_aspect("equal")
        axis.set_axis_off()
        figure.colorbar(image, ax=axis, fraction=0.046, pad=0.04)
    figure.savefig(arguments.output.with_suffix(".png"), dpi=180)
    plt.close(figure)
    print(arguments.output.resolve())


if __name__ == "__main__":
    main()
