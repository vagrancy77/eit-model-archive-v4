from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path


METHODS = ["eit_only", "baseline", "hard_constraint", "soft_constraint", "robust"]
CORRUPTED_CONDITIONS = [
    "shift10px",
    "rotate10deg",
    "scale85pct",
    "warp_local",
    "missing",
    "blur_sigma4",
    "false_positive",
]


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def fmt(value: float | None, digits: int = 5) -> str:
    if value is None:
        return "-"
    return f"{float(value):.{digits}f}"


def mean_over_conditions(summary: dict, method: str, conditions: list[str]) -> dict[str, float]:
    corr = []
    rel_l2 = []
    mae = []
    for condition in conditions:
        item = summary["metrics"][method][condition]
        corr.append(float(item["correlation"]["mean"]))
        rel_l2.append(float(item["relative_l2"]["mean"]))
        mae.append(float(item["mae"]["mean"]))
    return {
        "correlation": sum(corr) / len(corr),
        "relative_l2": sum(rel_l2) / len(rel_l2),
        "mae": sum(mae) / len(mae),
    }


def method_overview_table(summary: dict) -> str:
    lines = [
        "| Method | All 8 corr | All 8 L2 | All 8 MAE | Corrupt 7 corr | Corrupt 7 L2 | Corrupt 7 MAE |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    all_conditions = summary["conditions"]
    corrupt_conditions = [c for c in all_conditions if c != "clean"]
    for method in METHODS:
        all_stats = mean_over_conditions(summary, method, all_conditions)
        corrupt_stats = mean_over_conditions(summary, method, corrupt_conditions)
        lines.append(
            "| "
            + " | ".join(
                [
                    method,
                    fmt(all_stats["correlation"]),
                    fmt(all_stats["relative_l2"]),
                    fmt(all_stats["mae"]),
                    fmt(corrupt_stats["correlation"]),
                    fmt(corrupt_stats["relative_l2"]),
                    fmt(corrupt_stats["mae"]),
                ]
            )
            + " |"
        )
    return "\n".join(lines)


def condition_table(summary: dict) -> str:
    lines = [
        "| Condition | Baseline corr | Robust corr | Baseline L2 | Robust L2 | Baseline MAE | Robust MAE |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for condition in summary["conditions"]:
        baseline = summary["metrics"]["baseline"][condition]
        robust = summary["metrics"]["robust"][condition]
        lines.append(
            "| "
            + " | ".join(
                [
                    condition,
                    fmt(baseline["correlation"]["mean"]),
                    fmt(robust["correlation"]["mean"]),
                    fmt(baseline["relative_l2"]["mean"]),
                    fmt(robust["relative_l2"]["mean"]),
                    fmt(baseline["mae"]["mean"]),
                    fmt(robust["mae"]["mean"]),
                ]
            )
            + " |"
        )
    return "\n".join(lines)


def bootstrap_table(summary: dict) -> str:
    lines = [
        "| Condition | ΔCorr | ΔL2 | ΔMAE |",
        "|---|---:|---:|---:|",
    ]
    for condition in summary["conditions"]:
        item = summary["paired_bootstrap"]["baseline"][condition]
        lines.append(
            "| "
            + " | ".join(
                [
                    condition,
                    f'{fmt(item["correlation_improvement"]["mean"])} [{fmt(item["correlation_improvement"]["ci95_low"] )}, {fmt(item["correlation_improvement"]["ci95_high"])}]',
                    f'{fmt(item["relative_l2_improvement"]["mean"])} [{fmt(item["relative_l2_improvement"]["ci95_low"] )}, {fmt(item["relative_l2_improvement"]["ci95_high"])}]',
                    f'{fmt(item["mae_improvement"]["mean"])} [{fmt(item["mae_improvement"]["ci95_low"] )}, {fmt(item["mae_improvement"]["ci95_high"])}]',
                ]
            )
            + " |"
        )
    return "\n".join(lines)


def stress_highlights(summary: dict) -> str:
    stress = summary.get("stress_metrics", {})
    if not stress:
        return "Stress metrics are not embedded in this summary."
    lines = ["| Axis | Final severity | Baseline L2 | Robust L2 | Baseline MAE | Robust MAE |", "|---|---:|---:|---:|---:|---:|"]
    for axis, rows in stress.items():
        final = rows[-1]
        baseline = final["methods"]["baseline"]
        robust = final["methods"]["robust"]
        lines.append(
            "| "
            + " | ".join(
                [
                    axis,
                    fmt(final["severity"], digits=2),
                    fmt(baseline["relative_l2"]),
                    fmt(robust["relative_l2"]),
                    fmt(baseline["mae"]),
                    fmt(robust["mae"]),
                ]
            )
            + " |"
        )
    return "\n".join(lines)


def confidence_section(summary: dict) -> str:
    confidence = summary["confidence_analysis"]
    selective = confidence["selective_mae"]
    lines = [
        "| Metric | Value |",
        "|---|---:|",
        f'| Clean-vs-corrupted AUROC | {fmt(confidence["confidence_corruption_auc"])} |',
        f'| Pearson(confidence, MAE) | {fmt(confidence["confidence_vs_mae_pearson"])} |',
        f'| Pearson(confidence, relative L2) | {fmt(confidence["confidence_vs_relative_l2_pearson"])} |',
        f'| ECE-like gap | {fmt(confidence["mae_ece_like"])} |',
        f'| Selective MAE @ 25% coverage | {fmt(selective["mae_at_25pct"])} |',
        f'| Selective MAE @ 50% coverage | {fmt(selective["mae_at_50pct"])} |',
        f'| Selective MAE @ 75% coverage | {fmt(selective["mae_at_75pct"])} |',
        f'| Selective MAE @ 100% coverage | {fmt(selective["mae_at_100pct"])} |',
    ]
    return "\n".join(lines)


def write_markdown(args: argparse.Namespace) -> None:
    summary = load_json(args.results / "summary.json")
    all_conditions = summary["conditions"]
    corrupt_conditions = [c for c in all_conditions if c != "clean"]
    robust_all = mean_over_conditions(summary, "robust", all_conditions)
    baseline_all = mean_over_conditions(summary, "baseline", all_conditions)
    robust_corrupt = mean_over_conditions(summary, "robust", corrupt_conditions)
    baseline_corrupt = mean_over_conditions(summary, "baseline", corrupt_conditions)

    lines = [
        "# Final Paper Package: Simulation-Methodology CEM/EIT Study",
        "",
        "This package captures the final closed-loop synthetic study centered on the independent v3 CEM test set.",
        "",
        "## Dataset and Scope",
        "",
        f'- Independent v3 test set size: {summary["samples"]} samples',
        f'- Conditions: {", ".join(all_conditions)}',
        f'- Result directory: `{args.results.resolve()}`',
        "",
        "## Main Method Comparison",
        "",
        method_overview_table(summary),
        "",
        "## Baseline vs Robust by Condition",
        "",
        condition_table(summary),
        "",
        "## Paired Bootstrap Against Baseline",
        "",
        bootstrap_table(summary),
        "",
        "## Stress Test Highlights",
        "",
        stress_highlights(summary),
        "",
        "## Confidence Reliability",
        "",
        confidence_section(summary),
        "",
        "## Conservative Takeaway",
        "",
        f'- On all 8 conditions, robust and baseline are nearly tied on relative L2 ({fmt(baseline_all["relative_l2"])} vs {fmt(robust_all["relative_l2"])}), but robust lowers MAE ({fmt(baseline_all["mae"])} vs {fmt(robust_all["mae"])}).',
        f'- On the 7 corrupted conditions, robust improves relative L2 ({fmt(baseline_corrupt["relative_l2"])} → {fmt(robust_corrupt["relative_l2"])}) and MAE ({fmt(baseline_corrupt["mae"])} → {fmt(robust_corrupt["mae"])}).',
        '- The confidence map is a weak prior-reliability signal, not a fully calibrated error predictor.',
        "",
        "## Figure Manifest",
        "",
        f'- Comparison: `{args.results / "comparison.png"}`',
        f'- Stress curves: `{args.results / "stress_curves.png"}`',
        f'- Confidence reliability: `{args.results / "confidence_reliability.png"}`',
        f'- Condition confidence/error: `{args.results / "condition_confidence_error.png"}`',
        f'- Example panels: `{args.results / "examples.png"}`',
    ]

    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "FINAL_PAPER_PACKAGE.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def copy_figures(args: argparse.Namespace) -> None:
    figure_dir = args.output_dir / "figures"
    figure_dir.mkdir(parents=True, exist_ok=True)
    sources = [
        args.results / "comparison.png",
        args.results / "stress_curves.png",
        args.results / "confidence_reliability.png",
        args.results / "condition_confidence_error.png",
        args.results / "examples.png",
    ]
    manifest = []
    for source in sources:
        if source.exists():
            target = figure_dir / source.name
            shutil.copy2(source, target)
            manifest.append({"source": str(source.resolve()), "target": str(target.resolve())})
    (args.output_dir / "figure_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")


def main() -> None:
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Build the final manuscript evidence package from the independent v3 CEM study.")
    parser.add_argument("--results", type=Path, default=root / "outputs_diverse_method_suite")
    parser.add_argument("--output-dir", type=Path, default=root / "paper_final_package")
    args = parser.parse_args()
    write_markdown(args)
    copy_figures(args)
    print(f"wrote {args.output_dir.resolve()}")


if __name__ == "__main__":
    main()
