from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

from eit_basic import EITConfig, run_eit_pipeline
from eit_basic.plotting import save_pipeline_figure


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run a basic 2D EIT forward and inverse simulation."
    )
    parser.add_argument("--snr-db", type=float, default=60.0)
    parser.add_argument("--model", choices=["cem", "point"], default="cem")
    parser.add_argument("--forward-mesh-size", type=float, default=0.05)
    parser.add_argument("--inverse-mesh-size", type=float, default=0.11)
    parser.add_argument("--electrode-width", type=float, default=2.5 / 14.0)
    parser.add_argument("--contact-impedance", type=float, default=0.01)
    parser.add_argument("--current-amplitude", type=float, default=1.0)
    parser.add_argument("--lambda-reg", type=float, default=0.01)
    parser.add_argument("--seed", type=int, default=20260716)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(__file__).resolve().parent / "outputs",
    )
    return parser.parse_args()


def save_numeric_outputs(result, output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)

    np.savez_compressed(
        output_dir / "simulation_data.npz",
        forward_nodes=result.forward_mesh.node,
        forward_elements=result.forward_mesh.element,
        forward_electrode_nodes=result.forward_mesh.el_pos,
        inverse_nodes=result.inverse_mesh.node,
        inverse_elements=result.inverse_mesh.element,
        inverse_electrode_nodes=result.inverse_mesh.el_pos,
        forward_electrode_edges=(
            result.forward_electrode_edges
            if result.forward_electrode_edges is not None
            else np.empty((0, 2), dtype=int)
        ),
        forward_electrode_ids=(
            result.forward_electrode_ids
            if result.forward_electrode_ids is not None
            else np.empty(0, dtype=int)
        ),
        excitation_matrix=result.protocol.ex_mat,
        measurement_matrix=result.protocol.meas_mat,
        conductivity_true_forward=result.conductivity_true_forward,
        conductivity_true_inverse=result.conductivity_true_inverse,
        truth_delta=result.truth_delta,
        voltage_background=result.voltage_background,
        voltage_clean=result.voltage_clean,
        voltage_noisy=result.voltage_noisy,
        voltage_noise=result.voltage_noise,
        first_excitation_potential=result.first_excitation_potential,
        reconstruction_delta=result.reconstruction_delta,
        jacobian=(
            result.jacobian
            if result.jacobian is not None
            else np.empty((0, result.inverse_mesh.n_elems))
        ),
    )

    with (output_dir / "voltages.csv").open(
        "w",
        newline="",
        encoding="utf-8",
    ) as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "index",
                "background",
                "clean",
                "noisy",
                "difference_clean",
                "difference_noisy",
            ]
        )
        for index, values in enumerate(
            zip(
                result.voltage_background,
                result.voltage_clean,
                result.voltage_noisy,
                result.voltage_clean - result.voltage_background,
                result.voltage_noisy - result.voltage_background,
                strict=True,
            )
        ):
            writer.writerow([index, *[float(value) for value in values]])

    summary = {
        "stage": f"basic {result.config.forward_model} EIT",
        "python_note": "Run with the active Python interpreter.",
        "n_electrodes": result.config.n_electrodes,
        "n_excitations": int(result.protocol.ex_mat.shape[0]),
        "measurements_per_excitation": int(result.protocol.meas_mat.shape[1]),
        "n_measurements": int(result.voltage_clean.size),
        "forward_mesh": {
            "mesh_size": result.config.forward_mesh_size,
            "n_nodes": int(result.forward_mesh.n_nodes),
            "n_elements": int(result.forward_mesh.n_elems),
        },
        "inverse_mesh": {
            "mesh_size": result.config.inverse_mesh_size,
            "n_nodes": int(result.inverse_mesh.n_nodes),
            "n_elements": int(result.inverse_mesh.n_elems),
        },
        "inverse_crime_avoided": True,
        "forward_model": result.config.forward_model,
        "cem_parameters": {
            "electrode_width": result.config.electrode_width,
            "contact_impedance": result.config.contact_impedance,
            "current_amplitude": result.config.current_amplitude,
            "forward_electrode_lengths": (
                result.forward_electrode_lengths.tolist()
                if result.forward_electrode_lengths is not None
                else None
            ),
            "inverse_electrode_lengths": (
                result.inverse_electrode_lengths.tolist()
                if result.inverse_electrode_lengths is not None
                else None
            ),
        },
        "target_snr_db": result.config.snr_db,
        "actual_snr_db": result.actual_snr_db,
        "lambda_reg": result.config.lambda_reg,
        "jacobian_p": result.config.jacobian_p,
        "jacobian_shape": (
            list(result.jacobian.shape) if result.jacobian is not None else None
        ),
        "reconstruction_correlation": result.reconstruction_correlation,
        "conductivity_values": {
            "background": result.config.background_conductivity,
            "lung": result.config.lung_conductivity,
            "heart": result.config.heart_conductivity,
        },
    }
    with (output_dir / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2, ensure_ascii=False)


def main() -> None:
    arguments = parse_arguments()
    configuration = EITConfig(
        forward_model=arguments.model,
        forward_mesh_size=arguments.forward_mesh_size,
        inverse_mesh_size=arguments.inverse_mesh_size,
        electrode_width=arguments.electrode_width,
        contact_impedance=arguments.contact_impedance,
        current_amplitude=arguments.current_amplitude,
        snr_db=arguments.snr_db,
        random_seed=arguments.seed,
        lambda_reg=arguments.lambda_reg,
    )

    print("[1/4] Creating mesh, electrodes and heart-lung phantom...")
    print("[2/4] Solving forward EIT measurements and adding noise...")
    print(
        "[3/4] Running "
        f"{arguments.model.upper()} JAC/Tikhonov difference reconstruction..."
    )
    result = run_eit_pipeline(configuration)

    print("[4/4] Saving arrays, summary and figures...")
    save_numeric_outputs(result, arguments.output_dir)
    save_pipeline_figure(result, arguments.output_dir / "eit_pipeline.png")

    print()
    print("Basic EIT pipeline completed.")
    print(
        "  Forward mesh: "
        f"{result.forward_mesh.n_nodes} nodes, "
        f"{result.forward_mesh.n_elems} elements"
    )
    print(
        "  Inverse mesh: "
        f"{result.inverse_mesh.n_nodes} nodes, "
        f"{result.inverse_mesh.n_elems} elements"
    )
    print(
        "  Protocol: "
        f"{result.protocol.ex_mat.shape[0]} excitations x "
        f"{result.protocol.meas_mat.shape[1]} measurements = "
        f"{result.voltage_clean.size} values"
    )
    print(f"  Actual SNR: {result.actual_snr_db:.4f} dB")
    print(
        "  Reconstruction correlation: "
        f"{result.reconstruction_correlation:.4f}"
    )
    print(f"  Outputs: {arguments.output_dir.resolve()}")


if __name__ == "__main__":
    main()
