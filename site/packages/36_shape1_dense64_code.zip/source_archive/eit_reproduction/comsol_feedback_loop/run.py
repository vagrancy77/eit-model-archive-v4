"""Locked, resumable full-cohort training; no test use until weights freeze."""
import argparse
import json
import os
import subprocess
import time
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import DataLoader, default_collate
from comsol_v4.data_v6 import (FINAL_DATASET_ROOT, assert_final_dataset, verify_manifest,
                              file_hash, grid_arrays)
from comsol_v4.train import load_checkpoint, move
from comsol_v4.paper_common import configure_runtime, StopState
from comsol_v4.metrics import per_case_metrics, aggregate
from comsol_feedback.fem import TerminalFEM
from .acceptance import BASE, run as accept
from .data import LoopDataset
from .model import ClosedLoopEIT, objective
from .io import write_json, save_checkpoint, sources, check_sources


def protocol():
    return {
        "version": "diagram-closed-loop-v2", "seed": 20261016, "K": 3,
        "dataset_root": str(FINAL_DATASET_ROOT),
        "dataset_contract": assert_final_dataset(FINAL_DATASET_ROOT),
        "baseline_checkpoint": str(BASE), "baseline_sha256": file_hash(BASE),
        "first_stage_frozen": False, "end_to_end_physics_loss": True,
        "sharing": "one refiner shared across three updates",
        "feedback": "fresh nonlinear FEM and complex residual/adjoint at every current state",
        "hint_derivative": "stop-gradient, no second-order adjoint; voltage path remains differentiable",
        "boundary_model": "dataset-effective ideal equipotential terminals, not finite-contact CEM",
        "background": "observed V0 plus known homogeneous material; independent-FEM anchoring",
        "batch_size": 4, "refiner_base": 24, "fem_spacing_m": .0016,
        "minimum_epochs": 100, "max_epochs": 250, "patience": 40,
        "minimum_improvement": 1e-5, "lr_initial": 1e-5, "lr_refiner": 1e-4,
        "lr_patience": 15, "lr_factor": .5, "min_lr": [1e-7, 1e-6],
        "loss": "last reconstruction + .2 mean earlier reconstruction + .2 V4 auxiliaries + .1 mean post-update complex voltage MSE",
        "selection": "validation CE + Dice + .65 log_sigma + .35 log_eps",
        "test_policy": "all weights selected/frozen before this run's test; historically observed test, exploratory",
        "comparators": ["original_V4", "joint_V4_before_loop", "round1", "round2", "round3",
                        "historical_single_step_same_seed"],
        "scope": "one predetermined seed, whole 3400/720/720 cohort; not a multiseed causal ablation",
        "source_hashes": sources()}


def arguments(batch):
    return [batch[k] for k in ("features", "observed", "background", "reference")]


def plot(root, preview=False):
    command = ["E:/Anaconda/python.exe", "-s", str(Path(__file__).with_name("report.py")),
               "--root", str(root)]
    if preview:
        command.append("--preview")
    subprocess.run(command, check=True, creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)


def epoch_run(model, ds, p, root, epoch, optimizer=None):
    training = optimizer is not None
    model.train(training)
    gen = torch.Generator().manual_seed(p["seed"]+1000003*epoch)
    loader = DataLoader(ds, batch_size=p["batch_size"], shuffle=training,
                        generator=gen, num_workers=0)
    sums = np.zeros(3)
    rows, count = [], 0
    start, last = time.monotonic(), 0
    for batch in loader:
        batch = move(batch, "cuda")
        with torch.set_grad_enabled(training):
            out = model(*arguments(batch))
            total, score, physical = objective(out, batch, model.refiner.fov)
            if not torch.isfinite(total):
                raise FloatingPointError("Nonfinite loss")
            if training:
                optimizer.zero_grad(set_to_none=True)
                total.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True)
                optimizer.step()
        n = len(batch["features"])
        sums += np.array([total.item(), score.item(), physical.item()])*n
        count += n
        if not training:
            rows.extend(per_case_metrics(out, batch, model.refiner.fov))
        elapsed = time.monotonic()-start
        if elapsed-last >= 30 or count == len(ds):
            last = elapsed
            seconds_case = elapsed/count
            write_json(root/"status.json", {
                "phase": "training" if training else "validation", "epoch": epoch,
                "processed": count, "total": len(ds), "max_epochs": p["max_epochs"],
                "minimum_epochs": p["minimum_epochs"], "K": p["K"], "joint_training": True,
                "seconds_per_case": seconds_case, "phase_remaining_seconds": seconds_case*(len(ds)-count),
                "updated_unix": time.time()})
            print(f'{"TRAIN" if training else "VAL"} epoch={epoch} {count}/{len(ds)} '
                  f'loss={sums[0]/count:.6f} physics={sums[2]/count:.6g} sec={elapsed:.1f}', flush=True)
        del out, batch, total, score, physical
    if count != len(ds):
        raise RuntimeError("Incomplete cohort")
    return (dict(zip(("loss", "selection_loss", "physics_loss"), (sums/count).tolist())),
            aggregate(rows) if rows else None)


def preview(model, ds, root, epoch):
    indices = [next(i for i, r in enumerate(ds.rows) if r["shape_class"] == cls) for cls in "ABCDE"]
    b = move(default_collate([ds[i] for i in indices]), "cuda")
    model.eval()
    with torch.no_grad():
        out = model(*arguments(b))
    np.savez_compressed(root/"validation_preview.npz",
                        truth=b["mask"].cpu().numpy(),
                        initial=out["initial"]["foreground_probability"].cpu().numpy(),
                        rounds=np.stack([s["foreground_probability"].cpu().numpy() for s in out["stages"]]),
                        voltage_mse=out["voltage_mse_by_round"].cpu().numpy(),
                        case_ids=np.array(b["case_id"]), epoch=epoch)
    plot(root, preview=True)


def train(root, p, phash, model, norm, solver):
    if (root/"training_complete.json").exists():
        done = json.loads((root/"training_complete.json").read_text())
        if done["protocol_sha256"] != phash or done["checkpoint_sha256"] != file_hash(root/"best.pt"):
            raise RuntimeError("Completed weights/protocol mismatch")
        return
    data = {split: LoopDataset(FINAL_DATASET_ROOT, split, norm, solver) for split in ("train", "val")}
    opt = torch.optim.AdamW([
        {"params": model.initial.parameters(), "lr": p["lr_initial"]},
        {"params": model.refiner.parameters(), "lr": p["lr_refiner"]}], weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        opt, patience=p["lr_patience"], factor=p["lr_factor"], min_lr=p["min_lr"],
        threshold=p["minimum_improvement"], threshold_mode="abs")
    stop = StopState(p["minimum_improvement"])
    history, start, best_epoch, best = [], 0, 0, float("inf")
    def ck(epoch):
        return {"protocol_sha256": phash, "model": model.state_dict(),
                "optimizer": opt.state_dict(), "scheduler": scheduler.state_dict(),
                "early_stop": stop.state_dict(), "history": history, "epoch": epoch,
                "best_score": best, "best_epoch": best_epoch,
                "rng_cpu": torch.get_rng_state(), "rng_cuda": torch.cuda.get_rng_state_all(),
                "normalizer": norm.state()}
    if (root/"last.pt").exists():
        c = torch.load(root/"last.pt", map_location="cpu", weights_only=True)
        if c["protocol_sha256"] != phash:
            raise ValueError("Resume provenance mismatch")
        model.load_state_dict(c["model"])
        opt.load_state_dict(c["optimizer"])
        scheduler.load_state_dict(c["scheduler"])
        stop.load_state_dict(c["early_stop"])
        history, start, best_epoch, best = c["history"], c["epoch"], c["best_epoch"], c["best_score"]
        torch.set_rng_state(c["rng_cpu"])
        torch.cuda.set_rng_state_all(c["rng_cuda"])
        del c
    else:
        initial, _ = epoch_run(model, data["val"], p, root, 0)
        best = initial["selection_loss"]
        stop.step(best)
        save_checkpoint(root/"best.pt", ck(0))
        save_checkpoint(root/"last.pt", ck(0))
        preview(model, data["val"], root, 0)
    reason = "max_epochs_not_automatic_convergence"
    for epoch in range(start+1, p["max_epochs"]+1):
        check_sources(p["source_hashes"])
        if epoch > p["minimum_epochs"] and stop.bad_epochs >= p["patience"]:
            reason = "validation_early_stopping"
            break
        tick = time.monotonic()
        tr, _ = epoch_run(model, data["train"], p, root, epoch, opt)
        va, metrics = epoch_run(model, data["val"], p, root, epoch)
        score = va["selection_loss"]
        scheduler.step(score)
        stop.step(score)
        improved = score < best
        if improved:
            best, best_epoch = score, epoch
        history.append({"epoch": epoch, "train": tr, "val": va, "val_metrics": metrics,
                        "lr": [g["lr"] for g in opt.param_groups], "seconds": time.monotonic()-tick})
        if improved:
            save_checkpoint(root/"best.pt", ck(epoch))
        save_checkpoint(root/"last.pt", ck(epoch))
        write_json(root/"history.json", history)
        # Fixed cases, not selected based on appealing reconstruction.
        preview(model, data["val"], root, epoch)
    write_json(root/"training_complete.json", {
        "protocol_sha256": phash, "epochs": len(history), "selected_epoch": best_epoch,
        "best_score": best, "stop_reason": reason, "checkpoint_sha256": file_hash(root/"best.pt")})


def evaluate(root, p, phash, model, norm, solver):
    done = json.loads((root/"training_complete.json").read_text())
    if done["protocol_sha256"] != phash or done["checkpoint_sha256"] != file_hash(root/"best.pt"):
        raise RuntimeError("Frozen checkpoint mismatch")
    write_json(root/"frozen_evaluation.json", done)
    c = torch.load(root/"best.pt", map_location="cpu", weights_only=True)
    model.load_state_dict(c["model"])
    del c
    model.eval()
    original, _, _, _ = load_checkpoint(BASE, torch.device("cuda"))
    ds = LoopDataset(FINAL_DATASET_ROOT, "test", norm, solver)
    names = ["original_V4", "joint_V4_before_loop", "round1", "round2", "round3"]
    records = {k: [] for k in names}
    for name in names:
        (root/"evaluations"/name).mkdir(parents=True, exist_ok=True)
    for raw in DataLoader(ds, batch_size=p["batch_size"], shuffle=False):
        b = move(raw, "cuda")
        with torch.no_grad():
            out = model(*arguments(b))
            old = original(b["features"])
            oldphysics = model.physics(old, b["observed"], b["background"], b["reference"], hints=False)
        states = [old, out["initial"], *out["stages"]]
        for j, (name, state) in enumerate(zip(names, states)):
            metrics = per_case_metrics(state, b, model.refiner.fov)
            physical = oldphysics["voltage_mse"] if j == 0 else out["voltage_mse_by_round"][:, j-1]
            for i, (cid, metric) in enumerate(zip(b["case_id"], metrics)):
                metric["voltage_mse_10000Hz"], metric["voltage_mse_50000Hz"] = physical[i].cpu().tolist()
                records[name].append(metric)
                np.savez_compressed(root/"evaluations"/name/(cid+".npz"),
                                    fg=state["foreground_probability"][i].cpu().numpy(),
                                    probabilities=state["probabilities"][i].cpu().numpy(),
                                    sigma=state["sigma"][i].cpu().numpy(),
                                    eps_r=state["eps_r"][i].cpu().numpy(),
                                    truth=b["mask"][i].cpu().numpy(),
                                    true_sigma=b["sigma"][i].cpu().numpy(),
                                    true_eps_r=b["eps_r"][i].cpu().numpy())
        write_json(root/"status.json", {"phase": "test", "processed": len(records[names[0]]),
                                       "total": 720, "updated_unix": time.time()})
        print(f'TEST {len(records[names[0]])}/720', flush=True)
    for name in names:
        if len(records[name]) != 720:
            raise RuntimeError("Incomplete test")
        write_json(root/"evaluations"/name/"metrics.json", {
            "protocol_sha256": phash, "aggregate": aggregate(records[name]), "records": records[name]})
    check_sources(p["source_hashes"])
    plot(root)
    write_json(root/"delivery_audit.json", {
        "status": "PASS", "protocol_sha256": phash, "checkpoint_sha256": file_hash(root/"best.pt"),
        "test_case_count_per_method": {k: len(v) for k, v in records.items()},
        "K": 3, "joint_training": True, "final_physics_loss": True,
        "test_after_freeze": True, "source_hashes": p["source_hashes"]})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, default=Path("E:/Codex/complex_feedback_loop_v2"))
    ap.add_argument("--prepare-only", action="store_true")
    a = ap.parse_args()
    root = a.root.resolve()
    root.mkdir(parents=True, exist_ok=True)
    import msvcrt
    lock = (root/"worker.lock").open("a+b")
    lock.seek(0)
    try:
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
    except OSError:
        lock.close()
        raise RuntimeError("Worker already running; do not duplicate")
    try:
        p = protocol()
        path = root/"protocol.json"
        if path.exists() and json.loads(path.read_text(encoding="utf-8")) != p:
            raise RuntimeError("Frozen protocol/source differs; use new directory")
        if not path.exists():
            write_json(path, p)
        phash = file_hash(path)
        if (root/"complete.json").exists():
            print("Already complete", flush=True)
            return
        qa = root/"qa/architecture_acceptance.json"
        fem = root/"qa/fem/physics_acceptance.json"
        if not qa.exists() or json.loads(qa.read_text())["source_hashes"] != sources() or not fem.exists():
            accept(root/"qa", full_physics=True)
        if json.loads(qa.read_text())["status"] != "PASS" or json.loads(fem.read_text())["status"] != "PASS":
            raise RuntimeError("Acceptance failed. Training forbidden.")
        integrity = root/"dataset_integrity.json"
        if not integrity.exists():
            write_json(integrity, verify_manifest(FINAL_DATASET_ROOT))
        if a.prepare_only:
            print("ACCEPTANCE PASSED; full training not started.", flush=True)
            return
        configure_runtime(p["seed"])  # QA weights/RNG never reused.
        x, y, fov = grid_arrays(FINAL_DATASET_ROOT)
        solver = TerminalFEM(x, y, fov, spacing=p["fem_spacing_m"])
        base, norm, _, _ = load_checkpoint(BASE, torch.device("cuda"))
        norm.validate_training_contract(FINAL_DATASET_ROOT, "calibrated")
        model = ClosedLoopEIT(base, solver, p["K"], p["refiner_base"]).cuda()
        train(root, p, phash, model, norm, solver)
        evaluate(root, p, phash, model, norm, solver)
        write_json(root/"complete.json", {"protocol_sha256": phash, "finished_unix": time.time()})
        write_json(root/"status.json", {"phase": "complete", "updated_unix": time.time()})
    except Exception as e:
        write_json(root/"status.json", {"phase": "failed", "error": repr(e), "updated_unix": time.time()})
        raise
    finally:
        lock.close()


if __name__ == "__main__":
    main()
