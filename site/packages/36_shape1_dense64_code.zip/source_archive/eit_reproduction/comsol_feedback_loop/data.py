"""Only features, observed/reference voltage and known background enter model."""
import json
import numpy as np
import torch
from comsol_v4.data_v6 import ComsolDataset, row_case_path, read_measurements
from comsol_feedback.verify import background_parameters


class LoopDataset(ComsolDataset):
    def __init__(self, root, split, normalizer, solver, limit=0, with_labels=True):
        super().__init__(root, split, normalizer, limit=limit, with_labels=with_labels)
        self.measurements = []
        references = {}
        for row in self.rows:
            path = row_case_path(root, row)
            observed, background, _, _ = read_measurements(path)
            with np.load(path, allow_pickle=False) as z:
                params = json.loads(z["parameters_json"].item()) if "parameters_json" in z else None
            if params is None:
                params = json.loads((path.parent/"case_parameters.json").read_text(encoding="utf-8"))
            known = background_parameters(params)
            for gamma in known:
                if gamma not in references:
                    references[gamma] = solver.solve(np.full((64, 64), gamma))[0]
            self.measurements.append({
                "observed": torch.from_numpy(observed.copy()),
                "background": torch.from_numpy(background.copy()),
                "reference": torch.from_numpy(np.stack([references[g] for g in known]))})
        # Cache data/labels in host RAM, NEVER case-dependent FEM predictions.
        self.items = [super(LoopDataset, self).__getitem__(i) for i in range(len(self.rows))]

    def __getitem__(self, i):
        return {**self.items[i], **self.measurements[i]}
