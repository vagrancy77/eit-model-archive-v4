"""CPU-only figures/statistics. Not imported by the training loss."""
import argparse
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def write(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False), encoding="utf-8")


def preview(root):
    with np.load(root/"validation_preview.npz", allow_pickle=False) as z:
        truth, initial, stages = z["truth"], z["initial"], z["rounds"]
        ids, epoch, voltage = z["case_ids"], int(z["epoch"]), z["voltage_mse"]
    fig, axes = plt.subplots(len(ids), 5, figsize=(13, 2.4*len(ids)), squeeze=False, constrained_layout=True)
    for i, cid in enumerate(ids):
        for j, image in enumerate([truth[i, 0], initial[i, 0], *stages[:, i, 0]]):
            axes[i, j].imshow(image, origin="lower", cmap="gray_r", vmin=0, vmax=1)
            if j:
                axes[i, j].contour(truth[i, 0], levels=[.5], colors="red", linewidths=.6)
            title = ["Truth", "V4 (joint)", "Round 1", "Round 2", "Round 3"][j]
            if j:
                title += f"\nvoltage MSE={voltage[i, j-1].mean():.2g}"
            axes[i, j].set_title(str(cid)+" / "+title, fontsize=8)
            axes[i, j].set_axis_off()
    fig.suptitle(f"Fixed VALIDATION cases | epoch {epoch} | probability maps (not selected by performance)")
    fig.savefig(root/"latest_validation.png", dpi=140)
    plt.close(fig)
    hp = root/"history.json"
    if hp.exists():
        h = json.loads(hp.read_text())
        fig, ax = plt.subplots(1, 3, figsize=(13, 3.7), constrained_layout=True)
        for a, metric, title in zip(ax, ["selection_loss", "physics_loss", "loss"],
                                    ["Reconstruction selection loss", "Post-update voltage MSE", "Training objective"]):
            for split in ("train", "val"):
                a.plot([x["epoch"] for x in h], [x[split][metric] for x in h], label=split)
            a.set_title(title)
            a.set_xlabel("Epoch")
            a.grid(alpha=.2)
            a.legend()
        fig.savefig(root/"training_curves.png", dpi=150)
        plt.close(fig)


def final(root):
    from scipy.ndimage import binary_erosion, distance_transform_edt
    p = json.loads((root/"protocol.json").read_text(encoding="utf-8"))
    dataset = Path(p["dataset_root"])
    names = ["original_V4", "joint_V4_before_loop", "round1", "round2", "round3"]
    with np.load(dataset/"grid.npz") as z:
        fov = z["valid_mask"].astype(bool)
        mm = float(np.diff(z["x"]).mean()*1000)
    positions = {r["case_id"]: r["position_id"] for r in json.loads((dataset/"splits.json").read_text())["splits"]}
    records = {n: json.loads((root/"evaluations"/n/"metrics.json").read_text())["records"] for n in names}
    folders = {n: root/"evaluations"/n for n in names}
    # Historical same-seed model is an explicitly labeled separate experiment.
    historical = Path("E:/Codex/complex_feedback_long_v1/seed20261016/evaluations/feedback")
    historical_protocol = historical.parents[1]/"protocol.json"
    if historical.exists():
        old = json.loads(historical_protocol.read_text())
        if old["baseline_sha256"] != p["baseline_sha256"]:
            raise ValueError("Historical baseline mismatch")
        records["historical_K1"] = json.loads((historical/"metrics.json").read_text())["records"]
        folders["historical_K1"] = historical
        names.append("historical_K1")
    reference_ids = {r["case_id"] for r in records["original_V4"]}
    for name in names:
        if len(records[name]) != 720 or {r["case_id"] for r in records[name]} != reference_ids:
            raise ValueError("Test cases do not align")
        for r in records[name]:
            with np.load(folders[name]/(r["case_id"]+".npz")) as z:
                pred = (z["probabilities"].argmax(0) > 0)&fov
                truth = (z["truth"][0] > .5)&fov
            a, b = pred^binary_erosion(pred), truth^binary_erosion(truth)
            dist = (np.r_[distance_transform_edt(~a)[b], distance_transform_edt(~b)[a]]*mm
                    if a.any() and b.any() else np.array([np.hypot(64, 64)*mm]))
            r["hd95_mm"] = float(np.quantile(dist, .95))
            r["position_id"] = positions[r["case_id"]]
    byid = {n: {r["case_id"]: r for r in rows} for n, rows in records.items()}
    groups = {"all": "ABCDE", "ordinary_A": "A", "concave_BCDE": "BCDE"}
    metrics = ["foreground_iou", "foreground_dice", "mean_iou_present_classes",
               "sigma_ssim_10000Hz", "sigma_ssim_50000Hz", "sigma_nrmse_10000Hz",
               "sigma_nrmse_50000Hz", "eps_r_nrmse_10000Hz", "eps_r_nrmse_50000Hz", "hd95_mm"]
    means = {n: {g: {m: float(np.mean([r[m] for r in records[n] if r["shape_class"] in classes]))
                     for m in metrics} for g, classes in groups.items()} for n in names}
    paired = {}
    rng = np.random.default_rng(20261021)
    for base in [n for n in names if n != "round3"]:
        paired[base] = {}
        for group, classes in groups.items():
            rows = [r for r in records["round3"] if r["shape_class"] in classes]
            clusters = sorted({r["position_id"] for r in rows})
            draws = rng.integers(0, len(clusters), (5000, len(clusters)))
            stats = {}
            for m in metrics:
                delta = {c: np.array([r[m]-byid[base][r["case_id"]][m] for r in rows if r["position_id"] == c])
                         for c in clusters}
                sums = np.array([a.sum() for a in delta.values()])
                sizes = np.array([len(a) for a in delta.values()])
                boots = sums[draws].sum(1)/sizes[draws].sum(1)
                stats[m] = {"difference": float(sums.sum()/sizes.sum()),
                            "position_bootstrap_95ci": np.quantile(boots, [.025, .975]).tolist()}
            delta = np.array([r["foreground_iou"]-byid[base][r["case_id"]]["foreground_iou"] for r in rows])
            paired[base][group] = {"metrics": stats, "improved": int((delta > 1e-10).sum()),
                                   "worse": int((delta < -1e-10).sum()), "unchanged": int((abs(delta) <= 1e-10).sum())}
    summary = {"K": 3, "seed": p["seed"], "single_seed": True, "aggregate": means,
               "round3_minus_comparator": paired,
               "voltage_mse": {n: {str(f): float(np.mean([r[f"voltage_mse_{f}Hz"] for r in records[n]]))
                                    for f in (10000, 50000)}
                               for n in names if n != "historical_K1"},
               "limitations": ["Previously observed test set; exploratory, not external validation.",
                               "One training seed; CI reflects position groups, not seed uncertainty.",
                               "Joint V4 fine-tuning differs from historical frozen-V4 K1.",
                               "Intermediate rounds share final trained weights; not separately trained ablations.",
                               "Independent FEM and known-background anchoring, not original COMSOL mesh.",
                               "Fresh adjoint hints are stop-gradient; the voltage/state path is differentiable."]}
    write(root/"summary_statistics.json", summary)
    write(root/"per_case_metrics.json", records)
    def draw(ids, filename):
        cols = ["original_V4", "joint_V4_before_loop", "round1", "round2", "round3"]
        fig, axes = plt.subplots(len(ids), len(cols)+1, figsize=(16, 2.35*len(ids)), squeeze=False, constrained_layout=True)
        for i, cid in enumerate(ids):
            with np.load(folders["original_V4"]/(cid+".npz")) as z:
                truth = z["truth"][0]
            axes[i, 0].imshow(np.where(fov, truth, np.nan), origin="lower", cmap="gray_r", vmin=0, vmax=1)
            axes[i, 0].set_title(cid+" / Truth", fontsize=8)
            for j, name in enumerate(cols, 1):
                with np.load(folders[name]/(cid+".npz")) as z:
                    im = z["probabilities"].argmax(0) > 0
                axes[i, j].imshow(np.where(fov, im, np.nan), origin="lower", cmap="gray_r", vmin=0, vmax=1)
                axes[i, j].contour(truth, levels=[.5], colors="red", linewidths=.6)
                axes[i, j].set_title(name+f'\nIoU={byid[name][cid]["foreground_iou"]:.4f}', fontsize=8)
            for ax in axes[i]:
                ax.set_axis_off()
        fig.savefig(root/filename, dpi=150)
        plt.close(fig)
    fixed = []
    for cls in "ABCDE":
        fixed.extend(sorted(cid for cid in reference_ids if cid.startswith(cls+"_"))[:2])
    draw(fixed, "fixed_cases.png")
    ordered = sorted(reference_ids, key=lambda cid: byid["round3"][cid]["foreground_iou"]-byid["original_V4"][cid]["foreground_iou"])
    draw(ordered[:5], "worst_changes.png")
    draw(ordered[-5:], "best_changes.png")
    fig, axes = plt.subplots(1, 3, figsize=(15, 4), constrained_layout=True)
    for ax, metric in zip(axes, ("foreground_iou", "sigma_nrmse_10000Hz", "hd95_mm")):
        ax.bar(range(len(names)), [means[n]["all"][metric] for n in names])
        ax.set_xticks(range(len(names)), names, rotation=35, ha="right", fontsize=8)
        ax.set_title(metric)
        ax.grid(axis="y", alpha=.2)
    fig.savefig(root/"overall_comparison.png", dpi=150)
    plt.close(fig)
    done = json.loads((root/"training_complete.json").read_text())
    text = ["# 三轮非线性物理闭环：最终数据集实验", "",
            "3400训练 / 720验证 / 720测试；K=3；联合微调V4和共享反馈网络；每轮重新求解；包含可微复数电压损失。",
            f'训练 {done["epochs"]} 轮，验证选择第 {done["selected_epoch"]} 轮；停止原因：{done["stop_reason"]}。', "",
            "|模型|IoU|Dice|mean IoU|SSIM 10k|SSIM 50k|σ NRMSE 10k|HD95 mm|",
            "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for n in names:
        text.append("|"+n+"|"+"|".join(f'{means[n]["all"][m]:.6f}' for m in metrics[:6]+["hd95_mm"])+"|")
    text += ["", "## 逐病例退步也必须报告", ""]
    for base in paired:
        for g in groups:
            d = paired[base][g]
            ci = d["metrics"]["foreground_iou"]
            text.append(f'- round3 vs {base}, {g}: ΔIoU={ci["difference"]:+.6f}, 位置组95%CI={ci["position_bootstrap_95ci"]}; 提升{d["improved"]}、下降{d["worse"]}、相同{d["unchanged"]}例。')
    text += ["", "## 解读限制", ""]+["- "+s for s in summary["limitations"]]
    text += ["", "图像：fixed_cases.png、worst_changes.png、best_changes.png、overall_comparison.png、training_curves.png。",
             "不能只因总体均值提高就声称普通病例全部不受损；不能把此单种子比较称为充分的因果消融。"]
    (root/"RESULTS.md").write_text("\n".join(text), encoding="utf-8")
    preview(root)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--preview", action="store_true")
    args = parser.parse_args()
    preview(args.root) if args.preview else final(args.root)
