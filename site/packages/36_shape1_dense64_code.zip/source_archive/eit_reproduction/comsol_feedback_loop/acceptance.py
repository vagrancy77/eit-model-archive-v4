"""Executable diagram acceptance, all examples from TRAIN only."""
import argparse
import inspect
import time
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import default_collate
from comsol_v4.train import load_checkpoint, move
from comsol_v4.data_v6 import FINAL_DATASET_ROOT, grid_arrays
from comsol_v4.paper_common import configure_runtime
from comsol_feedback.fem import TerminalFEM
from comsol_feedback.verify import run as verify_fem
from .data import LoopDataset
from .model import ClosedLoopEIT, objective
from .io import write_json, save_checkpoint, sources

BASE = Path("E:/Codex/eit_reproduction/outputs/final4840_paper_suite/runs/calibrated_seed20261016/best.pt")


def run(root, full_physics=True):
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    configure_runtime(20261016)
    if full_physics:
        verify_fem(root/"fem")
    x, y, fov = grid_arrays(FINAL_DATASET_ROOT)
    fov = fov.astype(bool)
    solver = TerminalFEM(x, y, fov)
    fv = torch.tensor(fov, dtype=torch.bool, device="cuda")
    base, norm, _, _ = load_checkpoint(BASE, torch.device("cuda"))
    ds = LoopDataset(FINAL_DATASET_ROOT, "train", norm, solver, limit=5)
    batch = move(default_collate([ds[0]]), "cuda")
    m = ClosedLoopEIT(base, solver, rounds=3).cuda()
    def predict(b, trace=False):
        return m(b["features"], b["observed"], b["background"], b["reference"], trace=trace)
    checks = {}
    assert list(inspect.signature(m.forward).parameters) == [
        "features", "observed", "background", "reference", "trace"]
    checks["measurement_only_forward_signature"] = True
    frozen_obs = batch["observed"].clone()
    # Nonzero update is required to distinguish recomputation from cached reuse.
    with torch.no_grad():
        m.refiner.head.bias.fill_(.003)
    m.eval()
    calls = m.physics.evaluations
    with torch.no_grad():
        out = predict(batch, True)
    assert m.physics.evaluations-calls == 4 and len(out["stages"]) == 3
    checks["three_updates_four_fresh_dual_frequency_forward_evaluations"] = True
    changes = []
    for k in range(1, 3):
        torch.testing.assert_close(out["trace"][k]["sigma"], out["stages"][k-1]["sigma"])
        torch.testing.assert_close(out["trace"][k]["eps_r"], out["stages"][k-1]["eps_r"])
        assert not torch.equal(out["trace"][k]["residual"], out["trace"][k-1]["residual"])
        changes.append(float((out["trace"][k]["residual"]-out["trace"][k-1]["residual"]).abs().max()))
    checks["updated_state_reaches_next_forward_and_changes_residual"] = changes
    torch.testing.assert_close(frozen_obs, batch["observed"])
    checks["original_measurements_never_overwritten"] = True
    for stage in out["stages"]:
        assert (stage["sigma"][..., fv] > 0).all() and (stage["eps_r"][..., fv] > 0).all()
        assert stage["fg"].min() >= 0 and stage["fg"].max() <= 1
    checks["physical_positivity_and_probability_bounds"] = True
    bad = dict(batch)
    for key in ("mask", "labels", "sdf", "cutout", "mouth", "sigma", "eps_r"):
        bad[key] = torch.zeros_like(batch[key])
    with torch.no_grad():
        alternative = predict(bad)
    torch.testing.assert_close(out["sigma"], alternative["sigma"], rtol=0, atol=0)
    checks["corrupting_truth_does_not_change_prediction"] = True
    # Phase perturbation, with original normalized features held constant: tests
    # that the feedback path really uses the complex observed measurement.
    phase = dict(batch)
    phase["observed"] = batch["observed"]*complex(np.cos(.001), np.sin(.001))
    with torch.no_grad():
        altered = predict(phase, True)
    assert not torch.equal(out["trace"][0]["residual"], altered["trace"][0]["residual"])
    checks["imaginary_measurement_information_used"] = True
    del out, alternative, altered
    # Differentiability through the final physical solve and all three updates.
    m.train()
    with torch.no_grad():
        m.refiner.head.weight.normal_(0, .0001)
    feedback_inputs = []
    def capture_feedback(_module, args):
        r = args[0]["residual"]
        r.retain_grad()
        feedback_inputs.append(r)
    hook = m.refiner.register_forward_pre_hook(capture_feedback)
    t = time.monotonic()
    out = predict(batch)
    physical = out["voltage_mse_by_round"][:, -1].mean()
    physical.backward()
    hook.remove()
    assert len(feedback_inputs) == 3
    checks["gradient_through_all_three_measurement_feedback_paths"] = []
    for r in feedback_inputs:
        assert r.grad is not None and torch.isfinite(r.grad).all() and r.grad.abs().sum() > 0
        checks["gradient_through_all_three_measurement_feedback_paths"].append(float(r.grad.norm()))
    del feedback_inputs
    for name, parameter in [("initial_material", m.initial.material_head[-1].weight),
                            ("initial_geometry", m.initial.base_logits_head[-1].weight),
                            ("refiner", m.refiner.head.weight)]:
        assert parameter.grad is not None and torch.isfinite(parameter.grad).all()
        assert parameter.grad.abs().sum() > 0, name
        checks["final_physics_gradient_"+name] = float(parameter.grad.norm())
    m.zero_grad(set_to_none=True)
    del out
    before_base = m.initial.material_head[-1].weight.detach().clone()
    before_refiner = m.refiner.head.weight.detach().clone()
    optimizer = torch.optim.AdamW(m.parameters(), lr=1e-5)
    out = predict(batch)
    loss, score, physical = objective(out, batch, m.refiner.fov)
    assert torch.isfinite(loss)
    loss.backward()
    torch.nn.utils.clip_grad_norm_(m.parameters(), 1., error_if_nonfinite=True)
    optimizer.step()
    assert not torch.equal(before_base, m.initial.material_head[-1].weight)
    assert not torch.equal(before_refiner, m.refiner.head.weight)
    checks["joint_training_updates_both_stages"] = True
    elapsed = time.monotonic()-t
    del out
    # Exercise the actual training batch size, all data still from TRAIN.
    benchmark_batch = move(default_collate([ds[i] for i in range(4)]), "cuda")
    optimizer.zero_grad(set_to_none=True)
    tick = time.monotonic()
    out = predict(benchmark_batch)
    total, _, _ = objective(out, benchmark_batch, m.refiner.fov)
    total.backward()
    torch.nn.utils.clip_grad_norm_(m.parameters(), 1., error_if_nonfinite=True)
    optimizer.step()
    batch_seconds = time.monotonic()-tick
    checks["batch4_forward_backward_optimizer_step"] = True
    from comsol_v4.metrics import per_case_metrics
    rows = per_case_metrics(out, benchmark_batch, m.refiner.fov)
    assert len(rows) == 4 and all(np.isfinite(r["foreground_iou"]) for r in rows)
    checks["evaluation_metrics_pipeline"] = True
    del benchmark_batch, out, total
    # Inference executes the very same loop with gradients disabled.
    m.eval()
    with torch.no_grad():
        out = predict(batch)
    saved = {k: v.detach().cpu().clone() for k, v in m.state_dict().items()}
    save_checkpoint(root/"qa_roundtrip.pt", {"model": saved, "optimizer": optimizer.state_dict()})
    restored = torch.load(root/"qa_roundtrip.pt", map_location="cpu", weights_only=True)
    m.load_state_dict(restored["model"])
    optimizer.load_state_dict(restored["optimizer"])
    with torch.no_grad():
        loaded = predict(batch)
    torch.testing.assert_close(out["sigma"], loaded["sigma"], rtol=0, atol=0)
    checks["checkpoint_reload_inference_equivalence"] = True
    # Confirm bidirectional geometry capability independent of learned quality.
    state, _ = m.initial_state(batch["features"])
    state.update(features=batch["features"], residual=torch.zeros(1, 4, 32, 32, device="cuda"),
                 hint=torch.zeros(1, 4, 64, 64, device="cuda"))
    with torch.no_grad():
        m.refiner.head.weight.zero_()
        for bias, sign in ((.03, 1), (-.03, -1)):
            m.refiner.head.bias.zero_()
            m.refiner.head.bias[0] = bias
            shifted = m.refiner(state)
            assert ((shifted["fg"]-state["fg"])*sign)[..., fv].min() >= -1e-6
    checks["geometry_addition_and_removal"] = True
    report = {"status": "PASS", "source_hashes": sources(), "checks": checks,
              "training_only_case_ids": [r["case_id"] for r in ds.rows],
              "two_forward_backward_pass_seconds": elapsed,
              "batch4_train_seconds": batch_seconds,
              "cuda_peak_allocated_MB": torch.cuda.max_memory_allocated()/2**20,
              "note": "Temporary QA weights are discarded, never used to initialize training.",
              "adjoint_hint": "fresh at each state; stop-gradient to avoid second-order FEM",
              "K": 3, "joint_training": True, "differentiable_physics_loss": True}
    write_json(root/"architecture_acceptance.json", report)
    print(report, flush=True)
    return report


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, required=True)
    ap.add_argument("--skip-fem", action="store_true")
    a = ap.parse_args()
    run(a.root, not a.skip_fem)
