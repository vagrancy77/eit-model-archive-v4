"""Atomic output with bounded Windows sharing retries, and source provenance."""
import json
import os
import time
from pathlib import Path
import torch
from comsol_v4.data_v6 import file_hash


def replace(source, dest):
    for attempt in range(101):
        try:
            os.replace(source, dest)
            return
        except PermissionError:
            if attempt == 100:
                raise
            time.sleep(.05)


def write_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix+".tmp")
    temp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    replace(temp, path)


def save_checkpoint(path, obj):
    path = Path(path)
    temp = path.with_suffix(".tmp.pt")
    torch.save(obj, temp)
    replace(temp, path)


def sources():
    project = Path(__file__).resolve().parents[1]
    paths = list((project/"comsol_feedback_loop").glob("*.py"))
    for folder in ("comsol_v4", "comsol_feedback"):
        paths.extend((project/folder).glob("*.py"))
    paths.append(project/"pytorch_eit/topology_residual_net.py")
    return {str(p.relative_to(project)).replace("\\", "/"): file_hash(p) for p in sorted(paths)}


def check_sources(expected):
    if sources() != expected:
        raise RuntimeError("Source changed since protocol freeze. Do not mix experiments.")
