"""V4 -> [fresh nonlinear FEM -> residual/adjoint -> update] x K.

All measured voltages remain fixed. Only homogeneous-reference FEM solutions
are cached. No case-dependent prediction, residual, or hint is cached.
The primary path is differentiable through each FEM solve and update. Adjoint
hints are freshly computed, but stop-gradient (no second-order FEM derivative).
"""
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from comsol_feedback.fem import EPS0, forward_voltage
from comsol_feedback.model import FeedbackRefiner, loss as reconstruction_loss
from comsol_v4.features import measurement_mask
from comsol_v4.losses import compute_loss


class DynamicPhysics(nn.Module):
    def __init__(self, solver):
        super().__init__()
        self.solver = solver
        self.register_buffer("valid", torch.tensor(measurement_mask()))
        self.register_buffer("omega_eps", torch.tensor(
            [2*np.pi*10000*EPS0, 2*np.pi*50000*EPS0], dtype=torch.float64)[None, :, None, None])
        self.evaluations = 0

    def forward(self, state, observed, background, reference, hints=True):
        # Need a local gradient for adjoint features even during no_grad inference.
        track = torch.is_grad_enabled()
        with torch.enable_grad():
            gamma = state["sigma"].double() + 1j*self.omega_eps*state["eps_r"].double()
            if not gamma.requires_grad:
                gamma = gamma.detach().requires_grad_(True)
            voltage = forward_voltage(gamma, self.solver)
            self.evaluations += 1
            # Match independent-FEM background to the measured reference.
            pred = voltage - reference + background
            q = lambda x: x-torch.roll(x, -1, -1)
            qb = q(background)
            rms = (qb.abs().square()[..., self.valid].mean(-1)).sqrt()[..., None, None]
            scale = qb.conj()/(qb.abs().square()+(.01*rms).square())*self.valid
            residual = (q(observed)-q(pred))*scale
            per_frequency = residual.abs().square()[..., self.valid].mean(-1)
            hint = None
            if hints:
                grad, = torch.autograd.grad(per_frequency.sum()/2, gamma,
                                            retain_graph=track, create_graph=False)
                h = torch.cat((-grad.real*state["sigma"].detach(),
                               -grad.imag*self.omega_eps*state["eps_r"].detach()), 1).detach()
                fv = torch.as_tensor(self.solver.fov, device=h.device)
                norm = torch.quantile(h[..., fv].abs(), .99, dim=-1).clamp_min(1e-12)
                hint = (h/norm[..., None, None]).clamp(-5, 5).float()
            packed = torch.cat((residual.real, residual.imag), 1).float()
            result = {"residual": packed, "hint": hint, "voltage": pred,
                      "voltage_mse": per_frequency}
        if not track:
            result = {k: v.detach() if torch.is_tensor(v) else v for k, v in result.items()}
        return result


class ClosedLoopEIT(nn.Module):
    def __init__(self, initial, solver, rounds=3, base=24):
        super().__init__()
        if rounds < 2:
            raise ValueError("This multi-round experiment requires K >= 2")
        self.initial = initial
        self.rounds = rounds
        self.physics = DynamicPhysics(solver)
        self.refiner = FeedbackRefiner(solver.fov, base=base, feedback=True)
        # Expose the existing material head output without editing historical V4.
        self._raw_material = None
        self.initial.material_head.register_forward_hook(self._capture_material)

    def _capture_material(self, _module, _args, output):
        self._raw_material = output

    def initial_state(self, features):
        out = self.initial(features)
        raw = self._raw_material
        self._raw_material = None
        probs = out["base_probabilities"][:, 1:]
        state = {"fg": out["foreground_probability"],
                 "conditional": probs/probs.sum(1, keepdim=True).clamp_min(1e-7),
                 "sigma": out["sigma"], "eps_r": out["eps_r"],
                 "lesion_sigma": F.softplus(raw[:, :2])+1e-6,
                 "lesion_eps": (F.softplus(raw[:, 2:])+1e-6)*10000,
                 "background_sigma": out["background_sigma"],
                 "background_eps": out["background_eps_r"]}
        return state, out

    def forward(self, features, observed, background, reference, trace=False):
        # Explicit measurement-only signature: no labels/target arguments.
        state, initial = self.initial_state(features)
        stages, history, residuals = [], [], []
        for iteration in range(self.rounds):
            physical = self.physics(state, observed, background, reference)
            if trace:
                history.append({"iteration": iteration,
                                "sigma": state["sigma"].detach().clone(),
                                "eps_r": state["eps_r"].detach().clone(),
                                "residual": physical["residual"].detach().clone(),
                                "voltage": physical["voltage"].detach().clone()})
            residuals.append(physical["voltage_mse"])
            state = self.refiner({**state, "features": features,
                                  "residual": physical["residual"], "hint": physical["hint"]})
            stages.append(state)
        final = self.physics(state, observed, background, reference, hints=False)
        residuals.append(final["voltage_mse"])
        return {**state, "initial": initial, "stages": stages,
                "voltage_mse_by_round": torch.stack(residuals, 1),
                "predicted_voltage": final["voltage"], "trace": history}


def objective(out, target, fov):
    """Final supervision, intermediate supervision, V4 auxiliaries, FEM loss."""
    initial_fg = out["initial"]["foreground_probability"]
    totals, scores = [], []
    for stage in out["stages"]:
        total, score = reconstruction_loss(stage, {"target": target, "fg": initial_fg}, fov)
        totals.append(total)
        scores.append(score)
    auxiliary, _ = compute_loss(out["initial"], target, fov)
    physics = out["voltage_mse_by_round"][:, 1:].mean()
    total = totals[-1]+.2*torch.stack(totals[:-1]).mean()+.2*auxiliary+.1*physics
    # Same image objective as before; test outcomes never select the checkpoint.
    return total, scores[-1], physics
