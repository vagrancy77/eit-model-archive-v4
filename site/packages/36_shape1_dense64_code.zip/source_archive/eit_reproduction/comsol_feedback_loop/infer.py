"""Label-free single-case inference using the SAME K=3 closed-loop forward."""
import argparse
import json
from pathlib import Path
import numpy as np
import torch
from comsol_v4.data_v6 import read_measurements, file_hash
from comsol_v4.features import calibrated_features
from comsol_v4.train import load_checkpoint
from comsol_v4.paper_common import configure_runtime
from comsol_feedback.verify import background_parameters
from comsol_feedback.fem import TerminalFEM
from .model import ClosedLoopEIT
from .io import check_sources


def reconstruct(root, case):
    root, case = Path(root), Path(case)
    p = json.loads((root/"protocol.json").read_text(encoding="utf-8"))
    check_sources(p["source_hashes"])
    done = json.loads((root/"training_complete.json").read_text())
    if done["protocol_sha256"] != file_hash(root/"protocol.json") or done["checkpoint_sha256"] != file_hash(root/"best.pt"):
        raise ValueError("Checkpoint/protocol integrity mismatch")
    if p["baseline_sha256"] != file_hash(p["baseline_checkpoint"]):
        raise ValueError("Original V4 changed")
    configure_runtime(p["seed"])
    base, norm, _, original = load_checkpoint(p["baseline_checkpoint"], torch.device("cuda"))
    v, b, _, freq = read_measurements(case)
    # Only extract background metadata, never segmentation/conductivity labels.
    with np.load(case, allow_pickle=False) as z:
        params = json.loads(z["parameters_json"].item()) if "parameters_json" in z else None
    if params is None:
        params = json.loads((case.parent/"case_parameters.json").read_text(encoding="utf-8"))
    known = background_parameters(params)
    solver = TerminalFEM(original["x"].numpy(), original["y"].numpy(), original["fov"].numpy(),
                         spacing=p["fem_spacing_m"])
    reference = np.stack([solver.solve(np.full((64, 64), g))[0] for g in known])
    model = ClosedLoopEIT(base, solver, rounds=p["K"], base=p["refiner_base"]).cuda()
    ck = torch.load(root/"best.pt", map_location="cpu", weights_only=True)
    if ck["protocol_sha256"] != file_hash(root/"protocol.json"):
        raise ValueError("Internal checkpoint provenance mismatch")
    model.load_state_dict(ck["model"])
    model.eval()
    def tensor(a):
        return torch.as_tensor(a)[None].cuda()
    with torch.no_grad():
        out = model(tensor(norm(calibrated_features(v, b))), tensor(v), tensor(b), tensor(reference))
    result = {key: out[key][0].cpu().numpy() for key in
              ("foreground_probability", "probabilities", "sigma", "eps_r",
               "predicted_voltage", "voltage_mse_by_round")}
    result.update(round_fg=np.stack([s["fg"][0].cpu().numpy() for s in out["stages"]]),
                  measured_voltage=v, background_voltage=b, frequencies_hz=freq,
                  x=original["x"].numpy(), y=original["y"].numpy(), valid_mask=original["fov"].numpy(),
                  metadata_json=np.array(json.dumps({"K": p["K"], "labels_used_as_input": False,
                                                    "protocol_sha256": file_hash(root/"protocol.json")})))
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--input-npz", required=True)
    parser.add_argument("--output", type=Path, required=True)
    a = parser.parse_args()
    if a.output.exists():
        raise FileExistsError(a.output)
    result = reconstruct(a.root, a.input_npz)
    a.output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(a.output, **result)
