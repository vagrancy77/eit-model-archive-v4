# 面向不确定超声先验的配准鲁棒与置信度感知 EIT 重建

## 摘要

超声引导电阻抗成像（electrical impedance tomography，EIT）能够利用超声提供的结构信息改善病灶定位，但现有方法通常默认超声分割准确、跨模态配准无误且先验始终可信。该假设在真实采集环境中容易失效：超声图像可能出现模糊、分割缺失、假阳性以及与 EIT 坐标系之间的平移和旋转误差。本文提出一种配准鲁棒、置信度感知的超声引导 EIT 重建网络。网络以物理模型生成的 EIT 基线重建和电压特征为主分支，以超声图像为辅助分支；通过受限仿射空间变换学习小范围超声—EIT 配准，并在多尺度融合层预测空间置信度图。当超声特征与 EIT 结构不一致时，置信度门控抑制超声注入，使网络自动回退到 EIT 分支。训练阶段随机加入平移、旋转、模糊、假病灶和超声模态 dropout，以模拟不完美先验。

在独立生成的 2048 例 v3 CEM 仿真数据上（307 例测试样本），最终统一评估表明：在 7 种受损先验条件下，robust 模型的平均 relative L2 从 0.12947 降至 0.12870，MAE 从 0.05070 降至 0.04605；在平移、旋转和缺失先验条件下改善最明显，而在模糊与假阳性条件下 relative L2 并不总是单调下降，但 MAE 仍保持更低。连续 0–20 px 平移和 0–20° 旋转应力测试显示，鲁棒模型曲线更平滑，baseline 更容易退化。confidence map 对 clean vs corrupted prior 的 AUROC 为 0.664，但与 per-sample MAE 和 relative L2 的 Pearson 相关接近 0，因此更适合作为 prior-reliability 软门控，而不是已充分校准的不确定性估计。公开真实 US-EIT 数据的伪标签检查仍显示合成—真实域差异，因此本文结论限定为“在不完美超声先验下提高仿真域的性能保持能力”，不将伪标签结果解释为临床精度。

**关键词：** 电阻抗成像；超声先验；不确定性建模；配准误差；深度学习；完整电极模型

## 1. 引言

EIT 通过边界电流和电压反演内部电导率分布，具有无辐射、低成本和可连续监测等优点，但其逆问题严重病态，重建结果容易受到噪声、模型误差和电极接触条件影响。深度神经网络可以从大量仿真或实验数据中学习非线性逆映射，但单模态网络容易产生过度平滑、位置漂移和对训练分布的依赖。

超声图像提供较高空间分辨率的组织边界，因此自然适合作为 EIT 的结构先验。然而，“直接拼接超声图像”并没有解决先验可靠性问题。真实场景中的超声并不总是与 EIT 同步采集，也不保证分割边界准确；如果以硬 mask 约束重建，错误先验会导致病灶被强制移动、误删或错误添加。

本文的研究问题是：**当超声先验不完美时，如何让 EIT 网络在利用结构信息的同时避免被错误先验主导？**

本文的主要贡献如下：

1. 提出一个面向不确定超声先验的 EIT 重建框架，将超声作为可抑制的辅助信息，而非绝对约束；
2. 引入有边界的仿射配准模块和多尺度置信度门控，实现超声—EIT 配准误差下的结构融合与 EIT fallback；
3. 构建包含受控超声退化的 CEM 多模态实验协议，并通过三随机种子、独立 phantom 测试集、连续应力曲线和模块消融验证方法；
4. 对公开真实 US-EIT 数据进行域外检查，明确当前方法的适用边界和真实部署中的主要瓶颈。

## 2. 方法

### 2.1 CEM 正问题和物理 EIT 输入

在二维域 \(\Omega\) 中，电势 \(u\) 满足

\[
\nabla\cdot(\sigma\nabla u)=0,
\]

其中 \(\sigma(x)\) 为电导率。有限宽度电极采用完整电极模型（complete electrode model，CEM）：

\[
u+z_l\sigma\frac{\partial u}{\partial n}=U_l,
\qquad
\int_{e_l}\sigma\frac{\partial u}{\partial n}\,ds=I_l,
\]

其中 \(z_l\) 为接触阻抗，\(U_l\) 为电极电压，\(I_l\) 为激励电流。数据生成采用 16 电极、208 个测量通道、正问题细网格和逆问题粗网格，以避免 inverse crime。网络输入包括：

- 由线性 Tikhonov 重建得到的 EIT 基线图 \(x_{EIT}\)；
- 归一化电压特征 \(v\in\mathbb{R}^{208}\)；
- 超声 proxy 图像 \(x_{US}\)。

### 2.2 共享物理编码器和电压条件化

EIT 和超声分别经过四尺度卷积编码器。深层特征通过电压条件化模块进行 FiLM 调制：

\[
z' = z\odot(1+\alpha\tanh(\gamma(v))) + \beta\tanh(\eta(v)).
\]

该设计使网络不会只依赖图像形状，也能利用原始边界电压中的物理信息。

### 2.3 受限超声—EIT 配准

超声首先输入轻量空间变换网络，预测平移、旋转和尺度参数：

\[
\theta =
\begin{bmatrix}
s\cos\phi & -s\sin\phi & t_x\\
s\sin\phi & s\cos\phi & t_y
\end{bmatrix}.
\]

参数通过 \(\tanh\) 限制在小范围内，并从单位变换初始化。对超声图像进行可微 warp：

\[
\tilde{x}_{US}=\operatorname{Warp}(x_{US};\theta).
\]

训练中加入单位变换正则项 \(\mathcal{L}_{reg}=\|\theta-I\|_2^2\)，避免在没有充分证据时产生过大的形变。

### 2.4 置信度感知融合和 EIT fallback

在每一个尺度，网络根据 EIT 和超声特征预测置信度图 \(R_k(x)\in[0,1]\)：

\[
R_k=\operatorname{sigmoid}(g_k([f_{EIT,k},f_{US,k}])).
\]

融合形式为

\[
f_k^{fusion}=h_k\left(f_{EIT,k}+a\,R_k\,G_k\,P_k(f_{US,k})\right),
\]

其中 \(G_k\) 是特征门控，\(a\) 是超声可用性变量。当超声缺失或不可靠时，\(aR_k\) 降低，网络保留 EIT 分支，这对应

\[
M_{effective}=R M_{US}+(1-R)M_{EIT}.
\]

输出电导率通过 sigmoid 约束到正值范围：

\[
\hat{\sigma}=0.05+2.95\,\operatorname{sigmoid}(r+\operatorname{logit}(x_{EIT})).
\]

### 2.5 训练目标

总损失为

\[
\mathcal{L}=\mathcal{L}_{image}+0.20\mathcal{L}_{grad}+0.15\mathcal{L}_{corr}
 +0.08\mathcal{L}_{seg}+0.02\mathcal{L}_{data}+0.02\mathcal{L}_{reg}.
\]

其中包括 masked L1、梯度一致性、相关性损失、病灶分割 Dice-BCE、电压数据一致性和配准正则。训练时随机加入超声平移、旋转、模糊、假病灶与 modality dropout。

## 3. 实验设计

### 3.1 数据集

训练数据为 `datasets/multimodal_cem_v1.npz`，共 1024 例，按 70%/15%/15% 划分。每个 phantom 包含 1–4 个随机椭圆病灶、非线性 CEM 电压、线性重建、真值电导率和几何一致的超声 proxy。

为检验独立分布泛化，另生成 `datasets/multimodal_cem_v2.npz`：2048 个新 phantom，随机种子不同，SNR 范围改为 30–60 dB，测试集包含 307 例。

最终定稿实验进一步使用 `datasets/synthetic_cem_v3.npz` 和 `datasets/multimodal_cem_v3.npz`。该版本重新生成完全独立的 CEM phantom，并把病灶从简单椭圆扩展到 ellipse、circle、rectangle、triangle 和 capsule，允许更多病灶数量、位置变化和噪声等级；测试阶段统一加入平移、旋转、缩放、局部形变、超声缺失、模糊和假阳性等 stress 条件。v3 测试集包含 307 例，用于统一比较 EIT-only、baseline、hard constraint、soft constraint 和 robust 模型，避免训练/测试分布过于相似造成虚高结果。

真实域外数据来自 Sagar 等公开 US-EIT Zenodo 数据（DOI: 10.5281/zenodo.19558489）。该数据只有一张共享超声图，作者 GN 图作为 pseudo-label，因此只做定性和伪标签相关性检查。

### 3.2 对照方法

1. **Multimodal baseline：** 原始多模态 PyTorch 网络，使用 EIT、电压和超声直接融合；
2. **Robust full：** 受限配准 + confidence gate + EIT fallback；
3. **No registration：** 关闭空间配准，仅保留 confidence gate；
4. **No confidence：** 关闭置信度门控，仅保留配准；
5. EIT-only 分支作为缺失超声的内部对照。

### 3.3 评价指标

在圆形有效域内计算 Pearson-like spatial correlation、relative L2 和 MAE。所有主实验重复 3 个随机种子。鲁棒性测试包括：

- 平移：0、5、10、15、20 px；
- 旋转：0、5、10、15、20°；
- 模糊：1、3、5、7、9 像素核。

## 4. 结果

### 4.1 v1 三随机种子主结果

| 条件 | baseline corr | robust corr | baseline L2 | robust L2 | baseline MAE | robust MAE |
|---|---:|---:|---:|---:|---:|---:|
| clean | 0.97582 | 0.97355 ± 0.00011 | 0.10127 | 0.10606 ± 0.00027 | 0.03960 | 0.03607 ± 0.00017 |
| shift10px | 0.96670 | **0.97341 ± 0.00012** | 0.11969 | **0.10636 ± 0.00027** | 0.04738 | **0.03621 ± 0.00017** |
| rotate10deg | 0.97262 | **0.97351 ± 0.00011** | 0.10833 | **0.10614 ± 0.00028** | 0.04225 | **0.03610 ± 0.00017** |
| blur_sigma4 | 0.97438 | 0.97351 ± 0.00011 | 0.10430 | 0.10614 ± 0.00029 | 0.04055 | **0.03612 ± 0.00017** |
| false_positive | 0.97528 | 0.97357 ± 0.00012 | 0.10257 | 0.10603 ± 0.00029 | 0.04055 | **0.03603 ± 0.00016** |

五种条件平均 correlation 为 0.97296→0.97351，relative L2 为 0.10723→0.10614，MAE 为 0.04207→0.03610。只看四种受损超声条件，relative L2 为 0.10872→0.10617，MAE 为 0.04268→0.03611。

### 4.2 v2 独立 CEM 分布

| 指标 | baseline | robust |
|---|---:|---:|
| 五条件平均 correlation | 0.97283 | **0.97346** |
| 五条件平均 relative L2 | 0.10820 | **0.10703** |
| 五条件平均 MAE | 0.04284 | **0.03704** |
| 四种受损条件 relative L2 | 0.10982 | **0.10705** |
| 四种受损条件 MAE | 0.04352 | **0.03705** |

独立 v2 结果与 v1 方向一致，说明收益不是单纯来自固定测试划分。

### 4.2.1 配对 bootstrap

在 v2 的 307 个测试 phantom 上进行 2000 次配对 bootstrap。定义正值为 robust 相对于 baseline 的改善。10 px 平移条件下，correlation 改善为 0.00748（95% CI [0.00670, 0.00829]），relative L2 改善为 0.01425（95% CI [0.01290, 0.01563]），MAE 改善为 0.01157（95% CI [0.01076, 0.01238]）。10° 旋转条件下，relative L2 改善为 0.00262（95% CI [0.00145, 0.00376]），MAE 改善为 0.00586（95% CI [0.00518, 0.00655]）。clean 条件的 relative L2 置信区间为 [-0.00633, -0.00411]，定量说明鲁棒训练存在少量 clean 精度代价；这支持本文将方法定位为风险控制而不是无条件精度提升。

![配对 bootstrap](E:/Codex/eit_reproduction/outputs_registration_robust_bootstrap/paired_bootstrap.png)

### 4.3 连续应力测试

![连续应力曲线](E:/Codex/eit_reproduction/outputs_registration_robust_stress/stress_curves.png)

在独立 v2 数据上，baseline 平移 10 px 时 relative L2 达到 0.12147，旋转 20° 时达到 0.11595；robust 模型对应为 0.10721 和 0.10713。鲁棒模型的主要特征不是 clean 条件获得最大精度，而是在先验质量下降时保持相对稳定。

### 4.4 机制消融

| 变体 | 平均 correlation | 平均 relative L2 | 平均 MAE |
|---|---:|---:|---:|
| baseline | 0.97296 | 0.10723 | 0.04207 |
| robust full | **0.97357** | **0.10604** | 0.03612 |
| no registration | 0.97355 | 0.10611 | **0.03611** |
| no confidence | 0.97345 | 0.10627 | 0.03630 |

confidence gate 是主要贡献，registration 在当前扰动范围内提供较小但一致的 relative L2 改善。

### 4.5 公开真实 US-EIT 域外检查

公开 12 例数据没有逐帧真值，只能与作者 GN pseudo-label 比较：

- 原始 baseline：correlation 0.61797；
- robust fusion：0.60802；
- robust EIT-only：0.60455；
- robust 模型关闭 confidence：0.58573。

confidence gate 能缓解部分域差异，但没有超过 synthetic baseline。这一结果被作为失败边界报告，而非临床精度结论。

### 4.6 置信度可靠性分析

为了检查模型学到的 `confidence_map` 是否真的在反映先验可靠性，我们把 clean / shift / rotate / blur / false positive 五种 prior 条件展开到每个测试样本，并统计样本级 confidence、MAE 和 relative L2。结果如下：

| 条件 | n | Mean confidence | MAE | Relative L2 |
|---|---:|---:|---:|---:|
| clean | 307 | 0.30599 | 0.03698 | 0.10695 |
| shift10px | 307 | 0.30303 | 0.03719 | 0.10721 |
| rotate10deg | 307 | 0.30501 | 0.03703 | 0.10705 |
| blur_sigma4 | 307 | 0.29746 | 0.03708 | 0.10706 |
| false_positive | 307 | 0.31057 | 0.03686 | 0.10687 |

进一步看全体样本：clean-vs-corrupted AUROC = 0.59891，Pearson(confidence, MAE) = 0.31365，Pearson(confidence, relative L2) = 0.35384，selective MAE at 50% coverage = 0.04167，full-coverage MAE = 0.03703。

这说明当前 `confidence_map` 具有一定 prior-reliability 区分能力，但还没有达到“完全校准的误差预测器”水平。更稳妥的表述是：它能作为超声可信度的软门控信号，而不应被描述为已充分校准的绝对不确定性估计。

### 4.7 v3 独立测试集上的最终统一比较

最终方法学结论以 `outputs_diverse_method_suite` 为准。该实验在同一 307 例 v3 测试集上统一比较 EIT-only、baseline、hard constraint、soft constraint 和 robust 模型，并对 robust 的 3 个随机种子结果先做样本级平均，再进行 2000 次配对 bootstrap。结果显示，robust 不是“所有指标无条件最优”的模型，而是一个面向错误先验的风险控制模型：在 clean 条件下 baseline 的 relative L2 更低，但在受损先验整体上 robust 的 MAE 和 relative L2 更稳。

| 汇总范围 | baseline corr | robust corr | baseline L2 | robust L2 | baseline MAE | robust MAE |
|---|---:|---:|---:|---:|---:|---:|
| 全部 8 条件 | 0.96132 | 0.96125 | 0.12867 | 0.12868 | 0.05033 | **0.04604** |
| 7 种受损条件 | 0.96084 | **0.96124** | 0.12947 | **0.12870** | 0.05070 | **0.04605** |

代表性配对 bootstrap 结果如下，正值表示 robust 相对于 baseline 改善：

| 条件 | correlation 改善 | relative L2 改善 | MAE 改善 |
|---|---:|---:|---:|
| shift10px | 0.00720 [0.00631, 0.00822] | 0.01135 [0.01007, 0.01276] | 0.00996 [0.00917, 0.01073] |
| rotate10deg | 0.00111 [0.00054, 0.00173] | 0.00235 [0.00128, 0.00340] | 0.00471 [0.00407, 0.00530] |
| missing | 0.00110 [0.00057, 0.00167] | 0.00184 [0.00096, 0.00275] | 0.00447 [0.00386, 0.00505] |
| blur_sigma4 | -0.00135 [-0.00190, -0.00084] | -0.00221 [-0.00313, -0.00124] | 0.00346 [0.00292, 0.00396] |
| false_positive | -0.00271 [-0.00327, -0.00217] | -0.00435 [-0.00536, -0.00333] | 0.00276 [0.00216, 0.00332] |

v3 的 confidence 可靠性分析也更保守：clean-vs-corrupted AUROC = 0.66382，Pearson(confidence, MAE) = 0.00929，Pearson(confidence, relative L2) = 0.01018，selective MAE at 50% coverage = 0.05056，full-coverage MAE = 0.04604。这说明当前 confidence map 能识别部分先验可用性变化，尤其是缺失先验，但还不能作为连续误差大小的校准预测器。

## 5. 讨论

### 5.1 为什么鲁棒模型 clean 指标略低

鲁棒训练主动引入了超声损坏和模态 dropout，模型被优化为在“超声可信”和“超声错误”之间折中。因此 clean 条件下 baseline 的 relative L2 更低是合理的；鲁棒模型牺牲少量峰值精度，换取对先验损坏的性能保持。

### 5.2 创新点的准确表述

本文创新不是简单地“把超声拼接到 EIT 网络”，而是：

> 将超声视为可能不可靠的结构证据，通过可学习置信度控制其影响，并在跨模态不一致时保留 EIT 物理分支。

配准模块是辅助机制；当前消融表明 confidence-aware fallback 应作为主创新，registration-robust 作为增强项。

### 5.3 真实数据域差异

合成 proxy 超声由电导率边缘渲染而来，不包含真实声学传播、探头姿态、散斑统计和成像设备响应。公开真实数据还存在电极协议、幅值标定和超声配准不一致。因此 synthetic → real 的差异是当前最重要的限制。

## 6. 局限性和投稿前必要工作

1. 当前超声不是物理声学仿真，也不是逐帧实测 US；
2. v1/v2 虽然独立，但仍来自同一 CEM 几何和同一随机 phantom 生成器；
3. 公开真实数据只有 12 例且 GN 是伪标签；
4. 还需要多几何、多接触阻抗、多噪声和多病灶数量的 forward-model shift；
5. 置信度图已经补做 calibration、AUROC 和 risk-coverage 分析，但当前结果仍显示其更像 prior-reliability gate，而不是完全校准的误差预测器；
6. 最终投稿应加入真实同步 US-EIT 数据或明确的跨模态配准实验。

## 7. 结论

本文完成了一个从 CEM 正问题、物理 EIT 基线、超声先验、鲁棒神经网络、损坏先验应力测试、独立数据泛化到真实公开域外检查的完整实验闭环。结果支持“置信度感知超声先验能够提高 EIT 在不完美先验下的稳定性”这一论文假设，但不支持“当前方法已经在真实临床数据上全面优于 baseline”。因此，本文当前可作为方法学论文初稿和后续真实数据研究的实验基础。

## 8. 复现实验入口

工程根目录为 `E:/Codex/eit_reproduction`。关键命令：

```bash
python train_registration_robust_multimodal.py --epochs 20 --batch-size 32 --base-channels 24 --output-dir outputs_registration_robust_multimodal_warmstart
python evaluate_registration_robust_crossdomain.py
python stress_test_registration_robust.py
python aggregate_registration_robust_runs.py --run outputs_registration_robust_multimodal_warm_seed1 --run outputs_registration_robust_multimodal_warm_seed2 --run outputs_registration_robust_multimodal_warm_seed3 --output-dir outputs_registration_robust_multimodal_multiseed
python infer_public_us_eit_robust.py
```

## 9. 数据和软件资源

1. Sagar 等公开 US-EIT 数据，Zenodo DOI: [10.5281/zenodo.19558489](https://doi.org/10.5281/zenodo.19558489)。
2. KTC2023 v3 EIT 数据，Zenodo DOI: [10.5281/zenodo.10986692](https://doi.org/10.5281/zenodo.10986692)。
3. Edinburgh mfEIT Dataset，DataShare DOI: [10.7488/ds/3464](https://doi.org/10.7488/ds/3464)。
4. GN4IP 公开代码与权重：[github.com/wherzberg/GN4IP](https://github.com/wherzberg/GN4IP)。
5. 本文全部实现、配置、checkpoint、指标 JSON 和图像均位于 `E:/Codex/eit_reproduction`。
