from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from torch.nn import functional as F

from pytorch_eit.models import RegistrationRobustMultiModalEITNet


def correlation(prediction: np.ndarray, target: np.ndarray, mask: np.ndarray) -> float:
    p = prediction[:, mask]
    t = target[:, mask]
    p = p - p.mean(axis=1, keepdims=True)
    t = t - t.mean(axis=1, keepdims=True)
    denominator = np.linalg.norm(p, axis=1) * np.linalg.norm(t, axis=1)
    values = np.divide(np.sum(p * t, axis=1), denominator, out=np.zeros_like(denominator), where=denominator > 1e-8)
    return float(np.mean(values))


def main() -> None:
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Run robust US-EIT model on the public domain-out dataset.")
    parser.add_argument("--data", type=Path, default=root / "datasets" / "public_us_eit" / "public_us_eit_v1.npz")
    parser.add_argument("--checkpoint", type=Path, default=root / "outputs_registration_robust_multimodal_warmstart" / "model.pt")
    parser.add_argument("--output-dir", type=Path, default=root / "outputs_public_us_eit_robust")
    parser.add_argument("--disable-registration", action="store_true")
    parser.add_argument("--disable-confidence", action="store_true")
    parser.add_argument("--cpu", action="store_true")
    args = parser.parse_args()
    device = torch.device("cpu" if args.cpu or not torch.cuda.is_available() else "cuda")
    checkpoint = torch.load(args.checkpoint, map_location=device, weights_only=False)
    model = RegistrationRobustMultiModalEITNet(
        voltage_dim=int(checkpoint.get("voltage_dim", 208)),
        base_channels=int(checkpoint["base_channels"]),
        use_registration=not args.disable_registration,
        use_confidence=not args.disable_confidence,
    ).to(device)
    model.load_state_dict(checkpoint["model_state"], strict=False)
    model.eval()
    data = np.load(args.data, allow_pickle=True)
    voltage_complex = np.asarray(data["voltage_features"], dtype=np.float32)
    voltage_real, voltage_imag = voltage_complex[:, :208], voltage_complex[:, 208:]
    voltage = np.sqrt(voltage_real * voltage_real + voltage_imag * voltage_imag)
    metadata = json.loads(str(data["metadata_json"].item()))
    voltage = np.asarray([row / max(float(item["voltage_vpp"]), 1.0) for row, item in zip(voltage, metadata, strict=True)], dtype=np.float32)
    voltage = (voltage - np.asarray(checkpoint["voltage_mean"], dtype=np.float32)) / np.asarray(checkpoint["voltage_std"], dtype=np.float32)
    baseline = torch.from_numpy(np.asarray(data["baseline_tikhonov"], dtype=np.float32)[:, None])
    pseudo_target = torch.from_numpy(np.asarray(data["pseudo_target_gn"], dtype=np.float32)[:, None])
    ultrasound = torch.from_numpy(np.asarray(data["ultrasound"], dtype=np.float32))
    baseline = F.interpolate(baseline, size=(64, 64), mode="bilinear", align_corners=False)
    pseudo_target = F.interpolate(pseudo_target, size=(64, 64), mode="bilinear", align_corners=False)
    voltage_tensor = torch.from_numpy(voltage)
    availability = torch.ones((baseline.shape[0], 1), dtype=torch.float32)
    with torch.no_grad():
        output = model(baseline.to(device), voltage_tensor.to(device), ultrasound.to(device), availability.to(device))
        prediction = output["reconstruction"].cpu().numpy()[:, 0]
        eit_only = model(baseline.to(device), voltage_tensor.to(device), ultrasound.to(device), torch.zeros_like(availability).to(device))["reconstruction"].cpu().numpy()[:, 0]
        confidence = output["confidence_map"].cpu().numpy()[:, 0]
    target = pseudo_target.numpy()[:, 0]
    yy, xx = np.mgrid[0:64, 0:64]
    mask = (xx - 31.5) ** 2 + (yy - 31.5) ** 2 <= 30.0 ** 2
    summary = {
        "source": str(args.data.resolve()),
        "checkpoint": str(args.checkpoint.resolve()),
        "warning": "pseudo_target_gn is the public author's GN reconstruction; this is domain-out evidence, not ground-truth clinical accuracy",
        "robust_fusion_correlation_to_public_gn": correlation(prediction, target, mask),
        "robust_eit_only_correlation_to_public_gn": correlation(eit_only, target, mask),
        "mean_confidence": float(confidence.mean()),
        "samples": len(metadata),
        "device": str(device),
    }
    args.output_dir.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(args.output_dir / "predictions.npz", prediction=prediction, eit_only=eit_only, baseline=baseline.numpy()[:, 0], pseudo_target=target, ultrasound=ultrasound.numpy()[:, 0], confidence=confidence)
    (args.output_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    count = min(4, prediction.shape[0])
    figure, axes = plt.subplots(count, 5, figsize=(15, 3 * count), squeeze=False, constrained_layout=True)
    for row in range(count):
        fields = [target[row], baseline.numpy()[row, 0], prediction[row], eit_only[row], confidence[row]]
        titles = ["public GN (pseudo-label)", "Tikhonov baseline", "robust fusion", "robust EIT-only", "confidence"]
        for column, (field, title) in enumerate(zip(fields, titles, strict=True)):
            axes[row, column].imshow(field, cmap="magma" if column == 4 else "viridis")
            axes[row, column].set_title(f"{metadata[row]['sample']}\n{title}", fontsize=8)
            axes[row, column].axis("off")
    figure.savefig(args.output_dir / "examples.png", dpi=160)
    plt.close(figure)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
