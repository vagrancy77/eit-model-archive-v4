"""Compare reconstructed multi-frequency curves inside each known lesion."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader

from pytorch_eit.multifrequency import (
    InstanceGeometryDispersionAnomalyNet,
    JointFrequencyAnomalyNet,
    SharedGeometryFrequencyContrastAnomalyNet,
)
from train_edinburgh_mfeit import EdinburghDataset


def load_model(path: Path, device: torch.device) -> tuple[str, nn.Module]:
    checkpoint = torch.load(path, map_location=device, weights_only=False)
    name = str(checkpoint["model"])
    config = checkpoint["model_config"]
    common = {
        "voltage_dim": int(config["voltage_dim"]),
        "num_frequencies": int(config["num_frequencies"]),
        "latent_dim": int(config["latent_dim"]),
        "base_channels": int(config["base_channels"]),
        "pixels": int(config["pixels"]),
        "coordinate_min": 1.0,
        "coordinate_max": 4.0,
    }
    if name == "joint":
        model: nn.Module = JointFrequencyAnomalyNet(**common)
    elif name == "factorized":
        model = SharedGeometryFrequencyContrastAnomalyNet(**common)
    elif name == "instance_dispersion":
        model = InstanceGeometryDispersionAnomalyNet(max_instances=int(config.get("max_instances", 3)), **common)
    else:
        raise ValueError(f"unsupported model checkpoint: {name}")
    model.load_state_dict(checkpoint["model_state"])
    return name, model.to(device).eval()


def forward(name: str, model: nn.Module, voltage: torch.Tensor, coordinate: torch.Tensor) -> tuple[torch.Tensor, dict[str, torch.Tensor] | None]:
    if name == "joint":
        return model(voltage, coordinate), None
    output = model(voltage, coordinate, return_auxiliary=True)
    return output["reconstruction"], output


def main() -> None:
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Evaluate lesion-level spectral curves on Edinburgh mfEIT.")
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "datasets" / "public" / "edinburgh_mfeit" / "edinburgh_mfeit_manifest_v1.npz",
    )
    parser.add_argument("--joint", type=Path, required=True)
    parser.add_argument("--factorized", type=Path, required=True)
    parser.add_argument("--instance-dispersion", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--max-test-samples", type=int, default=None)
    parser.add_argument("--cpu", action="store_true")
    arguments = parser.parse_args()

    manifest = np.load(arguments.manifest)
    source = Path(str(np.asarray(manifest["source_root"]).reshape(()).item()))
    dataset = EdinburghDataset(
        source,
        np.asarray(manifest["test_case"]),
        np.asarray(manifest["test_index"]),
        np.asarray(manifest["voltage_mean"], dtype=np.float32),
        np.asarray(manifest["voltage_std"], dtype=np.float32),
        arguments.max_test_samples,
    )
    device = torch.device("cpu" if arguments.cpu or not torch.cuda.is_available() else "cuda")
    loader = DataLoader(dataset, batch_size=arguments.batch_size, shuffle=False, pin_memory=device.type == "cuda")
    coordinate = torch.from_numpy(np.asarray(manifest["frequency_coordinate"], dtype=np.float32)).to(device)[None]
    checkpoints = [arguments.joint, arguments.factorized, arguments.instance_dispersion]
    models = dict(load_model(path, device) for path in checkpoints)
    rows: list[dict[str, object]] = []

    with torch.no_grad():
        for voltage, _, masks, spectra, valid, cases, indices in loader:
            voltage = voltage.to(device, non_blocking=True)
            masks_np = masks.numpy().astype(bool)
            spectra_np = spectra.numpy()
            valid_np = valid.numpy().astype(bool)
            for name, model in models.items():
                reconstruction, _ = forward(name, model, voltage, coordinate.expand(voltage.shape[0], -1))
                reconstruction_np = reconstruction[:, :, 0].cpu().numpy()
                for batch in range(voltage.shape[0]):
                    for slot in np.flatnonzero(valid_np[batch]):
                        lesion = masks_np[batch, slot]
                        reference = spectra_np[batch, slot]
                        reconstructed = reconstruction_np[batch][:, lesion].mean(axis=1)
                        row: dict[str, object] = {
                            "model": name,
                            "case": int(cases[batch]),
                            "sample_index": int(indices[batch]),
                            "lesion_slot": int(slot + 1),
                            "target_region_spectrum_mae": float(np.mean(np.abs(reconstructed - reference))),
                        }
                        for frequency in range(4):
                            row[f"target_f{frequency + 1}"] = float(reference[frequency])
                            row[f"reconstruction_f{frequency + 1}"] = float(reconstructed[frequency])
                            row[f"absolute_error_f{frequency + 1}"] = float(abs(reconstructed[frequency] - reference[frequency]))
                        rows.append(row)

    arguments.output_dir.mkdir(parents=True, exist_ok=True)
    with (arguments.output_dir / "lesion_spectrum_rows.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        fieldnames = list(dict.fromkeys(key for row in rows for key in row))
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    summary: dict[str, dict[str, float]] = {}
    for name in models:
        model_rows = [row for row in rows if row["model"] == name]
        summary[name] = {
            "target_region_spectrum_mae": float(np.mean([row["target_region_spectrum_mae"] for row in model_rows])),
            "per_lesion_curves": float(len(model_rows)),
        }
    result = {"test_samples": len(dataset), "device": str(device), "models": summary}
    with (arguments.output_dir / "lesion_spectrum_summary.json").open("w", encoding="utf-8") as handle:
        json.dump(result, handle, ensure_ascii=False, indent=2)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
