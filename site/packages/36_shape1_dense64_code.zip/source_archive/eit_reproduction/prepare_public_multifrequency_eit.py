"""Create strictly paired 10/50-kHz samples from the public US--EIT release.

This is deliberately a small, transparent adapter.  It does *not* turn the
author's GN reconstructions into conductivity ground truth: ``targets`` in the
output remain clearly labelled as GN pseudo-targets.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import zoom


def resize_field(field: np.ndarray, pixels: int) -> np.ndarray:
    """Resize an EIT reconstruction while retaining its background value."""

    image = np.asarray(field, dtype=np.float32)
    if image.ndim != 2:
        raise ValueError(f"expected a two-dimensional reconstruction, got {image.shape}")
    scale = (pixels / image.shape[0], pixels / image.shape[1])
    result = zoom(image, scale, order=1, prefilter=False)
    if result.shape != (pixels, pixels):  # protects against rare rounding differences
        result = result[:pixels, :pixels]
        if result.shape != (pixels, pixels):
            raise RuntimeError(f"unexpected resized shape {result.shape}")
    return result.astype(np.float32)


def circular_mask(pixels: int) -> np.ndarray:
    coordinate = np.linspace(-1.0 + 1.0 / pixels, 1.0 - 1.0 / pixels, pixels)
    x, y = np.meshgrid(coordinate, coordinate, indexing="xy")
    return (x * x + y * y <= 1.0).astype(np.float32)


def main() -> None:
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Pair 10- and 50-kHz public EIT measurements.")
    parser.add_argument(
        "--input",
        type=Path,
        default=root / "datasets" / "public_us_eit" / "public_us_eit_v1.npz",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=root / "datasets" / "public_us_eit" / "public_us_eit_multifrequency_v1.npz",
    )
    parser.add_argument("--pixels", type=int, default=64)
    arguments = parser.parse_args()
    if arguments.pixels < 16:
        raise ValueError("pixels must be at least 16")

    source = np.load(arguments.input)
    required = {"voltage_features", "baseline_tikhonov", "pseudo_target_gn", "metadata_json"}
    missing = required.difference(source.files)
    if missing:
        raise ValueError(f"input is missing required fields: {sorted(missing)}")
    metadata = json.loads(str(np.asarray(source["metadata_json"]).reshape(()).item()))
    if len(metadata) != source["voltage_features"].shape[0]:
        raise ValueError("metadata and measurement counts do not agree")

    lookup: dict[tuple[str, int, int], int] = {}
    for index, item in enumerate(metadata):
        key = (str(item["layer"]), int(item["voltage_vpp"]), int(item["frequency_khz"]))
        if key in lookup:
            raise ValueError(f"duplicate sample key: {key}")
        lookup[key] = index

    layers = sorted({key[0] for key in lookup})
    amplitudes = sorted({key[1] for key in lookup})
    frequencies = np.asarray([10.0, 50.0], dtype=np.float32)
    pairs: list[tuple[str, int, list[int]]] = []
    for layer in layers:
        for voltage_vpp in amplitudes:
            indices = [lookup.get((layer, voltage_vpp, int(frequency))) for frequency in frequencies]
            if any(index is None for index in indices):
                raise ValueError(f"missing a 10/50-kHz partner for layer={layer}, voltage={voltage_vpp} Vpp")
            pairs.append((layer, voltage_vpp, [int(index) for index in indices]))
    if len(pairs) < 3:
        raise ValueError("at least three paired samples are required for grouped evaluation")

    source_indices = np.asarray([item[2] for item in pairs], dtype=np.int64)
    targets = np.asarray(source["pseudo_target_gn"], dtype=np.float32)[source_indices]
    baselines = np.asarray(source["baseline_tikhonov"], dtype=np.float32)[source_indices]
    target_grid = np.stack(
        [[resize_field(field, arguments.pixels) for field in pair] for pair in targets], axis=0
    ).astype(np.float32)
    baseline_grid = np.stack(
        [[resize_field(field, arguments.pixels) for field in pair] for pair in baselines], axis=0
    ).astype(np.float32)
    mask = circular_mask(arguments.pixels)
    # MATLAB's exterior is not a physical reconstruction domain.  Set it to the
    # nominal background so a network cannot benefit from this artificial border.
    target_grid[:, :, mask == 0] = 1.0
    baseline_grid[:, :, mask == 0] = 1.0

    pair_ids = [f"{layer}_{voltage_vpp}V" for layer, voltage_vpp, _ in pairs]
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        arguments.output,
        pair_voltages=np.asarray(source["voltage_features"], dtype=np.float32)[source_indices],
        pair_targets_gn=target_grid,
        pair_baselines_tikhonov=baseline_grid,
        frequency_khz=frequencies,
        layers=np.asarray([item[0] for item in pairs]),
        voltage_vpp=np.asarray([item[1] for item in pairs], dtype=np.int16),
        pair_ids=np.asarray(pair_ids),
        source_indices=source_indices,
        mask=mask,
        source_metadata_json=np.asarray(json.dumps(metadata, ensure_ascii=False)),
    )
    summary = {
        "source": "Zenodo 10.5281/zenodo.19558489, CC BY 4.0",
        "input": str(arguments.input.resolve()),
        "output": str(arguments.output.resolve()),
        "paired_samples": len(pairs),
        "pair_definition": "same layer and excitation amplitude; 10 kHz and 50 kHz measurements",
        "layers": layers,
        "voltage_vpp": amplitudes,
        "frequencies_khz": frequencies.tolist(),
        "voltage_shape": list(np.asarray(source["voltage_features"])[source_indices].shape),
        "image_shape": list(target_grid.shape),
        "target_status": "author GN reconstructions only; not independent conductivity ground truth",
        "permitted_conclusion": "paired pseudo-target fidelity and noise stability only",
        "not_permitted_conclusion": "true lesion/conductivity accuracy improvement",
    }
    with arguments.output.with_suffix(".json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
