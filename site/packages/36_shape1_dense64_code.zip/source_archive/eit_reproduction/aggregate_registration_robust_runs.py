from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def main() -> None:
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Aggregate robust multimodal EIT runs.")
    parser.add_argument("--run", action="append", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    summaries = [json.loads(path.joinpath("summary.json").read_text(encoding="utf-8")) for path in args.run]
    conditions = [item["condition"] for item in summaries[0]["robust_metrics"]]
    result: dict[str, object] = {"runs": [str(path.resolve()) for path in args.run], "conditions": conditions, "robust": {}, "baseline": {}}
    for method in ("robust_metrics", "baseline_metrics"):
        key = "robust" if method == "robust_metrics" else "baseline"
        for metric in ("correlation", "relative_l2", "mae", "mean_confidence"):
            condition_stats = {}
            for idx, condition in enumerate(conditions):
                values = [summary[method][idx][metric] for summary in summaries if summary[method] is not None and summary[method][idx][metric] is not None]
                condition_stats[condition] = {"mean": float(np.mean(values)) if values else None, "std": float(np.std(values, ddof=1)) if len(values) > 1 else 0.0 if values else None, "values": values}
            result[key][metric] = condition_stats
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    x = np.arange(len(conditions))
    figure, axes = plt.subplots(1, 3, figsize=(15, 4.5), constrained_layout=True)
    for ax, metric, title in zip(axes, ("correlation", "relative_l2", "mae"), ("Correlation ↑", "Relative L2 ↓", "MAE ↓"), strict=True):
        for method, color, label in (("baseline", "0.45", "baseline"), ("robust", "tab:blue", "warm-start robust")):
            stats = result[method][metric]
            means = [stats[c]["mean"] for c in conditions]
            stds = [stats[c]["std"] for c in conditions]
            offset = -0.16 if method == "baseline" else 0.16
            ax.errorbar(x + offset, means, yerr=stds, fmt="o-", capsize=3, color=color, label=label)
        ax.set_xticks(x, conditions, rotation=28, ha="right")
        ax.set_title(title)
        ax.grid(alpha=0.25)
        if metric == "correlation":
            ax.set_ylim(0.94, 0.99)
    axes[0].legend()
    figure.savefig(args.output_dir / "multiseed_metrics.png", dpi=180)
    plt.close(figure)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
