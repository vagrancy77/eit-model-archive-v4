from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import dolfinx
from mpi4py import MPI
import numpy as np

from fenicsx_backend import ArrayProtocol, FenicsxCEMForward, reconstruct_tikhonov


def parse_arguments() -> argparse.Namespace:
    project_root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(
        description=(
            "Re-run the saved EIT experiment with a DOLFINx-assembled "
            "complete electrode model."
        )
    )
    parser.add_argument(
        "--input",
        type=Path,
        default=project_root / "outputs" / "simulation_data.npz",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=project_root / "outputs_fenicsx",
    )
    parser.add_argument("--electrode-width", type=float, default=2.5 / 14.0)
    parser.add_argument("--contact-impedance", type=float, default=0.01)
    parser.add_argument("--current-amplitude", type=float, default=1.0)
    parser.add_argument("--background-conductivity", type=float, default=1.0)
    parser.add_argument("--snr-db", type=float, default=60.0)
    parser.add_argument("--seed", type=int, default=20260716)
    parser.add_argument("--lambda-reg", type=float, default=0.01)
    parser.add_argument("--jacobian-p", type=float, default=0.5)
    return parser.parse_args()


def relative_error(reference: np.ndarray, candidate: np.ndarray) -> float:
    denominator = np.linalg.norm(reference)
    if denominator == 0.0:
        return float(np.linalg.norm(candidate - reference))
    return float(np.linalg.norm(candidate - reference) / denominator)


def safe_correlation(first: np.ndarray, second: np.ndarray) -> float:
    if np.std(first) == 0.0 or np.std(second) == 0.0:
        return float("nan")
    return float(np.corrcoef(first, second)[0, 1])


def add_gaussian_noise_at_snr(
    signal: np.ndarray,
    snr_db: float,
    random_seed: int,
) -> tuple[np.ndarray, np.ndarray, float]:
    rng = np.random.default_rng(random_seed)
    raw_noise = rng.standard_normal(signal.shape)
    signal_norm = np.linalg.norm(signal)
    raw_norm = np.linalg.norm(raw_noise)
    if signal_norm == 0.0 or raw_norm == 0.0:
        raise ValueError("signal and generated noise must have non-zero norm")
    target_noise_norm = signal_norm / (10.0 ** (snr_db / 20.0))
    noise = raw_noise * (target_noise_norm / raw_norm)
    noisy = signal + noise
    actual_snr = float(20.0 * np.log10(signal_norm / np.linalg.norm(noise)))
    return noisy, noise, actual_snr


def save_outputs(
    output_dir: Path,
    arrays: dict[str, np.ndarray],
    summary: dict,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(output_dir / "fenicsx_results.npz", **arrays)
    with (output_dir / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)

    voltage_columns = [
        arrays["voltage_background"],
        arrays["voltage_clean"],
        arrays["voltage_noisy"],
        arrays["voltage_clean"] - arrays["voltage_background"],
        arrays["voltage_noisy"] - arrays["voltage_background"],
    ]
    with (output_dir / "voltages.csv").open(
        "w",
        newline="",
        encoding="utf-8",
    ) as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "index",
                "background",
                "clean",
                "noisy",
                "difference_clean",
                "difference_noisy",
            ]
        )
        for index, values in enumerate(zip(*voltage_columns, strict=True)):
            writer.writerow([index, *[float(value) for value in values]])


def main() -> None:
    arguments = parse_arguments()
    saved = np.load(arguments.input)
    protocol = ArrayProtocol(
        saved["excitation_matrix"],
        saved["measurement_matrix"],
    )

    print("[1/5] Building the DOLFINx forward CEM model...", flush=True)
    forward_nodes = saved["forward_nodes"]
    forward_electrode_positions = forward_nodes[
        saved["forward_electrode_nodes"]
    ]
    forward_solver = FenicsxCEMForward(
        nodes=forward_nodes,
        elements=saved["forward_elements"],
        electrode_positions=forward_electrode_positions,
        protocol=protocol,
        electrode_width=arguments.electrode_width,
        contact_impedance=arguments.contact_impedance,
        current_amplitude=arguments.current_amplitude,
    )

    print("[2/5] Solving background and heart-lung voltages...", flush=True)
    forward_background = forward_solver.solve_protocol(
        arguments.background_conductivity
    )
    forward_phantom = forward_solver.solve_protocol(
        saved["conductivity_true_forward"]
    )
    voltage_noisy, voltage_noise, actual_snr = add_gaussian_noise_at_snr(
        forward_phantom.measurements,
        arguments.snr_db,
        arguments.seed,
    )

    print("[3/5] Building the independent inverse mesh...", flush=True)
    inverse_nodes = saved["inverse_nodes"]
    inverse_electrode_positions = inverse_nodes[
        saved["inverse_electrode_nodes"]
    ]
    inverse_solver = FenicsxCEMForward(
        nodes=inverse_nodes,
        elements=saved["inverse_elements"],
        electrode_positions=inverse_electrode_positions,
        protocol=protocol,
        electrode_width=arguments.electrode_width,
        contact_impedance=arguments.contact_impedance,
        current_amplitude=arguments.current_amplitude,
    )

    print("[4/5] Computing the reciprocal-adjoint Jacobian...", flush=True)
    jacobian = inverse_solver.compute_jacobian(
        arguments.background_conductivity
    )
    reconstruction = reconstruct_tikhonov(
        jacobian,
        voltage_noisy - forward_background.measurements,
        lambda_reg=arguments.lambda_reg,
        p=arguments.jacobian_p,
    )
    truth_delta = saved["truth_delta"]
    reconstruction_correlation = safe_correlation(truth_delta, reconstruction)

    comparisons = {
        "background_voltage_relative_error": relative_error(
            saved["voltage_background"],
            forward_background.measurements,
        ),
        "clean_voltage_relative_error": relative_error(
            saved["voltage_clean"],
            forward_phantom.measurements,
        ),
        "first_field_relative_error": relative_error(
            saved["first_excitation_potential"],
            forward_phantom.node_potentials[:, 0],
        ),
        "jacobian_relative_error": relative_error(saved["jacobian"], jacobian),
    }

    print("[5/5] Saving FEniCSX results and comparison metrics...", flush=True)
    arrays = {
        "voltage_background": forward_background.measurements,
        "voltage_clean": forward_phantom.measurements,
        "voltage_noisy": voltage_noisy,
        "voltage_noise": voltage_noise,
        "first_excitation_potential": forward_phantom.node_potentials[:, 0],
        "jacobian": jacobian,
        "reconstruction_delta": reconstruction,
        "truth_delta": truth_delta,
        "forward_electrode_lengths": forward_solver.electrodes.electrode_lengths,
        "inverse_electrode_lengths": inverse_solver.electrodes.electrode_lengths,
    }
    summary = {
        "stage": "FEniCSX complete electrode model validation",
        "dolfinx_version": str(dolfinx.__version__),
        "mpi_library": MPI.Get_library_version().splitlines()[0].rstrip("\x00"),
        "serial_execution": True,
        "input": str(arguments.input.resolve()),
        "n_electrodes": forward_solver.n_electrodes,
        "n_excitations": protocol.n_excitations,
        "measurements_per_excitation": (
            protocol.n_measurements_per_excitation
        ),
        "n_measurements": int(forward_phantom.measurements.size),
        "forward_mesh": {
            "n_nodes": int(forward_solver.nodes.shape[0]),
            "n_elements": int(forward_solver.elements.shape[0]),
            "electrode_edge_counts": (
                forward_solver.electrodes.edge_counts.tolist()
            ),
        },
        "inverse_mesh": {
            "n_nodes": int(inverse_solver.nodes.shape[0]),
            "n_elements": int(inverse_solver.elements.shape[0]),
            "electrode_edge_counts": (
                inverse_solver.electrodes.edge_counts.tolist()
            ),
        },
        "cem_parameters": {
            "electrode_width": arguments.electrode_width,
            "contact_impedance": arguments.contact_impedance,
            "current_amplitude": arguments.current_amplitude,
        },
        "target_snr_db": arguments.snr_db,
        "actual_snr_db": actual_snr,
        "jacobian_shape": list(jacobian.shape),
        "lambda_reg": arguments.lambda_reg,
        "jacobian_p": arguments.jacobian_p,
        "reconstruction_correlation": reconstruction_correlation,
        "comparison_with_scipy_cem": comparisons,
    }
    save_outputs(arguments.output_dir, arrays, summary)

    print("\nFEniCSX CEM pipeline completed.")
    print(f"  DOLFINx: {dolfinx.__version__}")
    print(
        "  Protocol: "
        f"{protocol.n_excitations} x "
        f"{protocol.n_measurements_per_excitation} = "
        f"{forward_phantom.measurements.size}"
    )
    print(f"  Actual SNR: {actual_snr:.4f} dB")
    print(f"  Reconstruction correlation: {reconstruction_correlation:.4f}")
    print(
        "  SciPy/FEniCSX background voltage relative error: "
        f"{comparisons['background_voltage_relative_error']:.3e}"
    )
    print(
        "  SciPy/FEniCSX Jacobian relative error: "
        f"{comparisons['jacobian_relative_error']:.3e}"
    )
    print(f"  Outputs: {arguments.output_dir.resolve()}")


if __name__ == "__main__":
    main()
