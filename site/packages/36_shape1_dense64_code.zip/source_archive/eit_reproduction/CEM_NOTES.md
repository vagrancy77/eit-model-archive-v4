# CEM 数学模型与两个后端

## 1. 连续模型

区域内部满足：

```text
div(sigma * grad(u)) = 0
```

在第 `l` 个有限宽度电极上：

```text
u + z_l * sigma * du/dn = U_l
integral_e_l sigma * du/dn ds = I_l
```

非电极边界满足绝缘条件，并施加：

```text
sum(I_l) = 0
sum(U_l) = 0
```

其中 `u` 是区域内部电势，`U_l` 是电极电势，`z_l` 是接触阻抗，`I_l` 是注入电流。

## 2. 有限元离散

使用一阶三角形单元后，CEM 形成增广分块系统：

```text
[ A   B   0 ] [u]   [0]
[ B^T C   1 ] [U] = [I]
[ 0   1^T 0 ] [r]   [0]
```

- `A`：区域刚度矩阵与电极 Robin 边界质量矩阵；
- `B`：节点电势与电极电势的耦合；
- `C`：电极长度除以接触阻抗形成的对角矩阵；
- `r`：强制 `sum(U)=0` 的拉格朗日乘子。

对于长度为 `L` 的一阶边界边：

```text
边界质量矩阵 = L/6 * [[2, 1], [1, 2]]
基函数边界积分 = L/2 * [1, 1]
```

## 3. 两个实现

### NumPy/SciPy 后端

`eit_basic/cem.py` 显式计算每个三角形的基函数梯度，并用 SciPy 稀疏矩阵组装 `A`、`B`、`C`。该实现容易逐行对应公式。

### FEniCSX 后端

`fenicsx_backend/cem.py` 将保存的 pyEIT 三角网格转换为 DOLFINx 网格，并用 UFL 形式装配：

```text
integral_Omega sigma * grad(u) dot grad(v) dx
+ sum_l (1/z_l) * integral_e_l u*v ds
```

电极耦合块在同一组一阶边界边上进行精确积分，然后与 DOLFINx 节点矩阵组合。由于 DOLFINx 会重新编号单元和自由度，代码通过坐标一一映射把输入电导率送入 DG0 自由度，并把 CG1 电势恢复到原网格节点顺序。

在当前数据上，两后端的电压和 Jacobian 相对误差均约为 `10^-14`。

## 4. 测量协议

16 个电极依次进行相邻激励。每次激励使用 13 个不接触载流电极的相邻电压差，因此：

```text
16 * 13 = 208
```

## 5. 互易伴随 Jacobian

对激励场 `u_exc` 和测量伴随场 `u_adj`，第 `e` 个单元的灵敏度为：

```text
J[m, e] = -area_e * dot(grad(u_exc), grad(u_adj))
```

测量对也是电极电流模式，因此可复用少量唯一伴随场，不需要逐单元做有限差分正问题。

## 6. 当前逆问题

当前求解差分线性化问题：

```text
delta_v = J * delta_sigma
```

正则化目标为：

```text
min ||J * delta_sigma - delta_v||^2
    + lambda * ||R * delta_sigma||^2
```

`R` 由 Jacobian 法方程的对角线构造，对应 NOSER/Kotre 风格正则化。

## 7. 后续可扩展方向

1. 在每次迭代重新求解 CEM 和 Jacobian，实现非线性 Gauss–Newton；
2. 加入正值约束与 TV 正则化；
3. 使用 FEniCSX 原生网格表达非圆形胸腔和三维几何；
4. 用当前模拟器批量生成神经网络训练样本；
5. 将网格电导率或初始重建交给 U-Net、图网络或坐标网络进行后处理。

## 8. 非线性绝对 EIT

绝对 EIT 直接拟合测量电压：

```text
min_sigma 0.5 * ||(F(sigma) - v_meas) / s||^2
          + alpha * TV(sigma)
          + 0.5 * beta * ||log(sigma) - log(sigma_ref)||^2
```

代码使用 `x = log(sigma)`，因此 `sigma = exp(x)` 始终为正。对数参数下的 Jacobian 为：

```text
J_x = J_sigma * diag(sigma)
```

TV 定义在三角形单元的对偶图上。若相邻单元差为 `d_k`，共享边权重为 `w_k`：

```text
TV_epsilon(sigma) = sum_k w_k * sqrt(d_k^2 + epsilon^2)
```

每次迭代固定当前 TV 权重，构造 lagged-diffusivity/IRLS 拉普拉斯矩阵。Gauss–Newton 方程中加入 LM 对角阻尼，候选步还必须通过真实非线性目标的回溯线搜索。

## 9. 神经网络与物理重建

当前网络不直接丢弃物理模型。首先使用固定 CEM Jacobian 和 Tikhonov 算子得到：

```text
delta_sigma_linear = H * (v - v_background)
```

残差 MLP 学习：

```text
correction = MLP(delta_sigma_linear)
delta_sigma_neural = delta_sigma_linear + correction
```

这种结构保留物理重建的稳定低频信息，网络只学习非线性偏差、形状锐化和模拟分布中的统计先验。独立测试集同时报告线性和网络结果，避免只展示训练样本。
