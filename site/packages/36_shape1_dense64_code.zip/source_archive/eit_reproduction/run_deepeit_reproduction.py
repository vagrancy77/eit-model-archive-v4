from __future__ import annotations

from deepeit_reproduction.run_deepeit_reproduction import main


if __name__ == "__main__":
    main()
