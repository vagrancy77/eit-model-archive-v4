# KTC2023-ABC2 DIP+TV 复现记录

## 论文与仓库

- 方法标题：`Deep image prior with total variation regularization to reconstruct Electrical Impedance Tomography images from limited data`
- 公开代码：`https://github.com/robert-abc/KTC2023-ABC2`
- 本地路径：`E:\Codex\eit_reproduction\external\KTC2023-ABC2`

这条线比前面的 GN4IP 更接近最早的 DeepEIT / DIP 思路，因为它不是监督训练一个重建网络，而是对每个样本单独优化一个 DIP 生成器，并把 EIT 线性化前向模型和 TV 正则一起放进损失函数里。

仓库自带：

- `inputs/data1.mat` 到 `data4.mat`
- `groundTruths/true1.mat` 到 `true4.mat`
- `outputs/data1.png` 到 `data4.png`
- 完整 Python 实现和参考网格/矩阵文件

所以它满足“公开代码 + 公开数据/样例结果 + DIP 后续研究”的筛选条件。

## 当前已做的工程化处理

为了让它在当前环境里更容易跑，我做了两处兼容：

1. 在 [solver.py](/E:/Codex/eit_reproduction/external/KTC2023-ABC2/utils/solver.py) 中加入了 `torchmetrics.image.TotalVariation` 的本地 fallback。
2. 给 `solve(...)` 增加了可选的 `num_iter_override` 参数，默认仍然是作者的 `3000` 次迭代，不影响原始入口。

新增了两个辅助脚本：

- [reproduce_ktc2023_abc2.py](/E:/Codex/eit_reproduction/scripts/reproduce_ktc2023_abc2.py)
- [plot_ktc2023_abc2_reference_examples.py](/E:/Codex/eit_reproduction/scripts/plot_ktc2023_abc2_reference_examples.py)

其中：

- `reproduce_ktc2023_abc2.py` 用来固定随机种子、调用作者求解器、输出 PNG，并和仓库自带结果做对照。
- `plot_ktc2023_abc2_reference_examples.py` 用来把 `groundTruth / bundled output / local smoke output` 画成一张对照图。

## 当前验证到的结果

已经确认：

- 代码仓库可以在本地接通；
- 轻量 smoke run 会真实生成输出图；
- 但该方法单样本就比较慢，远慢于 GN4IP 这种直接前向推理的监督网络；
- 当迭代数很低时，本地 smoke 输出会明显欠收敛。

目前生成的参考对照图在：

- [ktc2023_abc2_reference_examples.png](/E:/Codex/eit_reproduction/outputs/ktc2023_abc2_reference/ktc2023_abc2_reference_examples.png)

从这张图可以直接看出两点：

1. 仓库自带输出确实是 DIP+TV 风格的最终分割结果。
2. 我们当前低迭代 smoke 输出只有 `data1` 有粗糙结构，其余样本还没跑，所以不能拿来当正式复现结果。

本地 smoke 输出目录：

- `E:\Codex\eit_reproduction\outputs\ktc2023_abc2_smoke`

## 完整复现的现实成本

作者默认参数是每个样本 `3000` 次迭代，而且每次迭代都要结合 EIT 的雅可比矩阵和 TV 正则做优化。它不是“几秒跑完”的实验，更接近需要长时间单样本优化的 DIP 流程。

这意味着：

- 它非常适合你写“DIP 类 EIT 方法”的复现；
- 但不适合像 GN4IP 那样快速批量试验；
- 如果后面我们继续这条线，比较合理的做法是：
  - 先复现作者自带 4 个样例；
  - 再把 `num_iter`、随机种子、分割后处理固定下来；
  - 最后再考虑把它和更现代的神经网络或超声先验做结合。

## 推荐的下一步

如果继续走这条线，最合理的是：

1. 只针对 `data1.mat` 做一次真正的 `3000` 迭代长跑，确认最终输出是否接近仓库自带 `data1.png`。
2. 如果接近，再扩展到 `data2-4`。
3. 如果你想把它作为论文复现对象，就把它定义成“DIP+TV 的后续工作复现”，而不要再要求它像 GN4IP 一样做到秒级推理。
