"""Compact PyTorch models for a paired multi-frequency EIT ablation.

The public release has six paired measurements only.  These models are
therefore intentionally much smaller than the 6.9-M parameter US--EIT model;
they are tools for a grouped feasibility experiment, not clinical models.
"""

from __future__ import annotations

import math

import torch
from torch import nn
from torch.nn import functional as F


class DenseResidual(nn.Module):
    def __init__(self, width: int, dropout: float = 0.05) -> None:
        super().__init__()
        self.block = nn.Sequential(
            nn.LayerNorm(width),
            nn.Linear(width, width * 2),
            nn.SiLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(width * 2, width),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.block(x)


class VoltageEncoder(nn.Module):
    """The same voltage encoder is used for both frequencies."""

    def __init__(self, voltage_dim: int, latent_dim: int, blocks: int = 3) -> None:
        super().__init__()
        self.stem = nn.Sequential(
            nn.Linear(voltage_dim, latent_dim),
            nn.LayerNorm(latent_dim),
            nn.SiLU(inplace=True),
        )
        self.blocks = nn.Sequential(*(DenseResidual(latent_dim) for _ in range(blocks)))

    def forward(self, voltage: torch.Tensor) -> torch.Tensor:
        return self.blocks(self.stem(voltage))


class FrequencyConditioner(nn.Module):
    """Continuous log-frequency conditioning; inputs are frequencies in kHz."""

    def __init__(self, latent_dim: int) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(1, latent_dim // 2),
            nn.SiLU(inplace=True),
            nn.Linear(latent_dim // 2, latent_dim * 2),
        )

    def forward(self, frequency_khz: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        frequency = frequency_khz.to(dtype=torch.float32).reshape(-1, 1).clamp_min(1e-4)
        # Center at the geometric mean of 10 and 50 kHz.  The model sees the
        # numerical frequency, rather than a mere category identifier.
        normalized = (torch.log(frequency) - math.log(math.sqrt(500.0))) / math.log(5.0)
        gamma, beta = self.net(normalized).chunk(2, dim=1)
        return gamma, beta


class ConvNormAct(nn.Module):
    def __init__(self, channels_in: int, channels_out: int) -> None:
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(channels_in, channels_out, 3, padding=1, bias=False),
            nn.GroupNorm(min(4, channels_out), channels_out),
            nn.SiLU(inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.block(x)


class SpatialDecoder(nn.Module):
    """Decode a voltage latent vector into a low-resolution conductivity map."""

    def __init__(self, latent_dim: int, base_channels: int, pixels: int) -> None:
        super().__init__()
        if pixels != 64:
            raise ValueError("the current decoder is defined for 64 x 64 targets")
        self.base_channels = base_channels
        self.project = nn.Sequential(
            nn.Linear(latent_dim, base_channels * 4 * 4),
            nn.SiLU(inplace=True),
        )
        self.stages = nn.ModuleList(
            [
                nn.Sequential(nn.ConvTranspose2d(base_channels, base_channels, 4, 2, 1), ConvNormAct(base_channels, base_channels)),
                nn.Sequential(nn.ConvTranspose2d(base_channels, base_channels, 4, 2, 1), ConvNormAct(base_channels, base_channels)),
                nn.Sequential(nn.ConvTranspose2d(base_channels, base_channels, 4, 2, 1), ConvNormAct(base_channels, base_channels)),
                nn.Sequential(nn.ConvTranspose2d(base_channels, base_channels, 4, 2, 1), ConvNormAct(base_channels, base_channels)),
            ]
        )

    def forward(self, latent: torch.Tensor) -> torch.Tensor:
        image = self.project(latent).reshape(-1, self.base_channels, 4, 4)
        for stage in self.stages:
            image = stage(image)
        return image


def bounded_conductivity(logits: torch.Tensor) -> torch.Tensor:
    return 0.05 + 2.95 * torch.sigmoid(logits)


class FrequencyConditionedEITNet(nn.Module):
    """Single-frame EIT reconstruction from voltage plus the actual frequency."""

    def __init__(self, voltage_dim: int = 416, latent_dim: int = 96, base_channels: int = 12, pixels: int = 64) -> None:
        super().__init__()
        self.encoder = VoltageEncoder(voltage_dim, latent_dim)
        self.frequency_conditioner = FrequencyConditioner(latent_dim)
        self.decoder = SpatialDecoder(latent_dim, base_channels, pixels)
        self.head = nn.Sequential(ConvNormAct(base_channels, base_channels), nn.Conv2d(base_channels, 1, 1))

    def forward(self, voltage: torch.Tensor, frequency_khz: torch.Tensor) -> torch.Tensor:
        latent = self.encoder(voltage)
        gamma, beta = self.frequency_conditioner(frequency_khz)
        latent = latent * (1.0 + 0.15 * torch.tanh(gamma)) + 0.15 * torch.tanh(beta)
        return bounded_conductivity(self.head(self.decoder(latent)))


class SharedEncoderFrequencyHeadsNet(nn.Module):
    """Paired 10/50-kHz model with a shared encoder and frequency-specific heads.

    The input is ``[batch, 2, measurements]`` in the same order as
    ``frequency_khz``.  A two-token attention block permits either frequency to
    borrow information from its paired measurement, while two final heads keep
    frequency-specific output characteristics separate.
    """

    def __init__(self, voltage_dim: int = 416, latent_dim: int = 96, base_channels: int = 12, pixels: int = 64, heads: int = 4) -> None:
        super().__init__()
        if latent_dim % heads != 0:
            raise ValueError("latent_dim must be divisible by attention heads")
        self.encoder = VoltageEncoder(voltage_dim, latent_dim)
        self.frequency_conditioner = FrequencyConditioner(latent_dim)
        self.cross_frequency_attention = nn.MultiheadAttention(latent_dim, heads, dropout=0.05, batch_first=True)
        self.attention_norm = nn.LayerNorm(latent_dim)
        self.decoder = SpatialDecoder(latent_dim, base_channels, pixels)
        self.frequency_heads = nn.ModuleList(
            [
                nn.Sequential(ConvNormAct(base_channels, base_channels), nn.Conv2d(base_channels, 1, 1)),
                nn.Sequential(ConvNormAct(base_channels, base_channels), nn.Conv2d(base_channels, 1, 1)),
            ]
        )

    def forward(self, paired_voltage: torch.Tensor, frequency_khz: torch.Tensor) -> torch.Tensor:
        if paired_voltage.ndim != 3 or paired_voltage.shape[1] != 2:
            raise ValueError("paired_voltage must have shape [batch, 2, measurements]")
        if frequency_khz.shape[-1] != 2:
            raise ValueError("frequency_khz must contain the matching two frequencies")
        batch, frequencies, features = paired_voltage.shape
        latent = self.encoder(paired_voltage.reshape(batch * frequencies, features)).reshape(batch, frequencies, -1)
        gamma, beta = self.frequency_conditioner(frequency_khz.reshape(-1))
        latent = latent * (1.0 + 0.15 * torch.tanh(gamma.reshape(batch, frequencies, -1)))
        latent = latent + 0.15 * torch.tanh(beta.reshape(batch, frequencies, -1))
        attended, _ = self.cross_frequency_attention(self.attention_norm(latent), self.attention_norm(latent), self.attention_norm(latent), need_weights=False)
        latent = latent + attended
        decoded = self.decoder(latent.reshape(batch * frequencies, -1)).reshape(batch, frequencies, -1, 64, 64)
        output = [self.frequency_heads[index](decoded[:, index]) for index in range(2)]
        return bounded_conductivity(torch.stack(output, dim=1))


class SharedGeometryFrequencyContrastNet(nn.Module):
    """Factorize paired EIT into shared lesion geometry and spectral contrast.

    Both voltage frames determine one geometry gate, answering *where* the
    anomaly is.  Two frequency-specific contrast heads answer *how strongly*
    that shared structure changes conductivity at 10 and 50 kHz.  The final
    conductivity is formed explicitly from these two factors, so the network
    cannot silently hide a separate lesion location in each output head.
    """

    def __init__(self, voltage_dim: int = 416, latent_dim: int = 96, base_channels: int = 12, pixels: int = 64, heads: int = 4) -> None:
        super().__init__()
        if latent_dim % heads != 0:
            raise ValueError("latent_dim must be divisible by attention heads")
        self.pixels = pixels
        self.encoder = VoltageEncoder(voltage_dim, latent_dim)
        self.frequency_conditioner = FrequencyConditioner(latent_dim)
        self.cross_frequency_attention = nn.MultiheadAttention(latent_dim, heads, dropout=0.05, batch_first=True)
        self.attention_norm = nn.LayerNorm(latent_dim)
        self.geometry_fusion = nn.Sequential(
            nn.Linear(latent_dim * 2, latent_dim),
            nn.LayerNorm(latent_dim),
            nn.SiLU(inplace=True),
            DenseResidual(latent_dim),
        )
        self.geometry_decoder = SpatialDecoder(latent_dim, base_channels, pixels)
        self.geometry_head = nn.Sequential(ConvNormAct(base_channels, base_channels), nn.Conv2d(base_channels, 1, 1))
        self.contrast_decoder = SpatialDecoder(latent_dim, base_channels, pixels)
        self.contrast_heads = nn.ModuleList(
            [
                nn.Sequential(ConvNormAct(base_channels, base_channels), nn.Conv2d(base_channels, 1, 1)),
                nn.Sequential(ConvNormAct(base_channels, base_channels), nn.Conv2d(base_channels, 1, 1)),
            ]
        )
        self.background_heads = nn.ModuleList([nn.Linear(latent_dim, 1), nn.Linear(latent_dim, 1)])
        background_probability = (1.0 - 0.05) / 2.95
        self.register_buffer("background_logit", torch.tensor(math.log(background_probability / (1.0 - background_probability)), dtype=torch.float32))

    def forward(
        self,
        paired_voltage: torch.Tensor,
        frequency_khz: torch.Tensor,
        return_auxiliary: bool = False,
    ) -> torch.Tensor | dict[str, torch.Tensor]:
        if paired_voltage.ndim != 3 or paired_voltage.shape[1] != 2:
            raise ValueError("paired_voltage must have shape [batch, 2, measurements]")
        if frequency_khz.shape[-1] != 2:
            raise ValueError("frequency_khz must contain the matching two frequencies")
        batch, frequencies, features = paired_voltage.shape
        latent = self.encoder(paired_voltage.reshape(batch * frequencies, features)).reshape(batch, frequencies, -1)
        gamma, beta = self.frequency_conditioner(frequency_khz.reshape(-1))
        latent = latent * (1.0 + 0.15 * torch.tanh(gamma.reshape(batch, frequencies, -1)))
        latent = latent + 0.15 * torch.tanh(beta.reshape(batch, frequencies, -1))
        normalized = self.attention_norm(latent)
        attended, _ = self.cross_frequency_attention(normalized, normalized, normalized, need_weights=False)
        latent = latent + attended

        # Mean features describe common content; absolute spectral differences
        # tell the geometry branch which structures persist across frequencies.
        geometry_latent = self.geometry_fusion(torch.cat([latent.mean(dim=1), torch.abs(latent[:, 0] - latent[:, 1])], dim=1))
        geometry = torch.sigmoid(self.geometry_head(self.geometry_decoder(geometry_latent)))

        contrast_latent = latent + geometry_latent[:, None, :]
        contrast_features = self.contrast_decoder(contrast_latent.reshape(batch * frequencies, -1)).reshape(
            batch, frequencies, -1, self.pixels, self.pixels
        )
        contrast_logits = torch.stack(
            [self.contrast_heads[index](contrast_features[:, index]) for index in range(2)], dim=1
        )
        background_shift = torch.stack(
            [self.background_heads[index](latent[:, index]) for index in range(2)], dim=1
        )[:, :, :, None, None]
        background_logits = self.background_logit + torch.tanh(background_shift)
        # geometry=0 yields a frequency-specific spatially uniform background;
        # signed contrast logits then describe only localized deviations.
        reconstruction = bounded_conductivity(background_logits + geometry[:, None] * contrast_logits)
        if return_auxiliary:
            return {
                "reconstruction": reconstruction,
                "geometry": geometry,
                "contrast_logits": contrast_logits,
                "frequency_background": bounded_conductivity(background_logits),
            }
        return reconstruction


class CoordinateConditioner(nn.Module):
    """FiLM parameters for a scalar frequency coordinate.

    Some public mfEIT releases only identify channels as ``f1``--``f4`` and
    do not publish their physical frequencies.  In that situation callers can
    pass the ordinal coordinates 1--4 without pretending that they are kHz.
    """

    def __init__(self, latent_dim: int, coordinate_min: float, coordinate_max: float) -> None:
        super().__init__()
        if coordinate_max <= coordinate_min:
            raise ValueError("coordinate_max must be greater than coordinate_min")
        self.coordinate_center = 0.5 * (coordinate_min + coordinate_max)
        self.coordinate_scale = 0.5 * (coordinate_max - coordinate_min)
        self.net = nn.Sequential(
            nn.Linear(1, latent_dim // 2),
            nn.SiLU(inplace=True),
            nn.Linear(latent_dim // 2, latent_dim * 2),
        )

    def forward(self, coordinate: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        normalized = (coordinate.to(dtype=torch.float32).reshape(-1, 1) - self.coordinate_center) / self.coordinate_scale
        gamma, beta = self.net(normalized).chunk(2, dim=1)
        return gamma, beta


class SingleFrameAnomalyNet(nn.Module):
    """One voltage frame to one normalized conductivity-change magnitude."""

    def __init__(self, voltage_dim: int, latent_dim: int = 128, base_channels: int = 16, pixels: int = 64) -> None:
        super().__init__()
        self.encoder = VoltageEncoder(voltage_dim, latent_dim)
        self.decoder = SpatialDecoder(latent_dim, base_channels, pixels)
        self.head = nn.Sequential(ConvNormAct(base_channels, base_channels), nn.Conv2d(base_channels, 1, 1))

    def forward(self, voltage: torch.Tensor) -> torch.Tensor:
        return torch.sigmoid(self.head(self.decoder(self.encoder(voltage))))


class IndependentFrequencyAnomalyNet(nn.Module):
    """Strict single-frequency baseline implemented as one network per channel."""

    def __init__(
        self,
        voltage_dim: int,
        num_frequencies: int,
        latent_dim: int = 128,
        base_channels: int = 16,
        pixels: int = 64,
    ) -> None:
        super().__init__()
        self.num_frequencies = num_frequencies
        self.models = nn.ModuleList(
            [SingleFrameAnomalyNet(voltage_dim, latent_dim, base_channels, pixels) for _ in range(num_frequencies)]
        )

    def forward(self, paired_voltage: torch.Tensor) -> torch.Tensor:
        if paired_voltage.ndim != 3 or paired_voltage.shape[1] != self.num_frequencies:
            raise ValueError(f"paired_voltage must have shape [batch, {self.num_frequencies}, measurements]")
        return torch.stack(
            [model(paired_voltage[:, index]) for index, model in enumerate(self.models)], dim=1
        )


class FrequencyConditionedAnomalyNet(nn.Module):
    """Single-frame baseline that knows the channel coordinate but not other frames."""

    def __init__(
        self,
        voltage_dim: int,
        latent_dim: int = 128,
        base_channels: int = 16,
        pixels: int = 64,
        coordinate_min: float = 1.0,
        coordinate_max: float = 4.0,
    ) -> None:
        super().__init__()
        self.encoder = VoltageEncoder(voltage_dim, latent_dim)
        self.conditioner = CoordinateConditioner(latent_dim, coordinate_min, coordinate_max)
        self.decoder = SpatialDecoder(latent_dim, base_channels, pixels)
        self.head = nn.Sequential(ConvNormAct(base_channels, base_channels), nn.Conv2d(base_channels, 1, 1))

    def forward(self, voltage: torch.Tensor, frequency_coordinate: torch.Tensor) -> torch.Tensor:
        latent = self.encoder(voltage)
        gamma, beta = self.conditioner(frequency_coordinate)
        latent = latent * (1.0 + 0.15 * torch.tanh(gamma)) + 0.15 * torch.tanh(beta)
        return torch.sigmoid(self.head(self.decoder(latent)))


class JointFrequencyAnomalyNet(nn.Module):
    """General multi-frequency model with shared encoding and channel heads."""

    def __init__(
        self,
        voltage_dim: int,
        num_frequencies: int,
        latent_dim: int = 128,
        base_channels: int = 16,
        pixels: int = 64,
        heads: int = 4,
        coordinate_min: float = 1.0,
        coordinate_max: float = 4.0,
    ) -> None:
        super().__init__()
        if latent_dim % heads != 0:
            raise ValueError("latent_dim must be divisible by attention heads")
        self.num_frequencies = num_frequencies
        self.pixels = pixels
        self.encoder = VoltageEncoder(voltage_dim, latent_dim)
        self.conditioner = CoordinateConditioner(latent_dim, coordinate_min, coordinate_max)
        self.attention = nn.MultiheadAttention(latent_dim, heads, dropout=0.05, batch_first=True)
        self.attention_norm = nn.LayerNorm(latent_dim)
        self.decoder = SpatialDecoder(latent_dim, base_channels, pixels)
        self.frequency_heads = nn.ModuleList(
            [nn.Sequential(ConvNormAct(base_channels, base_channels), nn.Conv2d(base_channels, 1, 1)) for _ in range(num_frequencies)]
        )

    def _latent(self, paired_voltage: torch.Tensor, frequency_coordinate: torch.Tensor) -> torch.Tensor:
        if paired_voltage.ndim != 3 or paired_voltage.shape[1] != self.num_frequencies:
            raise ValueError(f"paired_voltage must have shape [batch, {self.num_frequencies}, measurements]")
        batch, frequencies, features = paired_voltage.shape
        latent = self.encoder(paired_voltage.reshape(batch * frequencies, features)).reshape(batch, frequencies, -1)
        gamma, beta = self.conditioner(frequency_coordinate.reshape(-1))
        latent = latent * (1.0 + 0.15 * torch.tanh(gamma.reshape(batch, frequencies, -1)))
        latent = latent + 0.15 * torch.tanh(beta.reshape(batch, frequencies, -1))
        normalized = self.attention_norm(latent)
        attended, _ = self.attention(normalized, normalized, normalized, need_weights=False)
        return latent + attended

    def forward(self, paired_voltage: torch.Tensor, frequency_coordinate: torch.Tensor) -> torch.Tensor:
        batch = paired_voltage.shape[0]
        latent = self._latent(paired_voltage, frequency_coordinate)
        decoded = self.decoder(latent.reshape(batch * self.num_frequencies, -1)).reshape(
            batch, self.num_frequencies, -1, self.pixels, self.pixels
        )
        return torch.sigmoid(
            torch.stack(
                [self.frequency_heads[index](decoded[:, index]) for index in range(self.num_frequencies)], dim=1
            )
        )


class SharedGeometryFrequencyContrastAnomalyNet(JointFrequencyAnomalyNet):
    """Shared lesion support with a separate conductivity magnitude per channel.

    The reconstructed normalized anomaly magnitude is explicitly
    ``shared_geometry * frequency_contrast``.  Consequently, frequency heads
    can change lesion strength but cannot move a lesion independently.
    """

    def __init__(
        self,
        voltage_dim: int,
        num_frequencies: int,
        latent_dim: int = 128,
        base_channels: int = 16,
        pixels: int = 64,
        heads: int = 4,
        coordinate_min: float = 1.0,
        coordinate_max: float = 4.0,
    ) -> None:
        super().__init__(
            voltage_dim,
            num_frequencies,
            latent_dim,
            base_channels,
            pixels,
            heads,
            coordinate_min,
            coordinate_max,
        )
        self.geometry_fusion = nn.Sequential(
            nn.Linear(latent_dim * 2, latent_dim),
            nn.LayerNorm(latent_dim),
            nn.SiLU(inplace=True),
            DenseResidual(latent_dim),
        )
        self.geometry_decoder = SpatialDecoder(latent_dim, base_channels, pixels)
        self.geometry_head = nn.Sequential(ConvNormAct(base_channels, base_channels), nn.Conv2d(base_channels, 1, 1))

    def forward(
        self,
        paired_voltage: torch.Tensor,
        frequency_coordinate: torch.Tensor,
        return_auxiliary: bool = False,
    ) -> torch.Tensor | dict[str, torch.Tensor]:
        batch = paired_voltage.shape[0]
        latent = self._latent(paired_voltage, frequency_coordinate)
        shared = torch.cat(
            [latent.mean(dim=1), torch.mean(torch.abs(latent - latent.mean(dim=1, keepdim=True)), dim=1)], dim=1
        )
        geometry_latent = self.geometry_fusion(shared)
        geometry = torch.sigmoid(self.geometry_head(self.geometry_decoder(geometry_latent)))
        contrast_latent = latent + geometry_latent[:, None, :]
        decoded = self.decoder(contrast_latent.reshape(batch * self.num_frequencies, -1)).reshape(
            batch, self.num_frequencies, -1, self.pixels, self.pixels
        )
        contrast = torch.sigmoid(
            torch.stack(
                [self.frequency_heads[index](decoded[:, index]) for index in range(self.num_frequencies)], dim=1
            )
        )
        reconstruction = geometry[:, None] * contrast
        if return_auxiliary:
            return {"reconstruction": reconstruction, "geometry": geometry, "frequency_contrast": contrast}
        return reconstruction


class InstanceGeometryDispersionAnomalyNet(JointFrequencyAnomalyNet):
    """Instance-level geometry with a smooth, frequency-conditioned spectrum.

    The older factorized model predicts one spatial contrast map per frequency.
    That representation is prone to smoothing the intensity of neighbouring
    lesions together.  This model instead predicts up to ``max_instances``
    shared lesion masks and one smooth response curve for each lesion.  The
    curve is parameterised by a low value, a positive gap and a positive power:

        a_k(t) = low_k + gap_k * (1 - t) ** power_k,

    where ``t`` is the normalized frequency coordinate.  It is a deliberately
    small physical-dispersion prior: responses are smooth and non-increasing,
    while each lesion retains its own frequency-dependent amplitude.
    """

    def __init__(
        self,
        voltage_dim: int,
        num_frequencies: int,
        latent_dim: int = 128,
        base_channels: int = 16,
        pixels: int = 64,
        heads: int = 4,
        coordinate_min: float = 1.0,
        coordinate_max: float = 4.0,
        max_instances: int = 3,
    ) -> None:
        super().__init__(
            voltage_dim,
            num_frequencies,
            latent_dim,
            base_channels,
            pixels,
            heads,
            coordinate_min,
            coordinate_max,
        )
        if max_instances <= 0:
            raise ValueError("max_instances must be positive")
        self.max_instances = max_instances
        self.coordinate_min = float(coordinate_min)
        self.coordinate_max = float(coordinate_max)
        self.geometry_fusion = nn.Sequential(
            nn.Linear(latent_dim * (num_frequencies + 1), latent_dim),
            nn.LayerNorm(latent_dim),
            nn.SiLU(inplace=True),
            DenseResidual(latent_dim),
        )
        self.geometry_decoder = SpatialDecoder(latent_dim, base_channels, pixels)
        self.instance_mask_head = nn.Sequential(
            ConvNormAct(base_channels, base_channels),
            nn.Conv2d(base_channels, max_instances + 1, 1),
        )
        self.slot_embedding = nn.Parameter(torch.randn(max_instances, latent_dim) * 0.02)
        self.spectrum_head = nn.Sequential(
            nn.Linear(latent_dim * 2, latent_dim),
            nn.LayerNorm(latent_dim),
            nn.SiLU(inplace=True),
            nn.Linear(latent_dim, 3),
        )

    def forward(
        self,
        paired_voltage: torch.Tensor,
        frequency_coordinate: torch.Tensor,
        return_auxiliary: bool = False,
    ) -> torch.Tensor | dict[str, torch.Tensor]:
        latent = self._latent(paired_voltage, frequency_coordinate)
        batch = paired_voltage.shape[0]
        spectral_summary = torch.cat([latent.mean(dim=1), latent.flatten(start_dim=1)], dim=1)
        geometry_latent = self.geometry_fusion(spectral_summary)

        geometry_features = self.geometry_decoder(geometry_latent)
        class_probability = torch.softmax(self.instance_mask_head(geometry_features), dim=1)
        background_probability = class_probability[:, :1]
        instance_masks = class_probability[:, 1:]
        geometry = 1.0 - background_probability
        presence = instance_masks.flatten(start_dim=2).amax(dim=-1)

        slot = self.slot_embedding[None].expand(batch, -1, -1)
        spectrum_context = torch.cat([geometry_latent[:, None, :].expand(-1, self.max_instances, -1), slot], dim=-1)
        raw_parameters = self.spectrum_head(spectrum_context)
        low = torch.sigmoid(raw_parameters[..., 0])
        gap = (1.0 - low) * torch.sigmoid(raw_parameters[..., 1])
        power = F.softplus(raw_parameters[..., 2]) + 0.25
        coordinate = frequency_coordinate.to(dtype=geometry_latent.dtype)
        coordinate = (coordinate - self.coordinate_min) / (self.coordinate_max - self.coordinate_min)
        coordinate = coordinate.clamp(0.0, 1.0)
        curve = low[:, :, None] + gap[:, :, None] * torch.pow(
            (1.0 - coordinate[:, None, :]).clamp_min(1e-6), power[:, :, None]
        )
        instance_spectra = curve
        reconstruction = torch.einsum("bkhw,bkf->bfhw", instance_masks, instance_spectra)
        reconstruction = reconstruction.clamp(0.0, 1.0).unsqueeze(2)
        if return_auxiliary:
            return {
                "reconstruction": reconstruction,
                "geometry": geometry,
                "instance_masks": instance_masks,
                "instance_spectra": instance_spectra,
                "presence": presence,
                "background_probability": background_probability,
                "dispersion_parameters": torch.stack([low, low + gap, power], dim=-1),
            }
        return reconstruction
