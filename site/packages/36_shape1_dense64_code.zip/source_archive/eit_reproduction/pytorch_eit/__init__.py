"""PyTorch models and data utilities for physics-guided EIT reconstruction."""

# Data preparation is also supported from the Windows scientific Python
# environment, where PyTorch may not be installed. Keep the model import
# optional so ``pytorch_eit.data`` remains usable there.
try:
    from .models import MultiModalEITNet
    from .multifrequency import (
        FrequencyConditionedAnomalyNet,
        FrequencyConditionedEITNet,
        IndependentFrequencyAnomalyNet,
        JointFrequencyAnomalyNet,
        SharedEncoderFrequencyHeadsNet,
        SharedGeometryFrequencyContrastAnomalyNet,
        SharedGeometryFrequencyContrastNet,
    )
except ModuleNotFoundError:  # pragma: no cover - exercised only without torch
    MultiModalEITNet = None  # type: ignore[assignment]
    FrequencyConditionedEITNet = None  # type: ignore[assignment]
    SharedEncoderFrequencyHeadsNet = None  # type: ignore[assignment]
    SharedGeometryFrequencyContrastNet = None  # type: ignore[assignment]
    IndependentFrequencyAnomalyNet = None  # type: ignore[assignment]
    FrequencyConditionedAnomalyNet = None  # type: ignore[assignment]
    JointFrequencyAnomalyNet = None  # type: ignore[assignment]
    SharedGeometryFrequencyContrastAnomalyNet = None  # type: ignore[assignment]

__all__ = [
    "MultiModalEITNet",
    "FrequencyConditionedEITNet",
    "SharedEncoderFrequencyHeadsNet",
    "SharedGeometryFrequencyContrastNet",
    "IndependentFrequencyAnomalyNet",
    "FrequencyConditionedAnomalyNet",
    "JointFrequencyAnomalyNet",
    "SharedGeometryFrequencyContrastAnomalyNet",
]
