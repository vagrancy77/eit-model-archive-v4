from __future__ import annotations

from typing import Optional

import torch
from torch import nn
from torch.nn import functional as F


class ConvNormAct(nn.Module):
    def __init__(self, channels_in: int, channels_out: int, stride: int = 1) -> None:
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(channels_in, channels_out, 3, stride=stride, padding=1, bias=False),
            nn.GroupNorm(min(8, channels_out), channels_out),
            nn.SiLU(inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.block(x)


class ResidualBlock(nn.Module):
    def __init__(self, channels: int, dropout: float = 0.0) -> None:
        super().__init__()
        self.conv1 = ConvNormAct(channels, channels)
        self.conv2 = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1, bias=False),
            nn.GroupNorm(min(8, channels), channels),
        )
        self.dropout = nn.Dropout2d(dropout) if dropout > 0 else nn.Identity()
        self.act = nn.SiLU(inplace=True)
        self.se = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(channels, max(channels // 8, 4), 1),
            nn.SiLU(inplace=True),
            nn.Conv2d(max(channels // 8, 4), channels, 1),
            nn.Sigmoid(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        y = self.conv1(x)
        y = self.dropout(self.conv2(y))
        y = y * self.se(y)
        return self.act(y + residual)


class EncoderStage(nn.Module):
    def __init__(self, channels_in: int, channels_out: int, blocks: int = 2) -> None:
        super().__init__()
        self.down = ConvNormAct(channels_in, channels_out, stride=2)
        self.blocks = nn.Sequential(*(ResidualBlock(channels_out) for _ in range(blocks)))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.blocks(self.down(x))


class ModalityEncoder(nn.Module):
    def __init__(self, channels_in: int, base: int, blocks: int = 2) -> None:
        super().__init__()
        self.stem = nn.Sequential(ConvNormAct(channels_in, base), ResidualBlock(base))
        self.stage1 = EncoderStage(base, base * 2, blocks)
        self.stage2 = EncoderStage(base * 2, base * 4, blocks)
        self.stage3 = EncoderStage(base * 4, base * 8, blocks)

    def forward(self, x: torch.Tensor) -> list[torch.Tensor]:
        f0 = self.stem(x)
        f1 = self.stage1(f0)
        f2 = self.stage2(f1)
        f3 = self.stage3(f2)
        return [f0, f1, f2, f3]


class CrossModalGate(nn.Module):
    """Learned spatial gate that lets ultrasound add structure to EIT features."""

    def __init__(self, channels: int) -> None:
        super().__init__()
        self.us_projection = nn.Conv2d(channels, channels, 1, bias=False)
        self.gate = nn.Sequential(
            nn.Conv2d(channels * 2, channels, 1),
            nn.GroupNorm(min(8, channels), channels),
            nn.SiLU(inplace=True),
            nn.Conv2d(channels, channels, 1),
            nn.Sigmoid(),
        )
        self.out = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1, bias=False),
            nn.GroupNorm(min(8, channels), channels),
            nn.SiLU(inplace=True),
        )

    def forward(self, eit: torch.Tensor, ultrasound: torch.Tensor, available: torch.Tensor) -> torch.Tensor:
        ultrasound = self.us_projection(ultrasound)
        gate = self.gate(torch.cat([eit, ultrasound], dim=1))
        # available is [B, 1] and is deliberately applied after the learned gate.
        available = available[:, :, None, None]
        return self.out(eit + available * gate * ultrasound)


class VoltageConditioner(nn.Module):
    def __init__(self, voltage_dim: int, embedding_dim: int) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(voltage_dim, embedding_dim),
            nn.LayerNorm(embedding_dim),
            nn.SiLU(inplace=True),
            nn.Dropout(0.1),
            nn.Linear(embedding_dim, embedding_dim),
            nn.SiLU(inplace=True),
        )
        self.to_film = nn.Linear(embedding_dim, embedding_dim * 2)

    def forward(self, voltage: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        embedding = self.net(voltage)
        gamma, beta = self.to_film(embedding).chunk(2, dim=1)
        return gamma[:, :, None, None], beta[:, :, None, None]


class BottleneckCrossAttention(nn.Module):
    def __init__(self, channels: int, heads: int = 8) -> None:
        super().__init__()
        self.norm_q = nn.LayerNorm(channels)
        self.norm_kv = nn.LayerNorm(channels)
        self.attention = nn.MultiheadAttention(channels, heads, dropout=0.1, batch_first=True)
        self.ffn = nn.Sequential(
            nn.LayerNorm(channels),
            nn.Linear(channels, channels * 4),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(channels * 4, channels),
        )

    def forward(self, query_map: torch.Tensor, key_value_map: torch.Tensor, available: torch.Tensor) -> torch.Tensor:
        b, c, h, w = query_map.shape
        query = query_map.flatten(2).transpose(1, 2)
        key_value = key_value_map.flatten(2).transpose(1, 2)
        attended, _ = self.attention(self.norm_q(query), self.norm_kv(key_value), self.norm_kv(key_value))
        attended = attended * available[:, :, None]
        output = query + attended
        output = output + self.ffn(output)
        return output.transpose(1, 2).reshape(b, c, h, w)


class DecoderStage(nn.Module):
    def __init__(self, channels_in: int, skip_channels: int, channels_out: int) -> None:
        super().__init__()
        self.up = nn.Sequential(
            nn.ConvTranspose2d(channels_in, channels_out, 2, stride=2),
            nn.GroupNorm(min(8, channels_out), channels_out),
            nn.SiLU(inplace=True),
        )
        self.fuse = nn.Sequential(
            nn.Conv2d(channels_out + skip_channels, channels_out, 1, bias=False),
            nn.GroupNorm(min(8, channels_out), channels_out),
            nn.SiLU(inplace=True),
            ResidualBlock(channels_out),
        )

    def forward(self, x: torch.Tensor, skip: torch.Tensor) -> torch.Tensor:
        x = self.up(x)
        if x.shape[-2:] != skip.shape[-2:]:
            x = F.interpolate(x, size=skip.shape[-2:], mode="bilinear", align_corners=False)
        return self.fuse(torch.cat([x, skip], dim=1))


class MultiModalEITNet(nn.Module):
    """Physics-guided multimodal EIT reconstruction network.

    Inputs are a physics-based EIT image, the raw 208-dimensional voltage
    feature vector, and an ultrasound image. Ultrasound can be absent: pass
    ``ultrasound=None`` or set ``ultrasound_available`` to zero. During
    training, modality dropout makes the same checkpoint useful for EIT-only
    measurements and for future synchronized US-EIT acquisitions.
    """

    def __init__(
        self,
        voltage_dim: int = 208,
        base_channels: int = 24,
        output_channels: int = 1,
        attention_heads: int = 8,
    ) -> None:
        super().__init__()
        self.voltage_dim = voltage_dim
        self.base_channels = base_channels
        self.eit_encoder = ModalityEncoder(1, base_channels)
        self.us_encoder = ModalityEncoder(1, base_channels)
        channels = [base_channels, base_channels * 2, base_channels * 4, base_channels * 8]
        self.fusions = nn.ModuleList(CrossModalGate(c) for c in channels)
        self.voltage_conditioner = VoltageConditioner(voltage_dim, channels[-1])
        self.cross_attention = BottleneckCrossAttention(channels[-1], attention_heads)
        self.bottleneck = nn.Sequential(ResidualBlock(channels[-1], 0.1), ResidualBlock(channels[-1], 0.1))
        self.decoder2 = DecoderStage(channels[-1], channels[-2], channels[-2])
        self.decoder1 = DecoderStage(channels[-2], channels[-3], channels[-3])
        self.decoder0 = DecoderStage(channels[-3], channels[-4], channels[-4])
        self.head = nn.Sequential(
            ConvNormAct(channels[0], channels[0]),
            nn.Conv2d(channels[0], output_channels, 1),
        )
        self.segmentation_head = nn.Conv2d(channels[0], 1, 1)

    def forward(
        self,
        eit_image: torch.Tensor,
        voltages: torch.Tensor,
        ultrasound: Optional[torch.Tensor] = None,
        ultrasound_available: Optional[torch.Tensor] = None,
    ) -> dict[str, torch.Tensor]:
        if ultrasound is None:
            ultrasound = torch.zeros_like(eit_image)
        if ultrasound_available is None:
            ultrasound_available = torch.ones((eit_image.shape[0], 1), device=eit_image.device, dtype=eit_image.dtype)
        ultrasound_available = ultrasound_available.to(dtype=eit_image.dtype, device=eit_image.device).reshape(-1, 1)
        eit_features = self.eit_encoder(eit_image)
        us_features = self.us_encoder(ultrasound)
        fused = [gate(e, u, ultrasound_available) for gate, e, u in zip(self.fusions, eit_features, us_features)]
        gamma, beta = self.voltage_conditioner(voltages)
        x = fused[-1] * (1.0 + 0.1 * torch.tanh(gamma)) + 0.1 * torch.tanh(beta)
        x = self.cross_attention(x, us_features[-1], ultrasound_available)
        x = self.bottleneck(x)
        x = self.decoder2(x, fused[-2])
        x = self.decoder1(x, fused[-3])
        x = self.decoder0(x, fused[-4])
        raw_residual = self.head(x)
        # Conductivity is constrained to a physically meaningful positive range.
        prediction = 0.05 + 2.95 * torch.sigmoid(raw_residual + torch.logit((eit_image.clamp(0.051, 2.949) - 0.05) / 2.95))
        return {
            "reconstruction": prediction,
            "residual": raw_residual,
            "segmentation_logits": self.segmentation_head(x),
        }


class UltrasoundSpatialRegistration(nn.Module):
    """Small bounded affine registration module for ultrasound-to-EIT alignment."""

    def __init__(self, max_translation: float = 0.20, max_rotation: float = 0.20, max_log_scale: float = 0.10) -> None:
        super().__init__()
        self.max_translation = float(max_translation)
        self.max_rotation = float(max_rotation)
        self.max_log_scale = float(max_log_scale)
        self.localization = nn.Sequential(
            nn.Conv2d(1, 8, 5, stride=2, padding=2),
            nn.SiLU(inplace=True),
            nn.Conv2d(8, 16, 5, stride=2, padding=2),
            nn.GroupNorm(4, 16),
            nn.SiLU(inplace=True),
            nn.AdaptiveAvgPool2d(1),
        )
        self.parameter_head = nn.Sequential(
            nn.Flatten(),
            nn.Linear(16, 16),
            nn.SiLU(inplace=True),
            nn.Linear(16, 4),
        )
        # Start exactly at the identity transform so the model initially
        # behaves like the existing multimodal network.
        nn.init.zeros_(self.parameter_head[-1].weight)
        nn.init.zeros_(self.parameter_head[-1].bias)

    def forward(self, ultrasound: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        raw = self.parameter_head(self.localization(ultrasound))
        tx, ty = torch.tanh(raw[:, 0]) * self.max_translation, torch.tanh(raw[:, 1]) * self.max_translation
        angle = torch.tanh(raw[:, 2]) * self.max_rotation
        scale = torch.exp(torch.tanh(raw[:, 3]) * self.max_log_scale)
        cos = torch.cos(angle) * scale
        sin = torch.sin(angle) * scale
        theta = torch.stack(
            [torch.stack([cos, -sin, tx], dim=1), torch.stack([sin, cos, ty], dim=1)], dim=1
        )
        grid = F.affine_grid(theta, ultrasound.shape, align_corners=False)
        aligned = F.grid_sample(ultrasound, grid, mode="bilinear", padding_mode="zeros", align_corners=False)
        return aligned, theta


class UncertaintyAwareCrossModalGate(nn.Module):
    """Fuse ultrasound only where a learned confidence map supports it."""

    def __init__(self, channels: int, use_confidence: bool = True) -> None:
        super().__init__()
        self.use_confidence = bool(use_confidence)
        self.us_projection = nn.Conv2d(channels, channels, 1, bias=False)
        self.confidence = nn.Sequential(
            nn.Conv2d(channels * 2, channels, 1),
            nn.GroupNorm(min(8, channels), channels),
            nn.SiLU(inplace=True),
            nn.Conv2d(channels, 1, 1),
            nn.Sigmoid(),
        )
        self.gate = nn.Sequential(
            nn.Conv2d(channels * 2, channels, 1),
            nn.GroupNorm(min(8, channels), channels),
            nn.SiLU(inplace=True),
            nn.Conv2d(channels, channels, 1),
            nn.Sigmoid(),
        )
        self.out = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1, bias=False),
            nn.GroupNorm(min(8, channels), channels),
            nn.SiLU(inplace=True),
        )

    def forward(self, eit: torch.Tensor, ultrasound: torch.Tensor, available: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        ultrasound = self.us_projection(ultrasound)
        pair = torch.cat([eit, ultrasound], dim=1)
        confidence = self.confidence(pair) if self.use_confidence else torch.ones_like(eit[:, :1])
        gate = self.gate(pair)
        available = available[:, :, None, None]
        fused = self.out(eit + available * confidence * gate * ultrasound)
        return fused, confidence * available


class RegistrationRobustMultiModalEITNet(MultiModalEITNet):
    """Multi-modal EIT network with registration and uncertainty fallback.

    Ultrasound is first aligned by a bounded spatial transformer. Each fusion
    stage predicts a confidence map; low-confidence ultrasound features are
    automatically suppressed, leaving the EIT branch as the fallback path.
    """

    def __init__(
        self,
        voltage_dim: int = 208,
        base_channels: int = 24,
        output_channels: int = 1,
        attention_heads: int = 8,
        use_registration: bool = True,
        use_confidence: bool = True,
    ) -> None:
        super().__init__(voltage_dim, base_channels, output_channels, attention_heads)
        self.use_registration = bool(use_registration)
        self.use_confidence = bool(use_confidence)
        channels = [base_channels, base_channels * 2, base_channels * 4, base_channels * 8]
        self.registration = UltrasoundSpatialRegistration()
        self.fusions = nn.ModuleList(UncertaintyAwareCrossModalGate(c, use_confidence=use_confidence) for c in channels)

    def forward(
        self,
        eit_image: torch.Tensor,
        voltages: torch.Tensor,
        ultrasound: Optional[torch.Tensor] = None,
        ultrasound_available: Optional[torch.Tensor] = None,
    ) -> dict[str, torch.Tensor]:
        if ultrasound is None:
            ultrasound = torch.zeros_like(eit_image)
        if ultrasound_available is None:
            ultrasound_available = torch.ones((eit_image.shape[0], 1), device=eit_image.device, dtype=eit_image.dtype)
        ultrasound_available = ultrasound_available.to(dtype=eit_image.dtype, device=eit_image.device).reshape(-1, 1)
        if self.use_registration:
            aligned_ultrasound, theta = self.registration(ultrasound)
        else:
            aligned_ultrasound = ultrasound
            theta = ultrasound.new_zeros((ultrasound.shape[0], 2, 3))
            theta[:, 0, 0] = 1.0
            theta[:, 1, 1] = 1.0
        eit_features = self.eit_encoder(eit_image)
        us_features = self.us_encoder(aligned_ultrasound)
        fused_features = []
        confidence_maps = []
        for gate, eit_feature, us_feature in zip(self.fusions, eit_features, us_features):
            fused, confidence = gate(eit_feature, us_feature, ultrasound_available)
            fused_features.append(fused)
            confidence_maps.append(confidence)
        gamma, beta = self.voltage_conditioner(voltages)
        x = fused_features[-1] * (1.0 + 0.1 * torch.tanh(gamma)) + 0.1 * torch.tanh(beta)
        x = self.cross_attention(x, us_features[-1], ultrasound_available)
        x = self.bottleneck(x)
        x = self.decoder2(x, fused_features[-2])
        x = self.decoder1(x, fused_features[-3])
        x = self.decoder0(x, fused_features[-4])
        raw_residual = self.head(x)
        prediction = 0.05 + 2.95 * torch.sigmoid(
            raw_residual + torch.logit((eit_image.clamp(0.051, 2.949) - 0.05) / 2.95)
        )
        confidence_map = F.interpolate(confidence_maps[0], size=eit_image.shape[-2:], mode="bilinear", align_corners=False)
        return {
            "reconstruction": prediction,
            "residual": raw_residual,
            "segmentation_logits": self.segmentation_head(x),
            "confidence_map": confidence_map,
            "registration_theta": theta,
            "aligned_ultrasound": aligned_ultrasound,
        }
