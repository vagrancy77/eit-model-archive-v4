"""Physics- and topology-aware Boolean shape network for 2-D EIT.

The network represents each inclusion as a smooth outer body minus an
explicit inward-background field.  This makes a re-entrant boundary a
first-class prediction rather than a small residual of a foreground mask.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


def norm_layer(channels: int) -> nn.GroupNorm:
    groups = min(8, channels)
    while channels % groups:
        groups -= 1
    return nn.GroupNorm(groups, channels)


class ResidualBlock(nn.Module):
    def __init__(self, in_channels: int, out_channels: int) -> None:
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, 3, padding=1, bias=False)
        self.norm1 = norm_layer(out_channels)
        self.conv2 = nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False)
        self.norm2 = norm_layer(out_channels)
        self.skip = (
            nn.Identity()
            if in_channels == out_channels
            else nn.Conv2d(in_channels, out_channels, 1, bias=False)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = self.skip(x)
        x = F.silu(self.norm1(self.conv1(x)))
        x = self.norm2(self.conv2(x))
        return F.silu(x + residual)


class InputAdapter(nn.Module):
    """Turn a scale-dependent linear EIT image into stable spatial channels."""

    def __init__(self, fov_mask: np.ndarray) -> None:
        super().__init__()
        mask = torch.from_numpy(np.asarray(fov_mask, dtype=np.float32))[None, None]
        self.register_buffer("mask", mask)
        sobel = torch.tensor(
            [[-1.0, 0.0, 1.0], [-2.0, 0.0, 2.0], [-1.0, 0.0, 1.0]],
            dtype=torch.float32,
        ) / 8.0
        self.register_buffer("sobel_x", sobel[None, None])
        self.register_buffer("sobel_y", sobel.T[None, None])

    def forward(self, image: torch.Tensor) -> torch.Tensor:
        batch = image.shape[0]
        selected = image[:, 0, self.mask[0, 0].bool()]
        center = selected.median(dim=1).values.reshape(batch, 1, 1, 1)
        centered = (image - center) * self.mask
        selected_abs = centered[:, 0, self.mask[0, 0].bool()].abs()
        scale = torch.quantile(selected_abs, 0.985, dim=1).clamp_min(1e-5).reshape(batch, 1, 1, 1)
        signed = torch.clamp(centered / scale, -3.0, 3.0) / 3.0
        signed = signed * self.mask
        smooth3 = F.avg_pool2d(signed, 3, stride=1, padding=1) * self.mask
        smooth7 = F.avg_pool2d(signed, 7, stride=1, padding=3) * self.mask
        gx = F.conv2d(signed, self.sobel_x, padding=1)
        gy = F.conv2d(signed, self.sobel_y, padding=1)
        edge = torch.sqrt(gx.square() + gy.square() + 1e-8).clamp(0.0, 1.0) * self.mask
        return torch.cat((signed, smooth3, smooth7, gx, gy, edge), dim=1)


class AttentionDecoderStage(nn.Module):
    def __init__(self, in_channels: int, skip_channels: int, out_channels: int) -> None:
        super().__init__()
        self.reduce = nn.Conv2d(in_channels, out_channels, 1, bias=False)
        hidden = max(8, skip_channels // 2)
        self.skip_projection = nn.Conv2d(skip_channels, hidden, 1, bias=False)
        self.gate_projection = nn.Conv2d(out_channels, hidden, 1, bias=False)
        self.attention = nn.Conv2d(hidden, 1, 1)
        self.block = ResidualBlock(out_channels + skip_channels, out_channels)

    def forward(self, x: torch.Tensor, skip: torch.Tensor) -> torch.Tensor:
        x = F.interpolate(x, size=skip.shape[-2:], mode="bilinear", align_corners=False)
        x = self.reduce(x)
        gate = torch.sigmoid(self.attention(F.silu(self.skip_projection(skip) + self.gate_projection(x))))
        return self.block(torch.cat((x, skip * gate), dim=1))


class VoltageEncoder(nn.Module):
    """Encode the full KTC 76-by-31 voltage table without a legacy network."""

    def __init__(self, base: int) -> None:
        super().__init__()
        self.encoder = nn.Sequential(
            ResidualBlock(1, base),
            nn.Conv2d(base, base * 2, 3, stride=2, padding=1, bias=False),
            ResidualBlock(base * 2, base * 2),
            nn.Conv2d(base * 2, base * 4, 3, stride=2, padding=1, bias=False),
            ResidualBlock(base * 4, base * 4),
            nn.Conv2d(base * 4, base * 8, 3, stride=2, padding=1, bias=False),
            ResidualBlock(base * 8, base * 8),
        )
        self.projection = nn.Conv2d(base * 8, base * 16, 1)

    def forward(self, voltage: torch.Tensor) -> torch.Tensor:
        centered = voltage - voltage.median(dim=1, keepdim=True).values
        scale = torch.quantile(centered.abs(), 0.985, dim=1, keepdim=True).clamp_min(1e-6)
        table = torch.clamp(centered / scale, -4.0, 4.0).reshape(-1, 1, 76, 31) / 4.0
        return self.projection(F.adaptive_avg_pool2d(self.encoder(table), (4, 4)))


class MultiScaleImplicitHead(nn.Module):
    """Spline-like 4x4 + 16x16 fields with a learned 64x64 residual."""

    def __init__(self, base: int, bias: float) -> None:
        super().__init__()
        self.coarse = nn.Conv2d(base * 16, 1, 1)
        self.middle = nn.Conv2d(base * 4, 1, 1)
        self.fine = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))
        nn.init.zeros_(self.coarse.weight)
        nn.init.constant_(self.coarse.bias, bias)
        nn.init.zeros_(self.middle.weight)
        nn.init.zeros_(self.middle.bias)
        nn.init.zeros_(self.fine[-1].weight)
        nn.init.zeros_(self.fine[-1].bias)

    def forward(self, bottleneck: torch.Tensor, middle: torch.Tensor, fine: torch.Tensor) -> torch.Tensor:
        size = fine.shape[-2:]
        coarse = F.interpolate(self.coarse(bottleneck), size=size, mode="bicubic", align_corners=False)
        middle_field = F.interpolate(self.middle(middle), size=size, mode="bicubic", align_corners=False)
        return 1.20 * coarse + 0.80 * torch.tanh(middle_field) + 0.55 * torch.tanh(self.fine(fine))


class BooleanShapeNet(nn.Module):
    """Independent body-minus-cutout EIT reconstruction network."""

    def __init__(self, fov_mask: np.ndarray, base: int = 24, temperature: float = 0.42) -> None:
        super().__init__()
        self.base = base
        self.temperature = temperature
        self.adapter = InputAdapter(fov_mask)
        mask = torch.from_numpy(np.asarray(fov_mask, dtype=np.float32))[None, None]
        self.register_buffer("fov_mask", mask)

        self.stem = ResidualBlock(6, base)
        self.enc1 = ResidualBlock(base, base * 2)
        self.enc2 = ResidualBlock(base * 2, base * 4)
        self.enc3 = ResidualBlock(base * 4, base * 8)
        self.bottleneck = nn.Sequential(
            ResidualBlock(base * 8, base * 16),
            nn.Dropout2d(0.10),
            ResidualBlock(base * 16, base * 16),
        )
        self.voltage_encoder = VoltageEncoder(base)
        self.voltage_gate = nn.Parameter(torch.tensor(-0.8))
        self.dec3 = AttentionDecoderStage(base * 16, base * 8, base * 8)
        self.dec2 = AttentionDecoderStage(base * 8, base * 4, base * 4)
        self.dec1 = AttentionDecoderStage(base * 4, base * 2, base * 2)
        self.dec0 = AttentionDecoderStage(base * 2, base, base)

        # A dedicated decoder prevents the small inward-background signal from
        # being averaged away by the much larger body/contrast objectives.
        self.cut_dec3 = AttentionDecoderStage(base * 16, base * 8, base * 8)
        self.cut_dec2 = AttentionDecoderStage(base * 8, base * 4, base * 4)
        self.cut_dec1 = AttentionDecoderStage(base * 4, base * 2, base * 2)
        self.cut_dec0 = AttentionDecoderStage(base * 2, base, base)

        self.body_head = MultiScaleImplicitHead(base, bias=-0.55)
        self.cutout_head = MultiScaleImplicitHead(base, bias=-2.10)
        self.polarity_head = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 2, 1))
        self.mouth_head = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))
        self.contrast_head = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))
        self.concavity_confidence = nn.Sequential(
            nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(base * 16, base * 2),
            nn.SiLU(), nn.Dropout(0.10), nn.Linear(base * 2, 1),
        )
        self.amplitudes = nn.Sequential(
            nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(base * 16, 2)
        )
        nn.init.zeros_(self.polarity_head[-1].weight)
        nn.init.zeros_(self.polarity_head[-1].bias)
        nn.init.zeros_(self.mouth_head[-1].weight)
        nn.init.constant_(self.mouth_head[-1].bias, -2.5)
        nn.init.zeros_(self.contrast_head[-1].weight)
        nn.init.zeros_(self.contrast_head[-1].bias)
        nn.init.constant_(self.concavity_confidence[-1].bias, -0.5)

    def forward(self, image: torch.Tensor, voltage: torch.Tensor) -> dict[str, torch.Tensor]:
        adapted = self.adapter(image)
        e0 = self.stem(adapted)
        e1 = self.enc1(F.max_pool2d(e0, 2))
        e2 = self.enc2(F.max_pool2d(e1, 2))
        e3 = self.enc3(F.max_pool2d(e2, 2))
        bottleneck = self.bottleneck(F.max_pool2d(e3, 2))
        bottleneck = bottleneck + torch.sigmoid(self.voltage_gate) * self.voltage_encoder(voltage)
        d3 = self.dec3(bottleneck, e3)
        d2 = self.dec2(d3, e2)
        d1 = self.dec1(d2, e1)
        fine = self.dec0(d1, e0)
        cut_d3 = self.cut_dec3(bottleneck, e3)
        cut_d2 = self.cut_dec2(cut_d3, e2)
        cut_d1 = self.cut_dec1(cut_d2, e1)
        cut_fine = self.cut_dec0(cut_d1, e0)

        body_field = self.body_head(bottleneck, d2, fine)
        cutout_field = self.cutout_head(bottleneck, cut_d2, cut_fine)
        body_probability = torch.sigmoid(body_field / self.temperature) * self.fov_mask
        raw_cutout_probability = torch.sigmoid(cutout_field / self.temperature) * self.fov_mask
        confidence_logit = self.concavity_confidence(bottleneck)
        confidence = torch.sigmoid(confidence_logit)[:, :, None, None]
        mouth_logit = self.mouth_head(cut_fine)
        mouth_probability = torch.sigmoid(mouth_logit)
        # Differentiable exterior-connected growth. A cutout can affect the
        # Boolean result only when it is reachable from a predicted mouth.
        reachable = raw_cutout_probability * mouth_probability
        for _ in range(12):
            expanded = F.max_pool2d(reachable, 3, stride=1, padding=1)
            reachable = torch.maximum(reachable, expanded * raw_cutout_probability)
        reach_gate = torch.sqrt(reachable.clamp_min(1e-6))
        connected_cutout = raw_cutout_probability * (0.25 + 0.75 * reach_gate)
        cutout_probability = connected_cutout * (0.35 + 0.65 * confidence)
        foreground_probability = (body_probability * (1.0 - cutout_probability)).clamp(1e-6, 1.0 - 1e-6)

        polarity = torch.softmax(self.polarity_head(fine), dim=1)
        probabilities = torch.cat(
            (
                1.0 - foreground_probability,
                foreground_probability * polarity[:, 0:1],
                foreground_probability * polarity[:, 1:2],
            ),
            dim=1,
        ).clamp_min(1e-7)

        amplitude = self.amplitudes(bottleneck)
        negative = 0.10 + 0.90 * torch.sigmoid(amplitude[:, 0:1, None, None])
        positive = 0.10 + 1.15 * torch.sigmoid(amplitude[:, 1:2, None, None])
        signed_contrast = -negative * polarity[:, 0:1] + positive * polarity[:, 1:2]
        delta = foreground_probability * (
            signed_contrast + 0.20 * torch.tanh(self.contrast_head(fine))
        )
        delta = delta * self.fov_mask

        return {
            "adapted": adapted,
            "logits": torch.log(probabilities),
            "probabilities": probabilities,
            "body_field": body_field,
            "cutout_field": cutout_field,
            "body_probability": body_probability,
            "raw_cutout_probability": raw_cutout_probability,
            "connected_cutout_probability": connected_cutout,
            "cutout_probability": cutout_probability,
            "foreground_probability": foreground_probability,
            "polarity_probability": polarity,
            "mouth_logit": mouth_logit,
            "mouth_probability": mouth_probability,
            "confidence_logit": confidence_logit,
            "confidence": confidence,
            "delta": delta,
        }


@dataclass
class PhysicsOperator:
    jacobian: torch.Tensor
    node_to_raw_pixel: torch.Tensor
    voltage_scale: float = 2.0

    def loss(self, delta: torch.Tensor, voltage: torch.Tensor) -> torch.Tensor:
        with torch.amp.autocast("cuda", enabled=False):
            display_pixels = delta[:, 0].float()
            raw_pixels = torch.flip(display_pixels, dims=(1,)).flatten(1)
            nodes = raw_pixels[:, self.node_to_raw_pixel]
            predicted = self.voltage_scale * (nodes @ self.jacobian.float().T)
            measured = voltage.float()
            rms = torch.sqrt(measured.square().mean(dim=1, keepdim=True) + 1e-10)
            return torch.mean(((predicted - measured) / rms).square())
