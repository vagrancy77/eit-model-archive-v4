"""Direct EIT reconstruction with a conservative topology-residual branch."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


def norm_layer(channels: int) -> nn.GroupNorm:
    groups = min(8, channels)
    while channels % groups:
        groups -= 1
    return nn.GroupNorm(groups, channels)


class ResidualBlock(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, dropout: float = 0.0) -> None:
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, 3, padding=1, bias=False)
        self.norm1 = norm_layer(out_channels)
        self.conv2 = nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False)
        self.norm2 = norm_layer(out_channels)
        self.dropout = nn.Dropout2d(dropout) if dropout else nn.Identity()
        self.skip = (
            nn.Identity()
            if in_channels == out_channels
            else nn.Conv2d(in_channels, out_channels, 1, bias=False)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = self.skip(x)
        x = F.silu(self.norm1(self.conv1(x)))
        x = self.dropout(x)
        x = self.norm2(self.conv2(x))
        return F.silu(x + residual)


class InputAdapter(nn.Module):
    """Produce scale-stable signed, smoothed, and edge EIT channels."""

    def __init__(self, fov_mask: np.ndarray) -> None:
        super().__init__()
        mask = torch.from_numpy(np.asarray(fov_mask, dtype=np.float32))[None, None]
        self.register_buffer("mask", mask)
        sobel = torch.tensor(
            [[-1.0, 0.0, 1.0], [-2.0, 0.0, 2.0], [-1.0, 0.0, 1.0]],
            dtype=torch.float32,
        ) / 8.0
        self.register_buffer("sobel_x", sobel[None, None])
        self.register_buffer("sobel_y", sobel.T[None, None])

    def forward(self, image: torch.Tensor) -> torch.Tensor:
        batch = image.shape[0]
        selected = image[:, 0, self.mask[0, 0].bool()]
        center = selected.median(dim=1).values.reshape(batch, 1, 1, 1)
        centered = (image - center) * self.mask
        selected_abs = centered[:, 0, self.mask[0, 0].bool()].abs()
        scale = torch.quantile(selected_abs, 0.985, dim=1).clamp_min(1e-5).reshape(batch, 1, 1, 1)
        signed = torch.clamp(centered / scale, -3.0, 3.0) / 3.0
        signed = signed * self.mask
        smooth3 = F.avg_pool2d(signed, 3, stride=1, padding=1) * self.mask
        smooth7 = F.avg_pool2d(signed, 7, stride=1, padding=3) * self.mask
        grad_x = F.conv2d(signed, self.sobel_x, padding=1) * self.mask
        grad_y = F.conv2d(signed, self.sobel_y, padding=1) * self.mask
        edge = torch.sqrt(grad_x.square() + grad_y.square() + 1e-8).clamp(0.0, 1.0) * self.mask
        return torch.cat((signed, smooth3, smooth7, grad_x, grad_y, edge), dim=1)


class DecoderStage(nn.Module):
    def __init__(self, in_channels: int, skip_channels: int, out_channels: int) -> None:
        super().__init__()
        self.reduce = nn.Conv2d(in_channels, out_channels, 1, bias=False)
        hidden = max(8, skip_channels // 2)
        self.skip_projection = nn.Conv2d(skip_channels, hidden, 1, bias=False)
        self.gate_projection = nn.Conv2d(out_channels, hidden, 1, bias=False)
        self.attention = nn.Conv2d(hidden, 1, 1)
        self.block = ResidualBlock(out_channels + skip_channels, out_channels)

    def forward(self, x: torch.Tensor, skip: torch.Tensor) -> torch.Tensor:
        x = F.interpolate(x, size=skip.shape[-2:], mode="bilinear", align_corners=False)
        x = self.reduce(x)
        gate = torch.sigmoid(self.attention(F.silu(self.skip_projection(skip) + self.gate_projection(x))))
        return self.block(torch.cat((x, skip * gate), dim=1))


class VoltageEncoder(nn.Module):
    """Encode the ordered KTC 76-by-31 voltage table."""

    def __init__(self, base: int) -> None:
        super().__init__()
        self.features = nn.Sequential(
            ResidualBlock(1, base),
            nn.Conv2d(base, base * 2, 3, stride=2, padding=1, bias=False),
            ResidualBlock(base * 2, base * 2),
            nn.Conv2d(base * 2, base * 4, 3, stride=2, padding=1, bias=False),
            ResidualBlock(base * 4, base * 4),
            nn.Conv2d(base * 4, base * 8, 3, stride=2, padding=1, bias=False),
            ResidualBlock(base * 8, base * 8),
        )
        self.projection = nn.Conv2d(base * 8, base * 16, 1, bias=False)

    def forward(self, voltage: torch.Tensor) -> torch.Tensor:
        centered = voltage - voltage.median(dim=1, keepdim=True).values
        scale = torch.quantile(centered.abs(), 0.985, dim=1, keepdim=True).clamp_min(1e-6)
        table = torch.clamp(centered / scale, -4.0, 4.0).reshape(-1, 1, 76, 31) / 4.0
        return self.projection(F.adaptive_avg_pool2d(self.features(table), (4, 4)))


class TopologyResidualEITNet(nn.Module):
    """Strong direct reconstruction plus an exterior-connected removal residual."""

    def __init__(
        self,
        fov_mask: np.ndarray,
        base: int = 32,
        propagation_steps: int = 14,
        risk_aware: bool = False,
    ) -> None:
        super().__init__()
        self.base = base
        self.propagation_steps = propagation_steps
        self.risk_aware = risk_aware
        self.adapter = InputAdapter(fov_mask)
        mask = torch.from_numpy(np.asarray(fov_mask, dtype=np.float32))[None, None]
        self.register_buffer("fov_mask", mask)

        self.stem = ResidualBlock(6, base)
        self.enc1 = ResidualBlock(base, base * 2)
        self.enc2 = ResidualBlock(base * 2, base * 4)
        self.enc3 = ResidualBlock(base * 4, base * 8)
        self.bottleneck = nn.Sequential(
            ResidualBlock(base * 8, base * 16, dropout=0.08),
            ResidualBlock(base * 16, base * 16),
        )
        self.voltage_encoder = VoltageEncoder(base)
        self.fusion = ResidualBlock(base * 32, base * 16, dropout=0.08)

        self.base_dec3 = DecoderStage(base * 16, base * 8, base * 8)
        self.base_dec2 = DecoderStage(base * 8, base * 4, base * 4)
        self.base_dec1 = DecoderStage(base * 4, base * 2, base * 2)
        self.base_dec0 = DecoderStage(base * 2, base, base)

        self.topology_dec3 = DecoderStage(base * 16, base * 8, base * 8)
        self.topology_dec2 = DecoderStage(base * 8, base * 4, base * 4)
        self.topology_dec1 = DecoderStage(base * 4, base * 2, base * 2)
        self.topology_dec0 = DecoderStage(base * 2, base, base)

        self.base_logits_head = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 3, 1))
        self.sdf_head = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))
        self.delta_head = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))

        topology_input = base + 2
        self.topology_fusion = ResidualBlock(topology_input, base)
        self.cutout_head = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))
        self.mouth_head = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))
        self.local_gate_head = nn.Sequential(ResidualBlock(base, base), nn.Conv2d(base, 1, 1))
        self.case_gate_head = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(base * 16, base * 2),
            nn.SiLU(),
            nn.Dropout(0.10),
            nn.Linear(base * 2, 1),
        )
        if risk_aware:
            # The action gate sees both global EIT features and explicit
            # statistics of the proposed topological edit.  This separates
            # "a concavity may exist" from "this particular edit is safe".
            self.action_gate_head = nn.Sequential(
                nn.Linear(base * 16 + 10, base * 4),
                nn.SiLU(),
                nn.Dropout(0.12),
                nn.Linear(base * 4, base * 2),
                nn.SiLU(),
                nn.Linear(base * 2, 1),
            )

        nn.init.zeros_(self.cutout_head[-1].weight)
        nn.init.constant_(self.cutout_head[-1].bias, -2.8)
        nn.init.zeros_(self.mouth_head[-1].weight)
        nn.init.constant_(self.mouth_head[-1].bias, -3.0)
        nn.init.zeros_(self.local_gate_head[-1].weight)
        nn.init.constant_(self.local_gate_head[-1].bias, 1.0)
        nn.init.constant_(self.case_gate_head[-1].bias, -1.5)
        if risk_aware:
            nn.init.constant_(self.action_gate_head[-1].bias, -1.5)

    def _decode_base(
        self, bottleneck: torch.Tensor, e3: torch.Tensor, e2: torch.Tensor,
        e1: torch.Tensor, e0: torch.Tensor,
    ) -> torch.Tensor:
        x = self.base_dec3(bottleneck, e3)
        x = self.base_dec2(x, e2)
        x = self.base_dec1(x, e1)
        return self.base_dec0(x, e0)

    def _decode_topology(
        self, bottleneck: torch.Tensor, e3: torch.Tensor, e2: torch.Tensor,
        e1: torch.Tensor, e0: torch.Tensor,
    ) -> torch.Tensor:
        x = self.topology_dec3(bottleneck, e3)
        x = self.topology_dec2(x, e2)
        x = self.topology_dec1(x, e1)
        return self.topology_dec0(x, e0)

    def forward(self, image: torch.Tensor, voltage: torch.Tensor) -> dict[str, torch.Tensor]:
        adapted = self.adapter(image)
        e0 = self.stem(adapted)
        e1 = self.enc1(F.max_pool2d(e0, 2))
        e2 = self.enc2(F.max_pool2d(e1, 2))
        e3 = self.enc3(F.max_pool2d(e2, 2))
        image_latent = self.bottleneck(F.max_pool2d(e3, 2))
        voltage_latent = self.voltage_encoder(voltage)
        bottleneck = self.fusion(torch.cat((image_latent, voltage_latent), dim=1))

        base_features = self._decode_base(bottleneck, e3, e2, e1, e0)
        raw_base_logits = self.base_logits_head(base_features)
        sdf = torch.tanh(self.sdf_head(base_features)) * self.fov_mask
        geometry_bias = 1.20 * sdf
        base_logits = torch.cat(
            (
                raw_base_logits[:, 0:1] - geometry_bias,
                raw_base_logits[:, 1:2] + 0.5 * geometry_bias,
                raw_base_logits[:, 2:3] + 0.5 * geometry_bias,
            ),
            dim=1,
        )
        base_probabilities = torch.softmax(base_logits, dim=1)
        base_foreground = base_probabilities[:, 1:].sum(dim=1, keepdim=True) * self.fov_mask

        topology_features = self._decode_topology(bottleneck, e3, e2, e1, e0)
        topology_features = self.topology_fusion(
            torch.cat((topology_features, base_foreground.detach(), sdf.detach()), dim=1)
        )
        cutout_logit = self.cutout_head(topology_features)
        mouth_logit = self.mouth_head(topology_features)
        local_gate = torch.sigmoid(self.local_gate_head(topology_features))
        raw_cutout = torch.sigmoid(cutout_logit) * self.fov_mask
        mouth = torch.sigmoid(mouth_logit) * self.fov_mask
        class_gate_logit = self.case_gate_head(bottleneck)
        class_gate = torch.sigmoid(class_gate_logit)[:, :, None, None]

        # A valid inward correction must be reachable from a predicted mouth
        # or from background already identified by the direct reconstruction.
        seed = raw_cutout * torch.maximum(mouth, (1.0 - base_foreground).detach())
        reachable = seed
        for _ in range(self.propagation_steps):
            expanded = F.max_pool2d(reachable, 3, stride=1, padding=1)
            reachable = torch.maximum(reachable, expanded * raw_cutout)
        connected_cutout = raw_cutout * torch.sqrt(reachable.clamp_min(1e-6))
        proposal_cutout = connected_cutout * local_gate
        if self.risk_aware:
            entropy = -(base_probabilities * torch.log(base_probabilities.clamp_min(1e-7))).sum(
                dim=1, keepdim=True
            )
            statistic_maps = (raw_cutout, mouth, connected_cutout, proposal_cutout, entropy)
            statistics = torch.cat(
                tuple(value.mean(dim=(2, 3)) for value in statistic_maps)
                + tuple(value.amax(dim=(2, 3)) for value in statistic_maps),
                dim=1,
            )
            pooled = F.adaptive_avg_pool2d(bottleneck, 1).flatten(1)
            action_gate_logit = self.action_gate_head(torch.cat((pooled, statistics), dim=1))
            action_gate = torch.sigmoid(action_gate_logit)[:, :, None, None]
        else:
            action_gate_logit = torch.zeros_like(class_gate_logit)
            action_gate = torch.ones_like(class_gate)
        case_gate = class_gate * action_gate
        effective_cutout = proposal_cutout * case_gate
        corrected_foreground = (
            base_foreground * (1.0 - 0.98 * effective_cutout)
        ).clamp(1e-6, 1.0 - 1e-6)

        proposal_foreground = (
            base_foreground * (1.0 - 0.98 * proposal_cutout)
        ).clamp(1e-6, 1.0 - 1e-6)

        conditional_class = base_probabilities[:, 1:] / base_foreground.clamp_min(1e-6)
        conditional_class = conditional_class / conditional_class.sum(dim=1, keepdim=True).clamp_min(1e-6)
        probabilities = torch.cat(
            (1.0 - corrected_foreground, corrected_foreground * conditional_class), dim=1
        ).clamp_min(1e-7)
        probabilities = probabilities / probabilities.sum(dim=1, keepdim=True)
        proposal_probabilities = torch.cat(
            (1.0 - proposal_foreground, proposal_foreground * conditional_class), dim=1
        ).clamp_min(1e-7)
        proposal_probabilities = proposal_probabilities / proposal_probabilities.sum(
            dim=1, keepdim=True
        )
        delta = 1.25 * torch.tanh(self.delta_head(base_features)) * corrected_foreground * self.fov_mask

        return {
            "adapted": adapted,
            "base_logits": base_logits,
            "base_probabilities": base_probabilities,
            "base_foreground_probability": base_foreground,
            "sdf": sdf,
            "cutout_logit": cutout_logit,
            "raw_cutout_probability": raw_cutout,
            "mouth_logit": mouth_logit,
            "mouth_probability": mouth,
            "local_gate": local_gate,
            "case_gate_logit": class_gate_logit,
            "class_gate": class_gate,
            "action_gate_logit": action_gate_logit,
            "action_gate": action_gate,
            "case_gate": case_gate,
            "connected_cutout_probability": connected_cutout,
            "proposal_cutout_probability": proposal_cutout,
            "proposal_probabilities": proposal_probabilities,
            "effective_cutout_probability": effective_cutout,
            "foreground_probability": corrected_foreground,
            "probabilities": probabilities,
            "logits": torch.log(probabilities),
            "delta": delta,
        }


@dataclass
class PhysicsOperator:
    jacobian: torch.Tensor
    node_to_raw_pixel: torch.Tensor
    voltage_scale: float = 2.0

    def loss(self, delta: torch.Tensor, voltage: torch.Tensor) -> torch.Tensor:
        with torch.amp.autocast("cuda", enabled=False):
            display_pixels = delta[:, 0].float()
            raw_pixels = torch.flip(display_pixels, dims=(1,)).flatten(1)
            nodes = raw_pixels[:, self.node_to_raw_pixel]
            predicted = self.voltage_scale * (nodes @ self.jacobian.float().T)
            measured = voltage.float()
            rms = torch.sqrt(measured.square().mean(dim=1, keepdim=True) + 1e-10)
            return torch.mean(((predicted - measured) / rms).square())
