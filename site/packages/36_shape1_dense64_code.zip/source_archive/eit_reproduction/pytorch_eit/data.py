from __future__ import annotations

from pathlib import Path
from typing import Optional

import numpy as np
from scipy.ndimage import gaussian_filter, sobel
from scipy.spatial import cKDTree
try:
    from torch.utils.data import Dataset
except ModuleNotFoundError:  # data conversion can run without PyTorch
    Dataset = object  # type: ignore[assignment,misc]


def mesh_to_grid(nodes: np.ndarray, elements: np.ndarray, fields: np.ndarray, pixels: int = 64) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    nodes = np.asarray(nodes, dtype=float)[:, :2]
    elements = np.asarray(elements, dtype=np.int64)[:, :3]
    centers = nodes[elements].mean(axis=1)
    radius = float(np.max(np.linalg.norm(nodes, axis=1)))
    edges = np.linspace(-radius, radius, pixels + 1)
    centers_1d = edges[:-1] + np.diff(edges) * 0.5
    gx, gy = np.meshgrid(centers_1d, centers_1d, indexing="xy")
    points = np.column_stack([gx.reshape(-1), gy.reshape(-1)])
    closest_elements = cKDTree(centers).query(points)[1]
    closest_pixels = cKDTree(points).query(centers)[1]
    fields = np.asarray(fields, dtype=np.float32)
    grid = fields[:, closest_elements].reshape(fields.shape[0], pixels, pixels)
    mask = (gx * gx + gy * gy <= radius * radius).astype(np.float32)
    return grid, mask, closest_pixels


def render_ultrasound_proxy(conductivity: np.ndarray, mask: np.ndarray, seed: int) -> np.ndarray:
    """Render a reproducible B-mode-like proxy from a conductivity phantom.

    This is not a physical acoustic simulator. It is a geometry-consistent
    pretraining modality: interfaces are bright, depth is attenuated, and
    multiplicative speckle is applied before Gaussian point-spread blur.
    """
    rng = np.random.default_rng(int(seed))
    field = np.asarray(conductivity, dtype=np.float32)
    smooth = gaussian_filter(field, sigma=1.0)
    gx = sobel(smooth, axis=1, mode="nearest")
    gy = sobel(smooth, axis=2, mode="nearest")
    edges = np.sqrt(gx * gx + gy * gy)
    low_frequency = gaussian_filter(rng.rayleigh(0.35, size=field.shape).astype(np.float32), sigma=2.0)
    depth = np.linspace(1.1, 0.45, field.shape[1], dtype=np.float32)[None, :, None]
    image = 0.18 * smooth + 1.25 * edges + 0.22 * low_frequency
    image = image * depth
    image *= mask[None, :, :]
    image -= image.min(axis=(1, 2), keepdims=True)
    image /= np.maximum(image.max(axis=(1, 2), keepdims=True), 1e-6)
    return image.astype(np.float32)


class MultimodalCEMDataset(Dataset):
    def __init__(self, path: str | Path, split: str, modality_dropout: float = 0.0) -> None:
        data = np.load(path)
        indices = np.asarray(data[f"{split}_indices"], dtype=np.int64)
        self.eit_images = np.asarray(data["baseline_grid"], dtype=np.float32)[indices, None]
        self.targets = np.asarray(data["target_grid"], dtype=np.float32)[indices, None]
        self.ultrasound = np.asarray(data["ultrasound_grid"], dtype=np.float32)[indices, None]
        self.voltages = np.asarray(data["voltage_features"], dtype=np.float32)[indices]
        self.segmentations = np.asarray(data["segmentation_grid"], dtype=np.float32)[indices, None]
        self.modality_dropout = float(modality_dropout)

    def __len__(self) -> int:
        return self.targets.shape[0]

    def __getitem__(self, index: int) -> dict[str, np.ndarray | float]:
        available = 0.0 if self.modality_dropout > 0 and np.random.random() < self.modality_dropout else 1.0
        return {
            "eit_image": self.eit_images[index],
            "ultrasound": self.ultrasound[index],
            "voltages": self.voltages[index],
            "target": self.targets[index],
            "segmentation": self.segmentations[index],
            "ultrasound_available": np.asarray([available], dtype=np.float32),
        }
