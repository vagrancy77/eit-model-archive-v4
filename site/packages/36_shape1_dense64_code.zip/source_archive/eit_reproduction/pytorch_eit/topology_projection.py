"""Truth-blind discrete topology projection for topology-residual EIT outputs."""
from __future__ import annotations

import heapq

import numpy as np
from scipy.ndimage import binary_dilation, binary_fill_holes, distance_transform_edt, label


def _shortest_opening_path(
    foreground: np.ndarray,
    hole: np.ndarray,
    evidence: np.ndarray,
) -> tuple[list[tuple[int, int]], float]:
    """Find the most strongly supported path from an internal hole to exterior background."""
    height, width = foreground.shape
    external = ~binary_fill_holes(foreground)
    distance = np.full((height, width), np.inf, dtype=np.float64)
    previous_y = np.full((height, width), -1, dtype=np.int16)
    previous_x = np.full((height, width), -1, dtype=np.int16)
    queue: list[tuple[float, int, int]] = []
    for y, x in np.argwhere(hole):
        distance[y, x] = 0.0
        heapq.heappush(queue, (0.0, int(y), int(x)))

    destination: tuple[int, int] | None = None
    neighbors = ((-1, 0), (1, 0), (0, -1), (0, 1))
    while queue:
        cost, y, x = heapq.heappop(queue)
        if cost != distance[y, x]:
            continue
        if external[y, x]:
            destination = (y, x)
            break
        for dy, dx in neighbors:
            ny, nx = y + dy, x + dx
            if ny < 0 or ny >= height or nx < 0 or nx >= width:
                continue
            if hole[ny, nx]:
                step = 0.0
            elif external[ny, nx]:
                step = 0.0
            else:
                step = float(-np.log(np.clip(evidence[ny, nx], 1e-5, 1.0)))
            candidate = cost + step
            if candidate < distance[ny, nx]:
                distance[ny, nx] = candidate
                previous_y[ny, nx] = y
                previous_x[ny, nx] = x
                heapq.heappush(queue, (candidate, ny, nx))

    if destination is None:
        return [], 0.0
    path: list[tuple[int, int]] = []
    y, x = destination
    while not hole[y, x]:
        if foreground[y, x]:
            path.append((y, x))
        py, px = int(previous_y[y, x]), int(previous_x[y, x])
        if py < 0:
            break
        y, x = py, px
    values = np.asarray([evidence[y, x] for y, x in path], dtype=np.float64)
    confidence = float(np.exp(np.log(np.clip(values, 1e-5, 1.0)).mean())) if values.size else 1.0
    return path, confidence


def _fill_with_nearest_class(prediction: np.ndarray, hole: np.ndarray) -> None:
    foreground = prediction != 0
    if not foreground.any():
        return
    _, indices = distance_transform_edt(~foreground, return_indices=True)
    prediction[hole] = prediction[indices[0][hole], indices[1][hole]]


def resolve_closed_holes(
    prediction: np.ndarray,
    effective_cutout: np.ndarray,
    mouth: np.ndarray,
    case_gate: float,
    confidence_threshold: float,
    mouth_weight: float = 0.65,
    path_width: int = 1,
) -> tuple[np.ndarray, dict[str, float]]:
    """Open supported inward bays and fill unsupported spurious holes.

    The operation uses only predictions and learned confidence fields.  It does
    not inspect a target image.  Every resolved component is therefore either
    connected to exterior background or removed as an unsupported closed hole.
    """
    result = np.asarray(prediction, dtype=np.uint8).copy()
    foreground = result != 0
    holes = binary_fill_holes(foreground) & ~foreground
    components, count = label(holes)
    opened = 0
    filled = 0
    confidences: list[float] = []
    evidence = np.maximum(
        np.asarray(effective_cutout, dtype=np.float64),
        float(mouth_weight) * float(case_gate) * np.asarray(mouth, dtype=np.float64),
    )
    structure = np.ones((3, 3), dtype=bool)
    for component in range(1, count + 1):
        hole = components == component
        path, path_confidence = _shortest_opening_path(result != 0, hole, evidence)
        confidence = float(case_gate) * path_confidence
        confidences.append(confidence)
        if path and confidence >= confidence_threshold:
            path_mask = np.zeros_like(hole)
            yy, xx = zip(*path)
            path_mask[np.asarray(yy), np.asarray(xx)] = True
            if path_width > 1:
                for _ in range(path_width - 1):
                    path_mask = binary_dilation(path_mask, structure=structure)
            result[path_mask] = 0
            opened += 1
        else:
            _fill_with_nearest_class(result, hole)
            filled += 1
    return result, {
        "holes_seen": float(count),
        "holes_opened": float(opened),
        "holes_filled": float(filled),
        "mean_path_confidence": float(np.mean(confidences)) if confidences else float("nan"),
    }

