"""Local topology correction modules used by the v6 EIT experiment.

The corrector never synthesizes a complete reconstruction.  It predicts an
exterior-connected removal field and applies it to a frozen v4 foreground
probability.  A separate quantile regressor estimates case-level benefit and
risk so uncertain cases can fall back exactly to the frozen anchor.
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


def group_norm(channels: int) -> nn.GroupNorm:
    groups = min(8, channels)
    while channels % groups:
        groups -= 1
    return nn.GroupNorm(groups, channels)


class ResidualBlock(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, dilation: int = 1) -> None:
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(
                in_channels, out_channels, 3, padding=dilation, dilation=dilation, bias=False
            ),
            group_norm(out_channels),
            nn.SiLU(),
            nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False),
            group_norm(out_channels),
        )
        self.skip = (
            nn.Identity() if in_channels == out_channels else nn.Conv2d(in_channels, out_channels, 1)
        )

    def forward(self, value: torch.Tensor) -> torch.Tensor:
        return F.silu(self.block(value) + self.skip(value))


class DecoderBlock(nn.Module):
    def __init__(self, in_channels: int, skip_channels: int, out_channels: int) -> None:
        super().__init__()
        self.block = ResidualBlock(in_channels + skip_channels, out_channels)

    def forward(self, value: torch.Tensor, skip: torch.Tensor) -> torch.Tensor:
        value = F.interpolate(value, size=skip.shape[-2:], mode="bilinear", align_corners=False)
        return self.block(torch.cat((value, skip), dim=1))


class LocalTopologyCorrectorV6(nn.Module):
    """Predict a connected inward-boundary edit conditioned on a frozen anchor."""

    def __init__(
        self,
        input_channels: int = 15,
        base_channels: int = 24,
        propagation_steps: int = 14,
        maximum_removal: float = 0.995,
        enforce_connectivity: bool = True,
    ) -> None:
        super().__init__()
        self.input_channels = input_channels
        self.base_channels = base_channels
        self.propagation_steps = propagation_steps
        self.maximum_removal = maximum_removal
        self.enforce_connectivity = enforce_connectivity

        base = base_channels
        self.stem = ResidualBlock(input_channels, base)
        self.enc1 = ResidualBlock(base, base * 2)
        self.enc2 = ResidualBlock(base * 2, base * 4)
        self.enc3 = ResidualBlock(base * 4, base * 8)
        self.context = nn.Sequential(
            ResidualBlock(base * 8, base * 8, dilation=1),
            ResidualBlock(base * 8, base * 8, dilation=2),
            ResidualBlock(base * 8, base * 8, dilation=4),
        )
        self.dec2 = DecoderBlock(base * 8, base * 4, base * 4)
        self.dec1 = DecoderBlock(base * 4, base * 2, base * 2)
        self.dec0 = DecoderBlock(base * 2, base, base)
        self.refine = nn.Sequential(ResidualBlock(base, base), ResidualBlock(base, base))

        self.removal_head = nn.Conv2d(base, 1, 1)
        self.mouth_head = nn.Conv2d(base, 1, 1)
        self.local_confidence_head = nn.Conv2d(base, 1, 1)

        nn.init.zeros_(self.removal_head.weight)
        nn.init.constant_(self.removal_head.bias, -2.8)
        nn.init.zeros_(self.mouth_head.weight)
        nn.init.constant_(self.mouth_head.bias, -3.2)
        nn.init.zeros_(self.local_confidence_head.weight)
        nn.init.constant_(self.local_confidence_head.bias, 1.2)

    def forward(
        self,
        features: torch.Tensor,
        anchor_probabilities: torch.Tensor,
        fov_mask: torch.Tensor,
    ) -> dict[str, torch.Tensor]:
        e0 = self.stem(features)
        e1 = self.enc1(F.max_pool2d(e0, 2))
        e2 = self.enc2(F.max_pool2d(e1, 2))
        e3 = self.enc3(F.max_pool2d(e2, 2))
        value = self.context(e3)
        value = self.dec2(value, e2)
        value = self.dec1(value, e1)
        value = self.dec0(value, e0)
        value = self.refine(value)

        fov = fov_mask
        raw_removal = torch.sigmoid(self.removal_head(value)) * fov
        mouth = torch.sigmoid(self.mouth_head(value)) * fov
        local_confidence = torch.sigmoid(self.local_confidence_head(value)) * fov

        anchor_foreground = anchor_probabilities[:, 1:].sum(dim=1, keepdim=True) * fov
        # A cut must be connected to a learned mouth or to background already
        # visible in the anchor.  This suppresses isolated false cavities.
        if self.enforce_connectivity:
            seed = raw_removal * torch.maximum(mouth, (1.0 - anchor_foreground).detach())
            reachable = seed
            for _ in range(self.propagation_steps):
                expanded = F.max_pool2d(reachable, 3, stride=1, padding=1)
                reachable = torch.maximum(reachable, expanded * raw_removal)
            connected_removal = raw_removal * torch.sqrt(reachable.clamp_min(1e-6))
        else:
            # Ablation only: allow unconstrained local removals while retaining
            # the same parameter count and all other heads.
            connected_removal = raw_removal
        removal = connected_removal * local_confidence

        candidate_foreground = (
            anchor_foreground * (1.0 - self.maximum_removal * removal)
        ).clamp(1e-6, 1.0 - 1e-6)
        conditional_class = anchor_probabilities[:, 1:] / anchor_foreground.clamp_min(1e-6)
        conditional_class = conditional_class / conditional_class.sum(
            dim=1, keepdim=True
        ).clamp_min(1e-6)
        candidate_probabilities = torch.cat(
            (1.0 - candidate_foreground, candidate_foreground * conditional_class), dim=1
        ).clamp_min(1e-7)
        candidate_probabilities = candidate_probabilities / candidate_probabilities.sum(
            dim=1, keepdim=True
        )
        return {
            "raw_removal": raw_removal,
            "mouth": mouth,
            "local_confidence": local_confidence,
            "connected_removal": connected_removal,
            "removal": removal,
            "anchor_foreground": anchor_foreground,
            "candidate_foreground": candidate_foreground,
            "candidate_probabilities": candidate_probabilities,
        }


class DualRiskQuantileGate(nn.Module):
    """Estimate benefit and risk quantiles from truth-blind case features."""

    def __init__(self, input_features: int, hidden: int = 96, dropout: float = 0.12) -> None:
        super().__init__()
        self.input_features = input_features
        self.network = nn.Sequential(
            nn.Linear(input_features, hidden),
            nn.LayerNorm(hidden),
            nn.SiLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, hidden),
            nn.LayerNorm(hidden),
            nn.SiLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, hidden // 2),
            nn.SiLU(),
            nn.Linear(hidden // 2, 9),
        )

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        # Shape: batch x target(benefit, IoU loss, bank loss) x quantile(0.2,0.5,0.8)
        return self.network(features).reshape(-1, 3, 3)


def quantile_loss(
    prediction: torch.Tensor,
    target: torch.Tensor,
    quantiles: tuple[float, float, float] = (0.2, 0.5, 0.8),
) -> torch.Tensor:
    target = target[:, :, None]
    error = target - prediction
    q = prediction.new_tensor(quantiles)[None, None, :]
    raw = torch.maximum(q * error, (q - 1.0) * error)
    crossing = F.relu(prediction[:, :, :-1] - prediction[:, :, 1:]).mean()
    return raw.mean() + 0.15 * crossing
