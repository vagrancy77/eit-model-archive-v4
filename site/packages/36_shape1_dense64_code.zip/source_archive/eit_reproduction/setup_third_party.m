function status = setup_third_party(verbose)
%SETUP_THIRD_PARTY Load project-local EIT and ultrasound simulation tools.
%   STATUS = SETUP_THIRD_PARTY() adds the installed toolboxes to the
%   current MATLAB session only. It does not call SAVEPATH or modify the
%   MATLAB installation.

if nargin < 1
    verbose = true;
end

project_root = fileparts(mfilename('fullpath'));
third_party = fullfile(project_root, 'third_party');

status = struct( ...
    'eidors', false, ...
    'kwave', false, ...
    'must', false, ...
    'fieldii', false);

% EIDORS startup derives its root from PWD, so invoke it from its own root.
eidors_root = fullfile(third_party, 'eidors', 'eidors');
eidors_startup_file = fullfile(eidors_root, 'eidors_startup.m');
if isfile(eidors_startup_file)
    original_dir = pwd;
    restore_dir = onCleanup(@() cd(original_dir));
    cd(eidors_root);
    eidors_startup;
    status.eidors = exist('fwd_solve', 'file') == 2;
    clear restore_dir;
end

kwave_root = fullfile(third_party, 'k-wave', 'k-Wave');
if isfolder(kwave_root)
    addpath(genpath(kwave_root));
    status.kwave = exist('kspaceFirstOrder2D', 'file') == 2;
end

must_root = fullfile(third_party, 'must');
if isfolder(must_root)
    addpath(must_root);
    status.must = exist('simus', 'file') == 2;
end

fieldii_root = fullfile(third_party, 'field-ii');
fieldii_mfiles = fullfile(fieldii_root, 'm_files');
if isfolder(fieldii_mfiles)
    addpath(fieldii_mfiles);
elseif isfolder(fieldii_root)
    addpath(genpath(fieldii_root));
end
status.fieldii = exist('field_init', 'file') >= 2;

if verbose
    fprintf('\nProject-local toolbox status:\n');
    fprintf('  EIDORS : %s\n', state_text(status.eidors));
    fprintf('  k-Wave : %s\n', state_text(status.kwave));
    fprintf('  MUST   : %s\n', state_text(status.must));
    fprintf('  Field II: %s\n\n', state_text(status.fieldii));
end
end

function text = state_text(value)
if value
    text = 'loaded';
else
    text = 'not available';
end
end
