import unittest
from pathlib import Path

import numpy as np

try:
    import dolfinx  # noqa: F401
except (ImportError, OSError):
    dolfinx = None


@unittest.skipIf(dolfinx is None, "DOLFINx is not available in this interpreter")
class FenicsxBackendTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        from fenicsx_backend import ArrayProtocol, FenicsxCEMForward

        project_root = Path(__file__).resolve().parents[1]
        cls.saved = np.load(project_root / "outputs" / "simulation_data.npz")
        protocol = ArrayProtocol(
            cls.saved["excitation_matrix"],
            cls.saved["measurement_matrix"],
        )
        nodes = cls.saved["inverse_nodes"]
        cls.solver = FenicsxCEMForward(
            nodes=nodes,
            elements=cls.saved["inverse_elements"],
            electrode_positions=nodes[cls.saved["inverse_electrode_nodes"]],
            protocol=protocol,
            electrode_width=2.5 / 14.0,
            contact_impedance=0.01,
            current_amplitude=1.0,
        )

    def test_reciprocity(self) -> None:
        _, electrode_potentials = self.solver.solve_pairs(
            1.0,
            self.solver.protocol.excitation_pairs,
        )
        currents = np.zeros(
            (
                self.solver.n_electrodes,
                self.solver.protocol.n_excitations,
            )
        )
        for index, pair in enumerate(
            self.solver.protocol.excitation_pairs
        ):
            currents[pair[0], index] = 1.0
            currents[pair[1], index] = -1.0
        transfer_matrix = currents.T @ electrode_potentials
        np.testing.assert_allclose(
            transfer_matrix,
            transfer_matrix.T,
            rtol=1e-9,
            atol=1e-9,
        )

    def test_jacobian_matches_saved_scipy_backend(self) -> None:
        jacobian = self.solver.compute_jacobian(1.0)
        relative_error = np.linalg.norm(
            jacobian - self.saved["jacobian"]
        ) / np.linalg.norm(self.saved["jacobian"])
        self.assertLess(relative_error, 1e-8)


if __name__ == "__main__":
    unittest.main()
