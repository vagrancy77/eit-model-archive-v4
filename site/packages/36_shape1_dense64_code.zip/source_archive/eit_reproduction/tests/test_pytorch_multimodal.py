from __future__ import annotations

import unittest


try:
    import torch
    from pytorch_eit.models import MultiModalEITNet
except ModuleNotFoundError:
    torch = None
    MultiModalEITNet = None


@unittest.skipIf(torch is None, "PyTorch is installed in the WSL gn4ip-env")
class TestPyTorchMultimodal(unittest.TestCase):
    def test_forward_and_missing_ultrasound(self) -> None:
        model = MultiModalEITNet(voltage_dim=208, base_channels=8, attention_heads=4)
        eit = torch.ones(2, 1, 32, 32)
        voltage = torch.randn(2, 208)
        ultrasound = torch.rand(2, 1, 32, 32)
        present = model(eit, voltage, ultrasound, torch.ones(2, 1))
        missing = model(eit, voltage, ultrasound, torch.zeros(2, 1))
        self.assertEqual(tuple(present["reconstruction"].shape), (2, 1, 32, 32))
        self.assertEqual(tuple(present["segmentation_logits"].shape), (2, 1, 32, 32))
        self.assertTrue(torch.isfinite(present["reconstruction"]).all())
        self.assertTrue((present["reconstruction"] > 0).all())
        self.assertTrue(torch.isfinite(missing["reconstruction"]).all())


if __name__ == "__main__":
    unittest.main()

