import tempfile
import unittest
from pathlib import Path

import numpy as np

from eit_basic.cem import (
    build_cem_tikhonov_operator,
    reconstruct_cem_tikhonov,
)
from eit_basic.measurements import load_measurement_vector
from eit_basic.neural import MLPConfig, ResidualMLP
from eit_basic.synthetic import EllipticInclusion, apply_inclusions


class OperatorTests(unittest.TestCase):
    def test_reconstruction_operator_matches_single_solve(self) -> None:
        rng = np.random.default_rng(42)
        jacobian = rng.normal(size=(12, 7))
        voltage = rng.normal(size=12)
        operator = build_cem_tikhonov_operator(
            jacobian,
            lambda_reg=0.02,
            p=0.5,
        )
        expected = reconstruct_cem_tikhonov(
            jacobian,
            voltage,
            lambda_reg=0.02,
            p=0.5,
        )
        np.testing.assert_allclose(operator @ voltage, expected, rtol=1e-11)


class SyntheticTests(unittest.TestCase):
    def test_same_inclusion_rasterizes_on_mesh(self) -> None:
        nodes = np.array(
            [[-1.0, -1.0], [1.0, -1.0], [1.0, 1.0], [-1.0, 1.0]]
        )
        elements = np.array([[0, 1, 2], [0, 2, 3]])
        inclusion = EllipticInclusion(0.0, 0.0, 1.0, 1.0, 0.0, 0.25)
        conductivity = apply_inclusions(nodes, elements, (inclusion,))
        np.testing.assert_allclose(conductivity, 0.25)


class MeasurementTests(unittest.TestCase):
    def test_npy_loader_validates_measurement_count(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "frame.npy"
            np.save(path, np.arange(8.0))
            loaded = load_measurement_vector(path, expected_size=8)
            np.testing.assert_array_equal(loaded, np.arange(8.0))
            with self.assertRaises(ValueError):
                load_measurement_vector(path, expected_size=7)


class NeuralTests(unittest.TestCase):
    def test_training_and_model_round_trip(self) -> None:
        rng = np.random.default_rng(7)
        features = rng.normal(size=(80, 5)).astype(np.float32)
        mapping = rng.normal(size=(5, 4)).astype(np.float32)
        targets = np.tanh(features @ mapping).astype(np.float32)
        model = ResidualMLP(input_size=5, output_size=4, hidden_units=16)
        history = model.fit(
            features[:64],
            targets[:64],
            features[64:],
            targets[64:],
            config=MLPConfig(
                hidden_units=16,
                epochs=80,
                batch_size=16,
                learning_rate=3e-3,
                patience=20,
                seed=9,
            ),
        )
        self.assertLess(np.min(history.validation_loss), history.validation_loss[0])
        prediction = model.predict_correction(features[64:])
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "model.npz"
            config = MLPConfig(hidden_units=16)
            model.save(path, config)
            loaded = ResidualMLP.load(path)
            np.testing.assert_allclose(
                loaded.predict_correction(features[64:]),
                prediction,
                rtol=1e-6,
                atol=1e-6,
            )


if __name__ == "__main__":
    unittest.main()
