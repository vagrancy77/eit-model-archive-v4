import unittest
from types import SimpleNamespace

import numpy as np
import pyeit.eit.protocol as protocol
import pyeit.mesh as mesh

from eit_basic.cem import CEMForward
from eit_basic.noise import add_gaussian_noise_at_snr
from eit_basic.nonlinear import (
    CellGraphTV,
    NonlinearEITConfig,
    solve_absolute_eit,
)
from eit_basic.phantom import build_heart_lung_phantom


class ProtocolTests(unittest.TestCase):
    def test_standard_adjacent_protocol_has_208_measurements(self) -> None:
        protocol_object = protocol.create(
            n_el=16,
            dist_exc=1,
            step_meas=1,
            parser_meas="std",
        )
        self.assertEqual(protocol_object.ex_mat.shape, (16, 2))
        self.assertEqual(protocol_object.meas_mat.shape, (16, 13, 2))
        self.assertEqual(16 * 13, 208)


class MeshTests(unittest.TestCase):
    def test_forward_and_inverse_meshes_are_independent(self) -> None:
        forward_mesh = mesh.create(n_el=16, h0=0.12)
        inverse_mesh = mesh.create(n_el=16, h0=0.20)
        self.assertGreater(forward_mesh.n_elems, inverse_mesh.n_elems)
        np.testing.assert_allclose(
            forward_mesh.node[forward_mesh.el_pos, :2],
            inverse_mesh.node[inverse_mesh.el_pos, :2],
            atol=1e-12,
        )


class NoiseTests(unittest.TestCase):
    def test_noise_is_rescaled_to_requested_snr(self) -> None:
        signal = np.linspace(-2.0, 2.0, 208)
        _, _, actual_snr = add_gaussian_noise_at_snr(
            signal,
            snr_db=40.0,
            random_seed=123,
        )
        self.assertAlmostEqual(actual_snr, 40.0, places=10)


class PhantomTests(unittest.TestCase):
    def test_phantom_contains_all_three_conductivities(self) -> None:
        mesh_object = mesh.create(n_el=16, h0=0.18)
        _, conductivity = build_heart_lung_phantom(mesh_object)
        values = set(np.unique(conductivity).tolist())
        self.assertTrue({0.25, 1.0, 1.5}.issubset(values))


class CEMTests(unittest.TestCase):
    def setUp(self) -> None:
        self.mesh = mesh.create(n_el=8, h0=0.20)
        self.protocol = protocol.create(
            n_el=8,
            dist_exc=1,
            step_meas=1,
            parser_meas="std",
        )
        self.solver = CEMForward(
            self.mesh,
            self.protocol,
            electrode_width=0.30,
            contact_impedance=0.02,
            current_amplitude=1.0,
        )

    def test_all_cem_electrodes_have_finite_width(self) -> None:
        self.assertTrue(np.all(self.solver.electrodes.electrode_lengths > 0.0))

    def test_cem_reciprocity(self) -> None:
        conductivity = np.ones(self.mesh.n_elems)
        _, electrode_potentials = self.solver.solve_pairs(
            conductivity,
            self.protocol.ex_mat,
            amplitudes=1.0,
        )
        currents = np.zeros((8, self.protocol.n_exc))
        for index, pair in enumerate(self.protocol.ex_mat):
            currents[pair[0], index] = 1.0
            currents[pair[1], index] = -1.0
        transfer_matrix = currents.T @ electrode_potentials
        np.testing.assert_allclose(
            transfer_matrix,
            transfer_matrix.T,
            rtol=1e-9,
            atol=1e-9,
        )

    def test_cem_jacobian_matches_finite_difference(self) -> None:
        conductivity = np.ones(self.mesh.n_elems)
        jacobian = self.solver.compute_jacobian(conductivity)
        element_centers = self.mesh.node[
            self.mesh.element[:, :3], :2
        ].mean(axis=1)
        element_index = int(np.argmin(np.linalg.norm(element_centers, axis=1)))
        epsilon = 1e-5
        perturbed = conductivity.copy()
        perturbed[element_index] += epsilon
        baseline = self.solver.solve_protocol(conductivity).measurements
        changed = self.solver.solve_protocol(perturbed).measurements
        finite_difference = (changed - baseline) / epsilon
        relative_error = np.linalg.norm(
            finite_difference - jacobian[:, element_index]
        ) / np.linalg.norm(finite_difference)
        self.assertLess(relative_error, 2e-3)


class _LinearPositiveForward:
    def __init__(self, matrix: np.ndarray) -> None:
        self.matrix = matrix

    def solve_protocol(self, conductivity: np.ndarray) -> SimpleNamespace:
        return SimpleNamespace(measurements=self.matrix @ conductivity)

    def compute_jacobian(self, conductivity: np.ndarray) -> np.ndarray:
        del conductivity
        return self.matrix


class NonlinearTests(unittest.TestCase):
    def setUp(self) -> None:
        self.nodes = np.array(
            [
                [0.0, 0.0],
                [1.0, 0.0],
                [1.0, 1.0],
                [0.0, 1.0],
                [0.5, 0.5],
            ]
        )
        self.elements = np.array(
            [
                [0, 1, 4],
                [1, 2, 4],
                [2, 3, 4],
                [3, 0, 4],
            ]
        )

    def test_tv_laplacian_annihilates_constant_field(self) -> None:
        tv = CellGraphTV(self.nodes, self.elements)
        constant = np.ones(self.elements.shape[0])
        laplacian = tv.lagged_laplacian(constant, epsilon=1e-3)
        np.testing.assert_allclose(laplacian @ constant, 0.0, atol=1e-12)

    def test_nonlinear_solver_is_positive_and_decreases_objective(self) -> None:
        matrix = np.array(
            [
                [1.0, 0.2, 0.0, 0.1],
                [0.1, 1.0, 0.2, 0.0],
                [0.0, 0.1, 1.0, 0.2],
                [0.2, 0.0, 0.1, 1.0],
                [0.4, 0.3, 0.2, 0.1],
                [0.1, 0.2, 0.3, 0.4],
            ]
        )
        truth = np.array([0.4, 0.7, 1.4, 1.8])
        forward = _LinearPositiveForward(matrix)
        result = solve_absolute_eit(
            forward,
            measured_voltage=matrix @ truth,
            initial_conductivity=np.ones(4),
            nodes=self.nodes,
            elements=self.elements,
            config=NonlinearEITConfig(
                max_iterations=8,
                tv_weight=1e-6,
                l2_weight=1e-6,
                min_conductivity=0.05,
                max_conductivity=3.0,
            ),
        )
        objectives = [record.objective for record in result.history]
        self.assertGreater(len(objectives), 1)
        self.assertTrue(np.all(np.diff(objectives) < 0.0))
        self.assertTrue(np.all(result.conductivity > 0.0))
        self.assertLess(
            np.linalg.norm(result.conductivity - truth),
            np.linalg.norm(np.ones(4) - truth),
        )


if __name__ == "__main__":
    unittest.main()
