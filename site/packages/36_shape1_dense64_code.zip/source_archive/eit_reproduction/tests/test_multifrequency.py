from __future__ import annotations

import unittest


try:
    import torch
    from pytorch_eit.multifrequency import (
        FrequencyConditionedEITNet,
        IndependentFrequencyAnomalyNet,
        InstanceGeometryDispersionAnomalyNet,
        JointFrequencyAnomalyNet,
        SharedEncoderFrequencyHeadsNet,
        SharedGeometryFrequencyContrastAnomalyNet,
        SharedGeometryFrequencyContrastNet,
    )
except ModuleNotFoundError:
    torch = None
    FrequencyConditionedEITNet = None
    SharedEncoderFrequencyHeadsNet = None
    SharedGeometryFrequencyContrastNet = None
    IndependentFrequencyAnomalyNet = None
    InstanceGeometryDispersionAnomalyNet = None
    JointFrequencyAnomalyNet = None
    SharedGeometryFrequencyContrastAnomalyNet = None


@unittest.skipIf(torch is None, "PyTorch is installed in the WSL gn4ip-env")
class TestMultifrequencyModels(unittest.TestCase):
    def test_frequency_conditioned_forward(self) -> None:
        model = FrequencyConditionedEITNet(voltage_dim=16, latent_dim=32, base_channels=4)
        reconstruction = model(torch.randn(3, 16), torch.tensor([10.0, 50.0, 10.0]))
        self.assertEqual(tuple(reconstruction.shape), (3, 1, 64, 64))
        self.assertTrue(torch.isfinite(reconstruction).all())
        self.assertTrue((reconstruction > 0).all())

    def test_shared_encoder_and_frequency_heads_forward(self) -> None:
        model = SharedEncoderFrequencyHeadsNet(voltage_dim=16, latent_dim=32, base_channels=4, heads=4)
        reconstruction = model(torch.randn(2, 2, 16), torch.tensor([[10.0, 50.0], [10.0, 50.0]]))
        self.assertEqual(tuple(reconstruction.shape), (2, 2, 1, 64, 64))
        self.assertTrue(torch.isfinite(reconstruction).all())
        self.assertTrue((reconstruction > 0).all())

    def test_shared_geometry_frequency_contrast_factorization(self) -> None:
        model = SharedGeometryFrequencyContrastNet(voltage_dim=16, latent_dim=32, base_channels=4, heads=4)
        output = model(
            torch.randn(2, 2, 16),
            torch.tensor([[10.0, 50.0], [10.0, 50.0]]),
            return_auxiliary=True,
        )
        self.assertEqual(tuple(output["reconstruction"].shape), (2, 2, 1, 64, 64))
        self.assertEqual(tuple(output["geometry"].shape), (2, 1, 64, 64))
        self.assertEqual(tuple(output["contrast_logits"].shape), (2, 2, 1, 64, 64))
        self.assertEqual(tuple(output["frequency_background"].shape), (2, 2, 1, 1, 1))
        self.assertTrue((output["geometry"] >= 0).all() and (output["geometry"] <= 1).all())
        self.assertTrue(torch.isfinite(output["reconstruction"]).all())

    def test_general_four_frequency_models(self) -> None:
        voltage = torch.randn(2, 4, 16)
        coordinate = torch.tensor([[1.0, 2.0, 3.0, 4.0], [1.0, 2.0, 3.0, 4.0]])
        independent = IndependentFrequencyAnomalyNet(16, 4, latent_dim=32, base_channels=4)
        joint = JointFrequencyAnomalyNet(16, 4, latent_dim=32, base_channels=4)
        factorized = SharedGeometryFrequencyContrastAnomalyNet(16, 4, latent_dim=32, base_channels=4)
        self.assertEqual(tuple(independent(voltage).shape), (2, 4, 1, 64, 64))
        self.assertEqual(tuple(joint(voltage, coordinate).shape), (2, 4, 1, 64, 64))
        output = factorized(voltage, coordinate, return_auxiliary=True)
        self.assertEqual(tuple(output["reconstruction"].shape), (2, 4, 1, 64, 64))
        self.assertEqual(tuple(output["geometry"].shape), (2, 1, 64, 64))
        self.assertEqual(tuple(output["frequency_contrast"].shape), (2, 4, 1, 64, 64))
        self.assertTrue((output["reconstruction"] >= 0).all() and (output["reconstruction"] <= 1).all())

    def test_instance_dispersion_forward(self) -> None:
        voltage = torch.randn(2, 4, 16)
        coordinate = torch.tensor([[1.0, 2.0, 3.0, 4.0], [1.0, 2.0, 3.0, 4.0]])
        model = InstanceGeometryDispersionAnomalyNet(16, 4, latent_dim=32, base_channels=4, max_instances=3)
        output = model(voltage, coordinate, return_auxiliary=True)
        self.assertEqual(tuple(output["reconstruction"].shape), (2, 4, 1, 64, 64))
        self.assertEqual(tuple(output["instance_masks"].shape), (2, 3, 64, 64))
        self.assertEqual(tuple(output["instance_spectra"].shape), (2, 3, 4))
        self.assertTrue(torch.isfinite(output["reconstruction"]).all())
        self.assertTrue((output["instance_spectra"][:, :, 0] >= output["instance_spectra"][:, :, -1]).all())


if __name__ == "__main__":
    unittest.main()
