from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pyeit.eit.protocol as protocol
from pyeit.mesh.wrapper import PyEITMesh

from eit_basic.cem import CEMForward, build_cem_tikhonov_operator
from eit_basic.noise import add_gaussian_noise_at_snr
from eit_basic.synthetic import (
    SHAPE_KIND_TO_CODE,
    apply_diverse_inclusions,
    diverse_inclusions_to_arrays,
    sample_diverse_inclusions,
)


def parse_arguments() -> argparse.Namespace:
    project_root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Generate a more diverse independent CEM dataset.")
    parser.add_argument("--base-data", type=Path, default=project_root / "outputs" / "simulation_data.npz")
    parser.add_argument("--output", type=Path, default=project_root / "datasets" / "synthetic_cem_v3.npz")
    parser.add_argument("--samples", type=int, default=2048)
    parser.add_argument("--seed", type=int, default=20260803)
    parser.add_argument("--snr-min-db", type=float, default=25.0)
    parser.add_argument("--snr-max-db", type=float, default=70.0)
    parser.add_argument("--maximum-inclusions", type=int, default=5)
    parser.add_argument("--electrode-width", type=float, default=2.5 / 14.0)
    parser.add_argument("--contact-impedance", type=float, default=0.01)
    parser.add_argument("--current-amplitude", type=float, default=1.0)
    parser.add_argument("--lambda-reg", type=float, default=0.01)
    parser.add_argument("--jacobian-p", type=float, default=0.5)
    return parser.parse_args()


def make_mesh(nodes: np.ndarray, elements: np.ndarray, electrode_nodes: np.ndarray) -> PyEITMesh:
    return PyEITMesh(node=nodes, element=elements, perm=np.ones(elements.shape[0]), el_pos=electrode_nodes)


def main() -> None:
    arguments = parse_arguments()
    if arguments.samples < 16:
        raise ValueError("at least 16 samples are required for train/val/test splits")
    if arguments.snr_min_db > arguments.snr_max_db:
        raise ValueError("snr-min-db must not exceed snr-max-db")

    base = np.load(arguments.base_data)
    forward_mesh = make_mesh(base["forward_nodes"], base["forward_elements"], base["forward_electrode_nodes"])
    inverse_mesh = make_mesh(base["inverse_nodes"], base["inverse_elements"], base["inverse_electrode_nodes"])
    protocol_object = protocol.create(n_el=forward_mesh.el_pos.size, dist_exc=1, step_meas=1, parser_meas="std")
    forward_solver = CEMForward(
        forward_mesh,
        protocol_object,
        electrode_width=arguments.electrode_width,
        contact_impedance=arguments.contact_impedance,
        current_amplitude=arguments.current_amplitude,
    )
    inverse_solver = CEMForward(
        inverse_mesh,
        protocol_object,
        electrode_width=arguments.electrode_width,
        contact_impedance=arguments.contact_impedance,
        current_amplitude=arguments.current_amplitude,
    )
    background_forward = np.ones(forward_mesh.n_elems)
    background_inverse = np.ones(inverse_mesh.n_elems)
    voltage_background = forward_solver.solve_protocol(background_forward).measurements
    jacobian = inverse_solver.compute_jacobian(background_inverse)
    reconstruction_operator = build_cem_tikhonov_operator(jacobian, lambda_reg=arguments.lambda_reg, p=arguments.jacobian_p)

    n_samples = arguments.samples
    n_measurements = voltage_background.size
    maximum_inclusions = arguments.maximum_inclusions
    conductivity_forward = np.empty((n_samples, forward_mesh.n_elems), dtype=np.float32)
    conductivity_inverse = np.empty((n_samples, inverse_mesh.n_elems), dtype=np.float32)
    voltages_clean = np.empty((n_samples, n_measurements), dtype=np.float32)
    voltages_noisy = np.empty_like(voltages_clean)
    linear_reconstructions = np.empty((n_samples, inverse_mesh.n_elems), dtype=np.float32)
    snr_db = np.empty(n_samples, dtype=np.float32)
    inclusion_counts = np.empty(n_samples, dtype=np.int16)
    inclusion_centers = np.empty((n_samples, maximum_inclusions, 2), dtype=np.float32)
    inclusion_axes = np.empty_like(inclusion_centers)
    inclusion_angles = np.empty((n_samples, maximum_inclusions), dtype=np.float32)
    inclusion_conductivities = np.empty_like(inclusion_angles)
    inclusion_kinds = np.full((n_samples, maximum_inclusions), -1, dtype=np.int16)

    rng = np.random.default_rng(arguments.seed)
    print(
        f"Generating {n_samples} diverse nonlinear CEM samples on {forward_mesh.n_elems} forward elements...",
        flush=True,
    )
    for sample_index in range(n_samples):
        inclusions = sample_diverse_inclusions(rng, minimum_count=1, maximum_count=maximum_inclusions)
        sigma_forward = apply_diverse_inclusions(forward_mesh.node, forward_mesh.element, inclusions)
        sigma_inverse = apply_diverse_inclusions(inverse_mesh.node, inverse_mesh.element, inclusions)
        clean = forward_solver.solve_protocol(sigma_forward).measurements
        sample_snr = float(rng.uniform(arguments.snr_min_db, arguments.snr_max_db))
        noisy, _, _ = add_gaussian_noise_at_snr(
            clean,
            sample_snr,
            random_seed=int(rng.integers(0, np.iinfo(np.int32).max)),
        )
        difference = noisy - voltage_background
        linear = reconstruction_operator @ difference

        conductivity_forward[sample_index] = sigma_forward
        conductivity_inverse[sample_index] = sigma_inverse
        voltages_clean[sample_index] = clean
        voltages_noisy[sample_index] = noisy
        linear_reconstructions[sample_index] = linear
        snr_db[sample_index] = sample_snr
        inclusion_counts[sample_index] = len(inclusions)
        centers, axes, angles, values, kinds = diverse_inclusions_to_arrays(inclusions, maximum_inclusions)
        inclusion_centers[sample_index] = centers
        inclusion_axes[sample_index] = axes
        inclusion_angles[sample_index] = angles
        inclusion_conductivities[sample_index] = values
        inclusion_kinds[sample_index] = kinds
        if (sample_index + 1) % 50 == 0 or sample_index + 1 == n_samples:
            print(f"  {sample_index + 1}/{n_samples}", flush=True)

    shuffled = rng.permutation(n_samples)
    n_train = int(round(0.70 * n_samples))
    n_validation = int(round(0.15 * n_samples))
    train_indices = np.sort(shuffled[:n_train])
    validation_indices = np.sort(shuffled[n_train : n_train + n_validation])
    test_indices = np.sort(shuffled[n_train + n_validation :])
    voltage_scale = float(np.linalg.norm(voltage_background) / np.sqrt(n_measurements))

    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        arguments.output,
        forward_nodes=forward_mesh.node,
        forward_elements=forward_mesh.element,
        inverse_nodes=inverse_mesh.node,
        inverse_elements=inverse_mesh.element,
        inverse_electrode_nodes=inverse_mesh.el_pos,
        excitation_matrix=protocol_object.ex_mat,
        measurement_matrix=protocol_object.meas_mat,
        voltage_background=voltage_background.astype(np.float32),
        voltage_scale=np.array(voltage_scale, dtype=np.float32),
        jacobian=jacobian.astype(np.float32),
        reconstruction_operator=reconstruction_operator.astype(np.float32),
        conductivity_forward=conductivity_forward,
        conductivity_inverse=conductivity_inverse,
        voltages_clean=voltages_clean,
        voltages_noisy=voltages_noisy,
        voltage_differences=(voltages_noisy - voltage_background[None, :]).astype(np.float32),
        linear_reconstructions=linear_reconstructions,
        snr_db=snr_db,
        inclusion_counts=inclusion_counts,
        inclusion_centers=inclusion_centers,
        inclusion_axes=inclusion_axes,
        inclusion_angles=inclusion_angles,
        inclusion_conductivities=inclusion_conductivities,
        inclusion_kinds=inclusion_kinds,
        train_indices=train_indices,
        validation_indices=validation_indices,
        test_indices=test_indices,
    )
    summary = {
        "dataset": arguments.output.name,
        "samples": n_samples,
        "splits": {"train": int(train_indices.size), "validation": int(validation_indices.size), "test": int(test_indices.size)},
        "forward_elements": int(forward_mesh.n_elems),
        "inverse_elements": int(inverse_mesh.n_elems),
        "measurements": int(n_measurements),
        "snr_db_range": [arguments.snr_min_db, arguments.snr_max_db],
        "maximum_inclusions": maximum_inclusions,
        "seed": arguments.seed,
        "forward_model": "nonlinear complete electrode model",
        "inverse_crime_avoided": True,
        "electrode_width": arguments.electrode_width,
        "contact_impedance": arguments.contact_impedance,
        "current_amplitude": arguments.current_amplitude,
        "lambda_reg": arguments.lambda_reg,
        "jacobian_p": arguments.jacobian_p,
        "shape_kinds": SHAPE_KIND_TO_CODE,
    }
    with arguments.output.with_suffix(".json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    print(f"Dataset saved to {arguments.output.resolve()}")


if __name__ == "__main__":
    main()
