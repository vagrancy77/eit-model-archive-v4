"""Save last-checkpoint validation diagnostics; never promote failed candidates."""
import json
import time
import torch
from common import Lock, file_hash, write_json, verify_historical_sources
from localization_probe import DEST, LocalizedCorrection, evaluate
from readout import CacheDataset
from comsol_v4.paper_common import configure_runtime


def run():
    verify_historical_sources();configure_runtime(20261023)
    proto=json.loads((DEST/'protocol.json').read_text())
    for n,h in proto['source_hashes'].items():assert file_hash(__import__('pathlib').Path(__file__).with_name(n))==h
    ds=CacheDataset('val');rows=[]
    for p in sorted(DEST.glob('gate*/complete.json')):
        c=json.loads(p.read_text());model=LocalizedCorrection().cuda()
        ck=torch.load(p.parent/'last.pt',map_location='cpu',weights_only=True);model.load_state_dict(ck['model'])
        records,summary,coverage=evaluate(model,ds,p.parent/'last_validation_predictions.npz')
        history=json.loads((p.parent/'history.json').read_text());expected=history[-1]['validation']
        for group in summary:
            for k,v in summary[group].items():assert abs(v-expected[group][k])<1e-8,(group,k)
        row=dict(variant=c['variant'],seed=c['seed'],epoch=ck['epoch'],validation=summary,
            checkpoint_sha256=file_hash(p.parent/'last.pt'),predicted_band_bump_coverage=coverage,
            diagnostic_only=True,selected=False,test_read=False)
        write_json(p.parent/'last_validation_metrics.json',records);write_json(p.parent/'last_diagnostic.json',row);rows.append(row)
        del model
    write_json(DEST/'last_diagnostic_summary.json',dict(status='PASS',records=rows,training_updates=0,test_read=False))
    print('PASS: 4 last checkpoints replayed; no selection or test',flush=True)


if __name__=='__main__':
    with Lock():run()
