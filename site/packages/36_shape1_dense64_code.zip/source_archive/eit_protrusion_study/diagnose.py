"""Full train/validation audit; no test access and no training updates."""
import argparse
import json
import time
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader
from common import *
from comsol_v4.data_v6 import ComsolDataset
from comsol_v4.train import move
from comsol_v4.paper_common import configure_runtime


def run():
    configure_runtime(20261022); freeze_protocol()
    if (ROOT/'diagnostic_complete.json').exists(): return
    model, norm = initial_model()
    x, y, fov = grid_arrays(FINAL_DATASET_ROOT)
    captured = {}
    model.base_logits_head.register_forward_pre_hook(lambda m, a: captured.update(base_features=a[0].detach()))
    model.cutout_head.register_forward_pre_hook(lambda m, a: captured.update(topo_features=a[0].detach()))
    all_stats, resolution = {}, []
    cache = ROOT/'cache'; cache.mkdir(parents=True, exist_ok=True)
    for split in ('train', 'val'):
        done_path = ROOT/f'{split}_diagnostic.json'
        if done_path.exists():
            all_stats[split] = json.loads(done_path.read_text(encoding='utf-8'))['aggregate']
            resolution.extend(json.loads(done_path.read_text(encoding='utf-8'))['resolution'])
            continue
        ds = ComsolDataset(FINAL_DATASET_ROOT, split, norm)
        meta = {r['case_id']: r for r in ds.rows}
        record = {'base': [], 'after_cut': []}; res = []; tick = time.monotonic()
        # Frozen feature cache is a neural readout diagnostic, never FEM residual caching.
        items = []; split_cache = cache/split; split_cache.mkdir(exist_ok=True)
        for batch in DataLoader(ds, batch_size=24, shuffle=False):
            b = move(batch, 'cuda')
            with torch.no_grad(): out = model(b['features'])
            for i, cid in enumerate(batch['case_id']):
                row = meta[cid]; params = parameters(row)
                truth = batch['mask'][i, 0].numpy().astype(bool)
                added, neighbor, band = regions(params, truth, x, y)
                common = dict(case_id=cid, shape_class=row['shape_class'], position_id=row['position_id'],
                              bump_size_class=params.get('bump_size_class'), shape_subtype=params.get('shape_subtype'))
                pb = out['base_foreground_probability'][i, 0].cpu().numpy()
                pf = out['foreground_probability'][i, 0].cpu().numpy()
                for name, prob in (('base', pb), ('after_cut', pf)):
                    rec = {**common, **metrics(prob, truth, added, neighbor)}
                    if added.any():
                        rec.update(missed_before_cut=int(((pb<.5)&added).sum()),
                                   newly_deleted=int(((pb>=.5)&(pf<.5)&added).sum()),
                                   effective_cut_on_bump=float(out['effective_cutout_probability'][i,0].cpu().numpy()[added].mean()))
                    record[name].append(rec)
                if added.any():
                    el, cut, bump, analytic = masks(params, x, y)
                    hx = np.linspace(x[0], x[-1], 512)
                    he, hc, hb, hm = masks(params, hx, hx)
                    area64 = added.sum()*(x[1]-x[0])*(y[1]-y[0])
                    area512 = (he & hc & hb).sum()*(hx[1]-hx[0])**2
                    res.append({**common, 'bump_pixels': int(added.sum()),
                        'analytic_disagreement_pixels': int((analytic != truth).sum()),
                        'native_bump_area_mm2': float(area64*1e6), 'analytic512_bump_area_mm2': float(area512*1e6),
                        'relative_area_error': float((area64-area512)/area512),
                        'bump_radius_in_pixels': float(float(params['rB'])/(x[1]-x[0])),
                        'intrusion_in_pixels': float(float(params['rB'])*float(params['bump_intrusion_ratio'])/(x[1]-x[0]))})
                feats = torch.cat((captured['base_features'][i], captured['topo_features'][i],
                    out['base_foreground_probability'][i], out['foreground_probability'][i],
                    out['effective_cutout_probability'][i], out['sdf'][i]), 0).cpu().half().numpy()
                np.savez_compressed(split_cache/(cid+'.npz'), inputs=feats, truth=truth,
                    added=added, neighbor=neighbor, band=band, base=pb, after_cut=pf,
                    raw_cut=out['raw_cutout_probability'][i,0].cpu().numpy(),
                    effective_cut=out['effective_cutout_probability'][i,0].cpu().numpy(),
                    sdf=out['sdf'][i,0].cpu().numpy())
                items.append(common)
            if len(items)%120==0 or len(items)==len(ds):
                status('diagnosis_and_feature_cache', split=split, processed=len(items), total=len(ds),
                       elapsed_seconds=time.monotonic()-tick)
        aggregates = {k: aggregate(v) for k, v in record.items()}
        write_json(done_path, dict(aggregate=aggregates, records=record, resolution=res, metadata=items))
        all_stats[split] = aggregates; resolution.extend(res)
    write_json(ROOT/'diagnostic_complete.json', dict(status='PASS', test_read=False, training_updates=0,
        aggregate=all_stats, resolution_summary=aggregate(resolution),
        source_hashes={p.name: file_hash(p) for p in Path(__file__).parent.glob('*.py')}))
    status('diagnostic_complete', aggregate=all_stats['val'])


if __name__ == '__main__':
    with Lock():
        try: run()
        except Exception as exc:
            write_json(ROOT/'error.json', dict(error=repr(exc), time=time.time()))
            raise
