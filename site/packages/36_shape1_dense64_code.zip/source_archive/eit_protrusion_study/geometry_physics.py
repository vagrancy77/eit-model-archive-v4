"""Measurement-only bidirectional geometry refinement with fixed predicted material.

Starts at the saved output of an actually executed K3 loop. Every trial geometry
gets a fresh nonlinear FEM solve; neither true bump location nor labels enter
the update. This is a diagnostic optimization arm, not a trained shared network.
"""
import json
import time
import numpy as np
import torch
from torch.nn import functional as F
from common import *
from comsol_feedback.fem import TerminalFEM
from comsol_feedback_loop.model import DynamicPhysics
from comsol_v4.paper_common import configure_runtime


def rebuild(state,p,fov):
    return {**state,'fg':p,'sigma':(state['background_sigma']+p*(state['lesion_sigma']-state['background_sigma']))*fov,
            'eps_r':(state['background_eps']+p*(state['lesion_eps']-state['background_eps']))*fov}


def refine(state,observed,background,reference,physics):
    fv=torch.tensor(physics.solver.fov,device='cuda')[None,None];p0=state['fg'].detach()
    hard=(p0>=.5).float();band=(F.max_pool2d(hard,7,1,3)+F.max_pool2d(-hard,7,1,3)>0).float()*fv
    p=p0;probabilities=[p0.cpu().numpy()[0,0]];residuals=[];steps=[]
    with torch.no_grad():init=physics(rebuild(state,p,fv),observed,background,reference,hints=False)['voltage_mse'].mean()
    scale=float(init.clamp_min(1e-12));residuals.append(float(init))
    for iteration in range(3):
        p=p.detach().requires_grad_(True)
        value=physics(rebuild(state,p,fv),observed,background,reference,hints=False)['voltage_mse'].mean()
        penalty=2*((p-p0).square()*band).sum()/band.sum().clamp_min(1)
        objective=value/scale+penalty
        grad,=torch.autograd.grad(objective,p)
        g=grad*band;norm=torch.quantile(g[band.bool()].abs(),.99).clamp_min(1e-12)
        direction=(g/norm).clamp(-1,1);accepted=p.detach();chosen=0.;new_mse=float(value.detach())
        for step in (.05,.025,.0125):
            trial=(p.detach()-step*direction).clamp(1e-6,1-1e-6)*fv
            with torch.no_grad():
                v=physics(rebuild(state,trial,fv),observed,background,reference,hints=False)['voltage_mse'].mean()
                cost=v/scale+2*((trial-p0).square()*band).sum()/band.sum().clamp_min(1)
            if float(cost)<float(objective.detach()) and float(v)<=float(value.detach()):
                accepted=trial;chosen=step;new_mse=float(v);break
        p=accepted;probabilities.append(p.cpu().numpy()[0,0]);residuals.append(new_mse);steps.append(chosen)
    assert all(residuals[i+1]<=residuals[i]+1e-12 for i in range(3))
    return probabilities,residuals,steps


def run():
    configure_runtime(20261022);verify_historical_sources()
    audit=json.loads((ROOT/'stage_audit.json').read_text());x,y,fv=grid_arrays(FINAL_DATASET_ROOT)
    proto=dict(version='geometry-only-real-physics-v1',stage_protocol_sha256=audit['protocol_sha256'],
        source_hashes={n:file_hash(Path(__file__).with_name(n)) for n in ('common.py','geometry_physics.py')},
        iterations=3,step=.05,backtracking=[.05,.025,.0125,0],support='3 pixel band around predicted 0.5 contour; no label-defined ROI',
        objective='mean dual-frequency calibrated nonlinear voltage MSE / initial MSE + 2 mean squared change in band',
        material='all predicted lesion and background sigma/epsilon fixed at actual K3 output; shared geometry for both frequencies',
        role='diagnostic measurement-only optimization, not full shared-network retraining',test_read=False)
    path=ROOT/'geometry_physics_protocol.json'
    if path.exists() and json.loads(path.read_text())!=proto:raise RuntimeError('Physics geometry protocol changed')
    if not path.exists():write_json(path,proto)
    solver=TerminalFEM(x,y,fv);physics=DynamicPhysics(solver).cuda();dest=ROOT/'geometry_physics';dest.mkdir(exist_ok=True)
    output={}
    for split,data in audit['splits'].items():
        rows=[]
        for row in data['records']:
            cid=row['case_id'];rp=dest/(split+'_'+cid+'.json')
            if rp.exists():rows.append(json.loads(rp.read_text()));continue
            ck=torch.load(ROOT/'physics'/(split+'_'+cid+'_state.pt'),map_location='cuda',weights_only=True)
            tick=time.monotonic();probs,residual,steps=refine(ck['state'],ck['observed'],ck['background'],ck['reference'],physics)
            with np.load(ROOT/'cache'/split/(cid+'.npz')) as z:
                records=[metrics(p,z['truth'],z['added'],z['neighbor']) for p in probs]
            r={k:row[k] for k in ('case_id','shape_class','position_id','bump_size_class','shape_subtype')}
            r.update(stages=records,voltage_mse=residual,accepted_steps=steps,seconds=time.monotonic()-tick)
            np.savez_compressed(dest/(split+'_'+cid+'.npz'),probability=np.stack(probs));write_json(rp,r);rows.append(r)
            print(json.dumps(dict(phase='fixed_material_geometry_physics',split=split,case_id=cid,done=len(rows),total=len(data['records']),seconds=r['seconds'])),flush=True)
        output[split]=dict(records=rows,aggregate={str(i):aggregate([{**r,**r['stages'][i]} for r in rows]) for i in range(4)})
    write_json(ROOT/'geometry_physics_summary.json',dict(status='complete',protocol_sha256=file_hash(path),splits=output,test_read=False))

if __name__=='__main__':
    with Lock():run()
