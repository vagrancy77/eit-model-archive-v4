"""Read-only inference audit of all frozen best/last probes on TRAIN.

No optimizer, threshold changes, test access, or writes to existing checkpoints.
Validation summaries already saved by training are compared with training fit.
"""
import gc
import json
import time
from pathlib import Path

import torch

from common import ROOT, Lock, file_hash, initial_model, verify_historical_sources, write_json
import readout
import joint_probe
from comsol_v4.paper_common import configure_runtime

DEST = ROOT / 'scientific_review'


def run():
    verify_historical_sources()
    assert (ROOT / 'integration_summary.json').is_file()
    configure_runtime(20261023)
    DEST.mkdir(exist_ok=True)
    inputs = []
    for family, folder in [('frozen', 'candidates'), ('joint', 'joint_candidates')]:
        for p in sorted((ROOT / folder).glob('*/complete.json')):
            complete = json.loads(p.read_text())
            for stage in ('best', 'last'):
                cp = p.parent / (stage + '.pt')
                sha = file_hash(cp)
                if stage == 'best':
                    assert sha == complete['checkpoint_sha256']
                inputs.append(dict(family=family, variant=complete['variant'], seed=complete['seed'],
                                   stage=stage, path=str(cp), sha256=sha))
    assert len(inputs) == 32
    protocol = dict(version='training-fit-diagnostic-v1', inputs=inputs, split='train', count=3400,
                    source_hashes={n: file_hash(Path(__file__).with_name(n)) for n in
                                   ('review_fit.py', 'common.py', 'readout.py', 'joint_probe.py')},
                    purpose='Compare saved best/last TRAIN fit with existing validation; no new training or selection',
                    test_read=False)
    pp = DEST / 'fit_protocol.json'
    if pp.exists():
        assert json.loads(pp.read_text()) == protocol
    else:
        write_json(pp, protocol)
    results = []
    for family in ('frozen', 'joint'):
        current = [r for r in inputs if r['family'] == family]
        ds = None
        for row in current:
            tag = f"{row['variant']}_seed{row['seed']}_{row['stage']}"
            output = DEST / ('fit_' + tag + '.json')
            if output.exists():
                result = json.loads(output.read_text())
                assert result['checkpoint_sha256'] == row['sha256']
                results.append(result)
                continue
            started = time.monotonic()
            checkpoint = torch.load(row['path'], map_location='cpu', weights_only=True)
            if family == 'frozen':
                if ds is None:
                    ds = readout.CacheDataset('train')
                model = readout.GeometryReadout(60, row['variant']).cuda()
                model.load_state_dict(checkpoint['model'])
                _, summary = readout.evaluate(model, ds)
            else:
                base, norm = initial_model()
                if ds is None:
                    ds = joint_probe.Items('train', norm)
                model = joint_probe.JointGeometry(base).cuda()
                model.load_state_dict(checkpoint['model'])
                _, summary = joint_probe.evaluate(model, ds)
            result = dict(**{k: row[k] for k in ('family', 'variant', 'seed', 'stage')},
                          checkpoint_sha256=row['sha256'], checkpoint_epoch=checkpoint['epoch'],
                          train=summary, seconds=time.monotonic()-started, test_read=False)
            write_json(output, result)
            results.append(result)
            progress = dict(phase='training_fit_diagnostic', processed=len(results), total=len(inputs),
                            active=tag, updated_unix=time.time(), training_updates=0, test_read=False)
            write_json(DEST/'status.json', progress)
            print(json.dumps(progress), flush=True)
            del model, checkpoint
            torch.cuda.empty_cache()
        del ds
        gc.collect()
    write_json(DEST/'fit_summary.json', dict(status='complete', records=results,
               protocol_sha256=file_hash(pp), training_updates=0, test_read=False))
    write_json(DEST/'status.json', dict(phase='training_fit_diagnostic_complete', processed=32,
               total=32, updated_unix=time.time(), training_updates=0, test_read=False))


if __name__ == '__main__':
    with Lock():
        run()
