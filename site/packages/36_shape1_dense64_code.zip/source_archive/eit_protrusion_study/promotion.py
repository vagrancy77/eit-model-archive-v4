"""Validate a selected geometry candidate inside the existing real K3 loop.

Model selection uses full validation only. No test code is called here.
"""
import json
import time
import numpy as np
import torch
from torch import nn
from common import *
from joint_probe import JointGeometry
from readout import GeometryReadout,eligible
from comsol_feedback.fem import TerminalFEM
from comsol_feedback.verify import background_parameters
from comsol_feedback_loop.model import ClosedLoopEIT
from comsol_v4.data_v6 import ComsolDataset,read_measurements
from comsol_v4.paper_common import configure_runtime


class CorrectedInitial(nn.Module):
    def __init__(self,geometry):
        super().__init__();self.geometry=geometry;self.raw=None
        self.material_head.register_forward_hook(lambda m,a,o:setattr(self,'raw',o))
    @property
    def material_head(self):return self.geometry.base.material_head
    def forward(self,features):
        p,out=self.geometry(features);raw=self.raw;self.raw=None;fv=self.geometry.base.fov_mask
        ls=torch.nn.functional.softplus(raw[:,:2])+1e-6;le=(torch.nn.functional.softplus(raw[:,2:])+1e-6)*10000
        bs=out['background_sigma'];be=out['background_eps_r'];probs=out['base_probabilities'][:,1:]
        cond=probs/probs.sum(1,keepdim=True).clamp_min(1e-7);probs=torch.cat((1-p,p*cond),1)
        return {**out,'foreground_probability':p,'probabilities':probs,'logits':probs.clamp_min(1e-7).log(),
                'sigma':(bs+p*(ls-bs))*fv,'eps_r':(be+p*(le-be))*fv}


def choose():
    a=json.loads((ROOT/'candidate_comparison.json').read_text());b=json.loads((ROOT/'joint_comparison.json').read_text())
    options=[]
    for family,report in [('frozen',a),('joint',b)]:
        for rank in report['rankings']:
            options.append(dict(family=family,variant=rank['variant'],mean_local_iou=rank['mean_local_iou']))
    options.sort(key=lambda r:r['mean_local_iou'],reverse=True);winner=options[0]
    sub='joint_candidates' if winner['family']=='joint' else 'candidates'
    checkpoints=[ROOT/sub/f"{winner['variant']}_seed{seed}"/'best.pt' for seed in (20261022,20261023)]
    obj=dict(status='validation_selection_frozen',rankings=options,selected=winner,seed_policy='representative deployment seed fixed to 20261022; both seed summaries retained',
        checkpoints=[dict(path=str(p),sha256=file_hash(p)) for p in checkpoints],test_read=False,
        integration='selected geometry output before same pretrained K3 shared refiner; fresh nonlinear FEM each round; no retraining based on test')
    path=ROOT/'selection.json'
    if path.exists() and json.loads(path.read_text())!=obj:raise RuntimeError('Selection changed')
    if not path.exists():write_json(path,obj)
    return obj


def build(selection,solver):
    base,norm=initial_model();old=ClosedLoopEIT(base,solver).cuda()
    old.load_state_dict(torch.load(QUICK/'best.pt',map_location='cpu',weights_only=True)['model'])
    old.eval();candidate_base,_=initial_model();geometry=JointGeometry(candidate_base).cuda()
    ck=torch.load(selection['checkpoints'][0]['path'],map_location='cpu',weights_only=True)
    if selection['selected']['family']=='joint':geometry.load_state_dict(ck['model'])
    else:
        geometry.head.variant=selection['selected']['variant'];geometry.head.load_state_dict(ck['model'])
    candidate=ClosedLoopEIT(CorrectedInitial(geometry),solver).cuda()
    candidate.refiner.load_state_dict(old.refiner.state_dict());candidate.eval()
    for m in (old,candidate):
        for p in m.parameters():p.requires_grad_(False)
    return old,candidate,norm


def run():
    configure_runtime(20261022);verify_historical_sources();sel=choose()
    protocol=dict(version='candidate-live-loop-validation-v1',selection_sha256=file_hash(ROOT/'selection.json'),
        source_hashes={n:file_hash(Path(__file__).with_name(n)) for n in ('common.py','readout.py','joint_probe.py','promotion.py')},
        split='val',count=720,comparison='same current V4 and same K3 shared weights vs selected geometry+K3',test_read=False)
    pp=ROOT/'integration_protocol.json'
    if pp.exists() and json.loads(pp.read_text())!=protocol:raise RuntimeError('Integration protocol changed')
    if not pp.exists():write_json(pp,protocol)
    x,y,fv=grid_arrays(FINAL_DATASET_ROOT);solver=TerminalFEM(x,y,fv);old,candidate,norm=build(sel,solver)
    ds=ComsolDataset(FINAL_DATASET_ROOT,'val',norm);refs={};dest=ROOT/'integration_validation';dest.mkdir(exist_ok=True);records=[]
    for i,row in enumerate(ds.rows):
        path=dest/(row['case_id']+'.json')
        if path.exists():records.append(json.loads(path.read_text()));continue
        tick=time.monotonic();item=ds[i];params=parameters(row);v,b,_,_=read_measurements(row_case_path(FINAL_DATASET_ROOT,row))
        known=background_parameters(params)
        for g in known:
            if g not in refs:refs[g]=solver.solve(np.full((64,64),g))[0]
        args=[item['features'][None].cuda(),torch.tensor(v[None],device='cuda'),torch.tensor(b[None],device='cuda'),
              torch.tensor(np.stack([refs[g] for g in known])[None],device='cuda')]
        truth=item['mask'][0].numpy().astype(bool);added,neighbor,_=regions(params,truth,x,y)
        record=dict(case_id=row['case_id'],shape_class=row['shape_class'],position_id=row['position_id'],
            bump_size_class=params.get('bump_size_class'),shape_subtype=params.get('shape_subtype'),methods={})
        images={}
        for name,model in [('old',old),('candidate',candidate)]:
            with torch.no_grad():out=model(*args)
            for stage,p in [('before_loop',out['initial']['foreground_probability']),('K3',out['fg'])]:
                key=name+'_'+stage;images[key]=p[0,0].cpu().numpy()
                record['methods'][key]=metrics(images[key],truth,added,neighbor)
            record[name+'_voltage_mse']=out['voltage_mse_by_round'][0].cpu().tolist()
        record['seconds']=time.monotonic()-tick
        write_json(path,record);np.savez_compressed(dest/(row['case_id']+'.npz'),**images);records.append(record)
        if (i+1)%24==0 or i+1==len(ds):status('full_validation_live_loop',processed=i+1,total=len(ds),case_seconds=record['seconds'])
    summaries={key:aggregate([{**r,**r['methods'][key]} for r in records]) for key in records[0]['methods']}
    guards={key:eligible(summary,summaries['old_K3']) for key,summary in summaries.items() if key.startswith('candidate')}
    write_json(ROOT/'integration_summary.json',dict(status='complete',protocol_sha256=file_hash(pp),aggregate=summaries,guards=guards,
        test_read=False,records=records,note='Single fixed representative seed for expensive full live-loop validation; two seed geometry screening is separate.'))
    status('integration_validation_complete',guards=guards,summary={k:v['E'] for k,v in summaries.items()})

if __name__=='__main__':
    with Lock():run()
