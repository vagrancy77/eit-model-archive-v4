"""Isolated protrusion study. Historical model packages are never edited."""
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch
from scipy import ndimage as ndi

PROJECT = Path('E:/Codex/eit_reproduction')
sys.path.insert(0, str(PROJECT))
from comsol_v4.data_v6 import FINAL_DATASET_ROOT, grid_arrays, load_rows, row_case_path, file_hash
from comsol_feedback_loop.io import write_json, save_checkpoint

ROOT = Path('E:/Codex/protrusion_study_v1')
QUICK = Path('E:/Codex/complex_feedback_quick_v2')
BASE = Path('E:/Codex/eit_reproduction/outputs/final4840_paper_suite/runs/calibrated_seed20261016/best.pt')


def status(phase, **kw):
    obj = dict(phase=phase, updated_unix=time.time(), **kw)
    write_json(ROOT/'status.json', obj)
    print(json.dumps(obj, ensure_ascii=False), flush=True)


class Lock:
    def __enter__(self):
        ROOT.mkdir(parents=True, exist_ok=True)
        self.f = open(ROOT/'worker.lock', 'a+b')
        self.f.seek(0)
        if os.name == 'nt':
            import msvcrt
            if self.f.read(1) == b'': self.f.write(b'0'); self.f.flush()
            self.f.seek(0); msvcrt.locking(self.f.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(self.f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return self

    def __exit__(self, *args):
        self.f.close()


def masks(params, x, y):
    xx, yy = np.meshgrid(x, y)
    t = np.deg2rad(float(params['rotL']))
    dx, dy = xx-float(params['xL']), yy-float(params['yL'])
    el = ((dx*np.cos(t)+dy*np.sin(t))/float(params['aL']))**2 + ((-dx*np.sin(t)+dy*np.cos(t))/float(params['bL']))**2 <= 1
    cut = (xx-float(params['xC']))**2+(yy-float(params['yC']))**2 <= float(params['rC'])**2
    bump = (xx-float(params['xB']))**2+(yy-float(params['yB']))**2 <= float(params['rB'])**2
    return el, cut, bump, (el & ~cut) | bump


def regions(params, truth, x, y):
    """Label-defined audit/loss regions only. Never supplied as model inputs."""
    truth = np.asarray(truth, bool)
    boundary = ndi.distance_transform_edt(~truth)+ndi.distance_transform_edt(truth)
    band = boundary <= 2
    added = np.zeros_like(truth)
    neighbor = np.zeros_like(truth)
    if params['cls'] == 'E':
        el, cut, bump, _ = masks(params, x, y)
        added = truth & cut & bump & el
        # Fixed 3-pixel dilation, including non-lesion pixels on both shoulders.
        neighbor = ndi.binary_dilation(added, iterations=3) & ~truth
    return added, neighbor, band


def metrics(p, truth, added, neighbor, xstep=100/63):
    p = np.asarray(p).squeeze(); truth = np.asarray(truth, bool).squeeze()
    binary = p >= .5
    inter = (binary & truth).sum(); union = (binary | truth).sum()
    r = dict(iou=float(inter/max(union, 1)), dice=float(2*inter/max(binary.sum()+truth.sum(), 1)),
             false_positive_pixels=int((binary & ~truth).sum()), missed_pixels=int((~binary & truth).sum()))
    if added.any():
        recall = float(binary[added].mean()); fp = int(binary[neighbor].sum())
        r.update(bump_pixels=int(added.sum()), bump_recall=recall,
                 bump_probability=float(p[added].mean()), neighbor_false_addition=float(binary[neighbor].mean()),
                 local_iou=float((binary & added).sum()/max(added.sum()+fp, 1)),
                 bump_detected=bool(recall >= .75 and float(binary[neighbor].mean()) <= .1))
    return r


def aggregate(records):
    subsets = {'all': records, 'A': [r for r in records if r['shape_class']=='A'],
               'BCDE': [r for r in records if r['shape_class']!='A'],
               'E': [r for r in records if r['shape_class']=='E']}
    for size in ('small', 'medium', 'large'):
        subsets['E_'+size] = [r for r in records if r.get('bump_size_class')==size]
    result = {}
    for name, rows in subsets.items():
        values = {'count': len(rows)}
        for key in sorted({k for r in rows for k in r}):
            v = [r[key] for r in rows if isinstance(r.get(key), (int, float, bool))]
            if v: values[key] = float(np.mean(v))
        result[name] = values
    return result


def verify_historical_sources():
    p = json.loads((QUICK/'protocol.json').read_text(encoding='utf-8'))
    for rel, sha in p['source_hashes'].items():
        if file_hash(PROJECT/rel) != sha: raise RuntimeError('Historical source changed: '+rel)
    done = json.loads((QUICK/'training_complete.json').read_text())
    if file_hash(QUICK/'best.pt') != done['checkpoint_sha256']: raise RuntimeError('Quick checkpoint changed')
    if file_hash(BASE) != p['baseline_sha256']: raise RuntimeError('Original checkpoint changed')
    return p, done


def initial_model():
    from comsol_v4.train import load_checkpoint
    initial, norm, _, _ = load_checkpoint(BASE, torch.device('cuda'))
    ck = torch.load(QUICK/'best.pt', map_location='cpu', weights_only=True)
    initial.load_state_dict({k[len('initial.'):]: v for k, v in ck['model'].items() if k.startswith('initial.')})
    initial.eval()
    return initial, norm


def parameters(row):
    with np.load(row_case_path(FINAL_DATASET_ROOT, row), allow_pickle=False) as z:
        return json.loads(z['parameters_json'].item())


def freeze_protocol():
    p, done = verify_historical_sources()
    protocol = dict(version='protrusion-diagnosis-v1', dataset_contract=p['dataset_contract'],
        checkpoint=str(QUICK/'best.pt'), checkpoint_sha256=done['checkpoint_sha256'],
        development_splits=['train', 'val'], test_policy='not opened for diagnosis or candidate selection',
        geometry='actual truth intersect ellipse, bite circle and bump circle; parameter-defined before prediction',
        foreground_threshold=.5, metric_note='binary foreground p>=0.5; also inspect continuous p; not historical three-class argmax',
        detection_thresholds=dict(bump_recall=.75, neighbor_false_addition=.1),
        neighbor_band_pixels=3, boundary_band_pixels=2,
        six_tracks=['stage attribution', 'native versus analytic high resolution labels', 'fixed-material FEM counterfactual',
                    'bidirectional geometry readout', 'local geometric supervision', 'fresh FEM geometry coupling'],
        status='diagnostic protocol; candidate protocol is frozen separately before candidate training',
        old_long_training='preserve paused checkpoints; never resume automatically',
        historical_sources=p['source_hashes'])
    target = ROOT/'diagnostic_protocol.json'
    if target.exists():
        if json.loads(target.read_text(encoding='utf-8')) != protocol: raise RuntimeError('Diagnostic protocol mismatch')
    else: write_json(target, protocol)
    return protocol
