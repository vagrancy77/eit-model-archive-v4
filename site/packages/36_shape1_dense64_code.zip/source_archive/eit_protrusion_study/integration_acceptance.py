"""Check geometry-to-material coupling and unchanged K3 identity wiring."""
import torch
from common import *
from promotion import CorrectedInitial
from joint_probe import JointGeometry
from comsol_v4.data_v6 import ComsolDataset
from comsol_v4.paper_common import configure_runtime

configure_runtime(20261022);base,norm=initial_model();geometry=JointGeometry(base).cuda().eval()
wrapped=CorrectedInitial(geometry).eval();ds=ComsolDataset(FINAL_DATASET_ROOT,'train',norm)
x=ds[0]['features'][None].cuda()
with torch.no_grad():
    old=base(x);out=wrapped(x)
    errors={k:float((old[k]-out[k]).abs().max()) for k in ('foreground_probability','sigma','eps_r')}
    assert errors['foreground_probability']<1e-5 and errors['sigma']<1e-5 and errors['eps_r']<.1
    geometry.head.head.bias.fill_(.2);plus=wrapped(x)
    assert float((plus['foreground_probability']-out['foreground_probability']).max())>0
    assert float((plus['sigma']-out['sigma']).abs().max())>0
write_json(ROOT/'integration_acceptance.json',dict(status='PASS',zero_correction_errors=errors,
    geometry_changes_material_fields=True,truth_not_in_forward=True,shared_geometry_for_two_frequencies=True))
print('PASS',errors)
