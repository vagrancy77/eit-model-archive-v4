"""Record completed review with explicit unsolved outcome; preserve old status."""
import hashlib
import json
import time
from pathlib import Path
from datetime import datetime,timezone,timedelta

ROOT=Path('E:/Codex/protrusion_study_v1')
OUT=ROOT/'scientific_review'


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def write(p,o):p.write_text(json.dumps(o,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')


def main():
    audit=read(ROOT/'delivery_audit.json');assert audit['status']=='PASS' and audit['solution_found'] is False
    for name,h in audit['files'].items():assert sha(ROOT/name)==h
    quick=Path('E:/Codex/complex_feedback_quick_v2');p=read(quick/'protocol.json')
    for rel,h in p['source_hashes'].items():assert sha(Path('E:/Codex/eit_reproduction')/rel)==h
    assert sha(quick/'best.pt')==read(quick/'training_complete.json')['checkpoint_sha256']
    assert sha(Path('E:/Codex/eit_reproduction/outputs/final4840_paper_suite/runs/calibrated_seed20261016/best.pt'))==p['baseline_sha256']
    images=['fixed_cases.png','best_changes.png','worst_changes.png','overall_comparison.png',
            'train_validation_gap.png','localization_failures_20261022.png','localization_failures_20261023.png',
            'localization_training_curves.png']
    visual=dict(status='reviewed',method='actual generated images opened with view_image',
        images={n:sha(OUT/n) for n in images},
        observations=['Fixed cases often retain smooth boundary and missing bump; E_000034 remains missed.',
            'Largest local-IoU increases often recover one or a few pixels rather than the bump shape.',
            'E_000676 and other regressions add background pixels beside the bump.',
            'Explicitly supervised gates respond along much of the concave boundary, rather than isolating the true bump; both seeds fail precision guards.'],
        solution_found=False)
    write(OUT/'visual_review.json',visual)
    done=dict(status='completed_no_effective_solution',solution_found=False,
        completed_unix=time.time(),completed_at=datetime.now(timezone(timedelta(hours=8))).isoformat(timespec='seconds'),
        scope='All six research directions, 16 initial candidates, 720 real-K3 paired validation, 32 train-fit audits, 4 localization follow-on runs, statistics and image review',
        test_read=False,test_policy='Not opened because no stable effective validation candidate',
        historical_source_and_weights_verified=True,old_long_training_resumed=False,
        report_sha256=sha(ROOT/'RESULTS.md'),statistics_sha256=sha(ROOT/'summary_statistics.json'),
        audit_sha256=sha(ROOT/'delivery_audit.json'),visual_review_sha256=sha(OUT/'visual_review.json'))
    write(ROOT/'complete.json',done)
    previous=ROOT/'status.json';archive=OUT/'integration_status_original.json'
    if not archive.exists():write(archive,read(previous))
    write(previous,dict(phase='completed_screening_no_effective_solution',updated_unix=time.time(),solution_found=False,
        report='RESULTS.md',statistics='summary_statistics.json',test_read=False))
    print(json.dumps(done,ensure_ascii=False))


if __name__=='__main__':main()
