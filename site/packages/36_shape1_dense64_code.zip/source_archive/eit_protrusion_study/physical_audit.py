"""Fixed-material counterfactual and stage attribution on preselected cases.

Counterfactual uses true material ONLY as a diagnostic. Loop inference uses
measured voltages and predicted material, never true geometry or properties.
"""
import argparse
import json
import time
import numpy as np
import torch
from common import *
from comsol_feedback.fem import TerminalFEM, EPS0
from comsol_feedback.verify import background_parameters
from comsol_feedback_loop.model import ClosedLoopEIT
from comsol_v4.data_v6 import ComsolDataset, read_measurements
from comsol_v4.features import measurement_mask
from comsol_v4.paper_common import configure_runtime


def selection(split):
    chosen={};ordinary={}
    for row in sorted(load_rows(FINAL_DATASET_ROOT,split),key=lambda r:r['case_id']):
        p=parameters(row)
        if row['shape_class']=='E':
            key=(p['shape_subtype'],p['bump_size_class'],p['background_material'])
            if key not in chosen: chosen[key]=row
        else:
            key=(row['shape_class'],p['background_material'])
            if key not in ordinary: ordinary[key]=row
    return list(chosen.values())+list(ordinary.values())


def freeze():
    p=dict(version='physical-attribution-v1',splits={s:[r['case_id'] for r in selection(s)] for s in ('train','val')},
        selection='first ID per E subtype x size x background; first ID per A-D class x background',
        counterfactual='training E only, true fixed material, remove defined protrusion and replace with known background',
        physics='fresh nonlinear P1 FEM .0016m; .0010m mesh check on first E per size/background',
        noise='dataset contains no added noise; 0.1%,0.5%,1% levels are hypothetical sensitivity references only',
        stages='current jointly tuned V4 and all three live-FEM K3 stages',
        test_read=False,source_hashes={p.name:file_hash(p) for p in (Path(__file__),Path(__file__).with_name('common.py'))},
        checkpoint_sha256=file_hash(QUICK/'best.pt'))
    path=ROOT/'physical_protocol.json'
    if path.exists() and json.loads(path.read_text(encoding='utf-8'))!=p:raise RuntimeError('Physical protocol changed')
    if not path.exists():write_json(path,p)
    return p


def counterfactual(row,solver,refs):
    p=parameters(row);x,y,_=grid_arrays(FINAL_DATASET_ROOT)
    with np.load(row_case_path(FINAL_DATASET_ROOT,row),allow_pickle=False) as z:
        truth=z['lesion_mask'].astype(bool);added,_,_=regions(p,truth,x,y)
        gamma=z['conductivity_S_per_m']+1j*(2*np.pi*np.array([10000,50000])*EPS0)[:,None,None]*z['eps_r']
    obs,bg,_,_=read_measurements(row_case_path(FINAL_DATASET_ROOT,row))
    known=background_parameters(p);valid=measurement_mask();q=lambda v:v-np.roll(v,-1,-1)
    records=[]
    for f in range(2):
        if known[f] not in refs:refs[known[f]]=solver.solve(np.full((64,64),known[f]))[0]
        without=gamma[f].copy();without[added]=known[f]
        vt=solver.solve(gamma[f])[0];vw=solver.solve(without)[0]
        qb=q(bg[f]);rms=np.sqrt(np.mean(np.abs(qb[valid])**2))
        scale=qb.conj()/(np.abs(qb)**2+(.01*rms)**2)*valid
        signal=q(vt-vw)*scale;mismatch=q(vt-refs[known[f]]+bg[f]-obs[f])*scale
        signal_rms=float(np.sqrt(np.mean(np.abs(signal[valid])**2)))
        error_rms=float(np.sqrt(np.mean(np.abs(mismatch[valid])**2)))
        records.append(dict(frequency=[10000,50000][f],bump_signal_calibrated_rms=signal_rms,
            raster_fem_mismatch_calibrated_rms=error_rms,signal_to_mismatch=signal_rms/max(error_rms,1e-15),
            absolute_voltage_signal_rms_V=float(np.sqrt(np.mean(np.abs(q(vt-vw)[valid])**2))),
            relative_to_background_l2=float(np.linalg.norm(q(vt-vw)[valid])/np.linalg.norm(qb[valid]))))
    return dict(case_id=row['case_id'],shape_class='E',position_id=row['position_id'],bump_size_class=p['bump_size_class'],
                shape_subtype=p['shape_subtype'],background=p['background_material'],bump_pixels=int(added.sum()),frequencies=records)


def run(mode):
    configure_runtime(20261022);verify_historical_sources();protocol=freeze()
    dest=ROOT/'physics';dest.mkdir(exist_ok=True)
    x,y,fov=grid_arrays(FINAL_DATASET_ROOT);solver=TerminalFEM(x,y,fov)
    if mode in ('counterfactual','all'):
        refs={};fine_refs={};fine=None;fine_keys=set();results=[]
        for row in selection('train'):
            if row['shape_class']!='E':continue
            path=dest/('counterfactual_'+row['case_id']+'.json')
            p=parameters(row);key=(p['bump_size_class'],p['background_material']);check=key not in fine_keys;fine_keys.add(key)
            if path.exists():results.append(json.loads(path.read_text()));continue
            tick=time.monotonic();r=counterfactual(row,solver,refs)
            if check:
                if fine is None:fine=TerminalFEM(x,y,fov,spacing=.0010)
                r['mesh_check']=counterfactual(row,fine,fine_refs)
            r['seconds']=time.monotonic()-tick;write_json(path,r);results.append(r)
            print(json.dumps(dict(phase='counterfactual',case_id=row['case_id'],seconds=r['seconds'],done=len(results))),flush=True)
        write_json(ROOT/'counterfactual_summary.json',dict(protocol_sha256=file_hash(ROOT/'physical_protocol.json'),
            status='complete',cases=results,solver=solver.info,test_read=False,noise_note=protocol['noise'],
            limitation='Signal/mismatch ratio is not a statistical identifiability proof; this independent raster FEM differs from original COMSOL geometry.'))
    if mode in ('stages','all'):
        initial,norm=initial_model();model=ClosedLoopEIT(initial,solver).cuda()
        model.load_state_dict(torch.load(QUICK/'best.pt',map_location='cpu',weights_only=True)['model']);model.eval()
        for p in model.parameters():p.requires_grad_(False)
        refs={};all_records={}
        for split in ('train','val'):
            ds=ComsolDataset(FINAL_DATASET_ROOT,split,norm);byid={r['case_id']:i for i,r in enumerate(ds.rows)}
            records=[]
            for row in selection(split):
                path=dest/(split+'_'+row['case_id']+'.json')
                if path.exists():records.append(json.loads(path.read_text()));continue
                tick=time.monotonic();item=ds[byid[row['case_id']]];params=parameters(row)
                obs,bg,_,_=read_measurements(row_case_path(FINAL_DATASET_ROOT,row));known=background_parameters(params)
                for g in known:
                    if g not in refs:refs[g]=solver.solve(np.full((64,64),g))[0]
                args=[item['features'][None].cuda(),torch.tensor(obs[None],device='cuda'),torch.tensor(bg[None],device='cuda'),
                      torch.tensor(np.stack([refs[g] for g in known])[None],device='cuda')]
                with torch.no_grad():out=model(*args)
                truth=item['mask'][0].numpy().astype(bool);added,neighbor,_=regions(params,truth,x,y)
                probs=[out['initial']['foreground_probability']]+[s['fg'] for s in out['stages']]
                meta=dict(case_id=row['case_id'],shape_class=row['shape_class'],position_id=row['position_id'],
                          bump_size_class=params.get('bump_size_class'),shape_subtype=params.get('shape_subtype'))
                r={**meta,'stages':[metrics(p.cpu().numpy(),truth,added,neighbor) for p in probs],
                   'voltage_mse':out['voltage_mse_by_round'][0].cpu().tolist(),'seconds':time.monotonic()-tick}
                state={k:v.detach().cpu() for k,v in out['stages'][-1].items() if torch.is_tensor(v)}
                save_checkpoint(dest/(split+'_'+row['case_id']+'_state.pt'),dict(state=state,features=args[0].cpu(),
                    observed=args[1].cpu(),background=args[2].cpu(),reference=args[3].cpu()))
                np.savez_compressed(dest/(split+'_'+row['case_id']+'_stages.npz'),probability=np.stack([p[0,0].cpu().numpy() for p in probs]))
                write_json(path,r);records.append(r)
                print(json.dumps(dict(phase='live_K3_stage_audit',split=split,case_id=row['case_id'],done=len(records),
                    total=len(selection(split)),seconds=r['seconds'])),flush=True)
            all_records[split]=dict(records=records,aggregate={str(i):aggregate([{**r,**r['stages'][i]} for r in records]) for i in range(4)})
            write_json(ROOT/'stage_audit_partial.json',all_records)
        write_json(ROOT/'stage_audit.json',dict(status='complete',protocol_sha256=file_hash(ROOT/'physical_protocol.json'),splits=all_records,test_read=False))


if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--mode',choices=['counterfactual','stages','all'],default='all');args=a.parse_args()
    with Lock():run(args.mode)
