"""Render actual validation cases and native/high-resolution label evidence."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import ndimage as ndi

ROOT=Path('E:/Codex/protrusion_study_v1')

def main():
    report=json.loads((ROOT/'val_diagnostic.json').read_text(encoding='utf-8'))
    rows=[r for r in report['metadata'] if r['shape_class']=='E']
    selected=[]
    for size in ('small','medium','large'):
        selected.extend(sorted([r for r in rows if r['bump_size_class']==size],key=lambda r:r['case_id'])[:2])
    out=ROOT/'figures';out.mkdir(exist_ok=True)
    fig,axes=plt.subplots(len(selected),5,figsize=(13,14),constrained_layout=True)
    for i,row in enumerate(selected):
        with np.load(ROOT/'cache/val'/(row['case_id']+'.npz')) as z:
            y,x=np.where(ndi.binary_dilation(z['added'],iterations=6))
            crop=np.s_[max(y.min(),0):min(y.max()+1,64),max(x.min(),0):min(x.max()+1,64)]
            fields=[z['truth'],z['added'],z['base'],z['effective_cut'],z['after_cut']]
            for j,field in enumerate(fields):
                a=axes[i,j];a.imshow(field[crop],origin='lower',vmin=0,vmax=1,cmap='viridis',interpolation='nearest')
                if j>1:a.contour(z['truth'][crop],levels=[.5],colors=['white'],linewidths=.7)
                a.set_xticks([]);a.set_yticks([])
            axes[i,0].set_ylabel(row['case_id']+'\n'+row['bump_size_class'],fontsize=9)
    for a,t in zip(axes[0],['True foreground','Defined bump region','Base probability','Effective removal','Post-cut probability']):a.set_title(t,fontsize=10)
    fig.suptitle('Validation cases selected by ID and bump size, before candidate training\nWhite contour = truth; all columns use identical local crops',fontsize=12)
    fig.savefig(out/'diagnostic_cases.png',dpi=160);plt.close(fig)
    both=[]
    for split in ('train','val'):both+=json.loads((ROOT/f'{split}_diagnostic.json').read_text(encoding='utf-8'))['resolution']
    fig,axes=plt.subplots(1,3,figsize=(13,3.8),constrained_layout=True)
    for i,size in enumerate(('small','medium','large')):
        sub=[r for r in both if r['bump_size_class']==size]
        axes[i].scatter([r['analytic512_bump_area_mm2'] for r in sub],[r['native_bump_area_mm2'] for r in sub],s=8,alpha=.5)
        upper=max(r['analytic512_bump_area_mm2'] for r in sub)*1.15
        axes[i].plot([0,upper],[0,upper],'k--',lw=1);axes[i].set_title(size+f' (n={len(sub)})')
        axes[i].set_xlabel('Analytical 512-grid area (mm2)');axes[i].set_ylabel('Stored 64-grid area (mm2)')
    fig.savefig(out/'label_resolution.png',dpi=160);plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11,4.4),constrained_layout=True)
    baseline=report['aggregate']['after_cut']['E']
    variants=['delete_global','signed_global','signed_boundary','signed_local','probability_local']
    for v in variants:
        for seed in (20261022,20261023):
            hist=json.loads((ROOT/'candidates'/f'{v}_seed{seed}'/'history.json').read_text())
            axes[0].scatter([h['validation']['E']['neighbor_false_addition'] for h in hist],
                            [h['validation']['E']['bump_recall'] for h in hist],s=24,alpha=.6,label=v if seed==20261022 else None)
    axes[0].axvline(baseline['neighbor_false_addition']+.02,color='red',ls='--',lw=1)
    axes[0].scatter([baseline['neighbor_false_addition']],[baseline['bump_recall']],marker='*',s=150,color='black')
    axes[0].set_xlabel('False foreground near true bump');axes[0].set_ylabel('True bump recall');axes[0].legend(fontsize=7)
    axes[0].set_title('Frozen-feature probes: all validation epochs\nRed line = predeclared false-addition limit')
    cf=json.loads((ROOT/'counterfactual_summary.json').read_text())
    for i,size in enumerate(('small','medium','large')):
        rows=[r for r in cf['cases'] if r['bump_size_class']==size]
        ratio=[f['signal_to_mismatch'] for r in rows for f in r['frequencies']]
        axes[1].scatter(np.full(len(ratio),i)+np.linspace(-.15,.15,len(ratio)),ratio,s=18)
    axes[1].axhline(1,color='black',ls='--',lw=1);axes[1].set_xticks([0,1,2],['Small','Medium','Large'])
    axes[1].set_ylabel('Bump voltage signal / FEM-COMSOL mismatch');axes[1].set_title('24 preselected training cases, 2 frequencies\nFixed true materials; mesh spacing 1.6 mm')
    fig.savefig(out/'screening_and_physics.png',dpi=160);plt.close(fig)
    print(json.dumps({'figures':[str(p) for p in out.glob('*.png')]}))

if __name__=='__main__':main()
