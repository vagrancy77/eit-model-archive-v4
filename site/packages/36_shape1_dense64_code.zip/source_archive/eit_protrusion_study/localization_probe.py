"""Matched geometry-only gate-localization probes after the first review.

Frozen measurement-derived features; no FEM training. All labels are loss-only.
Historical sources and checkpoints are read-only. Existing train/val split only.
"""
import argparse
import json
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.data import DataLoader

from common import ROOT, Lock, file_hash, verify_historical_sources, write_json, save_checkpoint, aggregate, metrics
from readout import CacheDataset, objective, region_mean
from comsol_v4.paper_common import configure_runtime

DEST = ROOT/'localization_probe'
VARIANTS = ['gate_control', 'gate_supervised']
SEEDS = [20261022, 20261023]


class LocalizedCorrection(nn.Module):
    def __init__(self):
        super().__init__()
        self.body=nn.Sequential(nn.Conv2d(60,32,3,padding=1),nn.GroupNorm(8,32),nn.SiLU(),
            nn.Conv2d(32,32,3,padding=1),nn.GroupNorm(8,32),nn.SiLU(),
            nn.Conv2d(32,32,3,padding=1),nn.GroupNorm(8,32),nn.SiLU())
        self.gate=nn.Conv2d(32,1,1)
        self.correction=nn.Conv2d(32,1,1)
        nn.init.zeros_(self.gate.weight);nn.init.constant_(self.gate.bias,-2.)
        nn.init.zeros_(self.correction.weight);nn.init.zeros_(self.correction.bias)

    def forward(self, features, initial):
        z=self.body(features);gate_logits=self.gate(z)
        binary=(initial>=.5).float()
        band=(F.max_pool2d(binary,7,stride=1,padding=3)-(-F.max_pool2d(-binary,7,stride=1,padding=3)))>0
        p=initial+.9*band*torch.sigmoid(gate_logits)*torch.tanh(self.correction(z))
        return p.clamp(1e-6,1-1e-6),gate_logits,band.float()


def loss_for(p, logits, band, b, variant, fov):
    loss=objective(p.clamp(1e-6,1-1e-6),b,'probability_local',fov)
    if variant=='gate_supervised':
        target=b['added'].float()
        ce=F.binary_cross_entropy_with_logits(logits,target,reduction='none')
        valid=(target.sum((1,2,3))>0).float()
        positive=(region_mean(ce,target)*valid).sum()/valid.sum().clamp_min(1)
        # Negatives include BOTH shoulder tissue and background, and non-E cases.
        negative=region_mean(ce,band*(1-target)*fov).mean()
        loss=loss+.25*(positive+2*negative)
    return loss


def evaluate(model,ds,path=None):
    model.eval();records=[];preds=[];gates=[];coverage=[]
    with torch.no_grad():
        for raw in DataLoader(ds,batch_size=48):
            p,logits,band=model(raw['inputs'].cuda().float(),raw['after_cut'].cuda().float())
            p=(p*ds.fov.cuda()).cpu().numpy();q=logits.sigmoid().cpu().numpy();band=band.cpu().numpy()
            for j,idx in enumerate(raw['index'].tolist()):
                added=raw['added'][j,0].numpy().astype(bool)
                records.append({**ds.metadata[idx],**metrics(p[j],raw['truth'][j,0].numpy(),added,raw['neighbor'][j,0].numpy())})
                preds.append(p[j,0]);gates.append(q[j,0])
                if added.any():coverage.append(float(band[j,0][added].mean()))
    if path is not None:
        np.savez_compressed(path,probability=np.stack(preds),gate=np.stack(gates),case_ids=np.array([r['case_id'] for r in records]))
    return records,aggregate(records),float(np.mean(coverage))


def eligible(s,b):
    return s['all']['iou']>=b['all']['iou']-.002 and s['A']['iou']>=b['A']['iou']-.002 and s['E']['neighbor_false_addition']<=b['E']['neighbor_false_addition']+.005


def freeze():
    p=dict(version='explicit-localization-matched-probe-v1',variants=VARIANTS,seeds=SEEDS,
        min_epochs=12,max_epochs=24,patience=8,batch_size=48,lr=.0003,lr_patience=4,lr_factor=.5,min_lr=.00001,
        architecture='same 3-layer 32-channel body, separate gate and signed correction heads, predicted 3-pixel boundary band',
        inference='only frozen measurement-derived 60-channel features and initial foreground; no labels, class, subtype, bump parameters or true ROI',
        initialization='zero correction identity; gate bias -2; identical seeded weights and epoch order between arms',
        objective='both: original probability_local BCE/Dice/anchor/boundary/local objective; supervised arm adds .25*(bump-positive BCE + 2*predicted-band non-bump BCE) for gate logits',
        selection='E local IoU with original all/A IoU drop .002; stricter new neighbor-FP increase .005; retain epoch0 when none qualify',
        comparison_note='follow-on diagnostic after observed validation failures; not preregistered before first study; not an independent confirmatory validation',
        motivation='best/last train fit indicates localization and generalization failure; distinguish explicit bump localization from merely filling an edge',
        source_hashes={n:file_hash(Path(__file__).with_name(n)) for n in ('localization_probe.py','common.py','readout.py')},
        historical_review_sha256=file_hash(ROOT/'scientific_review/summary_statistics.json'),
        data='all 3400 train / 720 val, unchanged position groups',test_read=False,
        role='geometry-only follow-on screening; no FEM training; must evaluate successful frozen candidate in fresh real K3 separately')
    pp=DEST/'protocol.json'
    if pp.exists():assert json.loads(pp.read_text())==p
    else:write_json(pp,p)
    return p,file_hash(pp)


def progress(**kw):
    obj=dict(updated_unix=time.time(),**kw);write_json(DEST/'status.json',obj);print(json.dumps(obj),flush=True)


def acceptance():
    configure_runtime(20261023);m=LocalizedCorrection().cuda()
    x=torch.randn(2,60,16,16,device='cuda');p=torch.zeros(2,1,16,16,device='cuda');p[:,:,:,:8]=.8
    with torch.no_grad():
        q,g,band=m(x,p);assert (q-p).abs().max()<2e-6
        m.correction.bias.fill_(1);q,_,_=m(x,p);assert ((q-p)[band.bool()]>0).all()
        m.correction.bias.fill_(-1);q,_,_=m(x,p);assert ((q-p)[band.bool()]<1e-5).all()
        assert torch.max((q-p).abs()*(1-band))<2e-6
    m.zero_grad(set_to_none=True)
    with torch.no_grad():m.correction.bias.zero_()
    q,g,band=m(x,p)
    target=torch.zeros_like(p);target[:,:,7:9,7:9]=1
    b=dict(truth=p,after_cut=p,added=target,neighbor=band*(1-target),band=band)
    loss=loss_for(q,g,band,b,'gate_supervised',torch.ones_like(p[:1]));loss.backward()
    assert m.gate.weight.grad.abs().sum()>0 and m.correction.weight.grad.abs().sum()>0
    write_json(DEST/'acceptance.json',dict(status='PASS',identity=True,bidirectional_within_predicted_band=True,
        losses_reach_both_heads=True,truth_not_in_forward=True,test_read=False))
    print('ACCEPTANCE PASS',flush=True)


def run():
    verify_historical_sources();acceptance();proto,ph=freeze()
    progress(phase='loading_feature_cache',completed_runs=0,total_runs=4)
    tr,va=CacheDataset('train'),CacheDataset('val')
    baseline=json.loads((ROOT/'val_diagnostic.json').read_text())['aggregate']['after_cut']
    results=[]
    for seed in SEEDS:
        for variant in VARIANTS:
            dest=DEST/f'{variant}_seed{seed}';dest.mkdir(exist_ok=True)
            if (dest/'complete.json').exists():
                r=json.loads((dest/'complete.json').read_text())
                assert r['protocol_sha256']==ph and r['checkpoint_sha256']==file_hash(dest/'best.pt')
                results.append(r);continue
            configure_runtime(seed);model=LocalizedCorrection().cuda()
            opt=torch.optim.AdamW(model.parameters(),lr=proto['lr'],weight_decay=.0001)
            scheduler=torch.optim.lr_scheduler.ReduceLROnPlateau(opt,mode='max',factor=.5,patience=4,min_lr=proto['min_lr'])
            epoch=0;best=baseline['E']['local_iou'];best_epoch=0;bad=0;history=[]
            def ckpt():return dict(model=model.state_dict(),optimizer=opt.state_dict(),scheduler=scheduler.state_dict(),epoch=epoch,
                best_epoch=best_epoch,best=best,bad=bad,history=history,seed=seed,variant=variant,protocol_sha256=ph)
            if (dest/'last.pt').exists():
                ck=torch.load(dest/'last.pt',map_location='cpu',weights_only=True);assert ck['protocol_sha256']==ph
                model.load_state_dict(ck['model']);opt.load_state_dict(ck['optimizer']);scheduler.load_state_dict(ck['scheduler'])
                epoch=ck['epoch'];best=ck['best'];best_epoch=ck['best_epoch'];bad=ck['bad'];history=ck['history']
            else:save_checkpoint(dest/'best.pt',ckpt());save_checkpoint(dest/'last.pt',ckpt())
            start=epoch;fov=tr.fov.cuda()
            for epoch in range(start+1,proto['max_epochs']+1):
                if epoch>proto['min_epochs'] and bad>=proto['patience']:break
                tick=time.monotonic();model.train();total=0.;count=0
                gen=torch.Generator().manual_seed(seed+1000003*epoch)
                for raw in DataLoader(tr,batch_size=proto['batch_size'],shuffle=True,generator=gen):
                    b={k:v.cuda().float() for k,v in raw.items() if k!='index'}
                    p,g,band=model(b['inputs'],b['after_cut']);p=p*fov
                    loss=loss_for(p,g,band,b,variant,fov)
                    if not torch.isfinite(loss):raise FloatingPointError('nonfinite localization loss')
                    opt.zero_grad(set_to_none=True);loss.backward();nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True);opt.step()
                    total+=float(loss.detach())*len(raw['index']);count+=len(raw['index'])
                _,val,coverage=evaluate(model,va)
                passes=eligible(val,baseline);score=val['E']['local_iou'];scheduler.step(score if passes else 0.)
                if passes and score>best+1e-5:best=score;best_epoch=epoch;bad=0
                else:bad+=1
                history.append(dict(epoch=epoch,loss=total/count,validation=val,eligible=passes,seconds=time.monotonic()-tick,
                                    lr=opt.param_groups[0]['lr'],predicted_band_bump_coverage=coverage))
                if best_epoch==epoch:save_checkpoint(dest/'best.pt',ckpt())
                save_checkpoint(dest/'last.pt',ckpt());write_json(dest/'history.json',history)
                progress(phase='localization_training',variant=variant,seed=seed,epoch=epoch,selected_epoch=best_epoch,
                    epoch_seconds=history[-1]['seconds'],completed_runs=len(results),total_runs=4,eligible=passes,
                    local_iou=score,recall=val['E']['bump_recall'],false_add=val['E']['neighbor_false_addition'])
            best_ck=torch.load(dest/'best.pt',map_location='cpu',weights_only=True);model.load_state_dict(best_ck['model'])
            records,val,coverage=evaluate(model,va,dest/'validation_predictions.npz')
            write_json(dest/'validation_metrics.json',records)
            _,train,_=evaluate(model,tr)
            r=dict(status='complete',variant=variant,seed=seed,selected_epoch=best_epoch,epochs=len(history),validation=val,train=train,
                eligible=eligible(val,baseline),protocol_sha256=ph,checkpoint_sha256=file_hash(dest/'best.pt'),
                predicted_band_bump_coverage=coverage,test_read=False,physics_training=False)
            write_json(dest/'complete.json',r);results.append(r)
            del model,opt,scheduler;torch.cuda.empty_cache()
    write_json(DEST/'comparison.json',dict(status='complete',runs=results,protocol_sha256=ph,test_read=False,
        note='Review both seeds and actual shape/false fill before any promotion. Not a complete physical K3 retraining.'))
    progress(phase='localization_complete_needs_review',completed_runs=4,total_runs=4)


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--acceptance-only',action='store_true');args=ap.parse_args()
    DEST.mkdir(exist_ok=True)
    with Lock():
        if args.acceptance_only:acceptance()
        else:run()
