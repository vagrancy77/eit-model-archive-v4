"""Check a real train mini-batch before freezing/running joint probes."""
import torch
from common import *
from joint_probe import JointGeometry
from readout import objective
from comsol_v4.data_v6 import ComsolDataset
from comsol_v4.losses import compute_loss
from comsol_v4.paper_common import configure_runtime

configure_runtime(20261022)
base,norm=initial_model();model=JointGeometry(base).cuda()
ds=ComsolDataset(FINAL_DATASET_ROOT,'train',norm)
idx=next(i for i,r in enumerate(ds.rows) if r['shape_class']=='E');row=ds.rows[idx]
b={k:v[None].cuda() for k,v in ds[idx].items() if torch.is_tensor(v)}
with np.load(ROOT/'cache/train'/(row['case_id']+'.npz')) as z:
    for key in ('added','neighbor','band','after_cut'):b[key]=torch.tensor(z[key],device='cuda')[None,None]
b['truth']=b['mask'];p,out=model(b['features'])
assert (p-out['foreground_probability']).abs().max()<1e-5
loss=objective(p.clamp(1e-6,1-1e-6),b,'signed_local',model.base.fov_mask)
aux,_=compute_loss(out,b,model.base.fov_mask);loss=loss+.2*aux;loss.backward()
assert torch.isfinite(loss)
assert model.head.head.weight.grad.abs().sum()>0
assert sum(float(p.grad.abs().sum()) for p in model.base.base_logits_head.parameters() if p.grad is not None)>0
write_json(ROOT/'joint_acceptance.json',dict(status='PASS',real_training_case=row['case_id'],zero_identity=True,
    local_loss_finite=True,base_receives_gradient=True,head_receives_gradient=True,parameters_unchanged=True))
print('PASS',float(loss.detach()))
