"""End-to-end geometry-screening extension, explicitly without FEM training.

Motivation is recorded before training: frozen-feature local heads mostly
thicken the notch. Test whether measurement/backbone adaptation resolves this.
All final physics comparisons remain fresh nonlinear K3 evaluations.
"""
import json
import time
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.data import Dataset, DataLoader
from common import *
from readout import GeometryReadout, objective, eligible, region_mean
from comsol_v4.data_v6 import ComsolDataset
from comsol_v4.losses import compute_loss
from comsol_v4.paper_common import configure_runtime

VARIANTS=['joint_global','joint_local','joint_local_precise']
SEEDS=[20261022,20261023]

class JointGeometry(nn.Module):
    def __init__(self,base):
        super().__init__();self.base=base;self.head=GeometryReadout(60,'signed_local');self.captured={}
        base.base_logits_head.register_forward_pre_hook(lambda m,a:self.captured.update(b=a[0]))
        base.cutout_head.register_forward_pre_hook(lambda m,a:self.captured.update(t=a[0]))
    def forward(self,features):
        out=self.base(features)
        features=torch.cat((self.captured.pop('b'),self.captured.pop('t'),out['base_foreground_probability'],
            out['foreground_probability'],out['effective_cutout_probability'],out['sdf']),1)
        return self.head(features,out['foreground_probability'])*self.base.fov_mask,out

class Items(Dataset):
    def __init__(self,split,norm):
        ds=ComsolDataset(FINAL_DATASET_ROOT,split,norm)
        self.meta=json.loads((ROOT/f'{split}_diagnostic.json').read_text(encoding='utf-8'))['metadata'];self.items=[]
        for i,row in enumerate(ds.rows):
            item={k:v for k,v in ds[i].items() if torch.is_tensor(v)}
            with np.load(ROOT/'cache'/split/(row['case_id']+'.npz')) as z:
                for key in ('added','neighbor','band','after_cut'):item[key]=torch.from_numpy(z[key].copy())[None]
            item['truth']=item['mask'];item['index']=i;self.items.append(item)
    def __len__(self):return len(self.items)
    def __getitem__(self,i):return self.items[i]

def evaluate(model,ds,path=None):
    model.eval();records=[];pred=[]
    with torch.no_grad():
        for b in DataLoader(ds,batch_size=32):
            ps,_=model(b['features'].cuda());ps=ps.cpu().numpy()
            for j,i in enumerate(b['index'].tolist()):
                records.append({**ds.meta[i],**metrics(ps[j],b['mask'][j,0].numpy(),b['added'][j,0].numpy(),b['neighbor'][j,0].numpy())})
                pred.append(ps[j,0])
    if path is not None:np.savez_compressed(path,probability=np.stack(pred),case_ids=np.array([r['case_id'] for r in records]))
    return records,aggregate(records)

def freeze():
    p=dict(version='joint-geometry-screen-v1',variants=VARIANTS,seeds=SEEDS,max_epochs=24,minimum_epochs=12,patience=8,
        batch_size=24,base_lr=.00002,head_lr=.0003,lr_patience=4,weight_decay=.0001,
        source_hashes={n:file_hash(Path(__file__).with_name(n)) for n in ('common.py','readout.py','joint_probe.py')},
        old_checkpoint_sha256=file_hash(QUICK/'best.pt'),init='same jointly tuned V4 and zero geometry head for every arm',
        objectives='same global BCE/Dice and .2 native V4 auxiliary; local adds boundary and bump-neighbor balanced BCE; precise adds .5 extra neighbor BCE',
        selection='same predeclared validation local-IoU and overall/A/false-addition guards as first screen',
        distinction='backbone+geometry head trained end-to-end without FEM, followed separately by real K3 evaluation; no replacement of historical K3 source',
        test_read=False,reason='frozen-head supervision raised recall through notch filling; end-to-end matched controls test whether features can adapt')
    path=ROOT/'joint_protocol.json'
    if path.exists() and json.loads(path.read_text(encoding='utf-8'))!=p:raise RuntimeError('Joint protocol changed')
    if not path.exists():write_json(path,p)
    return p,file_hash(path)

def run():
    verify_historical_sources();proto,ph=freeze();initial,norm=initial_model();del initial
    status('loading_joint_training_data');tr,va=Items('train',norm),Items('val',norm)
    baseline=json.loads((ROOT/'val_diagnostic.json').read_text())['aggregate']['after_cut'];results=[]
    for seed in SEEDS:
        for variant in VARIANTS:
            configure_runtime(seed);dest=ROOT/'joint_candidates'/f'{variant}_seed{seed}';dest.mkdir(parents=True,exist_ok=True)
            if (dest/'complete.json').exists():
                r=json.loads((dest/'complete.json').read_text())
                if r['protocol_sha256']!=ph or r['checkpoint_sha256']!=file_hash(dest/'best.pt'):raise RuntimeError('Joint completion changed')
                results.append(r);continue
            base,_=initial_model();model=JointGeometry(base).cuda()
            opt=torch.optim.AdamW([dict(params=model.base.parameters(),lr=proto['base_lr']),dict(params=model.head.parameters(),lr=proto['head_lr'])],weight_decay=proto['weight_decay'])
            scheduler=torch.optim.lr_scheduler.ReduceLROnPlateau(opt,mode='max',factor=.5,patience=4,min_lr=1e-7)
            epoch=0;best_epoch=0;best=baseline['E']['local_iou'];bad=0;history=[]
            def ckpt():return dict(model=model.state_dict(),optimizer=opt.state_dict(),scheduler=scheduler.state_dict(),epoch=epoch,
                best_epoch=best_epoch,best_score=best,bad=bad,history=history,variant=variant,seed=seed,protocol_sha256=ph)
            if (dest/'last.pt').exists():
                ck=torch.load(dest/'last.pt',map_location='cpu',weights_only=True)
                if ck['protocol_sha256']!=ph:raise RuntimeError('Joint resume mismatch')
                model.load_state_dict(ck['model']);opt.load_state_dict(ck['optimizer']);scheduler.load_state_dict(ck['scheduler'])
                epoch=ck['epoch'];best_epoch=ck['best_epoch'];best=ck['best_score'];bad=ck['bad'];history=ck['history']
            else:save_checkpoint(dest/'best.pt',ckpt());save_checkpoint(dest/'last.pt',ckpt())
            start=epoch
            for epoch in range(start+1,proto['max_epochs']+1):
                if epoch>proto['minimum_epochs'] and bad>=proto['patience']:break
                tick=time.monotonic();model.train();loss_sum=0.;count=0;fv=model.base.fov_mask
                gen=torch.Generator().manual_seed(seed+1000003*epoch)
                for raw in DataLoader(tr,batch_size=proto['batch_size'],shuffle=True,generator=gen):
                    b={k:v.cuda() for k,v in raw.items() if k!='index'}
                    p,out=model(b['features']);loss=objective(p.clamp(1e-6,1-1e-6),b,'signed_global' if variant=='joint_global' else 'signed_local',fv)
                    native,_=compute_loss(out,b,fv);loss=loss+.2*native
                    if variant=='joint_local_precise':
                        ce=F.binary_cross_entropy(p.clamp(1e-6,1-1e-6),b['truth'],reduction='none')
                        valid=(b['added'].sum((1,2,3))>0).float()
                        loss=loss+.5*(region_mean(ce,b['neighbor'])*valid).sum()/valid.sum().clamp_min(1)
                    if not torch.isfinite(loss):raise FloatingPointError('Nonfinite joint loss')
                    opt.zero_grad(set_to_none=True);loss.backward();nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True);opt.step()
                    loss_sum+=float(loss.detach())*len(raw['index']);count+=len(raw['index'])
                records,summary=evaluate(model,va);score=summary['E']['local_iou'];passes=eligible(summary,baseline)
                scheduler.step(score if passes else 0)
                improved=passes and score>best+1e-5
                if improved:best=score;best_epoch=epoch;bad=0
                else:bad+=1
                history.append(dict(epoch=epoch,loss=loss_sum/count,validation=summary,eligible=passes,seconds=time.monotonic()-tick,
                                    lr=[g['lr'] for g in opt.param_groups]))
                if improved:save_checkpoint(dest/'best.pt',ckpt())
                save_checkpoint(dest/'last.pt',ckpt());write_json(dest/'history.json',history)
                status('joint_geometry_training',variant=variant,seed=seed,epoch=epoch,selected_epoch=best_epoch,
                    E_local_iou=score,E_recall=summary['E']['bump_recall'],E_false_add=summary['E']['neighbor_false_addition'],
                    iou=summary['all']['iou'],A_iou=summary['A']['iou'],eligible=passes,epoch_seconds=history[-1]['seconds'])
            selected=torch.load(dest/'best.pt',map_location='cpu',weights_only=True);model.load_state_dict(selected['model'])
            records,summary=evaluate(model,va,dest/'validation_predictions.npz')
            write_json(dest/'validation_metrics.json',records)
            r=dict(status='complete',variant=variant,seed=seed,selected_epoch=best_epoch,epochs=len(history),validation=summary,
                   checkpoint_sha256=file_hash(dest/'best.pt'),protocol_sha256=ph,test_read=False)
            write_json(dest/'complete.json',r);results.append(r)
            del model,opt,scheduler;torch.cuda.empty_cache()
    rankings=[dict(variant=v,mean_local_iou=float(np.mean([r['validation']['E']['local_iou'] for r in results if r['variant']==v])),
        selected_epochs=[r['selected_epoch'] for r in results if r['variant']==v]) for v in VARIANTS]
    rankings.sort(key=lambda r:r['mean_local_iou'],reverse=True)
    write_json(ROOT/'joint_comparison.json',dict(protocol_sha256=ph,rankings=rankings,runs=results,test_read=False));status('joint_screening_complete',rankings=rankings)

if __name__=='__main__':
    with Lock():run()
