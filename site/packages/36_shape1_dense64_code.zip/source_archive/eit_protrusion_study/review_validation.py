"""Independent metric replay, paired position bootstrap and real validation images.

Uses only saved validation predictions and train/validation diagnostics. No model
selection, test access, training imports or modification of frozen experiments.
"""
import hashlib
import json
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from scipy import ndimage as ndi

ROOT = Path('E:/Codex/protrusion_study_v1')
OUT = ROOT/'scientific_review'
METHODS = ['old_before_loop', 'old_K3', 'candidate_before_loop', 'candidate_K3']
METRICS = ['iou', 'dice', 'bump_recall', 'local_iou', 'neighbor_false_addition', 'bump_detected']
GROUPS = ['all', 'A', 'BCDE', 'E', 'E_small', 'E_medium', 'E_large']
NBOOT = 10000


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def write(path, obj):
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False), encoding='utf-8')


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def subset(rows, group):
    if group == 'all': return rows
    if group == 'BCDE': return [r for r in rows if r['shape_class'] != 'A']
    if group.startswith('E_'): return [r for r in rows if r['shape_class']=='E' and r['bump_size_class']==group[2:]]
    return [r for r in rows if r['shape_class']==group]


def paired(rows, left, right):
    """Resample positions, preserve all correlated cases and pair method deltas."""
    groups = sorted({r['position_id'] for r in rows})
    sums = np.array([sum(right(r)-left(r) for r in rows if r['position_id']==g) for g in groups])
    counts = np.array([sum(r['position_id']==g for r in rows) for g in groups])
    idx = np.random.default_rng(20261023).integers(0, len(groups), (NBOOT, len(groups)))
    boot = sums[idx].sum(1)/counts[idx].sum(1)
    return dict(n=len(rows), positions=len(groups), before=float(np.mean([left(r) for r in rows])),
                after=float(np.mean([right(r) for r in rows])), delta=float(sums.sum()/counts.sum()),
                ci95=np.quantile(boot, [.025,.975]).tolist())


def replay(p, truth, added, neighbor):
    b = p >= .5
    inter = int((b & truth).sum())
    ans = dict(iou=inter/max((b|truth).sum(),1), dice=2*inter/max(b.sum()+truth.sum(),1),
               missed_pixels=int((~b&truth).sum()), false_positive_pixels=int((b&~truth).sum()))
    if added.any():
        recall = float(b[added].mean()); fp=float(b[neighbor].mean())
        ans.update(bump_recall=recall, neighbor_false_addition=fp,
                   local_iou=float((b&added).sum()/max(added.sum()+(b&neighbor).sum(),1)),
                   bump_detected=float(recall>=.75 and fp<=.1))
    return ans


def verify(records):
    assert len(records)==720 and len({r['case_id'] for r in records})==720
    meta = read(ROOT/'val_diagnostic.json')['metadata']
    assert {r['case_id'] for r in records}=={r['case_id'] for r in meta}
    hashes=[]; max_error=0.; transitions=[]
    for r in records:
        path=ROOT/'integration_validation'/(r['case_id']+'.npz')
        with np.load(path, allow_pickle=False) as pred, np.load(ROOT/'cache/val'/(r['case_id']+'.npz'), allow_pickle=False) as z:
            truth=z['truth'].astype(bool);added=z['added'].astype(bool);neighbor=z['neighbor'].astype(bool)
            for m in METHODS:
                assert pred[m].shape==(64,64) and np.isfinite(pred[m]).all()
                for k,v in replay(pred[m],truth,added,neighbor).items():
                    err=abs(v-r['methods'][m][k]); max_error=max(max_error,err)
                    assert err<1e-10, (r['case_id'],m,k,err)
            if added.any():
                b=pred['old_K3']>=.5;c=pred['candidate_K3']>=.5
                transitions.append(dict(case_id=r['case_id'],position_id=r['position_id'],
                    recovered_bump_pixels=int((~b&c&added).sum()),lost_bump_pixels=int((b&~c&added).sum()),
                    newly_filled_neighbor_pixels=int((~b&c&neighbor).sum()),removed_neighbor_pixels=int((b&~c&neighbor).sum())))
        hashes.append(dict(case_id=r['case_id'],sha256=sha(path)))
    for name in ('candidate_protocol.json','joint_protocol.json','integration_protocol.json'):
        obj=read(ROOT/name)
        for filename,expected in obj.get('source_hashes',obj.get('code_hashes',{})).items():
            assert sha(Path(__file__).with_name(filename))==expected
    checkpoints=[]
    for folder,protocol in [('candidates','candidate_protocol.json'),('joint_candidates','joint_protocol.json')]:
        for p in sorted((ROOT/folder).glob('*/complete.json')):
            c=read(p)
            assert c['protocol_sha256']==sha(ROOT/protocol)
            assert c['checkpoint_sha256']==sha(p.parent/'best.pt')
            assert not c['test_read']
            checkpoints.append(dict(path=str(p.parent/'best.pt'),sha256=c['checkpoint_sha256']))
    assert len(checkpoints)==16
    selection=read(ROOT/'selection.json')
    assert sha(ROOT/'selection.json')==read(ROOT/'integration_protocol.json')['selection_sha256']
    for c in selection['checkpoints']: assert sha(Path(c['path']))==c['sha256']
    return dict(status='PASS',recomputed_cases=720,methods_per_case=4,max_metric_error=max_error,
                validation_positions=len({r['position_id'] for r in records}),prediction_hashes=hashes,
                checked_checkpoints=checkpoints,test_read=False),transitions


def case_panel(rows, name, title):
    fig,axes=plt.subplots(len(rows),5,figsize=(13,len(rows)*2.4),squeeze=False,constrained_layout=True)
    for i,r in enumerate(rows):
        cid=r['case_id']
        with np.load(ROOT/'cache/val'/(cid+'.npz')) as z:
            truth=z['truth'].astype(bool);added=z['added'].astype(bool);neighbor=z['neighbor'].astype(bool)
        with np.load(ROOT/'integration_validation'/(cid+'.npz')) as z:
            before=z['old_K3'];candidate=z['candidate_K3']
        y,x=np.where(ndi.binary_dilation(added,iterations=5))
        crop=np.s_[y.min():y.max()+1,x.min():x.max()+1]
        labels=truth.astype(int);labels[neighbor]=2;labels[added]=3
        change=np.zeros(truth.shape,dtype=int)
        change[(candidate>=.5)&(before<.5)&truth]=1
        change[(candidate>=.5)&(before<.5)&~truth]=2
        change[(candidate<.5)&(before>=.5)&truth]=3
        change[(candidate<.5)&(before>=.5)&~truth]=4
        arrays=[labels,before,candidate,(candidate>=.5).astype(int),change]
        for j,(a,arr) in enumerate(zip(axes[i],arrays)):
            if j==0:a.imshow(arr[crop],origin='lower',interpolation='nearest',cmap=ListedColormap(['#eff3f8','#64748b','#bae6fd','#f59e0b']),vmin=0,vmax=3)
            elif j==4:a.imshow(arr[crop],origin='lower',interpolation='nearest',cmap=ListedColormap(['#e8edf4','#16a34a','#ef4444','#a855f7','#2563eb']),vmin=0,vmax=4)
            else:a.imshow(arr[crop],origin='lower',interpolation='nearest',cmap='viridis',vmin=0,vmax=1)
            if j>0:a.contour(truth[crop],levels=[.5],colors=['white' if j<4 else 'black'],linewidths=.8)
            a.set_xticks([]);a.set_yticks([])
        a=r['methods']['old_K3'];b=r['methods']['candidate_K3']
        axes[i,0].set_ylabel(cid+' / '+r['bump_size_class']+'\n'+f"local IoU {a['local_iou']:.3f} > {b['local_iou']:.3f}\nrecall {a['bump_recall']:.3f} > {b['bump_recall']:.3f}\nnear FP {a['neighbor_false_addition']:.3f} > {b['neighbor_false_addition']:.3f}",fontsize=8)
    for a,t in zip(axes[0],['Truth: orange bump / blue neighbor','Original K3 probability','Candidate K3 probability','Candidate binary (p >= 0.5)','Added/lost pixels vs original']):a.set_title(t,fontsize=9)
    fig.suptitle(title+'\nChange: green=correct addition; red=false addition; purple=lost truth; blue=removed background error',fontsize=11)
    fig.savefig(OUT/name,dpi=150);plt.close(fig)


def main():
    OUT.mkdir(exist_ok=True)
    s=read(ROOT/'integration_summary.json');assert s['status']=='complete' and not s['test_read']
    rows=s['records'];audit,transitions=verify(rows)
    write(OUT/'artifact_audit.json',audit)
    contrasts=[('old_K3','candidate_K3'),('old_before_loop','old_K3'),('candidate_before_loop','candidate_K3')]
    stats={}
    for left,right in contrasts:
        subsets={}
        for group in GROUPS:
            rr=subset(rows,group);m={}
            for k in METRICS:
                valid=[r for r in rr if k in r['methods'][left]]
                if valid:
                    m[k]=paired(valid,lambda r:r['methods'][left][k],lambda r:r['methods'][right][k])
            subsets[group]=m
        stats[right+' minus '+left]=subsets
    voltage={}
    for group in GROUPS:
        rr=subset(rows,group)
        voltage[group]={}
        for freq,hz in enumerate((10000,50000)):
            voltage[group][str(hz)]=paired(rr,lambda r:r['old_voltage_mse'][-1][freq],lambda r:r['candidate_voltage_mse'][-1][freq])
        voltage[group]['round_means']={m:np.mean([r[m+'_voltage_mse'] for r in rr],axis=0).tolist() for m in ('old','candidate')}
    baseline={r['case_id']:r for r in read(ROOT/'val_diagnostic.json')['records']['after_cut']}
    seeds=[]
    for family,folder in [('frozen','candidates'),('joint','joint_candidates')]:
        for p in sorted((ROOT/folder).glob('*/complete.json')):
            c=read(p);records=read(p.parent/'validation_metrics.json')
            rr=[r for r in records if r['shape_class']=='E']
            seeds.append(dict(family=family,variant=c['variant'],seed=c['seed'],selected_epoch=c['selected_epoch'],epochs=c['epochs'],
                validation=c['validation'],paired_E={k:paired(rr,lambda r:baseline[r['case_id']][k],lambda r:r[k])
                    for k in ('local_iou','bump_recall','neighbor_false_addition')}))
    erows=subset(rows,'E');delta=lambda r:r['methods']['candidate_K3']['local_iou']-r['methods']['old_K3']['local_iou']
    fixed=sum([sorted(subset(rows,'E_'+size),key=lambda r:r['case_id'])[:2] for size in ('small','medium','large')],[])
    best=sorted(erows,key=lambda r:(-delta(r),r['case_id']))[:6]
    worst=sorted(erows,key=lambda r:(delta(r),r['case_id']))[:6]
    case_panel(fixed,'fixed_cases.png','Fixed validation IDs: first two per bump size (same rule as diagnostic panels)')
    case_panel(best,'best_changes.png','Six largest validation local-IoU increases; selected for inspection, not typical performance')
    case_panel(worst,'worst_changes.png','Six largest validation local-IoU decreases; explicit failure review')
    fig,axes=plt.subplots(1,2,figsize=(12,4.5),constrained_layout=True)
    names=[r['variant']+' / '+str(r['seed'])[-2:] for r in seeds]
    vals=[r['paired_E']['local_iou'] for r in seeds]
    yy=np.arange(len(vals));cent=np.array([r['delta']*100 for r in vals]);low=np.array([r['ci95'][0]*100 for r in vals]);high=np.array([r['ci95'][1]*100 for r in vals])
    axes[0].errorbar(cent,yy,xerr=np.stack((np.maximum(cent-low,0),np.maximum(high-cent,0))),fmt='o',markersize=3,capsize=2)
    axes[0].set_yticks(yy,names,fontsize=7);axes[0].axvline(0,color='black',lw=.8);axes[0].set_xlabel('Local IoU change (percentage points)');axes[0].set_title('All frozen best checkpoints: 2 seeds / arm\nPaired position-bootstrap 95% CI; selection on same val')
    for family,color in [('frozen','#0891b2'),('joint','#ea580c')]:
        rr=[r for r in seeds if r['family']==family]
        axes[1].scatter([r['validation']['E']['neighbor_false_addition']*100 for r in rr],[r['validation']['E']['bump_recall']*100 for r in rr],label=family,color=color,s=35,alpha=.8)
    for m,color in [('old_K3','black'),('candidate_K3','#7c3aed')]:
        a=s['aggregate'][m]['E'];axes[1].scatter(a['neighbor_false_addition']*100,a['bump_recall']*100,label=m,color=color,s=90,marker='*')
    axes[1].set_xlabel('False foreground near bump (%)');axes[1].set_ylabel('Bump recall (%)');axes[1].legend(fontsize=8);axes[1].set_title('Recall versus notch filling\nHigher recall alone is not recovery')
    fig.savefig(OUT/'overall_comparison.png',dpi=160);plt.close(fig)
    key='candidate_K3 minus old_K3'
    result=dict(status='reviewed_not_solved',test_read=False,bootstrap=dict(replicates=NBOOT,seed=20261023,unit='position_id',
        interval='paired cluster percentile; case-weighted within resampled positions; no multiplicity/selection correction',
        limitation='same validation selected candidates; conditional descriptive intervals, not independent confirmation'),
        aggregate=s['aggregate'],paired_comparisons=stats,voltage=voltage,candidates=seeds,
        transitions=transitions,transition_totals={k:sum(r[k] for r in transitions) for k in transitions[0] if k.endswith('pixels')},
        E_case_change_counts=dict(improved=sum(delta(r)>1e-12 for r in erows),worse=sum(delta(r)<-1e-12 for r in erows),unchanged=sum(abs(delta(r))<=1e-12 for r in erows)),
        cases={name:[r['case_id'] for r in rr] for name,rr in [('fixed',fixed),('best',best),('worst',worst)]},
        decision='Do not promote as a solution or open test: tiny recall/local-IoU gain increases false fill and selected second seed is identity; continue train-fit diagnosis.')
    write(OUT/'summary_statistics.json',result)
    lines=['# 凸起研究：第一轮完整验证审阅','',
      '已完成 5 个冻结特征方案 × 2 种子、3 个联合几何方案 × 2 种子，以及预先固定代表种子的 720 例真实 K=3 配对验证。尚未解决凸起恢复问题，本研究测试集仍未读取。','',
      '候选按两个种子均值选为 probability_local；种子 20261022 选 epoch 1，20261023 仍选 epoch 0（恒等修正）。第二名 joint_local_precise 也有一个种子退回 epoch 0。不能将均值排名当作稳定成功。','',
      '## 720 例验证与位置组置信区间','',
      '下表为候选 K3 − 原 K3，数值均为百分比/百分点；95% CI 使用 18 个位置组配对 bootstrap 10000 次。同一验证集用于选模，这些区间没有校正选模与多重比较。','',
      '| 分组 | 指标 | 原 K3 | 候选 K3 | 差值 [95% CI] |','|---|---|---:|---:|---:|']
    for group in GROUPS:
        keys=['iou']+(['bump_recall','local_iou','neighbor_false_addition'] if group.startswith('E') else [])
        for k in keys:
            v=stats[key][group][k];lines.append(f"| {group} | {k} | {100*v['before']:.3f} | {100*v['after']:.3f} | {100*v['delta']:+.3f} [{100*v['ci95'][0]:+.3f}, {100*v['ci95'][1]:+.3f}] |")
    lines+=['','## 全部候选与两种子','',
      '这里是几何筛选，不含 FEM 训练；真实实时 FEM 仅在后续 K3 接入验证。epoch 0 表示没有合格改进，保留初始预测。','',
      '| 方案 | 种子 | 选中/已训轮数 | 局部 IoU | 凸起召回 | 邻近误填 |','|---|---|---|---:|---:|---:|']
    for r in seeds:
        e=r['validation']['E'];lines.append(f"| {r['variant']} | {r['seed']} | {r['selected_epoch']}/{r['epochs']} | {e['local_iou']:.4f} | {e['bump_recall']:.4f} | {e['neighbor_false_addition']:.4f} |")
    lines+=['','## 实际像素与失败病例','',f"局部 IoU 改善/退步/不变：{result['E_case_change_counts']}。像素转移合计：{result['transition_totals']}。",'',
      '两模型满足预设 recall≥0.75 且邻近误填≤0.1 的病例数均为 1/144；这个阈值本身也不代表形状忠实恢复。',
      'fixed_cases.png：按病例 ID 和大小预定；best_changes.png 与 worst_changes.png：分别展示局部 IoU 变化最大的 6 例，不代表平均效果。颜色和二值图揭示是否仅将整个边缘填厚。','',
      '## 物理电压残差','',
      '记录的是经背景参考校准、相邻测量与归一化后的复数残差平方均值，不是原始伏特单位 MSE。', '',
      '| 频率 | 原 K3 | 候选 K3 | 配对差 [95% CI] |','|---|---:|---:|---:|']
    for hz in ('10000','50000'):
        v=voltage['all'][hz];lines.append(f"| {hz} Hz | {v['before']:.6g} | {v['after']:.6g} | {v['delta']:+.6g} [{v['ci95'][0]:+.6g}, {v['ci95'][1]:+.6g}] |")
    lines+=['','## 六方向结论与后续','',
      '1. 逐阶段归因：验证真实凸起 1485 像素中，基础分支已漏 948，切除仅额外删 1。主要问题在切除之前；最新 K3 本身有双向修正。',
      '2. 64/512 标签：824 个 train/val E 病例标签存在，小凸起平均深入约 1.62 像素；有分辨率困难，不能说凸起标签消失。',
      '3. 固定材料 FEM 反事实：小凸起信号常弱于独立 FEM 与 COMSOL 差异；不等于不可辨识证明。',
      '4. 双向修正：单纯增加可加可减能力只获微弱改进，没有稳定恢复凸起。',
      '5. 局部监督：经常增厚凹口边缘；联合训练和加强误增约束也未在两种子稳定成功。',
      '6. 实时物理：接入原 K3 后微小改善不足；此前三步几何小幅优化无明显二值收益，仅限该设置，不能概括为物理无效。','',
      '下一步：只对现存 best/last 检查点做训练集推理，区分训练拟合不足与训练—验证泛化差距，同时检查凸起/邻近背景概率分离。没有获得稳定形状收益前不打开本研究测试集。','',
      '限制：历史测试已观察；全部候选共享已训骨干；两种子只是校正/筛选重复，不是独立骨干重复；短程筛选不保证收敛；本次 K3 只验证固定代表种子，未重新训练完整物理循环。旧源码、旧权重及暂停长训保持不变。','',
      '独立核验：720×4 预测全部重新计算指标并与原记录一致；16 个选中检查点与协议、源码哈希匹配。具体见 artifact_audit.json；统计见 summary_statistics.json。']
    (OUT/'RESULTS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps(dict(audit=audit['status'],E=stats[key]['E'],transitions=result['transition_totals'],cases=result['E_case_change_counts']),ensure_ascii=False))


if __name__=='__main__': main()
