"""Assemble an explicitly negative research-stage delivery, not success claims."""
import hashlib
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import ndimage as ndi

ROOT=Path('E:/Codex/protrusion_study_v1')
OUT=ROOT/'scientific_review'
LOCAL=ROOT/'localization_probe'


def read(p):return json.loads(p.read_text(encoding='utf-8'))
def write(p,o):p.write_text(json.dumps(o,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()


def main():
    stats=read(OUT/'summary_statistics.json');local=read(LOCAL/'comparison.json')
    last=read(LOCAL/'last_diagnostic_summary.json');fit=read(OUT/'fit_comparison.json')
    assert last['status']=='PASS' and len(local['runs'])==4
    for r in local['runs']:
        folder=LOCAL/f"{r['variant']}_seed{r['seed']}"
        assert sha(folder/'best.pt')==r['checkpoint_sha256']
        assert r['protocol_sha256']==sha(LOCAL/'protocol.json')
        assert r['selected_epoch']==0 and r['eligible']
        assert not r['test_read']
    proto=read(LOCAL/'protocol.json')
    for n,h in proto['source_hashes'].items():assert sha(Path(__file__).with_name(n))==h
    fixed=stats['cases']['fixed']
    figures=[]
    for seed in (20261022,20261023):
        predictions={}
        for variant in ('gate_control','gate_supervised'):
            with np.load(LOCAL/f'{variant}_seed{seed}'/'last_validation_predictions.npz') as z:
                predictions[variant]={str(cid):(p,g) for cid,p,g in zip(z['case_ids'],z['probability'],z['gate'])}
        fig,axes=plt.subplots(len(fixed),5,figsize=(12,13),constrained_layout=True)
        for i,cid in enumerate(fixed):
            with np.load(ROOT/'cache/val'/(cid+'.npz')) as z:
                truth=z['truth'];added=z['added'];base=z['after_cut']
            y,x=np.where(ndi.binary_dilation(added,iterations=5));crop=np.s_[y.min():y.max()+1,x.min():x.max()+1]
            fields=[truth,base,predictions['gate_control'][cid][0],predictions['gate_supervised'][cid][0],predictions['gate_supervised'][cid][1]]
            for j,(ax,arr) in enumerate(zip(axes[i],fields)):
                ax.imshow(arr[crop],origin='lower',interpolation='nearest',vmin=0,vmax=1,cmap='viridis')
                if j>0:ax.contour(truth[crop],levels=[.5],colors='white',linewidths=.8)
                if j in (2,3):ax.contour(arr[crop],levels=[.5],colors='#ff477e',linewidths=.9)
                ax.set_xticks([]);ax.set_yticks([])
            axes[i,0].set_ylabel(cid,fontsize=9)
        for ax,t in zip(axes[0],['True foreground','Initial foreground','No gate supervision','With gate supervision','Predicted bump gate']):ax.set_title(t,fontsize=9)
        fig.suptitle(f'Seed {seed}: last epoch 12, rejected by validation guards\nWhite=truth; pink=prediction boundary. Fixed IDs, not selected successes. Gate is predicted from measurements.',fontsize=11)
        path=OUT/f'localization_failures_{seed}.png';fig.savefig(path,dpi=150);plt.close(fig);figures.append(path.name)
    fig,axes=plt.subplots(2,2,figsize=(11,7),constrained_layout=True)
    for j,seed in enumerate((20261022,20261023)):
        for variant,color in [('gate_control','#0891b2'),('gate_supervised','#c65b25')]:
            h=read(LOCAL/f'{variant}_seed{seed}'/'history.json')
            for i,key in enumerate(('local_iou','neighbor_false_addition')):
                axes[i,j].plot([r['epoch'] for r in h],[r['validation']['E'][key] for r in h],label=variant,color=color)
        axes[0,j].axhline(.24181314176127827,color='black',ls='--',lw=1)
        axes[1,j].axhline(.09055183505118472+.005,color='red',ls='--',lw=1,label='FP guard')
        axes[0,j].set_title(f'Seed {seed}');axes[0,j].set_ylabel('Validation local IoU');axes[1,j].set_ylabel('Neighbor false addition');axes[1,j].set_xlabel('Epoch')
        axes[0,j].legend(fontsize=8);axes[1,j].legend(fontsize=8)
    fig.suptitle('Explicit-localization follow-on: local IoU rises with notch filling\nAll four selected checkpoints remain epoch 0; no promoted candidate')
    fig.savefig(OUT/'localization_training_curves.png',dpi=160);plt.close(fig)
    stats.update(localization_followon=local,last_localization_diagnostics=last,training_fit=fit,
        study_status='completed_screening_no_effective_solution',solution_found=False,test_evaluation_performed=False,
        test_decision='Not opened: no stable candidate recovered bump without notch filling.',
        scope='Six diagnostic/research directions plus matched explicit-localization follow-on; not six equal-budget end-to-end physical retrainings.')
    write(ROOT/'summary_statistics.json',stats)
    report=(OUT/'RESULTS.md').read_text(encoding='utf-8')
    report=report.replace('下一步：只对现存 best/last 检查点做训练集推理，区分训练拟合不足与训练—验证泛化差距，同时检查凸起/邻近背景概率分离。没有获得稳定形状收益前不打开本研究测试集。',
        '补充工作已完成：全部 32 个 best/last 检查点的全训练集推理，以及显式定位门控的同结构两方案×两种子对照。详见下节。由于未获得稳定形状收益，本研究测试集未打开。')
    report+='''

## 补充诊断与显式定位对照

对 16 次筛选的 best/last 共 32 个检查点做了全 3400 例训练集推理，没有更新权重。加强误填约束的联合模型在最后一轮训练局部 IoU 为 0.5462/0.5170，验证仅 0.3000/0.3208。局部监督虽能拟合部分训练形状，却无法可靠泛化到保留位置组；高训练召回也可能来自误填。详表见 scientific_review/TRAIN_FIT.md。

据此增加一个受控跟进：同结构的 gate_control 与 gate_supervised，各两个种子，均训练 12 轮，后者额外用“凸起/非凸起”定位监督训练门控。推理只用测量派生特征和预测边界，真值几何从未作为输入。此轮只训练冻结特征后的几何头，不含 FEM 训练，不能称为完整 K3 训练。

| 方案 | 种子 | 最后轮凸起召回 | 最后轮局部 IoU | 最后轮邻近误填 | 验证选中轮 |
|---|---|---:|---:|---:|---:|
'''
    for r in last['records']:
        v=r['validation']['E'];report+=f"| {r['variant']} | {r['seed']} | {100*v['bump_recall']:.2f}% | {v['local_iou']:.4f} | {100*v['neighbor_false_addition']:.2f}% | 0 |\n"
    report+='''
此轮预先收紧邻近误填增幅上限至 0.005，所有四组均未通过，保留第 0 轮。预测边界带覆盖全部验证凸起像素（平均覆盖率 1.0），所以本轮失败不能简单归为“允许修正的带太窄”。最后一轮图像仅用于诊断失败，没有偷换为最终模型。两个种子的失败图和曲线均保留。

## 当前判断

本次已尝试的六方向及补充定位对照，没有找到能够稳定恢复凸起、同时不误填凹口的有效方法。平均分数最高的受控候选为 probability_local，但它只在一个种子带来微弱收益，不能推荐替换现有模型。没有最终候选冻结用于测试，也没有用测试结果调参。

最可靠的失败定位是“基础分支已经漏掉大部分凸起，后续校正难以根据现有特征区分凸起与其邻近背景”，而不是“整个新模型只能做减法”。独立 FEM 与原测量的偏差、小尺寸分辨率和位置泛化均可能参与；目前没有证据将它们归为唯一根因。

后续若继续研发，优先检验更明确的几何参数化或测量对局部几何的辨识能力，并把普通病例保护、凹口误填和完整物理循环的预算一并设计。单纯继续加大局部损失或增加同一设置轮数，现有证据不足以支持。此处是下一阶段的研究建议，不宣称已经验证有效。

本轮筛选与审阅完成并如实交付负结果；“完成”仅指本轮工作结束，不代表凸起问题已解决或模型收敛。原 V4/K3 源码和暂停长训均未修改或恢复。
'''
    (ROOT/'RESULTS.md').write_text(report,encoding='utf-8')
    audit=dict(status='PASS',scope='artifact/protocol/metric integrity; NOT model effectiveness',solution_found=False,
        validation_replay=read(OUT/'artifact_audit.json')['status'],validation_cases=720,real_K3_methods_per_case=4,
        original_candidate_runs=16,followon_candidate_runs=4,training_fit_checkpoints=32,
        followon_last_replay=last['status'],test_read=False,source_hashes_checked=True,
        source_snapshot={n:sha(Path(__file__).with_name(n)) for n in ('review_validation.py','review_fit.py','review_localization.py','finish_review.py')},
        files={str(p.relative_to(ROOT)):sha(p) for p in [ROOT/'RESULTS.md',ROOT/'summary_statistics.json',OUT/'TRAIN_FIT.md',OUT/'fit_summary.json',LOCAL/'protocol.json',LOCAL/'comparison.json']})
    write(ROOT/'delivery_audit.json',audit)
    print(json.dumps(dict(status='report_ready',solution_found=False,audit='PASS',figures=figures),ensure_ascii=False))


if __name__=='__main__':main()
