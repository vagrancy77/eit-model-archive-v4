"""Resumable serial follow-up. Never runs or resumes old long training."""
import json
import os
import subprocess
import sys
import time
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=Path('E:/Codex/protrusion_study_v1')
PYTHON='E:/conda-envs/pytorch-gpu/python.exe'

def write(name,data):
    tmp=ROOT/(name+'.tmp');tmp.write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8');tmp.replace(ROOT/name)

def busy():
    import msvcrt
    with open(ROOT/'worker.lock','a+b') as f:
        if f.tell()==0:f.write(b'0');f.flush()
        f.seek(0)
        try:msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
        except OSError:return True
        msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
        return False

def run():
    import msvcrt
    lock=open(ROOT/'pipeline.lock','a+b')
    if lock.tell()==0:lock.write(b'0');lock.flush()
    lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
    jobs=[('joint_comparison.json','joint_probe.py',[]),('integration_summary.json','promotion.py',[])]
    for marker,script,args in jobs:
        while busy():
            write('pipeline_status.json',dict(phase='waiting_for_existing_worker',marker=marker,updated_unix=time.time(),pid=os.getpid()))
            time.sleep(15)
        if (ROOT/marker).exists():continue
        stamp=time.strftime('%Y%m%d_%H%M%S');out=ROOT/(script.removesuffix('.py')+'_'+stamp+'.stdout.log');err=ROOT/(script.removesuffix('.py')+'_'+stamp+'.stderr.log')
        with out.open('wb') as so,err.open('wb') as se:
            proc=subprocess.Popen([PYTHON,'-B','-u',str(HERE/script),*args],cwd='E:/Codex/eit_reproduction',
                stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
            write('pipeline_status.json',dict(phase='running',script=script,child_pid=proc.pid,pid=os.getpid(),stdout=str(out),stderr=str(err),updated_unix=time.time()))
            print('START',script,proc.pid,flush=True);code=proc.wait()
        if code or not (ROOT/marker).exists():raise RuntimeError(f'{script} exited {code}; inspect {err}')
    write('pipeline_status.json',dict(phase='ready_for_scientific_review',updated_unix=time.time(),pid=os.getpid(),
        remaining='review integrated validation, failure images, selection freeze and any justified final evaluation; do not claim protrusion solved from scalar metrics alone'))
    print('READY_FOR_REVIEW',flush=True)

if __name__=='__main__':
    try:run()
    except Exception as exc:
        write('pipeline_error.json',dict(error=repr(exc),updated_unix=time.time(),pid=os.getpid()));raise
