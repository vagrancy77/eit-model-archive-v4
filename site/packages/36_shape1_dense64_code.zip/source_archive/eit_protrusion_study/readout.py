"""Matched frozen-feature probes: direction, saturation and local supervision.

These are explicitly neural geometry probes, not replacements for the K=3 FEM
loop. All variants receive identical measurement-derived frozen features.
"""
import argparse
import copy
import json
import random
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.data import DataLoader, Dataset
from common import *
from comsol_v4.paper_common import configure_runtime

VARIANTS = ['delete_global', 'signed_global', 'signed_boundary', 'signed_local', 'probability_local']
SEEDS = [20261022, 20261023]


class GeometryReadout(nn.Module):
    def __init__(self, channels=60, variant='signed_local'):
        super().__init__(); self.variant = variant
        self.body = nn.Sequential(nn.Conv2d(channels, 24, 3, padding=1), nn.GroupNorm(6, 24), nn.SiLU(),
            nn.Conv2d(24, 24, 3, padding=1), nn.GroupNorm(6, 24), nn.SiLU(),
            nn.Conv2d(24, 24, 3, padding=1), nn.GroupNorm(6, 24), nn.SiLU())
        self.head = nn.Conv2d(24, 1, 1)
        nn.init.zeros_(self.head.weight); nn.init.zeros_(self.head.bias)

    def forward(self, measurement_features, initial_foreground):
        raw = self.head(self.body(measurement_features))
        p = initial_foreground
        if self.variant == 'probability_local':
            updated = p + .9*torch.tanh(raw)
        else:
            clipped = p.clamp(.005, .995)
            shifted = torch.sigmoid(torch.logit(clipped)+8*torch.tanh(raw))
            updated = p+shifted-clipped
        if self.variant == 'delete_global': updated = torch.minimum(updated, p)
        return updated.clamp(1e-6, 1-1e-6)


class CacheDataset(Dataset):
    def __init__(self, split):
        self.split = split
        self.metadata = json.loads((ROOT/f'{split}_diagnostic.json').read_text(encoding='utf-8'))['metadata']
        self.items = []
        for row in self.metadata:
            with np.load(ROOT/'cache'/split/(row['case_id']+'.npz'), allow_pickle=False) as z:
                self.items.append({k: torch.from_numpy(z[k].copy())[None] if k!='inputs' else torch.from_numpy(z[k].copy())
                    for k in ('inputs', 'truth', 'added', 'neighbor', 'band', 'after_cut')})
        self.fov = torch.tensor(grid_arrays(FINAL_DATASET_ROOT)[2], dtype=torch.float32)[None, None]

    def __len__(self): return len(self.items)
    def __getitem__(self, i): return {**self.items[i], 'index': i}


def region_mean(v, region):
    return (v*region).sum((1,2,3))/region.sum((1,2,3)).clamp_min(1)


def objective(p, batch, variant, fov):
    t = batch['truth'].float(); bce = F.binary_cross_entropy(p, t, reduction='none')
    ce = region_mean(bce, fov.expand_as(p)).mean()
    dice = (1-(2*(p*t*fov).sum((1,2,3))+1)/((p*fov+t*fov).sum((1,2,3))+1)).mean()
    loss = ce+dice+.01*region_mean((p-batch['after_cut']).abs(), fov.expand_as(p)).mean()
    if variant in ('signed_boundary', 'signed_local', 'probability_local'):
        band = batch['band'].float()
        loss = loss+.25*(region_mean(bce, band*t)+region_mean(bce, band*(1-t))).mean()
    if variant in ('signed_local', 'probability_local'):
        added = batch['added'].float(); neighbor = batch['neighbor'].float()
        valid = (added.sum((1,2,3))>0).float()
        # E-only geometric labels affect supervision, never the forward inputs.
        local = region_mean(bce, added)+region_mean(bce, neighbor)
        loss = loss+.25*(local*valid).sum()/valid.sum().clamp_min(1)
    return loss


def evaluate(model, ds, save=None):
    model.eval(); records = []; predictions = []
    fov = ds.fov.cuda()
    with torch.no_grad():
        for raw in DataLoader(ds, batch_size=48, shuffle=False):
            p = (model(raw['inputs'].cuda().float(), raw['after_cut'].cuda().float())*fov).cpu().numpy()
            for j, idx in enumerate(raw['index'].tolist()):
                records.append({**ds.metadata[idx], **metrics(p[j], raw['truth'][j].numpy()[0],
                    raw['added'][j].numpy()[0], raw['neighbor'][j].numpy()[0])})
                predictions.append(p[j,0])
    if save is not None:
        np.savez_compressed(save, probability=np.stack(predictions),
                            case_ids=np.array([r['case_id'] for r in records]))
    return records, aggregate(records)


def eligible(summary, baseline):
    return (summary['all']['iou'] >= baseline['all']['iou']-.002 and
            summary['A']['iou'] >= baseline['A']['iou']-.002 and
            summary['E']['neighbor_false_addition'] <= baseline['E']['neighbor_false_addition']+.02)


def freeze_candidates(channels):
    p = dict(version='frozen-spatial-geometry-probes-v1', variants=VARIANTS, seeds=SEEDS,
        max_epochs=20, minimum_epochs=6, patience=6, batch_size=48, lr=.001, min_lr=.00001,
        lr_factor=.5, lr_patience=3, weight_decay=.0001, channels=channels,
        features='frozen jointly fine-tuned V4 base/topology 64x64 decoder features plus B,P,C,SDF; no labels/geometry parameters in inference',
        cache_precision='float16 features, float32 foreground; same cache for every candidate',
        initialization='zero final correction; same seeded body and same epoch order across variants',
        losses='BCE+Dice+.01 anchor; boundary variants +.25 balanced 2-pixel-band BCE; local variants +.25 bump/neighbor balanced BCE',
        selection='maximize E local IoU among validation checkpoints passing ordinary/overall and false-addition guards; otherwise retain epoch0 identity',
        guards=dict(overall_iou_drop=.002, A_iou_drop=.002, E_neighbor_false_addition_increase=.02),
        test='never read during candidate comparison; exploratory historical test only after selection freeze',
        six_track_coverage='direction and saturation / local geometry supervision; independent spatial readout probes, not full K3 retraining',
        checkpoint_sha256=file_hash(QUICK/'best.pt'),
        code_hashes={p.name: file_hash(p) for p in [Path(__file__), Path(__file__).with_name('common.py')]})
    target = ROOT/'candidate_protocol.json'
    if target.exists() and json.loads(target.read_text(encoding='utf-8')) != p: raise RuntimeError('Candidate protocol changed')
    if not target.exists(): write_json(target, p)
    return p, file_hash(target)


def train_one(variant, seed, tr, va, protocol, phash):
    configure_runtime(seed)
    dest = ROOT/'candidates'/f'{variant}_seed{seed}'; dest.mkdir(parents=True, exist_ok=True)
    if (dest/'complete.json').exists():
        done = json.loads((dest/'complete.json').read_text())
        if done['protocol_sha256']!=phash or done['checkpoint_sha256']!=file_hash(dest/'best.pt'): raise RuntimeError('Candidate completion mismatch')
        return done
    model = GeometryReadout(protocol['channels'], variant).cuda()
    opt = torch.optim.AdamW(model.parameters(), lr=protocol['lr'], weight_decay=protocol['weight_decay'])
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, mode='max', factor=.5, patience=3, min_lr=1e-5)
    baseline = json.loads((ROOT/'val_diagnostic.json').read_text(encoding='utf-8'))['aggregate']['after_cut']
    start=0; best=baseline['E']['local_iou']; best_epoch=0; bad=0; history=[]
    def checkpoint(epoch):
        return dict(protocol_sha256=phash, variant=variant, seed=seed, epoch=epoch, best_score=best,
            best_epoch=best_epoch, bad_epochs=bad, model=model.state_dict(), optimizer=opt.state_dict(),
            scheduler=scheduler.state_dict(), history=history)
    if (dest/'last.pt').exists():
        ck=torch.load(dest/'last.pt',map_location='cpu',weights_only=True)
        if ck['protocol_sha256']!=phash: raise RuntimeError('Resume protocol changed')
        model.load_state_dict(ck['model']); opt.load_state_dict(ck['optimizer']); scheduler.load_state_dict(ck['scheduler'])
        start=ck['epoch']; best=ck['best_score']; best_epoch=ck['best_epoch']; bad=ck['bad_epochs']; history=ck['history']
    else:
        save_checkpoint(dest/'best.pt', checkpoint(0)); save_checkpoint(dest/'last.pt', checkpoint(0))
    fov=tr.fov.cuda()
    for epoch in range(start+1,protocol['max_epochs']+1):
        if epoch>protocol['minimum_epochs'] and bad>=protocol['patience']: break
        tick=time.monotonic(); model.train(); total=0.; count=0
        gen=torch.Generator().manual_seed(seed+1000003*epoch)
        for raw in DataLoader(tr,batch_size=protocol['batch_size'],shuffle=True,generator=gen,num_workers=0):
            b={k:v.cuda().float() for k,v in raw.items() if k!='index'}
            p=model(b['inputs'],b['after_cut'])*fov
            loss=objective(p.clamp(1e-6,1-1e-6),b,variant,fov)
            if not torch.isfinite(loss): raise FloatingPointError('Nonfinite probe loss')
            opt.zero_grad(set_to_none=True); loss.backward(); nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True); opt.step()
            total+=float(loss.detach())*len(raw['index']); count+=len(raw['index'])
        records, summary=evaluate(model,va)
        score=summary['E']['local_iou']; passes=eligible(summary,baseline)
        scheduler.step(score if passes else 0)
        improved=passes and score>best+1e-5
        if improved: best=score;best_epoch=epoch;bad=0
        else: bad+=1
        history.append(dict(epoch=epoch,loss=total/count,validation=summary,eligible=passes,seconds=time.monotonic()-tick,lr=opt.param_groups[0]['lr']))
        if improved: save_checkpoint(dest/'best.pt',checkpoint(epoch))
        save_checkpoint(dest/'last.pt',checkpoint(epoch));write_json(dest/'history.json',history)
        status('candidate_training',variant=variant,seed=seed,epoch=epoch,max_epochs=protocol['max_epochs'],
            selected_epoch=best_epoch,E_local_iou=score,E_recall=summary['E']['bump_recall'],A_iou=summary['A']['iou'],
            eligible=passes,epoch_seconds=history[-1]['seconds'])
    ck=torch.load(dest/'best.pt',map_location='cpu',weights_only=True);model.load_state_dict(ck['model'])
    records,summary=evaluate(model,va,dest/'validation_predictions.npz')
    result=dict(status='complete',protocol_sha256=phash,checkpoint_sha256=file_hash(dest/'best.pt'),variant=variant,seed=seed,
        selected_epoch=best_epoch,epochs=len(history),validation=summary,eligible=eligible(summary,baseline),
        note='fixed-feature readout; two seeds only probe optimization, not base-network training uncertainty',test_read=False)
    write_json(dest/'validation_metrics.json',records);write_json(dest/'complete.json',result)
    return result


def acceptance():
    configure_runtime(19)
    m=GeometryReadout().cuda();x=torch.randn(2,60,64,64,device='cuda');p=torch.rand(2,1,64,64,device='cuda')
    with torch.no_grad():
        assert torch.max(torch.abs(m(x,p)-p))<1e-5
        m.head.bias.fill_(1.);plus=m(x,p);assert float((plus-p).mean())>0
        m.head.bias.fill_(-1.);minus=m(x,p);assert float((minus-p).mean())<0
        m.variant='delete_global';m.head.bias.fill_(1.);assert torch.all(m(x,p)<=p+1e-6)
    # The local objective prefers recovery over both missing and filling everything.
    t=torch.zeros(1,1,8,8,device='cuda');t[:,:,2:6,2:6]=1
    added=torch.zeros_like(t);added[:,:,2:4,3:5]=1
    neighbor=torch.zeros_like(t);neighbor[:,:,:2,2:6]=1
    b=dict(truth=t,added=added,neighbor=neighbor,band=torch.ones_like(t),after_cut=t*.9)
    good=t*.98+.01;miss=good*(1-added);fill=(good+neighbor*.98).clamp(max=.99)
    fv=torch.ones_like(t)
    assert objective(good,b,'signed_local',fv)<objective(miss.clamp_min(1e-6),b,'signed_local',fv)
    assert objective(good,b,'signed_local',fv)<objective(fill,b,'signed_local',fv)
    write_json(ROOT/'readout_acceptance.json',dict(status='PASS',zero_identity=True,bidirectional=True,
        deletion_control_cannot_add=True,loss_penalizes_missing_and_false_filling=True,truth_not_in_forward=True))


def run():
    verify_historical_sources(); acceptance()
    status('loading_feature_cache')
    tr,va=CacheDataset('train'),CacheDataset('val')
    protocol,phash=freeze_candidates(tr.items[0]['inputs'].shape[0])
    results=[]
    for seed in SEEDS:
        for variant in VARIANTS:
            results.append(train_one(variant,seed,tr,va,protocol,phash))
    rankings=[]
    for variant in VARIANTS:
        rows=[r for r in results if r['variant']==variant]
        rankings.append(dict(variant=variant,mean_local_iou=float(np.mean([r['validation']['E']['local_iou'] for r in rows])),
            mean_bump_recall=float(np.mean([r['validation']['E']['bump_recall'] for r in rows])),
            mean_A_iou=float(np.mean([r['validation']['A']['iou'] for r in rows])),
            selected_epochs=[r['selected_epoch'] for r in rows],all_eligible=all(r['eligible'] for r in rows)))
    rankings.sort(key=lambda r:r['mean_local_iou'],reverse=True)
    write_json(ROOT/'candidate_comparison.json',dict(protocol_sha256=phash,rankings=rankings,runs=results,test_read=False))
    status('candidate_screening_complete',rankings=rankings)


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--acceptance-only',action='store_true');args=ap.parse_args()
    with Lock():
        try:
            if args.acceptance_only: acceptance()
            else: run()
        except Exception as exc:
            write_json(ROOT/'error.json',dict(error=repr(exc),time=time.time()));raise
