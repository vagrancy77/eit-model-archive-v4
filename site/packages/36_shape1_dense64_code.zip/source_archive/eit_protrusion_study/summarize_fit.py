"""Summarize immutable checkpoint train-fit audit against saved validation."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path('E:/Codex/protrusion_study_v1')
OUT=ROOT/'scientific_review'


def read(p):return json.loads(p.read_text(encoding='utf-8'))


def main():
    data=read(OUT/'fit_summary.json');assert data['status']=='complete' and len(data['records'])==32
    rows=[]
    for r in data['records']:
        folder=ROOT/('candidates' if r['family']=='frozen' else 'joint_candidates')/f"{r['variant']}_seed{r['seed']}"
        val=read(folder/'complete.json')['validation'] if r['stage']=='best' else read(folder/'history.json')[-1]['validation']
        rows.append(dict(**r,validation=val))
    result=dict(status='complete',training_updates=0,test_read=False,rows=rows,
        conclusion='Local losses improve training fit, but much of recall comes with notch filling; even stronger background loss leaves a marked train/validation gap. This is evidence of localization/generalization difficulty, not proof of a unique cause.',
        next='Matched same-architecture gate_control versus gate_supervised, explicit loss-only bump localization, 2 seeds, frozen features; no FEM training; stricter predeclared neighbor-FP guard.')
    (OUT/'fit_comparison.json').write_text(json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')
    lines=['# 训练拟合补充诊断','',
        '只读取现有 best/last 检查点，对全部 3400 训练病例推理，与对应保存的 720 例验证比较。未训练、未改权重、未读取测试。','',
        '| 方案 | 种子 | 权重/轮数 | 训练局部 IoU | 验证局部 IoU | 训练/验证凸起召回 | 训练/验证邻近误填 |',
        '|---|---|---|---:|---:|---:|---:|']
    for r in rows:
        t=r['train']['E'];v=r['validation']['E']
        lines.append(f"| {r['variant']} | {r['seed']} | {r['stage']}/{r['checkpoint_epoch']} | {t['local_iou']:.4f} | {v['local_iou']:.4f} | {t['bump_recall']:.4f}/{v['bump_recall']:.4f} | {t['neighbor_false_addition']:.4f}/{v['neighbor_false_addition']:.4f} |")
    lines+=['','局部监督最后一轮的训练召回很高，但误填也高，不能解释为学会了正确凸起。加强误填约束后训练局部 IoU 约 0.52–0.55，而验证只有 0.30–0.32。说明不仅有修正方向问题，也有定位/泛化困难；不能凭这个差距认定单一根因。','',
        '以下一项受控几何探针检验：显式凸起定位门控，对照完全相同结构但无定位辅助监督。真值区域只参与训练损失；推理门控由测量特征预测，修正支持区由模型预测轮廓生成，不用真值框、真值类别或几何参数。','',
        '新实验在 localization_probe/ 单独冻结，旧所有协议、权重不变。两个方案各两种子，12–24 轮。全体/A 类 IoU 退步上限仍为 0.002；邻近误填容许增幅从前轮 0.02 收紧至 0.005，并在本轮训练前固定。此轮是观察验证失败后的探索性跟进，不是独立确认实验。','',
        '本轮仍不做 FEM 训练，不替代原 K3。只有定位收益稳定、误填可控且真实图像支持后，才将冻结候选接入实时 K3 验证。']
    (OUT/'TRAIN_FIT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    fig,axes=plt.subplots(1,2,figsize=(12,5),constrained_layout=True)
    variants=sorted({r['variant'] for r in rows})
    for j,stage in enumerate(('best','last')):
        for v in variants:
            rr=[r for r in rows if r['stage']==stage and r['variant']==v]
            axes[j].scatter([r['train']['E']['local_iou'] for r in rr],[r['validation']['E']['local_iou'] for r in rr],label=v,s=36)
        axes[j].plot([.2,.65],[.2,.65],'k--',lw=1)
        axes[j].set_xlabel('Training local IoU');axes[j].set_ylabel('Validation local IoU')
        axes[j].set_title(stage+' checkpoint: same 2 seeds per arm')
    axes[1].legend(fontsize=8,loc='upper left')
    fig.suptitle('Training fit versus validation transfer\nHigh recall with notch filling is not faithful bump recovery')
    fig.savefig(OUT/'train_validation_gap.png',dpi=160);plt.close(fig)
    print(json.dumps({'status':'complete','checkpoints':len(rows),'test_read':False}))


if __name__=='__main__':main()
