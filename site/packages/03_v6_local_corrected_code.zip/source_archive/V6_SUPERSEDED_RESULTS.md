# Superseded v6 Results

The unprefixed v6 result directories are retained for provenance but are not
authoritative. Their Notch evaluation used a `uint8` array as a NumPy index,
which invoked integer advanced indexing instead of Boolean-mask indexing.

Superseded families include:

- `topology_local_eit_v6_seed_*`
- `topology_local_eit_v6_multiseed_final`
- `topology_local_eit_v6_ablation_*`
- `topology_local_eit_v6_strict_ablation_final`
- `topology_local_eit_v6_measurement_shift_final`
- `topology_local_eit_v6_physical_mismatch_final`

Use only the corresponding `topology_local_eit_v6_corrected_*` directories and
the final package at `topology_local_eit_v6_corrected_paper_final` for figures,
tables, or manuscript claims.

The old outputs have not been deleted or modified.
