# v6 模型独立包

本包是 corrected v6 local topology corrector + dual-risk gate 的独立快照，包含冻结 v4 前级。

## 模型组成

1. 冻结 v4 anchor：先由 v4 输出三类概率、SDF、cutout/mouth/connected-cutout/effective-cutout、Δσ 和物理反投影。v6 不直接使用真值作为输入。
2. 15 通道 truth-blind 特征：3 类 anchor probability、熵、5 个 v4 几何图、Δσ、归一化线性图、平滑图、边缘图、物理反投影和 FOV。
3. LocalTopologyCorrectorV6：残差卷积编码器、三层下采样、膨胀残差 context、U-Net 式跳连解码器；输出 raw removal、mouth、local confidence。
4. 拓扑约束：max-pool 可达性传播把切除限制为从 mouth/背景连通的区域；candidate foreground = anchor foreground × (1−maximum_removal×removal)。因此 v6 是局部前景删除器，不会凭空生成完整病灶。
5. DualRiskQuantileGate：多层感知器 + LayerNorm、SiLU、Dropout，预测三组风险/收益的 q20/q50/q80：凹陷收益、IoU 损失、病灶主体误删损失。
6. 路由规则：收益 q20 > 0，IoU 损失 q80 ≤ 0.006，主体误删 q80 ≤ 0.05 时才采用 candidate，否则精确回退 v4 anchor。阈值只在合成验证集确定。
7. 损失：raw/effective removal BCE/Dice、mouth BCE/Dice、candidate foreground BCE/Dice、主体保护、凹口填充、凹陷深度、外部编辑、普通病例编辑、面积预算和边界损失。

## 亮点和创新

- 把 v4 的直接重建和局部拓扑修改解耦，专门针对 inward boundary，而不是重新学习整个 EIT 逆问题。
- 显式表示 removal/mouth/connectivity，避免用平滑正则把凹口填平。
- 风险门控同时估计“可能有收益”和“可能伤害主体”，不是只按置信度开关。
- 精确 anchor fallback 提供普通病例安全机制。
- 多数据源、噪声、测量缺失和物理失配评估都以相同输入下的相对改善为主。

## 结果边界

修正版报告显示：生物凹病例 IoU 平均增量约 +0.00065，凹陷趋势指标增量约 +0.00676；普通病例 IoU 平均增量约 −0.00083，仍有约 2.25% 严重下降病例。因此不能表述为普通病例绝对无损，也不能表述为大幅提升。

## 运行

`python run_model.py verify` 校验包；`python run_model.py infer-four --device cuda` 做四病例前向和图片输出；`python run_model.py train --seeds 20260911 --device cuda` 在冻结 v4 上继续训练新的 v6。

本包不含超声输入、不含临床数据，也不把内部 FEM 电势场作为网络输入。

## 已完成的包内验证

`checks/four_cases/forward_check.json` 是本包重新加载四个种子的短前向记录；`seed_20260911.png` 等图片为 Truth / Routed v4 / v6 final 对照。验证检查了输出有限值、15 通道特征尺寸以及“只从前景删除”的结构约束，未更新权重。
