"""Portable entry point for the exported research snapshot; no training by default."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / 'eit_reproduction'
sys.path.insert(0, str(PROJECT))
sys.path.insert(0, str(PROJECT / 'scripts'))

def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def verify():
    manifest = read_json(ROOT/'MANIFEST.json')
    for number, row in enumerate(manifest['files'], 1):
        p = ROOT/row['path']
        digest = hashlib.sha256()
        with p.open('rb') as stream:
            for block in iter(lambda: stream.read(8*1024*1024), b''):
                digest.update(block)
        if p.stat().st_size != row['size'] or digest.hexdigest() != row['sha256']:
            raise RuntimeError('Integrity mismatch: '+row['path'])
        if number % 100 == 0:
            print('Verified',number,'/',len(manifest['files']),flush=True)
    print('PASS:',len(manifest['files']),'files verified',flush=True)

def run_train(args, config):
    seed = args.seeds[0]
    if len(args.seeds) != 1:
        raise ValueError('Train one seed per command; use --seeds 20260911')
    state = config['runs'][str(seed)]
    output = (args.output or ROOT/'new_runs'/f'{config["version"]}_{seed}').resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError('Choose an empty --output directory; archival weights are never overwritten')
    output.mkdir(parents=True, exist_ok=True)
    command = [sys.executable, str(PROJECT/'scripts'/config['training_script']),
               '--output-dir',str(output),'--seed',str(seed),'--device',args.device]
    if config['version'] == 'v4':
        command += ['--architecture','v4','--epochs','80','--patience','18',
                    '--batch-size','18','--base-channels','28','--learning-rate','0.0004',
                    '--weight-decay','0.0001','--stress-repeat','2','--ordinary-repeat','4',
                    '--physics-weight','0.00015','--topology-start','4','--topology-ramp','10',
                    '--disable-amp']
    else:
        command += ['--checkpoint',str(ROOT/state['v4_checkpoint']),
                    '--anchor-router',str(ROOT/state['v4_router']),
                    '--epochs','54','--patience','12','--batch-size','28',
                    '--base-channels','24','--gate-epochs','260','--gate-patience','36']
    command += args.extra
    print('Launching:',subprocess.list2cmdline(command),flush=True)
    subprocess.run(command,cwd=ROOT,check=True)

def infer(args, config):
    import numpy as np
    import scipy.io as sio
    import torch
    import torch.nn.functional as F
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from pytorch_eit.topology_residual_net import TopologyResidualEITNet
    from score_ktc2023_outputs import ktc_score_fft
    torch.set_num_threads(4)
    device = torch.device('cuda' if args.device=='auto' and torch.cuda.is_available()
                          else 'cpu' if args.device=='auto' else args.device)
    if device.type=='cuda' and not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable; use --device cpu')
    output = (args.output or ROOT/'checks'/'four_cases').resolve()
    output.mkdir(parents=True, exist_ok=True)
    repo = PROJECT/'external'/'KTC2023-ABC2'
    with np.load(PROJECT/'datasets'/'ktc_shape_nonlinear_v1.npz',allow_pickle=False) as z:
        fov_np = z['fov_mask'].astype(np.float32)
        operator = z['reconstruction_operator'].astype(np.float32)
        mapping = z['raw_pixel_to_node'].astype(np.int64)
        jacobian = z['jacobian'].astype(np.float32)
        node_mapping = z['node_to_raw_pixel'].astype(np.int64)
    ref = sio.loadmat(repo/'utils'/'reference_files'/'ref.mat')['Uelref'].reshape(-1)
    volts, images, truths = [],[],[]
    for number in range(1,5):
        measurement = sio.loadmat(repo/'inputs'/f'data{number}.mat')['Uel'].reshape(-1)
        v = (2*(measurement-ref)).astype(np.float32)
        volts.append(v)
        images.append(np.flip((v@operator.T)[mapping].reshape(64,64),axis=0).copy())
        truths.append(sio.loadmat(repo/'groundTruths'/f'true{number}.mat')['truth'].astype(np.uint8))
    x = torch.from_numpy(np.stack(images)[:,None]).to(device)
    v = torch.from_numpy(np.stack(volts)).to(device)
    fov = torch.from_numpy(fov_np)[None,None].to(device)
    truths = np.stack(truths)
    report = {'version':config['version'],'device':str(device),'torch':torch.__version__,
              'scope':'Frozen-weight forward check on the four ABC2 cases; no optimization or threshold selection',
              'source_modules':{},'runs':{}}
    if config['version']=='v6':
        import train_local_topology_corrector_v6 as v6
        report['source_modules']['v6']=str(Path(v6.__file__).relative_to(ROOT))
    import pytorch_eit.topology_residual_net as source_v4
    report['source_modules']['v4']=str(Path(source_v4.__file__).relative_to(ROOT))
    for seed in args.seeds:
        paths=config['runs'][str(seed)]
        state=torch.load(ROOT/paths['v4_checkpoint'],map_location='cpu',weights_only=False)
        model=TopologyResidualEITNet(fov_np,base=state['base_channels'],
              propagation_steps=state.get('propagation_steps',14),risk_aware=state['risk_aware']).to(device)
        model.load_state_dict(state['model'],strict=True)
        model.eval()
        run={'v4_parameters':sum(p.numel() for p in model.parameters()),'v4_epoch':state['epoch']}
        del state
        with torch.no_grad():
            values=model(x,v)
            assert all(torch.isfinite(t).all() for t in values.values()), 'Nonfinite v4 output'
            gate4=values['case_gate'][:,0,0,0]
            route4=gate4>=paths['v4_threshold']
            anchor=torch.where(route4[:,None,None,None],values['probabilities'],values['base_probabilities'])
            if config['version']=='v6':
                bp=v6.physics_backprojection(values['delta'],v,torch.from_numpy(jacobian).to(device),
                                             torch.from_numpy(node_mapping).to(device))
                maps=torch.cat([values[k] for k in ['sdf','raw_cutout_probability',
                    'connected_cutout_probability','mouth_probability','effective_cutout_probability','delta']]+[bp],1)
                # Original v6 training/evaluation cache stores these fields as float16.
                anchor=anchor.to(torch.float16).float()
                maps=maps.to(torch.float16).float()
                cs=torch.load(ROOT/paths['corrector_checkpoint'],map_location='cpu',weights_only=False)
                corrector=v6.LocalTopologyCorrectorV6(input_channels=cs.get('input_channels',15),
                    base_channels=cs.get('base_channels',24),enforce_connectivity=cs.get('enforce_connectivity',True)).to(device)
                corrector.load_state_dict(cs['model'],strict=True)
                corrector.eval()
                run['corrector_parameters']=sum(p.numel() for p in corrector.parameters())
                gs=torch.load(ROOT/paths['risk_checkpoint'],map_location='cpu',weights_only=False)
                gate=v6.DualRiskQuantileGate(len(gs['feature_names'])).to(device)
                gate.load_state_dict(gs['model'],strict=True)
                gate.eval()
                run['gate_parameters']=sum(p.numel() for p in gate.parameters())
                features=v6.build_features(anchor,maps,x,fov)
                edited=corrector(features,anchor,fov)
                gfeatures=v6.extract_gate_features(edited,anchor,maps,x,gate4,route4.float(),fov)
                quantiles=v6.risk_predictions(gate,gfeatures.cpu().numpy(),np.asarray(gs['feature_mean']),
                                             np.asarray(gs['feature_std']),device)
                selected=v6.apply_gate(quantiles,paths['gate_rule'])
                candidate=edited['candidate_probabilities']
                assert torch.isfinite(features).all() and torch.isfinite(candidate).all()
                assert np.isfinite(quantiles).all()
                run['feature_shape']=list(features.shape)
                run['gate_selected']=selected.tolist()
                run['risk_quantiles']=quantiles.tolist()
                run['only_removes_foreground']=bool(torch.all(edited['candidate_foreground']<=edited['anchor_foreground']+1.1e-6))
            else:
                candidate=values['probabilities']
                selected=route4.cpu().numpy()
            anchor_pred=F.interpolate(anchor,(256,256),mode='bilinear',align_corners=False).argmax(1).cpu().numpy().astype(np.uint8)
            candidate_pred=F.interpolate(candidate,(256,256),mode='bilinear',align_corners=False).argmax(1).cpu().numpy().astype(np.uint8)
            final=np.where(selected[:,None,None],candidate_pred,anchor_pred) if config['version']=='v6' else anchor_pred
        run['cases']=[]
        for i in range(4):
            ious=[]
            for c in [1,2]:
                a,b=truths[i]==c,final[i]==c
                union=np.logical_or(a,b).sum()
                ious.append(float(np.logical_and(a,b).sum()/union) if union else 1.0)
            run['cases'].append({'case':f'data{i+1}','mean_iou':float(np.mean(ious)),
                                 'ktc_ssim':float(ktc_score_fft(truths[i],final[i]))})
        np.savez_compressed(output/f'seed_{seed}.npz',truth=truths,anchor=anchor_pred,candidate=candidate_pred,final=final)
        fig,axes=plt.subplots(4,3,figsize=(8,10),constrained_layout=True)
        for i in range(4):
            for j,(arr,title) in enumerate([(truths[i],'Truth'),(anchor_pred[i],'Routed v4'),(final[i],config['version']+' final')]):
                axes[i,j].imshow(arr,vmin=0,vmax=2,cmap='viridis')
                axes[i,j].set_title(f'data{i+1}: {title}')
                axes[i,j].axis('off')
        fig.savefig(output/f'seed_{seed}.png',dpi=130)
        plt.close(fig)
        report['runs'][str(seed)]=run
        print('PASS forward',config['version'],'seed',seed,'parameters',run,flush=True)
        del model,values
        if config['version']=='v6':
            del corrector,gate,cs,gs,edited
        if device.type=='cuda':
            torch.cuda.empty_cache()
    (output/'forward_check.json').write_text(json.dumps(report,indent=2,allow_nan=False),encoding='utf-8')
    print('Saved:',output,flush=True)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['verify','infer-four','train'])
    parser.add_argument('--seeds',type=int,nargs='+',default=[20260911,20260912,20260913,20260914])
    parser.add_argument('--device',choices=['auto','cpu','cuda'],default='auto')
    parser.add_argument('--output',type=Path)
    parser.add_argument('--extra',nargs=argparse.REMAINDER,default=[])
    args=parser.parse_args()
    config=read_json(ROOT/'PACKAGE_CONFIG.json')
    if args.action=='verify': verify()
    elif args.action=='train': run_train(args,config)
    else: infer(args,config)

if __name__=='__main__':
    main()
