# v4 模型独立包

本包是 physics/topology-aware direct reconstruction v4 的独立快照。

## 模型组成

1. 输入：64×64 的 EIT 线性初始图像与有序 76×31 电压表。输入适配器做中位数中心化、0.985 分位数尺度归一化、平滑和 Sobel 边缘提取。
2. 图像主干：残差卷积块 + GroupNorm + SiLU，四级编码器/解码器；解码阶段有 skip projection 和空间门控，属于带 attention gate 的双 U-Net 风格结构。
3. 电压分支：残差 CNN 编码 76×31 表格，通过自适应池化形成瓶颈特征。
4. 融合：图像瓶颈与电压瓶颈拼接，经残差块融合。
5. 输出：三类电气类别 logits、foreground SDF、Δσ 回归图；第二个 topology decoder 预测 cutout、mouth、local gate 和 case gate。
6. 拓扑机制：cutout 必须从 mouth 或已识别背景可达，使用 max-pool 传播构造 exterior-connected correction，避免孤立孔洞；最终只从 v4 foreground 中减去 cutout。
7. 损失：基础/最终交叉熵和 Dice、SDF smooth-L1、边界梯度损失、Δσ smooth-L1、物理电压一致性损失，以及 cutout BCE/Dice、mouth、clDice、凹陷深度、面积预算、普通病例保护和 gate 损失。
8. 正则化：GroupNorm、Dropout2d、AdamW weight decay、梯度裁剪、early stopping；物理项是软正则，不是硬求解器。

这不是 DIP，也不是随机初始化后逐病例优化；训练时网络随机初始化一次，之后用合成训练集监督学习。

## 亮点和创新

- 把完整病灶恢复与“从边界中挖出凹口”分解，显式建模内凹拓扑。
- 将有序电压表和空间线性重建图联合编码。
- 采用可达性约束，降低普通病例产生孤立伪孔的风险。
- 使用验证集路由的 case gate，在不适合修正时保留直接分支。
- v4 的真正贡献是拓扑感知局部修正，不是声称所有普通病例都绝对提升。

## 结果

正式权重来自 CUDA、4 个随机种子，训练/选择未使用公开 KTC 测试真值。`results/` 中保存权重、预测、训练历史、图像、路由及多种子汇总。

## 运行

`python run_model.py verify` 校验包；`python run_model.py infer-four --device cuda` 做四病例短前向检查；`python run_model.py train --seeds 20260911 --device cuda` 从头训练新实验。

依赖：Python 3.10+、PyTorch 2.x、NumPy、SciPy、Matplotlib、Pillow。

## 已完成的包内验证

`checks/four_cases/forward_check.json` 是本包重新加载四个种子后的短前向记录；`seed_20260911.png` 等图片为 Truth / Routed v4 对照。验证使用 CUDA 环境，未更新权重。
