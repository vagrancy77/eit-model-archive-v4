"""One fresh process per configuration, exclusive QA window, TRAIN only."""
import sys,json,time,hashlib,gc,argparse
from pathlib import Path
sys.path.insert(0,'E:/Codex')
from eit_execution_accel_v5.resources import Guard,memory,GIB
guard=Guard().start()
import numpy as np
import torch
from torch.utils.data import default_collate
from eit_old_champion_selection_v1.model import Combined,loss,model_inputs
from eit_old_champion_selection_v1.config import SEED,ABLATIONS
from eit_champion_adaptive_v3.data import StrictChampionDataset
from eit_champion_adaptive_v3.fem import PixelConformingFEM
from eit_execution_accel_v5.backend import ParallelFEM,forward_voltage,state_digest
from comsol_feedback.fem import forward_voltage as serial_voltage
import comsol_feedback_loop.model as physics
from common import DATA,NORMALIZER
from comsol_v4.data_v6 import Normalizer,grid_arrays,file_hash
from comsol_feedback_loop.io import write_json
ROOT=Path('E:/Codex/old_champion_selection_v1/execution_accel_v5')

def fingerprint(value):
    h=hashlib.sha256()
    def visit(v):
        if torch.is_tensor(v):
            a=v.detach().cpu().contiguous().numpy();h.update(str((a.dtype,a.shape)).encode());h.update(a.tobytes())
        elif isinstance(v,dict):
            for k,item in v.items():h.update(str(k).encode());visit(item)
        elif isinstance(v,(list,tuple)):
            for item in v:visit(item)
        else:h.update(repr(v).encode())
    visit(value);return h.hexdigest()

class AuditedFEM(ParallelFEM):
    def __init__(self,*a,reference,**kw):
        super().__init__(*a,**kw);self.reference=reference;self.audit=True;self.checked_forward=0;self.checked_vjp=0;self.materials={}
    def solve_batch(self,arrays):
        result=super().solve_batch(arrays)
        if self.audit:
            for array,(v,handle) in zip(arrays,result):
                w,state=self.reference.solve(array)
                assert v.tobytes()==w.tobytes() and self.diagnostic_state_digest(handle)==state_digest(state)
                self.materials[handle]=array.copy();self.checked_forward+=1
                del state,w
        return result
    def vjp_batch(self,handles,arrays):
        result=super().vjp_batch(handles,arrays)
        if self.audit:
            for handle,array,value in zip(handles,arrays,result):
                _,state=self.reference.solve(self.materials[handle])
                reference=self.reference.vjp(state,array)
                assert value.tobytes()==reference.tobytes();self.checked_vjp+=1
                del state,reference
        return result

def main(index,kind,operation):
    assert kind in ('serial','parallel') and operation in ('parity','benchmark')
    arms=[]
    for projection in (False,True):
        arms.extend([dict(id=f'p{int(projection)}_{mode}',projection=projection,loop=mode) for mode in ('fixed3','adaptive')])
        arms.extend([dict(id=f'p{int(projection)}_no_{a}',projection=projection,loop='adaptive',ablate=a) for a in ABLATIONS])
    arms.append(dict(id='trained_oc_adaptive',projection=False,loop='adaptive'))
    arm=arms[index];path=ROOT/'cases'/f"{index:02d}_{kind}_{operation}.json"
    assert not path.exists()
    assert memory()['available_commit']>5*GIB
    torch.set_num_threads(2);torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
    x,y,fov=grid_arrays(DATA);serial=PixelConformingFEM(x,y,fov)
    fast=AuditedFEM(x,y,fov,reference=serial) if kind=='parallel' else None
    if fast:fast.audit=operation=='parity'
    solver=serial if kind=='serial' else fast
    norm=Normalizer.load(NORMALIZER,DATA);ds=StrictChampionDataset(DATA,'train',norm,serial,limit=4)
    j=2*(index%2);raw=default_collate([ds[j],ds[j+1]]);b={k:v.cuda() if torch.is_tensor(v) else v for k,v in raw.items()}
    torch.manual_seed(SEED);torch.cuda.manual_seed_all(SEED);m=Combined(solver,arm).cuda()
    checkpoint=None
    if index==12:
        cp=ROOT.parent/'runs/oc_adaptive/last.pt';ck=torch.load(cp,map_location='cpu',weights_only=True)
        assert ck['step']==256;m.load_state_dict(ck['model'],strict=True);del ck;checkpoint=file_hash(cp)
    physics.forward_voltage=serial_voltage if kind=='serial' else forward_voltage
    rng=torch.get_rng_state();cuda_rng=torch.cuda.get_rng_state_all()
    print(json.dumps(dict(stage='model_ready',kind=kind,operation=operation,memory=memory())),flush=True)
    record=dict(index=index,arm=arm,kind=kind,operation=operation,case_ids=raw['case_id'],checkpoint_sha256=checkpoint,test_read=False)
    try:
        if operation=='parity':
            m.train();m.zero_grad(set_to_none=True);torch.set_rng_state(rng);torch.cuda.set_rng_state_all(cuda_rng)
            out=m(*model_inputs(b));value,score=loss(out,b,m.fov,arm)
            record['train_forward_hash']=fingerprint((out,value,score));record['train_stops']=out['stop_trace']
            value.backward()
            assert all(p.grad is None or torch.isfinite(p.grad).all() for p in m.parameters())
            del out,value,score;m.zero_grad(set_to_none=True);gc.collect()
            print(json.dumps(dict(stage='backward_done',memory=memory())),flush=True)
            m.eval()
            with torch.no_grad():out=m(*model_inputs(b))
            record['eval_hash']=fingerprint(out);record['eval_stops']=out['stop_trace'];del out
            record['checked_frequency_forwards']=fast.checked_forward if fast else 0
            record['checked_frequency_vjps']=fast.checked_vjp if fast else 0
        else:
            original={k:v.detach().cpu().clone() for k,v in m.state_dict().items()}
            times=[]
            # One warm-up, one measured update in a FRESH process per backend.
            # No empty_cache churn, and no surviving loss graph across iterations.
            for rep in range(2):
                m.load_state_dict(original,strict=True);m.train();m.zero_grad(set_to_none=True)
                torch.set_rng_state(rng);torch.cuda.set_rng_state_all(cuda_rng)
                opt=torch.optim.AdamW(m.optimizer_groups(),weight_decay=1e-4)
                torch.cuda.synchronize();t=time.perf_counter()
                out=m(*model_inputs(b));value,score=loss(out,b,m.fov,arm);torch.cuda.synchronize();t1=time.perf_counter()
                value.backward();torch.nn.utils.clip_grad_norm_(m.parameters(),1.,error_if_nonfinite=True);opt.step();torch.cuda.synchronize();t2=time.perf_counter()
                times.append(dict(forward=t1-t,backward_optimizer=t2-t1,total=t2-t))
                del out,value,score,opt;m.zero_grad(set_to_none=True);gc.collect()
                print(json.dumps(dict(stage='update_done',rep=rep,memory=memory())),flush=True)
            record['times']=times
            # Same-weight inference timing, after train buffers are released.
            m.load_state_dict(original,strict=True);m.eval();torch.cuda.synchronize();t=time.perf_counter()
            with torch.no_grad():out=m(*model_inputs(b))
            torch.cuda.synchronize();record['eval_seconds']=time.perf_counter()-t;del out
        gc.collect()
        if fast:assert fast.live_state_count()==0,'Unreleased FEM states after model graph cleanup'
        record.update(status='PASS',resources=guard.report(),full_training_bitwise_identity=False)
        write_json(path,record);print(json.dumps(dict(status='PASS',index=index,kind=kind,operation=operation,resources=guard.report())),flush=True)
    finally:
        m.close()
        if fast:fast.close()
        guard.close()
if __name__=='__main__':main(int(sys.argv[1]),sys.argv[2],sys.argv[3])
