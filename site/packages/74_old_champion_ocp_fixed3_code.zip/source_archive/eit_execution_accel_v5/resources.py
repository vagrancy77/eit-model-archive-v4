"""Windows resource guard for isolated QA, never a training budget."""
import ctypes,threading,time,os,json
from ctypes import wintypes
GIB=1024**3
class MEMORYSTATUSEX(ctypes.Structure):
    _fields_=[('dwLength',wintypes.DWORD),('dwMemoryLoad',wintypes.DWORD)]+[(n,ctypes.c_ulonglong) for n in ('ullTotalPhys','ullAvailPhys','ullTotalPageFile','ullAvailPageFile','ullTotalVirtual','ullAvailVirtual','ullAvailExtendedVirtual')]
class COUNTERS(ctypes.Structure):
    _fields_=[('cb',wintypes.DWORD),('PageFaultCount',wintypes.DWORD)]+[(n,ctypes.c_size_t) for n in ('PeakWorkingSetSize','WorkingSetSize','QuotaPeakPagedPoolUsage','QuotaPagedPoolUsage','QuotaPeakNonPagedPoolUsage','QuotaNonPagedPoolUsage','PagefileUsage','PeakPagefileUsage','PrivateUsage')]
ctypes.windll.psapi.GetProcessMemoryInfo.argtypes=[wintypes.HANDLE,ctypes.POINTER(COUNTERS),wintypes.DWORD]
def memory():
    s=MEMORYSTATUSEX();s.dwLength=ctypes.sizeof(s);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(s))
    c=COUNTERS();c.cb=ctypes.sizeof(c)
    ctypes.windll.kernel32.GetCurrentProcess.restype=wintypes.HANDLE
    assert ctypes.windll.psapi.GetProcessMemoryInfo(ctypes.windll.kernel32.GetCurrentProcess(),ctypes.byref(c),c.cb)
    return dict(available_physical=s.ullAvailPhys,available_commit=s.ullAvailPageFile,private_bytes=c.PrivateUsage,working_set=c.WorkingSetSize)
class Guard:
    def __init__(self):self.peak=0;self.min_commit=10**30;self.min_physical=10**30;self.done=threading.Event()
    def start(self):
        def check():
            while not self.done.wait(.25):
                m=memory();self.peak=max(self.peak,m['private_bytes']);self.min_commit=min(self.min_commit,m['available_commit']);self.min_physical=min(self.min_physical,m['available_physical'])
                if m['available_commit']<2.5*GIB or m['available_physical']<.75*GIB or m['private_bytes']>10*GIB:
                    print(json.dumps(dict(status='QA_RESOURCE_GUARD_STOP',memory=m)),flush=True);os._exit(77)
        self.thread=threading.Thread(target=check,daemon=True);self.thread.start();return self
    def report(self):return dict(peak_private_bytes=self.peak,min_available_commit=self.min_commit,min_available_physical=self.min_physical)
    def close(self):self.done.set();self.thread.join()
