"""Read/check/hash saved work, acquire OS lock, create new QA handoff record."""
import sys,json,time,hashlib,msvcrt
from pathlib import Path
sys.path.insert(0,'E:/Codex')
from eit_execution_accel_v5.qa_queue import ROOT,OUT,read,sha,write
def main():
    with (ROOT/'worker.lock').open('r+b') as lock:
        lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        c=read(ROOT/'runs/oc_adaptive/complete.json');assert c['steps']==256
        assert c['protocol_sha256']==sha(ROOT/'protocol.json')
        assert c['checkpoint_sha256']==sha(ROOT/'runs/oc_adaptive'/c['selected_checkpoint'])
        assert not (ROOT/'runs/oc_fixed3/last.pt').exists()
        prior=read(ROOT/'execution_accel_v2/handoff_ready.json')
        for path,h in prior['protected_files'].items():assert sha(path)==h,path
        s=prior['prior_status'];assert s['arm']=='oc_fixed3' and s['phase']=='validation' and s['tag']=='initial'
        paths=list((ROOT/'runs/oc_adaptive').rglob('*'))+[ROOT/'protocol.json',ROOT/'training_order.json']
        protected={str(p):sha(p) for p in paths if p.is_file()}
        for tag in ('initial','trained'):
            r=read(ROOT/'runs/oc_adaptive'/(tag+'.json'));assert r['prediction_sha256']==sha(ROOT/'runs/oc_adaptive'/(tag+'.npz'))
        assert not (OUT/'handoff_ready.json').exists()
        write(OUT/'handoff_ready.json',dict(status='PRIOR_ARM_COMPLETE_OS_LOCK_FREE',protected_files=protected,prior_status=s,
                                          protocol_sha256=sha(ROOT/'protocol.json'),time_unix=time.time(),test_read=False))
        print('Exclusive QA handoff PASS')
if __name__=='__main__':main()
