$ErrorActionPreference='Stop'
$existing=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^python(w)?\.exe$' -and ($_.CommandLine -match 'eit_old_champion_selection_v1[/\\]run\.py|eit_execution_accel_v[12345][/\\](qa_queue|qa_case|accelerated_run|boundary_probe|model_probe|repeatability_probe)\.py') })
if ($existing.Count -gt 0) { throw "Conflicting compute processes: $($existing.ProcessId -join ',')" }
$root='E:/Codex/old_champion_selection_v1'
if (-not (Test-Path -LiteralPath "$root/execution_accel_v5/acceptance.json")) { throw 'Missing complete acceleration acceptance' }
& E:/conda-envs/pytorch-gpu/python.exe -B -c "import msvcrt; f=open(r'E:/Codex/old_champion_selection_v1/worker.lock','r+b'); f.seek(0); msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1); msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1); f.close(); print('worker.lock FREE')"
if ($LASTEXITCODE -ne 0) { throw 'OS lock busy; do not duplicate worker' }
$stamp=Get-Date -Format 'yyyyMMdd_HHmmss_fff'
$p=Start-Process -FilePath 'E:/conda-envs/pytorch-gpu/python.exe' -ArgumentList @('-B','-u','E:/Codex/eit_execution_accel_v5/accelerated_run.py') -WorkingDirectory 'E:/Codex' -WindowStyle Hidden -RedirectStandardOutput "$root/worker_accel_v5_$stamp.stdout.log" -RedirectStandardError "$root/worker_accel_v5_$stamp.stderr.log" -PassThru
Write-Output "Accelerated worker PID $($p.Id); logs $root/worker_accel_v5_$stamp.*.log"
