"""Owner-thread SuperLU lifecycle; exact original arithmetic, two frequencies.

SciPy/SuperLU allocations made in a worker must also be released there on this
Windows build. Main/autograd retains opaque handles, NEVER cross-thread LU.
"""
import weakref,hashlib
from concurrent.futures import ThreadPoolExecutor
from collections import defaultdict,deque
import numpy as np
import torch
from eit_execution_accel_v1.backend import ParallelFEM as Arithmetic,_LIMIT_LOCK

def state_digest(state):
    lu,u=state;h=hashlib.sha256()
    arrays=[u,lu.perm_r,lu.perm_c]
    for a in (lu.L,lu.U):arrays.extend((a.data,a.indices,a.indptr))
    for a in arrays:h.update(str((a.dtype,a.shape)).encode());h.update(a.tobytes())
    return h.hexdigest()

class ParallelFEM(Arithmetic):
    def __init__(self,*args,workers=2,**kwargs):
        super().__init__(*args,workers=workers,**kwargs);self.pool.shutdown(wait=True)
        self.owners=[ThreadPoolExecutor(max_workers=1,thread_name_prefix=f'fem-owner-{i}') for i in range(workers)]
        self._states=[{} for _ in self.owners];self._sequence=[0 for _ in self.owners];self._closed=False
        self.timings=defaultdict(lambda:deque(maxlen=256))
    def _store(self,owner,gamma):
        voltage,state=self._solve_kernel(gamma);self._sequence[owner]+=1;key=self._sequence[owner]
        self._states[owner][key]=state
        return voltage,(owner,key)
    def _owned_vjp(self,handle,gradient):
        owner,key=handle;return self._vjp_kernel(self._states[owner][key],gradient)
    def solve_batch(self,arrays):
        with _LIMIT_LOCK,self.controller.limit(limits=1):
            tasks=[self.owners[i%len(self.owners)].submit(self._store,i%len(self.owners),a) for i,a in enumerate(arrays)]
            return [t.result() for t in tasks]
    def vjp_batch(self,handles,arrays):
        with _LIMIT_LOCK,self.controller.limit(limits=1):
            tasks=[self.owners[h[0]].submit(self._owned_vjp,h,a) for h,a in zip(handles,arrays)]
            return [t.result() for t in tasks]
    def _release(self,owner,keys):
        for key in keys:self._states[owner].pop(key,None)
    def release_batch(self,handles):
        with _LIMIT_LOCK:
            if self._closed:return
            tasks=[]
            for owner,executor in enumerate(self.owners):
                keys=[h[1] for h in handles if h[0]==owner]
                if keys:tasks.append(executor.submit(self._release,owner,keys))
            for t in tasks:t.result()
    def diagnostic_state_digest(self,handle):
        owner,key=handle
        return self.owners[owner].submit(lambda:state_digest(self._states[owner][key])).result()
    def live_state_count(self):
        return sum(executor.submit(lambda owner=owner:len(self._states[owner])).result() for owner,executor in enumerate(self.owners))
    def close(self):
        with _LIMIT_LOCK:
            if self._closed:return
            self._closed=True
            for owner,executor in enumerate(self.owners):executor.submit(self._states[owner].clear).result()
            for executor in self.owners:executor.shutdown(wait=True)

class _OwnedFunction(torch.autograd.Function):
    @staticmethod
    def forward(ctx,gamma,solver):
        array=gamma.detach().cpu().numpy();solved=solver.solve_batch(array.reshape(-1,64,64))
        ctx.handles=[s[1] for s in solved];ctx.solver=solver;ctx.shape=gamma.shape
        # Survives retain_graph hint/backprop reuse. Release only with graph death.
        ctx.release=weakref.finalize(ctx,solver.release_batch,ctx.handles)
        return torch.as_tensor(np.stack([s[0] for s in solved]).reshape(*array.shape[:-2],32,32),device=gamma.device,dtype=gamma.dtype)
    @staticmethod
    def backward(ctx,grad):
        array=grad.detach().cpu().numpy().reshape(-1,32,32)
        result=np.stack(ctx.solver.vjp_batch(ctx.handles,array))
        return torch.as_tensor(result.reshape(ctx.shape),device=grad.device,dtype=grad.dtype),None

def forward_voltage(gamma,solver):return _OwnedFunction.apply(gamma,solver)
