$ErrorActionPreference='Stop'
$existing=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^python(w)?\.exe$' -and ($_.CommandLine -match 'eit_old_champion_selection_v1[/\\]run\.py|eit_execution_accel_v[12345][/\\](qa_queue|qa_case|accelerated_run|boundary_probe|model_probe|repeatability_probe)\.py') })
if ($existing.Count -gt 0) { throw "Conflicting compute processes: $($existing.ProcessId -join ',')" }
$root='E:/Codex/old_champion_selection_v1/execution_accel_v5'
if (-not (Test-Path -LiteralPath "$root/handoff_ready.json")) { throw 'Verify handoff first' }
$stamp=Get-Date -Format 'yyyyMMdd_HHmmss_fff'
$p=Start-Process -FilePath 'E:/conda-envs/pytorch-gpu/python.exe' -ArgumentList @('-B','-u','E:/Codex/eit_execution_accel_v5/qa_queue.py') -WorkingDirectory 'E:/Codex' -WindowStyle Hidden -RedirectStandardOutput "$root/queue_$stamp.stdout.log" -RedirectStandardError "$root/queue_$stamp.stderr.log" -PassThru
Write-Output "Exclusive QA PID $($p.Id), log $root/queue_$stamp.*.log"
