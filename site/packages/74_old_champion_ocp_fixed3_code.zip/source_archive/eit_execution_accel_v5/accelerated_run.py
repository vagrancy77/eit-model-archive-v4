"""Execution adapter only: original byte-frozen experiment, bounded telemetry."""
import sys,json,time,traceback
from pathlib import Path
sys.path.insert(0,'E:/Codex')
from eit_execution_accel_v5.backend import ParallelFEM,forward_voltage
from eit_old_champion_selection_v1 import run as original
from comsol_v4.data_v6 import file_hash
from comsol_feedback_loop.io import write_json
import comsol_feedback_loop.model as physics
ROOT=Path('E:/Codex/old_champion_selection_v1');OUT=ROOT/'execution_accel_v5'
def verify():
    a=json.loads((OUT/'acceptance.json').read_text(encoding='utf-8'))
    assert a['status']=='PASS' and a['isolated_processes']==52
    assert a['median_paired_train_speedup']>1.05 and a['median_paired_eval_speedup']>1.05
    for path,h in a['source_hashes'].items():assert file_hash(path)==h,path
    for path,h in a['case_hashes'].items():assert file_hash(path)==h,path
    assert file_hash('E:/Codex/eit_execution_accel_v1/backend.py')==a['inherited_backend_sha256']
    assert file_hash(ROOT/'execution_memory_v1/owned_backend_probe.json')==a['memory_stress_sha256']
    assert file_hash(ROOT/'protocol.json')==a['original_protocol_sha256']
    handoff=json.loads((OUT/'handoff_ready.json').read_text(encoding='utf-8'))
    for path,h in handoff['protected_files'].items():assert file_hash(path)==h,path
    return a
def main():
    a=verify();solvers=[]
    class RuntimeFEM(ParallelFEM):
        def __init__(self,*args,**kwargs):super().__init__(*args,**kwargs);solvers.append(self)
    original.PixelConformingFEM=RuntimeFEM;physics.forward_voltage=forward_voltage
    base_write=original.write_json
    def write_with_executor(path,value):
        if Path(path)==ROOT/'status.json':value={**value,'execution_backend':'dual_frequency_parallel_v5','execution_acceptance_sha256':file_hash(OUT/'acceptance.json')}
        return base_write(path,value)
    original.write_json=write_with_executor
    write_json(OUT/f'executor_start_{time.time_ns()}.json',dict(time_unix=time.time(),acceptance_sha256=file_hash(OUT/'acceptance.json'),
               scientific_protocol_sha256=a['original_protocol_sha256'],model_and_settings_changed=False,first_handoff_after_complete_arm='oc_adaptive'))
    try:original.main()
    finally:
        for s in solvers:s.close()
if __name__=='__main__':
    try:main()
    except Exception:
        write_json(ROOT/'error.json',dict(error=traceback.format_exc(),time_unix=time.time(),executor=__file__))
        s=original.read(ROOT/'status.json') if (ROOT/'status.json').exists() else {}
        write_json(ROOT/'status.json',{**s,'phase':'failed','updated_unix':time.time()});raise
