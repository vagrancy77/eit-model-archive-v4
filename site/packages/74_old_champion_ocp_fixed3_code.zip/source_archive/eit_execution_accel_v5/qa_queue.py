"""Exclusive QA, one backend/operation per subprocess; no formal training."""
import sys,json,time,subprocess,os,hashlib,statistics,msvcrt
from pathlib import Path
sys.path.insert(0,'E:/Codex')
from eit_execution_accel_v5.resources import memory,GIB
HERE=Path(__file__).parent;ROOT=Path('E:/Codex/old_champion_selection_v1');OUT=ROOT/'execution_accel_v5'
PY='E:/conda-envs/pytorch-gpu/python.exe'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,value):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(tmp,p)
def main():
    OUT.mkdir(exist_ok=True)
    with (ROOT/'worker.lock').open('r+b') as lock:
        lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        plan=read(OUT/'handoff_ready.json')
        stress_path=ROOT/'execution_memory_v1/owned_backend_probe.json';stress=read(stress_path)
        assert stress['status']=='PASS' and stress['cycles']==100 and stress['growth_after_warmup_bytes']<128*1024**2
        for path,h in plan['protected_files'].items():assert sha(path)==h,path
        assert memory()['available_commit']>8*GIB and memory()['available_physical']>4*GIB
        protocol=read(ROOT/'protocol.json');assert sha(ROOT/'protocol.json')==plan['protocol_sha256']
        for path,h in protocol['source_hashes'].items():assert sha(path)==h,path
        code_hashes={str(p):sha(p) for p in HERE.glob('*.py')};inherited_sha=sha('E:/Codex/eit_execution_accel_v1/backend.py')
        qa_protocol=dict(source_hashes=code_hashes,inherited_backend_sha256=inherited_sha,scientific_protocol_sha256=plan['protocol_sha256'],
            configurations=13,isolated_processes=52,train_case_count=4,scope='one backend and one operation per process; no concurrent formal training',
            memory_guards=dict(min_available_commit_gib=2.5,min_available_physical_gib=.75,max_probe_private_gib=10),test_read=False)
        if (OUT/'qa_protocol.json').exists():assert read(OUT/'qa_protocol.json')==qa_protocol
        else:write(OUT/'qa_protocol.json',qa_protocol)
        stamp=time.strftime('%Y%m%d_%H%M%S');start=read(ROOT/'launch.json')['started_unix']
        def status(done,phase='execution_verification'):
            obj=dict(phase=phase,pid=os.getpid(),updated_unix=time.time(),started_unix=start,total_arms=8,arm='execution_backend',processed=done,total=52,
                     wall_deadline=None,test_read=False,message='13配置×2后端×数值/测速分离，每项独立进程；正式训练暂歇，实验设置不变。')
            write(ROOT/'status.json',obj);write(OUT/'status.json',obj)
        tasks=[]
        for i in range(13):
            for op in ('parity','benchmark'):
                for kind in (('serial','parallel') if i%2==0 else ('parallel','serial')):tasks.append((i,kind,op))
        for done,(i,kind,op) in enumerate(tasks):
            for path,h in code_hashes.items():assert sha(path)==h,path
            assert sha('E:/Codex/eit_execution_accel_v1/backend.py')==inherited_sha
            target=OUT/'cases'/f'{i:02d}_{kind}_{op}.json'
            if target.exists():assert read(target)['status']=='PASS';continue
            status(done);log=OUT/f'qa_{i:02d}_{kind}_{op}_{stamp}.log'
            with log.open('w',encoding='utf-8') as f:
                proc=subprocess.Popen([PY,'-B','-u',str(HERE/'qa_case.py'),str(i),kind,op],stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
                tick=time.monotonic()
                while proc.poll() is None:
                    status(done)
                    if time.monotonic()-tick>600:proc.terminate();proc.wait();break
                    time.sleep(5)
            if proc.returncode!=0:
                write(OUT/'failure.json',dict(index=i,kind=kind,operation=op,exit_code=proc.returncode,log=str(log)));status(done,'execution_verification_failed');raise RuntimeError('QA failed; preserve evidence, no backend switch')
            print('QA PASS',i,kind,op,flush=True)
            if op=='parity':
                pair=[OUT/'cases'/f'{i:02d}_{k}_parity.json' for k in ('serial','parallel')]
                if all(p.exists() for p in pair):
                    a,b=[read(p) for p in pair]
                    assert a['train_forward_hash']==b['train_forward_hash'] and a['eval_hash']==b['eval_hash'],'Same-weight model/stop trace mismatch'
                    assert b['checked_frequency_forwards']>0 and b['checked_frequency_vjps']>0
        pairs=[]
        for i in range(13):
            a,b=[read(OUT/'cases'/f'{i:02d}_{k}_benchmark.json') for k in ('serial','parallel')]
            pairs.append(dict(index=i,arm=a['arm'],serial_warm_step_seconds=a['times'][1]['total'],parallel_warm_step_seconds=b['times'][1]['total'],
                              train_speedup=a['times'][1]['total']/b['times'][1]['total'],serial_eval_seconds=a['eval_seconds'],parallel_eval_seconds=b['eval_seconds'],eval_speedup=a['eval_seconds']/b['eval_seconds']))
        files=list((OUT/'cases').glob('*.json'));rows=[read(p) for p in files];assert len(rows)==52
        result=dict(status='PASS',isolated_processes=52,configurations=13,test_read=False,all_settings_unchanged=True,
                    bitwise_FEM_complete_nodal_state_LU_voltage_VJP=True,bitwise_same_weight_model_forward_and_stops=True,full_training_bitwise_identity=False,
                    reason='Untouched CUDA NN backward is non-bitwise-repeatable; exact substitution-boundary checks do not imply long-training weight identity',
                    median_paired_train_speedup=statistics.median(r['train_speedup'] for r in pairs),median_paired_eval_speedup=statistics.median(r['eval_speedup'] for r in pairs),pairs=pairs,
                    peak_QA_private_bytes=max(r['resources']['peak_private_bytes'] for r in rows),minimum_QA_available_commit=min(r['resources']['min_available_commit'] for r in rows),
                    case_hashes={str(p):sha(p) for p in files},source_hashes=code_hashes,inherited_backend_sha256=inherited_sha,original_protocol_sha256=sha(ROOT/'protocol.json'),memory_stress_sha256=sha(stress_path),
                    timing_limitations='One warm-up then one measured update per backend/config; separate processes without formal training contention. Actual production timing still required.')
        assert result['median_paired_train_speedup']>1.05 and result['median_paired_eval_speedup']>1.05
        for path,h in plan['protected_files'].items():assert sha(path)==h,path
        write(OUT/'acceptance.json',result);status(52,'execution_verified');print(json.dumps(result),flush=True)
if __name__=='__main__':main()
