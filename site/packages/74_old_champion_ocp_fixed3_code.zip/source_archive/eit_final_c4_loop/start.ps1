$ErrorActionPreference = 'Stop'
$root = 'E:/Codex/final_c4_loop_v1'
New-Item -ItemType Directory -Force -Path $root | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$p = Start-Process -FilePath 'E:/conda-envs/pytorch-gpu/python.exe' -ArgumentList @('-B','-u','E:/Codex/eit_final_c4_loop/train.py','--K','3') -WorkingDirectory 'E:/Codex/eit_final_c4_loop' -WindowStyle Hidden -RedirectStandardOutput "$root/worker_$stamp.stdout.log" -RedirectStandardError "$root/worker_$stamp.stderr.log" -PassThru
$p | Select-Object Id,StartTime
