"""One complete full-model epoch, baseline/final validation, resumable batches.

No test loader. Source lock is per experiment version, not a prohibition on
future controlled revisions inside the fixed diagram modules.
"""
import argparse
import json
import os
import random
import subprocess
import time
from pathlib import Path
import numpy as np
from scipy import ndimage as ndi
import torch
from torch.utils.data import DataLoader
from model import FinalC4Loop, objective
HERE=Path(__file__).resolve().parent
QA_ROOT=Path('E:/Codex/final_c4_loop_v1')
PARENT=Path('E:/Codex/shape_generalization_v1/phase3/runs/physical_c4_seed20261023/best.pt')
ARCHIVE=Path('E:/Codex/EIT_C4_Champion_20261020.zip')
from common import DATA, NORMALIZER
from evaluate import metadata, aggregate
from comsol_v4.data_v6 import Normalizer, grid_arrays, signature, FINAL_SIGNATURE, file_hash
from comsol_v4.paper_common import configure_runtime
from comsol_feedback.fem import TerminalFEM
from comsol_feedback_loop.data import LoopDataset
from comsol_feedback_loop.io import save_checkpoint, write_json

RUN_K=3
ROOT=Path('E:/Codex/final_c4_loop_v1/runs/K3')

def status(phase,**kw):
    obj=dict(phase=phase,updated_unix=time.time(),K=RUN_K,whole_model_training=True,test_read=False,**kw)
    write_json(ROOT/'status.json',obj);print(json.dumps(obj,ensure_ascii=False),flush=True)

def protocol():
    qa=json.loads((QA_ROOT/'qa/architecture_acceptance.json').read_text())
    assert qa['status']=='PASS' and qa['K']==3
    for p,h in qa['source_hashes'].items():assert file_hash(p)==h,p
    local={str(p):file_hash(p) for p in sorted(HERE.glob('*.py'))}
    deps={str(p):file_hash(p) for p in (
        Path('E:/Codex/eit_reproduction/comsol_feedback_loop/data.py'),
        Path('E:/Codex/eit_reproduction/comsol_feedback_loop/io.py'),
        Path('E:/Codex/eit_reproduction/comsol_v4/data_v6.py'),
        Path('E:/Codex/eit_reproduction/comsol_v4/features.py'),
        Path('E:/Codex/eit_shape_general/evaluate.py'),
        Path('E:/Codex/eit_shape_general/common.py'))}
    p=dict(version='fixed-diagram-configurable-k-short-v1',seed=20261023,K=RUN_K,max_epochs=1,
        dataset_signature=signature(DATA),splits=dict(train=3400,val=720,test=720),
        batch_size=2,lr_initial=1e-5,lr_feedback=1e-4,weight_decay=1e-4,
        first_stage_frozen=False,physics_loss_weight=.1,epoch_cap_not_convergence=True,
        loss='final generic loss + .2 mean(all pre-final generic states) + .1 mean(post-update voltage losses)',
        selection='minimum full validation generic BCE+Dice+0.1 material; epoch0 included',
        checkpoint_every_batches=100,session_budget_seconds=6*3600,
        parent=str(PARENT),parent_sha256=file_hash(PARENT),archive_sha256=file_hash(ARCHIVE),
        normalizer_sha256=file_hash(NORMALIZER),projection_sha256=file_hash(Path('E:/Codex/shape_generalization_v1/phase2/physical_projection.npz')),
        qa_sha256=file_hash(QA_ROOT/'qa/architecture_acceptance.json'),source_hashes={**qa['source_hashes'],**deps,**local},
        module_contract='fixed_projection+measurement_encoder+generic_UNet+full_fields+C4+fresh_FEM+complex_residual+adjoint_hint+shared_feedback_K',
        K_policy='Configurable positive integer; default 3 is a feasibility setting, not an optimum. No K sweep.',
        no_extra_modules=True,no_test=True,allowed_revision='new version only; fixed module graph',
        continuation_gate=dict(all_iou_drop_max=.002,A_iou_drop_max=.002,neighbor_fp_increase_max=.005,
                               E_local_iou_gain_min=.01,E_recall_gain_min=.02),
        stop_policy='No automatic second epoch, no parameter sweep. Review real images and gains first.',
        limitations=['single seed, warm start from validation-selected C4-augmentation parent',
                    'new C4 pool full-field adapter is not the complete Champion network',
                    'historical test observed; current test unopened',
                    'within-model stages are not independently trained causal ablations',
                    'independent FEM has approximation error; free probability/material fields may differ'])
    assert p['dataset_signature']==FINAL_SIGNATURE
    path=ROOT/'protocol.json'
    if path.exists():assert json.loads(path.read_text())==p,'Version changed: do not mix training sources'
    else:write_json(path,p)
    return p,file_hash(path)

def check_sources(p):
    for path,h in p['source_hashes'].items():assert file_hash(path)==h,path

def move(raw):return {k:v.cuda() if torch.is_tensor(v) else v for k,v in raw.items()}
def inputs(b):return [b[k] for k in ('features','observed','background','reference')]

def metric(prob,truth,info,added,neighbor):
    pred=prob>=.5;inter=int((pred&truth).sum());union=int((pred|truth).sum())
    r={**info,'iou':inter/max(union,1),'dice':2*inter/max(int(pred.sum()+truth.sum()),1)}
    bt=truth&~ndi.binary_erosion(truth);bp=pred&~ndi.binary_erosion(pred)
    dt=ndi.distance_transform_edt(~bt);dp=ndi.distance_transform_edt(~bp)
    prec=float((dt[bp]<=1).mean()) if bp.any() else 0
    rec=float((dp[bt]<=1).mean()) if bt.any() else 0
    r['boundary_f1']=2*prec*rec/max(prec+rec,1e-12)
    r['boundary_distance_pixels']=float((dt[bp].mean()+dp[bt].mean())/2) if bp.any() and bt.any() else 64.
    if added.any():
        hit=int((pred&added).sum());fp=int((pred&neighbor).sum())
        recall=hit/int(added.sum());false=fp/max(int(neighbor.sum()),1)
        r.update(bump_recall=recall,neighbor_false_addition=false,local_iou=hit/max(int(added.sum())+fp,1),
                 detected=recall>=.75 and false<=.1)
    return r

@torch.no_grad()
def validate(model,ds,meta,p,tag):
    dest=ROOT/tag;dest.mkdir(exist_ok=True)
    names=['initial_c4']+[f'round{k}' for k in range(1,p['K']+1)]
    rows={k:[] for k in names};preds={k:[] for k in names};truths=[];case_ids=[]
    sums=np.zeros(3);count=0;tick=time.monotonic();last=tick
    model.eval()
    for raw in DataLoader(ds,batch_size=p['batch_size'],shuffle=False):
        b=move(raw);out=model(*inputs(b));loss,score,physical=objective(out,b,model.fov)
        n=len(b['features']);sums+=np.array([float(loss),float(score),float(physical)])*n
        targets=raw['mask'][:,0].numpy()>.5
        for j,(name,state) in enumerate(zip(names,[out['initial']]+out['stages'])):
            ps=state['probability'][:,0].cpu().numpy()
            volts=out['voltage_mse_by_round'][:,j].cpu().numpy()
            truthmat=torch.cat((b['sigma'],b['eps_r']),1).clamp_min(1e-8).log()
            err=(((state['log_material']-truthmat).abs()*model.fov).sum((2,3))/model.fov.sum()).cpu().numpy()
            for i,(prob,t) in enumerate(zip(ps,targets)):
                info,added,neighbor=meta[count+i]
                rec=metric(prob,t,info,added,neighbor)
                rec.update(voltage_mse_10=float(volts[i,0]),voltage_mse_50=float(volts[i,1]),
                           log_sigma_mae=float(err[i,:2].mean()),log_eps_mae=float(err[i,2:].mean()))
                rows[name].append(rec);preds[name].append(prob)
        truths.extend(targets);case_ids.extend(raw['case_id']);count+=n
        now=time.monotonic()
        if now-last>30 or count==len(ds):
            status('validation',tag=tag,processed=count,total=len(ds),seconds_per_case=(now-tick)/count,
                   phase_remaining_seconds=(now-tick)/count*(len(ds)-count))
            last=now
        del b,out,loss,score,physical
    assert count==720
    summary=dict(score=float(sums[1]/count),loss=float(sums[0]/count),physics_loss=float(sums[2]/count),
                 count=count,groups={name:aggregate(recs) for name,recs in rows.items()},seconds=time.monotonic()-tick)
    np.savez_compressed(dest/'predictions.npz',**{k:np.stack(v) for k,v in preds.items()},
                        truth=np.stack(truths),case_ids=np.array(case_ids))
    write_json(dest/'metrics.json',dict(summary=summary,records=rows))
    return summary

def compare():
    before=json.loads((ROOT/'epoch0/metrics.json').read_text())
    after=json.loads((ROOT/'epoch1/metrics.json').read_text())
    final_name=f'round{RUN_K}'
    a=before['records'][final_name];b=after['records'][final_name];assert [r['case_id'] for r in a]==[r['case_id'] for r in b]
    comparisons={};rng=np.random.default_rng(20261023)
    for group in ('all','A','BCDE','E','E_small','E_medium','E_large'):
        def keep(r):
            if group=='all':return True
            if group=='BCDE':return r['shape_class']!='A'
            if group.startswith('E_'):return r['shape_class']=='E' and r.get('bump_size_class')==group[2:]
            return r['shape_class']==group
        ids=[i for i,r in enumerate(a) if keep(r)];positions=sorted({a[i]['position_id'] for i in ids});out={}
        for key in ('iou','dice','boundary_f1','local_iou','bump_recall','neighbor_false_addition','voltage_mse_10','voltage_mse_50','log_sigma_mae','log_eps_mae'):
            ix=[i for i in ids if key in a[i]]
            if not ix:continue
            deltas=np.array([float(b[i][key])-float(a[i][key]) for i in ix]);pool={pos:np.array([j for j,i in enumerate(ix) if a[i]['position_id']==pos]) for pos in positions}
            samples=[]
            for _ in range(1000):
                chosen=rng.choice(positions,len(positions));jj=np.concatenate([pool[pos] for pos in chosen])
                samples.append(float(deltas[jj].mean()))
            out[key]=dict(before=float(np.mean([a[i][key] for i in ix])),after=float(np.mean([b[i][key] for i in ix])),
                          difference=float(deltas.mean()),position_group_ci95=np.quantile(samples,[.025,.975]).tolist())
        comparisons[group]=out
    allg=comparisons['all'];eg=comparisons['E'];ag=comparisons['A']
    gate=bool(allg['iou']['difference']>=-.002 and ag['iou']['difference']>=-.002 and
              eg['neighbor_false_addition']['difference']<=.005 and eg['local_iou']['difference']>=.01 and eg['bump_recall']['difference']>=.02)
    return dict(comparison='epoch1 complete model minus epoch0 complete model; same seed',groups=comparisons,
                continuation_gate_passed=gate,visual_review_required=True,
                caveat='Exploratory validation-selected, single seed, 18 position groups; not causal C4/K3 ablation',test_read=False)

def run():
    p,ph=protocol();configure_runtime(p['seed'])
    write_json(ROOT/'worker_identity.json',dict(pid=os.getpid(),started_unix=time.time(),protocol_sha256=ph))
    if (ROOT/'complete.json').exists():print('Already complete; no retraining',flush=True);return
    x,y,fov=grid_arrays(DATA);solver=TerminalFEM(x,y,fov,spacing=.0016)
    norm=Normalizer.load(NORMALIZER,DATA)
    data={}
    for split,n in [('train',3400),('val',720)]:
        status('loading_data',split=split,total=n)
        data[split]=LoopDataset(DATA,split,norm,solver);assert len(data[split])==n
    meta=metadata(data['val'].rows,'val')
    parent=torch.load(PARENT,map_location='cpu',weights_only=True)
    model=FinalC4Loop(solver,parent['model'],K=RUN_K).cuda();del parent
    opt=torch.optim.AdamW([dict(params=model.initial.parameters(),lr=p['lr_initial']),
                           dict(params=model.feedback.parameters(),lr=p['lr_feedback'])],weight_decay=p['weight_decay'])
    completed=0;start_batch=0;sums=np.zeros(3);count=0;best_epoch=0;best=float('inf')
    def ck(epoch,next_batch=0):
        return dict(protocol_sha256=ph,epoch=epoch,next_batch=next_batch,model=model.state_dict(),optimizer=opt.state_dict(),
                    train_sums=sums.tolist(),train_count=count,best_epoch=best_epoch,best_score=best,
                    rng_cpu=torch.get_rng_state(),rng_cuda=torch.cuda.get_rng_state_all())
    if (ROOT/'last.pt').exists():
        c=torch.load(ROOT/'last.pt',map_location='cpu',weights_only=True);assert c['protocol_sha256']==ph
        model.load_state_dict(c['model']);opt.load_state_dict(c['optimizer'])
        completed=c['epoch'];start_batch=c['next_batch'];sums=np.array(c['train_sums']);count=c['train_count']
        best_epoch=c['best_epoch'];best=c['best_score']
        torch.set_rng_state(c['rng_cpu']);torch.cuda.set_rng_state_all(c['rng_cuda']);del c
    else:
        initial=validate(model,data['val'],meta,p,'epoch0');best=initial['score']
        save_checkpoint(ROOT/'best.pt',ck(0));save_checkpoint(ROOT/'last.pt',ck(0))
    if completed<1:
        status('training',epoch=1,processed=count,total=3400)
        generator=torch.Generator().manual_seed(p['seed']+1000003)
        loader=DataLoader(data['train'],batch_size=p['batch_size'],shuffle=True,generator=generator,num_workers=0)
        tick=time.monotonic();last=tick;session_count=count;model.train()
        for index,raw in enumerate(loader):
            if index<start_batch:continue
            b=move(raw);out=model(*inputs(b));loss,score,physical=objective(out,b,model.fov)
            if not torch.isfinite(loss):raise FloatingPointError('Nonfinite full-model objective')
            opt.zero_grad(set_to_none=True);loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True);opt.step()
            n=len(b['features']);sums+=np.array([float(loss.detach()),float(score.detach()),float(physical.detach())])*n;count+=n
            now=time.monotonic()
            if now-last>30 or count==len(data['train']):
                spc=(now-tick)/max(count-session_count,1)
                status('training',epoch=1,processed=count,total=3400,loss=float(sums[0]/count),
                       seconds_per_case=spc,phase_remaining_seconds=spc*(3400-count),
                       note='ETA is training phase only; full validation follows')
                last=now
            if (index+1)%p['checkpoint_every_batches']==0:
                check_sources(p);save_checkpoint(ROOT/'last.pt',ck(0,index+1))
            if now-tick>p['session_budget_seconds']:
                save_checkpoint(ROOT/'last.pt',ck(0,index+1));status('budget_stopped',processed=count,total=3400)
                return
            del b,out,loss,score,physical
        assert count==3400
        save_checkpoint(ROOT/'last.pt',ck(1))
    check_sources(p)
    final=validate(model,data['val'],meta,p,'epoch1')
    if final['score']<best:best=final['score'];best_epoch=1;save_checkpoint(ROOT/'best.pt',ck(1))
    save_checkpoint(ROOT/'last.pt',ck(1))
    write_json(ROOT/'training_complete.json',dict(protocol_sha256=ph,epochs=1,selected_epoch=best_epoch,best_score=best,
        checkpoint_sha256=file_hash(ROOT/'best.pt'),stop_reason='one_epoch_short_validation_not_convergence',
        train_cases=3400,val_cases=720,K=RUN_K,joint_training=True,test_read=False))
    write_json(ROOT/'summary_statistics.json',compare())
    subprocess.run(['E:/Anaconda/python.exe','-s','-B',str(HERE/'report.py'),'--root',str(ROOT)],check=True,
                   creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
    check_sources(p)
    write_json(ROOT/'complete.json',dict(status='computed_pending_visual_review',protocol_sha256=ph,
        best_checkpoint_sha256=file_hash(ROOT/'best.pt'),completed_unix=time.time(),test_read=False))
    status('computed_pending_visual_review',selected_epoch=best_epoch)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--prepare-only',action='store_true')
    ap.add_argument('--K',type=int,default=3);args=ap.parse_args()
    if args.K<1:ap.error('K must be a positive integer')
    RUN_K=args.K;ROOT=Path('E:/Codex/final_c4_loop_v1/runs')/f'K{RUN_K}'
    ROOT.mkdir(exist_ok=True,parents=True)
    import msvcrt
    with (ROOT/'worker.lock').open('a+b') as lock:
        if lock.tell()==0:lock.write(b'0');lock.flush()
        lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        try:
            if args.prepare_only:print(json.dumps(protocol()[0],ensure_ascii=False,indent=2))
            else:run()
        except Exception as e:
            status('failed',error=repr(e));raise
