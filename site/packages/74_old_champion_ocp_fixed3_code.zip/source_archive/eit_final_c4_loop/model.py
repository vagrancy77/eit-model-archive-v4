"""Diagram-preserving full-field C4 + mandatory configurable nonlinear FEM loop.

C4 input rotation/alignment are copied verbatim from the supplied archive.
Only the field readout adapter differs: the diagram has no regional logits/tau.
No Champion attention front, geometry query, or regional readout is imported.
"""
from pathlib import Path
import sys
import torch
from torch import nn
from torch.nn import functional as F

RESEARCH = Path('E:/Codex/eit_shape_general')
sys.path.insert(0, str(RESEARCH))
from physical_model import PhysicalReconstruction
from models import Block, objective as field_objective
from comsol_feedback_loop.model import DynamicPhysics


class ArchiveC4Operations:
    # Exact method bodies from RotationPoolCandidate; source parity tested in QA.
    def rotate_input(self,voltage,dv,k):
        if k%4==0:return voltage,dv
        shift=-8*(k%4)
        raw=voltage*self.input_std+self.input_mean
        v=(torch.roll(raw,(shift,shift),(-2,-1))-self.input_mean)/self.input_std
        d=torch.roll(dv.reshape(-1,2,2,32,32),(shift,shift),(-2,-1)).reshape_as(dv)
        return v,d

    @staticmethod
    def align_mean(value,batch,spatial=False):
        parts=value.split(batch,dim=0)
        assert len(parts)==4
        if spatial:parts=[torch.rot90(x,-k,(-2,-1)) for k,x in enumerate(parts)]
        return torch.stack(parts).mean(0)


class C4FullField(nn.Module, ArchiveC4Operations):
    def __init__(self, member):
        super().__init__()
        self.member=member
        self.register_buffer('input_mean',member.mean.clone())
        self.register_buffer('input_std',member.std.clone())
        self.register_buffer('fov',member.fov.clone())
        assert torch.equal(self.fov,torch.rot90(self.fov,1,(-2,-1)))

    def forward(self, features):
        # dv is unused by this fixed-projection backbone. Keep the archived
        # transformation signature for source parity, never introduce label input.
        dummy=features.new_zeros((len(features),2,2048))
        rotated=[self.rotate_input(features,dummy,k)[0] for k in range(4)]
        out=self.member(torch.cat(rotated))
        logits=self.align_mean(out['logits'],len(features),True)
        material=self.align_mean(out['log_material'],len(features),True)
        return state_from_fields(logits,material,self.fov)


def state_from_fields(logits,material,fov):
    return dict(logits=logits,probability=logits.sigmoid()*fov,
                log_material=material,sigma=material[:,:2].exp(),eps_r=material[:,2:].exp())


class FieldFeedback(nn.Module):
    """Single shared U-Net. Free-field update; no class/ROI/shape routing."""
    def __init__(self,fov,base=24):
        super().__init__()
        self.register_buffer('fov',torch.as_tensor(fov,dtype=torch.float32)[None,None])
        self.lift=nn.Sequential(nn.Flatten(),nn.Linear(16*32*32,256),
            nn.Unflatten(1,(1,16,16)),nn.Upsample(size=(64,64),mode='bilinear',align_corners=False),
            nn.Conv2d(1,4,3,padding=1),nn.SiLU())
        self.e0=Block(13,base);self.e1=Block(base,base*2);self.e2=Block(base*2,base*4)
        self.e3=Block(base*4,base*8)
        self.d2=Block(base*12,base*4);self.d1=Block(base*6,base*2);self.d0=Block(base*3,base)
        self.head=nn.Conv2d(base,5,1)
        nn.init.zeros_(self.head.weight);nn.init.zeros_(self.head.bias)
        self.register_buffer('center',torch.tensor([.1,.1,10000.,10000.]).log()[None,:,None,None])

    def forward(self,state,features,residual,hint):
        lift=self.lift(torch.cat((features,(residual/.05).clamp(-10,10)),1))*self.fov
        x=torch.cat((state['probability'],(state['log_material']-self.center)*self.fov,hint,lift),1)
        a=self.e0(x);b=self.e1(F.avg_pool2d(a,2));c=self.e2(F.avg_pool2d(b,2));e=self.e3(F.avg_pool2d(c,2))
        up=lambda x,y:F.interpolate(x,size=y.shape[-2:],mode='bilinear',align_corners=False)
        z=self.d2(torch.cat((up(e,c),c),1));z=self.d1(torch.cat((up(z,b),b),1))
        raw=self.head(self.d0(torch.cat((up(z,a),a),1)))
        logits=state['logits']+8*raw[:,:1].tanh()*self.fov
        material=state['log_material']+.5*raw[:,1:].tanh()*self.fov
        return state_from_fields(logits,material,self.fov)


class FinalC4Loop(nn.Module):
    def __init__(self,solver,parent_state=None,K=3):
        super().__init__()
        if isinstance(K,bool) or not isinstance(K,int) or K < 1:
            raise ValueError('K must be a positive integer; feedback cannot be disabled')
        self.K=K
        member=PhysicalReconstruction(dict(kind='physical'),solver.fov)
        if parent_state is not None:member.load_state_dict(parent_state,strict=True)
        self.initial=C4FullField(member)
        self.feedback=FieldFeedback(solver.fov)
        self.physics=DynamicPhysics(solver)
        self.register_buffer('fov',member.fov.clone())

    def forward(self,features,observed,background,reference):
        initial=self.initial(features);state=initial;stages=[];residuals=[]
        for _ in range(self.K):
            physical=self.physics(state,observed,background,reference)
            residuals.append(physical['voltage_mse'])
            state=self.feedback(state,features,physical['residual'],physical['hint'])
            stages.append(state)
        final=self.physics(state,observed,background,reference,hints=False)
        residuals.append(final['voltage_mse'])
        return {**state,'initial':initial,'stages':stages,
                'voltage_mse_by_round':torch.stack(residuals,1),'predicted_voltage':final['voltage']}


def objective(out,target,fov):
    label=dict(mask=target['mask'],log_material=torch.cat((target['sigma'],target['eps_r']),1).clamp_min(1e-8).log())
    losses=[field_objective(s,label,fov,False)[0] for s in out['stages']]
    initial=field_objective(out['initial'],label,fov,False)[0]
    physics=out['voltage_mse_by_round'][:,1:].mean()
    # Same generic reconstruction terms; no extra boundary, E-class or ROI loss.
    # Fixed total auxiliary weight for every K, including K=1. Average all
    # pre-final states (initial + intermediate), not a K-dependent loss sum.
    auxiliary=torch.stack([initial]+losses[:-1]).mean()
    total=losses[-1]+.2*auxiliary+.1*physics
    return total,losses[-1],physics
