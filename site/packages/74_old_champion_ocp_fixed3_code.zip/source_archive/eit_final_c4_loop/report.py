"""Read completed validation artifacts, draw real predictions, never run model."""
import json
import argparse
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path('E:/Codex/final_c4_loop_v1')

def main():
    K=json.loads((ROOT/'protocol.json').read_text())['K'];last=f'round{K}'
    a=np.load(ROOT/'epoch0/predictions.npz');b=np.load(ROOT/'epoch1/predictions.npz')
    metrics=json.loads((ROOT/'epoch1/metrics.json').read_text())['records'][last]
    old=json.loads((ROOT/'epoch0/metrics.json').read_text())['records'][last]
    assert np.array_equal(a['case_ids'],b['case_ids'])
    ids=[]
    for cls in 'ABCDE':ids.append(next(i for i,r in enumerate(metrics) if r['shape_class']==cls))
    for size in ('small','medium','large'):
        ids.append(next(i for i,r in enumerate(metrics) if r['shape_class']=='E' and r.get('bump_size_class')==size))
    def draw(indices,name):
        titles=['Truth',f'Before training K{K}','After training initial']+[f'Round {k}' for k in range(1,K+1)]
        fig,axes=plt.subplots(len(indices),len(titles),figsize=(2.5*len(titles),2.25*len(indices)),squeeze=False)
        for j,i in enumerate(indices):
            images=[b['truth'][i],a[last][i],b['initial_c4'][i]]+[b[f'round{k}'][i] for k in range(1,K+1)]
            for k,img in enumerate(images):
                ax=axes[j,k];ax.imshow(img,origin='lower',vmin=0,vmax=1,cmap='viridis')
                ax.contour(b['truth'][i],levels=[.5],colors='red',linewidths=.7)
                if k:ax.contour(img,levels=[.5],colors='white',linewidths=.7)
                ax.set_xticks([]);ax.set_yticks([])
                if j==0:ax.set_title(titles[k])
                if k==0:ax.set_ylabel(str(b['case_ids'][i]))
        fig.suptitle('Real validation cases | red = truth; white = prediction 0.5 | single seed / one epoch')
        fig.tight_layout();fig.savefig(ROOT/name,dpi=140);plt.close(fig)
    draw(ids,'fixed_cases.png')
    delta=np.array([r['iou']-s['iou'] for r,s in zip(metrics,old)])
    draw(np.argsort(delta)[:6],'worst_changes.png');draw(np.argsort(delta)[-6:][::-1],'best_changes.png')
    summary=json.loads((ROOT/'summary_statistics.json').read_text());done=json.loads((ROOT/'training_complete.json').read_text())
    lines=[f'# 完整 C4 + K={K}：一轮全量短训验证','',
           '模块固定，初始主干和共享反馈网络联合训练。最终4840例位置组划分未改：3400训练、720验证、720测试（本轮未读取）。',
           f"验证选中 epoch {done['selected_epoch']}；epoch0 纳入选择。单种子一轮不代表收敛，也不保证最终最优。",'',
           '|组|IoU 训练前|IoU 训练后|差值|位置组95%区间|','|---|---:|---:|---:|---|']
    for group,values in summary['groups'].items():
        x=values['iou'];lines.append(f"|{group}|{x['before']:.5f}|{x['after']:.5f}|{x['difference']:+.5f}|{x['position_group_ci95']}|")
    lines+=['','## E 局部结构（只用于验证，不输入网络）','']
    for key in ('local_iou','bump_recall','neighbor_false_addition'):
        x=summary['groups']['E'][key];lines.append(f"- {key}: {x['before']:.5f} → {x['after']:.5f}; Δ {x['difference']:+.5f}; CI {x['position_group_ci95']}")
    lines+=['',f"继续研究的数值门槛：{summary['continuation_gate_passed']}。仍需人工查看固定/最好/最差真实图，不自动追加训练。",'',
            'C4 旋转和对齐方法取自用户包；全场融合接口已适配，非整个Champion模型。各轮输出不是独立训练消融。旧测试曾观察，本轮未读test。自由材料场与几何概率不强制同一边界；独立FEM仍有失配。']
    (ROOT/'RESULTS.md').write_text('\n'.join(lines),encoding='utf-8')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);a=ap.parse_args();ROOT=a.root;main()
