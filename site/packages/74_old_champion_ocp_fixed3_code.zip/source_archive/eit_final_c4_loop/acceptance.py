"""Train-only QA; never starts an experiment or saves QA weights for reuse."""
import ast
import hashlib
import json
import sys
import time
import zipfile
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import default_collate

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from model import FinalC4Loop, ArchiveC4Operations, objective
from common import DATA, NORMALIZER
from comsol_v4.data_v6 import grid_arrays, Normalizer, file_hash, signature, FINAL_SIGNATURE
from comsol_feedback.fem import TerminalFEM
from comsol_feedback.verify import run as physics_acceptance
from comsol_feedback_loop.data import LoopDataset
from comsol_feedback_loop.io import write_json
from comsol_v4.paper_common import configure_runtime,tensor_hash

ROOT=Path('E:/Codex/final_c4_loop_v1')
PARENT=Path('E:/Codex/shape_generalization_v1/phase3/runs/physical_c4_seed20261023/best.pt')
ARCHIVE=Path('E:/Codex/EIT_C4_Champion_20261020.zip')

def main():
    ROOT.mkdir(exist_ok=True)
    qa=ROOT/'qa';qa.mkdir(exist_ok=True)
    import msvcrt
    with (ROOT/'worker.lock').open('a+b') as lock:
        if lock.tell()==0:lock.write(b'0');lock.flush()
        lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        configure_runtime(20261023)
        assert signature(DATA)==FINAL_SIGNATURE
        name='EIT_C4_Champion_20261020/original_sources/EIT_C4Synthesis_4840/rotation_pool_candidate.py'
        with zipfile.ZipFile(ARCHIVE) as z:original=z.read(name)
        tree=ast.parse(original.decode());local=ast.parse((HERE/'model.py').read_text(encoding='utf-8'))
        cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='RotationPoolCandidate')
        ours=next(n for n in local.body if isinstance(n,ast.ClassDef) and n.name=='ArchiveC4Operations')
        for method in ('rotate_input','align_mean'):
            a=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name==method)
            b=next(n for n in ours.body if isinstance(n,ast.FunctionDef) and n.name==method)
            assert ast.dump(a)==ast.dump(b),method
        done=json.loads(PARENT.with_name('complete.json').read_text())
        assert file_hash(PARENT)==done['checkpoint_sha256']
        x,y,fov=grid_arrays(DATA);solver=TerminalFEM(x,y,fov,spacing=.0016)
        norm=Normalizer.load(NORMALIZER,DATA);norm.validate_training_contract(DATA,'calibrated')
        ds=LoopDataset(DATA,'train',norm,solver,limit=1)
        b={k:v.cuda() if torch.is_tensor(v) else v for k,v in default_collate([ds[0]]).items()}
        ck=torch.load(PARENT,map_location='cpu',weights_only=True)
        model=FinalC4Loop(solver,ck['model']).cuda();del ck
        model.eval()
        features=b['features'];dummy=features.new_zeros((len(features),2,2048))
        with torch.no_grad():
            unwrapped=model.initial.member(features)
            initial=model.initial(features)
            errors=[]
            for k in (1,2,3):
                rolled,_=model.initial.rotate_input(features,dummy,k)
                out=model.initial(rolled)
                errors.append(max(float((out[key]-torch.rot90(initial[key],k,(-2,-1))).abs().max())
                                  for key in ('logits','log_material')))
            assert max(errors)<2e-3,errors
        print('C4 archive AST parity and equivariance PASS',errors,flush=True)
        args=[b[k] for k in ('features','observed','background','reference')]
        # Use nonzero QA-only head to exercise updates at every round.
        with torch.no_grad():model.feedback.head.bias.copy_(torch.tensor([.01,.002,-.002,.003,-.003],device='cuda'))
        calls=[];hook=model.feedback.register_forward_hook(lambda m,a,o:calls.append(o))
        start=time.monotonic();model.train();out=model(*args)
        assert len(calls)==3 and model.physics.evaluations==4
        assert all(s['sigma'].gt(0).all() and s['eps_r'].gt(0).all() for s in out['stages'])
        assert all(not torch.equal(a['log_material'],c['log_material']) for a,c in zip([out['initial']]+out['stages'][:-1],out['stages']))
        for state in [out['initial']]+out['stages']:state['log_material'].retain_grad()
        loss,score,physical=objective(out,b,model.fov)
        assert torch.isfinite(loss)
        loss.backward()
        grad_initial=sum(float(p.grad.abs().sum()) for p in model.initial.parameters() if p.grad is not None)
        grad_feedback=sum(float(p.grad.abs().sum()) for p in model.feedback.parameters() if p.grad is not None)
        assert grad_initial>0 and grad_feedback>0
        assert all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)
        assert all(s['log_material'].grad is not None and s['log_material'].grad.abs().sum()>0 for s in [out['initial']]+out['stages'])
        elapsed=time.monotonic()-start
        # Direct physics-only gradient to initial stage through all three updates.
        model.zero_grad(set_to_none=True);direct=model(*args)
        direct['voltage_mse_by_round'][:,-1].mean().backward()
        physical_initial=sum(float(p.grad.abs().sum()) for p in model.initial.parameters() if p.grad is not None)
        assert physical_initial>0
        hook.remove()
        del out,direct,model;torch.cuda.empty_cache()
        print('Full K3 joint forward/backward PASS',elapsed,flush=True)
        k_checks=[];state_hashes=[]
        for k in (1,2,3,4):
            configure_runtime(20261023)
            parent=torch.load(PARENT,map_location='cpu',weights_only=True)
            candidate=FinalC4Loop(solver,parent['model'],K=k).cuda();del parent
            state_hashes.append(tensor_hash(candidate.state_dict()))
            t=time.monotonic();candidate.train();res=candidate(*args)
            loss,score,physical=objective(res,b,candidate.fov);loss.backward()
            assert torch.isfinite(loss) and candidate.physics.evaluations==k+1
            assert len(res['stages'])==k
            assert any(p.grad is not None and p.grad.abs().sum()>0 for p in candidate.feedback.parameters())
            assert any(p.grad is not None and p.grad.abs().sum()>0 for p in candidate.initial.parameters())
            k_checks.append(dict(K=k,dual_frequency_solves=k+1,loss=float(loss.detach()),
                                 seconds=time.monotonic()-t,initial_state_sha256=state_hashes[-1]))
            del res,candidate,loss,score,physical;torch.cuda.empty_cache()
        assert len(set(state_hashes))==1,'K must not alter parameter/buffer initialization'
        print('All K independent forward/backward PASS',k_checks,flush=True)
        fem=physics_acceptance(qa/'fem',spacing=.0016)
        deps=[HERE/'model.py',HERE/'acceptance.py',Path('E:/Codex/eit_shape_general/physical_model.py'),
              Path('E:/Codex/eit_shape_general/models.py'),Path('E:/Codex/eit_reproduction/comsol_feedback_loop/model.py'),
              Path('E:/Codex/eit_reproduction/comsol_feedback/fem.py')]
        report=dict(status='PASS',K=3,shared_feedback_calls=3,fresh_dual_frequency_solves_per_forward=4,
            archive_method_ast_parity=True,c4_equivariance_max_errors=errors,
            initial_gradient_l1=grad_initial,feedback_gradient_l1=grad_feedback,
            final_physics_to_initial_gradient_l1=physical_initial,seconds_per_training_case_QA=elapsed,
            input_signature='features, observed, background, homogeneous FEM reference; no labels/class/ROI',
            archive_c4_source_sha256=hashlib.sha256(original).hexdigest(),parent_sha256=file_hash(PARENT),
            source_hashes={str(p):file_hash(p) for p in deps},dataset_signature=signature(DATA),
            physics_status=fem['status'],k_checks=k_checks,identical_initial_tensors_for_all_K=True,
            test_read=False,formal_training_started=False,
            limitation='C4 operations exact; full-field readout adapted, NOT full Champion model parity. QA weights discarded.')
        write_json(qa/'architecture_acceptance.json',report)
        print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)

if __name__=='__main__':main()
