"""Preserve the complete original V4/refiner and the entire Champion in parallel."""
import sys
import torch
from torch import nn
sys.path.insert(0,'E:/Codex')
from eit_champion_loop_v2.model import vendor_model,DEFAULT_WEIGHTS,model_inputs
from eit_champion_adaptive_v3.policy import StopPolicy,StopTracker
from eit_final_c4_loop.model import PhysicalReconstruction,C4FullField
from comsol_feedback_loop.model import ClosedLoopEIT
from comsol_v4.model import V4Comsol
from eit_old_champion_selection_v1.config import OLD,OLD_SHA,PARENT
from comsol_v4.data_v6 import file_hash
from models import objective as generic_objective

def canonical(state):
    p=state['fg']
    material=torch.cat((state['sigma'],state['eps_r']),1).clamp_min(1e-8)
    return dict(probability=p,logits=torch.logit(p.clamp(1e-7,1-1e-7)),log_material=material.log(),sigma=state['sigma'],eps_r=state['eps_r'])

class Combined(nn.Module):
    def __init__(self,solver,arm):
        super().__init__();self.arm=dict(arm)
        assert file_hash(OLD)==OLD_SHA
        self.old=ClosedLoopEIT(V4Comsol(solver.fov,base=28,propagation_steps=14),solver,rounds=3,base=24)
        ck=torch.load(OLD,map_location='cpu',weights_only=True)
        self.old.load_state_dict(ck['model'],strict=True)
        self.champion,_=vendor_model.load_model(DEFAULT_WEIGHTS,'cpu')
        self.register_buffer('fov',self.champion.fov.clone())
        assert torch.equal(self.fov.cpu(),torch.as_tensor(solver.fov,dtype=self.fov.dtype)[None,None])
        self.projection=None
        if arm.get('projection'):
            member=PhysicalReconstruction(dict(kind='physical'),solver.fov)
            member.load_state_dict(torch.load(PARENT,map_location='cpu',weights_only=True)['model'],strict=True)
            self.projection=C4FullField(member)
        self.mix_logits=nn.Parameter(torch.zeros(3 if self.projection is not None else 2))
        self.policy=StopPolicy()

    def champion_state(self,voltage,dv,groups):
        out=self.champion(voltage,dv,groups)
        bg=self.champion.background[groups,:,None,None]
        material=bg+out['fields']*out['fields'].new_tensor([.2,.2,50000.,50000.])[None,:,None,None]
        if not torch.isfinite(material).all() or not (material>0).all():raise FloatingPointError('Invalid Champion field')
        return dict(probability=out['foreground'],logits=out['geometry_logit'],log_material=material.log(),sigma=material[:,:2],eps_r=material[:,2:])

    def blend(self,states):
        weights=self.mix_logits.softmax(0)
        p=sum(w*s['probability'] for w,s in zip(weights,states))
        sigma=sum(w*s['sigma'] for w,s in zip(weights,states))
        eps=sum(w*s['eps_r'] for w,s in zip(weights,states))
        return dict(probability=p,logits=torch.logit(p.clamp(1e-7,1-1e-7)),sigma=sigma,eps_r=eps,log_material=torch.cat((sigma,eps),1).clamp_min(1e-8).log())

    def forward(self,features,observed,background,reference,voltage,dv,groups):
        initial,_=self.old.initial_state(features)
        champ=self.champion_state(voltage,dv,groups)
        proj=self.projection(features) if self.projection is not None else None
        finals=[];volts=[];traces=[];trajectories=[];branch_states=[]
        for i in range(len(features)):
            one=lambda s:{k:v[i:i+1] for k,v in s.items()}
            state=one(initial);states=[state];args=[v[i:i+1] for v in (observed,background,reference)]
            physical=self.old.physics(state,*args);physicals=[physical]
            tracker=StopTracker(self.policy,float(physical['voltage_mse'].detach().mean()))
            history=[];maximum=3 if self.arm['loop']=='fixed3' else self.policy.max_steps
            for step in range(1,maximum+1):
                residual=physical['residual'];hint=physical['hint']
                if self.arm.get('ablate')=='residual':residual=torch.zeros_like(residual)
                if self.arm.get('ablate')=='hint':hint=torch.zeros_like(hint)
                candidate=self.old.refiner({**state,'features':features[i:i+1],'residual':residual,'hint':hint})
                new=self.old.physics(candidate,*args)
                with torch.no_grad():
                    dp=float(((candidate['fg']-state['fg']).abs()*self.fov).max())
                    dm=float(((canonical(candidate)['log_material']-canonical(state)['log_material']).abs()*self.fov).max())
                    if self.arm['loop']=='fixed3':
                        decision=dict(stop=step==3,reason='fixed3' if step==3 else None,selected_step=step,step=step)
                    else:decision=tracker.update(step,float(new['voltage_mse'].mean()),dp,dm)
                states.append(candidate);physicals.append(new);history.append(decision)
                state=candidate;physical=new
                if decision['stop']:break
            chosen=decision['selected_step'];old_states=[canonical(s) for s in states]
            branches=[old_states[chosen],one(champ)]
            if proj is not None:branches.append(one(proj))
            fused=self.blend(branches)
            fused_physics=self.old.physics(fused,*args,hints=False)
            finals.append(fused);volts.append(fused_physics['voltage']);branch_states.append(branches)
            trajectories.append(dict(old_states=old_states,branches=branches,errors=[p['voltage_mse'] for p in physicals],final_error=fused_physics['voltage_mse']))
            traces.append(dict(executed_steps=step,selected_step=chosen,reason=decision['reason'],stop_scope='old_branch_only',dual_frequency_solves=step+2,history=history))
        return {**{k:torch.cat([s[k] for s in finals]) for k in finals[0]},'predicted_voltage':torch.cat(volts),'stop_trace':traces,'trajectories':trajectories,'branch_states':branch_states,'fusion_weights':self.mix_logits.softmax(0)}

    def optimizer_groups(self):
        groups=[dict(params=self.old.initial.parameters(),lr=1e-5),dict(params=self.champion.parameters(),lr=1e-5),dict(params=self.old.refiner.parameters(),lr=1e-4),dict(params=[self.mix_logits],lr=1e-3)]
        if self.projection is not None:groups.append(dict(params=self.projection.parameters(),lr=1e-5))
        return groups

    def close(self):self.champion.close()

def loss(out,batch,fov,arm):
    target=dict(mask=batch['mask'],log_material=torch.cat((batch['sigma'],batch['eps_r']),1).clamp_min(1e-8).log())
    score=generic_objective(out,target,fov,False)[0]
    extra=[]
    for i,t in enumerate(out['trajectories']):
        lab={k:v[i:i+1] for k,v in target.items()};v=score*0
        if arm.get('ablate')!='auxiliary':
            supervised=t['old_states']+t['branches'][1:]
            v=v+.2*torch.stack([generic_objective(s,lab,fov,False)[0] for s in supervised]).mean()
        if arm.get('ablate')!='physics':
            v=v+.1*torch.stack([e.mean() for e in t['errors'][1:]]+[t['final_error'].mean()]).mean()
        extra.append(v)
    return score+torch.stack(extra).mean(),score
