"""Read-only process-lock/source audit; writes a new diagnostic record only."""
import json,time,hashlib,msvcrt
from pathlib import Path
ROOT=Path('E:/Codex/old_champion_selection_v1')
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=read(ROOT/'protocol.json');s=read(ROOT/'status.json')
changed=[name for name,h in p['source_hashes'].items() if sha(name)!=h]
assert not changed
lock=ROOT/'worker.lock'
with lock.open('r+b') as f:
    f.seek(0)
    try:
        msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1);held=False
        f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
    except OSError:held=True
record=dict(time_unix=time.time(),status=s,OS_worker_lock='HELD' if held else 'FREE',sources_unchanged=True,protocol_sha256=sha(ROOT/'protocol.json'),error_present=(ROOT/'error.json').exists(),warning='Lock/status only. Cross-check external PID command line before any restart.')
dest=ROOT/'diagnostics';dest.mkdir(exist_ok=True)
(dest/f'startup_{time.time_ns()}.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record),flush=True)
