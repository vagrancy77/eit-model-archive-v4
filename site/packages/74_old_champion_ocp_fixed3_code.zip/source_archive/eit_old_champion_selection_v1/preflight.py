"""Freeze the new protocol only after acceptances and old-artifact preservation."""
import sys,ast,json
from pathlib import Path
sys.path.insert(0,'E:/Codex')
from eit_old_champion_selection_v1.run import freeze,read,sources
from eit_old_champion_selection_v1.config import ROOT,HERE
from comsol_v4.data_v6 import file_hash
from comsol_feedback_loop.io import write_json
def main():
    if (ROOT/'preflight.json').exists():raise FileExistsError('Preflight already recorded')
    qa=read(ROOT/'extended_acceptance.json')
    assert all(file_hash(p)==h for p,h in qa['sources'].items())
    assert file_hash(ROOT/'acceptance.json')==qa['inherited_acceptance_sha256']
    original=Path('E:/Codex/short_selection_v1')
    audit=read(original/'offline_review_v2/audit.json');assert audit['completed']==21
    preserved={}
    for arm,item in audit['inventory'].items():
        for name,h in item['hashes'].items():
            path=original/'runs'/arm/name;assert file_hash(path)==h;preserved[str(path)]=h
    old18=read(original/'completion_v2/preserved_18_hashes.json')
    for path,h in old18.items():assert file_hash(path)==h;preserved[path]=h
    for folder in ('offline_review_v1','offline_review_v2','historical_comparison_v1'):
        for path in (original/folder).glob('*.json'):preserved[str(path)]=file_hash(path)
    for p in HERE.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'))
    protocol,ph=freeze()
    write_json(ROOT/'protected_historical_hashes.json',preserved)
    write_json(ROOT/'preflight.json',dict(status='PASS',protocol_sha256=ph,all21_unchanged=True,original18_unchanged=True,protected_files=len(preserved),
        source_files=len(sources()),extended_acceptance_pass=True,no_test_read=True,wall_deadline=None,no_old_training_restarted=True,
        display_sources={str(HERE/p):file_hash(HERE/p) for p in ('dashboard.py','index.html','start.ps1','start_dashboard.ps1')},
        distinction='new 8-arm experiment, previous21 not repeated; still not a final efficacy selection'))
    print(json.dumps(dict(status='PASS',protocol_sha256=ph,protected_files=len(preserved)),ensure_ascii=False),flush=True)
if __name__=='__main__':main()
