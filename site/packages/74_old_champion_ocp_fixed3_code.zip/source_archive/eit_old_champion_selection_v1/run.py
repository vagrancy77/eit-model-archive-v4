"""Eight new arms on the requested common base. No wall deadline or test reads."""
import sys,os,time,json,traceback,zipfile,gc
from collections import Counter
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import DataLoader,Subset
sys.path.insert(0,'E:/Codex')
from eit_old_champion_selection_v1.config import *
from eit_old_champion_selection_v1.model import Combined,loss,model_inputs,DEFAULT_WEIGHTS
from eit_champion_adaptive_v3.data import StrictChampionDataset
from eit_champion_adaptive_v3.fem import PixelConformingFEM
from eit_short_selection_v1.metrics import metadata,metric,aggregate,compare
from common import DATA,NORMALIZER
from comsol_v4.data_v6 import Normalizer,grid_arrays,file_hash,signature,FINAL_SIGNATURE
from comsol_feedback_loop.io import write_json,save_checkpoint

def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sources():
    old=read('E:/Codex/eit_short_release_v2/manifest.json')['runtime_hashes']
    paths={Path(p) for p in old if p.endswith('.py')}
    paths.update(HERE/n for n in ('model.py','config.py','acceptance.py','extended_acceptance.py','run.py'))
    paths.update(Path('E:/Codex/eit_reproduction')/n for n in ('comsol_feedback/model.py','comsol_feedback_loop/model.py','pytorch_eit/topology_residual_net.py'))
    return {str(p):file_hash(p) for p in sorted(paths)}

def freeze():
    qa=read(ROOT/'acceptance.json');extra=read(ROOT/'extended_acceptance.json')
    assert qa['status']=='PASS' and extra['status']=='PASS'
    assert signature(DATA)==FINAL_SIGNATURE
    assets={str(p):file_hash(p) for p in (OLD,DEFAULT_WEIGHTS,PARENT,NORMALIZER,Path('E:/Codex/shape_generalization_v1/phase2/physical_projection.npz'))}
    assert assets[str(OLD)]==OLD_SHA
    p=dict(version='old-plus-entire-champion-short-selection-v1',stage_a=STAGE_A,stage_b_ablations=ABLATIONS,seed=SEED,steps=STEPS,batch_size=BATCH,total_new_arms=8,
           training_pool=3400,validation_cases=720,test_read=False,wall_deadline=None,not_full_epoch=True,source_hashes=sources(),assets=assets,
           acceptance_sha256=file_hash(ROOT/'acceptance.json'),extended_acceptance_sha256=file_hash(ROOT/'extended_acceptance.json'),mesh_sha256=qa['mesh']['mesh_sha256'],
           old_complete_chain_preserved=True,champion_complete_preserved=True,fusion='global softmax weights shared by probability and absolute material; initially equal; learned at lr .001',
           supervision='generic foreground BCE+Dice+0.1 material; no cutout/mouth/E supervision. Old pretrained lineage retained',
           loss='final generic + .2 mean old-states/other-branches generic + .1 mean old-post-update/fused field voltage MSE',
           selection='U=(all IoU+E local IoU)/2. Max U among A-protected dynamic candidates. Initial eligible. A drop <=.002 from oc_adaptive initial. No hard fill guard; report all tradeoffs/Pareto.',
           stage_b_rule='pick protected dynamic base with max U after A; if none protected, diagnostic highest U only, no success claim. Reset to same pretrained parents for each ablation.',
           lr=dict(initial=1e-5,refiner=1e-4,fusion=1e-3),weight_decay=1e-4,
           limitations=['single seed short budget','adaptive reuse of val for stage B; selection bias','different parent pretraining histories','full branches/parameters differ with projection','old learned topology/risk bias retained by request','FEM pixel compatible not exact COMSOL','known background condition','historical test previously observed'])
    p=json.loads(json.dumps(p))
    if (ROOT/'protocol.json').exists():assert read(ROOT/'protocol.json')==p,'Frozen protocol mismatch'
    else:
        write_json(ROOT/'protocol.json',p)
        with zipfile.ZipFile(ROOT/'frozen_sources.zip','x',zipfile.ZIP_DEFLATED) as z:
            for path in p['source_hashes']:z.write(path,Path(path).as_posix().replace(':',''))
    return p,file_hash(ROOT/'protocol.json')

def main():
    import msvcrt
    ROOT.mkdir(parents=True,exist_ok=True)
    with (ROOT/'worker.lock').open('a+b') as lock:
        if lock.tell()==0:lock.write(b'0');lock.flush()
        lock.seek(0)
        try:msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        except OSError:print('Worker lock busy; leaving current worker alone',flush=True);return
        if (ROOT/'queue_complete.json').exists():print('Computed; do not retrain');return
        p,ph=freeze()
        if (ROOT/'error.json').exists():
            (ROOT/'errors').mkdir(exist_ok=True);(ROOT/'error.json').rename(ROOT/'errors'/f'prior_{time.time_ns()}.json')
        if not (ROOT/'launch.json').exists():write_json(ROOT/'launch.json',dict(started_unix=time.time(),wall_deadline=None))
        launch=read(ROOT/'launch.json')
        def status(phase,**kw):
            obj=dict(phase=phase,pid=os.getpid(),updated_unix=time.time(),started_unix=launch['started_unix'],total_arms=8,test_read=False,wall_deadline=None,**kw)
            write_json(ROOT/'status.json',obj);print(json.dumps(obj,ensure_ascii=False),flush=True)
        torch.set_num_threads(2);torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
        status('loading_data');x,y,fov=grid_arrays(DATA);solver=PixelConformingFEM(x,y,fov)
        assert solver.info['mesh_sha256']==p['mesh_sha256']
        norm=Normalizer.load(NORMALIZER,DATA);norm.validate_training_contract(DATA,'calibrated')
        data={s:StrictChampionDataset(DATA,s,norm,solver) for s in ('train','val')}
        assert len(data['train'])==3400 and len(data['val'])==720
        order_info=read('E:/Codex/short_selection_v1/training_order.json');order=order_info['indices']
        assert len(order)==512 and order_info['case_ids']==[data['train'].rows[i]['case_id'] for i in order]
        if (ROOT/'training_order.json').exists():assert read(ROOT/'training_order.json')==order_info
        else:write_json(ROOT/'training_order.json',order_info)
        meta=metadata(data['val'].rows,'val')
        move=lambda b:{k:v.cuda() if torch.is_tensor(v) else v for k,v in b.items()}
        def validate(model,arm,dest,tag):
            jp=dest/(tag+'.json');npz=dest/(tag+'.npz')
            if jp.exists():
                result=read(jp);assert result['prediction_sha256']==file_hash(npz);return result
            model.eval();records=[];probs=[];truth=[];scores=[];tick=time.monotonic()
            for raw in DataLoader(data['val'],batch_size=2,num_workers=0):
                b=move(raw)
                with torch.no_grad():
                    out=model(*model_inputs(b));_,score=loss(out,b,model.fov,arm)
                    errors=torch.cat([t['final_error'] for t in out['trajectories']]).cpu().numpy()
                    target=torch.cat((b['sigma'],b['eps_r']),1).clamp_min(1e-8).log()
                    err=(((out['log_material']-target).abs()*model.fov).sum((2,3))/model.fov.sum()).cpu().numpy()
                pp=out['probability'][:,0].cpu().numpy();tt=raw['mask'][:,0].numpy()>.5
                for i in range(len(pp)):
                    info,added,neighbor=meta[len(records)];assert info['case_id']==raw['case_id'][i]
                    r=metric(pp[i],tt[i],info,added,neighbor)
                    r.update(voltage_mse_10=float(errors[i,0]),voltage_mse_50=float(errors[i,1]),log_sigma_mae=float(err[i,:2].mean()),log_eps_mae=float(err[i,2:].mean()),stop=out['stop_trace'][i])
                    records.append(r);probs.append(pp[i]);truth.append(tt[i])
                scores.extend([float(score)]*len(pp));n=len(records)
                if n%10==0 or n==720:
                    rate=(time.monotonic()-tick)/n;status('validation',arm=arm['id'],tag=tag,processed=n,total=720,seconds_per_unit=rate,phase_remaining_seconds=rate*(720-n))
                del b,out,score
            groups=aggregate(records)
            np.savez_compressed(npz,probability=np.stack(probs),truth=np.stack(truth),case_ids=np.array([r['case_id'] for r in records]))
            result=dict(tag=tag,groups=groups,records=records,generic_score=float(np.mean(scores)),utility=utility(groups),seconds=time.monotonic()-tick,fusion_weights=model.mix_logits.softmax(0).detach().cpu().tolist(),prediction_sha256=file_hash(npz),
                        actual_k_counts=dict(Counter(r['stop']['executed_steps'] for r in records)),stop_reasons=dict(Counter(r['stop']['reason'] for r in records)))
            write_json(jp,result);return result
        def run_arm(arm):
            dest=ROOT/'runs'/arm['id'];dest.mkdir(parents=True,exist_ok=True)
            if (dest/'complete.json').exists():
                c=read(dest/'complete.json');assert c['protocol_sha256']==ph and c['checkpoint_sha256']==file_hash(dest/c['selected_checkpoint']);return
            assert sources()==p['source_hashes']
            assert all(file_hash(path)==h for path,h in p['assets'].items())
            status('starting_arm',arm=arm['id'])
            torch.manual_seed(SEED);torch.cuda.manual_seed_all(SEED);model=Combined(solver,arm).cuda()
            opt=torch.optim.AdamW(model.optimizer_groups(),weight_decay=1e-4);step=0;tick=time.monotonic()
            def checkpoint():return dict(model=model.state_dict(),optimizer=opt.state_dict(),step=step,arm=arm,protocol_sha256=ph,policy=model.policy.as_dict(),rng=torch.get_rng_state(),cuda_rng=torch.cuda.get_rng_state_all())
            try:
                if not (dest/'initial.pt').exists():save_checkpoint(dest/'initial.pt',checkpoint())
                initial=validate(model,arm,dest,'initial')
                if (dest/'last.pt').exists():
                    ck=torch.load(dest/'last.pt',map_location='cpu',weights_only=True);assert ck['protocol_sha256']==ph
                    model.load_state_dict(ck['model'],strict=True);opt.load_state_dict(ck['optimizer']);step=ck['step'];torch.set_rng_state(ck['rng']);torch.cuda.set_rng_state_all(ck['cuda_rng']);del ck
                attempt=dest/'attempts'/f'{time.time_ns()}';attempt.mkdir(parents=True)
                write_json(attempt/'start.json',dict(resume_step=step,pid=os.getpid(),time_unix=time.time()))
                model.train();start=time.monotonic();resume=step
                for j,raw in enumerate(DataLoader(Subset(data['train'],order),batch_size=BATCH,shuffle=False,num_workers=0)):
                    if j<step:continue
                    b=move(raw);opt.zero_grad(set_to_none=True);out=model(*model_inputs(b));value,score=loss(out,b,model.fov,arm)
                    if not torch.isfinite(value):raise FloatingPointError('Nonfinite loss')
                    value.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True);opt.step();step=j+1
                    row=dict(step=step,loss=float(value.detach()),generic=float(score.detach()),case_ids=raw['case_id'],fusion_weights=out['fusion_weights'].detach().cpu().tolist(),stop=out['stop_trace'],time_unix=time.time())
                    with (attempt/'history.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(row)+'\n')
                    rate=(time.monotonic()-start)/max(step-resume,1)
                    status('training',arm=arm['id'],processed=step,total=STEPS,seconds_per_unit=rate,phase_remaining_seconds=rate*(STEPS-step),loss=row['loss'])
                    if step%16==0 or step==STEPS:save_checkpoint(dest/'last.pt',checkpoint())
                    del out,b,value,score
                trained=validate(model,arm,dest,'trained')
                rows={}
                for path in sorted((dest/'attempts').glob('*/history.jsonl')):
                    for line in path.read_text().splitlines():
                        r=json.loads(line);rows[r['step']]=r
                assert sorted(rows)==list(range(1,257))
                for j in range(STEPS):assert rows[j+1]['case_ids']==order_info['case_ids'][j*2:j*2+2]
                write_json(dest/'training_history.json',[rows[i] for i in sorted(rows)])
                base=read(ROOT/'runs/oc_adaptive/initial.json')
                eligible=[r for r in (initial,trained) if r['groups']['A']['iou']>=base['groups']['A']['iou']-.002]
                chosen=max(eligible or [initial,trained],key=lambda r:r['utility']);tag=chosen['tag']
                name='last.pt' if tag=='trained' else 'initial.pt'
                write_json(dest/'change.json',compare(initial['records'],trained['records']))
                write_json(dest/'complete.json',dict(arm=arm,steps=step,selected=tag,selected_checkpoint=name,checkpoint_sha256=file_hash(dest/name),protocol_sha256=ph,utility=chosen['utility'],A_protection_pass=bool(eligible),seconds=time.monotonic()-tick,status='computed_pending_review',test_read=False))
            finally:model.close();del model,opt;gc.collect();torch.cuda.empty_cache()
        for arm in sorted(STAGE_A,key=lambda a:a['id']!='oc_adaptive'):run_arm(arm)
        dynamic=[];base=read(ROOT/'runs/oc_adaptive/initial.json')['groups']['A']['iou']
        for arm in STAGE_A:
            if arm['loop']!='adaptive':continue
            c=read(ROOT/'runs'/arm['id']/'complete.json');v=read(ROOT/'runs'/arm['id']/(c['selected']+'.json'))
            dynamic.append((arm,v,v['groups']['A']['iou']>=base-.002))
        pool=[r for r in dynamic if r[2]] or dynamic
        selected=max(pool,key=lambda row:row[1]['utility'])[0]
        decision=dict(selected_base=selected,criterion=p['stage_b_rule'],A_protected_candidates=[r[0]['id'] for r in dynamic if r[2]],test_read=False)
        if (ROOT/'stage_b_decision.json').exists():assert read(ROOT/'stage_b_decision.json')==decision
        else:write_json(ROOT/'stage_b_decision.json',decision)
        arms=STAGE_A+[dict(id='selected_no_'+a,projection=selected['projection'],loop='adaptive',ablate=a) for a in ABLATIONS]
        for arm in arms[4:]:run_arm(arm)
        results={}
        for arm in arms:
            d=ROOT/'runs'/arm['id'];c=read(d/'complete.json');v=read(d/(c['selected']+'.json'))
            results[arm['id']]=dict(complete=c,groups=v['groups'],utility=v['utility'],fusion_weights=v['fusion_weights'])
        write_json(ROOT/'summary.json',dict(results=results,all8_complete=True,final_selection_frozen=False,test_read=False))
        write_json(ROOT/'queue_complete.json',dict(completed=8,total=8,status='computed_pending_independent_review',test_read=False))
        status('computed_pending_independent_review',completed=8,total=8)

if __name__=='__main__':
    try:main()
    except Exception:
        ROOT.mkdir(parents=True,exist_ok=True);write_json(ROOT/'error.json',dict(error=traceback.format_exc(),time_unix=time.time()))
        s=read(ROOT/'status.json') if (ROOT/'status.json').exists() else {};write_json(ROOT/'status.json',{**s,'phase':'failed','updated_unix':time.time()});raise
