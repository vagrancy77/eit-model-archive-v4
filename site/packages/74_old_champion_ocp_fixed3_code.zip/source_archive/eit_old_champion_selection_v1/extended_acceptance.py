"""Batch2 and every planned optional switch, using TRAIN only before freezing."""
import sys,time,inspect
from pathlib import Path
import torch
from torch.utils.data import default_collate
sys.path.insert(0,'E:/Codex')
from eit_old_champion_selection_v1.model import Combined,loss,model_inputs
from eit_old_champion_selection_v1.config import ROOT,SEED,ABLATIONS
from eit_champion_adaptive_v3.data import StrictChampionDataset
from eit_champion_adaptive_v3.fem import PixelConformingFEM
from common import DATA,NORMALIZER
from comsol_v4.data_v6 import Normalizer,grid_arrays,file_hash
from comsol_feedback_loop.io import write_json

def main():
    path=ROOT/'extended_acceptance.json'
    if path.exists():raise FileExistsError('Do not overwrite acceptance')
    torch.set_num_threads(2);torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
    x,y,fov=grid_arrays(DATA);solver=PixelConformingFEM(x,y,fov)
    norm=Normalizer.load(NORMALIZER,DATA)
    ds=StrictChampionDataset(DATA,'train',norm,solver,limit=2)
    raw=default_collate([ds[0],ds[1]]);b={k:v.cuda() if torch.is_tensor(v) else v for k,v in raw.items()}
    rows=[]
    for projection in (False,True):
        for ablate in (None,*ABLATIONS):
            arm=dict(id=f'qa_p{int(projection)}_{ablate}',projection=projection,loop='adaptive')
            if ablate:arm['ablate']=ablate
            torch.manual_seed(SEED);torch.cuda.manual_seed_all(SEED)
            m=Combined(solver,arm).cuda();params=m.optimizer_groups()
            ids=[id(p) for g in params for p in g['params']]
            # parameters() generators were consumed for the identity check.
            assert len(ids)==len(set(ids)) and set(ids)=={id(p) for p in m.parameters()}
            opt=torch.optim.AdamW(m.optimizer_groups(),weight_decay=1e-4)
            inputs=[]
            def capture(_module,args):
                inputs.append((float(args[0]['residual'].abs().sum()),float(args[0]['hint'].abs().sum())))
            hook=m.old.refiner.register_forward_pre_hook(capture)
            m.train();tick=time.monotonic();before=m.old.physics.evaluations
            out=m(*model_inputs(b));value,score=loss(out,b,m.fov,arm)
            assert m.old.physics.evaluations-before==sum(t['dual_frequency_solves'] for t in out['stop_trace'])
            assert len(out['stop_trace'])==2 and torch.isfinite(value)
            if ablate=='hint':assert all(h==0 for _,h in inputs)
            else:assert all(h>0 for _,h in inputs)
            if ablate=='residual':assert all(r==0 for r,_ in inputs)
            else:assert all(r>0 for r,_ in inputs)
            if ablate in ('physics','auxiliary'):
                full,_=loss(out,b,m.fov,{**arm,'ablate':None})
                if ablate=='physics':
                    expected=.1*torch.stack([torch.stack([e.mean() for e in t['errors'][1:]]+[t['final_error'].mean()]).mean() for t in out['trajectories']]).mean()
                    torch.testing.assert_close(full-value,expected,rtol=1e-4,atol=1e-8)
                assert float(full-value)>0
            value.backward();grad=torch.nn.utils.clip_grad_norm_(m.parameters(),1.,error_if_nonfinite=True)
            oldweight=m.mix_logits.detach().clone();opt.step()
            assert not torch.equal(m.mix_logits.detach(),oldweight)
            for p in m.parameters():assert torch.isfinite(p).all()
            row=dict(arm=arm,train_batch2_seconds=time.monotonic()-tick,gradient_norm_before_clip=float(grad),loss=float(value.detach()),executed_k=[t['executed_steps'] for t in out['stop_trace']],all_fresh_FEM_count=True,optimizer_all_parameters_once=True)
            rows.append(row);print(row,flush=True)
            hook.remove();m.close();del m,out,opt,value,score;torch.cuda.empty_cache()
    write_json(path,dict(status='PASS',train_only=True,test_read=False,checks='All ablations on both common-base variants, batch2, one QA optimizer update discarded; source hashes recorded',arms=rows,
                         sources={str(Path(__file__).with_name(n)):file_hash(Path(__file__).with_name(n)) for n in ('model.py','config.py','acceptance.py','extended_acceptance.py')},inherited_acceptance_sha256=file_hash(ROOT/'acceptance.json')))
    print('EXTENDED ACCEPTANCE PASS',flush=True)

if __name__=='__main__':main()
