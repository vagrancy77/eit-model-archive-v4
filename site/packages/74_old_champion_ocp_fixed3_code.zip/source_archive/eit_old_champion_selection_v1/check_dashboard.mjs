import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const html=fs.readFileSync('E:/Codex/eit_old_champion_selection_v1/index.html','utf8');
const script=html.match(/<script>([\s\S]*?)<\/script>/)[1];
async function render(data,offline=false){
 const els=new Map();
 function element(){return {textContent:'',style:{},children:[],appendChild(x){this.children.push(x)},replaceChildren(){this.children=[]}}}
 const document={getElementById(id){if(!els.has(id))els.set(id,element());return els.get(id)},createElement:element};
 vm.runInNewContext(script,{document,fetch:async()=>{if(offline)throw Error('offline');return{ok:true,json:async()=>data}},AbortSignal:{timeout(){}},setTimeout(){},Date,Number,Math,Error});
 await new Promise(r=>setImmediate(r));return els;
}
const response=await fetch('http://127.0.0.1:8772/');assert.equal(response.status,200);assert.equal(await response.text(),html);
const d=await(await fetch('http://127.0.0.1:8772/api/status')).json();assert.equal(d.total,8);assert.equal(d.wall_deadline,null);assert.equal(d.error,null);
let els=await render(d);assert.equal(els.get('rows').children.length,8);assert.equal(els.get('error').style.display,'none');
if(d.live){assert.notEqual(els.get('finish').textContent,'—');assert.notEqual(els.get('eta').textContent,'无运行ETA')}
const fixtures={stale:{...d,live:false,eta_seconds:null,finish_unix:null},completed:{...d,live:false,completed:8,status:{...d.status,phase:'computed_pending_independent_review'}},failed:{...d,live:false,status:{...d.status,phase:'failed'},error:{error:'fixture failure'}}};
for(const [name,fixture] of Object.entries(fixtures)){const e=await render(fixture);assert.equal(e.get('finish').textContent,'—');assert.equal(e.get('eta').textContent,'无运行ETA');if(name==='failed'){assert.equal(e.get('error').style.display,'block');assert.equal(e.get('error').textContent,'fixture failure')}}
els=await render(d,true);assert.equal(els.get('finish').textContent,'—');assert.equal(els.get('eta').textContent,'已暂停');
assert.equal((await fetch('http://127.0.0.1:8772/api/status',{method:'POST'})).status,501);
assert.equal((await fetch('http://127.0.0.1:8772/no-file-browsing')).status,404);
const report={status:'PASS',scope:'HTTP and JavaScript mock-DOM functional checks only; no real browser screenshot QA',snapshot_phase:d.status.phase,rows:8,live_eta:d.live,error:null,stale_offline_failed_terminal_checks:true,read_only_http:true,screenshot_qa:false,created_utc:new Date().toISOString()};
fs.writeFileSync('E:/Codex/old_champion_selection_v1/dashboard_acceptance.json',JSON.stringify(report,null,2),{flag:'wx'});console.log(JSON.stringify(report));
