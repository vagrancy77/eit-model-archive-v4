from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=Path('E:/Codex/old_champion_selection_v1')
OLD=Path('E:/Codex/complex_feedback_quick_v2/best.pt')
OLD_SHA='068c966b8aab28436cc1e4b1f0aef2ebf68ca2f84bc4a3153c81bb5170c366ca'
PARENT=Path('E:/Codex/shape_generalization_v1/phase3/runs/physical_c4_seed20261023/best.pt')
SEED=20261024
STEPS=256
BATCH=2
STAGE_A=[dict(id='oc_fixed3',projection=False,loop='fixed3'),dict(id='oc_adaptive',projection=False,loop='adaptive'),dict(id='ocp_fixed3',projection=True,loop='fixed3'),dict(id='ocp_adaptive',projection=True,loop='adaptive')]
ABLATIONS=('hint','residual','physics','auxiliary')
def utility(groups):return .5*(groups['all']['iou']+groups['E']['local_iou'])
