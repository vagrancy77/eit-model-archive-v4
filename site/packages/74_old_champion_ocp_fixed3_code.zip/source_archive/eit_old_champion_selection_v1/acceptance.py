"""TRAIN-only verification of the new connection; never a performance claim."""
import sys,json,time,inspect
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import default_collate
sys.path.insert(0,'E:/Codex')
from eit_old_champion_selection_v1.model import Combined,canonical,loss,model_inputs
from eit_old_champion_selection_v1.config import ROOT,OLD,OLD_SHA,STAGE_A,SEED
from eit_champion_adaptive_v3.data import StrictChampionDataset
from eit_champion_adaptive_v3.fem import PixelConformingFEM
from common import DATA,NORMALIZER
from comsol_v4.data_v6 import Normalizer,grid_arrays,file_hash
from comsol_feedback_loop.io import write_json

def main():
    ROOT.mkdir(parents=True,exist_ok=True);dest=ROOT/'acceptance.json'
    if dest.exists():raise FileExistsError('Keep acceptance bytes; new version required')
    torch.set_num_threads(2);torch.manual_seed(SEED);torch.cuda.manual_seed_all(SEED)
    torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
    x,y,fov=grid_arrays(DATA);solver=PixelConformingFEM(x,y,fov)
    norm=Normalizer.load(NORMALIZER,DATA);norm.validate_training_contract(DATA,'calibrated')
    ck=torch.load(OLD,map_location='cpu',weights_only=True)
    with np.load(NORMALIZER,allow_pickle=False) as z:
        for k in ('mean','std'):np.testing.assert_array_equal(np.asarray(ck['normalizer'][k]),z[k])
    ds=StrictChampionDataset(DATA,'train',norm,solver,limit=2)
    raw=default_collate([ds[0]]);b={k:v.cuda() if torch.is_tensor(v) else v for k,v in raw.items()}
    checks={};timing=[]
    for arm in STAGE_A:
        torch.manual_seed(SEED);torch.cuda.manual_seed_all(SEED);m=Combined(solver,arm).cuda();m.eval();tick=time.monotonic()
        for k,v in ck['model'].items():torch.testing.assert_close(m.old.state_dict()[k].cpu(),v,rtol=0,atol=0)
        assert list(inspect.signature(m.forward).parameters)==['features','observed','background','reference','voltage','dv','groups']
        with torch.no_grad():out=m(*model_inputs(b))
        if arm['loop']=='fixed3':
            with torch.no_grad():original=m.old(b['features'],b['observed'],b['background'],b['reference'])
            for k in ('probability','sigma','eps_r'):
                torch.testing.assert_close(out['branch_states'][0][0][k],canonical(original)[k],rtol=0,atol=0)
            del original
        with torch.no_grad():
            expected=m.champion_state(b['champion_voltage'],b['champion_dv'],b['background_group'])
            for k in ('probability','sigma','eps_r'):torch.testing.assert_close(out['branch_states'][0][1][k],expected[k],rtol=0,atol=0)
        weights=out['fusion_weights'];assert float(weights.min())>0
        for k in ('probability','sigma','eps_r'):
            expected=sum(w*s[k] for w,s in zip(weights,out['branch_states'][0]));torch.testing.assert_close(out[k],expected,rtol=0,atol=0)
        corrupt=dict(b)
        for key in ('mask','sigma','eps_r','labels','sdf','cutout','mouth'):
            if key in corrupt:corrupt[key]=torch.zeros_like(corrupt[key])
        with torch.no_grad():alternative=m(*model_inputs(corrupt))
        torch.testing.assert_close(out['probability'],alternative['probability'],rtol=0,atol=0)
        assert torch.isfinite(out['predicted_voltage']).all()
        assert (out['sigma'][...,torch.as_tensor(fov,device='cuda').bool()]>0).all()
        elapsed=time.monotonic()-tick;del out,alternative
        tick=time.monotonic();m.train();out=m(*model_inputs(b));value,_=loss(out,b,m.fov,arm);value.backward()
        modules={'v4':m.old.initial,'old_refiner':m.old.refiner,'champion':m.champion}
        if m.projection is not None:modules['projection']=m.projection
        grads={}
        for name,mod in modules.items():
            values=[p.grad for p in mod.parameters() if p.grad is not None]
            assert values and all(torch.isfinite(g).all() for g in values)
            grads[name]=sum(float(g.abs().sum()) for g in values);assert grads[name]>0
        assert m.mix_logits.grad is not None and torch.isfinite(m.mix_logits.grad).all() and float(m.mix_logits.grad.abs().sum())>0
        heads={name:sum(float(p.grad.abs().sum()) for p in getattr(m.old.initial,name).parameters() if p.grad is not None) for name in ('sdf_head','cutout_head','mouth_head','local_gate_head','case_gate_head','action_gate_head','material_head','background_head')}
        # Mouth may only feed a risk statistic, and very small gates can suppress gradients;
        # report exact sums instead of pretending each historical head was equally trained.
        row=dict(arm=arm['id'],loss=float(value.detach()),gradient_sums=grads,old_head_gradient_sums=heads,mix_gradient=m.mix_logits.grad.cpu().tolist(),forward_three_checks_seconds=elapsed,train_one_seconds=time.monotonic()-tick,stop=out['stop_trace'])
        timing.append(row);print(json.dumps(row),flush=True)
        m.close();del m,out,value;torch.cuda.empty_cache()
    checks.update(old_checkpoint_exact=True,old_fixed3_same_solver_exact=True,entire_champion_output_exact=True,convex_fusion_exact=True,truth_input_isolation=True,normalizers_exact=True,all_branch_gradients_nonzero=True,no_test_read=True)
    inherited=Path('E:/Codex/short_selection_v1/acceptance.json')
    result=dict(status='PASS',checks=checks,arms=timing,mesh=solver.info,old_sha256=file_hash(OLD),inherited_FEM_acceptance_sha256=file_hash(inherited),scope='TRAIN connection/gradient smoke, not efficacy; full FEM finite difference coverage inherited unchanged',test_read=False)
    write_json(dest,result);print('ACCEPTANCE PASS',flush=True)

if __name__=='__main__':main()
