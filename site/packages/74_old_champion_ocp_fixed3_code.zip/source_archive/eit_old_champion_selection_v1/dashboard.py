"""Loopback-only progress page; no mutation endpoints or file browsing."""
import json,time
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
ROOT=Path('E:/Codex/old_champion_selection_v1');HERE=Path(__file__).parent
IDS=['oc_adaptive','oc_fixed3','ocp_fixed3','ocp_adaptive','selected_no_hint','selected_no_residual','selected_no_physics','selected_no_auxiliary']
LABELS=['旧完整闭环 + 完整Champion · 动态K','旧完整闭环 + 完整Champion · 固定3','共同底座 + 投影分支 · 固定3','共同底座 + 投影分支 · 动态K','选定动态底座 · 去伴随提示','选定动态底座 · 去残差输入','选定动态底座 · 去物理损失','选定动态底座 · 去中间监督']
def read(p,default=None):
    try:return json.loads(p.read_text(encoding='utf-8'))
    except (OSError,ValueError):return default
def snapshot():
    now=time.time();s=read(ROOT/'status.json',{});runs=[];remaining=0.;age=now-s.get('updated_unix',now)
    terminal=s.get('phase') in ('failed','computed_pending_independent_review')
    samples={}
    for a in read(ROOT/'extended_acceptance.json',{}).get('arms',[]):
        if not a['arm'].get('ablate'):samples[a['arm']['projection']]=a['train_batch2_seconds']
    for id,label in zip(IDS,LABELS):
        d=ROOT/'runs'/id;c=read(d/'complete.json');initial=read(d/'initial.json');trained=read(d/'trained.json');active=s.get('arm')==id
        selected=read(d/(c['selected']+'.json')) if c else trained or initial
        runs.append(dict(id=id,label=label,complete=bool(c),active=active and not c,selected=c['selected'] if c else selected.get('tag') if selected else None,
                         utility=selected.get('utility') if selected else None,groups=selected.get('groups') if selected else None,
                         weights=selected.get('fusion_weights') if selected else None))
        if c:continue
        proj=id.startswith('ocp') or read(ROOT/'stage_b_decision.json',{}).get('selected_base',{}).get('projection',False)
        train=samples.get(proj,10.);ev=1.
        if initial:ev=initial['seconds']/720
        if active and s.get('phase')=='training':train=s.get('seconds_per_unit',train)
        if active and s.get('phase')=='validation':ev=s.get('seconds_per_unit',ev)
        for tag,r in [('initial',initial),('trained',trained)]:
            if r:continue
            done=s.get('processed',0) if active and s.get('phase')=='validation' and s.get('tag')==tag else 0
            remaining+=max(0,720-done)*ev
        steps=256 if trained or active and s.get('tag')=='trained' else s.get('processed',0) if active and s.get('phase')=='training' else 0
        remaining+=max(0,256-steps)*train
    live=not terminal and age<180 and s.get('phase') in ('loading_data','starting_arm','training','validation')
    return dict(status=s,now=now,age=age,live=live,completed=sum(r['complete'] for r in runs),total=8,runs=runs,
                eta_seconds=remaining if live else None,finish_unix=now+remaining if live else None,
                error=read(ROOT/'error.json'),stage_b=read(ROOT/'stage_b_decision.json'),wall_deadline=None)
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path in ('/','/index.html'):body=(HERE/'index.html').read_bytes();kind='text/html; charset=utf-8'
        elif self.path=='/api/status':body=json.dumps(snapshot(),ensure_ascii=False).encode();kind='application/json; charset=utf-8'
        elif self.path=='/favicon.ico':self.send_response(204);self.end_headers();return
        else:self.send_error(404);return
        self.send_response(200);self.send_header('Content-Type',kind);self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
    def log_message(self,*args):pass
if __name__=='__main__':
    print('http://127.0.0.1:8772',flush=True);ThreadingHTTPServer(('127.0.0.1',8772),Handler).serve_forever()
