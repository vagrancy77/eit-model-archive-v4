$ErrorActionPreference = 'Stop'
$root = 'E:/Codex/old_champion_selection_v1'
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
if (-not (Test-Path -LiteralPath "$root/protocol.json")) { throw 'Freeze and verify protocol first' }
$existing = @(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^python(w)?\.exe$' -and $_.CommandLine -match 'eit_old_champion_selection_v1[/\\]run\.py' })
if ($existing.Count -gt 0) { throw "Existing worker detected: $($existing.ProcessId -join ',')" }
$proc = Start-Process -FilePath 'E:/conda-envs/pytorch-gpu/python.exe' -ArgumentList @('-B','-u','E:/Codex/eit_old_champion_selection_v1/run.py') -WorkingDirectory 'E:/Codex' -WindowStyle Hidden -RedirectStandardOutput "$root/worker_$stamp.stdout.log" -RedirectStandardError "$root/worker_$stamp.stderr.log" -PassThru
Write-Output "Worker PID $($proc.Id); logs $root/worker_$stamp.*.log"
