$ErrorActionPreference = 'Stop'
$root = 'E:/Codex/old_champion_selection_v1'
if (Get-NetTCPConnection -LocalPort 8772 -State Listen -ErrorAction SilentlyContinue) { throw 'Port 8772 already occupied; inspect before restarting' }
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
$proc = Start-Process -FilePath 'E:/conda-envs/pytorch-gpu/python.exe' -ArgumentList @('-B','-u','E:/Codex/eit_old_champion_selection_v1/dashboard.py') -WorkingDirectory 'E:/Codex' -WindowStyle Hidden -RedirectStandardOutput "$root/dashboard_$stamp.stdout.log" -RedirectStandardError "$root/dashboard_$stamp.stderr.log" -PassThru
Write-Output "Dashboard PID $($proc.Id); http://127.0.0.1:8772"
