# Full Champion + adaptive physical feedback (v3)

This is a separate implementation. Historical v2, V4/K3 and research outputs are not modified. No formal v3 training has been launched; the saved QA optimizer step is disposable, not a trained checkpoint.

## Architecture and exactly what changed

1. **Unchanged entire packaged Champion**: original preprocessing, four rotated measurement views, NeuralEvidenceFront, dual encoders, InterfaceBackbone decoder, interface-width head, FineGeometryQuery, aligned C4 fusion and original geometry/material readout. All 21,038,925 parameters are retained. Fat/Muscle TRAIN examples match the package outputs exactly. Known background group is required, not target class.
2. **Unchanged differentiable interface**: `z=geometry_logit`, `P=foreground`, absolute materials = package background + normalized fields × `[.2,.2,50000,50000]`, then log materials. No detach or mask remix.
3. **Replaced FEM discretization**: each of the 3096 valid 64×64 raster samples owns its entire disk-clipped Voronoi material cell. Cell-conforming P1 triangles integrate piecewise-constant materials; refinement preserves cell boundaries. The previous centroid lookup missed 51 pixels. New coverage is 3096/3096 with zero missed pixels. Boundary extension uses nearest valid pixel cells, explicitly not the original curved COMSOL lesion geometry.
4. **Unchanged learned feedback module**: fresh nonlinear dual-frequency FEM, complex residual, fresh detached adjoint hint, shared 13-to-5 FieldFeedback and bidirectional geometry/material updates. Background reference is recomputed for the new mesh, not reused from the old mesh.
5. **Added deterministic adaptive-stop controller** (no learned halting head): decisions depend only on residuals and successive predicted states. Both training and inference use it; samples can execute different depths in one batch. No extra lesion template, label, target ROI or location enters inference.
6. **Adjusted auxiliary loss reduction for variable depth**: for each case, `L = G_selected + .2 mean(G_0,...,G_Kexecuted) + .1 mean(E_1,...,E_Kexecuted)`; then mean over cases. `G = BCE + Dice + .1 material SmoothL1`. All executed candidates are supervised, including rejected states. This is an explicit implementation change, not claimed identical to v2 loss averaging.

After initialization, feedback still updates free geometry and four material fields; it does not enforce the Champion single-region representation. Adjoint hints are stop-gradient; direct FEM voltage loss and residual paths remain differentiable. Discrete stop decisions themselves are not differentiated.

## Dynamic K semantics

Default engineering policy: minimum 2, safety maximum 6, patience 2. Stop for joint stability only when all three hold consecutively: relative voltage-loss change ≤0.001, maximum FOV probability change ≤0.001, maximum FOV log-material change ≤0.001. Local maximum changes, not spatial averages, prevent small changing structures being hidden in an average.

If residual exceeds the best prior residual by >5% twice consecutively, stop for deterioration and return the prior lowest-residual state (possibly initialization). This is a safety heuristic, not proof that the selected state has best geometry. At the cap, return the last state and label `max_steps`, never convergence. NaN/Inf fails loudly. Values are configurable through a JSON StopPolicy; no optimal thresholds or optimal K have been established.

`actual_k` counts executed correction rounds. `selected_step` identifies the returned state; these differ on rollback. There are `actual_k+1` dual-frequency FEM evaluations per case, including initialization and final candidate, with no padded evaluations for stopped cases. The current implementation also computes a fresh hint at the final candidate; this has cost. Zero-initialized feedback stopping at 2 only verifies control flow, not learned convergence.

## FEM acceptance: two different questions

**Raster compatibility PASS**: x/y ascending over [-0.05,0.05] m, material[y,x], shape 64×64, FOV3096, 32 electrodes, 5° width, 0.25mA adjacent drives, 10/50kHz, depth1m, sigma S/m and relative permittivity. Dataset adapter rejects incompatible protocol instead of silently resizing/reordering. Whole-cell forward mapping and material adjoint are consistent. All 51 formerly blind pixels now have nonzero sensitivity in the numerical test. The old blind test pixel changes voltage by about 4.59e-6 V after the prescribed perturbation. Maximum tested finite-difference/adjoint relative error is about 3.15e-6.

**Exact agreement with original COMSOL NOT established**. On 10 TRAIN cases × two frequencies, old background voltage errors were 1.626–1.678%, new base-mesh errors 1.986–2.084%. Background-anchored difference errors were 2.568–5.114% old vs 1.946–5.375% new. Some improve, some worsen. Refining further does not establish exact equality. These are raw solver cross-checks, not reconstruction scores. See `E:/Codex/champion_adaptive_v3/qa/physics.json` for per-case values. Its PASS is scoped ONLY to topology/coverage/gradient, not COMSOL equality.

The dataset's source voltage used continuous curved geometries; its 64×64 labels are sampled observations, not an exact specification of that continuous geometry. Full raster participation therefore cannot guarantee identical original voltages. The effective dataset electrode contact setting is ideal equipotential/current, according to CONTACT_MODEL_ADDENDUM; the nominal metadata contact impedance was inactive. Other boundary/electrode/discretization discrepancies are not uniquely attributed. Do not silently fit calibration parameters to labels or claim all numerical mismatch is repaired.

## Entry points

GPU-capable Python: `E:/conda-envs/pytorch-gpu/python.exe -B -u`.

- `acceptance.py`: full-network parity, stopping unit tests, actual FEM mixed depths 2/4 (8 dual-frequency evaluations), nonzero gradients through front/backbone/query/feedback, disposable optimizer step. TRAIN only, no formal training.
- `physics_acceptance.py`: full pixel coverage, mesh topology, three refinements, gradient/scaling/reciprocity, old-blind sensitivity, independent COMSOL TRAIN comparison. Do not rerun merely to produce a figure.
- `train.py`: default only verifies hashes and prints protocol. Explicit `--run` permits a **single full-data epoch**, 3400 train / 720 validation, epoch0 eligible, six-hour per-invocation budget, no test, no automatic extension. Validation may stop with a partial file; selection uses full-validation generic loss only. Interrupted training resumes the deterministic batch order from `last.pt`; uncheckpointed batches may be repeated. New version changes require a separate run/protocol, not mixing source hashes.
- `infer.py --input raw.npz --output new.npz [--checkpoint best.pt]`: raw complex voltage and background `[2,32,32]` (frequency,drive,measure), known scalar group0/1, optional frequencies_hz. Assumes the documented acquisition protocol; canonicalizes each drive to return-electrode gauge. No truth fields needed. Without a checkpoint, output explicitly reports untrained feedback. Checkpoint policy and mesh must match; no silent fixed/adaptive K change.

Policy overrides: `--policy-json path.json`, e.g. fields `min_steps`, `max_steps`, `patience`; omitted fields use defaults. Training and inference checkpoint policy is recorded exactly. Training records per-case stopping trace and validation K histograms. Code-level defaults are not a claim of best short- or long-training performance.

## Limitations and current status

Implementation QA is not reconstruction efficacy or generalization evidence. No v3 accuracy gain, convergence, optimal K, resolution of protrusions, or arbitrary-real-shape capability is claimed. The package checkpoint has historical test exposure. New v3 tests use TRAIN only. Known homogeneous background, package inductive bias, learned training distribution, and free-field feedback remain assumptions. Exact COMSOL equivalence remains an open numerical validation item; this version must not be presented as fully physically matched.
