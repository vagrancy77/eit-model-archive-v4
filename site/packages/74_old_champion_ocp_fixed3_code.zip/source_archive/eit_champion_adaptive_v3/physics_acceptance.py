"""Raster/adjoint/topology/COMSOL comparison, bounded TRAIN diagnostics only."""
import sys,json,time,hashlib
from pathlib import Path
import numpy as np
sys.path.insert(0,'E:/Codex')
from eit_champion_adaptive_v3.fem import PixelConformingFEM
from comsol_feedback.fem import TerminalFEM,EPS0
from comsol_feedback.verify import background_parameters
from comsol_v4.data_v6 import grid_arrays,FINAL_DATASET_ROOT,load_rows,row_case_path
from comsol_v4.features import measurement_mask

ROOT=Path('E:/Codex/champion_adaptive_v3/qa')
def main():
    ROOT.mkdir(parents=True,exist_ok=True)
    x,y,fov=grid_arrays(FINAL_DATASET_ROOT);old=TerminalFEM(x,y,fov)
    counts=np.bincount(old.pixel,minlength=4096).reshape(64,64);missing=(counts==0)&fov
    rng=np.random.default_rng(20261024);gx,gy=np.meshgrid(x,y)
    field=.2*np.exp(.2*np.sin(40*gx)+.1*np.cos(30*gy))+1j*.03
    checks=[];solvers=[]
    for level in (0,1,2):
        tick=time.monotonic();solver=PixelConformingFEM(x,y,fov,refinement=level);solvers.append(solver)
        v,state=solver.solve(field);cot=rng.normal(size=(32,32))+1j*rng.normal(size=(32,32))
        g=solver.vjp(state,cot);gradient=[]
        for imag in (False,True):
            direction=rng.normal(size=(64,64))*(1j if imag else 1)*fov
            eps=1e-6
            fd=float(np.vdot(cot,(solver.solve(field+eps*direction)[0]-solver.solve(field-eps*direction)[0])/(2*eps)).real)
            ad=float(np.vdot(g,direction).real);error=abs(fd-ad)/max(abs(fd),abs(ad),1e-10)
            assert error<1e-5,(level,error)
            gradient.append(error)
        hom=solver.solve(np.ones((64,64)))[0]
        scaled=solver.solve(np.full((64,64),.2+.03j))[0]
        scaling=float(np.linalg.norm(scaled-hom/(.2+.03j))/np.linalg.norm(scaled));assert scaling<1e-9
        transfer=(v-np.roll(v,-1,-1))/.00025
        reciprocity=float(np.linalg.norm(transfer-transfer.T)/np.linalg.norm(transfer));assert reciprocity<1e-10
        formerly_blind_min=float(np.abs(g[missing]).min());assert formerly_blind_min>1e-12
        row,col=np.argwhere(missing)[0];changed=field.copy();changed[row,col]+=.05
        response=float(np.max(np.abs(solver.solve(changed)[0]-v)));assert response>1e-12
        checks.append(dict(refinement=level,solver=solver.info,gradient_relative_error=gradient,
                           homogeneous_scaling_error=scaling,reciprocity_error=reciprocity,
                           formerly_blind_51_min_adjoint_magnitude=formerly_blind_min,
                           single_old_blind_pixel_voltage_response=response,seconds=time.monotonic()-tick))
        print('NUMERICAL',json.dumps(checks[-1]),flush=True)
    assert max(np.abs(solvers[0].pixel_area-s.pixel_area).max() for s in solvers)<1e-15
    # Refinements keep exactly the same material regions and disk polygon.
    sampled=[];seen=set();mask=measurement_mask();q=lambda a:(a-np.roll(a,-1,-1))[mask]
    for row in load_rows(FINAL_DATASET_ROOT,'train'):
        with np.load(row_case_path(FINAL_DATASET_ROOT,row),allow_pickle=False) as z:
            p=json.loads(z['parameters_json'].item());key=(row['shape_class'],p['background_material'])
            if key in seen:continue
            seen.add(key);bg=background_parameters(p)
            material=z['conductivity_S_per_m']+1j*2*np.pi*np.array([10000,50000])[:,None,None]*EPS0*z['eps_r']
            observed,background=z['voltage'],z['background_voltage']
            # All ten cases at 0/1; two fixed first cases also at 2 for cost control.
            versions=[('legacy',old),('conforming0',solvers[0]),('conforming1',solvers[1])]
            if len(seen)<=2:versions.append(('conforming2',solvers[2]))
            predicted={};records=[]
            for name,s in versions:
                for fi in range(2):
                    ref=s.solve(np.full((64,64),bg[fi]))[0];pred=s.solve(material[fi])[0]
                    target=q(observed[fi]-background[fi]);delta=q(pred-ref);predicted[(name,fi)]=delta
                    records.append(dict(mesh=name,frequency=[10000,50000][fi],
                        background_error=float(np.linalg.norm(q(ref-background[fi]))/np.linalg.norm(q(background[fi]))),
                        anchored_delta_error=float(np.linalg.norm(delta-target)/np.linalg.norm(target))))
            refinement=[]
            for fi in range(2):
                denominator=np.linalg.norm(q(observed[fi]-background[fi]))
                refinement.append(dict(frequency=[10000,50000][fi],
                    step0_to_1=float(np.linalg.norm(predicted[('conforming0',fi)]-predicted[('conforming1',fi)])/denominator),
                    step1_to_2=float(np.linalg.norm(predicted[('conforming1',fi)]-predicted[('conforming2',fi)])/denominator) if len(seen)<=2 else None))
            sampled.append(dict(case_id=row['case_id'],shape=row['shape_class'],background=p['background_material'],records=records,refinement=refinement))
            print('TRAIN',row['case_id'],flush=True)
        if len(seen)==10:break
    ranges={}
    for name in ('legacy','conforming0','conforming1','conforming2'):
        rs=[r for c in sampled for r in c['records'] if r['mesh']==name]
        ranges[name]={key:[min(r[key] for r in rs),max(r[key] for r in rs)] for key in ('background_error','anchored_delta_error')}
    result=dict(status='PASS',scope='topology/coverage/gradient; independent COMSOL comparison is not exact equality',
        numerical=checks,train_cases=sampled,ranges=ranges,test_read=False,
        no_material_refitting=True,all_valid_pixels=3096,missing_pixels_after=0,
        source_sha256=hashlib.sha256(Path(__file__).with_name('fem.py').read_bytes()).hexdigest(),
        legacy_source_sha256=hashlib.sha256(Path('E:/Codex/eit_reproduction/comsol_feedback/fem.py').read_bytes()).hexdigest())
    (ROOT/'physics.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    np.savez_compressed(ROOT/'coverage.npz',x=x,y=y,fov=fov,old_count=counts,new_count=solvers[0].count,new_area=solvers[0].pixel_area)
    print(json.dumps(dict(status='PASS',ranges=ranges),indent=2),flush=True)

if __name__=='__main__':main()
