"""Adaptive stopping, mixed-depth batching, full-network gradients and parity."""
import sys,json,hashlib,time
from pathlib import Path
import torch
import numpy as np
from torch import nn
from torch.utils.data import default_collate
sys.path.insert(0,'E:/Codex')
from eit_champion_adaptive_v3.model import AdaptiveChampion,objective,model_inputs
from eit_champion_adaptive_v3.policy import StopPolicy,StopTracker
from eit_champion_adaptive_v3.fem import PixelConformingFEM
from eit_champion_adaptive_v3.data import StrictChampionDataset
from eit_champion_loop_v2.model import DEFAULT_WEIGHTS,VENDOR,vendor_model
from eit_final_c4_loop.model import state_from_fields
from common import DATA,NORMALIZER
from comsol_v4.data_v6 import Normalizer,grid_arrays

ROOT=Path('E:/Codex/champion_adaptive_v3/qa');HERE=Path(__file__).parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    ROOT.mkdir(parents=True,exist_ok=True);torch.set_num_threads(2);torch.manual_seed(20261024)
    tick=time.monotonic();physics=json.loads((ROOT/'physics.json').read_text())
    assert physics['status']=='PASS' and physics['source_sha256']==sha(HERE/'fem.py')
    policy_tests={}
    for mode,errors,deltas in [('stable',[1.]*6,[0.]*6),('still_improving',[.5**i for i in range(1,7)],[.02]*6),
                               ('worse',[1.2,1.3,1.4],[.02]*3),('residual_only',[1.]*6,[.02]*6)]:
        tracker=StopTracker(StopPolicy(),1.)
        for i,(e,d) in enumerate(zip(errors,deltas),1):
            result=tracker.update(i,e,d,d)
            if result['stop']:break
        policy_tests[mode]=result
    assert policy_tests['stable']['step']==2 and policy_tests['stable']['reason']=='joint_stability'
    assert policy_tests['still_improving']['reason']=='max_steps'
    assert policy_tests['worse']['reason']=='residual_deterioration' and policy_tests['worse']['selected_step']==0
    assert policy_tests['residual_only']['reason']=='max_steps','Residual alone must not stop shape change'
    for kw in (dict(min_steps=0),dict(max_steps=0),dict(patience=True),dict(min_steps=5,max_steps=2),dict(probability_max_tolerance=float('nan'))):
        try:StopPolicy(**kw)
        except ValueError:pass
        else:raise AssertionError('Invalid policy accepted')
    try:StopTracker(StopPolicy(),1.).update(1,float('nan'),0.,0.)
    except FloatingPointError:pass
    else:raise AssertionError('NaN must not be convergence')
    x,y,fov=grid_arrays(DATA);solver=PixelConformingFEM(x,y,fov)
    norm=Normalizer.load(NORMALIZER,DATA);norm.validate_training_contract(DATA,'calibrated')
    ds=StrictChampionDataset(DATA,'train',norm,solver,limit=10)
    selected={}
    for i in range(len(ds)):selected.setdefault(int(ds[i]['background_group']),i)
    assert set(selected)=={0,1}
    batch=default_collate([ds[selected[0]],ds[selected[1]]])
    model=AdaptiveChampion(solver).eval();ref,_=vendor_model.load_model(DEFAULT_WEIGHTS,'cpu')
    with torch.no_grad():
        s,actual=model.initial_state(batch['champion_voltage'],batch['champion_dv'],batch['background_group'])
        expected=ref(batch['champion_voltage'],batch['champion_dv'],batch['background_group'])
        for key,v in actual.items():
            if torch.is_tensor(v):assert torch.equal(v,expected[key]),key
            else:
                for kk in v:assert torch.equal(v[kk],expected[key][kk]),kk
    ref.close();del ref,actual,expected,s
    with torch.no_grad():out=model(*model_inputs(batch))
    baseline_trace=out['stop_trace'];assert out['actual_k'].tolist()==[2,2]
    assert all(t['reason']=='joint_stability' for t in baseline_trace)
    del out
    # Controlled QA-only updates, actual FEM, per-case depths in a single batch.
    original_feedback=model.feedback
    class ControlledUpdate(nn.Module):
        def forward(self,state,features,residual,hint):
            marker=features[:,0,0,0][:,None,None,None]
            return state_from_fields(state['logits']+.02*marker*model.fov,
                                     state['log_material']+.002*marker*model.fov,model.fov)
    model.feedback=ControlledUpdate();model.policy=StopPolicy(max_steps=4,deterioration_relative=1e6)
    controlled={**batch,'features':batch['features'].clone()};controlled['features'][:,0,0,0]=torch.tensor([0.,1.])
    before=model.physics.evaluations
    with torch.no_grad():out=model(*model_inputs(controlled))
    mixed_trace=out['stop_trace'];assert out['actual_k'].tolist()==[2,4],out['actual_k']
    assert model.physics.evaluations-before==8,'3+5 solves, no padded inactive solves'
    del out;model.feedback=original_feedback
    model.policy=StopPolicy(max_steps=3,deterioration_relative=1e6,probability_max_tolerance=0.,log_material_max_tolerance=0.)
    with torch.no_grad():model.feedback.head.bias.copy_(torch.tensor([.005,.001,-.001,.001,-.001]))
    b=default_collate([ds[selected[0]]]);model.train();out=model(*model_inputs(b));loss,_,_=objective(out,b,model.fov)
    assert out['actual_k'].tolist()==[3] and torch.isfinite(loss)
    loss.backward();gradient={}
    for name,module in [('front',model.initial.member.base.front),('backbone',model.initial.member.base.backbone),
                        ('fine_query',model.initial.member.refiner),('feedback',model.feedback)]:
        grads=[p.grad for p in module.parameters() if p.grad is not None]
        assert grads and all(torch.isfinite(g).all() for g in grads)
        gradient[name]=sum(float(g.abs().sum()) for g in grads);assert gradient[name]>0
    before=next(model.initial.parameters()).detach().clone()
    optimizer=torch.optim.AdamW(model.parameters(),lr=1e-5);optimizer.step()
    assert not torch.equal(before,next(model.initial.parameters()).detach())
    del out,loss,optimizer
    model.close()
    source=[*HERE.glob('*.py'),Path('E:/Codex/eit_champion_loop_v2/model.py'),Path('E:/Codex/eit_champion_loop_v2/data.py'),
            Path('E:/Codex/eit_final_c4_loop/model.py'),Path('E:/Codex/eit_shape_general/models.py'),
            Path('E:/Codex/eit_reproduction/comsol_feedback/fem.py'),Path('E:/Codex/eit_reproduction/comsol_feedback_loop/model.py'),
            VENDOR/'model.py',VENDOR/'preprocess.py',VENDOR/'eit_complex_calibration.py']
    result=dict(status='PASS',scope='Implementation QA only; no training/effectiveness claim',
                champion_full_output_exact=True,champion_parameters=21038925,
                default_policy=StopPolicy().as_dict(),policy_tests=policy_tests,
                zero_head_baseline_trace=baseline_trace,controlled_mixed_batch_trace=mixed_trace,
                controlled_mixed_batch_solves=8,joint_gradient_l1=gradient,disposable_optimizer_step=True,
                seconds=time.monotonic()-tick,test_read=False,formal_training_started=False,
                source_hashes={str(p):sha(p) for p in source},weights_sha256=sha(DEFAULT_WEIGHTS),
                physics_report_sha256=sha(ROOT/'physics.json'),
                limitation='Stopping thresholds are engineering defaults, not validation-selected optimum; zero-head stopping is not learned convergence')
    (ROOT/'architecture.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    np.savez_compressed(ROOT/'raw_train.npz',voltage=b['observed'][0].numpy(),background_voltage=b['background'][0].numpy(),group=b['background_group'][0].numpy())
    print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)

if __name__=='__main__':main()
