"""Final-dataset adapter with explicit physics protocol checks, train/val only."""
import json
import numpy as np
from eit_champion_loop_v2.data import ChampionDataset
from comsol_v4.data_v6 import row_case_path


def validate_parameters(p):
    exact={'grid_size':64,'ne':32,'freq1':10000,'freq2':50000,'drive_count':32}
    for key,value in exact.items():
        if int(p[key])!=value:raise ValueError('Incompatible acquisition: '+key)
    for key,value in [('R',.05),('i0_ma',.25),('th0_deg',0.)]:
        if not np.isclose(float(p[key]),value,rtol=0,atol=1e-10):raise ValueError('Incompatible '+key)
    if p['drive_mode']!='adjacent' or p['adjacent_return']!='next':raise ValueError('Wrong current protocol')
    for key,value in [('elec_angles_deg',np.arange(32)*11.25),('jit_deg',np.zeros(32)),('w_deg',np.full(32,5.))]:
        a=np.fromstring(p[key],sep=' ')
        if a.shape!=(32,) or not np.allclose(a,value,atol=1e-7,rtol=0):raise ValueError('Incompatible electrodes: '+key)
    if p['background_material'] not in ('Fat','Muscle'):raise ValueError('Uncalibrated background')


class StrictChampionDataset(ChampionDataset):
    def __init__(self,root,split,normalizer,solver,limit=0,with_labels=True):
        if solver.info.get('unmapped_pixels')!=0 or solver.info.get('coverage_pixels')!=3096:
            raise ValueError('FEM must cover every valid pixel')
        super().__init__(root,split,normalizer,solver,limit,with_labels)
        for row in self.rows:
            path=row_case_path(root,row)
            with np.load(path,allow_pickle=False) as z:
                p=json.loads(z['parameters_json'].item()) if 'parameters_json' in z else None
            if p is None:p=json.loads((path.parent/'case_parameters.json').read_text(encoding='utf-8'))
            validate_parameters(p)
