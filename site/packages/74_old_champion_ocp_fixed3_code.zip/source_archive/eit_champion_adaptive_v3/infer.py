"""Measurement-only full-Champion inference with actual per-case stopping."""
import argparse,json,sys
from pathlib import Path
import numpy as np
import torch
sys.path.insert(0,'E:/Codex')
from eit_champion_adaptive_v3.model import AdaptiveChampion
from eit_champion_adaptive_v3.policy import StopPolicy
from eit_champion_adaptive_v3.fem import PixelConformingFEM,EPS0
from eit_champion_loop_v2.model import vendor_preprocess
from common import DATA,NORMALIZER
from comsol_v4.data_v6 import Normalizer,grid_arrays
from comsol_v4.features import calibrated_features

def canonical_voltage(v):
    v=np.asarray(v)
    if v.shape!=(2,32,32) or not np.iscomplexobj(v) or not np.isfinite(v).all():
        raise ValueError('Expected finite complex voltage [frequency,drive,measure]=[2,32,32]')
    return v-v[:,np.arange(32),(np.arange(32)+1)%32][:,:,None]

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',required=True);ap.add_argument('--output',required=True)
    ap.add_argument('--checkpoint');ap.add_argument('--policy-json');ap.add_argument('--device',choices=['cpu','cuda'],default='cpu')
    a=ap.parse_args();torch.set_num_threads(2);destination=Path(a.output)
    if destination.exists():raise FileExistsError('Choose a new output; previous predictions are preserved')
    ck=torch.load(a.checkpoint,map_location='cpu',weights_only=True) if a.checkpoint else None
    supplied=json.loads(Path(a.policy_json).read_text()) if a.policy_json else None
    policy=StopPolicy(**(supplied if supplied is not None else ck['policy'] if ck else {}))
    if ck and ck['policy']!=policy.as_dict():raise ValueError('Checkpoint policy mismatch; no silent evaluation change')
    with np.load(a.input,allow_pickle=False) as z:
        v=canonical_voltage(z['voltage']);b=canonical_voltage(z['background_voltage'])
        group=z['group'].item()
        if isinstance(group,(bool,np.bool_)) or group not in (0,1):raise ValueError('Known Fat=0 / Muscle=1 background required')
        g=int(group)
        if 'frequencies_hz' in z and not np.array_equal(z['frequencies_hz'],[10000,50000]):raise ValueError('Wrong frequencies')
    x,y,fov=grid_arrays(DATA);solver=PixelConformingFEM(x,y,fov)
    if ck and ck['mesh_sha256']!=solver.info['mesh_sha256']:raise ValueError('Checkpoint mesh mismatch')
    model=AdaptiveChampion(solver,policy=policy).to(a.device)
    try:
        if ck:model.load_state_dict(ck['model'],strict=True)
        model.eval();cx,dv,g=vendor_preprocess.prepare(v,b,g)
        norm=Normalizer.load(NORMALIZER,DATA);norm.validate_training_contract(DATA,'calibrated')
        feature=norm(calibrated_features(v,b))
        bg=model.initial.background[g].detach().cpu().numpy()
        gamma=bg[:2]+1j*2*np.pi*np.array([10000,50000])*EPS0*bg[2:]
        reference=np.stack([solver.solve(np.full((64,64),c))[0] for c in gamma])
        arrays=[feature,v,b,reference,cx,dv,np.array(g,dtype=np.int64)]
        with torch.no_grad():out=model(*[torch.from_numpy(z)[None].to(a.device) for z in arrays])
        result={k:out[k][0].cpu().numpy() for k in ('probability','sigma','eps_r')}
        meta=dict(policy=policy.as_dict(),mesh=solver.info,stop=out['stop_trace'][0],
                  checkpoint_loaded=bool(ck),feedback_optimizer_steps=int(ck.get('next_batch',0)) if ck else 0,
                  physical_exact_comsol_match=False,input_axes='frequency,drive,measure',voltage_gauge='injection_return',
                  warning='Without a checkpoint the feedback head is untrained; stopping is not an effectiveness claim')
        result.update(predicted_voltage=canonical_voltage(out['predicted_voltage'][0].cpu().numpy()),
                      initial_probability=out['initial']['probability'][0].cpu().numpy(),valid_mask=fov,
                      actual_k=out['actual_k'][0].cpu().numpy(),selected_step=out['selected_step'][0].cpu().numpy(),
                      metadata_json=np.array(json.dumps(meta,ensure_ascii=False)))
        destination.parent.mkdir(parents=True,exist_ok=True);np.savez_compressed(destination,**result)
        print(json.dumps(dict(output=str(destination),**meta),ensure_ascii=False,indent=2))
    finally:model.close()

if __name__=='__main__':main()
