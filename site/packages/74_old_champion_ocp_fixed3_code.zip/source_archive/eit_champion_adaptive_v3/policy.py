"""Measurement/state-only deterministic per-case stopping; no learned head."""
from dataclasses import dataclass,asdict
import math

@dataclass(frozen=True)
class StopPolicy:
    min_steps:int=2
    max_steps:int=6
    patience:int=2
    residual_relative_tolerance:float=1e-3
    probability_max_tolerance:float=1e-3
    log_material_max_tolerance:float=1e-3
    deterioration_relative:float=.05
    deterioration_patience:int=2
    def __post_init__(self):
        for name in ('min_steps','max_steps','patience','deterioration_patience'):
            v=getattr(self,name)
            if type(v) is not int or v<1:raise ValueError(name+' must be a positive integer')
        if self.min_steps>self.max_steps:raise ValueError('min_steps > max_steps')
        for name in ('residual_relative_tolerance','probability_max_tolerance','log_material_max_tolerance','deterioration_relative'):
            v=getattr(self,name)
            if not math.isfinite(v) or v<0:raise ValueError('Invalid tolerance '+name)
    def as_dict(self):return asdict(self)

class StopTracker:
    def __init__(self,policy,initial_error):
        self.p=policy;self.previous=initial_error;self.best=initial_error;self.best_step=0
        self.stable=0;self.worse=0
        if not math.isfinite(initial_error) or initial_error<0:raise FloatingPointError('Invalid initial residual')
    def update(self,step,error,delta_probability,delta_material):
        if not all(math.isfinite(x) and x>=0 for x in (error,delta_probability,delta_material)):
            raise FloatingPointError('Nonfinite feedback state; do not silently label convergence')
        relative=abs(error-self.previous)/max(abs(self.previous),1e-12)
        stable=relative<=self.p.residual_relative_tolerance and delta_probability<=self.p.probability_max_tolerance and delta_material<=self.p.log_material_max_tolerance
        self.stable=self.stable+1 if stable else 0
        self.worse=self.worse+1 if error>self.best*(1+self.p.deterioration_relative)+1e-12 else 0
        if error<self.best:self.best=error;self.best_step=step
        self.previous=error
        reason=None;selected=step
        if step>=self.p.min_steps:
            if self.worse>=self.p.deterioration_patience:
                reason='residual_deterioration';selected=self.best_step
            elif self.stable>=self.p.patience:reason='joint_stability'
        if reason is None and step>=self.p.max_steps:reason='max_steps'
        return dict(stop=reason is not None,reason=reason,selected_step=selected,step=step,
                    residual=error,residual_relative_change=relative,
                    delta_probability_max=delta_probability,delta_log_material_max=delta_material,
                    stable_count=self.stable,deterioration_count=self.worse)
