"""Explicitly launched, one-epoch full-data joint fine-tuning. No test path."""
import argparse
import hashlib
from collections import Counter
import json
import os
import time
import sys
from pathlib import Path
import torch
from torch.utils.data import DataLoader
sys.path.insert(0,'E:/Codex')
from eit_champion_adaptive_v3.model import DEFAULT_WEIGHTS, AdaptiveChampion, model_inputs, objective
from eit_champion_adaptive_v3.policy import StopPolicy
from eit_champion_adaptive_v3.fem import PixelConformingFEM
from eit_champion_adaptive_v3.data import StrictChampionDataset
from common import DATA, NORMALIZER
from comsol_v4.data_v6 import Normalizer, grid_arrays, signature, FINAL_SIGNATURE, file_hash
from comsol_feedback_loop.io import save_checkpoint, write_json


def protocol(policy):
    qa=json.loads(Path('E:/Codex/champion_adaptive_v3/qa/architecture.json').read_text(encoding='utf-8'))
    assert qa['status']=='PASS'
    for name,h in qa['source_hashes'].items():
        assert file_hash(Path(name))==h,name
    assert file_hash(DEFAULT_WEIGHTS)==qa['weights_sha256']
    assert signature(DATA)==FINAL_SIGNATURE
    physics=json.loads(Path('E:/Codex/champion_adaptive_v3/qa/physics.json').read_text())
    assert file_hash(Path('E:/Codex/champion_adaptive_v3/qa/physics.json'))==qa['physics_report_sha256']
    return dict(version='full-champion-adaptive-v3',policy=policy.as_dict(),mesh_sha256=physics['numerical'][0]['solver']['mesh_sha256'],seed=20261024,epochs=1,batch_size=2,
                dataset_signature=signature(DATA),splits=dict(train=3400,val=720,test=720),
                test_read=False,lr_initial=1e-5,lr_feedback=1e-4,weight_decay=1e-4,
                parent=str(DEFAULT_WEIGHTS),parent_sha256=qa['weights_sha256'],
                source_hashes=qa['source_hashes'],normalizer_sha256=file_hash(NORMALIZER),
                selection='minimum full-val generic loss; epoch0 eligible',
                budget_seconds=21600,no_automatic_extension=True,
                architecture='entire packaged Champion -> shared feedback with per-case dynamic stopping',
                physical_exact_comsol_match=False,refinement=0,
                loss='G_selected + .2 mean(G_all_states_including_initial) + .1 mean(E_postupdate)',
                limitations=['single seed, one epoch, not convergence','package weights have historical test exposure',
                             'background group known','post-initial feedback remains free-field','stopping thresholds are unvalidated engineering defaults','full pixel coverage is not exact COMSOL voltage equivalence'])


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--policy-json',help='JSON object containing StopPolicy fields')
    ap.add_argument('--run',action='store_true',help='Without this flag only validate/print the protocol')
    ap.add_argument('--device',choices=['cpu','cuda'],default='cuda');args=ap.parse_args()
    policy=StopPolicy(**(json.loads(Path(args.policy_json).read_text()) if args.policy_json else {}))
    p=protocol(policy)
    if not args.run:
        print(json.dumps(p,ensure_ascii=False,indent=2));return
    policy_id=hashlib.sha256(json.dumps(policy.as_dict(),sort_keys=True).encode()).hexdigest()[:12]
    root=Path('E:/Codex/champion_adaptive_v3/runs')/('adaptive_'+policy_id)
    root.mkdir(parents=True,exist_ok=True)
    import msvcrt
    with (root/'worker.lock').open('a+b') as lock:
        if lock.tell()==0:lock.write(b'0');lock.flush()
        lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        if (root/'complete.json').exists():print('Already complete');return
        pp=root/'protocol.json'
        if pp.exists():assert json.loads(pp.read_text())==p,'Use a new version directory'
        else:write_json(pp,p)
        ph=file_hash(pp);start=time.monotonic()
        def status(phase,**kw):
            obj=dict(phase=phase,policy=policy.as_dict(),updated_unix=time.time(),pid=os.getpid(),test_read=False,**kw)
            write_json(root/'status.json',obj);print(json.dumps(obj),flush=True)
        torch.set_num_threads(2);torch.manual_seed(p['seed'])
        x,y,fov=grid_arrays(DATA);solver=PixelConformingFEM(x,y,fov,refinement=p['refinement'])
        assert solver.info['mesh_sha256']==p['mesh_sha256']
        norm=Normalizer.load(NORMALIZER,DATA);norm.validate_training_contract(DATA,'calibrated')
        status('loading_data')
        data={s:StrictChampionDataset(DATA,s,norm,solver) for s in ('train','val')}
        assert len(data['train'])==3400 and len(data['val'])==720
        model=AdaptiveChampion(solver,policy=policy).to(args.device)
        opt=torch.optim.AdamW([dict(params=model.initial.parameters(),lr=p['lr_initial']),
                               dict(params=model.feedback.parameters(),lr=p['lr_feedback'])],weight_decay=p['weight_decay'])
        def move(raw):return {k:v.to(args.device) if torch.is_tensor(v) else v for k,v in raw.items()}
        def validate(tag):
            model.eval();total=0.;n=0;rows=[];tick=time.monotonic()
            for raw in DataLoader(data['val'],batch_size=1,num_workers=0):
                if time.monotonic()-start>p['budget_seconds']:
                    status('budget_stopped',tag=tag,processed=n,total=720)
                    write_json(root/(tag+'_partial.json'),dict(cases=rows,complete=False))
                    model.close();raise SystemExit('Bounded budget reached during validation; partial rows saved')
                b=move(raw)
                with torch.no_grad():
                    out=model(*model_inputs(b));_,generic,physical=objective(out,b,model.fov)
                pred=out['probability']>=.5;truth=b['mask']>=.5
                iou=float((pred&truth).sum()/((pred|truth).sum().clamp_min(1)))
                rows.append(dict(case_id=raw['case_id'][0],iou=iou,generic=float(generic),physical=float(physical),stop=out['stop_trace'][0]))
                total+=float(generic);n+=1
                if n%10==0 or n==720:
                    spc=(time.monotonic()-tick)/n
                    status('validation',tag=tag,processed=n,total=720,seconds_per_case=spc,phase_remaining_seconds=(720-n)*spc)
            result=dict(tag=tag,score=total/n,cases=rows,
                        actual_k_counts=dict(Counter(r['stop']['executed_steps'] for r in rows)),
                        stop_reason_counts=dict(Counter(r['stop']['reason'] for r in rows)))
            write_json(root/(tag+'.json'),result);return result['score']
        next_batch=0;trained=False;best=float('inf');best_epoch=0
        def checkpoint():
            return dict(model=model.state_dict(),optimizer=opt.state_dict(),next_batch=next_batch,
                        trained=trained,best=best,best_epoch=best_epoch,policy=policy.as_dict(),mesh_sha256=p['mesh_sha256'],protocol_sha256=ph,
                        rng=torch.get_rng_state(),cuda_rng=torch.cuda.get_rng_state_all() if torch.cuda.is_available() else [])
        if (root/'last.pt').exists():
            ck=torch.load(root/'last.pt',map_location='cpu',weights_only=True)
            assert ck['protocol_sha256']==ph and ck['policy']==policy.as_dict() and ck['mesh_sha256']==p['mesh_sha256']
            model.load_state_dict(ck['model']);opt.load_state_dict(ck['optimizer'])
            next_batch=ck['next_batch'];trained=ck['trained'];best=ck['best'];best_epoch=ck['best_epoch']
            torch.set_rng_state(ck['rng'])
            if ck['cuda_rng']:torch.cuda.set_rng_state_all(ck['cuda_rng'])
            del ck
        else:
            best=validate('epoch0');save_checkpoint(root/'best.pt',checkpoint());save_checkpoint(root/'last.pt',checkpoint())
        if not trained:
            model.train();generator=torch.Generator().manual_seed(p['seed']+1000003)
            loader=DataLoader(data['train'],batch_size=p['batch_size'],shuffle=True,generator=generator,num_workers=0)
            for index,raw in enumerate(loader):
                if index<next_batch:continue
                b=move(raw);out=model(*model_inputs(b));loss,_,_=objective(out,b,model.fov)
                if not torch.isfinite(loss):raise FloatingPointError('Nonfinite loss')
                opt.zero_grad(set_to_none=True);loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True);opt.step()
                next_batch=index+1
                with (root/'training_trace.jsonl').open('a',encoding='utf-8') as log:
                    log.write(json.dumps(dict(batch=next_batch,case_ids=raw['case_id'],loss=float(loss.detach()),stop=out['stop_trace']))+'\n')
                if next_batch%10==0:status('training',epoch=1,processed=min(next_batch*2,3400),total=3400,loss=float(loss.detach()))
                if next_batch%50==0:save_checkpoint(root/'last.pt',checkpoint())
                del b,out,loss
                if time.monotonic()-start>p['budget_seconds']:
                    save_checkpoint(root/'last.pt',checkpoint());status('budget_stopped');model.close();return
            trained=True;save_checkpoint(root/'last.pt',checkpoint())
        score=validate('epoch1')
        if score<best:best=score;best_epoch=1;save_checkpoint(root/'best.pt',checkpoint())
        save_checkpoint(root/'last.pt',checkpoint())
        for name,h in p['source_hashes'].items():assert file_hash(Path(name))==h,name
        write_json(root/'complete.json',dict(status='computed_pending_scientific_review',selected_epoch=best_epoch,
                   best_score=best,epochs=1,policy=policy.as_dict(),mesh_sha256=p['mesh_sha256'],test_read=False,convergence_claim=False))
        status('computed_pending_scientific_review');model.close()

if __name__=='__main__':main()


