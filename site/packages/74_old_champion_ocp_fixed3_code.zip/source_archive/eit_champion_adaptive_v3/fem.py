"""Pixel-Voronoi-conforming complex P1 FEM, not the original COMSOL mesh.

Every valid raster sample owns its clipped Voronoi cell. Fan triangulation
integrates its piecewise-constant material over the WHOLE cell, including disk
boundary extension. Refinement never crosses material-cell boundaries.
"""
import sys
import hashlib
import numpy as np
from scipy.spatial import cKDTree
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from shapely.geometry import MultiPoint, Polygon, box
from shapely.ops import voronoi_diagram
sys.path.insert(0,'E:/Codex/eit_reproduction')
from comsol_feedback.fem import TerminalFEM, EPS0, forward_voltage


class PixelConformingFEM(TerminalFEM):
    def __init__(self,x,y,fov,refinement=0,boundary_points=512):
        self.x=np.asarray(x,dtype=float);self.y=np.asarray(y,dtype=float);self.fov=np.asarray(fov,dtype=bool)
        if self.x.shape!=(64,) or self.y.shape!=(64,) or self.fov.shape!=(64,64):
            raise ValueError('Only the final 64x64 grid is supported')
        if type(refinement) is not int or not 0<=refinement<=2:raise ValueError('refinement must be 0,1,2')
        if not np.allclose(self.x,np.linspace(-.05,.05,64),atol=2e-9,rtol=0) or not np.allclose(self.y,self.x,atol=2e-9,rtol=0):
            raise ValueError('Wrong coordinate units, extent, or ordering')
        gx,gy=np.meshgrid(self.x,self.y)
        if not np.array_equal(self.fov,gx*gx+gy*gy<=.05**2):raise ValueError('Unexpected circular FOV')
        valid=np.flatnonzero(self.fov.ravel());centers=np.c_[gx[self.fov],gy[self.fov]]
        angles_e=np.arange(32)*2*np.pi/32
        angles=np.unique(np.round(np.r_[np.arange(boundary_points)*2*np.pi/boundary_points,
                    (angles_e-np.deg2rad(2.5))%(2*np.pi),(angles_e+np.deg2rad(2.5))%(2*np.pi)],12))
        domain=Polygon(.05*np.c_[np.cos(angles),np.sin(angles)])
        cells=voronoi_diagram(MultiPoint(centers),envelope=box(-.1,-.1,.1,.1),tolerance=0,edges=False)
        tree=cKDTree(centers);points=[];lookup={};triangles=[];pixels=[];cell_area=np.zeros(4096);seen=set()
        def vertex(p):
            key=tuple(np.round(p,12))
            if key not in lookup:lookup[key]=len(points);points.append(key)
            return lookup[key]
        for cell in cells.geoms:
            q=cell.representative_point();owner=int(tree.query([q.x,q.y])[1]);pix=int(valid[owner])
            if owner in seen:raise RuntimeError('Duplicate Voronoi owner')
            seen.add(owner);clipped=cell.intersection(domain)
            if clipped.geom_type!='Polygon' or not clipped.is_valid or clipped.area<=0:raise RuntimeError('Invalid material cell')
            cell_area[pix]=clipped.area;c=vertex(centers[owner]);boundary=list(clipped.exterior.coords)[:-1]
            ids=[vertex(v) for v in boundary]
            for a,b in zip(ids,ids[1:]+ids[:1]):
                if len({c,a,b})!=3:continue
                triangles.append((c,a,b));pixels.append(pix)
        if len(seen)!=len(valid):raise RuntimeError('Not every pixel owns a cell')
        xy=np.asarray(points);tri=np.asarray(triangles,dtype=np.int64);pixel=np.asarray(pixels,dtype=np.int64)
        for _ in range(refinement):
            edges=np.sort(np.concatenate((tri[:,[0,1]],tri[:,[1,2]],tri[:,[2,0]])),axis=1)
            unique,inverse=np.unique(edges,axis=0,return_inverse=True)
            midpoint=len(xy)+inverse.reshape(3,-1).T
            xy=np.vstack((xy,xy[unique].mean(1)))
            a,b,c=tri.T;ab,bc,ca=midpoint.T
            tri=np.stack((np.c_[a,ab,ca],np.c_[ab,b,bc],np.c_[ca,bc,c],np.c_[ab,bc,ca]),axis=1).reshape(-1,3)
            pixel=np.repeat(pixel,4)
        edge_all=np.sort(np.concatenate((tri[:,[0,1]],tri[:,[1,2]],tri[:,[2,0]])),axis=1)
        edges,incidence=np.unique(edge_all,axis=0,return_counts=True)
        if np.any(incidence>2):raise RuntimeError('Nonmanifold mesh')
        exterior=edges[incidence==1];boundary_nodes=np.unique(exterior)
        if not np.all(np.bincount(exterior.ravel(),minlength=len(xy))[boundary_nodes]==2):raise RuntimeError('Broken exterior')
        graph=coo_matrix((np.ones(len(edges)*2),(np.r_[edges[:,0],edges[:,1]],np.r_[edges[:,1],edges[:,0]])),shape=(len(xy),len(xy))).tocsr()
        if connected_components(graph)[0]!=1 or len(xy)-len(edges)+len(tri)!=1:raise RuntimeError('Mesh has holes/disconnected components')
        if np.min(np.linalg.norm(xy[boundary_nodes],axis=1)) < .05*np.cos(np.pi/boundary_points)-1e-9:
            raise RuntimeError('Unpaired interior edges')
        coords=xy[tri];a=coords[:,1]-coords[:,0];b=coords[:,2]-coords[:,0]
        det=a[:,0]*b[:,1]-a[:,1]*b[:,0];area=np.abs(det)/2
        if np.any(area<=1e-19):raise RuntimeError('Degenerate element')
        gradient=np.stack((np.c_[coords[:,1,1]-coords[:,2,1],coords[:,2,0]-coords[:,1,0]],
                           np.c_[coords[:,2,1]-coords[:,0,1],coords[:,0,0]-coords[:,2,0]],
                           np.c_[coords[:,0,1]-coords[:,1,1],coords[:,1,0]-coords[:,0,0]]),1)/det[:,None,None]
        self.element=area[:,None,None]*np.einsum('tik,tjk->tij',gradient,gradient)
        mapping=np.arange(len(xy));electrode_nodes=[];theta=np.arctan2(xy[boundary_nodes,1],xy[boundary_nodes,0])
        for center in angles_e:
            dist=np.abs((theta-center+np.pi)%(2*np.pi)-np.pi)
            ids=boundary_nodes[dist<=np.deg2rad(2.5)+1e-9]
            if len(ids)<2:raise RuntimeError('Unresolved electrode')
            mapping[ids]=ids[0];electrode_nodes.append(ids[0])
        _,mapping=np.unique(mapping,return_inverse=True);el=mapping[electrode_nodes]
        free=np.arange(mapping.max()+1)!=el[-1];reindex=np.full(len(free),-1);reindex[free]=np.arange(free.sum())
        self.tri=reindex[mapping[tri]];self.electrodes=reindex[el];self.n=int(free.sum())
        rr=np.broadcast_to(self.tri[:,:,None],self.element.shape).ravel();cc=np.broadcast_to(self.tri[:,None,:],self.element.shape).ravel()
        self.keep=(rr>=0)&(cc>=0);self.rows,self.cols=rr[self.keep],cc[self.keep]
        self.rhs=np.zeros((self.n,32),complex)
        for d in range(32):
            for e,sign in ((d,1),((d+1)%32,-1)):
                if self.electrodes[e]>=0:self.rhs[self.electrodes[e],d]+=sign*.00025
        self.pixel=pixel;self.xy=xy;self.raw_tri=tri;self.area=area
        self.pixel_area=np.bincount(pixel,weights=area,minlength=4096).reshape(64,64)
        self.count=np.bincount(pixel,minlength=4096).reshape(64,64)
        if not np.all(self.pixel_area[self.fov]>0) or np.any(self.count[~self.fov]):raise RuntimeError('Coverage failure')
        areaerr=float(np.max(np.abs(self.pixel_area.ravel()-cell_area)))
        if areaerr>1e-12 or abs(area.sum()-domain.area)>1e-11:raise RuntimeError('Material-area inconsistency')
        self.info=dict(kind='pixel_Voronoi_conforming_P1_FEM',refinement=refinement,nodes=len(xy),triangles=len(tri),
            free_unknowns=self.n,radius_m=.05,depth_m=1.,current_A=.00025,electrodes=32,arc_width_deg=5.,
            coverage_pixels=int((self.count>0).sum()),valid_pixels=int(self.fov.sum()),unmapped_pixels=0,
            mapping='whole clipped pixel Voronoi cell; piecewise-constant material; no centroid resampling',
            boundary_extension='nearest valid pixel Voronoi cells clipped to polygonal disk',
            material_cell_area_max_error=areaerr,domain_area_m2=float(area.sum()),
            disk_polygon_area_relative_error=float(abs(area.sum()-np.pi*.05**2)/(np.pi*.05**2)),
            contact_impedance_effective=0.,voltage_gauge='last_electrode',
            mesh_sha256=hashlib.sha256(xy.tobytes()+tri.tobytes()+pixel.tobytes()).hexdigest(),
            limitation='Exact raster coverage is not exact original curved COMSOL geometry or voltage equivalence')

    def solve(self,gamma):
        if np.asarray(gamma).shape!=(64,64):raise ValueError('Expected material[y,x] with shape 64x64')
        return super().solve(gamma)
