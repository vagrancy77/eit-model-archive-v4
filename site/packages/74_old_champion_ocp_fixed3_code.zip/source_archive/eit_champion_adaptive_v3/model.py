"""Entire Champion + truly per-case adaptive feedback, during train and infer."""
import sys
import torch
sys.path.insert(0,'E:/Codex')
from eit_champion_loop_v2.model import ChampionLoop,DEFAULT_WEIGHTS,model_inputs
from eit_champion_adaptive_v3.policy import StopPolicy,StopTracker
from models import objective as generic_objective


class AdaptiveChampion(ChampionLoop):
    def __init__(self,solver,weights=DEFAULT_WEIGHTS,policy=None):
        self.policy=policy or StopPolicy()
        super().__init__(solver,weights,K=self.policy.max_steps)
        del self.K  # There is no fixed run-wide reconstruction K anymore.

    def forward(self,features,observed,background,reference,voltage,dv,groups):
        if features.shape[1:]!=(12,32,32):raise ValueError('Expected feedback X12')
        initial,champion=self.initial_state(voltage,dv,groups)
        final=[];traces=[];final_voltage=[];trajectories=[]
        for i in range(len(features)):
            state={k:v[i:i+1] for k,v in initial.items()};states=[state]
            args=[v[i:i+1] for v in (observed,background,reference)]
            physical=self.physics(state,*args);physicals=[physical]
            tracker=StopTracker(self.policy,float(physical['voltage_mse'].detach().mean()))
            trace=[]
            for step in range(1,self.policy.max_steps+1):
                candidate=self.feedback(state,features[i:i+1],physical['residual'],physical['hint'])
                new_physical=self.physics(candidate,*args)
                with torch.no_grad():
                    mask=self.fov.bool().expand_as(state['probability'])
                    dp=float((candidate['probability']-state['probability']).abs()[mask].max())
                    mm=self.fov.bool().expand_as(state['log_material'])
                    dm=float((candidate['log_material']-state['log_material']).abs()[mm].max())
                    decision=tracker.update(step,float(new_physical['voltage_mse'].mean()),dp,dm)
                states.append(candidate);physicals.append(new_physical);trace.append(decision)
                state=candidate;physical=new_physical
                if decision['stop']:break  # No padded FEM calls after this case stops.
            chosen=decision['selected_step']
            final.append(states[chosen]);final_voltage.append(physicals[chosen]['voltage'])
            traces.append(dict(executed_steps=step,selected_step=chosen,reason=decision['reason'],
                               dual_frequency_solves=step+1,history=trace))
            trajectories.append(dict(states=states,errors=[v['voltage_mse'] for v in physicals],selected_step=chosen))
        return {**{k:torch.cat([s[k] for s in final]) for k in final[0]},
                'initial':initial,'champion':champion,'predicted_voltage':torch.cat(final_voltage),
                'actual_k':torch.tensor([t['executed_steps'] for t in traces],device=features.device),
                'selected_step':torch.tensor([t['selected_step'] for t in traces],device=features.device),
                'stop_trace':traces,'trajectories':trajectories}


def objective(out,target,fov):
    totals=[];finals=[];physics=[]
    for i,trajectory in enumerate(out['trajectories']):
        label=dict(mask=target['mask'][i:i+1],log_material=torch.cat((target['sigma'][i:i+1],target['eps_r'][i:i+1]),1).clamp_min(1e-8).log())
        losses=[generic_objective(s,label,fov,False)[0] for s in trajectory['states']]
        final=losses[trajectory['selected_step']]
        physical=torch.stack([e.mean() for e in trajectory['errors'][1:]]).mean()
        # Supervise all executed candidates, including a rejected candidate, so
        # rollback cannot erase geometry-learning gradients to the feedback head.
        totals.append(final+.2*torch.stack(losses).mean()+.1*physical)
        finals.append(final);physics.append(physical)
    return torch.stack(totals).mean(),torch.stack(finals).mean(),torch.stack(physics).mean()
