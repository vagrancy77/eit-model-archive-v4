"""Full, byte-unmodified packaged Champion followed by mandatory FEM feedback.

The old projection initializer is NOT instantiated. The existing feedback and
loss implementations are reused unchanged; only the initialization interface
changes. Vendor forward tensors are retained under ``champion`` for auditing.
"""
from pathlib import Path
import importlib.util
import sys
import torch
from torch import nn

HERE = Path(__file__).resolve().parent
VENDOR = HERE/'vendor/EIT_C4_Champion_20261020'
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, 'E:/Codex/eit_reproduction')
from eit_final_c4_loop.model import FieldFeedback, objective
from comsol_feedback_loop.model import DynamicPhysics


def load_vendor(name, path):
    if name in sys.modules:
        module = sys.modules[name]
        if Path(module.__file__).resolve() != path.resolve():
            raise RuntimeError('Conflicting vendor import: '+name)
        return module
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


vendor_model = load_vendor('champion_exact_vendor', VENDOR/'model.py')
load_vendor('eit_complex_calibration', VENDOR/'eit_complex_calibration.py')
vendor_preprocess = load_vendor('champion_exact_preprocess', VENDOR/'preprocess.py')
DEFAULT_WEIGHTS = VENDOR/'weights/seed_20260911_epoch_6.pt'


class ChampionLoop(nn.Module):
    def __init__(self, solver, weights=DEFAULT_WEIGHTS, K=3):
        super().__init__()
        if isinstance(K, bool) or not isinstance(K, int) or K < 1:
            raise ValueError('K must be a positive integer; feedback is mandatory')
        self.K = K
        self.initial, self.weight_metadata = vendor_model.load_model(weights, 'cpu')
        self.register_buffer('fov', self.initial.fov.clone())
        expected = torch.as_tensor(solver.fov, dtype=self.fov.dtype)[None, None]
        if not torch.equal(self.fov.cpu(), expected):
            raise ValueError('Champion/FEM spatial support differs; do not silently resize')
        self.feedback = FieldFeedback(solver.fov)
        self.physics = DynamicPhysics(solver)

    def initial_state(self, voltage, dv, groups):
        if voltage.shape[1:] != (8, 32, 32) or dv.shape[1:] != (2, 2048):
            raise ValueError('Use the archived 8-channel preprocessing, not legacy 12 channels')
        if groups.dtype != torch.long or not torch.all((groups == 0) | (groups == 1)):
            raise ValueError('Known background group required: Fat=0, Muscle=1')
        out = self.initial(voltage, dv, groups)
        # Exactly the absolute-field conversion used in the packaged infer.py.
        bg = self.initial.background[groups, :, None, None]
        scale = out['fields'].new_tensor([.2, .2, 50000., 50000.])[None, :, None, None]
        absolute = bg + out['fields']*scale
        if not torch.isfinite(absolute).all() or not (absolute > 0).all():
            raise ValueError('Nonpositive/nonfinite absolute material: incompatible input/weights')
        # No sigmoid inversion, no mask-based remix and no detached tensors.
        state = dict(logits=out['geometry_logit'], probability=out['foreground'],
                     log_material=absolute.log(), sigma=absolute[:, :2], eps_r=absolute[:, 2:])
        return state, out

    def forward(self, features, observed, background, reference, voltage, dv, groups):
        if features.shape[1:] != (12, 32, 32):
            raise ValueError('The unchanged feedback lift requires legacy 12-channel measurements')
        initial, champion = self.initial_state(voltage, dv, groups)
        state = initial; stages = []; residuals = []
        for _ in range(self.K):
            physical = self.physics(state, observed, background, reference)
            residuals.append(physical['voltage_mse'])
            state = self.feedback(state, features, physical['residual'], physical['hint'])
            stages.append(state)
        final = self.physics(state, observed, background, reference, hints=False)
        residuals.append(final['voltage_mse'])
        return {**state, 'initial': initial, 'champion': champion, 'stages': stages,
                'voltage_mse_by_round': torch.stack(residuals, 1),
                'predicted_voltage': final['voltage']}

    def close(self):
        self.initial.close()


def model_inputs(batch):
    return [batch[k] for k in ('features', 'observed', 'background', 'reference',
                               'champion_voltage', 'champion_dv', 'background_group')]
