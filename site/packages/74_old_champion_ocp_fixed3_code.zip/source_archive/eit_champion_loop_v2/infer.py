"""Raw-measurement inference with the entire Champion + mandatory K loop."""
import argparse
import json
import sys
from pathlib import Path
import numpy as np
import torch
sys.path.insert(0,'E:/Codex')
from eit_champion_loop_v2.model import ChampionLoop, vendor_preprocess
from common import DATA, NORMALIZER
from comsol_v4.data_v6 import Normalizer, grid_arrays
from comsol_v4.features import calibrated_features
from comsol_feedback.fem import TerminalFEM, EPS0

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',required=True);ap.add_argument('--output',required=True)
    ap.add_argument('--K',type=int,default=3);ap.add_argument('--checkpoint');ap.add_argument('--device',default='cpu')
    a=ap.parse_args();torch.set_num_threads(2)
    destination=Path(a.output)
    if destination.exists():raise FileExistsError('Preserve previous predictions: choose a new output')
    with np.load(a.input,allow_pickle=False) as z:
        v=z['voltage'].copy();b=z['background_voltage'].copy()
        g=int(z['group']) if 'group' in z else {'Fat':0,'Muscle':1}[json.loads(z['parameters_json'].item())['background_material']]
    x,y,fov=grid_arrays(DATA);solver=TerminalFEM(x,y,fov,spacing=.0016)
    model=ChampionLoop(solver,K=a.K).to(a.device)
    if a.checkpoint:
        ck=torch.load(a.checkpoint,map_location='cpu',weights_only=True)
        if ck['K']!=a.K:raise ValueError('Checkpoint K mismatch; do not silently change evaluation protocol')
        model.load_state_dict(ck['model'],strict=True)
    model.eval();cx,dv,g=vendor_preprocess.prepare(v,b,g)
    feature=Normalizer.load(NORMALIZER,DATA)(calibrated_features(v,b))
    bg=model.initial.background[g].detach().cpu().numpy()
    gamma=bg[:2]+1j*2*np.pi*np.array([10000,50000])*EPS0*bg[2:]
    reference=np.stack([solver.solve(np.full((64,64),c))[0] for c in gamma])
    arrays=[feature,v,b,reference,cx,dv,np.array(g,dtype=np.int64)]
    with torch.no_grad():out=model(*[torch.from_numpy(z)[None].to(a.device) for z in arrays])
    result={k:out[k][0].cpu().numpy() for k in ('probability','sigma','eps_r','predicted_voltage','voltage_mse_by_round')}
    result.update(initial_probability=out['initial']['probability'][0].cpu().numpy(),K=np.array(a.K),
                  valid_mask=fov,feedback_trained=np.array(bool(a.checkpoint)))
    np.savez_compressed(destination,**result);model.close()
    print(json.dumps(dict(output=str(destination),K=a.K,feedback_trained=bool(a.checkpoint))))

if __name__=='__main__':main()
