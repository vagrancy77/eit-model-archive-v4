"""Bounded TRAIN-only integration QA; never starts formal training."""
import hashlib
import json
import time
import zipfile
from pathlib import Path
import sys
import numpy as np
import torch
from torch.utils.data import default_collate
sys.path.insert(0, 'E:/Codex')
from eit_champion_loop_v2.model import HERE, VENDOR, DEFAULT_WEIGHTS, ChampionLoop, model_inputs, objective, vendor_model
from eit_champion_loop_v2.data import ChampionDataset
from common import DATA, NORMALIZER
from comsol_v4.data_v6 import Normalizer, grid_arrays, signature, FINAL_SIGNATURE
from comsol_feedback.fem import TerminalFEM

ROOT = Path('E:/Codex/champion_loop_v2')

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    ROOT.mkdir(exist_ok=True)
    torch.set_num_threads(2); torch.manual_seed(20261024)
    start = time.monotonic()
    archive = Path('E:/Codex/EIT_C4_Champion_20261020.zip')
    files = []
    with zipfile.ZipFile(archive) as z:
        for info in z.infolist():
            if info.is_dir(): continue
            local = HERE/'vendor'/info.filename
            assert sha(local) == hashlib.sha256(z.read(info)).hexdigest(), str(local)
            files.append(str(local.relative_to(HERE)))
    print('Exact vendor bytes PASS:', len(files), flush=True)
    assert signature(DATA) == FINAL_SIGNATURE
    x, y, fov = grid_arrays(DATA); solver = TerminalFEM(x, y, fov, spacing=.0016)
    norm = Normalizer.load(NORMALIZER, DATA)
    norm.validate_training_contract(DATA, 'calibrated')
    ds = ChampionDataset(DATA, 'train', norm, solver, limit=10)
    selected = {}
    for i in range(len(ds)):
        selected.setdefault(int(ds[i]['background_group']), i)
    assert set(selected) == {0, 1}, 'QA needs both known backgrounds'
    model = ChampionLoop(solver, K=3).eval()  # CPU QA does not compete for training GPU memory.
    ref, _ = vendor_model.load_model(DEFAULT_WEIGHTS, 'cpu')
    state = torch.load(DEFAULT_WEIGHTS, map_location='cpu', weights_only=True)['model']
    assert set(state) == set(model.initial.state_dict())
    assert all(torch.equal(v, model.initial.state_dict()[k]) for k, v in state.items())
    assert sum(p.numel() for p in model.initial.parameters()) == 21038925
    errors = []; batches = []
    for group, index in sorted(selected.items()):
        b = default_collate([ds[index]]); batches.append(b)
        with torch.no_grad():
            expected = ref(b['champion_voltage'], b['champion_dv'], b['background_group'])
            converted, actual = model.initial_state(b['champion_voltage'], b['champion_dv'], b['background_group'])
            for key, value in expected.items():
                if torch.is_tensor(value):
                    assert torch.equal(actual[key], value), key
                else:
                    for nested in value: assert torch.equal(actual[key][nested], value[nested]), nested
            bg = ref.background[b['background_group'], :, None, None]
            absolute = bg + expected['fields']*bg.new_tensor([.2,.2,50000.,50000.])[None,:,None,None]
            assert torch.equal(converted['probability'], expected['foreground'])
            assert torch.equal(converted['sigma'], absolute[:,:2])
            assert torch.equal(converted['eps_r'], absolute[:,2:])
            errors.append(dict(group=group, case_id=b['case_id'][0], maximum_tensor_error=0.0))
    ref.close();del ref,state
    print('Full Champion state + every output parity PASS', errors, flush=True)
    # A nonzero QA-only head exercises every loop. Discarded after QA.
    with torch.no_grad():
        model.feedback.head.bias.copy_(torch.tensor([.005,.001,-.001,.001,-.001]))
    b=batches[0]; model.train()
    # Native dropout remains enabled. These are gradient checks, not parity checks.
    calls=[]; hook=model.feedback.register_forward_hook(lambda m,a,o:calls.append(1))
    before=model.physics.evaluations
    out=model(*model_inputs(b)); loss,_,_=objective(out,b,model.fov)
    assert len(calls)==3 and model.physics.evaluations-before==4
    assert torch.isfinite(loss)
    loss.backward()
    grad={}
    for name,module in [('front',model.initial.member.base.front),
                        ('dual_encoder_decoder',model.initial.member.base.backbone),
                        ('fine_query',model.initial.member.refiner),('feedback',model.feedback)]:
        grads=[p.grad for p in module.parameters() if p.grad is not None]
        assert grads and all(torch.isfinite(g).all() for g in grads),name
        grad[name]=sum(float(g.abs().sum()) for g in grads)
        assert grad[name]>0,name
    hook.remove();del out,loss
    # One disposable optimizer step verifies the joint training path, not just
    # graph connectivity. No QA-modified weights are written or used to train.
    first=next(model.initial.member.base.front.token_embed.parameters())
    before_step=first.detach().clone()
    opt=torch.optim.AdamW(model.parameters(),lr=1e-5)
    opt.step()
    assert not torch.equal(before_step,first.detach())
    del opt,before_step
    model.zero_grad(set_to_none=True)
    out=model(*model_inputs(b));out['voltage_mse_by_round'][:,-1].mean().backward()
    physics_grad={name:sum(float(p.grad.abs().sum()) for p in module.parameters() if p.grad is not None)
                  for name,module in [('champion',model.initial),('feedback',model.feedback)]}
    assert all(v>0 and np.isfinite(v) for v in physics_grad.values())
    del out
    k_checks=[];model.eval()
    for k in (1,2,4):
        model.K=k;before=model.physics.evaluations
        with torch.no_grad(): out=model(*model_inputs(b))
        assert len(out['stages'])==k and model.physics.evaluations-before==k+1
        k_checks.append(dict(K=k,solves=k+1,finite=bool(torch.isfinite(out['sigma']).all())))
        assert k_checks[-1]['finite']
        del out
    for bad in (0,-1,True,1.5):
        try: ChampionLoop(solver,K=bad)
        except ValueError: pass
        else: raise AssertionError('Invalid K accepted')
    model.close()
    # CLI smoke input contains measurements/background metadata only, no labels.
    b=batches[0]
    np.savez_compressed(ROOT/'qa_raw_train.npz',voltage=b['observed'][0].numpy(),
                        background_voltage=b['background'][0].numpy(),
                        group=b['background_group'][0].numpy())
    sources=[*HERE.glob('*.py'),VENDOR/'model.py',VENDOR/'preprocess.py',VENDOR/'eit_complex_calibration.py',
             Path('E:/Codex/eit_final_c4_loop/model.py'),Path('E:/Codex/eit_shape_general/models.py'),
             Path('E:/Codex/eit_reproduction/comsol_feedback_loop/model.py'),
             Path('E:/Codex/eit_reproduction/comsol_feedback/fem.py')]
    result=dict(status='PASS',vendor_files_byte_identical=len(files),full_initial_parameters=21038925,
                exact_all_state_tensors=True,parity=errors,K3_joint_gradients=grad,
                disposable_joint_optimizer_step=True,
                final_physics_gradients=physics_grad,k_interface_checks=k_checks,
                elapsed_seconds=time.monotonic()-start,device='cpu',test_read=False,formal_training_started=False,
                weight_sha256=sha(DEFAULT_WEIGHTS),archive_sha256=sha(archive),
                dataset_signature=signature(DATA),source_hashes={str(p):sha(p) for p in sources},
                limits=['QA only; no accuracy claim','known background group required',
                        'Champion geometry/material coupling retained at initialization; subsequent feedback remains free-field'])
    (ROOT/'acceptance.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)

if __name__=='__main__':main()
