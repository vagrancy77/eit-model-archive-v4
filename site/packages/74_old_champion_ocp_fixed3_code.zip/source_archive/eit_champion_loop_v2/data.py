"""Two measurement encodings, no target shape/class/ROI in model inputs."""
import json
import numpy as np
import torch
from .model import vendor_preprocess
from comsol_feedback_loop.data import LoopDataset
from comsol_v4.data_v6 import row_case_path


class ChampionDataset(LoopDataset):
    def __init__(self, root, split, normalizer, solver, limit=0, with_labels=True):
        if split not in ('train', 'val'):
            raise ValueError('This integration does not authorize a test evaluation')
        super().__init__(root, split, normalizer, solver, limit, with_labels)
        for row, measured in zip(self.rows, self.measurements):
            path = row_case_path(root, row)
            with np.load(path, allow_pickle=False) as z:
                params = json.loads(z['parameters_json'].item()) if 'parameters_json' in z else None
            if params is None:
                params = json.loads((path.parent/'case_parameters.json').read_text(encoding='utf-8'))
            group = {'Fat': 0, 'Muscle': 1}[params['background_material']]
            x, dv, group = vendor_preprocess.prepare(measured['observed'].numpy(),
                                                      measured['background'].numpy(), group)
            measured.update(champion_voltage=torch.from_numpy(x), champion_dv=torch.from_numpy(dv),
                            background_group=torch.tensor(group, dtype=torch.long))
