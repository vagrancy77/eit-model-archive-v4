# 完整 Champion + 必选物理反馈 v2

本版根据 2026-10-24 用户纠正，**完整接入用户 ZIP 内的重建网络**，不再只提取 C4 操作。此前 `eit_final_c4_loop` 保留为历史版本；本目录为新的代码入口。

## 明确的结构替换

旧初始化的固定岭投影、FC 测量上下文、通用场 U-Net **不再执行**。整体替换为包内 `RotationPoolCandidate(CandidateInterface(InferenceBase, FineGeometryQuery))`：

电压注意力前端 → 图像/电压双编码器 → 瓶颈融合和共享解码 → 细尺度几何查询 → 四方向对齐平均 → 原包共同几何 / 区域材料 / 界面宽度读出。

原包的 21,038,925 个参数及全部固定缓冲均严格加载，包含所有前端、细尺度查询和宽度参数。采用包内登记首种子 `seed_20260911_epoch_6.pt`，不是按本地测试结果选种子。其余两份权重也完整保留，当前不是三种子集成。

`vendor/` 中 110 个原包文件逐字节与 ZIP 一致。没有修改原包层定义、前向或预处理。`dv` 按原包处理并传入，原前向未单独使用它也不人为增加用途。

## 与反馈的连接

`ChampionLoop.initial_state` 将原包 `geometry_logit`、`foreground` 原样传给反馈，按原包 infer.py 的尺度从归一化变化恢复绝对电导率与介电常数，再取 log。不会误把包内 `sigma` 字段当成 S/m，也不使用真值掩膜重新构造材料。

后续 `FieldFeedback`、`DynamicPhysics`、通用损失直接复用上版实现，未重新设计。`K` 为正整数参数，默认 3；必选反馈不能关掉，不自动搜索 K。整个 Champion 和反馈可共同训练。旧初始化类虽然在依赖模块定义中存在，**没有实例化或执行**。

需要两套测量编码：Champion 使用包内 8 通道与 dv；保留反馈 Lift 使用既有 12 通道。均来自同一病例电压和背景电压，不是新增第二套重建网络。

## 必须说明的条件

- 原包要求已知背景组 `Fat=0/Muscle=1`，影响背景、灵敏度和宽度；不是病灶类型、形状标签或目标 ROI。不能宣称完全不需要背景信息。
- 原包使用同一个 φ，概率为 sigmoid(-φ/0.75)，材料占据为 sigmoid(-φ/τ)。共享几何不等于二者软边界宽度相同。
- 原包初始化维持均匀背景加单组区域材料表达。**其后保留的自由场反馈不强制维持该表达**；本次没有暗中重写反馈来改变这一点。
- 推理只输入测量与已知背景；真值仅用于训练/评价。包内权重曾做过历史测试；本轮接口验收仅使用 TRAIN，不重新读取测试性能。
- 本次完成的是代码集成与数值/梯度验收，不是完整新模型的准确率验证，不声称解决外凸。

## 入口

环境：`E:/conda-envs/pytorch-gpu/python.exe`。

```powershell
# TRAIN-only 有限接口验收，CPU，约几十秒；不启动正式训练
& E:/conda-envs/pytorch-gpu/python.exe -B -u E:/Codex/eit_champion_loop_v2/acceptance.py

# 验收源码哈希并打印短训协议；不开始训练
& E:/conda-envs/pytorch-gpu/python.exe -B E:/Codex/eit_champion_loop_v2/train.py --K 3

# 只有显式 --run 才启动一轮 3400 训练 / 720 验证；无 test、无自动续轮
& E:/conda-envs/pytorch-gpu/python.exe -B -u E:/Codex/eit_champion_loop_v2/train.py --K 3 --run

# 全模型原始电压推理；输入格式同包内 raw.npz
& E:/conda-envs/pytorch-gpu/python.exe -B E:/Codex/eit_champion_loop_v2/infer.py --input YOUR_RAW.npz --output NEW_OUTPUT.npz --K 3
```

未提供 `--checkpoint` 时，推理使用预训练 Champion + 尚未训练的零头反馈，会明确输出 `feedback_trained=false`。不得把这种输出当成新反馈学习后的效果。已训练完整检查点由 `--checkpoint` 加载并严格核对 K。

短训入口保存模型、优化器、随机状态、batch 位置，OS 锁互斥，6 小时会话预算，不自动延长。epoch 0 纳入验证选优。当前入口仅输出通用验证损失和逐例 IoU；最终科学交付仍需局部评价、普通病例保护、真实图审阅，不将 complete 当作论文结果。

## 验收与图件

- `E:/Codex/champion_loop_v2/acceptance.json`：包文件逐字节、权重逐张量、两背景全输出一致性、K=3 全网梯度、最终物理损失梯度、其他 K 接口。
- `E:/Codex/model_diagrams_20261024/champion_loop_v2.png` 和 `.svg`：按本版实际连接绘制。

旧训练进程、日志、权重、自动任务均未在本次代码集成中改写或重启。本版没有自动开始正式训练。
