from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent
m=json.loads((r/'SOURCE_MANIFEST.json').read_text(encoding='utf-8'))
bad=[]
for p,v in m.items():
 q=r/'source_archive'/p
 if not q.exists() or hashlib.sha256(q.read_bytes()).hexdigest()!=v['sha256']:bad.append(p)
print('PASS' if not bad else 'FAIL',len(m),'files',bad)
raise SystemExit(bool(bad))
