"""Paired inference-only C4 switch study. Never imports a trainer or writes old runs."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import sys,json,time,hashlib,traceback
from pathlib import Path
import numpy as np
import torch

sys.path.insert(0,'E:/Codex')
from eit_final_c4_loop.model import PhysicalReconstruction,C4FullField,state_from_fields
from common import DATA,NORMALIZER
from comsol_v4.data_v6 import ComsolDataset,Normalizer,signature,FINAL_SIGNATURE,row_case_path
from comsol_v4.paper_common import configure_runtime,tensor_hash
sys.path.insert(0,'E:/Codex/eit_short_review_v1')
from review import read,write,sha,functions_only

OUT=Path('E:/Codex/c4_same_weight_validation_v2')
REVIEW=Path('E:/Codex/old_champion_selection_v1/review_v2')
OLD=Path('E:/Codex/protrusion_study_v1')
A=Path('E:/Codex/shape_generalization_v1/phase3/runs/physical_c4_seed20261025/best.pt')
B=Path('E:/Codex/short_selection_v1/runs/p_full/initial.pt')
PARENT=Path('E:/Codex/shape_generalization_v1/phase3/runs/physical_c4_seed20261023/best.pt')
OFF=Path('E:/Codex/short_selection_v1/runs/p_no_c4/initial.pt')

def status(phase,**kw):
    q=dict(phase=phase,time_unix=time.time(),**kw);write(OUT/'status.json',q)
    print(json.dumps(q,ensure_ascii=False),flush=True)

def c4state(ck):
    return {k.removeprefix('initial.member.'):v for k,v in ck['model'].items() if k.startswith('initial.member.')}

@torch.inference_mode()
def forward(member,pool,x,on):
    if on:return pool(x)
    o=member(x)
    return state_from_fields(o['logits'],o['log_material'],member.fov)

def utility_ci(a,b):
    positions=sorted({r['position_id'] for r in a});assert len(positions)==18
    pools=[np.array([i for i,r in enumerate(a) if r['position_id']==p]) for p in positions]
    def val(ix):
        es=[i for i in ix if a[i]['shape_class']=='E']
        return .5*(np.mean([b[i]['iou']-a[i]['iou'] for i in ix])+np.mean([b[i]['local_iou']-a[i]['local_iou'] for i in es]))
    rng=np.random.default_rng(20261024)
    samples=[val(np.concatenate([pools[i] for i in rng.integers(18,size=18)])) for _ in range(1000)]
    return dict(difference=val(np.arange(720)),position_group_ci95=np.quantile(samples,[.025,.975]).tolist())

@torch.inference_mode()
def benchmark(member,pool,x):
    results={}
    # Fixed validation subset, alternating order to reduce warmup/order bias.
    for bs,repeats in ((1,60),(24,24)):
        samples=[x[(j*29)%720:(j*29)%720+1] for j in range(24)] if bs==1 else [x[j*24:(j+1)*24] for j in range(6)]
        times={False:[],True:[]};peaks={}
        def invoke(batch,on):
            o=forward(member,pool,batch.cuda(),on)
            # Same complete user readout for both modes; includes CPU/GPU transfer.
            return [o[k].cpu() for k in ('probability','sigma','eps_r')]
        for on in (False,True):
            for _ in range(8):invoke(samples[0],on)
        torch.cuda.synchronize()
        for j in range(repeats):
            for on in ((False,True) if j%2==0 else (True,False)):
                torch.cuda.synchronize();start=time.perf_counter()
                out=invoke(samples[j%len(samples)],on)
                torch.cuda.synchronize();times[on].append(time.perf_counter()-start)
                del out
        for on in (False,True):
            torch.cuda.synchronize();torch.cuda.reset_peak_memory_stats()
            baseline=torch.cuda.memory_allocated();out=invoke(samples[0],on);torch.cuda.synchronize()
            peaks[on]=dict(baseline_bytes=baseline,peak_allocated_bytes=torch.cuda.max_memory_allocated(),
                           incremental_bytes=torch.cuda.max_memory_allocated()-baseline)
            del out
        result={}
        for on in (False,True):
            v=np.array(times[on])*1000
            result['on' if on else 'off']=dict(repeats=repeats,batch_size=bs,raw_batch_ms=v.tolist(),
                 median_batch_ms=float(np.median(v)),p10_batch_ms=float(np.quantile(v,.1)),
                 p90_batch_ms=float(np.quantile(v,.9)),median_ms_per_case=float(np.median(v)/bs),memory=peaks[on])
        result['on_over_off_time_ratio']=result['on']['median_batch_ms']/result['off']['median_batch_ms']
        results[str(bs)]=result
    return results

def main():
    OUT.mkdir(exist_ok=False)
    configure_runtime(20261026)
    assert torch.cuda.is_available()
    metric=functions_only(Path('E:/Codex/eit_short_selection_v1/metrics.py'),{'metric','compare'})
    aggregate=functions_only(Path('E:/Codex/eit_shape_general/evaluate.py'),{'aggregate'})['aggregate']
    ranking={r['key']:r for r in read(REVIEW/'ranking.json')['candidates']}
    references={
      'phase3_seed25_off':ranking['phase3__physical_c4_seed20261025__validation_predictions']['source'],
      'p_full_parent23_on':ranking['prior21__p_full__initial']['source'],
      'p_full_parent23_off':ranking['prior21__p_no_c4__initial']['source']}
    guarded=[A,B,PARENT,OFF,Path(NORMALIZER),Path(__file__),REVIEW/'audit.json',REVIEW/'ranking.json',
       Path('E:/Codex/eit_shape_general/physical_model.py'),Path('E:/Codex/eit_shape_general/models.py'),
       Path('E:/Codex/eit_shape_general/common.py'),Path('E:/Codex/eit_final_c4_loop/model.py'),
       Path('E:/Codex/eit_short_selection_v1/metrics.py'),Path('E:/Codex/eit_shape_general/evaluate.py'),
       Path('E:/Codex/eit_reproduction/comsol_v4/data_v6.py'),Path('E:/Codex/eit_reproduction/comsol_v4/features.py'),
       Path('E:/Codex/shape_generalization_v1/phase2/physical_projection.npz')]
    guarded.extend(Path(r['path']) for r in references.values())
    hashes={str(p):sha(p) for p in guarded}
    assert hashes[str(A)]=='28bf9696d5f3b7034ab4d6ceefb5a370420c408de50e66ca0445333be5bab828'
    assert hashes[str(B)]=='04c14ee36922f6ccf77c854587638ef03fb1170af6e94514213ebeabd07e6430'
    for r in references.values():assert sha(Path(r['path']))==r['sha256']
    protocol=dict(version='paired-inference-c4-v1',checkpoints={str(A):hashes[str(A)],str(B):hashes[str(B)]},
        conditions=['each checkpoint C4 off','same checkpoint C4 on'],train_updates=0,test_read=False,
        validation_cases=720,threshold=.5,validation_batch=2,precision='float32; TF32 and AMP disabled',
        c4='Existing C4FullField unchanged: four shared-weight transforms, aligned logit/log-material mean',
        metrics='same frozen per-case masks, shape/material metrics and 18-position 1000-resample bootstrap',
        descriptive_utility='(all IoU + E local IoU)/2; no new winner-selection threshold',
        timing='8 warmups per mode, alternating paired order, batch1 x60 / batch24 x24; synchronization and CPU input/output transfers included; cached normalized inputs; excludes disk/preprocessing/FEM',
        immutable_sources=hashes,device=torch.cuda.get_device_name(),torch_version=torch.__version__,
        historical_precision_check='Original phase3 disabled cuDNN TF32; old short runner left cuDNN TF32 enabled. Reproduce historical outputs separately; all FOUR primary conditions use identical full FP32.',
        limitations=['reused validation exploratory comparison','two fixed pretrained weights, not training-seed uncertainty',
         'no test data or nonlinear FEM voltage calculation','desktop GPU timing not dedicated server benchmark'])
    write(OUT/'protocol.json',protocol)
    status('loading_validation')
    assert signature(DATA)==FINAL_SIGNATURE
    norm=Normalizer.load(NORMALIZER,DATA);norm.validate_training_contract(DATA,'calibrated')
    ds=ComsolDataset(DATA,'val',norm);assert len(ds)==720 and all(r['split']=='val' for r in ds.rows)
    items=[];data_hashes={}
    for i in range(720):
        items.append(ds[i]);path=row_case_path(DATA,ds.rows[i]);data_hashes[str(path)]=sha(path)
        if (i+1)%240==0:status('loading_validation',completed=i+1,total=720)
    ids=[q['case_id'] for q in items]
    x=torch.stack([q['features'] for q in items]);truth=torch.stack([q['mask'][0] for q in items]).numpy().astype(bool)
    material=torch.stack([torch.cat((q['sigma'],q['eps_r'])).clamp_min(1e-8).log() for q in items]).numpy()
    with np.load(references['p_full_parent23_on']['path']) as z:
        ix=[list(z['case_ids']).index(cid) for cid in ids];assert np.array_equal(truth,z['truth'][ix].astype(bool))
    meta={r['case_id']:r for r in read(OLD/'val_diagnostic.json')['metadata']};masks=[]
    for cid in ids:
        path=OLD/'cache/val'/(cid+'.npz')
        with np.load(path) as z:masks.append((z['added'].astype(bool),z['neighbor'].astype(bool)))
        data_hashes[str(path)]=sha(path)
    write(OUT/'validation_inputs.json',dict(case_ids=ids,input_sha256=hashlib.sha256(x.numpy().tobytes()).hexdigest(),
          truth_sha256=hashlib.sha256(truth.tobytes()).hexdigest(),file_hashes=data_hashes))
    del items
    ca=torch.load(A,map_location='cpu',weights_only=True)['model']
    cb_full=torch.load(B,map_location='cpu',weights_only=True);cb=c4state(cb_full)
    cp=torch.load(PARENT,map_location='cpu',weights_only=True)['model']
    co=c4state(torch.load(OFF,map_location='cpu',weights_only=True))
    assert cb.keys()==cp.keys()==co.keys()
    assert all(torch.equal(cb[k],cp[k]) and torch.equal(cb[k],co[k]) for k in cb)
    for k,buffer in [('mean','input_mean'),('std','input_std'),('fov','fov')]:
        assert torch.equal(cb[k],cb_full['model']['initial.'+buffer])
    del cp,co,cb_full
    summaries={};records={};timings={};parity={}
    for name,state in [('phase3_seed25',ca),('p_full_parent23',cb)]:
        member=PhysicalReconstruction(dict(kind='physical'),ds.fov)
        member.load_state_dict(state,strict=True);before=tensor_hash(member.state_dict())
        assert torch.equal(member.fov,torch.as_tensor(ds.fov,dtype=torch.float32)[None,None])
        member=member.cuda().eval();pool=C4FullField(member).cuda().eval();member.requires_grad_(False)
        for on in (False,True):
            key=name+('_on' if on else '_off');status('validating',condition=key,completed=0,total=720)
            probs=[];logs=[]
            with torch.inference_mode():
                for i in range(0,720,2):
                    out=forward(member,pool,x[i:i+2].cuda(),on)
                    probs.append(out['probability'][:,0].cpu().numpy());logs.append(out['log_material'].cpu().numpy())
                    if (i+2)%180==0:status('validating',condition=key,completed=i+2,total=720)
            prob=np.concatenate(probs);logmat=np.concatenate(logs)
            assert np.isfinite(prob).all() and np.isfinite(logmat).all()
            rr=[]
            for i,cid in enumerate(ids):
                r=metric['metric'](prob[i],truth[i],meta[cid],*masks[i])
                error=np.abs(logmat[i]-material[i])
                r.update(log_sigma_mae=float(error[:2,ds.fov].mean()),log_eps_mae=float(error[2:,ds.fov].mean()))
                rr.append(r)
            g=aggregate(rr)
            for group in g:
                selected=[r for r in rr if group=='all' or group==r['shape_class'] or (group=='BCDE' and r['shape_class']!='A') or (group.startswith('E_') and r['shape_class']=='E' and r.get('bump_size_class')==group[2:])]
                for field in ('log_sigma_mae','log_eps_mae'):g[group][field]=float(np.mean([r[field] for r in selected]))
            summaries[key]=dict(groups=g,U=.5*(g['all']['iou']+g['E']['local_iou']),core_tensor_hash=before)
            records[key]=rr;write(OUT/'records'/(key+'.json'),rr)
            np.savez_compressed(OUT/(key+'.npz'),case_ids=np.array(ids),probability=prob,truth=truth,log_material=logmat)
            if key in references:
                with np.load(references[key]['path']) as z:
                    ix=[list(z['case_ids']).index(cid) for cid in ids];old=z['probability'][ix]
                parity[key]=dict(max_abs_probability_difference=float(np.max(np.abs(prob-old))),
                     changed_binary_pixels=int(np.count_nonzero((prob>=.5)!=(old>=.5))))
                if name=='phase3_seed25':
                    assert parity[key]['max_abs_probability_difference']<1e-4,(key,parity[key])
                    assert parity[key]['changed_binary_pixels']==0,(key,parity[key])
                else:
                    # Confirm the older runner's actual cuDNN default rather than
                    # silently treating precision drift as a C4 effect.
                    torch.backends.cudnn.allow_tf32=True
                    historical=[]
                    try:
                        with torch.inference_mode():
                            for j in range(0,720,2):
                                historical.append(forward(member,pool,x[j:j+2].cuda(),on)['probability'][:,0].cpu().numpy())
                    finally:torch.backends.cudnn.allow_tf32=False
                    historical=np.concatenate(historical)
                    hp=dict(cudnn_tf32=True,matmul_tf32=False,
                        max_abs_difference=float(np.max(np.abs(historical-old))),
                        binary_changes=int(np.count_nonzero((historical>=.5)!=(old>=.5))))
                    assert hp['max_abs_difference']<1e-4 and hp['binary_changes']==0,(key,hp)
                    parity[key]['historical_precision_reproduction']=hp
                    np.savez_compressed(OUT/(key+'_historical_precision_check.npz'),case_ids=np.array(ids),probability=historical)
            write(OUT/'summary.json',summaries)
        status('benchmarking',checkpoint=name)
        timings[name]=benchmark(member,pool,x);write(OUT/'timing.json',timings)
        assert tensor_hash(member.state_dict())==before,'Read-only inference changed weights or buffers'
        del pool,member;torch.cuda.empty_cache()
    comparisons={}
    for name in ('phase3_seed25','p_full_parent23'):
        a,b=records[name+'_off'],records[name+'_on']
        comparisons[name]=dict(direction='on minus off',groups=metric['compare'](a,b),utility=utility_ci(a,b),
             multiple_comparisons_adjusted=False,weight_seed_uncertainty=False)
    write(OUT/'comparisons.json',comparisons)
    for path,h in hashes.items():assert sha(Path(path))==h,path
    write(OUT/'audit.json',dict(status='PASS',same_weight_within_pairs=True,parent23_and_p_no_c4_identical=True,
        full_720_validation=True,threshold=.5,old_prediction_parity=parity,protected_hashes_unchanged=True,
        weights_and_buffers_unchanged=True,test_read=False,training_updates=0,source_hashes=hashes,
        artifacts={str(p.relative_to(OUT)):sha(p) for p in OUT.rglob('*') if p.is_file()}))
    status('complete',conditions=4,validation_cases_per_condition=720,test_read=False,training_updates=0)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():write(OUT/'failure.json',dict(traceback=traceback.format_exc()))
        raise
