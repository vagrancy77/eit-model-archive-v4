"""Read-only diagnosis of historical inference precision, a fixed eight-case check."""
from run_validation import *

def main():
    configure_runtime(20261026)
    n=Normalizer.load(NORMALIZER,DATA);ds=ComsolDataset(DATA,'val',n,with_labels=False)
    with np.load(OUT/'p_full_parent23_off.npz') as z:ids=z['case_ids'].tolist();new=z['probability']
    with np.load('E:/Codex/short_selection_v1/runs/p_no_c4/initial.npz') as z:
        old=z['probability'][[z['case_ids'].tolist().index(cid) for cid in ids]]
    worst=np.argsort(np.max(np.abs(new-old),axis=(1,2)))[-8:].tolist()
    inputs=torch.stack([ds[i]['features'] for i in worst]).cuda()
    state=c4state(torch.load(B,map_location='cpu',weights_only=True))
    m=PhysicalReconstruction(dict(kind='physical'),ds.fov);m.load_state_dict(state);m=m.cuda().eval()
    result=[]
    for matmul in (False,True):
        for cudnn in (False,True):
            torch.backends.cuda.matmul.allow_tf32=matmul;torch.backends.cudnn.allow_tf32=cudnn
            with torch.no_grad():p=torch.cat([m(inputs[i:i+2])['probability'] for i in range(0,8,2)])[:,0].cpu().numpy()
            q=dict(matmul_tf32=matmul,cudnn_tf32=cudnn,max_abs_difference=float(np.max(np.abs(p-old[worst]))),
                   binary_changes=int(np.count_nonzero((p>=.5)!=(old[worst]>=.5))))
            result.append(q);print(q,flush=True)
    write(OUT/'parity_diagnosis.json',dict(case_ids=[ids[i] for i in worst],results=result,
        script_sha256=sha(Path(__file__)),note='Eight worst-difference validation cases; no weights changed'))

if __name__=='__main__':main()
