"""Separate saved-artifact review/plots. Does not import torch or run inference."""
import sys,json,hashlib
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
sys.path.insert(0,'E:/Codex/eit_short_review_v1')
from review import read,write,sha,functions_only
ROOT=Path('E:/Codex/c4_same_weight_validation_v2')
OUT=ROOT/'review'
OLD=Path('E:/Codex/protrusion_study_v1')
FONT=FontProperties(fname='C:/Windows/Fonts/msyh.ttc')

def main():
    OUT.mkdir(exist_ok=False)
    audit=read(ROOT/'audit.json');assert audit['status']=='PASS'
    for p,h in audit['source_hashes'].items():assert sha(Path(p))==h,p
    for p,h in audit['artifacts'].items():
        # status is deliberately finalized after the numerical audit is saved.
        if p!='status.json':assert sha(ROOT/p)==h,p
    m=functions_only(Path('E:/Codex/eit_short_selection_v1/metrics.py'),{'metric','compare'})
    agg=functions_only(Path('E:/Codex/eit_shape_general/evaluate.py'),{'aggregate'})['aggregate']
    summary=read(ROOT/'summary.json');allrecords={};pictures={};meta={r['case_id']:r for r in read(OLD/'val_diagnostic.json')['metadata']}
    ids0=read(ROOT/'validation_inputs.json')['case_ids'];assert len(set(ids0))==720
    for key,s in summary.items():
        with np.load(ROOT/(key+'.npz')) as z:
            ids=z['case_ids'].tolist();prob=z['probability'];truth=z['truth'].astype(bool)
        assert ids==ids0 and len(ids)==720
        stored=read(ROOT/'records'/(key+'.json'));rows=[]
        for i,cid in enumerate(ids):
            with np.load(OLD/'cache/val'/(cid+'.npz')) as z:a=z['added'].astype(bool);n=z['neighbor'].astype(bool)
            r=m['metric'](prob[i],truth[i],meta[cid],a,n)
            for name in ('iou','dice','boundary_f1','boundary_distance_pixels','local_iou','bump_recall','neighbor_false_addition','detected'):
                if name in r:assert abs(float(r[name])-float(stored[i][name]))<1e-12,(key,cid,name)
            rows.append(r)
        g=agg(rows)
        for group,v in g.items():
            for name,val in v.items():assert abs(val-s['groups'][group][name])<1e-12
        allrecords[key]=rows;pictures[key]=(prob,truth)
    # Direct comparison of the two C4-on routes, exploratory and paired by position.
    write(OUT/'phase3_on_vs_pfull_on.json',dict(reference='p_full_parent23_on',candidate='phase3_seed25_on',
        delta='phase3_on minus pfull_on',groups=m['compare'](allrecords['p_full_parent23_on'],allrecords['phase3_seed25_on']),
        seed_selection_uncertainty_included=False,multiplicity_adjusted=False))
    cases={}
    for family in ('phase3_seed25','p_full_parent23'):
        off=allrecords[family+'_off'];on=allrecords[family+'_on'];p0,truth=pictures[family+'_off'];p1,_=pictures[family+'_on']
        es=[i for i,r in enumerate(off) if r['shape_class']=='E']
        fixed=[(f'固定 {c}',min([i for i,r in enumerate(off) if r['shape_class']==c],key=lambda i:hashlib.sha256(ids[i].encode()).hexdigest())) for c in 'ABCDE']
        delta=lambda i:on[i]['local_iou']-off[i]['local_iou']
        picks=fixed+[('局部改善最多',max(es,key=delta)),('局部退步最多',min(es,key=delta))]
        cases[family]=[dict(selection=s,case_id=ids[i]) for s,i in picks]
        fig,axes=plt.subplots(7,6,figsize=(16,18),layout='constrained')
        title='phase3 原权重' if family=='phase3_seed25' else 'p_full 原权重'
        fig.suptitle(title+'：同权重，四方向融合关闭 / 开启\n同720验证集；前5例按ID哈希固定，末2例为本次局部变化最好/最差；阈值均为0.5',fontproperties=FONT,fontsize=16)
        headers=['真值｜全图','关闭融合｜全图','开启融合｜全图','真值｜局部','关闭融合｜局部','开启融合｜局部']
        for row,(selection,i) in enumerate(picks):
            cid=ids[i]
            with np.load(OLD/'cache/val'/(cid+'.npz')) as z:a=z['added'].astype(bool);n=z['neighbor'].astype(bool)
            region=a|n if a.any() else truth[i]|(p0[i]>=.5)|(p1[i]>=.5)
            yy,xx=np.where(region);y0,y1=max(0,int(yy.min())-3),min(64,int(yy.max())+4);x0,x1=max(0,int(xx.min())-3),min(64,int(xx.max())+4)
            ims=[truth[i],p0[i]>=.5,p1[i]>=.5,truth[i,y0:y1,x0:x1],p0[i,y0:y1,x0:x1]>=.5,p1[i,y0:y1,x0:x1]>=.5]
            for col,im in enumerate(ims):
                ax=axes[row,col];ax.imshow(im,origin='lower',cmap='gray',vmin=0,vmax=1,interpolation='nearest');ax.set_xticks([]);ax.set_yticks([])
                if row==0:ax.set_title(headers[col],fontproperties=FONT,fontsize=11)
                if col>=3 and a.any():
                    ax.contour(a[y0:y1,x0:x1],levels=[.5],colors=['lime'],linewidths=.8)
                    ax.contour(n[y0:y1,x0:x1],levels=[.5],colors=['orange'],linewidths=.6)
            axes[row,0].set_ylabel(selection+'\n'+cid,fontproperties=FONT,fontsize=9)
            axes[row,1].set_xlabel(f'IoU {off[i]["iou"]:.4f}',fontsize=10)
            axes[row,2].set_xlabel(f'IoU {on[i]["iou"]:.4f}',fontsize=10)
            if a.any():
                for col,rs in ((4,off),(5,on)):
                    r=rs[i];axes[row,col].set_xlabel(f'局部IoU {r["local_iou"]:.3f}\n召回 {r["bump_recall"]:.3f} / 误填 {r["neighbor_false_addition"]:.3f}',fontproperties=FONT,fontsize=9)
        for ext in ('png','pdf'):fig.savefig(OUT/(family+'_paired.'+ext),dpi=145,bbox_inches='tight')
        plt.close(fig)
    write(OUT/'case_selection.json',cases)
    write(OUT/'review_audit.json',dict(status='PASS_saved_prediction_metrics',conditions=4,cases_each=720,
        audit_sha256=sha(ROOT/'audit.json'),script_sha256=sha(Path(__file__)),source_hashes_unchanged=True,
        figures_require_visual_review=True,test_read=False,training_updates=0))
    print('REVIEW_COMPLETE',flush=True)

if __name__=='__main__':main()
