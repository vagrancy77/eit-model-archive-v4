"""Frozen-checkpoint evaluation; test is loaded only after training completes."""
import argparse
import json
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

from run_experiment import (Cache, ControlledDataset, V4Comsol, FORMAT, validate, write_json,
                            measurement_mask, signature)
from comsol_v4.data_v6 import FINAL_DATASET_ROOT, assert_final_dataset, verify_manifest, file_hash


def from_q(qv, qb, mode):
    valid = measurement_mask()[None]
    if mode in ('amplitude', 'amplitude_calibrated'):
        a = np.zeros((12, 32, 32), np.float32)
        a[0:2], a[4:6] = np.abs(qv)*valid, np.abs(qb)*valid
        a[8:10] = (np.abs(qv)-np.abs(qb))*valid
        if mode == 'amplitude_calibrated':
            rms = np.sqrt((np.abs(qb)**2*valid).sum((1, 2), keepdims=True)/valid.sum())
            a[8:10] = ((np.abs(qv)-np.abs(qb))*np.abs(qb)/(np.abs(qb)**2+(.01*rms)**2))*valid
        return a
    d = qv-qb
    if mode == 'calibrated':
        rms = np.sqrt((np.abs(qb)**2*valid).sum((1, 2), keepdims=True)/valid.sum())
        d = d*qb.conj()/(np.abs(qb)**2+(.01*rms)**2)
    return (np.concatenate((qv.real, qv.imag, qb.real, qb.imag, d.real, d.imag))*valid).astype(np.float32)


def noisy_features(cache, mode, scenario, stress_seed):
    # Repeat exactly the same random nuisance realization for every model.
    rng = np.random.default_rng(stress_seed)
    valid = measurement_mask()[None]
    features = np.empty_like(cache.features[mode])
    for i in range(len(cache.rows)):
        v, b = cache.voltage[i], cache.background[i]
        qv, qb = v-np.roll(v, -1, axis=-1), b-np.roll(b, -1, axis=-1)
        amplitude_rms = np.sqrt((np.abs(qb)**2*valid).sum((1, 2), keepdims=True)/valid.sum())
        # Generate all draws in a fixed order so scenario magnitude alone varies.
        zv = (rng.normal(size=qv.shape)+1j*rng.normal(size=qv.shape))/np.sqrt(2)
        zb = (rng.normal(size=qb.shape)+1j*rng.normal(size=qb.shape))/np.sqrt(2)
        phase = rng.normal(size=(2, 1, 1))
        noise = scenario.get('voltage_noise_fraction_of_background_RMS', 0.)
        qv, qb = qv+noise*amplitude_rms*zv, qb+noise*amplitude_rms*zb
        drift = np.deg2rad(scenario.get('case_reference_differential_phase_SD_deg', 0.))*phase
        common = np.deg2rad(scenario.get('common_case_reference_phase_SD_deg', 0.))*phase
        qv = qv*np.exp(1j*(drift+common))
        qb = qb*np.exp(1j*common)
        features[i] = from_q(qv, qb, mode)
    return features


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--dataset-root', type=Path, default=FINAL_DATASET_ROOT)
    p.add_argument('--run-root', type=Path, required=True)
    p.add_argument('--output-dir', type=Path, required=True)
    p.add_argument('--split', choices=['val', 'test'], default='test')
    p.add_argument('--batch-size', type=int, default=64)
    p.add_argument('--clean-only', action='store_true')
    p.add_argument('--additional-run-root', type=Path)
    a = p.parse_args()
    final_contract = assert_final_dataset(a.dataset_root)
    integrity=verify_manifest(a.dataset_root)
    protocol = json.loads((a.run_root/'protocol.json').read_text(encoding='utf-8'))
    plan = json.loads((Path(__file__).parent/'EVALUATION_PLAN.json').read_text(encoding='utf-8'))
    plan['independent_evaluation'] = 'final 720-case position-isolated test partition after all checkpoints are frozen'
    plan['primary_metric'] = 'foreground IoU for concave B/C/D/E and ordinary A; report E separately'
    plan['final_dataset_contract'] = final_contract
    plan['dataset_integrity'] = integrity
    if protocol['dataset_signature'] != signature(a.dataset_root):
        raise ValueError('Dataset changed since training')
    if not (a.run_root/'experiment_completed.json').is_file():
        raise ValueError('Finish all prespecified training runs before independent evaluation')
    for seed in protocol['seeds']:
        for mode in protocol['modes']:
            if not (a.run_root/f'{mode}_seed{seed}'/'completed.json').is_file():
                raise ValueError('Missing frozen run')
    extra_protocol = None
    if a.additional_run_root:
        extra_protocol = json.loads((a.additional_run_root/'protocol.json').read_text(encoding='utf-8'))
        for key in ('dataset_signature', 'seeds', 'epochs', 'batch_size', 'base', 'lr', 'optimizer', 'measurement', 'selection'):
            if extra_protocol[key] != protocol[key]:
                raise ValueError('Additional control is not matched: '+key)
        if extra_protocol['modes'] != ['amplitude_calibrated'] or not (a.additional_run_root/'experiment_completed.json').exists():
            raise ValueError('Complete the matched amplitude calibration control first')
    effective_protocol = dict(protocol)
    if extra_protocol:
        if set(protocol['modes']) & set(extra_protocol['modes']):
            raise ValueError('Duplicate representation in main and additional experiment')
        effective_protocol['modes'] = protocol['modes']+extra_protocol['modes']
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.use_deterministic_algorithms(True)
    cache = Cache(a.dataset_root, a.split)
    a.output_dir.mkdir(parents=True, exist_ok=True)
    evaluation_plan={**plan, 'split': a.split, 'training_protocol': effective_protocol,
                     'additional_control_protocol': extra_protocol}
    existing_plan=a.output_dir/'evaluation_plan.json'
    if existing_plan.exists() and json.loads(existing_plan.read_text(encoding='utf-8')) != evaluation_plan:
        raise ValueError('Evaluation output belongs to another plan or dataset; choose a new directory')
    if not existing_plan.exists() and any(a.output_dir.iterdir()):
        raise ValueError('Unversioned nonempty evaluation directory; choose a new directory')
    write_json(existing_plan,evaluation_plan)
    scenarios = plan['noise_scenarios'][:1] if a.clean_only else plan['noise_scenarios']
    summary = []
    for seed in protocol['seeds']:
        for mode in effective_protocol['modes']:
            is_extra = extra_protocol is not None and mode in extra_protocol['modes']
            root = a.additional_run_root if is_extra else a.run_root
            expected_protocol = extra_protocol if is_extra else protocol
            checkpoint_path = root/f'{mode}_seed{seed}'/'best.pt'
            checkpoint_hash=file_hash(checkpoint_path)
            checkpoint = torch.load(checkpoint_path, map_location='cpu', weights_only=True)
            if checkpoint['format'] != FORMAT or checkpoint['protocol'] != expected_protocol:
                raise ValueError('Checkpoint protocol mismatch')
            net = V4Comsol(cache.fov, **checkpoint['model_config']).cuda()
            net.load_state_dict(checkpoint['model'])
            fov = torch.from_numpy(cache.fov.astype(np.float32))[None, None].cuda()
            mean, std = [checkpoint['normalizer'][k].numpy() for k in ('mean', 'std')]
            for scenario in scenarios:
                out = a.output_dir/f'{mode}_seed{seed}'/scenario['name']
                out.mkdir(parents=True, exist_ok=True)
                report_path = out/'metrics.json'
                if report_path.exists():
                    previous=json.loads(report_path.read_text(encoding='utf-8'))
                    if (previous.get('dataset_signature')!=protocol['dataset_signature'] or
                            previous.get('checkpoint_sha256')!=checkpoint_hash or previous.get('scenario')!=scenario):
                        raise ValueError('Stale evaluation result; refusing to mix data or model versions')
                    summary.append(previous)
                    continue
                features = None if scenario['name'] == 'clean' else noisy_features(cache, mode, scenario, plan['stress_seed'])
                if mode in ('amplitude', 'amplitude_calibrated') and ('phase' in scenario['name']):
                    # A phase-only perturbation must not change this baseline.
                    np.testing.assert_allclose(features, cache.features[mode], atol=1e-9, rtol=1e-6)
                ds = ControlledDataset(cache, mode, mean, std, override=features)
                loader = DataLoader(ds, batch_size=a.batch_size, shuffle=False, num_workers=0, pin_memory=True)
                exported = out/'predictions.npz' if scenario['name'] == 'clean' else None
                _, records, _ = validate(net, loader, fov, cache if exported else None, export=exported)
                from comsol_v4.metrics import aggregate
                report = {'mode': mode, 'seed': seed, 'scenario': scenario, 'split': a.split,
                          'dataset_signature':protocol['dataset_signature'],'checkpoint_sha256':checkpoint_hash,
                          'selected_epoch': checkpoint['epoch'], 'checkpoint_selected_by': protocol['selection'],
                          'metrics': aggregate(records), 'per_case': records,
                          'test_used_for_selection': False, 'physics_loss_active': False}
                write_json(report_path, report)
                summary.append(report)
                print(f'EVALUATED {mode} seed={seed} {scenario["name"]} '
                      f'IoU={report["metrics"]["all"]["foreground_iou"]:.4f}', flush=True)
                del ds, loader, features
            del net
            torch.cuda.empty_cache()
    write_json(a.output_dir/'evaluation_completed.json', {'status': 'complete', 'split': a.split,
               'evaluations': len(summary), 'test_used_for_selection': False,
               'conditions': [s['name'] for s in scenarios]})
    print('FROZEN EVALUATION COMPLETE', flush=True)


if __name__ == '__main__':
    main()
