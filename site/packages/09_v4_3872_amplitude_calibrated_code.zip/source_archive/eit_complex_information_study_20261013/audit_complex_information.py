"""Training-only information audit; no network training or reconstruction claim.

The source NPZ files and their official splits are never modified. Statistics
use gauge-invariant adjacent electrode voltage differences, excluding pairs
touching either injecting electrode. This is an analysis convention, not a
silent change to the existing v4 input convention.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

EPS0 = 8.8541878128e-12
FREQUENCIES = np.array([10000.0, 50000.0])


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def adjacent_mask():
    drive, pair = np.indices((32, 32))
    ret = (drive + 1) % 32
    other = (pair + 1) % 32
    return ~((pair == drive) | (pair == ret) | (other == drive) | (other == ret))


def adjacent_voltage(potential):
    return potential - np.roll(potential, -1, axis=-1)


def summarize(values):
    values = np.asarray(values, dtype=np.float64)
    if not np.isfinite(values).all():
        raise ValueError("Nonfinite diagnostic")
    return {"mean": float(values.mean()), "p05": float(np.quantile(values, .05)),
            "median": float(np.median(values)), "p95": float(np.quantile(values, .95))}


def audit_case(root, row, pair_mask):
    path = (root / row["file"]).resolve()
    if not path.is_relative_to(root):
        raise ValueError("Case escapes the dataset root")
    with np.load(path, allow_pickle=False) as z:
        v, b = z["voltage"], z["background_voltage"]
        if v.shape != (2, 32, 32) or b.shape != v.shape:
            raise ValueError("Unexpected measurement dimensions")
        if not (np.iscomplexobj(v) and np.iscomplexobj(b)
                and np.isfinite(v).all() and np.isfinite(b).all()):
            raise ValueError("Invalid complex data")
        if not np.array_equal(z["frequencies_hz"], FREQUENCIES):
            raise ValueError("Unexpected frequency order")
        params = json.loads(z["parameters_json"].item())
        if params["drive_mode"] != "adjacent" or params["adjacent_return"] != "next":
            raise ValueError("Audit mask does not match the stimulation protocol")
        if str(z["case_id"].item()) != row["case_id"]:
            raise ValueError("Case ID mismatch")
        truth = z["lesion_mask"].copy()

    qv, qb = adjacent_voltage(v), adjacent_voltage(b)
    dq = qv - qb
    record = {k: row[k] for k in ("case_id", "shape_class", "position_id", "material_combination_id")}
    record.update(background_material=params["background_material"], lesion_material=params["lesion_material"])
    amplitude_maps, phase_maps = [], []
    for fi, freq in enumerate(FREQUENCIES.astype(int)):
        a, a0 = np.abs(qv[fi]), np.abs(qb[fi])
        reference_rms = np.sqrt(np.mean(a0[pair_mask] ** 2))
        # A predeclared signal floor for descriptive statistics, not an estimated
        # instrument noise floor. Both signal magnitudes must pass it for phase.
        floor = .01 * reference_rms
        usable = pair_mask & (a0 > floor) & (a > floor)
        if not usable.any():
            raise ValueError("No usable measurement channels")
        phase = np.angle(qv[fi] * qb[fi].conj())
        weight = a0[usable] ** 2
        phase_rms = np.sqrt(np.sum(weight * phase[usable] ** 2) / weight.sum())
        delta_energy = float(np.sum(np.abs(dq[fi][usable]) ** 2))
        amplitude_energy = float(np.sum((a[usable] - a0[usable]) ** 2))
        # Exact identity on the same usable channels:
        # |qv-qb|^2 = (|qv|-|qb|)^2 + 2|qv||qb|(1-cos(relative phase)).
        phase_gap = float(np.sum(2 * a[usable] * a0[usable] * (1 - np.cos(phase[usable]))))
        if not np.isclose(delta_energy, amplitude_energy + phase_gap, rtol=1e-7, atol=1e-20):
            raise AssertionError("Amplitude/phase energy identity failed")
        centered_dv = (v[fi] - b[fi]) - (v[fi] - b[fi]).mean(-1, keepdims=True)
        prefix = f"{freq}Hz_"
        record.update({
            prefix + "relative_phase_weighted_rms_deg": float(np.rad2deg(phase_rms)),
            prefix + "relative_phase_channel_abs_median_deg": float(np.rad2deg(np.median(np.abs(phase[usable])))),
            prefix + "phase_dependent_delta_energy_fraction": phase_gap / max(delta_energy, 1e-30),
            prefix + "relative_delta_norm": float(np.linalg.norm(dq[fi][usable]) / np.linalg.norm(qb[fi][usable])),
            prefix + "centered_delta_imag_norm_fraction": float(np.linalg.norm(centered_dv.imag) / np.linalg.norm(centered_dv)),
            prefix + "usable_fraction": float(usable.sum() / pair_mask.sum()),
            prefix + "sigma_lesion_background_ratio": float(params[f"sig_l{10 if fi == 0 else 50}"]) / float(params[f"sig_b{10 if fi == 0 else 50}"]),
            prefix + "beta_lesion_background_ratio": float(params[f"eps_l{10 if fi == 0 else 50}"]) / float(params[f"eps_b{10 if fi == 0 else 50}"]),
            prefix + "background_beta_S_per_m": float(2 * np.pi * freq * EPS0 * float(params[f"eps_b{10 if fi == 0 else 50}"])),
        })
        amplitude_maps.append(np.where(usable, 100 * (a - a0) / np.maximum(a0, floor), np.nan))
        phase_maps.append(np.where(usable, np.rad2deg(phase), np.nan))
    return record, {"truth": truth, "amplitude_percent": amplitude_maps, "relative_phase_deg": phase_maps}


def configure_font():
    from matplotlib import font_manager
    font = Path("C:/Windows/Fonts/msyh.ttc")
    if font.exists():
        font_manager.fontManager.addfont(str(font))
        plt.rcParams["font.family"] = "Microsoft YaHei"
    plt.rcParams["axes.unicode_minus"] = False


def plot_summary(records, output):
    configure_font()
    fig, axes = plt.subplots(2, 2, figsize=(14, 9), constrained_layout=True)
    colors = ("#1971c2", "#f08c00")
    for freq, color in zip(FREQUENCIES.astype(int), colors):
        values = [r[f"{freq}Hz_relative_phase_weighted_rms_deg"] for r in records]
        axes[0, 0].hist(values, bins=35, density=True, histtype="step", linewidth=2,
                        color=color, label=f"{freq // 1000} kHz，中位数 {np.median(values):.3f}°")
        energy = np.array([r[f"{freq}Hz_phase_dependent_delta_energy_fraction"] for r in records]) * 100
        axes[0, 1].hist(energy, bins=np.linspace(0, 100, 41), density=True, histtype="step", linewidth=2,
                        color=color, label=f"{freq // 1000} kHz，中位数 {np.median(energy):.1f}%")
    axes[0, 0].set(title="病灶相对背景的相位变化", xlabel="逐病例、背景能量加权相位 RMS（度）", ylabel="密度")
    axes[0, 1].set(title="复差分电压中相位相关的能量占比", xlabel="相位项 / 复差分电压总能量（%）", ylabel="密度")
    classes = list("ABCD")
    material_ids = sorted({r["material_combination_id"] for r in records})
    for offset, freq, color in zip((-.17, .17), FREQUENCIES.astype(int), colors):
        medians = [np.median([r[f"{freq}Hz_relative_phase_weighted_rms_deg"] for r in records
                              if r["shape_class"] == c]) for c in classes]
        axes[1, 0].bar(np.arange(4) + offset, medians, .34, color=color, label=f"{freq // 1000} kHz")
        medians = [np.median([r[f"{freq}Hz_relative_phase_weighted_rms_deg"] for r in records
                              if r["material_combination_id"] == m]) for m in material_ids]
        axes[1, 1].bar(np.arange(len(material_ids)) + offset, medians, .34, color=color,
                       label=f"{freq // 1000} kHz")
    axes[1, 0].set(title="按形状分组：普通形状与内凹形状", xlabel="形状类（A 为凸形，B/C/D 为内凹）", ylabel="相对相位 RMS 中位数（度）",
                   xticks=np.arange(4), xticklabels=classes)
    axes[1, 1].set(title="按材料组合分组", xlabel="材料组合编号", ylabel="相对相位 RMS 中位数（度）",
                   xticks=np.arange(len(material_ids)), xticklabels=material_ids)
    for ax in axes.flat:
        ax.legend(fontsize=9)
        ax.grid(axis="y", alpha=.2)
    fig.suptitle("EIT 复电压信息审计：仅使用 2720 例训练数据；不是模型重建结果", fontsize=16)
    fig.savefig(output / "phase_information_summary.png", dpi=150)
    plt.close(fig)


def plot_examples(examples, output):
    configure_font()
    fig, axes = plt.subplots(4, 5, figsize=(18, 12), constrained_layout=True)
    amp_limit = max(np.nanquantile(np.abs(e[1]["amplitude_percent"]), .995) for e in examples)
    phase_limit = max(np.nanquantile(np.abs(e[1]["relative_phase_deg"]), .995) for e in examples)
    cmap = plt.get_cmap("RdBu_r").copy()
    cmap.set_bad("#dedede")
    for ri, (record, example) in enumerate(examples):
        axes[ri, 0].imshow(example["truth"], origin="lower", cmap="Greys", vmin=0, vmax=1)
        axes[ri, 0].set_ylabel(record["case_id"], fontsize=11)
        for fi in range(2):
            amp_image = axes[ri, 1 + 2 * fi].imshow(example["amplitude_percent"][fi], origin="lower",
                            cmap=cmap, vmin=-amp_limit, vmax=amp_limit)
            phase_image = axes[ri, 2 + 2 * fi].imshow(example["relative_phase_deg"][fi], origin="lower",
                            cmap=cmap, vmin=-phase_limit, vmax=phase_limit)
        for ax in axes[ri]:
            ax.set_xticks([])
            ax.set_yticks([])
    for ax, title in zip(axes[0], ("病灶真值：仅作展示", "10 kHz 幅值变化", "10 kHz 相对相位", "50 kHz 幅值变化", "50 kHz 相对相位")):
        ax.set_title(title, fontsize=11)
    fig.colorbar(amp_image, ax=list(axes[:, 1]) + list(axes[:, 3]), shrink=.45,
                 label="(|qV|−|qB|) / |qB|（%）")
    fig.colorbar(phase_image, ax=list(axes[:, 2]) + list(axes[:, 4]), shrink=.45,
                 label="arg(qV·conj(qB))（度）")
    fig.suptitle("固定位置组 P55、材料组 M01（脂肪背景 / 肝组织目标）的四类训练病例\n行：激励；列：相邻测量对。灰色：激励相关/低幅值通道；不是重建图", fontsize=15)
    fig.savefig(output / "amplitude_phase_examples.png", dpi=150)
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset-root", type=Path, required=True)
    ap.add_argument("--output-dir", type=Path, required=True)
    ap.add_argument("--archive", type=Path)
    ap.add_argument("--replot", action="store_true", help="Reuse completed statistics; reread only the four training examples")
    args = ap.parse_args()
    root = args.dataset_root.resolve()
    rows = json.loads((root / "splits.json").read_text(encoding="utf-8"))["splits"]
    positions = {}
    for row in rows:
        if positions.setdefault(row["position_id"], row["split"]) != row["split"]:
            raise ValueError("Position split leakage")
    train = [r for r in rows if r["split"] == "train"]
    if len(train) != 2720 or Counter(r["shape_class"] for r in train) != Counter({c: 680 for c in "ABCD"}):
        raise ValueError("This audit expects the specified 3872-case package")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    pair_mask = adjacent_mask()
    if not np.all(pair_mask.sum(-1) == 29):
        raise AssertionError("Protocol mask mismatch")
    if args.replot:
        saved = json.loads((args.output_dir / "summary.json").read_text(encoding="utf-8"))
        if saved["splits_sha256"] != sha256(root / "splits.json"):
            raise ValueError("Split changed since the audit")
        records = json.loads((args.output_dir / "per_case.json").read_text(encoding="utf-8"))
        selected = [next(r for r in train if r["case_id"] == cid) for cid in saved["example_case_ids"]]
        examples = [audit_case(root, row, pair_mask) for row in selected]
        plot_summary(records, args.output_dir)
        plot_examples(examples, args.output_dir)
        return
    records, examples = [], {}
    for i, row in enumerate(train, 1):
        record, example = audit_case(root, row, pair_mask)
        records.append(record)
        if row["position_id"] == "P55" and row["material_combination_id"] == "M01":
            examples[row["shape_class"]] = (record, example)
        if i % 500 == 0:
            print(f"Training-only audit {i}/{len(train)}", flush=True)
    metrics = [k for k, v in records[0].items() if isinstance(v, (int, float))]
    groups = {"all_train": records}
    groups.update({"shape_" + c: [r for r in records if r["shape_class"] == c] for c in "ABCD"})
    groups.update({"material_" + m: [r for r in records if r["material_combination_id"] == m]
                   for m in sorted({r["material_combination_id"] for r in records})})
    summary = {
        "status": "descriptive_information_audit_not_reconstruction_experiment",
        "dataset_root": str(root), "archive": str(args.archive) if args.archive else None,
        "archive_sha256": sha256(args.archive) if args.archive else None,
        "splits_sha256": sha256(root / "splits.json"), "frequencies_hz": FREQUENCIES.tolist(),
        "cases_read": {"train": len(train), "val": 0, "test": 0},
        "measurement_convention": "q[d,e]=U[d,e]-U[d,(e+1)%32]; omit pairs touching injecting electrodes",
        "retained_pairs_per_frequency": int(pair_mask.sum()),
        "phase_signal_floor": "both amplitudes > 0.01 * per-case/frequency background RMS; not measured hardware noise",
        "phase_energy_identity": "|qV-qB|^2=(|qV|-|qB|)^2+2|qV||qB|(1-cos(delta_phase))",
        "limitations": ["No model training and no reconstruction improvement demonstrated",
                        "Phase-dependent energy is not an information-theoretic independence or Fisher-information estimate",
                        "Raw data are noiseless simulation; hardware phase precision was not measured",
                        "v4 currently uses mean-centered potentials; do not directly compare different gauge/protocol features"],
        "groups": {name: {"case_count": len(group), **{metric: summarize([r[metric] for r in group])
                                                       for metric in metrics}} for name, group in groups.items()},
        "example_case_ids": [examples[c][0]["case_id"] for c in "ABCD"],
    }
    (args.output_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    (args.output_dir / "per_case.json").write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")
    plot_summary(records, args.output_dir)
    plot_examples([examples[c] for c in "ABCD"], args.output_dir)
    print(json.dumps(summary["groups"]["all_train"], ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
