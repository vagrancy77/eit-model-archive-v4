"""Package experiment code, frozen selected weights and reviewable results.

The original dataset, incomplete abandoned runs, large optimizer snapshots and
Python cache files are not included. The package stores checksums for each
delivered file and includes the minimal existing v4 source dependencies.
"""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path


def file_hash(path):
    h = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--study-root', type=Path, default=Path(__file__).resolve().parent)
    p.add_argument('--output-zip', type=Path, required=True)
    a = p.parse_args()
    if a.output_zip.exists():
        raise FileExistsError('Preserve the previous archive and choose a new path')
    study = a.study_root.resolve()
    test_root = study/'runs'/'controlled_v2'/'test_evaluation'
    if not (test_root/'final_summary.json').exists():
        raise ValueError('Complete independent evaluation and analysis before packaging')
    entries = {}
    for path in study.iterdir():
        if path.is_file() and path.suffix in ('.py', '.md', '.json', '.txt'):
            entries['eit_complex_information_study/'+path.name] = path
    for path in (study/'results').rglob('*'):
        if path.is_file():
            entries['eit_complex_information_study/'+str(path.relative_to(study)).replace('\\', '/')] = path
    for root in (study/'runs'/'controlled_v2', study/'runs'/'amplitude_calibration_control'):
        for path in root.rglob('*'):
            if not path.is_file() or '__pycache__' in path.parts:
                continue
            if path.name in ('last.pt',) or path.suffix == '.tmp':
                continue
            entries['eit_complex_information_study/'+str(path.relative_to(study)).replace('\\', '/')] = path
    project = study.parent/'eit_reproduction'
    # comsol_v4.data_v6 and model.py import only the topology backbone directly;
    # the original package initializer opportunistically imports these models.
    files = ['comsol_v4/__init__.py', 'comsol_v4/data_v6.py', 'comsol_v4/model.py',
             'comsol_v4/losses.py', 'comsol_v4/metrics.py',
             'pytorch_eit/__init__.py', 'pytorch_eit/topology_residual_net.py',
             'pytorch_eit/models.py', 'pytorch_eit/multifrequency.py']
    for relative in files:
        path = project/relative
        if not path.is_file():
            raise FileNotFoundError(path)
        entries['eit_reproduction/'+relative] = path
    manifest = {'format': 'eit_complex_information_experiment_delivery_v1',
                'dataset_not_embedded': 'E:/Codex/EIT数据集.zip',
                'checkpoint_policy': 'selected best.pt with embedded normalization/config; optimizer snapshots omitted',
                'files': {name: {'bytes': path.stat().st_size, 'sha256': file_hash(path)}
                          for name, path in sorted(entries.items())}}
    a.output_zip.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(a.output_zip, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=3, allowZip64=True) as archive:
        for name, path in sorted(entries.items()):
            archive.write(path, name)
        archive.writestr('MANIFEST.sha256.json', json.dumps(manifest, ensure_ascii=False, indent=2))
        archive.writestr('README_交付说明.md', '# 复电压 v4 受控实验交付\n\n'
                         '查看 eit_complex_information_study/EXPERIMENT_README.md 和 runs/controlled_v2/test_evaluation/RESULTS.md。\n\n'
                         '代码与原 v4 依赖同级打包，输入数据仍用原 EIT数据集.zip。每组/种子包含 best.pt、归一化、曲线和指标；完整独立测试预测、图片和统计均包含。\n\n'
                         'best.pt 内有推理所需配置和标准化参数；本包不含 last.pt 优化器状态，因此用于复核/推理和从头复训，不用于逐步恢复原优化器轨迹。\n')
    with zipfile.ZipFile(a.output_zip) as archive:
        bad = archive.testzip()
        if bad:
            raise ValueError('ZIP CRC failed: '+bad)
    report = {'path': str(a.output_zip), 'bytes': a.output_zip.stat().st_size,
              'sha256': file_hash(a.output_zip), 'file_count': len(entries)+2, 'zip_crc': 'PASS'}
    a.output_zip.with_suffix('.verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2), flush=True)


if __name__ == '__main__':
    main()
