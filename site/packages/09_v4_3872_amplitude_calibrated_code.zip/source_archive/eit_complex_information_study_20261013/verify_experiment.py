"""Check observability, paired initialization, loss gradients and metric parity."""
import argparse
import json
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import DataLoader
from run_experiment import (ComsolDataset, IdentityNormalizer, row_case_path, variant_features,
                            V4Comsol, compute_loss, forward, fast_metrics, move, seed_all, tensor_hash, write_json)
from comsol_v4.metrics import per_case_metrics


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--dataset-root', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    torch.set_num_threads(2)
    torch.use_deterministic_algorithms(True)
    ds = ComsolDataset(a.dataset_root, 'val', IdentityNormalizer(), limit=8)
    batch = next(iter(DataLoader(ds, batch_size=8)))
    batch['position_id'] = [r['position_id'] for r in ds.rows]
    values = {mode: [] for mode in ('amplitude', 'complex', 'calibrated')}
    for row in ds.rows:
        with np.load(row_case_path(a.dataset_root, row), allow_pickle=False) as z:
            original = variant_features(z['voltage'], z['background_voltage'])
            changed = variant_features(z['voltage'] * np.exp(.3j), z['background_voltage'])
        np.testing.assert_allclose(original['amplitude'], changed['amplitude'], rtol=1e-6, atol=1e-9)
        assert not np.allclose(original['complex'], changed['complex'])
        for mode in values:
            values[mode].append(original[mode])
    fov = torch.from_numpy(ds.fov.astype(np.float32))[None, None].cuda()
    hashes, modes = [], []
    for mode in values:
        seed_all(20261013)
        model = V4Comsol(ds.fov, base=28).cuda()
        hashes.append(tensor_hash(model.state_dict()))
        # Input shape, gradient and numerical checks only; fitting does not use val.
        features = np.stack(values[mode])
        scale = np.maximum(np.abs(features).max(axis=(1, 2, 3), keepdims=True), 1e-8)
        batch['features'] = torch.from_numpy(features/scale)
        b = move(batch)
        model.train()
        out = forward(model, b)
        loss, _ = compute_loss(out, b, fov)
        assert torch.isfinite(loss)
        loss.backward()
        assert all(torch.isfinite(q.grad).all() for q in model.parameters() if q.grad is not None)
        model.eval()
        with torch.no_grad():
            out = forward(model, b)
            actual, expected = fast_metrics(out, b, fov), per_case_metrics(out, b, fov)
            for x, y in zip(actual, expected):
                for key, value in y.items():
                    if isinstance(value, (int, float)):
                        np.testing.assert_allclose(x[key], value, atol=2e-6, rtol=1e-5)
            # Forward accepts measurement tensors only. Labels cannot influence it.
            other = dict(b)
            other['sigma'] = torch.ones_like(b['sigma']) * 9999
            other['eps_r'] = torch.ones_like(b['eps_r']) * .01
            other['mask'] = 1-b['mask']
            altered = forward(model, other)
            for key in ('sigma', 'eps_r', 'probabilities'):
                torch.testing.assert_close(out[key], altered[key], atol=0, rtol=0)
        modes.append({'mode': mode, 'parameters': sum(p.numel() for p in model.parameters()),
                      'finite_outputs': all(torch.isfinite(v).all().item() for v in out.values()),
                      'finite_loss_and_gradient': True, 'metric_parity': True, 'label_independent_forward': True})
        del model, out, loss
        torch.cuda.empty_cache()
    assert len(set(hashes)) == 1
    result = {'status': 'PASS', 'modes': modes, 'same_initialization_hash': hashes[0],
              'amplitude_input_invariant_to_phase_rotation': True,
              'test_split_loaded': False, 'validation_used_only_for_software_check': True}
    a.output.parent.mkdir(parents=True, exist_ok=True)
    write_json(a.output, result)
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    main()
