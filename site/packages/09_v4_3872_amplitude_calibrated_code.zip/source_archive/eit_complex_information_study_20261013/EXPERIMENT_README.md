# v4 复电压输入受控实验

本目录沿用现有 v4 残差注意力 U-Net、直接/拓扑双解码器、SDF、切除/侧壁监督和普通病例保护，研究输入信息的贡献。三个模型各 22,376,674 参数：

- `amplitude`：两频 |qV|、|qB|、|qV|−|qB|，虚部槽置零，不夹带相位。
- `complex`：两频 qV、qB、qV−qB 的实部和虚部。
- `calibrated`：保留 qV/qB 实虚部，将冗余差分槽改成背景校准的相对复变化。

在首次测试评价前增加 `amplitude_calibrated`：只用幅值，采用与复输入相同的背景归一化，保持参数量与预算一致。此控制用于排除归一化本身的贡献，方案记录在 ADDITIONAL_CONTROL_PLAN.json。它在 runs/amplitude_calibration_control 单独训练三种子，每种 40 轮。

q 是相邻电极电压差。每个激励删除触及注入/返回电极的测量对，所有组每频使用 928 个读数。该转换与旧 v4 均值参考接口不同，因此本轮不直接复用旧权重。

统一骨干、损失、参数量、同种子初始权重、数据顺序、40 轮训练与验证选模预算。三种子：20261013、20261014、20261015。使用 RTX 4060 / PyTorch 2.9.1+cu130；模型 BF16、损失与指标 FP32。严格确定性 CUDA，原中位数算子改用稳定排序取下中位数；数值定义保持一致。

原数据 `E:\Codex\EIT数据集.zip` 已解压到 `E:\Codex\eit_dataset_audit_20261010\extracted\V6_3872_Minimal`。训练 2720、验证 576、测试 576，位置组相互隔离；数据和划分不修改。输入规范化只用训练集拟合。

## 程序

| 文件 | 功能 |
| --- | --- |
| audit_complex_information.py | 训练集描述统计；不训练网络 |
| complex_features_prototype.py | 相对幅相特征原型及数值行为检查 |
| benchmark_v4.py | 合成输入计时；不是性能结果 |
| verify_experiment.py | 幅值对照不含相位、初始化一致、指标与原版一致、标签不进入前向等检查 |
| run_experiment.py | 三组训练、仅 train/val、断点恢复、保存规范化和权重 |
| plot_experiment.py | 每 5 轮更新曲线和固定验证病例预览 |
| EVALUATION_PLAN.json | 测试前固定的指标与噪声/相位漂移条件 |
| evaluate_experiment.py | 全部训练完成后，冻结检查点进行独立评价 |
| analyze_experiment.py | 边界/凹陷指标、三种子与位置组配对 bootstrap、最终图片和报告 |
| infer_controlled.py | 只读测量与频率的单病例推理 |

`runs/controlled_v2/protocol.json` 是这轮固定训练配置；同目录每个方法/种子的 best.pt 用验证总损失选出，last.pt 用于继续原训练，history.json 保存曲线。程序拒绝在同目录使用不同配置继续。

## 运行

在 PowerShell 中，工作目录为本目录。GPU Python：`E:\conda-envs\pytorch-gpu\python.exe -s`。绘图/边界统计使用已有 `E:\Anaconda\python.exe`，因为 GPU 环境不含 SciPy/matplotlib，无需为训练安装第二套依赖。

```powershell
& E:\conda-envs\pytorch-gpu\python.exe -s .\run_experiment.py --dataset-root E:\Codex\eit_dataset_audit_20261010\extracted\V6_3872_Minimal --output-dir .\runs\controlled_v2 --epochs 40 --batch-size 64 --base 28 --seeds 20261013 20261014 20261015

& E:\conda-envs\pytorch-gpu\python.exe -s .\run_experiment.py --dataset-root E:\Codex\eit_dataset_audit_20261010\extracted\V6_3872_Minimal --output-dir .\runs\amplitude_calibration_control --modes amplitude_calibrated --epochs 40 --batch-size 64 --base 28 --seeds 20261013 20261014 20261015

& E:\conda-envs\pytorch-gpu\python.exe -s .\evaluate_experiment.py --dataset-root E:\Codex\eit_dataset_audit_20261010\extracted\V6_3872_Minimal --run-root .\runs\controlled_v2 --additional-run-root .\runs\amplitude_calibration_control --output-dir .\runs\controlled_v2\test_evaluation --split test

& E:\Anaconda\python.exe .\analyze_experiment.py --evaluation-root .\runs\controlled_v2\test_evaluation
```

单病例推理可使用仅包含 `voltage`、`background_voltage`、`frequencies_hz` 的 NPZ，电压尺寸均为 [2,32,32]，不需要材料、掩膜或几何真值。该推理仍要求同一测量协议和二维坐标域。

## 结果解释

这轮先检验相位信息和表达方式，不包含新学习式相位门控，也未启用匹配 FEM 物理残差。不能据此宣称已完成新的物理与拓扑感知模型或临床泛化实验。

最终需分别判断：内凹 IoU/边界/深度是否改善；凸形病例是否满足预设 -0.01 IoU 非劣界；材料参数误差是否改善；相位漂移是否破坏收益。三个问题可能给出不同结论，不能将 εr 估计提升直接当作内凹边界提升。

当前数据的接触阻抗节点未生效，实际边界为电流端子模型；匹配正问题算子未交付，故默认物理残差关闭。既有数据主要是有限的单目标形状与材料系列，最终结论限定在这批仿真及预设测量扰动内。
