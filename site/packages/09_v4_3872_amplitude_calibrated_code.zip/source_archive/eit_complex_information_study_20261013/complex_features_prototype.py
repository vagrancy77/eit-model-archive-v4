"""Untrained, measurement-only feature prototype for a controlled v4 extension.

This module neither changes the dataset nor accepts reconstruction truth. It
does not replace comsol_v4.data_v6 or provide a trained model. Every proposed
ablation must use the same measurement operator and masking convention.
"""
from __future__ import annotations

import numpy as np


def measurement_mask():
    drive, electrode = np.indices((32, 32))
    ret, neighbor = (drive + 1) % 32, (electrode + 1) % 32
    return ~((electrode == drive) | (electrode == ret)
             | (neighbor == drive) | (neighbor == ret))


def build_inputs(voltage, background, relative_floor=.01):
    """Return unnormalized channels in [channel, drive, measurement-pair] order.

    raw_complex: 12 channels, V/B/dV real+imag, two frequencies each.
    amplitude_only: 6 channels, |V|/|B|/(|V|-|B|), two frequencies each.
    phase_branch: 8 channels, sin(psi)/(1-cos(psi))/Re(r)/Im(r), two frequencies.
    signal_weight: 2 channels from measurement amplitude, NOT learned confidence.
    valid_pairs: 1 channel, fixed protocol mask shared by all methods.

    V and B in this docstring mean adjacent electrode differences. The default
    1%-RMS floor is a numerical prototype setting, not hardware calibration.
    Fit feature scaling on the official training partition only before use.
    """
    v, b = np.asarray(voltage), np.asarray(background)
    if v.shape != (2, 32, 32) or b.shape != v.shape:
        raise ValueError("Expected two frequencies, 32 drives and 32 electrodes")
    if not all(np.iscomplexobj(a) and np.isfinite(a).all() for a in (v, b)):
        raise ValueError("Finite complex voltage and reference are required")
    if not np.isfinite(relative_floor) or relative_floor <= 0:
        raise ValueError("Positive relative floor required")
    qv = v - np.roll(v, -1, axis=-1)
    qb = b - np.roll(b, -1, axis=-1)
    dq = qv - qb
    valid = measurement_mask()[None]
    av, ab = np.abs(qv), np.abs(qb)
    rms = np.sqrt((ab * ab * valid).sum((1, 2), keepdims=True) / valid.sum())
    if np.any(rms <= 0):
        raise ValueError("Zero background signal")
    tau = relative_floor * rms
    r = dq * qb.conj() / (ab * ab + tau * tau)
    product = qv * qb.conj()
    unit_product = np.divide(product, np.abs(product), out=np.ones_like(product),
                             where=np.abs(product) > 0)
    weight = (ab * ab / (ab * ab + tau * tau)) * (av * av / (av * av + tau * tau))
    raw = np.concatenate((qv.real, qv.imag, qb.real, qb.imag, dq.real, dq.imag))
    amp = np.concatenate((av, ab, av - ab))
    phase = np.concatenate((unit_product.imag, 1 - unit_product.real, r.real, r.imag))
    return {
        "raw_complex": (raw * valid).astype(np.float32),
        "amplitude_only": (amp * valid).astype(np.float32),
        "phase_branch": (phase * np.tile(weight, (4, 1, 1)) * valid).astype(np.float32),
        "signal_weight": (weight * valid).astype(np.float32),
        "valid_pairs": valid.astype(np.float32),
    }


def self_check():
    rng = np.random.default_rng(20261013)
    b = rng.normal(size=(2, 32, 32)) + 1j * rng.normal(size=(2, 32, 32))
    v = b + .03 * (rng.normal(size=b.shape) + 1j * rng.normal(size=b.shape))
    outputs = build_inputs(v, b)
    assert {k: a.shape for k, a in outputs.items()} == {
        "raw_complex": (12, 32, 32), "amplitude_only": (6, 32, 32),
        "phase_branch": (8, 32, 32), "signal_weight": (2, 32, 32),
        "valid_pairs": (1, 32, 32)}
    assert all(np.isfinite(a).all() for a in outputs.values())
    # Different arbitrary additive reference potentials per drive must cancel.
    gauge = (rng.normal(size=(2, 32, 1)) + 1j * rng.normal(size=(2, 32, 1)))
    changed = build_inputs(v + gauge, b - 2 * gauge)
    for key in outputs:
        np.testing.assert_allclose(outputs[key], changed[key], atol=1e-7, rtol=1e-6)
    # A common phase/gain rotation cancels in relative features, but absolute
    # Cartesian features intentionally retain that information.
    gain = 1.3 * np.exp(.7j)
    changed = build_inputs(v * gain, b * gain)
    for key in ("phase_branch", "signal_weight", "valid_pairs"):
        np.testing.assert_allclose(outputs[key], changed[key], atol=1e-7, rtol=1e-6)
    # A true amplitude-only control must remain unchanged if only measurement
    # phase changes. |V-B| would FAIL this check and must not enter that control.
    changed = build_inputs(v * np.exp(.4j), b)
    np.testing.assert_allclose(outputs["amplitude_only"], changed["amplitude_only"], atol=1e-7, rtol=1e-6)
    assert not np.allclose(outputs["phase_branch"], changed["phase_branch"])
    # Very small/zero measurement channels must remain finite.
    zero = build_inputs(np.zeros_like(v), b)
    assert all(np.isfinite(a).all() for a in zero.values())
    assert np.all(zero["signal_weight"] == 0)
    print("PASS: dimensions, finite values, gauge invariance, common calibration cancellation, true amplitude-only control, low-signal handling")


if __name__ == "__main__":
    self_check()
