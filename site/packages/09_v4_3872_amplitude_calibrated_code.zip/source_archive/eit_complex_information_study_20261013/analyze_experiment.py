"""Boundary analysis, paired seed/position statistics and final figures."""
from __future__ import annotations
import argparse
import json
import hashlib
from pathlib import Path

import numpy as np
from scipy.ndimage import binary_erosion, distance_transform_edt
from scipy.spatial import ConvexHull, QhullError
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path as PolygonPath
from matplotlib import font_manager

LABELS = {'amplitude': '幅值输入', 'complex': '完整实虚部', 'calibrated': '背景校准复输入',
          'amplitude_calibrated': '背景校准幅值'}
COLORS = {'amplitude': '#1971c2', 'complex': '#e67700', 'calibrated': '#2b8a3e',
          'amplitude_calibrated': '#862e9c'}


def write_json(path, payload):
    Path(path).write_text(json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')


def hull(mask):
    points = np.argwhere(mask)
    if len(points) < 3:
        return mask.copy()
    try:
        polygon = ConvexHull(points)
    except QhullError:
        return mask.copy()
    yy, xx = np.indices(mask.shape)
    coords = np.stack((yy.ravel(), xx.ravel()), -1)
    return PolygonPath(points[polygon.vertices]).contains_points(coords, radius=1e-6).reshape(mask.shape) | mask


def boundary_metrics(pred, truth, fov, pixel_mm):
    pred, truth = pred & fov, truth & fov
    pb = pred & ~binary_erosion(pred)
    tb = truth & ~binary_erosion(truth)
    if pb.any() and tb.any():
        a = distance_transform_edt(~pb, sampling=pixel_mm)[tb]
        b = distance_transform_edt(~tb, sampling=pixel_mm)[pb]
        hd95, asd = np.quantile(np.concatenate((a, b)), .95), .5*(a.mean()+b.mean())
    else:
        # Penalize an empty reconstruction using the full image diagonal.
        hd95 = asd = np.hypot(*np.array(fov.shape)*pixel_mm)
    th, ph = hull(truth)&fov, hull(pred)&fov
    td, pd = th&~truth, ph&~pred
    true_depth = float(distance_transform_edt(th)[td].max()) if td.any() else 0.
    pred_depth = float(distance_transform_edt(ph)[pd].max()) if pd.any() else 0.
    # Rasterized convex masks can have shallow stair-step defects. Report
    # direction only if true defect depth >= 1.5 pixels and >= 3 pixels area.
    meaningful = true_depth >= 1.5 and td.sum() >= 3
    direction = cosine = None
    if meaningful:
        direction = 0.
        if pred_depth >= 1.5 and pd.sum() >= 3:
            tv = np.argwhere(td).mean(0)-np.argwhere(th).mean(0)
            pv = np.argwhere(pd).mean(0)-np.argwhere(ph).mean(0)
            denom = np.linalg.norm(tv)*np.linalg.norm(pv)
            if denom > 1e-9:
                cosine = float(np.clip(np.dot(tv, pv)/denom, -1, 1))
                direction = float(cosine > .5)  # Within 60 degrees, prespecified.
    return {'hd95_mm': float(hd95), 'asd_mm': float(asd),
            'true_concavity_depth_mm': true_depth*pixel_mm,
            'pred_concavity_depth_mm': pred_depth*pixel_mm,
            'concavity_depth_abs_error_mm': abs(pred_depth-true_depth)*pixel_mm,
            'convex_hull_defect_recall': float((td&pd).sum()/td.sum()) if meaningful else None,
            'convex_hull_defect_iou': float((td&pd).sum()/max((td|pd).sum(), 1)) if meaningful else None,
            'notch_direction_correct': direction, 'notch_direction_cosine': cosine,
            'pred_convex_hull_defect_area_fraction': float(pd.sum()/max(ph.sum(), 1)),
            'empty_prediction': float(not pred.any())}


def enrich_clean(path):
    cached = path/'metrics_with_boundaries.json'
    source_hashes = {name: hashlib.file_digest((path/name).open('rb'), 'sha256').hexdigest()
                     for name in ('metrics.json', 'predictions.npz')}
    if cached.exists():
        report = json.loads(cached.read_text(encoding='utf-8'))
        if report.get('source_hashes') == source_hashes and all('hd95_mm' in r for r in report['per_case']):
            print(f'Reuse boundary metrics: {path.parent.name}', flush=True)
            return report
    report = json.loads((path/'metrics.json').read_text(encoding='utf-8'))
    with np.load(path/'predictions.npz', allow_pickle=False) as z:
        ids = list(z['case_ids'])
        assert ids == [r['case_id'] for r in report['per_case']]
        pixel_mm = float(np.diff(z['x']).mean()*1000)
        predictions = z['probabilities'].argmax(1) != 0
        targets = z['truth_mask'][:, 0] > .5
        fov = z['fov'].copy()
        for i, row in enumerate(report['per_case']):
            row.update(boundary_metrics(predictions[i], targets[i], fov, pixel_mm))
    report['source_hashes'] = source_hashes
    write_json(path/'metrics_with_boundaries.json', report)
    print(f'Boundary metrics complete: {path.parent.name}', flush=True)
    return report


def groups(records, name):
    if name == 'all': return records
    if name == 'convex_A': return [r for r in records if r['shape_class'] == 'A']
    if name in ('concave_all', 'concave_BCDE'): return [r for r in records if r['shape_class'] in 'BCDE']
    if name == 'concave_BCD': return [r for r in records if r['shape_class'] in 'BCD']
    if name in tuple('ABCDE'): return [r for r in records if r['shape_class'] == name]
    raise ValueError('Unknown evaluation group: '+name)


def seed_sd(values):
    return float(np.std(values, ddof=1)) if len(values) > 1 else 0.


def mean_metric(records, metric):
    vals = [r[metric] for r in records if isinstance(r.get(metric), (int, float))]
    return float(np.mean(vals)) if vals else None


def paired_bootstrap(base, variant, group, metric, rng):
    if not base or not variant: return None
    if [r['seed'] for r in base] != [r['seed'] for r in variant]:
        raise ValueError('Paired bootstrap requires identical training seeds')
    arrays = []
    for a, b in zip(base, variant):
        aa, bb = groups(a['per_case'], group), groups(b['per_case'], group)
        bd = {r['case_id']: r for r in bb}
        if set(bd) != {r['case_id'] for r in aa}: raise ValueError('Paired case sets differ')
        values = {}
        for row in aa:
            other = bd[row['case_id']]
            x, y = row.get(metric), other.get(metric)
            if isinstance(x, (int, float)) and isinstance(y, (int, float)):
                values.setdefault(row['position_id'], []).append(y-x)
        arrays.append({p: np.mean(v) for p, v in values.items()})
    positions = sorted(set.intersection(*(set(a) for a in arrays)))
    if not positions:
        return None
    matrix = np.array([[a[p] for p in positions] for a in arrays])
    seeds = rng.integers(0, len(arrays), size=(5000, len(arrays)))
    positions_draw = rng.integers(0, len(positions), size=(5000, len(positions)))
    draws = matrix[seeds[:, :, None], positions_draw[:, None, :]].mean((1, 2))
    return {'mean_difference': float(matrix.mean()), 'ci95': np.quantile(draws, [.025, .975]).tolist(),
            'seed_count': len(arrays), 'position_group_count': len(positions),
            'per_seed_difference': matrix.mean(1).tolist()}


def configure_font():
    font = Path('C:/Windows/Fonts/msyh.ttc')
    if font.exists():
        font_manager.fontManager.addfont(str(font))
        plt.rcParams['font.family'] = 'Microsoft YaHei'
    plt.rcParams['axes.unicode_minus'] = False


def figures(root, reports, summary):
    configure_font()
    modes = list(summary['modes'])
    seeds = sorted({r['seed'] for r in reports})
    # Freeze displayed seed and cases independently of reconstruction scores.
    seed = seeds[0]
    files = {}
    for mode in modes:
        with np.load(root/f'{mode}_seed{seed}'/'clean'/'predictions.npz', allow_pickle=False) as z:
            files[mode] = {key: z[key].copy() for key in ('case_ids', 'positions', 'shape_classes',
                          'material_combinations', 'truth_mask', 'truth_sigma', 'truth_eps_r',
                          'probabilities', 'sigma', 'eps_r', 'fov')}
    first = files[modes[0]]
    ids = list(first['case_ids'])
    position_ids = sorted(set(first['positions']), key=lambda x: int(x[1:]))[:2]
    # Select M01 within each shape/position before inspecting predictions.
    chosen = []
    classes = sorted(set(first['shape_classes']))
    for cls in classes:
        for position in position_ids:
            chosen.append(next(i for i, (c, p, m) in enumerate(zip(first['shape_classes'], first['positions'], first['material_combinations']))
                               if c == cls and p == position and m == 'M01'))
    columns = len(modes)+1
    fig, axes = plt.subplots(len(chosen), columns, figsize=(3.5*columns, 2.6*len(chosen)), squeeze=False, constrained_layout=True)
    for row, i in enumerate(chosen):
        truth = first['truth_mask'][i, 0] > .5
        axes[row, 0].imshow(truth, origin='lower', cmap='Greys', vmin=0, vmax=1)
        axes[row, 0].set_ylabel(ids[i], fontsize=10)
        axes[row, 0].set_title('真值', fontsize=10)
        for col, mode in enumerate(modes, 1):
            pred = files[mode]['probabilities'][i].argmax(0) != 0
            inter, union = (pred&truth).sum(), (pred|truth).sum()
            axes[row, col].imshow(pred, origin='lower', cmap='Greys', vmin=0, vmax=1)
            axes[row, col].contour(truth, [.5], colors='#e03131', linewidths=.7)
            axes[row, col].set_title(f'{LABELS[mode]} / IoU {inter/max(union,1):.3f}', fontsize=10)
        for ax in axes[row]:
            ax.set_xticks([])
            ax.set_yticks([])
    fig.suptitle(f'独立 {summary["split"]} 病例对照：预先固定 seed {seed}，不挑最佳病例\n黑色：重建病灶；红线：真值边界', fontsize=15)
    fig.savefig(root/'final_shape_comparison.png', dpi=140)
    plt.close(fig)
    fig, axes = plt.subplots(len(chosen), columns, figsize=(3.5*columns, 2.6*len(chosen)), squeeze=False, constrained_layout=True)
    for row, i in enumerate(chosen):
        truth = first['truth_mask'][i, 0] > .5
        points = np.argwhere(truth)
        lo = np.maximum(points.min(0)-7, 0)
        hi = np.minimum(points.max(0)+8, truth.shape)
        images = [truth]+[files[m]['probabilities'][i].argmax(0) != 0 for m in modes]
        for col, (image, title) in enumerate(zip(images, ['真值']+[LABELS[m] for m in modes])):
            ax = axes[row, col]
            ax.imshow(image, origin='lower', cmap='Greys', vmin=0, vmax=1)
            if col:
                ax.contour(truth, [.5], colors='#e03131', linewidths=1.)
            ax.set(xlim=(lo[1]-.5, hi[1]-.5), ylim=(lo[0]-.5, hi[0]-.5), title=title)
            ax.set_xticks([])
            ax.set_yticks([])
        axes[row, 0].set_ylabel(ids[i], fontsize=10)
    fig.suptitle('相同固定病例的边界放大图\n每行统一按真值框裁切；完整视野另见 final_shape_comparison.png', fontsize=15)
    fig.savefig(root/'final_boundary_zoom.png', dpi=140)
    plt.close(fig)
    # One preselected case per available class, including E.
    chosen4 = chosen[::len(position_ids)]
    fig, axes = plt.subplots(len(chosen4), 2*columns, figsize=(3.*2*columns, 2.75*len(chosen4)), squeeze=False, constrained_layout=True)
    for row, i in enumerate(chosen4):
        fov = first['fov'].astype(bool)
        truth_sigma, truth_eps = first['truth_sigma'][i, 0], first['truth_eps_r'][i, 0]
        for offset, field, truth, cmap in ((0, 'sigma', truth_sigma, 'viridis'), (columns, 'eps_r', truth_eps, 'magma')):
            lo, hi = truth[fov].min(), truth[fov].max()
            if hi <= lo:
                hi = lo+1e-6
            images = [truth]+[files[m][field][i, 0] for m in modes]
            titles = ['真值']+[LABELS[m] for m in modes]
            for col, (image, title) in enumerate(zip(images, titles), offset):
                ax = axes[row, col]
                im = ax.imshow(np.where(fov, image, np.nan), origin='lower', cmap=cmap, vmin=lo, vmax=hi)
                ax.set_title(f'{ids[i]}\n{field} / {title}', fontsize=9)
                ax.set_xticks([])
                ax.set_yticks([])
                if col == offset+columns-1:
                    fig.colorbar(im, ax=list(axes[row, offset:offset+columns]), shrink=.75,
                                 label='S/m' if field == 'sigma' else 'εr（无量纲）')
    fig.suptitle('10 kHz 电导率与相对介电常数：各组共用真值色阶（超出色阶会截断）', fontsize=16)
    fig.savefig(root/'final_material_comparison.png', dpi=150)
    plt.close(fig)
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.8), constrained_layout=True)
    metrics = ('foreground_iou', 'sigma_lesion_nrmse_10000Hz', 'eps_r_lesion_nrmse_10000Hz')
    titles = ('病灶 IoU（越大越好）', '病灶 σ NRMSE / 10 kHz（越小越好）', '病灶 εr NRMSE / 10 kHz（越小越好）')
    for ax, metric, title in zip(axes, metrics, titles):
        width = .8/len(modes)
        offsets = (np.arange(len(modes))-(len(modes)-1)/2)*width
        for offset, mode in zip(offsets, modes):
            means, stds = [], []
            for group in ('all', 'convex_A', 'concave_all'):
                values = [mean_metric(groups(r['per_case'], group), metric) for r in reports if r['mode'] == mode]
                means.append(np.mean(values))
                stds.append(seed_sd(values))
            ax.bar(np.arange(3)+offset, means, width, yerr=stds, capsize=3, color=COLORS[mode], label=LABELS[mode])
        ax.set(title=title, xticks=np.arange(3), xticklabels=['全部', '凸形 A', '全部内凹'])
        ax.grid(axis='y', alpha=.2)
    axes[0].legend(fontsize=9)
    fig.suptitle(f'独立 {summary["split"]} 统计：{len(seeds)} 个种子；误差线为种子间标准差（单种子为0）', fontsize=14)
    fig.savefig(root/'final_metrics.png', dpi=160)
    plt.close(fig)
    conditions = list(summary['noise_scenarios'])
    fig, ax = plt.subplots(figsize=(13, 5.8), constrained_layout=True)
    for mode in modes:
        values = [np.mean(summary['noise_scenarios'][s][mode]['concave_all_foreground_iou_per_seed']) for s in conditions]
        ax.plot(np.arange(len(values)), values, marker='o', color=COLORS[mode], label=LABELS[mode])
    ax.set(xticks=np.arange(len(conditions)), xticklabels=conditions, ylabel='内凹病例 IoU',
           title='固定模型的噪声/相位标定压力测试；读数扰动实现对各组一致')
    ax.tick_params(axis='x', labelrotation=20)
    ax.grid(alpha=.2)
    ax.legend()
    fig.savefig(root/'noise_stress_comparison.png', dpi=150)
    plt.close(fig)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--evaluation-root', type=Path, required=True)
    a = p.parse_args()
    done = json.loads((a.evaluation_root/'evaluation_completed.json').read_text(encoding='utf-8'))
    plan = json.loads((a.evaluation_root/'evaluation_plan.json').read_text(encoding='utf-8'))
    protocol = plan['training_protocol']
    clean = []
    for seed in protocol['seeds']:
        for mode in protocol['modes']:
            clean.append(enrich_clean(a.evaluation_root/f'{mode}_seed{seed}'/'clean'))
    classes = sorted({r['shape_class'] for r in clean[0]['per_case']})
    evaluation_groups = ('all', 'convex_A', 'concave_all', 'concave_BCD') + (('concave_BCDE', 'E') if 'E' in classes else ())
    metrics = ('foreground_iou', 'foreground_dice', 'mean_iou_present_classes',
               'sigma_ssim_10000Hz', 'sigma_ssim_50000Hz', 'sigma_nrmse_10000Hz', 'sigma_nrmse_50000Hz',
               'eps_r_nrmse_10000Hz', 'eps_r_nrmse_50000Hz',
               'sigma_lesion_nrmse_10000Hz', 'sigma_lesion_nrmse_50000Hz',
               'eps_r_lesion_nrmse_10000Hz', 'eps_r_lesion_nrmse_50000Hz',
               'hd95_mm', 'asd_mm', 'concavity_depth_abs_error_mm', 'convex_hull_defect_recall',
               'convex_hull_defect_iou', 'notch_direction_correct', 'pred_convex_hull_defect_area_fraction', 'empty_prediction')
    summary = {'split': done['split'], 'test_used_for_selection': False, 'modes': {},
               'noise_scenarios': {}, 'paired_differences': {}, 'selection': protocol['selection'],
               'case_count_per_seed': len(clean[0]['per_case']), 'seed_count': len(protocol['seeds']),
               'limitations': ['Synthetic fixed protocol and shape/material family; not clinical generalization',
                               'Representation ablation, not a learned reliability fusion model',
                               'No matched FEM physics residual is active',
                               f'Bootstrap includes {len(protocol["seeds"])} training seeds and the available position groups; a single seed cannot establish training variability',
                               'Complex and calibrated inputs contain equivalent raw observations; extra information versus amplitude only comes from phase']}
    for mode in protocol['modes']:
        reports = sorted([r for r in clean if r['mode'] == mode], key=lambda r: r['seed'])
        summary['modes'][mode] = {'selected_epochs': [r['selected_epoch'] for r in reports], 'groups': {}}
        for group in evaluation_groups:
            entries = {}
            for metric in metrics:
                values = [mean_metric(groups(r['per_case'], group), metric) for r in reports]
                if all(v is not None for v in values):
                    entries[metric] = {'mean': float(np.mean(values)), 'seed_sd': seed_sd(values), 'per_seed': values}
            summary['modes'][mode]['groups'][group] = entries
            summary['modes'][mode].setdefault('metric_sample_counts', {})[group] = {
                metric: [sum(isinstance(v.get(metric), (int, float)) for v in groups(r['per_case'], group))
                         for r in reports] for metric in metrics}
    for mode in protocol['modes']:
        reports = sorted([r for r in clean if r['mode'] == mode], key=lambda r: r['seed'])
        per_class = {}
        for cls in classes:
            per_class[cls] = {}
            for metric in metrics:
                values = [mean_metric([v for v in r['per_case'] if v['shape_class'] == cls], metric) for r in reports]
                if all(v is not None for v in values):
                    per_class[cls][metric] = {'mean': float(np.mean(values)), 'seed_sd': seed_sd(values),
                                             'per_seed': values}
        summary['modes'][mode]['shape_classes'] = per_class
    rng = np.random.default_rng(2026101311)
    base = sorted([r for r in clean if r['mode'] == 'amplitude'], key=lambda r: r['seed'])
    for mode in ('complex', 'calibrated'):
        variant = sorted([r for r in clean if r['mode'] == mode], key=lambda r: r['seed'])
        if not base or not variant: continue
        summary['paired_differences'][mode+'_minus_amplitude'] = {
            group: {metric: paired_bootstrap(base, variant, group, metric, rng) for metric in metrics}
            for group in evaluation_groups}
    if 'amplitude_calibrated' in protocol['modes']:
        amp_calibrated = sorted([r for r in clean if r['mode'] == 'amplitude_calibrated'], key=lambda r: r['seed'])
        complex_calibrated = sorted([r for r in clean if r['mode'] == 'calibrated'], key=lambda r: r['seed'])
        for key, a_reports, b_reports in (
                ('amplitude_calibrated_minus_amplitude', base, amp_calibrated),
                ('calibrated_minus_amplitude_calibrated', amp_calibrated, complex_calibrated)):
            if not a_reports or not b_reports: continue
            summary['paired_differences'][key] = {
                group: {metric: paired_bootstrap(a_reports, b_reports, group, metric, rng) for metric in metrics}
                for group in evaluation_groups}
    for condition in done['conditions']:
        entry = {}
        for mode in protocol['modes']:
            reports = [json.loads((a.evaluation_root/f'{mode}_seed{s}'/condition/'metrics.json').read_text(encoding='utf-8')) for s in protocol['seeds']]
            entry[mode] = {f'{group}_foreground_iou_per_seed': [mean_metric(groups(r['per_case'], group), 'foreground_iou') for r in reports]
                           for group in evaluation_groups}
        summary['noise_scenarios'][condition] = entry
    write_json(a.evaluation_root/'final_summary.json', summary)
    figures(a.evaluation_root, clean, summary)
    counts = protocol.get('final_dataset_contract', {}).get('splits', {})
    lines = ['# 幅值与完整复电压：v4 同条件实验结果', '',
             f'本轮完成 {len(protocol["modes"])} 组 × {len(protocol["seeds"])} 种子 × {protocol["epochs"]} 轮。训练/验证数量以 protocol.json 为准：{counts}；按验证总损失选模，对 {done["split"]} 的 {summary["case_count_per_seed"]} 例冻结评价。测试集不用于选模；若本次为 val，不能当作独立测试结论。', '',
             '模型结构与预算见 protocol.json；校准组替换差分表示，保留原始复电压与复背景，未加入学习式相位门控。', '',
             '| 输入 | 全部 IoU | 凸形 A IoU | 全部内凹 IoU | 内凹 HD95 (mm) | 病灶 εr NRMSE / 10 kHz |',
             '| --- | ---: | ---: | ---: | ---: | ---: |']
    for mode in protocol['modes']:
        g = summary['modes'][mode]['groups']
        lines.append(f'| {LABELS[mode]} | {g["all"]["foreground_iou"]["mean"]:.4f} | {g["convex_A"]["foreground_iou"]["mean"]:.4f} | {g["concave_all"]["foreground_iou"]["mean"]:.4f} | {g["concave_all"]["hd95_mm"]["mean"]:.3f} | {g["all"]["eps_r_lesion_nrmse_10000Hz"]["mean"]:.4f} |')
    lines += ['', '| 输入 | '+' | '.join(cls+' IoU' for cls in classes)+' | σ SSIM / 10 kHz | σ SSIM / 50 kHz |',
              '| --- | '+' ---: |'*(len(classes)+2)]
    for mode in protocol['modes']:
        groups_ = summary['modes'][mode]
        class_iou = [groups_['shape_classes'][cls]['foreground_iou']['mean'] for cls in classes]
        scores = groups_['groups']['all']
        lines.append(f'| {LABELS[mode]} | '+ ' | '.join(f'{value:.4f}' for value in class_iou)
                     + f' | {scores["sigma_ssim_10000Hz"]["mean"]:.4f} | {scores["sigma_ssim_50000Hz"]["mean"]:.4f} |')
    lines += ['', '## 配对差和普通病例保护', '', '按种子和 position_id 分层配对 bootstrap，5000 次；同一位置内病例一起抽样。普通病例 IoU 非劣界值预先设为 -0.01。']
    for mode in ('complex', 'calibrated'):
        if mode+'_minus_amplitude' not in summary['paired_differences']: continue
        diff = summary['paired_differences'][mode+'_minus_amplitude']
        d = diff['concave_all']['foreground_iou']
        ordinary = diff['convex_A']['foreground_iou']
        passed = ordinary['ci95'][0] > -.01
        lines += ['', f'{LABELS[mode]}相对幅值：内凹 IoU 差 {d["mean_difference"]:+.4f}，95% CI [{d["ci95"][0]:+.4f}, {d["ci95"][1]:+.4f}]；普通 A 差 {ordinary["mean_difference"]:+.4f}，95% CI [{ordinary["ci95"][0]:+.4f}, {ordinary["ci95"][1]:+.4f}]。本轮普通病例非劣检查：{"通过" if passed else "未通过/证据不足"}。']
    if 'calibrated_minus_amplitude_calibrated' in summary['paired_differences']:
        lines += ['', '## 排除背景归一化的贡献', '',
                  '校准幅值对照不含相位；与校准复输入比较可帮助区分相位信息和背景归一化的贡献。具体预注册时间、预算与种子以本轮 protocol.json 为准。']
        diffs = summary['paired_differences']['calibrated_minus_amplitude_calibrated']
        for group, label in (('concave_all', '内凹'), ('convex_A', '普通凸形')):
            d = diffs[group]['foreground_iou']
            lines += ['', f'校准复输入相对校准幅值：{label} IoU 差 {d["mean_difference"]:+.4f}，95% CI [{d["ci95"][0]:+.4f}, {d["ci95"][1]:+.4f}]。']
    lines += ['', '## 文件与解释边界', '',
              '图片：final_shape_comparison.png、final_boundary_zoom.png、final_material_comparison.png、final_metrics.png、noise_stress_comparison.png。完整统计：final_summary.json；各方法/种子/条件的 metrics.json 和原始预测另存。', '',
              'IoU/SSIM 不同于 KTC 挑战定义。HD95 使用两方向边界距离合并的第 95 百分位，ASD 是两方向平均距离的均值；空预测按视野对角线惩罚。', '',
              '内凹缺陷定义为凸包减病灶；深度为缺陷点到凸包外部的最大距离。方向仅对真值缺陷深度≥1.5像素、面积≥3像素的病例统计；预测同样满足该条件且缺陷方向夹角<60°才记为正确。普通病例不以这个方向指标评分。', '',
              '当前结果是无噪声合成数据加预设测量扰动的受控实验，没有临床真实数据、没有有效有限接触阻抗 CEM 验证、没有实际 FEM 残差。复数或双频输入并非首次提出。是否值得进一步做可靠性融合，应结合三种种子的内凹/普通病例差、材料误差和相位漂移曲线判断。', '']
    (a.evaluation_root/'RESULTS.md').write_text('\n'.join(lines), encoding='utf-8')
    print(json.dumps({mode: summary['modes'][mode]['groups']['all']['foreground_iou'] for mode in protocol['modes']}, indent=2), flush=True)


if __name__ == '__main__':
    main()
