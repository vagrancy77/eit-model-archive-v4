"""Plot progressive paired training and fixed validation examples using CPU Python."""
import argparse
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

LABELS = {'amplitude': '幅值输入', 'complex': '完整实虚部', 'calibrated': '背景校准复输入',
          'amplitude_calibrated': '背景校准幅值'}
COLORS = {'amplitude': '#1971c2', 'complex': '#e67700', 'calibrated': '#2b8a3e',
          'amplitude_calibrated': '#862e9c'}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output-root', type=Path, required=True)
    a = p.parse_args()
    font = Path('C:/Windows/Fonts/msyh.ttc')
    if font.exists():
        font_manager.fontManager.addfont(str(font))
        plt.rcParams['font.family'] = 'Microsoft YaHei'
    plt.rcParams['axes.unicode_minus'] = False
    histories = []
    for path in a.output_root.glob('*_seed*/history.json'):
        record = json.loads(path.read_text(encoding='utf-8'))
        record['path'] = path.parent
        histories.append(record)
    if not histories:
        return
    fig, axes = plt.subplots(2, 2, figsize=(14, 9), constrained_layout=True)
    for record in histories:
        h, mode, seed = record['history'], record['mode'], record['seed']
        x = [v['epoch'] for v in h]
        label = f'{LABELS[mode]} / seed {seed}'
        axes[0, 0].plot(x, [v['val_loss'] for v in h], color=COLORS[mode], alpha=.75, label=label)
        for ax, group in zip((axes[0, 1], axes[1, 0], axes[1, 1]), ('all', 'convex_A', 'concave_all')):
            ax.plot(x, [v['val_metrics'][group if group in v['val_metrics'] else 'concave_BCD']['foreground_iou'] for v in h], color=COLORS[mode], alpha=.75, label=label)
    axes[0, 0].set(title='验证总损失（低为好；用于选模）', xlabel='训练轮数', ylabel='损失')
    for ax, title in zip((axes[0, 1], axes[1, 0], axes[1, 1]), ('全部验证病例', '普通凸形 A', '全部内凹病例')):
        ax.set(title=title, xlabel='训练轮数', ylabel='病灶 IoU', ylim=(0, 1))
    for ax in axes.flat:
        ax.grid(alpha=.2)
    axes[0, 0].legend(fontsize=7)
    fig.suptitle('相同 v4 骨干、预算与划分：训练进展（验证集，不是测试集）', fontsize=15)
    fig.savefig(a.output_root/'training_progress.png', dpi=150)
    plt.close(fig)
    seeds = sorted({r['seed'] for r in histories})
    for seed in seeds:
        active = [r for r in histories if r['seed'] == seed and (r['path']/'best_preview.npz').exists()]
        active.sort(key=lambda r: list(LABELS).index(r['mode']))
        payload = {r['mode']: np.load(r['path']/'best_preview.npz', allow_pickle=False) for r in active}
        if not payload:
            continue
        first = next(iter(payload.values()))
        ids = sorted({k.split('__')[0] for k in first.files})
        fig, axes = plt.subplots(len(ids), len(active)+1, figsize=(3.5*(len(active)+1), 2.35*len(ids)), squeeze=False, constrained_layout=True)
        for row, cid in enumerate(ids):
            truth = first[cid+'__truth_mask'][0]
            axes[row, 0].imshow(truth, origin='lower', cmap='Greys', vmin=0, vmax=1)
            axes[row, 0].set_ylabel(cid, fontsize=10)
            for col, record in enumerate(active, 1):
                probs = payload[record['mode']][cid+'__probabilities']
                pred = probs.argmax(0) != 0
                inter, union = np.logical_and(pred, truth).sum(), np.logical_or(pred, truth).sum()
                axes[row, col].imshow(pred, origin='lower', cmap='Greys', vmin=0, vmax=1)
                # Red contours show truth; black image shows reconstructed lesion.
                axes[row, col].contour(truth, levels=[.5], colors='#e03131', linewidths=.65)
                axes[row, col].set_title(f'{LABELS[record["mode"]]} / 已训练 {record["history"][-1]["epoch"]} 轮\nIoU={inter/max(union,1):.3f}', fontsize=9)
            axes[row, 0].set_title('病灶真值', fontsize=9)
            for ax in axes[row]:
                ax.set_xticks([])
                ax.set_yticks([])
        fig.suptitle(f'固定验证病例：seed {seed}，各方法当前验证损失最优模型\n黑色：重建；红线：真值边界。训练进行中，不能提前判定最终效果。', fontsize=13)
        fig.savefig(a.output_root/f'validation_comparison_seed{seed}.png', dpi=140)
        plt.close(fig)
        for z in payload.values():
            z.close()
    print(a.output_root/'training_progress.png', flush=True)


if __name__ == '__main__':
    main()
