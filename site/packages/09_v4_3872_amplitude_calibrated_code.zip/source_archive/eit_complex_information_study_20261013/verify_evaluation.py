"""Verify identical clean features and observable phase/amplitude stress controls."""
import argparse
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np
from run_experiment import variant_features, write_json
from evaluate_experiment import from_q, noisy_features


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--dataset-root', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    rows = json.loads((a.dataset_root/'splits.json').read_text(encoding='utf-8'))['splits']
    selected = [next(r for r in rows if r['split'] == 'train' and r['shape_class'] == c) for c in 'ABCD']
    volts, refs, features = [], [], {m: [] for m in ('amplitude', 'complex', 'calibrated', 'amplitude_calibrated')}
    for row in selected:
        with np.load(a.dataset_root/row['file'], allow_pickle=False) as z:
            v, b = z['voltage'], z['background_voltage']
        qv, qb = v-np.roll(v, -1, axis=-1), b-np.roll(b, -1, axis=-1)
        actual = variant_features(v, b)
        for mode in features:
            expected = from_q(qv, qb, mode)
            np.testing.assert_array_equal(actual[mode], expected)
            features[mode].append(expected)
        volts.append(v)
        refs.append(b)
    cache = SimpleNamespace(rows=selected, voltage=np.array(volts), background=np.array(refs),
                            features={m: np.array(v) for m, v in features.items()})
    plan = json.loads((Path(__file__).parent/'EVALUATION_PLAN.json').read_text(encoding='utf-8'))
    for scenario in plan['noise_scenarios']:
        if scenario['name'] == 'clean':
            continue
        for mode in features:
            x = noisy_features(cache, mode, scenario, plan['stress_seed'])
            y = noisy_features(cache, mode, scenario, plan['stress_seed'])
            assert np.isfinite(x).all()
            np.testing.assert_array_equal(x, y)
            if mode in ('amplitude', 'amplitude_calibrated') and 'phase' in scenario['name']:
                np.testing.assert_allclose(x, cache.features[mode], atol=1e-9, rtol=1e-6)
            else:
                assert not np.array_equal(x, cache.features[mode])
    result = {'status': 'PASS', 'clean_training_and_evaluation_features_exactly_equal': True,
              'stress_inputs_repeatable': True, 'amplitude_phase_only_control_unchanged': True,
              'all_stress_features_finite': True, 'test_data_read': False,
              'source_cases': [r['case_id'] for r in selected]}
    write_json(a.output, result)
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    main()
