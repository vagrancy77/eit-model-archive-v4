"""Matched-input v4 experiment on the official train/validation partitions.

No test samples are loaded. All variants have exactly the same v4 parameters,
loss, initialization (within seed), data order, protocol and training budget.
The calibrated variant changes only the difference representation, not the
available observations. This is not yet a learned phase reliability module.
"""
from __future__ import annotations

import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import argparse
import hashlib
import json
import math
import random
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F
from torch.utils.data import Dataset, DataLoader

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent / 'eit_reproduction'
sys.path.insert(0, str(PROJECT))
from comsol_v4.data_v6 import (ComsolDataset, grid_arrays, signature, row_case_path,
                               FREQUENCIES, FINAL_DATASET_ROOT, assert_final_dataset)
from comsol_v4.data_v6 import read_measurements, verify_manifest
from comsol_v4.model import V4Comsol as NativeV4Comsol
from comsol_v4.losses import compute_loss
from comsol_v4.metrics import aggregate
from pytorch_eit.topology_residual_net import InputAdapter
from complex_features_prototype import build_inputs, measurement_mask, self_check

FORMAT = 'v4-complex-information-controlled-v1'
MODES = ('amplitude', 'complex', 'calibrated', 'amplitude_calibrated')


class DeterministicAdapter(InputAdapter):
    """Same median value; stable sort defines the subgradient when values tie."""
    def forward(self, image):
        batch = image.shape[0]
        selected = image[:, 0, self.mask[0, 0].bool()]
        center = selected.sort(dim=1, stable=True).values[:, (selected.shape[1]-1)//2].reshape(batch, 1, 1, 1)
        centered = (image-center)*self.mask
        selected_abs = centered[:, 0, self.mask[0, 0].bool()].abs()
        scale = torch.quantile(selected_abs, .985, dim=1).clamp_min(1e-5).reshape(batch, 1, 1, 1)
        signed = torch.clamp(centered/scale, -3., 3.)/3.*self.mask
        smooth3 = F.avg_pool2d(signed, 3, 1, 1)*self.mask
        smooth7 = F.avg_pool2d(signed, 7, 1, 3)*self.mask
        gx = F.conv2d(signed, self.sobel_x, padding=1)*self.mask
        gy = F.conv2d(signed, self.sobel_y, padding=1)*self.mask
        edge = torch.sqrt(gx.square()+gy.square()+1e-8).clamp(0, 1)*self.mask
        return torch.cat((signed, smooth3, smooth7, gx, gy, edge), 1)


class V4Comsol(NativeV4Comsol):
    def __init__(self, fov_mask, **kwargs):
        super().__init__(fov_mask, **kwargs)
        self.adapter = DeterministicAdapter(fov_mask)


def write_json(path, payload):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    temporary.replace(path)


def tensor_hash(state):
    digest = hashlib.sha256()
    for key, tensor in sorted(state.items()):
        digest.update(key.encode())
        digest.update(tensor.detach().cpu().numpy().tobytes())
    return digest.hexdigest()


def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def variant_features(v, b):
    payload = build_inputs(v, b)
    amp = np.zeros((12, 32, 32), dtype=np.float32)
    # Match V/B/dV channel positions. Imaginary slots remain ZERO in this control.
    amp[0:2] = payload['amplitude_only'][0:2]
    amp[4:6] = payload['amplitude_only'][2:4]
    amp[8:10] = payload['amplitude_only'][4:6]
    qv, qb = v-np.roll(v, -1, axis=-1), b-np.roll(b, -1, axis=-1)
    valid = measurement_mask()[None]
    rms = np.sqrt((np.abs(qb)**2 * valid).sum((1, 2), keepdims=True) / valid.sum())
    tau = .01 * rms
    relative = (qv-qb) * qb.conj() / (np.abs(qb)**2 + tau**2)
    calibrated = payload['raw_complex'].copy()
    # qV and qB remain untouched: complete observed complex information remains.
    # Replace redundant dV by reference-calibrated relative complex change.
    calibrated[8:10] = relative.real * valid
    calibrated[10:12] = relative.imag * valid
    amplitude_calibrated = amp.copy()
    amplitude_calibrated[8:10] = ((np.abs(qv)-np.abs(qb))*np.abs(qb)/(np.abs(qb)**2+tau**2))*valid
    return {'amplitude': amp, 'complex': payload['raw_complex'], 'calibrated': calibrated,
            'amplitude_calibrated': amplitude_calibrated}


class IdentityNormalizer:
    def __call__(self, x):
        return np.asarray(x, dtype=np.float32)


class Cache:
    def __init__(self, root, split):
        # The existing reader supplies unchanged targets; its old feature output
        # is discarded. No spatial truth participates in variant_features.
        source = ComsolDataset(root, split, IdentityNormalizer())
        self.rows, self.fov, self.x, self.y = source.rows, source.fov, source.x, source.y
        self.features = {mode: np.empty((len(source), 12, 32, 32), np.float32) for mode in MODES}
        self.voltage = np.empty((len(source), 2, 32, 32), np.complex128)
        self.background = np.empty_like(self.voltage)
        self.targets = None
        for i in range(len(source)):
            item = source[i]
            targets = {k: v for k, v in item.items() if torch.is_tensor(v) and k != 'features'}
            if self.targets is None:
                self.targets = {k: torch.empty((len(source), *v.shape), dtype=v.dtype) for k, v in targets.items()}
            for key, value in targets.items():
                self.targets[key][i] = value
            v,b,_,_=read_measurements(row_case_path(root,self.rows[i]))
            self.voltage[i], self.background[i] = v, b
            for mode, features in variant_features(v, b).items():
                self.features[mode][i] = features
            if (i+1) % 500 == 0:
                print(f'cache {split} {i+1}/{len(source)}', flush=True)
        print(f'cache {split} complete: {len(source)} cases', flush=True)


class ControlledDataset(Dataset):
    def __init__(self, cache, mode, mean, std, override=None):
        self.cache, self.mode = cache, mode
        source = cache.features[mode] if override is None else override
        self.features = torch.from_numpy(((source-mean)/std).astype(np.float32))
        if not torch.isfinite(self.features).all():
            raise ValueError('Nonfinite normalized features')

    def __len__(self):
        return len(self.cache.rows)

    def __getitem__(self, index):
        row = self.cache.rows[index]
        return {'features': self.features[index], 'case_id': row['case_id'], 'shape_class': row['shape_class'],
                'position_id': row['position_id'], **{k: v[index] for k, v in self.cache.targets.items()}}


@torch.no_grad()
def fast_metrics(out, batch, fov):
    """Vectorize the established v4 metrics, preserving their definitions."""
    domain = fov[0, 0].bool()
    pred, base, truth = out['probabilities'].argmax(1), out['base_probabilities'].argmax(1), batch['labels']
    gt, pr, bp = truth[:, domain], pred[:, domain], base[:, domain]
    def fg(a):
        inter = ((a != 0) & (gt != 0)).sum(1)
        union = ((a != 0) | (gt != 0)).sum(1).clamp_min(1)
        size = ((a != 0).sum(1)+(gt != 0).sum(1)).clamp_min(1)
        return inter/union, 2*inter/size
    iou, dice = fg(pr)
    base_iou, _ = fg(bp)
    class_values, present = [], []
    for cls in (0, 1, 2):
        union = ((gt == cls)|(pr == cls)).sum(1)
        class_values.append(((gt == cls)&(pr == cls)).sum(1)/union.clamp_min(1))
        present.append((union > 0).float())
    cut = batch['cutout'][:, 0, domain] > .5
    cut_recall = ((pr == 0) & cut).sum(1)/cut.sum(1).clamp_min(1)
    scores = {'foreground_iou': iou, 'foreground_dice': dice,
              'mean_iou_present_classes': torch.stack(class_values).sum(0)/torch.stack(present).sum(0),
              'base_foreground_iou': base_iou, 'iou_change_from_base': iou-base_iou,
              'cutout_background_recall': cut_recall}
    for key in ('sigma', 'eps_r'):
        p, t = out[key][:, :, domain], batch[key][:, :, domain]
        score = ((p-t).square().sum(-1)/t.square().sum(-1).clamp_min(1e-20)).sqrt()
        lesion = (batch['mask'][:, 0, domain] > .5)[:, None]
        region_score = ((p-t).square().mul(lesion).sum(-1)/t.square().mul(lesion).sum(-1).clamp_min(1e-20)).sqrt()
        for j, freq in enumerate((10000, 50000)):
            scores[f'{key}_nrmse_{freq}Hz'] = score[:, j]
            scores[f'{key}_lesion_nrmse_{freq}Hz'] = region_score[:, j]
    x, y = out['sigma'], batch['sigma']
    mx, my = F.avg_pool2d(x, 7, 1, 3), F.avg_pool2d(y, 7, 1, 3)
    vx = (F.avg_pool2d(x*x, 7, 1, 3)-mx*mx).clamp_min(0)
    vy = (F.avg_pool2d(y*y, 7, 1, 3)-my*my).clamp_min(0)
    cov = F.avg_pool2d(x*y, 7, 1, 3)-mx*my
    yrange = (y[:, :, domain].amax(-1)-y[:, :, domain].amin(-1)).clamp_min(1e-6)[:, :, None, None]
    c1, c2 = (.01*yrange)**2, (.03*yrange)**2
    smap = ((2*mx*my+c1)*(2*cov+c2))/((mx*mx+my*my+c1)*(vx+vy+c2)).clamp_min(1e-20)
    svalid = F.avg_pool2d(fov, 7, 1, 3)[0, 0] > .999
    for j, freq in enumerate((10000, 50000)):
        scores[f'sigma_ssim_{freq}Hz'] = smap[:, j, svalid].mean(-1)
    values = {k: v.cpu().numpy() for k, v in scores.items()}
    has_cut = cut.any(1).cpu().numpy()
    return [{'case_id': batch['case_id'][i], 'shape_class': batch['shape_class'][i],
             'position_id': batch['position_id'][i],
             **{k: float(v[i]) if k != 'cutout_background_recall' or has_cut[i] else None
                for k, v in values.items()}} for i in range(len(pr))]


def move(batch):
    return {k: v.cuda(non_blocking=True) if torch.is_tensor(v) else v for k, v in batch.items()}


def forward(net, batch):
    with torch.autocast('cuda', dtype=torch.bfloat16):
        out = net(batch['features'], batch['frequencies_hz'])
    # Loss, SSIM and reductions operate in FP32. BF16 avoids overflow of eps_r.
    return {k: v.float() for k, v in out.items()}


def train_epoch(net, loader, opt, fov, strength):
    net.train()
    total = count = 0
    for raw in loader:
        batch = move(raw)
        out = forward(net, batch)
        loss, _ = compute_loss(out, batch, fov, strength)
        if not torch.isfinite(loss):
            raise FloatingPointError('Nonfinite training loss')
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(net.parameters(), 1., error_if_nonfinite=True)
        opt.step()
        n = len(batch['features'])
        count += n
        total += float(loss.detach()) * n
    return total/count


@torch.no_grad()
def validate(net, loader, fov, cache=None, export=None):
    net.eval()
    total = count = 0
    records, saved = [], {}
    sample_ids = set()
    if cache is not None:
        # Choose two position groups without consulting predictions or labels.
        positions = sorted({r['position_id'] for r in cache.rows}, key=lambda x: int(x[1:]))[:2]
        for c in sorted({r['shape_class'] for r in cache.rows}):
            for pos in positions:
                selected = next(r for r in cache.rows if r['shape_class'] == c and r['position_id'] == pos and r['material_combination_id'] == 'M01')
                sample_ids.add(selected['case_id'])
    for raw in loader:
        batch = move(raw)
        out = forward(net, batch)
        loss, _ = compute_loss(out, batch, fov, 1.)
        if not torch.isfinite(loss):
            raise FloatingPointError('Nonfinite validation loss')
        n = len(batch['features'])
        count += n
        total += float(loss) * n
        records.extend(fast_metrics(out, batch, fov))
        if export:
            for key in ('sigma', 'eps_r', 'probabilities', 'base_probabilities', 'sdf', 'raw_cutout_probability', 'case_gate'):
                saved.setdefault(key, []).append(out[key].cpu().numpy())
        elif sample_ids:
            for i, cid in enumerate(batch['case_id']):
                if cid in sample_ids:
                    saved[cid] = {'probabilities': out['probabilities'][i].cpu().numpy(),
                                  'sigma': out['sigma'][i].cpu().numpy(),
                                  'eps_r': out['eps_r'][i].cpu().numpy(),
                                  'truth_mask': batch['mask'][i].cpu().numpy(),
                                  'truth_sigma': batch['sigma'][i].cpu().numpy(),
                                  'truth_eps_r': batch['eps_r'][i].cpu().numpy()}
    if export:
        arrays = {k: np.concatenate(v) for k, v in saved.items()}
        arrays.update({f'truth_{k}': v.numpy() for k, v in cache.targets.items() if k != 'frequencies_hz'})
        arrays.update(case_ids=np.array([r['case_id'] for r in cache.rows]),
                      positions=np.array([r['position_id'] for r in cache.rows]),
                      shape_classes=np.array([r['shape_class'] for r in cache.rows]),
                      material_combinations=np.array([r['material_combination_id'] for r in cache.rows]),
                      fov=cache.fov, x=cache.x, y=cache.y)
        np.savez_compressed(export, **arrays)
    return total/count, records, saved if not export else None


def plot_progress(output):
    python = HERE.parent / 'Anaconda' / 'python.exe'
    python = Path('E:/Anaconda/python.exe') if not python.exists() else python
    result = subprocess.run([str(python), str(HERE/'plot_experiment.py'), '--output-root', str(output)],
                            capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=60)
    if result.returncode:
        print('PLOT ERROR: ' + result.stderr[-2000:], flush=True)


def save_preview(path, values):
    arrays = {}
    for cid, data in values.items():
        for key, value in data.items():
            arrays[cid + '__' + key] = value
    np.savez_compressed(path, **arrays)


def train_run(args, train, val, norms, mode, seed):
    run = args.output_dir / f'{mode}_seed{seed}'
    run.mkdir(parents=True, exist_ok=True)
    if (run/'completed.json').exists():
        print(f'SKIP completed {run.name}', flush=True)
        return
    mean, std = norms[mode]
    tr = ControlledDataset(train, mode, mean, std)
    va = ControlledDataset(val, mode, mean, std)
    generator = torch.Generator().manual_seed(seed+17)
    loaders = {'train': DataLoader(tr, batch_size=args.batch_size, shuffle=True, generator=generator, num_workers=0, pin_memory=True),
               'val': DataLoader(va, batch_size=args.batch_size, shuffle=False, num_workers=0, pin_memory=True)}
    seed_all(seed)
    net = V4Comsol(train.fov, base=args.base).cuda()
    opt = torch.optim.AdamW(net.parameters(), lr=args.lr, weight_decay=1e-4)
    config = {'base': args.base, 'propagation_steps': 14, 'physics_input': False}
    initial_hash = tensor_hash(net.state_dict())
    fov = torch.from_numpy(train.fov.astype(np.float32))[None, None].cuda()
    history, best, start = [], float('inf'), 0
    if (run/'last.pt').exists():
        checkpoint = torch.load(run/'last.pt', map_location='cpu', weights_only=True)
        if checkpoint['protocol'] != args.protocol or checkpoint['mode'] != mode or checkpoint['seed'] != seed:
            raise ValueError('Resume protocol mismatch')
        net.load_state_dict(checkpoint['model'])
        opt.load_state_dict(checkpoint['optimizer'])
        history, best, start = checkpoint['history'], checkpoint['best_score'], checkpoint['epoch']
        torch.set_rng_state(checkpoint['rng_torch'])
        torch.cuda.set_rng_state_all(checkpoint['rng_cuda'])
        generator.set_state(checkpoint['loader_rng'])
        print(f'RESUME {run.name} epoch={start}', flush=True)
    print(f'RUN {run.name} params={sum(p.numel() for p in net.parameters())} initial_hash={initial_hash}', flush=True)
    for epoch in range(start, args.epochs):
        tick = time.monotonic()
        # Identical fixed schedule in all modes. No early stopping or test selection.
        lr = args.lr * (.1 + .9 * .5 * (1 + math.cos(math.pi * epoch / max(args.epochs-1, 1))))
        for group in opt.param_groups:
            group['lr'] = lr
        loss = train_epoch(net, loaders['train'], opt, fov, min(1., (epoch+1)/10))
        vloss, rows, preview = validate(net, loaders['val'], fov, val)
        metrics = aggregate(rows)
        history.append({'epoch': epoch+1, 'train_loss': loss, 'val_loss': vloss,
                        'lr': lr, 'seconds': time.monotonic()-tick, 'val_metrics': metrics})
        improved = vloss < best
        best = min(best, vloss)
        checkpoint = {'format': FORMAT, 'model': net.state_dict(), 'optimizer': opt.state_dict(),
                      'protocol': args.protocol, 'mode': mode, 'seed': seed, 'epoch': epoch+1,
                      'model_config': config, 'normalizer': {'mean': torch.from_numpy(mean), 'std': torch.from_numpy(std)},
                      'fov': torch.from_numpy(train.fov), 'x': torch.from_numpy(train.x), 'y': torch.from_numpy(train.y),
                      'history': history, 'best_score': best, 'initial_state_sha256': initial_hash,
                      'rng_torch': torch.get_rng_state(), 'rng_cuda': torch.cuda.get_rng_state_all(),
                      'loader_rng': generator.get_state(), 'test_evaluated': False}
        # Atomic checkpoints preserve the last usable state if a process is interrupted.
        torch.save(checkpoint, run/'last.pt.tmp')
        (run/'last.pt.tmp').replace(run/'last.pt')
        if improved:
            torch.save({k: v for k, v in checkpoint.items() if k not in ('optimizer', 'rng_torch', 'rng_cuda', 'loader_rng')}, run/'best.pt.tmp')
            (run/'best.pt.tmp').replace(run/'best.pt')
            save_preview(run/'best_preview.npz', preview)
        write_json(run/'history.json', {'mode': mode, 'seed': seed, 'initial_state_sha256': initial_hash,
                                       'epochs_requested': args.epochs, 'test_evaluated': False, 'history': history})
        print(f'{run.name} epoch={epoch+1}/{args.epochs} tr={loss:.4f} val={vloss:.4f} '
              f'IoU={metrics["all"]["foreground_iou"]:.4f} A={metrics["convex_A"]["foreground_iou"]:.4f} '
              f'B-E={metrics["concave_all"]["foreground_iou"]:.4f} seconds={history[-1]["seconds"]:.1f}', flush=True)
        if (epoch+1) % 5 == 0 or epoch+1 == args.epochs:
            plot_progress(args.output_dir)
    checkpoint = torch.load(run/'best.pt', map_location='cpu', weights_only=True)
    net.load_state_dict(checkpoint['model'])
    score, rows, _ = validate(net, loaders['val'], fov, val, export=run/'validation_predictions.npz')
    write_json(run/'validation_metrics.json', {'mode': mode, 'seed': seed, 'selected_epoch': checkpoint['epoch'],
               'selection': 'minimum validation full weighted loss', 'val_loss': score,
               'metrics': aggregate(rows), 'per_case': rows, 'test_evaluated': False})
    write_json(run/'completed.json', {'status': 'completed', 'mode': mode, 'seed': seed,
                                    'epochs_trained': len(history), 'selected_epoch': checkpoint['epoch'],
                                    'test_evaluated': False, 'updated_unix': time.time()})
    plot_progress(args.output_dir)
    del net, opt, tr, va, loaders
    torch.cuda.empty_cache()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--dataset-root', type=Path, default=FINAL_DATASET_ROOT)
    p.add_argument('--output-dir', type=Path, required=True)
    p.add_argument('--modes', nargs='+', choices=MODES, default=list(MODES[:3]))
    p.add_argument('--seeds', nargs='+', type=int, default=[20261013, 20261014, 20261015])
    p.add_argument('--epochs', type=int, default=40)
    p.add_argument('--batch-size', type=int, default=64)
    p.add_argument('--base', type=int, default=28)
    p.add_argument('--lr', type=float, default=4e-4)
    a = p.parse_args()
    if min(a.epochs, a.batch_size, a.base) < 1 or a.lr <= 0 or len(set(a.seeds)) != len(a.seeds):
        p.error('Invalid experiment configuration')
    if not torch.cuda.is_available() or not torch.cuda.is_bf16_supported():
        raise RuntimeError('This experiment requires the installed BF16-capable GPU runtime')
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms(True)
    a.dataset_root = a.dataset_root.resolve()
    a.output_dir = a.output_dir.resolve()
    final_contract = assert_final_dataset(a.dataset_root)
    verify_manifest(a.dataset_root)
    protocol = {'format': FORMAT, 'dataset_signature': signature(a.dataset_root),
                'final_dataset_contract': final_contract,
                'modes': a.modes, 'seeds': a.seeds, 'epochs': a.epochs, 'batch_size': a.batch_size,
                'base': a.base, 'lr': a.lr, 'optimizer': 'AdamW wd=1e-4 clip=1 cosine lr to 0.1lr',
                'measurement': 'adjacent electrode differences; exclude injecting/return pairs; 928 measurements/frequency',
                'amplitude': '|qV|/zero/|qB|/zero/(|qV|-|qB|)/zero, two frequencies each',
                'complex': 'Re(qV)/Im(qV)/Re(qB)/Im(qB)/Re(qV-qB)/Im(qV-qB)',
                'calibrated': 'complex with final dV channels replaced by r=(qV-qB)conj(qB)/(|qB|^2+tau^2)',
                'relative_floor': .01, 'normalization': 'per mode/channel/measurement fitted on train only',
                'selection': 'minimum validation total loss with full unchanged v4 topology weights',
                'ordinary_iou_noninferiority_margin': .01, 'physics_operator': None,
                'precision': 'BF16 model; FP32 losses and metrics', 'test_evaluated': False,
                'determinism': 'strict CUDA deterministic algorithms; adapter median via stable lower-median sort',
                'status': 'controlled_simulation_pilot_not_final_paper_evidence'}
    a.output_dir.mkdir(parents=True, exist_ok=True)
    protocol_path = a.output_dir/'protocol.json'
    if protocol_path.exists() and json.loads(protocol_path.read_text(encoding='utf-8')) != protocol:
        raise ValueError('Protocol changed; use a new output directory')
    write_json(protocol_path, protocol)
    a.protocol = protocol
    self_check()
    # No evaluation/test data is loaded, including during normalizer fitting.
    train, val = Cache(a.dataset_root, 'train'), Cache(a.dataset_root, 'val')
    norms = {}
    for mode in a.modes:
        features = train.features[mode].astype(np.float64)
        mean, std = features.mean(0), features.std(0)
        std[std < 1e-12] = 1.
        norms[mode] = mean.astype(np.float32), std.astype(np.float32)
        np.savez_compressed(a.output_dir/f'normalizer_{mode}.npz', mean=norms[mode][0], std=norms[mode][1],
                            fit_split='train', case_count=len(train.rows), case_ids=np.array([r['case_id'] for r in train.rows]))
        del features
    for seed in a.seeds:
        for mode in a.modes:
            train_run(a, train, val, norms, mode, seed)
    write_json(a.output_dir/'experiment_completed.json', {'status': 'all_prespecified_runs_complete',
               'modes': a.modes, 'seeds': a.seeds, 'epochs': a.epochs, 'test_evaluated': False})
    print('ALL PRESPECIFIED TRAIN/VALIDATION RUNS COMPLETE; TEST NOT RUN', flush=True)


if __name__ == '__main__':
    main()
