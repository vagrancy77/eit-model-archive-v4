"""Measure full v4 training cost on the installed GPU; synthetic timing only."""
import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'eit_reproduction'))
from run_experiment import V4Comsol
from comsol_v4.losses import compute_loss


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--batch-size', type=int, default=16)
    p.add_argument('--base', type=int, default=28)
    p.add_argument('--steps', type=int, default=8)
    p.add_argument('--channels-last', action='store_true')
    a = p.parse_args()
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms(True)
    torch.manual_seed(20261013)
    grid = Path(__file__).resolve().parent.parent / 'eit_dataset_audit_20261010' / 'extracted' / 'V6_3872_Minimal' / 'grid.npz'
    with np.load(grid) as z:
        mask = z['valid_mask']
    net = V4Comsol(mask, base=a.base).cuda()
    if a.channels_last:
        net = net.to(memory_format=torch.channels_last)
    opt = torch.optim.AdamW(net.parameters(), lr=4e-4)
    fov = torch.from_numpy(mask.astype(np.float32))[None, None].cuda()
    b = a.batch_size
    target = (torch.rand(b, 1, 64, 64, device='cuda') > .9).float() * fov
    batch = {'features': torch.randn(b, 12, 32, 32, device='cuda'), 'mask': target,
             'labels': target[:, 0].long(), 'sdf': torch.zeros_like(target),
             'cutout': torch.zeros_like(target), 'mouth': torch.zeros_like(target),
             'sigma': torch.full((b, 2, 64, 64), .1, device='cuda') * fov,
             'eps_r': torch.full((b, 2, 64, 64), 10000., device='cuda') * fov}
    if a.channels_last:
        batch['features'] = batch['features'].contiguous(memory_format=torch.channels_last)
    durations = []
    for i in range(a.steps):
        torch.cuda.synchronize()
        start = time.perf_counter()
        with torch.autocast('cuda', dtype=torch.bfloat16):
            out = net(batch['features'])
        out = {k: v.float() for k, v in out.items()}
        loss, _ = compute_loss(out, batch, fov)
        if not torch.isfinite(loss):
            raise FloatingPointError('Nonfinite synthetic benchmark loss')
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(net.parameters(), 1., error_if_nonfinite=True)
        opt.step()
        torch.cuda.synchronize()
        durations.append(time.perf_counter() - start)
        print(f'step {i+1} seconds={durations[-1]:.3f}', flush=True)
    print(json.dumps({'batch_size': b, 'base': a.base,
                      'parameters': sum(p.numel() for p in net.parameters()),
                      'median_step_seconds_after_warmup': float(np.median(durations[2:])),
                      'max_memory_GB': torch.cuda.max_memory_allocated() / 2**30,
                      'synthetic_timing_only': True}, indent=2), flush=True)


if __name__ == '__main__':
    main()
