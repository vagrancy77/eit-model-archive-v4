"""Standalone measurement-only inference for the controlled-input v4 checkpoints."""
import argparse
import json
from pathlib import Path

import numpy as np
import torch

from run_experiment import FORMAT, V4Comsol, variant_features, forward, write_json


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--checkpoint', type=Path, required=True)
    p.add_argument('--input-npz', type=Path, required=True)
    p.add_argument('--output-npz', type=Path, required=True)
    a = p.parse_args()
    if a.output_npz.exists():
        raise FileExistsError('Choose a new output file to preserve existing results')
    torch.set_num_threads(2)
    torch.use_deterministic_algorithms(True)
    c = torch.load(a.checkpoint, map_location='cpu', weights_only=True)
    if c.get('format') != FORMAT:
        raise ValueError('Use a checkpoint from this controlled complex-input experiment')
    with np.load(a.input_npz, allow_pickle=False) as z:
        # Only measurements and frequencies are read, including when truth exists.
        if not np.array_equal(z['frequencies_hz'], [10000, 50000]):
            raise ValueError('Expected ordered frequencies 10 kHz and 50 kHz')
        v, b = z['voltage'], z['background_voltage']
        feature = variant_features(v, b)[c['mode']]
    feature = (feature-c['normalizer']['mean'].numpy())/c['normalizer']['std'].numpy()
    if not np.isfinite(feature).all():
        raise ValueError('Nonfinite normalized input')
    model = V4Comsol(c['fov'].numpy(), **c['model_config']).cuda().eval()
    model.load_state_dict(c['model'])
    batch = {'features': torch.from_numpy(feature)[None].cuda(),
             'frequencies_hz': torch.tensor([[10000., 50000.]], device='cuda')}
    with torch.no_grad():
        out = forward(model, batch)
    data = {k: out[k][0].cpu().numpy() for k in
            ('sigma', 'eps_r', 'probabilities', 'foreground_probability', 'sdf',
             'raw_cutout_probability', 'mouth_probability', 'case_gate')}
    data.update(x=c['x'].numpy(), y=c['y'].numpy(), valid_mask=c['fov'].numpy(),
                frequencies_hz=np.array([10000, 50000]),
                metadata_json=json.dumps({'mode': c['mode'], 'seed': c['seed'], 'selected_epoch': c['epoch'],
                                          'labels_loaded': False, 'matched_physics_operator': False,
                                          'axis_order': 'frequency,y,x', 'sigma_unit': 'S/m', 'eps_r_unit': 'dimensionless'}))
    a.output_npz.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(a.output_npz, **data)
    print(a.output_npz, flush=True)


if __name__ == '__main__':
    main()
